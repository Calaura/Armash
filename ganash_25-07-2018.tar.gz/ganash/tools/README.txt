
launche test-report
launche documentation generatiorn
    QtCreator
    GtkDoc
    Doxygen
launche jenkins
