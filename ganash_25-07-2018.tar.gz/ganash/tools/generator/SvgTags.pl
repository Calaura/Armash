#!/usr/bin/perl

use strict;
use Tag;


require "SvgAttributes.pl";



sub getSvgTags {

    my @tags = ();

    #my  $svg_qualified_name_calc_mode = QualifiedName->new('svg', 'calcMode');
    #my  $svg_qualified_name_calc_mode = SvgQualifiedName->new('calcMode');
    #my  $attributes_calc_mode = Attribute->new($svg_qualified_name_calc_mode);
    #my  $attributes_calc_mode = Attribute->new('calcMode');# dont work : what prefix ?
    #my  $attributes_calc_mode = Attribute->new('svg', 'calcMode');# dont implemented
    #my  $attributes_calc_mode = Attribute->new('svg', 'calcMode', Enum('', '', ''));# dont implemented
    #$tags_animate->addAttribute($attributes_calc_mode);
    #$tags_animate->addAttribute('svg:calcMode');
    #$tags_animate->addAttribute('calcMode'); # Attribute use the same namespace than Tag

    # <svg:a>
    my  $tags_a = Tag->new(QualifiedName->new('svg', 'a'));
        $tags_a->setEnable(0);
    push(@tags, $tags_a);

    # <svg:animate>
    my  $tags_animate = Tag->new(QualifiedName->new('svg', 'animate'));
        $tags_animate->setEnable(1);
        $tags_animate->addAttributes(attributes_descriptive_elements());
        $tags_animate->addAttributes(attributes_conditional_processing());
        $tags_animate->addAttributes(attributes_core());
        $tags_animate->addAttributes(attributes_animation_event());
        $tags_animate->addAttributes(attributes_xlink());
        $tags_animate->addAttributes(attributes_animation_attribute_target());
        $tags_animate->addAttributes(attributes_animation_timing());
        $tags_animate->addAttributes(attributes_animation_value());
        $tags_animate->addAttributes(attributes_animation_addition());
        $tags_animate->addAttributes(attributes_presentation());
        $tags_animate->addAttributes(attributes_resources());
    push(@tags, $tags_animate);

    # <svg:animateColor>
    my  $tags_animateColor = Tag->new(QualifiedName->new('svg', 'animateColor'));
        $tags_animateColor->setEnable(0);
    push(@tags, $tags_animateColor);

    # <svg:animateMotion>
    my  $tags_animateMotion = Tag->new(QualifiedName->new('svg', 'animateMotion'));
        $tags_animateMotion->setEnable(0);
    push(@tags, $tags_animateMotion);

    # <svg:animateTransform>
    my  $tags_animateTransform = Tag->new(QualifiedName->new('svg', 'animateTransform'));
        $tags_animateTransform->setEnable(0);
    push(@tags, $tags_animateTransform);

    # <svg:circle>
    my  $tags_circle = Tag->new(QualifiedName->new('svg', 'circle'));
        $tags_circle->setEnable(0);
    push(@tags, $tags_circle);

    # <svg:clipPath>
    my  $tags_clipPath = Tag->new(QualifiedName->new('svg', 'clipPath'));
        $tags_clipPath->setEnable(0);
    push(@tags, $tags_clipPath);

    # <svg:cursor>
    my  $tags_cursor = Tag->new(QualifiedName->new('svg', 'cursor'));
        $tags_cursor->setEnable(0);
    push(@tags, $tags_cursor);

    # <svg:defs>
    my  $tags_defs = Tag->new(QualifiedName->new('svg', 'defs'));
        $tags_defs->setEnable(1);
    push(@tags, $tags_defs);

    # <svg:desc>
    my  $tags_desc = Tag->new(QualifiedName->new('svg', 'desc'));
        $tags_desc->setEnable(0);
    push(@tags, $tags_desc);

    # <svg:ellipse>
    my  $tags_ellipse = Tag->new(QualifiedName->new('svg', 'ellipse'));
        $tags_ellipse->setEnable(0);
    push(@tags, $tags_ellipse);

    # <svg:foreignObject>
    my  $tags_foreignObject = Tag->new(QualifiedName->new('svg', 'foreignObject'));
        $tags_foreignObject->setEnable(0);
    push(@tags, $tags_foreignObject);

    # <svg:g>
    my  $tags_g = Tag->new(QualifiedName->new('svg', 'g'));
        $tags_g->setEnable(1);
    push(@tags, $tags_g);

    # <svg:image>
    my  $tags_image = Tag->new(QualifiedName->new('svg', 'image'));
        $tags_image->setEnable(0);
    push(@tags, $tags_image);

    # <svg:line>
    my  $tags_line = Tag->new(QualifiedName->new('svg', 'line'));
        $tags_line->setEnable(0);
    push(@tags, $tags_line);

    # <svg:linearGradient>
    my  $tags_linearGradient = Tag->new(QualifiedName->new('svg', 'linearGradient'));
        $tags_linearGradient->setEnable(0);
    push(@tags, $tags_linearGradient);

    # <svg:marker>
    my  $tags_marker = Tag->new(QualifiedName->new('svg', 'marker'));
        $tags_marker->setEnable(0);
    push(@tags, $tags_marker);

    # <svg:mask>
    my  $tags_mask = Tag->new(QualifiedName->new('svg', 'mask'));
        $tags_mask->setEnable(0);
    push(@tags, $tags_mask);

    # <svg:metadata>
    my  $tags_metadata = Tag->new(QualifiedName->new('svg', 'metadata'));
        $tags_metadata->setEnable(0);
    push(@tags, $tags_metadata);

    # <svg:mpath>
    my  $tags_mpath = Tag->new(QualifiedName->new('svg', 'mpath'));
        $tags_mpath->setEnable(0);
    push(@tags, $tags_mpath);

    # <svg:path>
    my  $tags_path = Tag->new(QualifiedName->new('svg', 'path'));
        $tags_path->setEnable(1);
    push(@tags, $tags_path);

    # <svg:pattern>
    my  $tags_pattern = Tag->new(QualifiedName->new('svg', 'pattern'));
        $tags_pattern->setEnable(0);
    push(@tags, $tags_pattern);

    # <svg:polygon>
    my  $tags_polygon = Tag->new(QualifiedName->new('svg', 'polygon'));
        $tags_polygon->setEnable(0);
    push(@tags, $tags_polygon);

    # <svg:polyline>
    my  $tags_polyline = Tag->new(QualifiedName->new('svg', 'polyline'));
        $tags_polyline->setEnable(0);
    push(@tags, $tags_polyline);

    # <svg:radialGradient>
    my  $tags_radialGradient = Tag->new(QualifiedName->new('svg', 'radialGradient'));
        $tags_radialGradient->setEnable(0);
    push(@tags, $tags_radialGradient);

    # <svg:rect>
    my  $tags_rect = Tag->new(QualifiedName->new('svg', 'rect'));
        $tags_rect->setEnable(1);
        $tags_rect->addAttributes(attributes_conditional_processing());
        $tags_rect->addAttributes(attributes_core());
        $tags_rect->addAttributes(attributes_graphical_event());
        $tags_rect->addAttributes(attributes_presentation());
        $tags_rect->addAttribute('class',     'DomString', 1);
        $tags_rect->addAttribute('style',     'DomString', 1);
        $tags_rect->addAttributes(attributes_resources());
        $tags_rect->addAttribute('transform', 'SvgAnimatedTransform', 1);
        $tags_rect->addAttribute('x',         'SvgAnimatedLength', 1);
        $tags_rect->addAttribute('y',         'SvgAnimatedLength', 1);
        $tags_rect->addAttribute('width',     'SvgAnimatedLength', 1);
        $tags_rect->addAttribute('height',    'SvgAnimatedLength', 1);
        $tags_rect->addAttribute('rx',        'SvgAnimatedLength', 1);
        $tags_rect->addAttribute('ry',        'SvgAnimatedLength', 1);
    push(@tags, $tags_rect);

    # <svg:script>
    my  $tags_script = Tag->new(QualifiedName->new('svg', 'script'));
        $tags_script->setEnable(0);
    push(@tags, $tags_script);

    # <svg:set>
    my  $tags_set = Tag->new(QualifiedName->new('svg', 'set'));
        $tags_set->setEnable(0);
    push(@tags, $tags_set);

    # <svg:stop>
    my  $tags_stop = Tag->new(QualifiedName->new('svg', 'stop'));
        $tags_stop->setEnable(1);
    push(@tags, $tags_stop);

    # <svg:style>
    my  $tags_style = Tag->new(QualifiedName->new('svg', 'style'));
        $tags_style->setEnable(0);
    push(@tags, $tags_style);

    # <svg:svg>
    my  $tags_svg = Tag->new(QualifiedName->new('svg', 'svg'));
        $tags_svg->setEnable(1);
    push(@tags, $tags_svg);

    # <svg:switch>
    my  $tags_switch = Tag->new(QualifiedName->new('svg', 'switch'));
        $tags_switch->setEnable(0);
    push(@tags, $tags_switch);

    # <svg:symbol>
    my  $tags_symbol = Tag->new(QualifiedName->new('svg', 'symbol'));
        $tags_symbol->setEnable(1);
    push(@tags, $tags_symbol);

    # <svg:text>
    my  $tags_text = Tag->new(QualifiedName->new('svg', 'text'));
        $tags_text->setEnable(0);
    push(@tags, $tags_text);

    # <svg:textPath>
    my  $tags_textPath = Tag->new(QualifiedName->new('svg', 'textPath'));
        $tags_textPath->setEnable(0);
    push(@tags, $tags_textPath);

    # <svg:title>
    my  $tags_title = Tag->new(QualifiedName->new('svg', 'title'));
        $tags_title->setEnable(0);
    push(@tags, $tags_title);

    # <svg:tref>
    my  $tags_tref = Tag->new(QualifiedName->new('svg', 'tref'));
        $tags_tref->setEnable(0);
    push(@tags, $tags_tref);

    # <svg:tspan>
    my  $tags_tspan = Tag->new(QualifiedName->new('svg', 'tspan'));
        $tags_tspan->setEnable(0);
    push(@tags, $tags_tspan);

    # <svg:use>
    my  $tags_use = Tag->new(QualifiedName->new('svg', 'use'));
        $tags_use->setEnable(1);
    push(@tags, $tags_use);

    # <svg:view>
    my  $tags_view = Tag->new(QualifiedName->new('svg', 'view'));
        $tags_view->setEnable(0);
    push(@tags, $tags_view);

    return @tags;
}

1;
