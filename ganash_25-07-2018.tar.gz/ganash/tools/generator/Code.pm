
package Code::Generator::Abstract;

sub new {
    my ($class, @args) = (@_);

    my $self = {
    };

    bless $self, $class;
    return $self;
}

sub generate {
    return ''; # what have been generated
}


# =============================================================================

#Class, Function, Object, Namespace
package Code::Generator::Object;

sub new {
    my ($class, @args) = (@_);

    my $self = {
    };

    bless $self, $class;
    return $self;
}

sub generate {
    return ''; # what have been generated
}
