<?php

namespace GLib\Code;

class CamelCase // helloDOMWorld
{
    function toSnackCase($string) {
        $className = $string;
        $className = preg_replace('/([A-Z][a-z])/', '_$1', $className);
        $className = preg_replace('/([a-z])([A-Z])/', '$1_$2', $className);
        $className = preg_replace('/-+| +/', '_', $className);
        $className = preg_replace('/^_/', '', $className);
        return $className;// strtoupper // HELLO_DOM_WORLD
    }
    function toPascalCase($string) {
        return ucfirst($string);
    }
    function toDashCase($string) {
        $fileName = $string;
        $fileName = preg_replace('/([A-Z][a-z])/', '-$1', $fileName);
        $fileName = preg_replace('/([a-z])([A-Z])/', '$1-$2', $fileName);
        $fileName = preg_replace('/_+| +/', '-', $fileName);
        $fileName = preg_replace('/^-/', '', $fileName);
        return $fileName;// strtoupper // hello-dom-world
    }

}


class SnackCase
{
    function toCamelCase($string) {
        return '';
    }
}

class PascalCase
{
    function toCamelCase($string) {
        return '';
    }
}

class Naming
{
    var $namespace;
    var $name;

    function __construct($name, $namespace=null) {// QualifiedName
        $this->name = $name;
        $this->namespace = $namespace;
    }

    function className() {
        return strtolower(CamelCase::toSnackCase($this->namespace)) . '_' . strtolower(CamelCase::toSnackCase($this->name));
    }
    function typeName() {
        return CamelCase::toPascalCase($this->namespace) . CamelCase::toPascalCase($this->name);
    }
    function macroName() {
        return strtoupper(CamelCase::toSnackCase($this->namespace)) . '_' . strtoupper(CamelCase::toSnackCase($this->name));
    }

    function toName() {
        return strtolower(CamelCase::toSnackCase($this->namespace)) . '_' . strtolower(CamelCase::toSnackCase($this->name));
    }
    function toType() {
        return CamelCase::toPascalCase($this->namespace) . CamelCase::toPascalCase($this->name);
    }
    function toMacroType() {
        return strtoupper(CamelCase::toSnackCase($this->namespace)) . '_TYPE_' . strtoupper(CamelCase::toSnackCase($this->name));
    }
    function toFileSystem() {
        return strtolower(CamelCase::toDashCase($this->namespace)) . '-' . strtolower(CamelCase::toDashCase($this->name));
    }

}
