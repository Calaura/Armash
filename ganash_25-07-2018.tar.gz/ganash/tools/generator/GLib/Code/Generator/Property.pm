
package GLib::Code::Generator::Property;
sub new {
    my $class = shift;

    my $self = {
        path => shift,
        filename => shift,
    };

    bless($self, $class);
    return $self;
}

sub generate {
    my $self = @_;

    return "generate Property\n";
}

1;
