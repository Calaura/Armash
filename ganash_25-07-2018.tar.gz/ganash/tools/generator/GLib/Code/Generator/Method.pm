
package GLib::Code::Generator::Method;
sub new {
    my $class = shift;

    my $self = {
        path => shift,
        filename => shift,
    };

    bless($self, $class);
    return $self;
}

sub generate {
    my $self = @_;

    return "generate Method\n";
}

1;
