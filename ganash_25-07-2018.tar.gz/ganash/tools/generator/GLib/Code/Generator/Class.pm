
package GLib::Code::Generator::Class;
our @ISA = qw(GLib::Code::Generator::Abstract);

sub new {
    my ($class, $qualified_name) = (@_);

    my  $self = $class->SUPER::new();
        $self->{qualified} = $qualified_name;
        $self->{extends} = [];
        $self->{interfaces} = [];
        $self->{constants} = [];
        $self->{members} = [];
        $self->{methods} = [];

    bless($self, $class);
    return($self);
}

sub generate {
  my $self = @_;
  return '';
}

sub addExtend {
  my ($self, $extend) = (@_);

  push $self->{extends}, $extend;
}

sub addInterface {
  my ($self, $interface) = (@_);

  push $self->{interfaces}, $interface;
}

sub addInterfaces {
  my ($self, $interfaces) = (@_);

  my $id = 0;

  return '';
}

1;
