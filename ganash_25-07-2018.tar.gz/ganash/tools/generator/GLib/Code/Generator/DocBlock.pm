
package GLib::Code::Generator::DocBlock;
sub new {
    my $class = shift;

    my $self = {
        path => shift,
        filename => shift,
    };

    bless($self, $class);
    return $self;
}

sub generate {
    my $self = @_;

    return "generate DocBlock\n";
}

1;
