
package GLib::Code::Generator::File;
sub new {
    #my ($class, $name) = (@_);
    my $class = shift;

    my $self = {
        path => shift,
        filename => shift,
    };

    bless($self, $class);
    return $self;
}

sub add {
    my ($self, $generator)
}

sub generate {
    my( $self ) = @_;

    print $self->{path}, $self->{filename}, "generate File...\n";
    return "generate File\n";
}

1;
