
package GLib::Code::Generator::Parameter;
sub new {
    my $class = shift;

    my $self = {
        path => shift,
        filename => shift,
    };

    bless($self, $class);
    return $self;
}

sub generate {
    my $self = @_;

    return "generate Parameter\n";
}

1;
