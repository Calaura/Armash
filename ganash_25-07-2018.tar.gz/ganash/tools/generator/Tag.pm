use warnings;
use strict;
use Data::Dumper;

package Wrapper;

sub upperCaseName
{
    my $name = shift;

    return uc $name;
}

sub camelCaseName
{
    my $name = shift;

    while ($name =~ /^(.*?)_(.*)/) {
        $name = $1 . ucfirst $2;
    }

    return ucfirst $name;
}

sub underscoreCaseName
{
    my ($param) = (@_);

    if (ref($param) eq 'QualifiedName') {
        my $name = $param->{name};
        $name =~ s/(?=[A-Z])/_/g;
        $name =~ s/(?=[\-])/_/g;
        $name =~ s/(\:)/_/g;
        $name =~ s/(__)/_/g;
        $name = substr $name, 1 if (substr($name, 0, 1) eq '_');# if start by _

        my $prefix = 0;
        if ($param->{prefix}) {
            $prefix = $param->{prefix};
            $prefix =~ s/(?=[A-Z])/_/g;
            $prefix =~ s/(?=[\-])/_/g;
            $prefix =~ s/(\:)/_/g;
            $prefix =~ s/(__)/_/g;
            $prefix = substr $prefix, 1 if (substr($prefix, 0, 1) eq '_');
        }

        return lc $prefix . '_' . lc $name;
    } else {
        my $name = $param;
        $name =~ s/(?=[A-Z])/_/g;
        $name =~ s/(?=[\-])/_/g;
        $name =~ s/(\:)/_/g;
        $name =~ s/(__)/_/g;
        $name = substr $name, 1 if (substr($name, 0, 1) eq '_');# if start by _

        return lc $name;
    }
}


sub defaultInterfaceName
{
    my ($qualifiedName) = (@_);
    die "No namespace found" if !$qualifiedName->{prefix};

    return Wrapper::camelCaseName($qualifiedName->{prefix}) . "Element" . Wrapper::camelCaseName($qualifiedName->{name})
}

sub defaultTypeName
{
    my ($qualifiedName) = (@_);
    die "No namespace found" if !$qualifiedName->{prefix};

    return Wrapper::upperCaseName($qualifiedName->{prefix}) . "_TYPE_ELEMENT_" . Wrapper::upperCaseName($qualifiedName->{name})
}

sub defaultCodeName
{
    my ($qualifiedName) = (@_);
    die "No namespace found" if !$qualifiedName->{prefix};

    my $name = Wrapper::underscoreCaseName($qualifiedName->{name});
    $name = Wrapper::upperCaseName($name);

    my $prefix = Wrapper::underscoreCaseName($qualifiedName->{prefix});
    $prefix = Wrapper::upperCaseName($prefix);

    $name = substr $name, 1 if (substr($name, 0, 1) eq '_');# if start by _

    return $prefix . "_" . $name;
}


package Value;
sub new {
    my ($class, $code) = (@_);

    my $self = {
        code => $code,
    };

    bless($self, $class);
    return($self);
}

package QualifiedName;
sub new {
    my ($class, $prefix, $name) = (@_);

    my $self = {
        prefix => $prefix,
        name => $name,
    };

    bless($self, $class);
    return($self);
}
sub toString {
    my ($self) = (@_);

    if ($self->{prefix}) {
        return $self->{prefix}. ":". $self->{name};
    } else {
        return $self->{name};
    }
}

package XmlQualifiedName;
sub new {
    my ($class, $name) = (@_);

    my $self = {
        prefix => 'xml',
        name => $name,
    };

    bless($self, $class);
    return($self);
}

package SvgQualifiedName;
sub new {
    my ($class, $name) = (@_);

    my $self = {
        prefix => 'svg',
        name => $name,
    };

    bless($self, $class);
    return($self);
}

package XlinkQualifiedName;
sub new {
    my ($class, $name) = (@_);

    my $self = {
        prefix => 'xlink',
        name => $name,
    };

    bless($self, $class);
    return($self);
}




package GLib::Code::Generator::File;
sub new {
    my ($class, $name) = (@_);

    my $self = {
        path => "",
        filename => '',
    };

    bless($self, $class);
    return $self;
}
sub add {
}
sub generate {
    return '';
}

package GLib::Code::Generator::Hash;
sub new {
    my ($class, $name) = (@_);

    my $qualified_name = QualifiedName->new(0, 0);
    my @words = split /\:/, $name;
    my $size = @words;
    if ($size > 2) {
        $qualified_name = QualifiedName->new($words[0], $words[2]);
    } else {
        if ($size == 2) {
            $qualified_name = QualifiedName->new($words[0], $words[1]);
        } else {
            $qualified_name = QualifiedName->new(0, $name);
        }
    }

    my @items = [];
    my $self = {
        qualified => $qualified_name,
        name => Wrapper::underscoreCaseName($qualified_name),
        code => Wrapper::underscoreCaseName($qualified_name),
        items => @items,
    };

    bless($self, $class);
    return($self);
}
sub add {
    my ($self, $name) = (@_);

    my $qualified_name = QualifiedName->new(0, 0);
    my @words = split /\:/, $name;
    my $size = @words;
    if ($size == 3) {
        $qualified_name = QualifiedName->new($words[1], $words[2]);
    } else {
        if ($size == 2) {
            $qualified_name = QualifiedName->new($words[0], $words[1]);
        } else {
            $qualified_name = QualifiedName->new($self->{qualified}->{prefix}, $name);
        }
    }

    my $item = {
        qualified => $qualified_name,
        name => Wrapper::underscoreCaseName($qualified_name),
        interface => Wrapper::defaultInterfaceName($qualified_name),
        type => Wrapper::defaultTypeName($qualified_name),
        code => Wrapper::defaultCodeName($qualified_name),
    };

    push $self->{items}, $item;
}

sub generateHeader {
    return '';
}
sub generateSource {
    my ($self, @args) = (@_);

    my $code_name = $self->{code} . 's';
    my $output = '';

    $output .= "\n";
    $output .= 'static GHashTable* '. $code_name. ' = NULL;'. "\n";
    $output .= 'GHashTable*'. "\n";
    $output .= $code_name. '_get()'. "\n";
    $output .= '{'. "\n";
    $output .= "\t". 'if ('. $code_name. ') {'. "\n";
    $output .= "\t". "\t". 'return '. $code_name. ';'. "\n";
    $output .= "\t". '}'. "\n";
    $output .= "\n";
    $output .= "\t". $code_name. ' = g_hash_table_new (g_str_hash, g_str_equal);'. "\n";
    $output .= "\n";
    my $id = 0;
    while ( $self->{items}[$id] ) {
        #print ::Dumper($self->{items}[$id]);
        #print "\t", 'g_hash_table_insert (svg_tag_names, DOM_QUALIFIED_NAME("', $hash->{name}->{prefix}, '", "', $hash->{name}->{name}, '"),   GINT_TO_POINTER (', $hash->{typeName}, '));', "\n";
        $output .= "\t". 'g_hash_table_insert ('. $code_name. ', "'. $self->{items}[$id]->{qualified}->toString(). '", GINT_TO_POINTER ('. $self->{items}[$id]->{type}. ')); '. "\n";
        $id++;
    }
    $output .= "\n";
    $output .= "\t". 'return '. $code_name. ';'. "\n";
    $output .= '}'. "\n";

    return $output;
}

sub generate {
    my ($self, @args) = (@_);

    my $str = '';
    $str .= $self->generateSource();
    $str .= "\n";
    $str .= $self->generateHeader();

    return $str;
}

package GLib::Code::Generator::Enum::Value;
sub new {
    my ($class, $name, $nick) = (@_);

    my $self = {
        name => $name,
        nick => $nick,
    };

    bless($self, $class);
    return($self);
}
sub setName {
    my ($self, $name) = (@_);
    $self->{name} = $name;
}
sub setNick {
    my ($self, $nick) = (@_);
    $self->{nick} = $nick;
}

package GLib::Code::Generator::Enum;
sub new {
    my ($class, $name) = (@_);

    my $qualified_name = QualifiedName->new(0, 0);
    if (ref($name) eq 'QualifiedName') {
        $qualified_name = $name;
    } else {
        my @words = split /\:/, $name;
        my $size = @words;
        if ($size > 2) {
            $qualified_name = QualifiedName->new($words[0], $words[2]);
        } else {
            if ($size == 2) {
                $qualified_name = QualifiedName->new($words[0], $words[1]);
            } else {
                $qualified_name = QualifiedName->new(0, $name);
            }
        }
    }

    my $self = {
        qualified => $qualified_name,
        name => Wrapper::underscoreCaseName($qualified_name),
        interface => Wrapper::defaultInterfaceName($qualified_name),
        type => Wrapper::defaultTypeName($qualified_name),
        code => Wrapper::defaultCodeName($qualified_name),
        items => [],
    };

    bless($self, $class);
    return($self);
}
sub add {
    my ($self, $name, $value) = (@_);

    my $qualified_name = QualifiedName->new(0, 0);
    if (ref($name) eq 'QualifiedName') {
        $qualified_name = $name;
    } else {
        my @words = split /\:/, $name;
        my $size = @words;
        if ($size == 3) {
            $qualified_name = QualifiedName->new($words[1], $words[2]);
        } else {
            if ($size == 2) {
                $qualified_name = QualifiedName->new($words[0], $words[1]);
            } else {
                $qualified_name = QualifiedName->new($self->{name}, $name);
            }
        }
    }

    if (not ref($value)) {
        $value = GLib::Code::Generator::Enum::Value->new();
        $value->setName(Wrapper::defaultCodeName($qualified_name));
        $value->setNick($qualified_name->{name});
    }

    my $item = {
        value => $value,
        qualified => $qualified_name,
        name => Wrapper::underscoreCaseName($qualified_name),
        interface => Wrapper::defaultInterfaceName($qualified_name),
        type => Wrapper::defaultTypeName($qualified_name),
        code => Wrapper::defaultCodeName($qualified_name),
    };

    push $self->{items}, $item;
}

sub generateHeader {
    my ($self, @args) = (@_);

    my $output = '';

    $output .= "\n";
    $output .= 'enum _'. Wrapper::camelCaseName($self->{name}). 's {'. "\n";
    my $id = 0;
    while ( $self->{items}[$id] ) {
        $output .= "\t". $self->{items}[$id]->{code}. ', '. "\n";
        $id++;
    }
    $output .= '};'. "\n";

    return $output;
}

sub generateSource {
    my ($self, @args) = (@_);

    my $output = '';

    $output .= "\n";
    $output .= 'GType'. "\n";
    $output .= $self->{name}. 's_get_type(void)'. "\n";
    $output .= '{'. "\n";
    $output .= "\n";
    $output .= "\t". 'static const GEnumValue values[] ='. "\n";
    $output .= "\t". '{'. "\n";
    my $id = 0;
    while ( $self->{items}[$id] ) {
        #print ::Dumper($self->{items}[$id]);
        $output .= "\t". "\t". '{ '. $self->{items}[$id]->{code}. ', "'. $self->{items}[$id]->{value}->{name}. '", "'. $self->{items}[$id]->{value}->{nick}. '"},'. "\n";
        $id++;
    }
    $output .= "\t". "\t". '{ 0, NULL, NULL},'. "\n";
    $output .= "\t". '};'. "\n";
    $output .= "\n";
    $output .= "\n";
    $output .= "\t". 'static GType type = 0;'. "\n";

    $output .= "\t". 'if (G_UNLIKELY (! type))'. "\n";
    $output .= "\t". '{'. "\n";
    $output .= "\t". "\t". 'type = g_enum_register_static ("'. Wrapper::camelCaseName($self->{name}). 's", values);'. "\n";
    $output .= "\t". '}'. "\n";


    $output .= "\t". 'return type;'. "\n";
    $output .= '}'. "\n";

    return $output;
}

sub generate {
    my ($self, @args) = (@_);

    my $str = '';
    $str .= $self->generateSource();
    $str .= "\n";
    $str .= $self->generateHeader();

    return $str;
}





package Code::Generator::Interface;
package GLib::Code::Generator::Abstract;
sub new {
    my ($class, @args) = (@_);

    my $self = {
    };

    bless $self, $class;
    return $self;
}
sub generate {
}

package GLib::Code::Generator::Parameter;
our @ISA = qw(GLib::Code::Generator::Abstract);
package GLib::Code::Generator::Member::Container;
package GLib::Code::Generator::Member;
our @ISA = qw(GLib::Code::Generator::Abstract);
package GLib::Code::Generator::Property;
our @ISA = qw(GLib::Code::Generator::Member);
package GLib::Code::Generator::Method;
our @ISA = qw(GLib::Code::Generator::Member);
package GLib::Code::Generator::File;
our @ISA = qw(GLib::Code::Generator::Abstract);

package GLib::Code::Generator::DocBlock::Tag;
our @ISA = qw(GLib::Code::Generator::Abstract);
package GLib::Code::Generator::DocBlock::Tag::ParamTag;
our @ISA = qw(GLib::Code::Generator::Tag);
package GLib::Code::Generator::DocBlock::Tag::ReturnTag;
our @ISA = qw(GLib::Code::Generator::Tag);


package Attribute;
sub new {
    my ($class, $qualifiedName, $type, $animatable) = (@_);

    if (! $type) {
        $type = 'DomString';
    }
    if (! $animatable) {
        $animatable = 0;
    }

    my $self = {
        name => $qualifiedName,
        type => $type,
        animatable => $animatable,
    };
    bless($self, $class);
    return($self);
}


package Property;
sub new {
    my $class = shift;

    my $self = {
        name => 0,
    };
    bless($self, $class);
    return($self);
}


package Tag;

#my $tags_rect = Tag->new('svg:rect');
#my @tags; push($tags, $tags_rect);
sub new {
    my ($class, $qualifiedName, $interfaceName, $typeName, $enable) = (@_);

    if (! $qualifiedName) {
        #Error
    }
    if (! $interfaceName) {
        $interfaceName = Wrapper::defaultInterfaceName($qualifiedName);
    }
    if (! $typeName) {
        $typeName = Wrapper::defaultTypeName($qualifiedName);# fixme pass $interfaceName
    }
    if (! $enable) {
        $enable = 0;
    } else {
        $enable = 1;
    }

    my $self = {
        enable => $enable,
        name => $qualifiedName,
        interfaceName => $interfaceName,
        typeName => $typeName,
        attributes => [],
    };

    bless($self, $class);
    return($self);
}

sub addAttribute {
    my ($self, $param) = (@_);

    if (ref($param) eq 'Attribute') {
        push($self->{attributes}, $param);
        return;
    }
    if (not ref($param)) {
        my @words = split /\:/, $param;
        my $size = @words;
        if ($size == 2) {
            my $qualifiedName = QualifiedName->new($words[0], $words[1]);
            my $attribute = Attribute->new($qualifiedName);
            push($self->{attributes}, $attribute);
        } else {
            my $qualifiedName = QualifiedName->new($self->{name}->{prefix}, $param);
            my $attribute = Attribute->new($qualifiedName);
            push($self->{attributes}, $attribute);
        }
        return;
    }

}

sub addAttributes {
    my ($self, @attributes) = (@_);

    for my $attribute ( @attributes ) {
        $self->addAttribute($attribute);
    }
}

sub setEnable {
    my ($self, $enable) = (@_);
    $self->{enable} = $enable;
}


package GLib::Code::Generator::Tag;
sub new {
}
sub generate {
  return '';
}
package GLib::Code::Generator::Tag::Param;
sub new {
}
sub generate {
  return '';
}
package GLib::Code::Generator::Doc;
sub new {
    my ($class, $tag) = (@_);
}
sub generate {
  return '';
}

package GLib::Code::Generator::Class;
our @ISA = qw(GLib::Code::Generator::Abstract);

sub new {
    my ($class, $qualified_name) = (@_);

    my  $self = $class->SUPER::new();
        $self->{qualified} = $qualified_name;
        $self->{extends} = [];
        $self->{interfaces} = [];
        $self->{constants} = [];
        $self->{members} = [];
        $self->{methods} = [];

    bless($self, $class);
    return($self);
}
sub generate {
  return '';
}
sub addExtend {
  my ($self, $extend) = (@_);

  push $self->{extends}, $extend;
}

sub addInterface {
  my ($self, $interface) = (@_);

  push $self->{interfaces}, $interface;
}

sub addInterfaces {
  my ($self, $interfaces) = (@_);

  my $id = 0;

  return '';
}

1;
