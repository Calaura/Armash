#!/usr/bin/perl

use strict;
use Tag;
#use Attribute


sub attributes_descriptive_elements {
    return [
        "desc",
        "metadata",
        "title"
    ];
}

sub attributes_conditional_processing {
    return [
        "requiredFeatures",
        "requiredExtensions",
        "systemLanguage"
    ];
}

sub attributes_core {
    return [
        "id",
        "xml:base",
        "xml:lang",
        "xml:space"
    ];
}

sub attributes_animation_event {
    return [
        "onbegin",
        "onend",
        "onrepeat",
        "onload"
    ];
}

sub attributes_graphical_event {
    return [
        "onfocusin",
        "onfocusout",
        "onactivate",
        "onclick",
        "onmousedown",
        "onmouseup",
        "onmouseover",
        "onmousemove",
        "onmouseout",
        "onload",
    ];
}

sub attributes_xlink {
    return [
        "xlink:href",
        "xlink:show",
        "xlink:actuate",
        "xlink:type",
        "xlink:role",
        "xlink:arcrole",
        "xlink:title"
    ];
}

sub attributes_animation_attribute_target {
    return [
        "attributeType",
        "attributeName"
    ];
}

=begin comment
my @attributes_animation_timing = (
    "begin",
    "dur",
    "end",
    "min",
    "max",
    "restart",
    "repeatCount",
    "repeatDur",
    "fill"
);
=cut

sub attributes_animation_timing {
    return [
        Attribute->new(QualifiedName->new('svg', 'begin'), 'SmilTime', 'SMIL_TYPE_TIME'),
        Attribute->new(QualifiedName->new('svg', 'dur'), 'SmilTime'),
        Attribute->new(QualifiedName->new('svg', 'end'), 'SmilTime'),
        Attribute->new(QualifiedName->new('svg', 'min'), 'SvgLength'),
        Attribute->new(QualifiedName->new('svg', 'max'), 'SvgLength'),
        Attribute->new(QualifiedName->new('svg', 'restart'), 'SmilEnumRestart'),
        Attribute->new(QualifiedName->new('svg', 'repeatCount'), 'DomInteger'),
        Attribute->new(QualifiedName->new('svg', 'repeatDur'), 'SmilTime'),
        Attribute->new(QualifiedName->new('svg', 'fill'), 'SmilEnumFill'),
    ];
}

sub attributes_animation_value {
    return [
        "calcMode",
        "values",
        "keyTimes",
        "keySplines",
        "from",
        "to",
        "by"
   ];
}

sub attributes_animation_addition {
    return [
        "additive",
        "accumulate"
    ];
}

sub attributes_presentation {
    return [
        "alignment-baseline",
        "baseline-shift",
        "clip",
        "clip-path",
        "clip-rule",
        "color",
        "color-interpolation",
        "color-interpolation-filters",
        "color-profile",
        "color-rendering",
        "cursor",
        "direction",
        "display",
        "dominant-baseline",
        "enable-background",
        "fill",
        "fill-opacity",
        "fill-rule",
        "filter",
        "flood-color",
        "flood-opacity",
        "font-family",
        "font-size",
        "font-size-adjust",
        "font-stretch",
        "font-style",
        "font-variant",
        "font-weight",
        "glyph-orientation-horizontal",
        "glyph-orientation-vertical",
        "image-rendering",
        "kerning",
        "letter-spacing",
        "lighting-color",
        "marker-end",
        "marker-mid",
        "marker-start",
        "mask",
        "opacity",
        "overflow",
        "pointer-events",
        "shape-rendering",
        "stop-color",
        "stop-opacity",
        "stroke",
        "stroke-dasharray",
        "stroke-dashoffset",
        "stroke-linecap",
        "stroke-linejoin",
        "stroke-miterlimit",
        "stroke-opacity",
        "stroke-width",
        "text-anchor",
        "text-decoration",
        "text-rendering",
        "unicode-bidi",
        "visibility",
        "word-spacing",
        "writing-mode"
    ];
}

sub attributes_resources {
    return ["externalResourcesRequired"];
}

1;
