#!/usr/bin/perl -w

# Copyright (C) 2005, 2006, 2007, 2009 Apple Inc. All rights reserved.
# Copyright (C) 2009, Julien Chaffraix <jchaffraix@webkit.org>
# Copyright (C) 2009 Torch Mobile Inc. All rights reserved. (http://www.torchmobile.com/)
# Copyright (C) 2011 Ericsson AB. All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# 1.  Redistributions of source code must retain the above copyright
#     notice, this list of conditions and the following disclaimer.
# 2.  Redistributions in binary form must reproduce the above copyright
#     notice, this list of conditions and the following disclaimer in the
#     documentation and/or other materials provided with the distribution.
# 3.  Neither the name of Apple Computer, Inc. ("Apple") nor the names of
#     its contributors may be used to endorse or promote products derived
#     from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY APPLE AND ITS CONTRIBUTORS "AS IS" AND ANY
# EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
# WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL APPLE OR ITS CONTRIBUTORS BE LIABLE FOR ANY
# DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
# ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
# THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

use strict;

use Config;
use Getopt::Long;
use File::Path;
use File::Spec;
use IO::File;
use InFilesParser;
use Data::Dumper;
use Tag;




sub readTags($$);
sub readAttrs($$);

my $printFactory = 0;
my $printWrapperFactory = 0;
my $printWrapperFactoryV8 = 0;
my $fontNamesIn = "";
my $tagsFile = "";
my $attrsFile = "";
my $outputDir = ".";
my %parsedTags = ();
my %parsedAttrs = ();
my %enabledTags = ();
my %enabledAttrs = ();
my %allTags = ();
my %allAttrs = ();
my %parameters = ();
my $extraDefines = 0;
my $initDefaults = 1;
my %extensionAttrs = ();

require Config;

my $gccLocation = "";
if ($ENV{CC}) {
    $gccLocation = $ENV{CC};
} elsif (($Config::Config{'osname'}) =~ /solaris/i) {
    $gccLocation = "/usr/sfw/bin/gcc";
} else {
    $gccLocation = "/usr/bin/gcc";
}
my $preprocessor = $gccLocation . " -E -x c++";

GetOptions(
    'tags=s' => \$tagsFile,
    'attrs=s' => \$attrsFile,
    'factory' => \$printFactory,
    'outputDir=s' => \$outputDir,
    'extraDefines=s' => \$extraDefines,
    'preprocessor=s' => \$preprocessor,
    'wrapperFactory' => \$printWrapperFactory,
    'wrapperFactoryV8' => \$printWrapperFactoryV8,
    'fonts=s' => \$fontNamesIn
);

=begin comment

mkpath($outputDir);

die "You must specify at least one of --tags <file> or --attrs <file>" unless (length($tagsFile) || length($attrsFile));

if (length($tagsFile)) {
    %allTags = %{readTags($tagsFile, 0)};
    %enabledTags = %{readTags($tagsFile, 1)};

    #print Dumper(%enabledTags);
}

if (length($attrsFile)) {
    %allAttrs = %{readTags($attrsFile, 0)};
    %enabledAttrs = %{readTags($attrsFile, 1)};

    #print Dumper(%enabledTags);
}

=cut

sub defaultParametersHash
{
    return (
        'namespace' => '',
        'namespacePrefix' => '',
        'namespaceURI' => '',
        'guardFactoryWith' => '',
        'tagsNullNamespace' => 0,
        'attrsNullNamespace' => 0,
        'fallbackInterfaceName' => ''
    );
}


## Support routines

sub preprocessorCommand()
{
    return $preprocessor if $extraDefines eq 0;
    return $preprocessor . " -D" . join(" -D", split(" ", $extraDefines));
}

sub svgCapitalizationHacks
{
    my $name = shift;

    $name = "FE" . ucfirst $1 if $name =~ /^fe(.+)$/;

    return $name;
}

sub upperCaseName
{
    my $name = shift;

    $parameters{namespace} = "Svg" if ($parameters{namespace} eq "SVG");
    #$name = svgCapitalizationHacks($name) if ($parameters{namespace} eq "SVG");

    while ($name =~ /^(.*?)_(.*)/) {
        $name = $1 . ucfirst $2;
    }

    return ucfirst $name;
}

sub defaultInterfaceName
{
    die "No namespace found" if !$parameters{namespace};
    return upperCaseName($parameters{namespace}) . "Element" . upperCaseName($_[0])
}

### Hash initialization

sub defaultTagPropertyHash
{
    return (
        'constructorNeedsCreatedByParser' => 0,
        'constructorNeedsFormElement' => 0,
        'noConstructor' => 0,
        'interfaceName' => defaultInterfaceName($_[0]),
        # By default, the JSInterfaceName is the same as the interfaceName.
        'JSInterfaceName' => defaultInterfaceName($_[0]),
        'mapToTagName' => '',
        'wrapperOnlyIfMediaIsAvailable' => 0,
        'conditional' => 0,
        'contextConditional' => 0,
        'runtimeConditional' => 0
    );
}

sub parametersHandler
{
    my ($parameter, $value) = @_;

    # Initialize default properties' values.
    %parameters = defaultParametersHash() if (!(keys %parameters) && $initDefaults);

    die "Unknown parameter $parameter for tags/attrs\n" if (!defined($parameters{$parameter}) && $initDefaults);
    $parameters{$parameter} = $value;
}

sub tagsHandler
{
    my ($tag, $property, $value) = @_;

    $tag =~ s/-/_/g;

    # Initialize default property values.
    $parsedTags{$tag} = { defaultTagPropertyHash($tag) } if !defined($parsedTags{$tag});

    if ($property) {
        die "Unknown property $property for tag $tag\n" if !defined($parsedTags{$tag}{$property});

        # The code relies on JSInterfaceName deriving from interfaceName to check for custom JSInterfaceName.
        # So override JSInterfaceName if it was not already set.
        $parsedTags{$tag}{JSInterfaceName} = $value if $property eq "interfaceName" && $parsedTags{$tag}{JSInterfaceName} eq $parsedTags{$tag}{interfaceName};

        $parsedTags{$tag}{$property} = $value;
    }
}

sub attrsHandler
{
    my ($attr, $property, $value) = @_;
    # Translate HTML5 extension attributes of the form 'x-webkit-feature' to 'webkitfeature'.
    # We don't just check for the 'x-' prefix because there are attributes such as x-height
    # which should follow the default path below.
    # if ($attr =~ m/^x-webkit-(.*)/) {
    #     my $newAttr = "webkit$1";
    #     $extensionAttrs{$newAttr} = $attr;
    #     $attr = $newAttr;
    # }
    # $attr =~ s/-/_/g;

    # Initialize default properties' values.
    $parsedAttrs{$attr} = {} if !defined($parsedAttrs{$attr});

    if ($property) {
        die "Unknown property $property for attribute $attr\n" if !defined($parsedAttrs{$attr}{$property});
        $parsedAttrs{$attr}{$property} = $value;
    }
}

sub readNames($$$$)
{
    my ($namesFile, $hashToFillRef, $handler, $usePreprocessor) = @_;

    my $names = new IO::File;
    if ($usePreprocessor) {
        open($names, preprocessorCommand() . " " . $namesFile . "|") or die "Failed to open file: $namesFile";
    } else {
        open($names, $namesFile) or die "Failed to open file: $namesFile";
    }

    my $InParser = InFilesParser->new();
    $InParser->parse($names, \&parametersHandler, $handler);

    close($names);
    die "Failed to read names from file: $namesFile" if (keys %{$hashToFillRef} == 0);
    return $hashToFillRef;
}

sub readTags($$)
{
    my ($namesFile, $usePreprocessor) = @_;
    %parsedTags = ();
    return readNames($namesFile, \%parsedTags, \&tagsHandler, $usePreprocessor);
}

sub readAttrs($$)
{
    my ($namesFile, $usePreprocessor) = @_;
    %parsedTags = ();
    return readNames($namesFile, \%parsedAttrs, \&attrsHandler, $usePreprocessor);
}

sub bar()
{
    for my $tagName (sort keys %enabledTags) {
        # Avoid defining the same wrapper method twice.
        #my $JSInterfaceName = $enabledTags{$tagName}{JSInterfaceName};
        #print "$tagName\n";
        print "# <svg:$tagName>\n";
        print 'my  $tags_', $tagName, ' = Tag->new(QualifiedName->new(\'svg\', \'', $tagName, '\'));', "\n";
        print '    $tags_', $tagName, '->setEnable(0);', "\n";
        print 'push(@tags, $tags_', $tagName, ');', "\n\n";

    }
}

sub makeEnumTags()
{
    my $tags = GLib::Code::Generator::Enum->new('Svg:Tag');

    for my $tagName (sort keys %enabledTags) {
        my $value = GLib::Code::Generator::Enum::Value->new();
           $value->setName('svg:'.$tagName);
           $value->setNick($tagName);
        my $qualified = QualifiedName->new('Svg:Tag', ucfirst($tagName));
        $tags->add($qualified, $value);
    }
    print $tags->generate();
}

sub makeHashTags()
{
    my $tags = GLib::Code::Generator::Hash->new('Svg:Tag');

    for my $tagName (sort keys %enabledTags) {
        $tags->add('svg:'.$tagName);
    }
    print $tags->generate();
}

sub makeEnumAttributes()
{
    my $attributes = GLib::Code::Generator::Enum->new('Svg:Attribute');

    for my $attributeName (sort keys %enabledAttrs) {
        my $value = GLib::Code::Generator::Enum::Value->new();
           $value->setName('svg:'.$attributeName);
           $value->setNick($attributeName);
        my $qualified = QualifiedName->new('Svg:Attribute', ucfirst($attributeName));
        $attributes->add($qualified, $value);
    }
    print $attributes->generate();
}

sub makeEnumSvgSpreadMethods()
{
    my  $spread_methods = GLib::Code::Generator::Enum->new('Svg:SpreadMethod');
        $spread_methods->add('pad');
        $spread_methods->add('repeat');
        $spread_methods->add('reflect');
    print $spread_methods->generate();
}

sub makeHash()
{
    my $attrs_size = keys %allAttrs;
    my $tags_size = keys %allTags;
    print $tags_size . ': tags; '.$attrs_size.': attributes'."\n"; # 81 tags; 246 attrs

    print 'struct PropertyHash {';
    #print "\t".'unsigned int tag:7;';# 2^7 = 128
    print "\t".'unsigned int attribute:8;';# 2^8 = 256
    print "\t".'unsigned int id:24;';# 2^24 = 16'777'216          2^17 = 131'072
    print '}';
}

#makeHashTags();
#makeEnumTags();
#makeEnumAttributes();
#makeEnumSvgSpreadMethods();

sub my_test()
{
    return "Hello Perl";
}

#TODO generate Tag:Property:InstanceCount = 32bits/64bits

my $property = GLib::Code::Generator::Property->new('height');
#   $property->setType('Svg:Animated:Length');
#   $property->setNick('height');
#   $property->setBlur('The height');
#   $property->setMin(100);
#   $property->setMax(200);
#   $property->setDefault(100);
    print $property->generate();

my  $svg_element_rect = GLib::Code::Generator::Class->new('Svg:Element:Rect');
    $svg_element_rect->addExtend('Svg:Element:Graphics');
    #$svg_element_rect->addInterfaces(['Svg:Stylable', 'Svg:Drawable', 'Svg:Locatable']);
    #$svg_element_rect->addInterface('Svg:Stylable');
    #$svg_element_rect->addProperty($property);
    print $svg_element_rect->generate();


my $gobject_header = new GLib::Code::Generator::File();
print GLib::Code::Generator::File->generate();
print "Hello World\n";

#print ::Dumper(%allAttrs);
