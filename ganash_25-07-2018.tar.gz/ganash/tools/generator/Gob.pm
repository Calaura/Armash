
package Gob::Code::Generator::Class;
sub new {
}
sub generate {
    my $TAB = "    ";

}


  enum LAME_CLIENT {
        IS_CONNECTED,
        NONE = 9,
        LAST
  } Test:Enum;

Gob::Code::Generator::Enum->new('Svg:Tags');
Gob::Code::Generator::File->new('svg-element-rect');
  ->addDocBlock();
  ->addClass();
  ->addEnum();
  ->addEntity();
Gob::Code::Generator::Class->new('Svg:Element:Rect');
  ->addInterface();
  ->add();
Gob::Code::Generator::Class->new('Svg:Rect');
