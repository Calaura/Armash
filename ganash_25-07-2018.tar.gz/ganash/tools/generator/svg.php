<?php

//include("math.inc.php");
//include("string.inc.php");
include("dom.inc.php");
include("xml.inc.php");
include("xlink.inc.php");
include("svg.inc.php");

define("ENABLE_SVG_FONTS", 1);
define("ENABLE_FILTERS", 1);
define("constructorNeedsCreatedByParser", True);

class GObject {
    var $parent;
    var $typeName;// G_TYPE_OBJECT
    var $className;// g_object
    var $fileName;// g-object.h/c
    function __construct() {

    }
}



class SvgTag
{
    var $code;
    var $name;
    var $qualifiedName;
    var $typeName;
    var $attributes;
    function __construct($qualified, $type=null, $flag=false) {
        $this->code = 0;
        $this->qualifiedName = $qualified;
        $this->typeName = $type;
        $this->name = null;

        $this->initCode();
        $this->initTypeName();
    }
    function initTypeName() {
        $this->typeName = $this->qualifiedName->toMacroType();
    }
    function initCode() {
        $this->code = Prime::getNext();
    }
    function addAttribute($attribute) {
        $this->attributes[$attribute->qualifiedName->toMacro()] = $attribute;
    }
    function addAttributes($attributes) {
        $this->attributes = array_merge($this->attributes, $attributes);
    }

}

class SvgAttribute /*extends DomAttribute*/
{
    var $code;
    var $qualifiedName;
    var $typeName;
    function __construct($qualified, $type=null, $flag=false) {
        $this->code = 0;
        $this->qualifiedName = $qualified;
        $this->typeName = $type;
    }
}


class Svg /*extends Generator*/
{
    static $namespace="svg";
    static $namespace_uri="http://www.w3.org/2000/svg";
    static $guardFactoryWith="ENABLE(SVG)";
    static $fallbackInterfaceName="element";

    var $tagNames=Array();
    var $attributeNames=Array();
    var $attributeGroups=Array();

    function __construct() {
        $this->initAttributes();
        $this->initGroupAttribute();
        $this->initTags();
    }

    function addTag($name, $type=null, $flag=false) {
        $tag = new SvgTag(new GLib\Code\Naming(Svg::$fallbackInterfaceName . ucfirst($name), Svg::$namespace), $type, $flag);
        $this->tagNames[$name] = $tag;
        return $tag;
    }

    function initTags() {
        $this->addTag('a');
        if (ENABLE_SVG_FONTS) {
            $this->addTag('altGlyph');//->addAttributes();
            $this->addTag('altGlyph');
            $this->addTag('altGlyphDef');
            $this->addTag('altGlyphItem');
        }
        $this->addTag('animate');
        $this->addTag('animateColor');
        $this->addTag('animateMotion');
        $this->addTag('animateTransform');
        $this->addTag('set');
        $this->addTag('circle');
        $this->addTag('clipPath');
        if (0) {
            $this->addTag('color_profile');
        }
        $this->addTag('cursor');
        $this->addTag('defs');
        $this->addTag('desc');
        $this->addTag('ellipse');

        if (ENABLE_FILTERS) {
            $this->addTag('feBlend');
            $this->addTag('feColorMatrix');
            $this->addTag('feComponentTransfer');
            $this->addTag('feComposite');
            $this->addTag('feConvolveMatrix');
            $this->addTag('feDiffuseLighting');
            $this->addTag('feDisplacementMap');
            $this->addTag('feDistantLight');
            $this->addTag('feDropShadow');
            $this->addTag('feFlood');
            $this->addTag('feFuncA');
            $this->addTag('feFuncB');
            $this->addTag('feFuncG');
            $this->addTag('feFuncR');
            $this->addTag('feGaussianBlur');
            $this->addTag('feImage');
            $this->addTag('feMerge');
            $this->addTag('feMergeNode');
            $this->addTag('feMorphology');
            $this->addTag('feOffset');
            $this->addTag('fePointLight');
            $this->addTag('feSpecularLighting');
            $this->addTag('feSpotLight');
            $this->addTag('feTile');
            $this->addTag('feTurbulence');
            $this->addTag('filter');
        }
        if (ENABLE_SVG_FONTS) {
            $this->addTag('font');
            $this->addTag('font_face');
            $this->addTag('font_face_format');
            $this->addTag('font_face_name');
            $this->addTag('font_face_src');
            $this->addTag('font_face_uri');
        }
        $this->addTag('foreignObject');
        $this->addTag('g');
        if (ENABLE_SVG_FONTS) {
            $this->addTag('glyph');
            $this->addTag('glyphRef');
            $this->addTag('hkern', 'SVG_TYPE_ELEMENT_H_KERN');
        }
        $this->addTag('image');
        $this->addTag('line');
        $this->addTag('linearGradient');
        $this->addTag('marker');
        $this->addTag('mask');
        $this->addTag('metadata');
        if (ENABLE_SVG_FONTS) {
            $this->addTag('missing_glyph');
        }
        $this->addTag('mpath', 'SVG_TYPE_ELEMENT_M_PATH');
        $this->addTag('path');
        $this->addTag('pattern');
        $this->addTag('polygon');
        $this->addTag('polyline');
        $this->addTag('radialGradient');
        $this->addTag('rect');
        $this->addTag('script', null, constructorNeedsCreatedByParser);
        $this->addTag('stop');
        $this->addTag('style', null, constructorNeedsCreatedByParser);
        $this->addTag('svg', 'SVG_TYPE_ELEMENT_SVG');
        $this->addTag('switch');
        $this->addTag('symbol');
        $this->addTag('text');
        $this->addTag('textPath');
        $this->addTag('title');
        $this->addTag('tref', 'SVG_TYPE_ELEMENT_T_REF');
        $this->addTag('tspan', 'SVG_TYPE_ELEMENT_T_SPAN');
        $this->addTag('use', null, constructorNeedsCreatedByParser);
        $this->addTag('view');
        if (ENABLE_SVG_FONTS) {
            $this->addTag('vkern', 'SVG_TYPE_ELEMENT_V_KERN');
        }
    }

    function addAttribute($name) {
        $this->attributeNames['svg:'.$name] = new SvgAttribute($name);
    }

    function initAttributes() {
/*
        namespace="SVG"
        namespaceURI="http://www.w3.org/2000/svg"
        guardFactoryWith="ENABLE(SVG)"
        attrsNullNamespace
*/
        $this->addAttribute('accent-height');// , 'SVG_TYPE_LENGTH', svg_parser_parse_length
        $this->addAttribute('accumulate');
        $this->addAttribute('additive');
        $this->addAttribute('alignment-baseline');
        $this->addAttribute('alphabetic');
        $this->addAttribute('amplitude');
        $this->addAttribute('animate');
        $this->addAttribute('arabic-form');
        $this->addAttribute('ascent');
        $this->addAttribute('attributeName');
        $this->addAttribute('attributeType');
        $this->addAttribute('azimuth');
        $this->addAttribute('baseFrequency');
        $this->addAttribute('baseline-shift');
        $this->addAttribute('baseProfile');
        $this->addAttribute('bbox');
        $this->addAttribute('begin');
        $this->addAttribute('bias');
        $this->addAttribute('by');
        $this->addAttribute('calcMode');
        $this->addAttribute('cap-height');
        $this->addAttribute('clip');
        $this->addAttribute('clip-path');
        $this->addAttribute('clip-rule');
        $this->addAttribute('clipPathUnits');
        $this->addAttribute('color');
        $this->addAttribute('color-interpolation');
        $this->addAttribute('color-interpolation-filters');
        $this->addAttribute('color-profile');
        $this->addAttribute('color-rendering');
        $this->addAttribute('contentScriptType');
        $this->addAttribute('contentStyleType');
        $this->addAttribute('cursor');
        $this->addAttribute('cx');
        $this->addAttribute('cy');
        $this->addAttribute('d');
        $this->addAttribute('descent');
        $this->addAttribute('diffuseConstant');
        $this->addAttribute('direction');
        $this->addAttribute('display');
        $this->addAttribute('divisor');
        $this->addAttribute('dominant-baseline');
        $this->addAttribute('dur');
        $this->addAttribute('dx');
        $this->addAttribute('dy');
        $this->addAttribute('edgeMode');
        $this->addAttribute('elevation');
        $this->addAttribute('enable-background');
        $this->addAttribute('end');
        $this->addAttribute('exponent');
        $this->addAttribute('externalResourcesRequired');
        $this->addAttribute('fill');
        $this->addAttribute('fill-opacity');
        $this->addAttribute('fill-rule');
        $this->addAttribute('filter');
        $this->addAttribute('filterRes');
        $this->addAttribute('filterUnits');
        $this->addAttribute('flood-color');
        $this->addAttribute('flood-opacity');
        $this->addAttribute('font-family');
        $this->addAttribute('font-size');
        $this->addAttribute('font-size-adjust');
        $this->addAttribute('font-stretch');
        $this->addAttribute('font-style');
        $this->addAttribute('font-variant');
        $this->addAttribute('font-weight');
        $this->addAttribute('format');
        $this->addAttribute('from');
        $this->addAttribute('fx');
        $this->addAttribute('fy');
        $this->addAttribute('fr');
        $this->addAttribute('g1');
        $this->addAttribute('g2');
        $this->addAttribute('glyph-name');
        $this->addAttribute('glyph-orientation-horizontal');
        $this->addAttribute('glyph-orientation-vertical');
        $this->addAttribute('glyphRef');
        $this->addAttribute('gradientTransform');
        $this->addAttribute('gradientUnits');
        $this->addAttribute('hanging');
        $this->addAttribute('height');
        $this->addAttribute('horiz-adv-x');
        $this->addAttribute('horiz-origin-x');
        $this->addAttribute('horiz-origin-y');
        $this->addAttribute('ideographic');
        $this->addAttribute('image-rendering');
        $this->addAttribute('in');
        $this->addAttribute('in2');
        $this->addAttribute('intercept');
        $this->addAttribute('k');
        $this->addAttribute('k1');
        $this->addAttribute('k2');
        $this->addAttribute('k3');
        $this->addAttribute('k4');
        $this->addAttribute('kernelMatrix');
        $this->addAttribute('kernelUnitLength');
        $this->addAttribute('kerning');
        $this->addAttribute('keyPoints');
        $this->addAttribute('keySplines');
        $this->addAttribute('keyTimes');
        $this->addAttribute('lang');
        $this->addAttribute('lengthAdjust');
        $this->addAttribute('letter-spacing');
        $this->addAttribute('lighting-color');
        $this->addAttribute('limitingConeAngle');
        $this->addAttribute('local');
        $this->addAttribute('marker-end');
        $this->addAttribute('marker-mid');
        $this->addAttribute('marker-start');
        $this->addAttribute('markerHeight');
        $this->addAttribute('markerUnits');
        $this->addAttribute('markerWidth');
        $this->addAttribute('mask');
        $this->addAttribute('mask-type');
        $this->addAttribute('maskContentUnits');
        $this->addAttribute('maskUnits');
        $this->addAttribute('mathematical');
        $this->addAttribute('max');
        $this->addAttribute('media');
        $this->addAttribute('method');
        $this->addAttribute('min');
        $this->addAttribute('mode');
        $this->addAttribute('name');
        $this->addAttribute('numOctaves');
        $this->addAttribute('offset');
        $this->addAttribute('onactivate');
        $this->addAttribute('onbegin');
        $this->addAttribute('onend');
        $this->addAttribute('onfocusin');
        $this->addAttribute('onfocusout');
        $this->addAttribute('onrepeat');
        $this->addAttribute('onzoom');
        $this->addAttribute('opacity');
        $this->addAttribute('operator');
        $this->addAttribute('order');
        $this->addAttribute('orient');
        $this->addAttribute('orientation');
        $this->addAttribute('origin');
        $this->addAttribute('overflow');
        $this->addAttribute('overline-position');
        $this->addAttribute('overline-thickness');
        $this->addAttribute('panose-1');
        $this->addAttribute('path');
        $this->addAttribute('pathLength');
        $this->addAttribute('patternContentUnits');
        $this->addAttribute('patternTransform');
        $this->addAttribute('patternUnits');
        $this->addAttribute('pointer-events');
        $this->addAttribute('points');
        $this->addAttribute('pointsAtX');
        $this->addAttribute('pointsAtY');
        $this->addAttribute('pointsAtZ');
        $this->addAttribute('preserveAlpha');
        $this->addAttribute('preserveAspectRatio');
        $this->addAttribute('primitiveUnits');
        $this->addAttribute('r');
        $this->addAttribute('radius');
        $this->addAttribute('refX');
        $this->addAttribute('refY');
        $this->addAttribute('rendering-intent');
        $this->addAttribute('repeatCount');
        $this->addAttribute('repeatDur');
        $this->addAttribute('requiredExtensions');
        $this->addAttribute('requiredFeatures');
        $this->addAttribute('restart');
        $this->addAttribute('result');
        $this->addAttribute('rotate');
        $this->addAttribute('rx');
        $this->addAttribute('ry');
        $this->addAttribute('scale');
        $this->addAttribute('seed');
        $this->addAttribute('shape-rendering');
        $this->addAttribute('slope');
        $this->addAttribute('spacing');
        $this->addAttribute('specularConstant');
        $this->addAttribute('specularExponent');
        $this->addAttribute('spreadMethod');
        $this->addAttribute('startOffset');
        $this->addAttribute('stdDeviation');
        $this->addAttribute('stemh');
        $this->addAttribute('stemv');
        $this->addAttribute('stitchTiles');
        $this->addAttribute('stop-color');
        $this->addAttribute('stop-opacity');
        $this->addAttribute('strikethrough-position');
        $this->addAttribute('strikethrough-thickness');
        $this->addAttribute('stroke');
        $this->addAttribute('stroke-dasharray');
        $this->addAttribute('stroke-dashoffset');
        $this->addAttribute('stroke-linecap');
        $this->addAttribute('stroke-linejoin');
        $this->addAttribute('stroke-miterlimit');
        $this->addAttribute('stroke-opacity');
        $this->addAttribute('stroke-width');
        $this->addAttribute('style');
        $this->addAttribute('surfaceScale');
        $this->addAttribute('systemLanguage');
        $this->addAttribute('tableValues');
        $this->addAttribute('target');
        $this->addAttribute('targetX');
        $this->addAttribute('targetY');
        $this->addAttribute('text-anchor');
        $this->addAttribute('text-decoration');
        $this->addAttribute('text-rendering');
        $this->addAttribute('textLength');
        $this->addAttribute('title');
        $this->addAttribute('to');
        $this->addAttribute('transform');
        $this->addAttribute('transform-origin');
        $this->addAttribute('type');
        $this->addAttribute('u1');
        $this->addAttribute('u2');
        $this->addAttribute('underline-position');
        $this->addAttribute('underline-thickness');
        $this->addAttribute('unicode');
        $this->addAttribute('unicode-bidi');
        $this->addAttribute('unicode-range');
        $this->addAttribute('units-per-em');
        $this->addAttribute('v-alphabetic');
        $this->addAttribute('v-hanging');
        $this->addAttribute('v-ideographic');
        $this->addAttribute('v-mathematical');
        $this->addAttribute('values');
        $this->addAttribute('vector-effect');
        $this->addAttribute('version');
        $this->addAttribute('vert-adv-y');
        $this->addAttribute('vert-origin-x');
        $this->addAttribute('vert-origin-y');
        $this->addAttribute('viewBox');
        $this->addAttribute('viewTarget');
        $this->addAttribute('visibility');
        $this->addAttribute('width');
        $this->addAttribute('widths');
        $this->addAttribute('word-spacing');
        $this->addAttribute('writing-mode');
        $this->addAttribute('x');
        $this->addAttribute('x-height');
        $this->addAttribute('x1');
        $this->addAttribute('x2');
        $this->addAttribute('xChannelSelector');
        $this->addAttribute('y');
        $this->addAttribute('y1');
        $this->addAttribute('y2');
        $this->addAttribute('yChannelSelector');
        $this->addAttribute('z');
        $this->addAttribute('zoomAndPan');
    }

    function initGroupAttribute() {
        $this->attributeGroups["descriptive_elements"] = array(
//            $this->attributeNames['desc'],
//            $this->attributeNames['metadata'],
            $this->attributeNames['svg:title']
        );
        $this->attributeGroups["conditional_processing"] = array(
            $this->attributeNames['svg:requiredFeatures'],
            $this->attributeNames['svg:requiredExtensions'],
            $this->attributeNames['svg:systemLanguage']
        );

/*
        $this->attributeGroups["core"] = array(
            $this->attributeNames['id'],
            $this->attributeNames['xml:base'],
            $this->attributeNames['xml:lang'],
            $this->attributeNames['xml:space']
        );

        $this->attributeGroups["animation_event"] = array(
            $this->attributeNames['svg:onbegin'],
            $this->attributeNames['svg:onend'],
            $this->attributeNames['svg:onrepeat'],
            $this->attributeNames['svg:onload']
        );

        $this->attributeGroups["graphical_event"] = array(
            $this->attributeNames['svg:onbegin'],
            $this->attributeNames['svg:onfocusin'],
            $this->attributeNames['svg:onfocusout'],
            $this->attributeNames['svg:onactivate'],
            $this->attributeNames['svg:onclick'],
            $this->attributeNames['svg:onmousedown'],
            $this->attributeNames['svg:onmouseup'],
            $this->attributeNames['svg:onmouseover'],
            $this->attributeNames['svg:onmousemove'],
            $this->attributeNames['svg:onmouseout'],
            $this->attributeNames['svg:onload'],
        );

*/
        $this->attributeGroups["animation_attribute_target"] = array(
            $this->attributeNames['svg:attributeType'],
            $this->attributeNames['svg:attributeName'],
        );
        $this->attributeGroups["animation_timing"] = array(
            $this->attributeNames['svg:attributeType'],
            $this->attributeNames['svg:begin'],
            $this->attributeNames['svg:dur'],
            $this->attributeNames['svg:end'],
            $this->attributeNames['svg:min'],
            $this->attributeNames['svg:max'],
            $this->attributeNames['svg:restart'],
            $this->attributeNames['svg:repeatCount'],
            $this->attributeNames['svg:repeatDur'],
            $this->attributeNames['svg:fill'],
        );
        $this->attributeGroups["animation_value"] = array(
            $this->attributeNames['svg:attributeType'],
            $this->attributeNames['svg:calcMode'],
            $this->attributeNames['svg:values'],
            $this->attributeNames['svg:keyTimes'],
            $this->attributeNames['svg:keySplines'],
            $this->attributeNames['svg:from'],
            $this->attributeNames['svg:to'],
            $this->attributeNames['svg:by'],
        );
        $this->attributeGroups["animation_addition"] = array(
            $this->attributeNames['svg:additive'],
            $this->attributeNames['svg:accumulate'],
        );

        $this->attributeGroups["presentation"] = array(
            $this->attributeNames['svg:alignment-baseline'],
            $this->attributeNames['svg:baseline-shift'],
            $this->attributeNames['svg:clip'],
            $this->attributeNames['svg:clip-path'],
            $this->attributeNames['svg:clip-rule'],
            $this->attributeNames['svg:color'],
            $this->attributeNames['svg:color-interpolation'],
            $this->attributeNames['svg:color-interpolation-filters'],
            $this->attributeNames['svg:color-profile'],
            $this->attributeNames['svg:color-rendering'],
            $this->attributeNames['svg:cursor'],
            $this->attributeNames['svg:direction'],
            $this->attributeNames['svg:display'],
            $this->attributeNames['svg:dominant-baseline'],
            $this->attributeNames['svg:enable-background'],
            $this->attributeNames['svg:fill'],
            $this->attributeNames['svg:fill-opacity'],
            $this->attributeNames['svg:fill-rule'],
            $this->attributeNames['svg:filter'],
            $this->attributeNames['svg:flood-color'],
            $this->attributeNames['svg:flood-opacity'],
            $this->attributeNames['svg:font-family'],
            $this->attributeNames['svg:font-size'],
            $this->attributeNames['svg:font-size-adjust'],
            $this->attributeNames['svg:font-stretch'],
            $this->attributeNames['svg:font-style'],
            $this->attributeNames['svg:font-variant'],
            $this->attributeNames['svg:font-weight'],
            $this->attributeNames['svg:glyph-orientation-horizontal'],
            $this->attributeNames['svg:glyph-orientation-vertical'],
            $this->attributeNames['svg:image-rendering'],
            $this->attributeNames['svg:kerning'],
            $this->attributeNames['svg:letter-spacing'],
            $this->attributeNames['svg:lighting-color'],
            $this->attributeNames['svg:marker-end'],
            $this->attributeNames['svg:marker-mid'],
            $this->attributeNames['svg:marker-start'],
            $this->attributeNames['svg:mask'],
            $this->attributeNames['svg:opacity'],
            $this->attributeNames['svg:overflow'],
            $this->attributeNames['svg:pointer-events'],
            $this->attributeNames['svg:shape-rendering'],
            $this->attributeNames['svg:stop-color'],
            $this->attributeNames['svg:stop-opacity'],
            $this->attributeNames['svg:stroke'],
            $this->attributeNames['svg:stroke-dasharray'],
            $this->attributeNames['svg:stroke-dashoffset'],
            $this->attributeNames['svg:stroke-linecap'],
            $this->attributeNames['svg:stroke-linejoin'],
            $this->attributeNames['svg:stroke-miterlimit'],
            $this->attributeNames['svg:stroke-opacity'],
            $this->attributeNames['svg:stroke-width'],
            $this->attributeNames['svg:text-anchor'],
            $this->attributeNames['svg:text-decoration'],
            $this->attributeNames['svg:text-rendering'],
            $this->attributeNames['svg:unicode-bidi'],
            $this->attributeNames['svg:visibility'],
            $this->attributeNames['svg:word-spacing'],
            $this->attributeNames['svg:writing-mode'],
        );

        $this->attributeGroups["resources"] = array(
            $this->attributeNames['svg:externalResourcesRequired'],
        );
    }
}

class Hasher
{
    function __construct($elements, $composition) {
    }
}


set_include_path('/home/gaulouis/local/src/ganash/tools/generator/');

require_once("GLib/Code/Naming.php");
require_once("GLib/Code/GeneratorInterface.php");
require_once("GLib/Code/AbstractGenerator.php");
require("GLib/Code/Generator/File.php");
require_once("GLib/Code/Generator/GObject.php");
//require("GLib/Code/Generator/Property.php");
require_once("GLib/Code/Generator/Type.php");
require_once("GLib/Code/Generator/Member.php");

echo "SVGTags:\n";

$svg = new Svg();

//foreach $svg->Tags() as $tag;
reset($svg->tagNames);
$tag = current($svg->tagNames);
//echo $tag->qualifiedName->toType(), "\n";
//echo $tag->code, "\n";
//echo $tag->typeName, "\n";
//echo $tag->attributes, "\n";


$gobject = new GLib\Code\Generator\GObject($tag->qualifiedName->name, 'svg');
$gobject->setExtendedClass(new GLib\Code\Naming('elementGraphics', 'svg'));
$member = new GLib\Code\Generator\Member(array('name'=>new GLib\Code\Naming('foo'), 'type'=>GLib\Code\Generator\Type::fromTypeString('gint')));
// $member->setDefault('0');
// $member->setType(GLib\Code\Generator\Type::fromTypeString('gint'));
// $member->setVisibility($member, GLib\Code\Member::VISIBILITY_PUBLIC);
$gobject->addMember($member);
//$property = new GLib\Code\Generator\Property(new GLib\Code\Naming('x', 'svg'));
// $property->setType(new GLib\Code\Generator\Type('length', 'svg'));
// $property->setNick();
// $property->setName();
// $property->setBlur();
//$gobject->addProperty($propertry);

$file = new GLib\Code\Generator\File();
$file->setClass($gobject);
$file->setFilename($gobject->toFile());

//$file->generate('header');
$file->generate('source');

// svg-names.h

foreach ($svg->tagNames as $tag) {
    //static Entity entity_a = {"a", G_TYPE_INT, 2};
    $name = strtolower(substr($tag->qualifiedName->name, strlen("element")));
    //echo "static Entity entity_", $name, " = {\"", $name, "\", ", $tag->qualifiedName->toMacroType(), ", ", $tag->code, "};\n";
    //echo "g_hash_table_insert ( hash, \"", $name, "\", &entity_", $name,");\n";
    //echo "#include \"", $tag->qualifiedName->toFileSystem(),".h\"\n";
    echo "g_hash_table_insert(svg_tag_table, \"", $name, "\", svg_tag_new(\"", $name, "\", ", $tag->qualifiedName->toMacroType(), ", ", $tag->code, "));\n";

}
//echo PHP_INT_MAX;
//echo $tag->code, "\n";
//echo $tag->typeName, "\n";
//echo $tag->attributes, "\n";

echo "First step: make TreeBinaryBool Alpha";
echo "Make struct GType";
echo "my_hash_table_key_hash";



