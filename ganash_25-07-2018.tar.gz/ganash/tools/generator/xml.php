<?php

require("dom.php");

class XmlAttribute extends DomAttribute
{
}

class Xml
{
    var $attributeGroups = array();
    var $attributeNames = array();

    function __construct() {
        $this->initAttributes();
    }

    function addAttribute($name) {
        $this->attributeNames['xml:'.$name] = new XmlAttribute($name);
    }

    function initAttributes() {
        $this->addAttribute('id');
        $this->addAttribute('base');
        $this->addAttribute('lang');
        $this->addAttribute('space');
    }

    function initAttributeGroups() {
        $this->attributeGroups["xml"] = array(
            $this->attributeNames['xml:id'],
            $this->attributeNames['xml:base'],
            $this->attributeNames['xml:lang'],
            $this->attributeNames['xml:space'],
        );

    }

}
