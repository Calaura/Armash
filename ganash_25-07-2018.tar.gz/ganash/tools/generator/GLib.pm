
package GLib::Code::Generator::Abstract;

sub new {
    my ($class, @args) = (@_);

    my $self = {
        source => '',
        header => '',
        header_type => '',
    };

    bless $self, $class;
    return $self;
}

sub generateSource {
    return '';
}
sub generateHeader {
    return '';
}
sub generateHeaderType {
    return '';
}
sub generate {
    my ($self, @args)  = (@_);

    $self->{source} = $self->generateSource();
    $self->{header} = $self->generateHeader();
    $self->{header_type} = $self->generateHeaderType();

    my $output = '';
    $output .= $self->{source};
    $output .= "\n";
    $output .= $self->{header};
    $output .= "\n";
    $output .= $self->{header_type};
    $output .= "\n";

    return $output;
}
