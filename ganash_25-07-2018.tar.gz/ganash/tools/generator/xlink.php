
require("dom.php");

class Xlink
{
    var $attributeGroups = array();
    var $attributeNames = array();

    function __construct() {
        $this->initAttributes();
    }

    function addAttribute($name) {
        $this->attributeNames['xlink:'.$name] = new DomAttribute($name);
    }

    function initAttributes() {
        /*
            namespace="SVG"
            namespaceURI="http://www.w3.org/2000/svg"
            guardFactoryWith="ENABLE(SVG)"
            attrsNullNamespace
        */
        $this->addAttribute('href');
        $this->addAttribute('show');
        $this->addAttribute('actuate');
        $this->addAttribute('type');
        $this->addAttribute('role');
        $this->addAttribute('arcrole');
        $this->addAttribute('title');
    }

    function initAttributeGroups() {
        $this->attributeGroups["xlink"] = array(
            $this->attributeNames['xlink:href'],
            $this->attributeNames['xlink:show'],
            $this->attributeNames['xlink:actuate'],
            $this->attributeNames['xlink:type'],
            $this->attributeNames['xlink:role'],
            $this->attributeNames['xlink:arcrole'],
            $this->attributeNames['xlink:title'],
        );
    }

}
