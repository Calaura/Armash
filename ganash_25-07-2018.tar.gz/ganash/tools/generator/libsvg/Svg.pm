
package Svg;

my $enumSpreadMethods = SvgSpreadMethods->new();

my $element_rect = SvgElementRect->new();
   $element_rect->addDependency($enumSpreadMethods);

my $file_rect = GLib::Code::Generator::File->new('./libsvg/svg-element-rect.h');
   $file_rect->add($element_rect);
   $file_rect->add($enumSpreadMethods);


my $element_g    = SvgElementG->new();
my $file_g = GLib::Code::Generator::File->new('./libsvg/svg-element-g.h');
   $file_g->add($element_g);



my $file_dom = GLib::Code::Generator::Library->new('svg-dom.h');
   $file_dom->addHeader($file_rect);
   $file_dom->addHeader($file_g);

my $lib_svg = GLib::Code::Generator::Library->new('libsvg', '0.0.1');
   $lib_svg->addDependency('glib', '2.0');
   $lib_svg->addObject($element_rect);

   $lib_svg->generate();

1;
