
package SvgElementG;
our @ISA = qw(GLib::Code::Generator::Class);

sub new {
    my ($class, $qualified_name) = (@_);

    my  $self = $class->SUPER::new();

    bless($self, $class);

    my  $svg_element_rect = GLib::Code::Generator::Class->new('Svg:Element:Rect');
        $svg_element_rect->addExtend('Svg:Element:Graphics');
        #$svg_element_rect->addInterfaces(['Svg:Stylable', 'Svg:Drawable', 'Svg:Locatable']);
        #$svg_element_rect->addInterface('Svg:Stylable');
        #$svg_element_rect->addProperty($property);

    return($self);
}

sub generate {
    my $output = $svg_element_rect->generate();

    return $output;
}

1;
