
package SvgElementRect;
our @ISA = qw(GLib::Code::Generator::File);

sub new {
    my ($class, $qualified_name) = (@_);

    my  $self = $class->SUPER::new();

    bless($self, $class);

    my $property = GLib::Code::Generator::Property->new('height', 'The height of element rect');

    my  $svg_element_rect = GLib::Code::Generator::Class->new('Svg:Element:Rect');
        $svg_element_rect->addExtend('Svg:Element:Graphics');
        #$svg_element_rect->addInterfaces(['Svg:Stylable', 'Svg:Drawable', 'Svg:Locatable']);
        #$svg_element_rect->addInterface('Svg:Stylable');
        #$svg_element_rect->addProperty($property);

    return($self);
}

sub init(SvgElementRect *element) {
    my $output = '';
    $output .= 'object->foo = 0;';

    return $output;
}

sub generate {
    my $output = $svg_element_rect->generate();

    return $output;
}

1;
