/*
 * motion-easing-cubic.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "motion-types.h"
#include "motion-easing.h"
#include "motion-easing-cubic.h"


#define MOTION_EASING_CUBIC_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), MOTION_TYPE_EASING_CUBIC, MotionEasingCubicPrivate))
struct _MotionEasingCubicPrivate {
	int foo;
};

static double motion_easing_cubic_interpolate(MotionEasing *easing, double progress);
static void motion_easing_cubic_class_init(MotionEasingCubicClass *klass);
static void motion_easing_cubic_init(MotionEasingCubic *gobject);

G_DEFINE_TYPE (MotionEasingCubic, motion_easing_cubic, MOTION_TYPE_EASING)

static void
motion_easing_cubic_class_init(MotionEasingCubicClass *klass)
{
	MotionEasingClass *motioneasing_class;

	motioneasing_class = (MotionEasingClass *) klass;
    motioneasing_class->interpolate = motion_easing_cubic_interpolate;

    g_type_class_add_private(klass, sizeof(MotionEasingCubicPrivate));
//	motion_easing_cubic_parent_class = g_type_class_peek_parent (klass);
}

static void
motion_easing_cubic_init (MotionEasingCubic *object)
{
	MotionEasingCubicPrivate *priv = MOTION_EASING_CUBIC_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

void motion_easing_cubic_set_values(MotionEasing *easing, double from, double to,
                                    double p1_x, double p1_y, double p2_x, double p2_y)
{
    MotionEasingCubic *easing_cubic = (MotionEasingCubic *) easing;
    easing->from = from;
    easing->to   = to;
    easing_cubic->p1_x = p1_x;
    easing_cubic->p1_y = p1_y;
    easing_cubic->p2_x = p2_x;
    easing_cubic->p2_y = p2_y;
}

void motion_easing_cubic_set_times(MotionEasing *easing, double begin, double end)
{
    MotionEasingCubic *easing_cubic = (MotionEasingCubic *) easing;
    easing->begin = begin;
    easing->end   = end;
}

static double motion_easing_cubic_interpolate(MotionEasing *easing, double progress)
{
    MotionEasingCubic *easing_cubic = (MotionEasingCubic *) easing;
    /*return easing_cubic->private_member->foo;*/

    double t   = progress;


    double tt  = t*t;
    double ttt = tt*t;
    double t_1 = (1-progress);
    double t_2 = t_1*t_1;
    double t_3 = t_2*t_1;
    double value =   0 * t_3
                 + 3*easing_cubic->p1_x *  t * t_2
                 + 3*easing_cubic->p2_x * tt * t_1
                 +   1 * ttt;

    return value * (easing->to-easing->from) + easing->from;
}

MotionEasingCubic *
motion_easing_cubic_new (void)
{
	return g_object_new (motion_easing_cubic_get_type (),
	                     NULL);
}

