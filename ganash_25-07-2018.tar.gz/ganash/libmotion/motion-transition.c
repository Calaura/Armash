/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * motion-transition.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "motion-transition.h"


static void motion_transition_class_init(MotionTransitionClass *klass);
static void motion_transition_init(MotionTransition *gobject);

G_DEFINE_TYPE (MotionTransition, motion_transition, G_TYPE_OBJECT)

static void
motion_transition_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (motion_transition_parent_class)->finalize (object);
}
static void
motion_transition_class_init(MotionTransitionClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = motion_transition_finalize;

//	motion_transition_parent_class = g_type_class_peek_parent (klass);
}

static void
motion_transition_init (MotionTransition *object)
{
}

MotionTransition *
motion_transition_new (void)
{
	return g_object_new (motion_transition_get_type (),
	                     NULL);
}

