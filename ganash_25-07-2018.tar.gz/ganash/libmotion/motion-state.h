/*
 * motion-state.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __MOTION_STATE_H__
#define __MOTION_STATE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define MOTION_TYPE_STATE            (motion_state_get_type())
#define MOTION_STATE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MOTION_TYPE_STATE, MotionState))
#define MOTION_STATE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), MOTION_TYPE_STATE, MotionStateClass))
#define MOTION_IS_STATE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MOTION_TYPE_STATE))
#define MOTION_IS_STATE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), MOTION_TYPE_STATE))
#define MOTION_STATE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), MOTION_TYPE_STATE, MotionStateClass))

typedef struct _MotionState MotionState;
typedef struct _MotionStateClass MotionStateClass;

enum {
    MOTION_FILL_FREEZ,
    MOTION_FILL_FILL
};

struct _MotionState {
	GObject parent_instance;
    int fill;
    MotionAnimation/*<MotionEasing>*/ *e;
};

struct _MotionStateClass {
	GObjectClass parent_class;
};

GType motion_state_get_type();
MotionState *motion_state_new();

G_END_DECLS

#endif /* __MOTION_STATE_H__ */

