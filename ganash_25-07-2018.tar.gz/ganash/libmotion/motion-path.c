/*
 * motion-path.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "motion-path.h"


#define MOTION_PATH_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), MOTION_TYPE_PATH, MotionPathPrivate))
struct _MotionPathPrivate {
	int foo;
    cairo_path_t *path;
};


static void motion_path_class_init(MotionPathClass *klass);
static void motion_path_init(MotionPath *gobject);

G_DEFINE_TYPE (MotionPath, motion_path, G_TYPE_OBJECT)

static void
motion_path_class_init(MotionPathClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    g_type_class_add_private(klass, sizeof(MotionPathPrivate));
//	motion_path_parent_class = g_type_class_peek_parent (klass);
}

static void
motion_path_init (MotionPath *object)
{
	MotionPathPrivate *priv = MOTION_PATH_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

MotionPath *
motion_path_new (void)
{
	return g_object_new (motion_path_get_type (),
	                     NULL);
}

