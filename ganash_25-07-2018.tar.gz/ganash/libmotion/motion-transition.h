/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * motion-transition.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __MOTION_TRANSITION_H__
#define __MOTION_TRANSITION_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define MOTION_TYPE_TRANSITION            (motion_transition_get_type())
#define MOTION_TRANSITION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MOTION_TYPE_TRANSITION, MotionTransition))
#define MOTION_TRANSITION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), MOTION_TYPE_TRANSITION, MotionTransitionClass))
#define MOTION_IS_TRANSITION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MOTION_TYPE_TRANSITION))
#define MOTION_IS_TRANSITION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), MOTION_TYPE_TRANSITION))
#define MOTION_TRANSITION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), MOTION_TYPE_TRANSITION, MotionTransitionClass))

typedef struct _MotionTransition MotionTransition;
typedef struct _MotionTransitionClass MotionTransitionClass;

struct _MotionTransition {
	GObject parent_instance;
};

struct _MotionTransitionClass {
	GObjectClass parent_class;
};

GType motion_transition_get_type();
MotionTransition *motion_transition_new();

G_END_DECLS

#endif /* __MOTION_TRANSITION_H__ */

