/*
 * motion-animation-parallel.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __MOTION_ANIMATION_PARALLEL_H__
#define __MOTION_ANIMATION_PARALLEL_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define MOTION_TYPE_ANIMATION_PARALLEL            (motion_animation_parallel_get_type())
#define MOTION_ANIMATION_PARALLEL(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MOTION_TYPE_ANIMATION_PARALLEL, MotionAnimationParallel))
#define MOTION_ANIMATION_PARALLEL_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), MOTION_TYPE_ANIMATION_PARALLEL, MotionAnimationParallelClass))
#define MOTION_IS_ANIMATION_PARALLEL(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MOTION_TYPE_ANIMATION_PARALLEL))
#define MOTION_IS_ANIMATION_PARALLEL_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), MOTION_TYPE_ANIMATION_PARALLEL))
#define MOTION_ANIMATION_PARALLEL_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), MOTION_TYPE_ANIMATION_PARALLEL, MotionAnimationParallelClass))

typedef struct _MotionAnimationParallel MotionAnimationParallel;
typedef struct _MotionAnimationParallelPrivate MotionAnimationParallelPrivate;
typedef struct _MotionAnimationParallelClass MotionAnimationParallelClass;

struct _MotionAnimationParallel {
	MotionAnimation parent_instance;
	/* private */
	MotionAnimationParallelPrivate *private_member;
};

struct _MotionAnimationParallelClass {
	MotionAnimationClass parent_class;
};

GType motion_animation_parallel_get_type();
MotionAnimationParallel *motion_animation_parallel_new();

G_END_DECLS

#endif /* __MOTION_ANIMATION_PARALLEL_H__ */

