/*
 * motion-animatable.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __MOTION_ANIMATABLE_H__
#define __MOTION_ANIMATABLE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define MOTION_TYPE_ANIMATABLE                (motion_animatable_get_type ())
#define MOTION_ANIMATABLE(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  MOTION_TYPE_ANIMATABLE,  MotionAnimatable))
#define MOTION_IS_ANIMATABLE(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  MOTION_TYPE_ANIMATABLE))
#define MOTION_ANIMATABLE_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  MOTION_TYPE_ANIMATABLE,  MotionAnimatableInterface))
typedef struct _MotionAnimatable  MotionAnimatable; /* dummy object */
typedef struct _MotionAnimatableInterface  MotionAnimatableInterface;

struct _MotionAnimatableInterface
{
	GTypeInterface parent;
    void (*init) ( MotionAnimatable *self, double time);
    void (*play) ( MotionAnimatable *self);
    void (*pause) ( MotionAnimatable *self);
    void (*stop) ( MotionAnimatable *self);
};

GType  motion_animatable_get_type (void);

void motion_animatable_interface_init  (MotionAnimatable *self, double time);
void motion_animatable_interface_play  (MotionAnimatable *self);
void motion_animatable_interface_pause (MotionAnimatable *self);
void motion_animatable_interface_stop  (MotionAnimatable *self);

G_END_DECLS

#endif /* __MOTION_ANIMATABLE_H__ */
