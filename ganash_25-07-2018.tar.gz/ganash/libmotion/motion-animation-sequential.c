/*
 * motion-animation-sequential.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "motion-types.h"
#include "motion-easing.h"
#include "motion-animation.h"
#include "motion-animation-sequential.h"


#define MOTION_ANIMATION_SEQUENTIAL_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), MOTION_TYPE_ANIMATION_SEQUENTIAL, MotionAnimationSequentialPrivate))
struct _MotionAnimationSequentialPrivate {
	int foo;
};


static void motion_animation_sequential_class_init(MotionAnimationSequentialClass *klass);
static void motion_animation_sequential_init(MotionAnimationSequential *gobject);

G_DEFINE_TYPE (MotionAnimationSequential, motion_animation_sequential, MOTION_TYPE_ANIMATION)

static void
motion_animation_sequential_class_init(MotionAnimationSequentialClass *klass)
{
	MotionAnimationClass *motionanimation_class;

	motionanimation_class = (MotionAnimationClass *) klass;

g_type_class_add_private(klass, sizeof(MotionAnimationSequentialPrivate));
//	motion_animation_sequential_parent_class = g_type_class_peek_parent (klass);
}

static void
motion_animation_sequential_init (MotionAnimationSequential *object)
{
	MotionAnimationSequentialPrivate *priv = MOTION_ANIMATION_SEQUENTIAL_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

MotionAnimationSequential *
motion_animation_sequential_new (void)
{
	return g_object_new (motion_animation_sequential_get_type (),
	                     NULL);
}

