/*
 * motion-easing-cubic.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __MOTION_EASING_CUBIC_H__
#define __MOTION_EASING_CUBIC_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS


#define MOTION_TYPE_EASING_CUBIC            (motion_easing_cubic_get_type())
#define MOTION_EASING_CUBIC(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MOTION_TYPE_EASING_CUBIC, MotionEasingCubic))
#define MOTION_EASING_CUBIC_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), MOTION_TYPE_EASING_CUBIC, MotionEasingCubicClass))
#define MOTION_IS_EASING_CUBIC(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MOTION_TYPE_EASING_CUBIC))
#define MOTION_IS_EASING_CUBIC_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), MOTION_TYPE_EASING_CUBIC))
#define MOTION_EASING_CUBIC_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), MOTION_TYPE_EASING_CUBIC, MotionEasingCubicClass))

typedef struct _MotionEasingCubicPrivate MotionEasingCubicPrivate;
typedef struct _MotionEasingCubicClass MotionEasingCubicClass;

struct _MotionEasingCubic {
	MotionEasing parent_instance;
	/* private */
    double p1_x, p1_y;
    double p2_x, p2_y;
    MotionEasingCubicPrivate *private_member;
};

struct _MotionEasingCubicClass {
	MotionEasingClass parent_class;
};

GType motion_easing_cubic_get_type();
MotionEasingCubic *motion_easing_cubic_new();
void motion_easing_cubic_set_values(MotionEasing *easing, double from, double to, double p1_x, double p1_y, double p2_x, double p2_y);
void motion_easing_cubic_set_times(MotionEasing *easing, double begin, double end);

G_END_DECLS

#endif /* __MOTION_EASING_CUBIC_H__ */

