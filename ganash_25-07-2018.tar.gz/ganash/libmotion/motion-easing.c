/*
 * motion-easing.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "motion-types.h"
#include "motion-easing.h"
#include "motion-animation.h"


#define MOTION_EASING_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), MOTION_TYPE_EASING, MotionEasingPrivate))
struct _MotionEasingPrivate {
    int foo;
};


static double motion_easing_default_interpolate(MotionEasing *easing, double progress);
static void   motion_easing_class_init(MotionEasingClass *klass);
static void   motion_easing_init(MotionEasing *gobject);

G_DEFINE_TYPE (MotionEasing, motion_easing, G_TYPE_OBJECT)

static void
motion_easing_class_init(MotionEasingClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    klass->interpolate   = motion_easing_default_interpolate;

    g_type_class_add_private(klass, sizeof(MotionEasingPrivate));
//	motion_easing_parent_class = g_type_class_peek_parent (klass);
}

static void
motion_easing_init (MotionEasing *object)
{
	MotionEasingPrivate *priv = MOTION_EASING_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

MotionEasing *
motion_easing_new (void)
{
    return g_object_new (motion_easing_get_type (),
                         NULL);
}

void motion_easing_set_values(MotionEasing *easing, double from)
{
    easing->from = from;
}

void motion_easing_set_times(MotionEasing *easing, double begin)
{
    easing->begin = begin;
}

static double motion_easing_default_interpolate(MotionEasing *easing, double progress)
{
    return easing->private_member->foo;
}

double
motion_easing_interpolate (MotionEasing *easing, double progress)
{
    return MOTION_EASING_GET_CLASS(easing)->interpolate(easing, progress);
}
