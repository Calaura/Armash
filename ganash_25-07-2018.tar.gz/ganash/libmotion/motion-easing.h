/*
 * motion-easing.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __MOTION_EASING_H__
#define __MOTION_EASING_H__

#include <glib-object.h>


G_BEGIN_DECLS

/*typedef double (*EasingFunction) (MotionEasing *easing, double progress);*/


#define MOTION_TYPE_EASING            (motion_easing_get_type())
#define MOTION_EASING(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MOTION_TYPE_EASING, MotionEasing))
#define MOTION_EASING_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), MOTION_TYPE_EASING, MotionEasingClass))
#define MOTION_IS_EASING(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MOTION_TYPE_EASING))
#define MOTION_IS_EASING_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), MOTION_TYPE_EASING))
#define MOTION_EASING_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), MOTION_TYPE_EASING, MotionEasingClass))

typedef struct _MotionEasingPrivate       MotionEasingPrivate;
typedef struct _MotionEasingClass         MotionEasingClass;

struct _MotionEasing {
    GObject parent_instance;

    double from;
    double to;

    double begin;
    double end;

    /* private */
    MotionEasingPrivate *private_member;
};
struct _MotionEasingClass {
    GObjectClass parent_class;

    double (*interpolate) (MotionEasing *easing, double progress);
};

GType motion_easing_get_type();
MotionEasing *motion_easing_new(void);
void motion_easing_set_values(MotionEasing *easing, double from);
void motion_easing_set_times(MotionEasing *easing, double begin);

/*motion_animation_play(time);*/
/*motion_animation_interpolate(double from, double to, double progress);*/
/*motion_animation_set_easing(MotionEasing *easing);*/

/*motion_easing_get_value(MotionEasing *easing);*/
double motion_easing_interpolate(MotionEasing *easing, double progress);

G_END_DECLS

#endif /* __MOTION_EASING_H__ */

