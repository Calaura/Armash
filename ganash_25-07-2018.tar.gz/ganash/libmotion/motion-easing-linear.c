/*
 * motion-easing-linear.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "motion-types.h"
#include "motion-easing.h"
#include "motion-easing-linear.h"


#define MOTION_EASING_LINEAR_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), MOTION_TYPE_EASING_LINEAR, MotionEasingLinearPrivate))
struct _MotionEasingLinearPrivate {
	int foo;
};

static double motion_easing_linear_interpolate(MotionEasing *easing, double progress);
static void motion_easing_linear_class_init(MotionEasingLinearClass *klass);
static void motion_easing_linear_init(MotionEasingLinear *gobject);

G_DEFINE_TYPE (MotionEasingLinear, motion_easing_linear, MOTION_TYPE_EASING)

static void
motion_easing_linear_class_init(MotionEasingLinearClass *klass)
{
	MotionEasingClass *motioneasing_class;

    motioneasing_class = (MotionEasingClass *) klass;

    motioneasing_class->interpolate = motion_easing_linear_interpolate;

    g_type_class_add_private(klass, sizeof(MotionEasingLinearPrivate));
//	motion_easing_linear_parent_class = g_type_class_peek_parent (klass);
}

static void
motion_easing_linear_init (MotionEasingLinear *object)
{
	MotionEasingLinearPrivate *priv = MOTION_EASING_LINEAR_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

static double motion_easing_linear_interpolate(MotionEasing *easing, double progress)
{
    return progress;
}

MotionEasing *
motion_easing_linear_new (void)
{
	return g_object_new (motion_easing_linear_get_type (),
	                     NULL);
}

void motion_easing_linear_set_values(MotionEasing *easing, double from, double to)
{
    easing->from = from;
    easing->to   = to;
}

void motion_easing_linear_set_times(MotionEasing *easing, double begin, double end)
{
    easing->begin = begin;
    easing->end   = end;
}
