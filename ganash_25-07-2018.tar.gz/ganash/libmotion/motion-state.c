/*
 * motion-state.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "motion-state.h"


static void motion_state_class_init(MotionStateClass *klass);
static void motion_state_init(MotionState *gobject);

G_DEFINE_TYPE (MotionState, motion_state, G_TYPE_OBJECT)

static void
motion_state_class_init(MotionStateClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	motion_state_parent_class = g_type_class_peek_parent (klass);
}

static void
motion_state_init (MotionState *object)
{
}

MotionState *
motion_state_new (void)
{
	return g_object_new (motion_state_get_type (),
	                     NULL);
}

