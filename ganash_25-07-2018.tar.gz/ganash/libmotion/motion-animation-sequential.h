/*
 * motion-animation-sequential.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __MOTION_ANIMATION_SEQUENTIAL_H__
#define __MOTION_ANIMATION_SEQUENTIAL_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define MOTION_TYPE_ANIMATION_SEQUENTIAL            (motion_animation_sequential_get_type())
#define MOTION_ANIMATION_SEQUENTIAL(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MOTION_TYPE_ANIMATION_SEQUENTIAL, MotionAnimationSequential))
#define MOTION_ANIMATION_SEQUENTIAL_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), MOTION_TYPE_ANIMATION_SEQUENTIAL, MotionAnimationSequentialClass))
#define MOTION_IS_ANIMATION_SEQUENTIAL(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MOTION_TYPE_ANIMATION_SEQUENTIAL))
#define MOTION_IS_ANIMATION_SEQUENTIAL_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), MOTION_TYPE_ANIMATION_SEQUENTIAL))
#define MOTION_ANIMATION_SEQUENTIAL_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), MOTION_TYPE_ANIMATION_SEQUENTIAL, MotionAnimationSequentialClass))

typedef struct _MotionAnimationSequential MotionAnimationSequential;
typedef struct _MotionAnimationSequentialPrivate MotionAnimationSequentialPrivate;
typedef struct _MotionAnimationSequentialClass MotionAnimationSequentialClass;

struct _MotionAnimationSequential {
	MotionAnimation parent_instance;
	/* private */
	MotionAnimationSequentialPrivate *private_member;
};

struct _MotionAnimationSequentialClass {
	MotionAnimationClass parent_class;
};

GType motion_animation_sequential_get_type();
MotionAnimationSequential *motion_animation_sequential_new();

G_END_DECLS

#endif /* __MOTION_ANIMATION_SEQUENTIAL_H__ */

