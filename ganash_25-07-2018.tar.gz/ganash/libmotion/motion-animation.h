/*
 * motion-animation.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __MOTION_ANIMATION_H__
#define __MOTION_ANIMATION_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define MOTION_TYPE_ANIMATION            (motion_animation_get_type())
#define MOTION_ANIMATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MOTION_TYPE_ANIMATION, MotionAnimation))
#define MOTION_ANIMATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), MOTION_TYPE_ANIMATION, MotionAnimationClass))
#define MOTION_IS_ANIMATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MOTION_TYPE_ANIMATION))
#define MOTION_IS_ANIMATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), MOTION_TYPE_ANIMATION))
#define MOTION_ANIMATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), MOTION_TYPE_ANIMATION, MotionAnimationClass))

typedef struct _MotionAnimationPrivate MotionAnimationPrivate;
typedef struct _MotionAnimationClass MotionAnimationClass;

struct _KeyPoint {
    double value;
    double time;
};

struct _MotionAnimation {
	GObject parent_instance;
    /*public*/
    void *data;/* application data*/

    /*only read*/
    double *times;
    double begin;
    double duration;// simple duration
    double end;// repeat

    double *values;/*GValue values[];*/
    double from;
    double to;

    double *splines;/*EasingLinear, EasingCubic*/

    MotionEasing *easing;
    /*MotionPath   *path_easing;*/

    double (*calculate_value)   (MotionAnimation *animation, double percent);


	/* private */
	MotionAnimationPrivate *private_member;
};

struct _MotionAnimationClass {
	GObjectClass parent_class;

    double (*interpolate)   (MotionAnimation *animation, double progress);
};

GType motion_animation_get_type();
MotionAnimation *motion_animation_new();

MotionEasing* motion_animation_get_easing(MotionAnimation *animation);
void          motion_animation_set_easing(MotionAnimation *animation, MotionEasing *easing);
double        motion_animation_interpolate(MotionAnimation *animation, double progress);

void motion_animation_set_times(MotionAnimation *animation, double begin, double end);
void motion_animation_set_values(MotionAnimation *animation, double from, double to);
double          motion_animation_get_begin(MotionAnimation *motion);
double          motion_animation_get_end(MotionAnimation *motion);
double          motion_animation_get_dur(MotionAnimation *motion);
double          motion_animation_get_from(MotionAnimation *animation);
double          motion_animation_get_to(MotionAnimation *animation);

G_END_DECLS

#endif /* __MOTION_ANIMATION_H__ */

