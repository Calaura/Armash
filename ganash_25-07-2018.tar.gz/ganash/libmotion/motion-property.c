/*
 * motion-property.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "motion-types.h"
#include "motion-easing.h"
#include "motion-animation.h"
#include "motion-property.h"


#define MOTION_PROPERTY_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), MOTION_TYPE_PROPERTY, MotionPropertyPrivate))
struct _MotionPropertyPrivate {
    gchar   *name;
    GObject *target;

    double begin;
    double end;//
    double duration;

    // MotionEasing *easings;// Array
    GValue *values;
    double *times;
    double *splines;
    gint    length;

};

static double motion_property_animation_interpolate(MotionAnimation *animation, double progress);

static void motion_property_class_init(MotionPropertyClass *klass);
static void motion_property_init(MotionProperty *gobject);

G_DEFINE_TYPE (MotionProperty, motion_property, MOTION_TYPE_ANIMATION)
#define parent_class motion_property_parent_class;

static void
motion_property_class_init(MotionPropertyClass *klass)
{
    MotionAnimationClass *animation_class;

    animation_class = (MotionAnimationClass *) klass;

    /*animation_class->interpolate = motion_property_animation_interpolate;*/

    g_type_class_add_private(klass, sizeof(MotionPropertyPrivate));
//	motion_property_parent_class = g_type_class_peek_parent (klass);
}

static void
motion_property_init (MotionProperty *object)
{
	MotionPropertyPrivate *priv = MOTION_PROPERTY_GET_PRIVATE(object);
	object->private_member = priv;
    priv->target = NULL;
    priv->name   = NULL;
}

static double motion_property_animation_interpolate(MotionAnimation *animation, double progress)
{
    g_print("------------------------------- \n");

    return 0.0;
}

MotionProperty *
motion_property_new (gchar* name, GObject *target)
{
    MotionProperty *property;
    property = g_object_new (motion_property_get_type (), NULL);
    property->private_member->target = target;
    property->private_member->name   = g_strdup(name);

    return property;
}
