#include "motion-animatable.h"

G_DEFINE_INTERFACE(MotionAnimatable, motion_animatable, 0)

static void
motion_animatable_default_init(MotionAnimatableInterface *klass) {
  /* Add properties and signals to the interface here */

}

void
motion_animatable_interface_init(MotionAnimatable *self, double time) {
    g_return_if_fail(MOTION_IS_ANIMATABLE(self));

    MOTION_ANIMATABLE_GET_INTERFACE(self)->init(self, time);
}

void
motion_animatable_interface_play(MotionAnimatable *self) {
    g_return_if_fail(MOTION_IS_ANIMATABLE(self));

    MOTION_ANIMATABLE_GET_INTERFACE(self)->play(self);
}

void
motion_animatable_interface_pause(MotionAnimatable *self) {
    g_return_if_fail(MOTION_IS_ANIMATABLE(self));

    MOTION_ANIMATABLE_GET_INTERFACE(self)->pause(self);
}

void
motion_animatable_interface_stop(MotionAnimatable *self) {
    g_return_if_fail(MOTION_IS_ANIMATABLE(self));

    MOTION_ANIMATABLE_GET_INTERFACE(self)->stop(self);
}
