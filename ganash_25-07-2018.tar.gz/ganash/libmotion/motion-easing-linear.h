/*
 * motion-easing-linear.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __MOTION_EASING_LINEAR_H__
#define __MOTION_EASING_LINEAR_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define MOTION_TYPE_EASING_LINEAR            (motion_easing_linear_get_type())
#define MOTION_EASING_LINEAR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MOTION_TYPE_EASING_LINEAR, MotionEasingLinear))
#define MOTION_EASING_LINEAR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), MOTION_TYPE_EASING_LINEAR, MotionEasingLinearClass))
#define MOTION_IS_EASING_LINEAR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MOTION_TYPE_EASING_LINEAR))
#define MOTION_IS_EASING_LINEAR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), MOTION_TYPE_EASING_LINEAR))
#define MOTION_EASING_LINEAR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), MOTION_TYPE_EASING_LINEAR, MotionEasingLinearClass))

typedef struct _MotionEasingLinearPrivate MotionEasingLinearPrivate;
typedef struct _MotionEasingLinearClass MotionEasingLinearClass;

struct _MotionEasingLinear {
	MotionEasing parent_instance;
	/* private */
    double P0_x, P0_y;
    double P1_x, P1_y;
    MotionEasingLinearPrivate *private_member;
};

struct _MotionEasingLinearClass {
	MotionEasingClass parent_class;
};

GType motion_easing_linear_get_type();
MotionEasing *motion_easing_linear_new();
void motion_easing_linear_set_values(MotionEasing *easing, double from, double to);
void motion_easing_linear_set_times(MotionEasing *easing, double begin, double end);

G_END_DECLS

#endif /* __MOTION_EASING_LINEAR_H__ */

