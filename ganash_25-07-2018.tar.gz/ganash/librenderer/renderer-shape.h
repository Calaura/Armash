/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _RENDERER_SHAPE_H_
#define _RENDERER_SHAPE_H_

#include <glib-object.h>

G_BEGIN_DECLS

enum
{
    RENDERER_PATH_SHIFT            = 4,/*RENDERER_OBJECT_SHIFT,*/
    RENDERER_GRAPHICS_PATH_SHIFT   = 6,
    RENDERER_GRAPHICS_FILL_SHIFT   = 8,
    RENDERER_GRAPHICS_STROKE_SHIFT = 10
};

enum
{
    RENDERER_PATH_MASK            = 0b0000000000110000,
    RENDERER_GRAPHICS_PATH_MASK   = 0b0000000011000000,
    RENDERER_GRAPHICS_FILL_MASK   = 0b0000001100000000,
    RENDERER_GRAPHICS_STROKE_MASK = 0b0000110000000000
};


#define RENDERER_TYPE_SHAPE             (renderer_shape_get_type ())
#define RENDERER_SHAPE(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), RENDERER_TYPE_SHAPE, RendererShape))
#define RENDERER_SHAPE_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), RENDERER_TYPE_SHAPE, RendererShapeClass))
#define RENDERER_IS_SHAPE(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), RENDERER_TYPE_SHAPE))
#define RENDERER_IS_SHAPE_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), RENDERER_TYPE_SHAPE))
#define RENDERER_SHAPE_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), RENDERER_TYPE_SHAPE, RendererShapeClass))


struct _RendererShape
{
    RendererObject parent_instance;

    guint            status;

    GraphicsFill   *fill;
    GraphicsStroke *stroke;
    GraphicsPath   *path;

};

typedef struct _RendererShapeClass RendererShapeClass;

struct _RendererShapeClass
{
    RendererObjectClass parent_class;
};

GType renderer_shape_get_type (void) G_GNUC_CONST;
RendererShape  *renderer_shape_new (RendererScene *scene, gchar *name);
GraphicsPath   *renderer_shape_get_path(RendererShape *shape);
void            renderer_shape_set_path(RendererShape *shape, GraphicsPath* path);
GraphicsFill   *renderer_shape_get_fill(RendererShape *shape);
void            renderer_shape_set_fill(RendererShape *shape, GraphicsFill *fill);
GraphicsStroke *renderer_shape_get_stroke(RendererShape *shape);
void            renderer_shape_set_stroke(RendererShape *shape, GraphicsStroke *stroke);


G_END_DECLS

#endif /* _RENDERER_SHAPE_H_ */
