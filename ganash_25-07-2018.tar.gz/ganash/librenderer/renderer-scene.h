/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _RENDERER_SCENE_H_
#define _RENDERER_SCENE_H_

#include <glib-object.h>

G_BEGIN_DECLS

#define RENDERER_TYPE_SCENE             (renderer_scene_get_type ())
#define RENDERER_SCENE(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), RENDERER_TYPE_SCENE, RendererScene))
#define RENDERER_SCENE_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), RENDERER_TYPE_SCENE, RendererSceneClass))
#define RENDERER_IS_SCENE(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), RENDERER_TYPE_SCENE))
#define RENDERER_IS_SCENE_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), RENDERER_TYPE_SCENE))
#define RENDERER_SCENE_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), RENDERER_TYPE_SCENE, RendererSceneClass))

typedef struct _RendererSceneClass RendererSceneClass;



struct _RendererSceneClass
{
    GObjectClass parent_class;
};

struct _RendererScene
{
    GObject parent_instance;

    gchar* name;

    /*RendererConfig config;*/
    RendererObject *root;/* Pointer to the root TreeRender */
    RendererObject *target;/* Pointer to Render object */
    RendererView   *view;/* Pointer to Render object */

    //RendererHitTestResult hit_test_result;

};

GType renderer_scene_get_type (void) G_GNUC_CONST;
RendererScene* renderer_scene_new (gchar *name);

void
renderer_scene_set_root(RendererScene *scene, RendererObject *object);

void
renderer_scene_set_target(RendererScene *scene, RendererObject *object);

void
renderer_scene_set_view(RendererScene *scene, RendererView *view);

void
renderer_scene_to_context(RendererScene *scene, cairo_t* cr);


gboolean
renderer_scene_hit_test(RendererScene *scene, cairo_t *cr, RendererHitTestRequest *request, RendererHitTestResult *result);

RendererBox*
renderer_scene_bounding_box(RendererScene* scene, cairo_t *cr, RendererBoundingMode mode);


G_END_DECLS

#endif /* _RENDERER_SCENE_H_ */
