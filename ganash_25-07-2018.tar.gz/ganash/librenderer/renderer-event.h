/*
 * renderer-event.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __RENDERER_EVENT_H__
#define __RENDERER_EVENT_H__

#include <glib-object.h>

typedef struct _RendererMouseEvent  RendererMouseEvent;
typedef enum   _RendererEventType   RendererEventType;

enum _RendererEventType
{
    RENDERER_ENTER_NOTIFY	= 10,
    RENDERER_LEAVE_NOTIFY	= 11,
};

// rename to GraphicsEvent
struct _RendererEvent {
    RendererEventType type;
    guint32 time;
    gdouble x;
    gdouble y;
    gdouble x_local;
    gdouble y_local;
};

struct _RendererMouseEvent {
    RendererEvent event;
};

struct _RendererProgressEvent {
    RendererEvent event;
};



#endif /* __RENDERER_EVENT_H__ */

