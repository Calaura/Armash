/*
 * renderer-config.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __RENDERER_CONFIG_H__
#define __RENDERER_CONFIG_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define RENDERER_TYPE_CONFIG            (renderer_config_get_type())
#define RENDERER_CONFIG(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), RENDERER_TYPE_CONFIG, RendererConfig))
#define RENDERER_CONFIG_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), RENDERER_TYPE_CONFIG, RendererConfigClass))
#define RENDERER_IS_CONFIG(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), RENDERER_TYPE_CONFIG))
#define RENDERER_IS_CONFIG_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), RENDERER_TYPE_CONFIG))
#define RENDERER_CONFIG_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), RENDERER_TYPE_CONFIG, RendererConfigClass))

typedef struct _RendererConfig RendererConfig;
typedef struct _RendererConfigClass RendererConfigClass;

struct _RendererConfig {
	GObject parent_instance;
};

struct _RendererConfigClass {
	GObjectClass parent_class;
};

GType renderer_config_get_type();
RendererConfig *renderer_config_new();

G_END_DECLS

#endif /* __RENDERER_CONFIG_H__ */

