/*
 * graphics-enums.h
 * Copyright (C) Sergio DE VASCONCELOS 2014 <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __RENDERER_ENUMS_H__
#define __RENDERER_ENUMS_H__

enum _RendererBoundingFlag {
    RENDERER_BOUNDING_TRANSFORM_FLAG = 0,
    RENDERER_BOUNDING_NUMS_FLAG
};

enum _RendererBoundingMode {
    RENDERER_BOUNDING_PATH_MODE   = 1 << RENDERER_BOUNDING_NUMS_FLAG,
    RENDERER_BOUNDING_FILL_MODE   = 2 << RENDERER_BOUNDING_NUMS_FLAG,
    RENDERER_BOUNDING_STROKE_MODE = 3 << RENDERER_BOUNDING_NUMS_FLAG,
    RENDERER_BOUNDING_EFFECT_MODE = 4 << RENDERER_BOUNDING_NUMS_FLAG,
    RENDERER_BOUNDING_VISUAL_MODE = 5 << RENDERER_BOUNDING_NUMS_FLAG
};

enum _RendererDumpFlag {
    RENDERER_DUMP_POINTER_FLAG    = 1 << (0 + LOG_DUMP_LAST_FLAG),
    RENDERER_DUMP_RECURSIVE_FLAG  = 1 << (1 + LOG_DUMP_LAST_FLAG),
    RENDERER_DUMP_TRANSFORM_FLAG  = 1 << (2 + LOG_DUMP_LAST_FLAG),
    RENDERER_DUMP_PATH_FLAG       = 1 << (3 + LOG_DUMP_LAST_FLAG),
    RENDERER_DUMP_ID_FLAG         = 1 << (4 + LOG_DUMP_LAST_FLAG),
    RENDERER_DUMP_ATTRIBUTES_FLAG = 1 << (5 + LOG_DUMP_LAST_FLAG),

    RENDERER_DUMP_LAST_FLAG       =       6 + LOG_DUMP_LAST_FLAG
};

#endif /* __RENDERER_ENUMS_H__ */
