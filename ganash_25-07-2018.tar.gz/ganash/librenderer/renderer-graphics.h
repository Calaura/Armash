/*
 * renderer-graphics.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __RENDERER_GRAPHICS_H__
#define __RENDERER_GRAPHICS_H__

#include <glib-object.h>

typedef struct _RendererGraphics RendererGraphics;

struct _RendererGraphics
{
    GraphicsFill*   fill;
    GraphicsStroke* stroke;
    GraphicsPath*   path;
    /*GraphicsData*   data;*/
    /*GraphicsContext* context; context->engine = cairo_t*; */
};

struct _RendererGraphicsClass
{
    void (*apply) (void);
};

/* renderer_graphics_*_to_context() */
void renderer_graphics_stroke(GraphicsStroke* stroke, cairo_t* cr);
void renderer_graphics_fill(GraphicsFill* fill, cairo_t* cr);
void renderer_graphics_path(GraphicsPath* path, cairo_t* cr);

#endif /* __RENDERER_GRAPHICS_H__ */
