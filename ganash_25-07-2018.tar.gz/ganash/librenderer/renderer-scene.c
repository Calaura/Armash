/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Sergio de Vasconcelos 2014 <user@mail.dtl>
 * 
 * Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <cairo/cairo.h>

#include "libgeom/geom-box.h"

#include <libgraphics/graphics.h>

#include <glib-object.h>
#include "renderer-types.h"
#include "renderer-enums.h"
#include "renderer-event.h"
#include "renderer-style.h"
#include "renderer-cache.h"
#include "renderer-object.h"
//#include "renderer-container.h"
#include "renderer-hit-test-result.h"
#include "renderer-hit-test-request.h"
#include "renderer-scene.h"
#include "renderer-view.h"
//#include "renderer-item.h"


G_DEFINE_TYPE (RendererScene, renderer_scene, G_TYPE_OBJECT)

static void
renderer_scene_init (RendererScene *scene)
{
    scene->root   = NULL;
    scene->target = NULL;
}

static void
renderer_scene_finalize (GObject *object)
{
	/* TODO: Add deinitalization code here */
    G_OBJECT_CLASS (renderer_scene_parent_class)->finalize (object);
}

static void
renderer_scene_class_init (RendererSceneClass *klass)
{
    GObjectClass* g_object_class = G_OBJECT_CLASS (klass);

    g_object_class->finalize = renderer_scene_finalize;

//    renderer_scene_parent_class = g_type_class_peek_parent (klass);
}

RendererScene*
renderer_scene_new (gchar *name)
{
    RendererScene  *scene  = g_object_new(RENDERER_TYPE_SCENE, NULL);
    if (name)
        scene->name = g_strdup(name);

    return scene;
}


void
renderer_scene_set_root(RendererScene *scene, RendererObject *object)
{
    scene->root = object;
}

void
renderer_scene_set_target(RendererScene *scene, RendererObject *object)
{
    scene->target = object;
}

void
renderer_scene_set_view(RendererScene *scene, RendererView *view)
{
    scene->view = view;
}

void renderer_scene_to_context(RendererScene* scene, cairo_t* cr)
{
    RendererObject *object = scene->target ? scene->target : scene->root;

    renderer_object_draw(object, cr);
}

gboolean
renderer_scene_hit_test(RendererScene *scene, cairo_t *cr, RendererHitTestRequest *request, RendererHitTestResult *result)
{
    RendererObject *object = scene->target ? scene->target : scene->root;

    gboolean succes = renderer_object_hit_test(object, cr, request, result);

    if (succes) {
        gboolean ret;
        RendererEvent e;// RendererMouseEvent
        e.x = request->x;
        e.y = request->y;

        g_signal_emit_by_name(result->items->data, "enter_notify_event", &e, &ret);
    }

    return succes;
}

/*
RendererHitTestResult
renderer_scene_hit_test (RendererScene* object, cairo_t *cr, const RendererHitTestRequest *request)
{
    RendererHitTestResult results;

    gboolean return_value;
    RendererScene* scene = RENDERER_SCENE(object);
    RendererContainer* container = RENDERER_CONTAINER(object);

    RendererHitTestResult results = RENDERER_OBJECT_CLASS(renderer_scene_parent_class)->hit_test(object, cr, request);

    RendererMouseEvent event;
    event.event.x = request->x;
    event.event.y = request->y;

    if (results.items) {
        GList* child = results.items;
        GList* seek  = scene->hit_test_result.items;
        while (child && seek && child->data==seek->data) {
            //event.event.target = seek->data;
            g_signal_emit_by_name (seek->data, "motion_notify_event", &event, &return_value);
            seek  = seek->next;
            child = child->next;
        }
        if (!child && seek) {
            seek = seek->prev;
        }
        while (seek && seek->data) {
            g_signal_emit_by_name (seek->data, "leave_notify_event", &event, &return_value);
            seek  = seek->next;
        }
        while (child && child->data) {
            g_signal_emit_by_name (child->data, "enter_notify_event", &event, &return_value);
            child  = child->next;
        }
    } else {
        GList* seek  = scene->hit_test_result.items;
        while (seek) {
            g_signal_emit_by_name (seek->data, "leave_notify_event", &event, &return_value);
            seek  = seek->next;
        }
    }

    g_list_free(scene->hit_test_result.items);
    scene->hit_test_result = results;
    return results;
}
*/
RendererBox*
renderer_scene_bounding_box(RendererScene* scene, cairo_t* cr, RendererBoundingMode mode)
{
    RendererObject  *object  = RENDERER_OBJECT(scene->target);

    return renderer_object_bounding_box(object, cr, mode);
}
