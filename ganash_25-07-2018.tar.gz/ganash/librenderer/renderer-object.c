/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
 * Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "config.h"

#include <string.h> //memcpy

#include <cairo/cairo.h>
#include <glib-object.h>
#include <liblog/log.h>

#include "libgraphics/graphics.h"


#include "renderer-types.h"
#include "renderer-enums.h"
#include "renderer-event.h"
#include "renderer-marshal.h"
#include "renderer-hit-test-request.h"
#include "renderer-hit-test-result.h"
#include "renderer-scene.h"
#include "renderer-cache.h"
#include "renderer-object.h"



enum
{
    ENTER_NOTIFY_EVENT,
    LEAVE_NOTIFY_EVENT,
    MOTION_NOTIFY_EVENT,
    BUTTON_PRESS_EVENT,
    BUTTON_RELEASE_EVENT,

    LAST_SIGNAL
};
static guint renderer_object_signals[LAST_SIGNAL] = { 0 };

static void renderer_object_log_interface_init (LogDumpInterface *iface);

G_DEFINE_TYPE_WITH_CODE (RendererObject, renderer_object, G_TYPE_OBJECT,
                         LOG_IMPLEMENT_INTERFACE_DUMP(renderer_object_log_interface_init))

/* Debugable interface                                                        */
/* ************************************************************************** */
static gchar*
renderer_object_default_dump(LogDump* object, LogDumpOptions *options)
{
#   define PLACE_HOLDER "%%s"
#   define EOL  "%s"
#   define TAB  "%s"
#   define GLUE "%s"
#   define FEEDL "%s"

    RendererObject *renderer = RENDERER_OBJECT(object);

    gchar *content = g_strdup("");
    gchar *tmp = content;

    // Use indentation
    gchar *indent;
    gchar *indent_;
    gchar *new_line;
    gchar *endl;
    gchar *glue_ = g_strdup("");
    gchar *glue = glue_;

    if (options->flags & LOG_DUMP_INDENT_FLAG) {
        size_t num_char = strlen(options->config->indent);
        size_t depth = num_char*options->depth +1;
        size_t depth_ = num_char*(options->depth+1)+1;
        indent = g_new(gchar, depth);
        memset(indent, options->config->indent[0], depth);
        indent_ = g_new(gchar, depth_);
        memset(indent_, options->config->indent[0], depth_);
        indent[depth-1] = '\0';
        indent_[depth_-1] = '\0';


        if (options->newl) {
            new_line = g_strdup_printf(EOL""TAB, options->config->endl, indent);
        } else {
            new_line = g_strdup("");
        }
        endl = g_strdup(options->config->endl);
    } else {
        indent   = g_strdup("");
        indent_  = g_strdup("");
        new_line = g_strdup("");
        endl     = g_strdup("");
    }


    if (renderer->name) {
        content = g_strdup_printf("%s"GLUE""EOL""TAB"name: \"%s\""PLACE_HOLDER, content, glue, endl, indent_, renderer->name);
        g_free(tmp);
        tmp = content;
        options->has_content = 1;
        glue = options->config->glue;
    }


    /*if((flags & RENDERER_DUMP_POINTER_FLAG) && object->data)
    {
        gchar *str_data = g_strdup_printf("[%s@%p]", G_OBJECT_TYPE_NAME(object->data), object->data);
        gchar *str_attr = g_strdup_printf("data: %s, "PLACE_HOLDER, str_data);// "data: [RendererRect@0x00], %s"
        content = g_strdup_printf(content, str_attr);
        g_free(tmp);
        tmp = content;
        g_free(str_data);
        g_free(str_attr);
    }*/

    /*if(!renderer_matrix_is_identity(&object->transform))
    {
        if (tmp) {
            gchar *matrix = renderer_matrix_debug(&object->transform);
            content = g_strdup_printf("%s, transform: %s", content, matrix);
            g_free(matrix);
            g_free(tmp);
            tmp = content;
        } else {
            gchar *matrix = renderer_matrix_debug(&object->transform);
            content = g_strdup_printf("transform: %s", content, matrix);
            g_free(matrix);
            tmp = content;
        }
    }*/

    /*if (tmp) {
        content = g_strdup_printf("%s, index: %d", content, object->index);
        g_free(tmp);
        tmp = content;
    } else {
        content = g_strdup_printf("index: %d", object->index);
        tmp = content;
    }*/

    if(options->flags & RENDERER_DUMP_POINTER_FLAG) {
        content = g_strdup_printf(FEEDL"[%s@%p{%s"EOL""TAB"}]", new_line, G_OBJECT_TYPE_NAME(object), object, content, endl, indent);
        g_free(tmp);
        tmp = content;
    } else {
        content = g_strdup_printf(FEEDL"[%s{%s"EOL""TAB"}]", new_line, G_OBJECT_TYPE_NAME(object), content, endl, indent);
        g_free(tmp);
        tmp = content;
    }

    return  content;
}



static void
renderer_object_log_interface_init (LogDumpInterface *iface)
{
    iface->to_string = renderer_object_dump;
}

/* Drawable interface                                                         */
/* ************************************************************************** */
static gboolean
renderer_object_default_draw (RendererObject* object, cairo_t* cr)
{
    g_error("Not Implemented");
    return FALSE;
}

/* Locatable interface                                                        */
/* ************************************************************************** */
static RendererBox*
renderer_object_default_bounding_box (RendererObject* object, cairo_t* cr, RendererBoundingMode mode)
{
    g_error("Not Implemented");

    return NULL;
}

gboolean
renderer_object_default_hit_test (RendererObject* object, cairo_t *cr,
                                  RendererHitTestRequest *request,
                                  RendererHitTestResult *result)
{
    return FALSE;
}

/* Stylable interface                                                         */
/* ************************************************************************** */


/* GObject signals                                                            */
/* ************************************************************************** */
static gboolean
renderer_object_enter_notify_event (RendererObject *self, RendererEvent* event)
{
    /* TODO: Add default signal handler implementation here */
    g_print("%s\n", G_STRFUNC);
    return FALSE;
}

static gboolean
renderer_object_leave_notify_event (RendererObject *self, RendererEvent* event)
{
    /* TODO: Add default signal handler implementation here */
    g_print("%s\n", G_STRFUNC);
    return FALSE;
}

static gboolean
renderer_object_motion_notify_event (RendererObject *self, RendererEvent* event)
{
    /* TODO: Add default signal handler implementation here */
    g_print("%s\n", G_STRFUNC);
    return FALSE;
}

static gboolean
renderer_object_button_press_event (RendererObject *self, RendererEvent* event)
{
    /* TODO: Add default signal handler implementation here */
    g_print("%s\n", G_STRFUNC);
    return FALSE;
}

static gboolean
renderer_object_button_release_event (RendererObject *self, RendererEvent* event)
{
    /* TODO: Add default signal handler implementation here */
    g_print("%s\n", G_STRFUNC);
    return FALSE;
}


/* GObject interface                                                          */
/* ************************************************************************** */
static void
renderer_object_init (RendererObject *object)
{
    /* TODO: Add initialization code here */
    object->data      = NULL;
    object->index     = 0;
    object->name      = NULL;

    object->parent    = NULL;
    object->scene     = NULL;

    object->sensitive = TRUE;
    object->visible   = TRUE;
    object->wired     = FALSE;

    object->opacity   = 1.0;

    object->mask      = NULL;
    object->clip      = NULL;

    cairo_matrix_init_identity(&object->transform);
    object->transform_is_identity = TRUE;

    /* renderer_cache_init */
    object->cache.root               = NULL;
    object->cache.absolute_transform = object->transform;
    object->cache.absolute_path      = NULL;
    object->cache.renderer_surface   = NULL;
    object->cache.status_update      = 0
        | RENDERER_CACHE_STATUS_UNKNOW << RENDERER_CACHE_PATH_SHIFT
        | RENDERER_CACHE_STATUS_UNKNOW << RENDERER_CACHE_TRANSFORM_SHIFT;
}


void
renderer_object_default_notify_transform(RendererObject* object)
{
    renderer_set_cache_status(object, TRANSFORM, EXPIRED);
}


static void
renderer_object_finalize (GObject *gobject)
{
    /* TODO: Add deinitalization code here */
    RendererObject *object = RENDERER_OBJECT(gobject);
    if (object->name) {
        g_free(object->name);
    }
    if (object->mask) {
        g_object_unref(object->mask);
    }
    if (object->clip) {
        g_object_unref(object->clip);
    }

    G_OBJECT_CLASS (renderer_object_parent_class)->finalize (gobject);
}

static void
renderer_object_class_init (RendererObjectClass *klass)
{
    GObjectClass* object_class = G_OBJECT_CLASS (klass);

    object_class->finalize = renderer_object_finalize;

    klass->dump             = renderer_object_default_dump;
    klass->draw             = renderer_object_default_draw;
    klass->bounding_box     = renderer_object_default_bounding_box;
    klass->hit_test         = renderer_object_default_hit_test;
    klass->notify_transform = renderer_object_default_notify_transform;

    klass->enter_notify_event   = renderer_object_enter_notify_event;
    klass->leave_notify_event   = renderer_object_leave_notify_event;
    klass->motion_notify_event  = renderer_object_motion_notify_event;
    klass->button_press_event   = renderer_object_button_press_event;
    klass->button_release_event = renderer_object_button_release_event;


    renderer_object_signals[ENTER_NOTIFY_EVENT] =
        g_signal_new ("enter_notify_event",
                      G_OBJECT_CLASS_TYPE (klass),
                      G_SIGNAL_RUN_LAST | G_SIGNAL_NO_RECURSE | G_SIGNAL_NO_HOOKS,
                      G_STRUCT_OFFSET (RendererObjectClass, enter_notify_event),
                      NULL, NULL,
                      renderer_marshal_BOOLEAN__POINTER,
                      G_TYPE_BOOLEAN, 1,
                      G_TYPE_POINTER);

    renderer_object_signals[LEAVE_NOTIFY_EVENT] =
        g_signal_new ("leave_notify_event",
                      G_OBJECT_CLASS_TYPE (klass),
                      G_SIGNAL_RUN_LAST | G_SIGNAL_NO_RECURSE | G_SIGNAL_NO_HOOKS,
                      G_STRUCT_OFFSET (RendererObjectClass, leave_notify_event),
                      NULL, NULL,
                      renderer_marshal_BOOLEAN__POINTER,
                      G_TYPE_BOOLEAN, 1,
                      G_TYPE_POINTER);

    renderer_object_signals[MOTION_NOTIFY_EVENT] =
        g_signal_new ("motion_notify_event",
                      G_OBJECT_CLASS_TYPE (klass),
                      G_SIGNAL_RUN_LAST | G_SIGNAL_NO_RECURSE | G_SIGNAL_NO_HOOKS,
                      G_STRUCT_OFFSET (RendererObjectClass, motion_notify_event),
                      NULL, NULL,
                      renderer_marshal_BOOLEAN__POINTER,
                      G_TYPE_BOOLEAN, 1,
                      G_TYPE_POINTER);

    renderer_object_signals[BUTTON_PRESS_EVENT] =
        g_signal_new ("button_press_event",
                      G_OBJECT_CLASS_TYPE (klass),
                      G_SIGNAL_RUN_LAST | G_SIGNAL_NO_RECURSE | G_SIGNAL_NO_HOOKS,
                      G_STRUCT_OFFSET (RendererObjectClass, button_press_event),
                      NULL, NULL,
                      renderer_marshal_BOOLEAN__POINTER,
                      G_TYPE_BOOLEAN, 1,
                      G_TYPE_POINTER);

    renderer_object_signals[BUTTON_RELEASE_EVENT] =
        g_signal_new ("button_release_event",
                      G_OBJECT_CLASS_TYPE (klass),
                      G_SIGNAL_RUN_LAST | G_SIGNAL_NO_RECURSE | G_SIGNAL_NO_HOOKS,
                      G_STRUCT_OFFSET (RendererObjectClass, button_release_event),
                      NULL, NULL,
                      renderer_marshal_BOOLEAN__POINTER,
                      G_TYPE_BOOLEAN, 1,
                      G_TYPE_POINTER);
}


/* public interface                                                           */
/* ************************************************************************** */
RendererObject*
renderer_object_new (RendererScene *scene, gchar *name)
{
    RendererObject *object = g_object_new(renderer_object_get_type(), NULL);
    object->scene = scene;
    if (name)
        object->name = g_strdup(name);
    return object;
}

void renderer_object_translate(RendererObject* object, gdouble tx, gdouble ty)
{
    cairo_matrix_t translate;
    cairo_matrix_init_translate(&translate, tx, ty);
    cairo_matrix_multiply(&object->transform, &object->transform, &translate);
}

void renderer_object_set_visible(RendererObject *object, gboolean visible)
{
    object->visible = visible;
}

/* virtual interface */

gchar *renderer_object_dump(LogDump* object, LogDumpOptions *options)
{
    return RENDERER_OBJECT_GET_CLASS(object)->dump(object, options);
}

gboolean renderer_object_draw(RendererObject* object, cairo_t *cr)
{
    return RENDERER_OBJECT_GET_CLASS(object)->draw(object, cr);
}

RendererBox *renderer_object_bounding_box(RendererObject* object, cairo_t *cr, RendererBoundingMode mode)
{
    return RENDERER_OBJECT_GET_CLASS(object)->bounding_box(object, cr, mode);
}

gboolean
renderer_object_hit_test(RendererObject *object, cairo_t *cr, RendererHitTestRequest *request, RendererHitTestResult *result)
{
    return RENDERER_OBJECT_GET_CLASS(object)->hit_test(object, cr, request, result);
}

void
renderer_object_notify_transform(RendererObject* object)
{
    RENDERER_OBJECT_GET_CLASS(object)->notify_transform(object);
}

void
renderer_object_get_transform_abs (RendererObject* object, cairo_matrix_t* matrix)
{
    g_return_if_fail(matrix);

    guint status_transform = renderer_get_cache_status(object, TRANSFORM);
    if (status_transform==RENDERER_CACHE_STATUS_UPDATE) {
        //g_print(" %s\n", G_STRFUNC);
        *matrix = object->cache.absolute_transform;
        return;
    }
    //g_print("+%s\n", G_STRFUNC);
    cairo_matrix_t *transform_abs = &object->cache.absolute_transform;
    cairo_matrix_init_identity(transform_abs);

    //RendererObject *root = object->scene->root;
    RendererObject *root = object->scene->target;// si on change de target le cache expire cf object->cache.root
    RendererObject *child;
    for(child = object; child; child = (RendererObject *) child->parent) {
        //if (!child->transform_is_identity) {
        //g_print("   %s->%s\n", G_OBJECT_TYPE_NAME(child->data), renderer_matrix_debug(&child->transform));

            cairo_matrix_multiply(transform_abs, transform_abs, &child->transform);
        //}
        if (child==root)
            break;
    }
    *matrix = *transform_abs;
    renderer_set_cache_status(object, TRANSFORM, UPDATE);
}

void
renderer_object_get_transform (RendererObject* object, cairo_matrix_t *matrix)
{
    *matrix = object->transform;
}

cairo_matrix_t*
renderer_object_transform (RendererObject* object)
{
    return &object->transform;
}

void
renderer_object_set_transform(RendererObject* object, cairo_matrix_t *matrix)
{
    object->transform = *matrix;
    object->transform_is_identity = renderer_matrix_is_identity(matrix);
}

gchar*
renderer_matrix_debug(cairo_matrix_t *matrix)
{
    return g_strdup_printf("[Matrix{f: %g, e: %g, d: %g, c: %g, b: %g, a: %g}]",
                           matrix->y0,
                           matrix->x0,
                           matrix->xx,
                           matrix->xy,
                           matrix->yx,
                           matrix->yy
                           );
}


gboolean
renderer_matrix_is_identity(cairo_matrix_t *matrix)
{
    if (    matrix->x0 == 0.0
         && matrix->xx == 1.0
         && matrix->xy == 0.0
         && matrix->y0 == 0.0
         && matrix->yx == 0.0
         && matrix->yy == 1.0) {
        return TRUE;
    }
    return FALSE;
}
