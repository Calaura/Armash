/*
 * renderer-line.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <libgraphics/graphics.h>

#include <liblog/log.h>

#include "renderer-types.h"
#include "renderer-cache.h"
#include "renderer-object.h"
#include "renderer-item.h"
#include "renderer-shape.h"
#include "renderer-line.h"
#include "renderer-scene.h"
#include "renderer-view.h"

static void renderer_line_class_init(RendererLineClass *klass);
static void renderer_line_init(RendererLine *gobject);

G_DEFINE_TYPE (RendererLine, renderer_line, RENDERER_TYPE_SHAPE)

static void
renderer_line_class_init(RendererLineClass *klass)
{
	RendererShapeClass *renderershape_class;

	renderershape_class = (RendererShapeClass *) klass;

//	renderer_line_parent_class = g_type_class_peek_parent (klass);
}

static void
renderer_line_init (RendererLine *object)
{
}

RendererLine *
renderer_line_new (void)
{
	return g_object_new (renderer_line_get_type (),
	                     NULL);
}

void renderer_line_set(RendererLine *line, double x0, double y0, double x1, double y1)
{
    RendererShape *shape = RENDERER_SHAPE(line);
//    RendererObject *object = (RendererObject*) shape;
//    RendererScene *scene = object->scene;
//    RendererView *view = scene->view;
//    cairo_t *cr = view->work_context;

//    graphics_path_clear(path);
//    graphics_path_move_to(path, x0, y0);
//    graphics_path_to(path, x1, y1);

//    graphics_path_set(shape->path, path);

    GraphicsPath *path = renderer_shape_get_path(shape);

    graphics_path_reset(path);
    graphics_path_move_to(path,   x0,   y0);
    graphics_path_line_to(path,   x1,   y1);
}
