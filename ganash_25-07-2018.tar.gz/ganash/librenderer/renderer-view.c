/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Ganash
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
 * Display is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Display is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <libgraphics/graphics.h>

#include "libgeom/geom-box.h"

#include "renderer-types.h"
#include "renderer-enums.h"
#include "renderer-box.h"
#include "renderer-cache.h"
#include "renderer-object.h"
#include "renderer-scene.h"
#include "renderer-view.h"


G_DEFINE_TYPE (RendererView, renderer_view, G_TYPE_OBJECT)
#define parent_class renderer_view_parent_class

static GObject *
renderer_view_constructor ( GType                  gtype,
                            guint                  n_properties,
                            GObjectConstructParam *properties)
{
    GObject *obj;

    {
        /* Always chain up to the parent constructor */
        obj = G_OBJECT_CLASS (parent_class)->constructor (gtype, n_properties, properties);
    }

    /* update the object state depending on constructor properties */

    return obj;
}

static void
renderer_view_dispose (GObject *gobject)
{
    RendererView   *view  = RENDERER_VIEW (gobject);
    RendererObject *object  = RENDERER_OBJECT (view);

    /* In dispose(), you are supposed to free all types referenced from this
     * object which might themselves hold a reference to self. Generally,
     * the most simple solution is to unref all members on which you own a
     * reference.
     */

    /* dispose() might be called multiple times, so we must guard against
     * calling g_object_unref() on an invalid GObject by setting the member
     * NULL; g_clear_object() does this for us, atomically.
     */
    //g_clear_object (&self->priv->an_object);

    /* Always chain up to the parent class; there is no need to check if
     * the parent class implements the dispose() virtual function: it is
     * always guaranteed to do so
     */
    //G_OBJECT_CLASS (parent_class)->dispose (gobject);
    G_OBJECT_CLASS (parent_class)->dispose (gobject);
}

static void
renderer_view_finalize (GObject *gobject)
{
    RendererView   *view  = RENDERER_VIEW (gobject);
    RendererObject *object  = RENDERER_OBJECT (view);
    /* TODO: Add deinitalization code here */

    //G_OBJECT_CLASS (parent_class)->finalize (object);
    G_OBJECT_CLASS (parent_class)->dispose (gobject);
}

static void
renderer_view_class_init (RendererViewClass *klass)
{
    GObjectClass        *object_class   = G_OBJECT_CLASS (klass);

    object_class->constructor = renderer_view_constructor;
    object_class->dispose     = renderer_view_dispose;
    object_class->finalize    = renderer_view_finalize;
}

static void
renderer_view_init (RendererView *view)
{
    view->scene = NULL;
    view->work_surface = cairo_image_surface_create (CAIRO_FORMAT_A8, 0, 0);
    view->work_context = cairo_create(view->work_surface);
    /*cairo_matrix_t *matrix = g_new(cairo_matrix_t, 1);
    cairo_matrix_init_identity(matrix);
    cairo_set_matrix(view->work_context, matrix);*/

    //view->background = NULL;

    view->offset_x = 0;
    view->offset_y = 0;
    view->scale_x = 1.0;
    view->scale_y = 1.0;
    view->rotate  = 0.0;

    /* TODO: Add initialization code here */
}

/* public functions */
RendererView*
renderer_view_new(void)
{
    RendererView *view = g_object_new(renderer_view_get_type(), NULL);
    return view;
}

void renderer_view_set_scene(RendererView* view, RendererScene *scene)
{
    view->scene = scene;
}

void renderer_view_to_context(RendererView* view, cairo_t *cr)
{
    cairo_t *context = cr ? cr : view->work_context;

    cairo_save(cr);

    //if (view->background) {
    //    graphics_fill_to_context(view->background, cr, FALSE);
    //}

    cairo_scale(context, view->scale_x, view->scale_y);
    cairo_translate(context, view->offset_x, view->offset_y);
    cairo_rotate(context, view->rotate);

    renderer_scene_to_context(RENDERER_SCENE(view->scene), cr);

    cairo_restore(cr);
}

gboolean
renderer_view_hit_test(RendererView *view, RendererObject *target, RendererHitTestRequest *request, RendererHitTestResult *result)
{
    gboolean ret;

    // TODO scale etc ...

    RendererObject *tmp = view->scene->target;
    renderer_scene_set_target(view->scene, target);
    ret = renderer_scene_hit_test(view->scene, view->work_context, request, result);
    renderer_scene_set_target(view->scene, tmp);

    return ret;
}

RendererBox*
renderer_view_bounding_box(RendererView* view, RendererBoundingMode mode)
{
    RendererScene  *scene  = RENDERER_SCENE(view->scene);

    return renderer_scene_bounding_box(scene, view->work_context, mode);
}
