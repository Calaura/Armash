Dans renderer-shape.c
if(!shape->fill && !shape->stroke) {
if (graphics_fill_is_empty(shape->fill) && graphics_stroke_is_empty(shape->stroke))

FIXME:
renderer_rect_new() doit retourner RendererObject*

Optimiser le hittest avec des bounding_box

graphics__bounding_box() see libsvg/TODO.txt
Faire le cache; transform, surface, etc...

TODO:
styleable
ghost
animation

Renderer = display
Graphics = display.graphics

View:
     void zoomIn() { scale(1.2, 1.2); }
     void zoomOut() { scale(1 / 1.2, 1 / 1.2); }
     void rotateLeft() { rotate(-10); }
     void rotateRight() { rotate(10); }


   Platform :
 +-------------------------------------------------+
 |                                                 |
 |  +-------+    +---------+    +---------+        |      +----------+       +----------+
 |  |       |    |         |    |         |        |      |          |       |          |
 |  | cairo |    | lib xml |    | lib css |        |      | lib math |       | lib geom |
 |  |       |    |         |    |         |        |      |          |       |          |
 |  +-------+    +---------+    +---------+        |      +----------+       +----------+
 |                                                 |           |                  |
 +---------+---------------------------------------+-----------+------------------+
           |
           |
           |
           |
           |
           |
    +--------------+
    |              |
    | lib Graphics |
    |              |
    +--------------+
           |
    +--------------+    +------------+
    |              |    |            |
    | lib Renderer |    | lib Motion |
    |              |    |            |
    +--------------+    +------------+
           |                   |
           +-------------------+
                               |
                           +---------+               +-------------+
                           |         |               |             |
                           | lib SVG |               | lib Widgets |
                           |         |               |             |
                           +---------+               +-------------+
                                |                           |
                                +---------------------------+
                                              |
-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
                                              |
                                       +-------------+
                                       |             |
                                       | lib Svgtk   |
                                       |             |
                                       +-------------+
                                              |
-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
                                              |
                                       +-------------+
                                       |             |
                                       | lib Display |
                                       |             |
                                       +-------------+
                                              |
-  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
                                              |


 +-----------------------------------------------------------------------------
 |
 | Platform :
 |
 |
 |  +-------+    +--------+
 |  |       |    |        |
 |  |  Gtk  |    |   Qt   |
 |  |       |    |        |
 |  +-------+    +--------+
 |
 +-----------------------------------------------------------------------------
