/*
 * renderer-rect.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "config.h"

#include <liblog/log.h>

#include <libgraphics/graphics.h>

#include "renderer-types.h"
#include "renderer-enums.h"

#include "renderer-cache.h"
#include "renderer-object.h"
#include "renderer-container.h"
#include "renderer-scene.h"
#include "renderer-view.h"
#include "renderer-item.h"
#include "renderer-shape.h"
#include "renderer-graphics.h"
#include "renderer-rect.h"

#include <glib/gstrfuncs.h>

#include <string.h>

static void renderer_rect_class_init(RendererRectClass *klass);
static void renderer_rect_init(RendererRect *gobject);


static void              renderer_rect_log_interface_init (LogDumpInterface *iface);
static LogDumpInterface *renderer_rect_log_parent_interface = NULL;

G_DEFINE_TYPE_WITH_CODE (RendererRect, renderer_rect, RENDERER_TYPE_SHAPE,
                         LOG_IMPLEMENT_INTERFACE_DUMP(renderer_rect_log_interface_init))


static gchar*
renderer_rect_debug (LogDump* object, LogDumpOptions *options)
{
#define PLACE_HOLDER "%%s"

    RendererShape* shape= RENDERER_SHAPE(object);

    // Use indentation
    gchar *indent;
    gchar *indent_;
    gchar *new_line;
    gchar *endl;
    gchar *glue_ = g_strdup("");
    gchar *glue = glue_;

    if (options->flags & LOG_DUMP_INDENT_FLAG) {
        size_t num_char = strlen(options->config->indent);
        size_t depth = num_char*options->depth;
        indent = g_new(gchar, depth);
        memset(indent, options->config->indent[0], depth);
        indent_ = g_new(gchar, depth+1);
        memset(indent_, options->config->indent[0], num_char*(options->depth+1));
        if (options->newl) {
            new_line = g_strdup(options->config->endl);
        } else {
            new_line = g_strdup("");
        }
        endl = g_strdup(options->config->endl);
    } else {
        indent   = g_strdup("");
        indent_  = g_strdup("");
        new_line = g_strdup("");
        endl     = g_strdup("");
    }

    gchar *ind = g_strdup_printf("%s%s", indent, "    ");
    gchar *content;
    gchar *tmp = NULL;
    LogDumpOptions opt = *options;
    content = renderer_rect_log_parent_interface->to_string(object, &opt);
    //content = RENDERER_OBJECT_CLASS(renderer_rect_parent_class)->debug(object, indent, flags);
    /*tmp = content;

    if (shape->path) {
        gchar *tmp_path;
        gchar *str_path = graphics_path_debug(shape->path);
        tmp_path = str_path;

        str_path = g_strdup_printf("path:%s, "PLACE_HOLDER, str_path);
        g_free(tmp_path);
        tmp_path = str_path;

        content = g_strdup_printf(content, str_path);
        g_free(str_path);
        g_free(tmp);
        tmp = content;
    }*/

    return content;
}

static void
renderer_rect_log_interface_init (LogDumpInterface *iface)
{
    renderer_rect_log_parent_interface = g_type_interface_peek_parent (iface);
    iface->to_string = renderer_rect_debug;
}

static void
renderer_rect_class_init(RendererRectClass *klass)
{
    RendererObjectClass *object_class;
    RendererShapeClass *shape_class;

    shape_class = (RendererShapeClass *) klass;
    object_class = (RendererObjectClass *) klass;

//	renderer_rect_parent_class = g_type_class_peek_parent (klass);
}

static void
renderer_rect_init (RendererRect *object)
{
}

RendererRect*
renderer_rect_new (RendererScene *scene, gchar *name)
{
    RendererRect* rect = g_object_new(RENDERER_TYPE_RECT, NULL);
    RendererObject* object = RENDERER_OBJECT(rect);
    if (name)
        object->name = g_strdup(name);
    object->scene = scene;
    return rect;
}

void renderer_rect_set(RendererRect *rect, double x0, double y0, double x1, double y1, double rx, double ry)
{
    //RendererView *view = RENDERER_OBJECT(rect)->scene->view;
    //cairo_t *cr = view->work_context;

    RendererShape *shape = (RendererShape *) rect;
    GraphicsPath *path = renderer_shape_get_path(shape);

    graphics_path_reset(path);
//    graphics_path_move_to(path,   x0,   y0);
//    graphics_path_line_to(path,   x1,   y0);
//    graphics_path_line_to(path,   x1,   y1);
//    graphics_path_line_to(path,   x0,   y1);
//    graphics_path_line_to(path,   x0,   y0);
//    graphics_path_close(path);

//    GraphicsPath *path = graphics_path_new();
        gdouble x = x0;
        gdouble y = y0;
        gdouble width = x1-x0;
        gdouble height = y1-y0;
        gdouble r1 = rx;
        gdouble r2 = rx;
        gdouble r3 = ry;
        gdouble r4 = ry;
        gdouble radius;
        gdouble degrees = 3.1415 / 180.0;

        if (r1>0.0) {
            radius = r1;
            graphics_path_move_to(path, x + width - radius, y);
            graphics_path_arc (path, x + width - radius, y + radius, radius, -90 * degrees, 0 * degrees);
        } else {
            graphics_path_move_to(path, x + width, y);
        }
        if (r2>0) {
            radius = r2;
            graphics_path_arc (path, x + width - radius, y + height - radius, radius, 0 * degrees, 90 * degrees);
        } else {
            graphics_path_line_to(path, x + width, y + height);
        }
        if (r3>0) {
            radius = r3;
            graphics_path_arc (path, x + radius, y + height - radius, radius, 90 * degrees, 180 * degrees);
        } else {
            graphics_path_line_to(path, x, y + height);
        }
        if (r4>0) {
            radius = r4;
            graphics_path_arc (path, x + radius, y + radius, radius, 180 * degrees, 270 * degrees);
        } else {
            graphics_path_line_to(path, x, y);
        }
        graphics_path_close (path);

}
