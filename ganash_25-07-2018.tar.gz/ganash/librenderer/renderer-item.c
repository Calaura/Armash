/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
 * Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <cairo/cairo.h>


#include "renderer-types.h"
#include "renderer-cache.h"
#include "renderer-object.h"
#include "renderer-item.h"


G_DEFINE_TYPE (RendererItem, renderer_item, RENDERER_TYPE_OBJECT)
#define parent_class renderer_item_parent_class

/* virtual function GObject */
/* ************************************************************************* */
static void
renderer_item_init (RendererItem *item)
{
    item->sensitive = TRUE;
    item->visible   = TRUE;
    item->wired     = FALSE;

    item->mask = NULL;
    item->clip = NULL;

}

static void
renderer_item_finalize (GObject *object)
{
    /* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (renderer_item_parent_class)->finalize (object);
}

/* virtual function RendererObject */
/* ************************************************************************* */
static gchar*
renderer_item_debug (RendererObject* object, gchar* indent)
{
    gchar *content;
    gchar *tmp = NULL;
    content = RENDERER_OBJECT_CLASS(renderer_item_parent_class)->debug(object, indent);
    tmp = content;

    content = g_strdup_printf(content, ", ...");
    g_free(tmp);

    return content;
}


/* virtual function RendererItem */
/* ************************************************************************* */
/* Drawable interface */
static gboolean
renderer_item_draw (RendererItem* object, cairo_t* cr)
{
    g_error("Not Implemented");
    /*
    DisplayContainer* container = DISPLAY_CONTAINER(object);
    cairo_save(cr);
    cairo_transform(cr, &object->matrix);
    GList* list;
    for (list = container->priv->children; list; list=list->next) {
        RendererObject* child = list->data;
        renderer_object_draw(child, cr);
    }
    cairo_restore(cr);
    */
    return FALSE;
}

static void
renderer_item_class_init (RendererItemClass *klass)
{
    GObjectClass        *gobject_class = G_OBJECT_CLASS (klass);
    RendererObjectClass *object_class  = RENDERER_OBJECT_CLASS (klass);
    /*GtkWidgetClass* widget_class = GTK_WIDGET_CLASS (klass);*/

    object_class->debug             = renderer_item_debug;
    klass->draw                         = renderer_item_draw;

    gobject_class->finalize = renderer_item_finalize;

//    renderer_item_parent_class = g_type_class_peek_parent (klass);
}



/* public function */
RendererItem *
renderer_item_new(gchar* name)
{
    RendererItem *item = g_object_new(renderer_item_get_type(), NULL);
    RendererObject *object = (RendererObject *) item;
    if(name)
        object->name = g_strdup(name);

    return item;
}

