/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
 * Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <gdk/gdk.h>

#include "config.h"

#include <liblog/log.h>

#include <libgraphics/graphics.h>
#include "libgraphics/graphics-path.h"


#include "libgeom/geom-box.h"
#include "libgeom/geom-point.h"
#include "libgeom/geom-polygon.h"

#include "renderer-types.h"
#include "renderer-enums.h"
#include "renderer-box.h"
#include "renderer-hit-test-request.h"
#include "renderer-hit-test-result.h"
#include "renderer-cache.h"
#include "renderer-object.h"
#include "renderer-container.h"
#include "renderer-scene.h"
#include "renderer-item.h"
#include "renderer-shape.h"
#include "renderer-graphics.h"
/*#include "renderer-style.h"*/

/*
enum
{
  PROPERTY_0,

  PROPERTY_PATH,

  PROPERTIES_LENGTH
};


static gboolean renderer_shape_draw (RendererObject* object, cairo_t *cr);
static RendererHitTestResult renderer_shape_hit_test(RendererObject* object, cairo_t *cr, const RendererHitTestRequest *request);
static GeomBox* renderer_shape_get_bounding_box (RendererObject* object, cairo_t *cr, guint flags);
static GeomBox* renderer_shape_get_bounding_box_approximate (RendererObject* object, cairo_t *cr, guint flags);

static void renderer_shape_set_property (GObject      *object,
                                      guint         property_id,
                                      const GValue *value,
                                      GParamSpec   *pspec);
static void renderer_shape_get_property (GObject    *object,
                                      guint       property_id,
                                      GValue     *value,
                                      GParamSpec *pspec);

static void renderer_shape_update (RendererObject* object, cairo_t *cr);


static GParamSpec *renderer_shape_properties[PROPERTIES_LENGTH] = { NULL, };
*/


/*
#include <liblog/log.h>
static void              renderer_shape_log_interface_init (LogDumpInterface *iface);
static LogDumpInterface *renderer_shape_log_parent_interface = NULL;

G_DEFINE_TYPE_WITH_CODE (RendererShape, renderer_shape, RENDERER_TYPE_OBJECT,
                         LOG_IMPLEMENT_DUMP(renderer_shape_log_interface_init))
*/

G_DEFINE_TYPE (RendererShape, renderer_shape, RENDERER_TYPE_OBJECT)

//#define parent_class renderer_shape_parent_class

/* Drawing interface */
/* ************************************************************************* */
static gboolean
renderer_shape_draw (RendererObject *object, cairo_t *cr)
{
    RendererShape* shape = RENDERER_SHAPE(object);

    if(!object->visible) {
        return FALSE;
    }

    if(graphics_path_is_empty(shape->path)) {
        g_print("Warning: empty Path\n");
        return FALSE;
    }
    if(!shape->fill && !shape->stroke) {
        g_print("Warning: empty Fill/Stroke\n");
        return FALSE;
    }

    cairo_save(cr);
    //graphics_transform_to_context(RENDERER_OBJECT(shape)->transform, cr);
    //if(!object->transform_is_identity) {
        cairo_transform(cr, &object->transform);
    //}

    graphics_path_to_context(shape->path, cr, FALSE);

    // graphics_fill_is_empty(!shape->fill|none)
    if (shape->fill && shape->fill->painter) {
        if (shape->stroke && shape->stroke->painter)
            graphics_fill_to_context(shape->fill, cr, TRUE);
        else
            graphics_fill_to_context(shape->fill, cr, FALSE);
    }
    if (shape->stroke && shape->stroke->painter) {
        graphics_stroke_to_context(shape->stroke, cr, FALSE);
    }

    cairo_restore(cr);

    return FALSE;
}

/* Locatable interface */
/* ************************************************************************* */
static RendererBox*
renderer_shape_bounding_box (RendererObject* object, cairo_t *cr, RendererBoundingMode mode)
{
    RendererShape* shape = RENDERER_SHAPE(object);

    gboolean use_transform = mode && RENDERER_BOUNDING_TRANSFORM_FLAG;// use graphics_path_bounding_box()


    if (graphics_path_is_empty(shape->path)) {
        return NULL;
    }

    if (use_transform) {
        cairo_matrix_t  transform;
        renderer_object_get_transform_abs(object, &transform);
        /*g_print("Transform{%f, %f, %f, %f, %f, %f}\n",
                transform->x0,
                transform->xx,
                transform->xy,
                transform->y0,
                transform->yx,
                transform->yy);*/
        /*if (object->transform)
            cairo_set_matrix(cr, object->transform);*/
        cairo_set_matrix(cr, &transform);
        cairo_append_path(cr, graphics_path_to_cairo(shape->path));
        cairo_matrix_init_identity(&transform);
        cairo_set_matrix(cr, &transform);
    } else {
        cairo_append_path(cr, graphics_path_to_cairo(shape->path));
    }

    /*gchar *str = graphics_path_debug(shape->path);
    g_print("PATH: %s\n", str);
    g_free(str);*/

    gdouble x1 = 0.0;
    gdouble y1 = 0.0;
    gdouble x2 = 0.0;
    gdouble y2 = 0.0;
    if (mode==RENDERER_BOUNDING_VISUAL_MODE) {
        if (!shape->fill) {
            mode = RENDERER_BOUNDING_STROKE_MODE;
        }
    }
    switch (mode) {
        case RENDERER_BOUNDING_EFFECT_MODE:
            break;
        case RENDERER_BOUNDING_STROKE_MODE:
            if(shape->stroke) {
                graphics_stroke_to_context(shape->stroke, cr, TRUE);
            }
            cairo_stroke_extents(cr, &x1,  &y1, &x2, &y2);
            break;
        case RENDERER_BOUNDING_FILL_MODE:
            if(shape->fill) {
                graphics_fill_to_context(shape->fill, cr, TRUE);
            }
            cairo_fill_extents(cr, &x1,  &y1, &x2, &y2);
            break;
        case RENDERER_BOUNDING_PATH_MODE:
        default:
            cairo_path_extents(cr, &x1,  &y1, &x2, &y2);
            break;
    }
    cairo_new_path(cr);

    RendererBox *box = renderer_box_new();
    box->left      = x1;
    box->bottom    = y1;
    box->right     = x2;
    box->top       = y2;

    return box;
}
/*
 *
  cairo_matrix_t matrix;
  cairo_matrix_init_translate(&matrix, 10, 10);
  cairo_matrix_invert(&matrix);

  cairo_matrix_t identity;
  cairo_matrix_init_identity(&identity);

  cairo_path_t *path = create_path();
  cairo_append_path(cr, path);
  cairo_set_matrix(cr, &matrix);

  cairo_path_t *tmp_path = cairo_copy_path(cr);
  cairo_set_matrix(cr, &identity);
  cairo_new_path(cr);
 *
 */
static cairo_path_t *
renderer_shape_get_path_abs(RendererShape *shape, cairo_t *cr)
{
    RendererObject* object = (RendererObject*) shape;

    guint status_path = renderer_get_cache_status(object, PATH);
    if (status_path==RENDERER_CACHE_STATUS_UPDATE) {
        //g_print(" %s\n", G_STRFUNC);
        return object->cache.absolute_path;
    }
    //g_print("+%s\n", G_STRFUNC);
    if (object->cache.absolute_path) {
        cairo_path_destroy(object->cache.absolute_path);
    }

    cairo_matrix_t tmp;
    cairo_get_matrix(cr, &tmp);// cairo_save()

    cairo_matrix_t matrix;
    renderer_object_get_transform_abs(object, &matrix);
    cairo_matrix_invert(&matrix);
    cairo_append_path(cr, graphics_path_to_cairo(shape->path));
    cairo_set_matrix(cr, &matrix);

    cairo_path_t* path = cairo_copy_path(cr);

    cairo_set_matrix(cr, &tmp);// cairo_restore()

    object->cache.absolute_path = path;
    ////renderer_set_cache_status(object, PATH, UPDATE);
    return path;
}

// Surement a revoir: cf Bounding_box (http://comments.gmane.org/gmane.comp.lib.cairo/16118)
static gboolean
renderer_shape_hit_test(RendererObject* object, cairo_t *cr, const RendererHitTestRequest *request, RendererHitTestResult *result)
{
    //g_print("%s -> %s - %s / %s\n", G_STRFUNC, G_OBJECT_TYPE_NAME(object), object->name, G_OBJECT_TYPE_NAME(object->data));
    RendererShape* shape = RENDERER_SHAPE(object);
    RendererScene* scene = RENDERER_SCENE(object->scene);
    gboolean found = FALSE;

    if (!object->sensitive)
        return NULL;

    if (graphics_path_is_empty(shape->path)) {
        return NULL;
    }

    double rel_x = request->x;
    double rel_y = request->y;

    cairo_matrix_t matrix;
    renderer_object_get_transform_abs(object, &matrix);// revoir le systeme de mise en cache
    cairo_matrix_invert(&matrix);
    cairo_matrix_transform_point(&matrix, &rel_x, &rel_y);

    cairo_path_t *path = graphics_path_to_cairo(shape->path);
    //cairo_path_t *path = renderer_shape_get_path_abs(object, cr);// revoir le systeme de mise en cache
    //g_print("%f, %f => %f, %f\n", request->x, request->y, rel_x, rel_y);
    //g_print("%s\n", renderer_matrix_debug(&matrix));
    //g_print("%s\n", graphics_path_debug(path));

    cairo_append_path(cr, path);
    RendererHitTestMode mode = request->type;
    switch(mode)
    {
    case RENDERER_HIT_TEST_FILL_MODE:
        if (cairo_in_fill(cr, rel_x, rel_y)) {
            result->items = g_list_append(result->items, shape);
            found = TRUE;
        }
    break;
    case RENDERER_HIT_TEST_STROKE_MODE:
    {
        double line_width = cairo_get_line_width(cr);// cairo_save()
        cairo_set_line_width(cr, shape->stroke->width + request->deltat);
        if (cairo_in_stroke(cr, rel_x, rel_y)) {
            result->items = g_list_append(result->items, shape);
            found = TRUE;
        }
        cairo_set_line_width(cr, line_width);// cairo_restore()
    }
    break;
    case RENDERER_HIT_TEST_VISUAL_MODE:
        if (shape->fill) {
            if (cairo_in_fill(cr, rel_x, rel_y)) {
                found = TRUE;
            }
        }
        if (!found && shape->stroke) {
            double line_width = cairo_get_line_width(cr);// cairo_save()
            cairo_set_line_width(cr, shape->stroke->width + request->deltat);
            if (cairo_in_stroke(cr, rel_x, rel_y)) {
                found = TRUE;
            }
            cairo_set_line_width(cr, line_width);// cairo_restore()
        }
        if (found) {
            result->items = g_list_append(result->items, shape);
        }
        break;
    case RENDERER_HIT_TEST_UNKNOW_MODE:
        break;
    }
    cairo_new_path(cr);

    return found;
}


/* GObject interface */
/* ************************************************************************* */
static void
renderer_shape_finalize (GObject *object)
{
    /* TODO: Add deinitalization code here */
    RendererShape *shape = RENDERER_SHAPE(object);
    if (shape->fill)
        g_object_unref(shape->fill);
    if (shape->stroke)
        g_object_unref(shape->stroke);
    if (shape->path)
        g_object_unref(shape->path);

    G_OBJECT_CLASS (renderer_shape_parent_class)->finalize (object);
}

static void
renderer_shape_init (RendererShape *shape)
{
    RendererObject* object = RENDERER_OBJECT(shape);

    shape->stroke = NULL;
    shape->fill   = NULL;
    shape->path   = NULL;
}

static void
renderer_shape_class_init (RendererShapeClass *klass)
{
    GObjectClass*        gobject_class = G_OBJECT_CLASS (klass);
    RendererObjectClass* object_class   = RENDERER_OBJECT_CLASS (klass);
//    RendererItemClass*   item_class     = RENDERER_ITEM_CLASS (klass);


    object_class->draw             = renderer_shape_draw;
    object_class->bounding_box     = renderer_shape_bounding_box;

    object_class->hit_test         = renderer_shape_hit_test;
/*
    object_class->get_bounding_box_approximate = renderer_shape_get_bounding_box_approximate;

    object_class->update           = renderer_shape_update;

*/
    gobject_class->finalize     = renderer_shape_finalize;
/*
    gobject_class->set_property = renderer_shape_set_property;
    gobject_class->get_property = renderer_shape_get_property;

    renderer_shape_properties[PROPERTY_PATH] =
      g_param_spec_pointer ("path",
                            "Path",
                            "Set/Get path",
                            G_PARAM_CONSTRUCT | G_PARAM_READABLE | G_PARAM_WRITABLE);

    g_object_class_install_properties (gobject_class,
                                       PROPERTIES_LENGTH,
                                       renderer_shape_properties);
*/
}

RendererShape*
renderer_shape_new (RendererScene *scene, gchar *name)
{
    RendererShape* shape = g_object_new(RENDERER_TYPE_SHAPE, NULL);
    RendererObject* object = RENDERER_OBJECT(shape);
    if (name)
        object->name = g_strdup(name);
    object->scene = scene;
    return shape;
}

void
renderer_shape_set_path (RendererShape *shape, GraphicsPath *path)
{
    g_object_ref(path);
    if (shape->path)
        g_object_unref(shape->path);
    shape->path = path;
}
GraphicsPath *
renderer_shape_get_path(RendererShape *shape)
{
    if (shape->path==NULL)
        shape->path = graphics_path_new();

    return shape->path;
}


void
renderer_shape_set_fill (RendererShape *shape, GraphicsFill *fill)
{
    if (shape->fill)
        g_object_unref(shape->fill);
    shape->fill = fill;
}
GraphicsFill *
renderer_shape_get_fill(RendererShape *shape)
{
    if (!shape->fill)
        shape->fill = graphics_fill_new();

    return shape->fill;
}

void
renderer_shape_set_stroke (RendererShape *shape, GraphicsStroke *stroke)
{
    if (shape->stroke)
        g_object_unref(shape->stroke);
    shape->stroke = stroke;
}
GraphicsStroke *
renderer_shape_get_stroke(RendererShape *shape)
{
    if (!shape->stroke)
        shape->stroke = graphics_stroke_new();

    return shape->stroke;
}
