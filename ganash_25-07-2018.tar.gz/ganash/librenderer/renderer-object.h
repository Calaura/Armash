/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
 * Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _RENDERER_OBJECT_H_
#define _RENDERER_OBJECT_H_

/*
#include "libgeom/geom-box.h"

#include "renderer-hit-test-request.h"
#include "renderer-hit-test-result.h"

#include <glib-object.h>
#include <cairo/cairo.h>
*/


G_BEGIN_DECLS

/* see types.h
typedef enum _RendererStatus
{
    RENDERER_STATUS_UPDATE   = 0b00,// L'element est a jour
    RENDERER_STATUS_MODIFIED = 0b01,// L'element a été modifié
    RENDERER_STATUS_EXPIRED  = 0b10,// L'element n'a pas été modifier mais son contenu oui
    RENDERER_STATUS_UNKNOW   = 0b11 //
} RendererStatus;*/

typedef enum _RendererShift
{
    RENDERER_SHAPE_SHIFT           = 0,
    RENDERER_TRANSFORM_SHIFT       = 2,
    RENDERER_STYLE_SHIFT           = 4
} RendererShift;

#define renderer_is_update(elt) (elt->status_update == RENDERER_STATUS_UPDATE)
#define renderer_get_status(elt, var)      ((elt->status_update & RENDERER_##var##_MASK) >> RENDERER_##var##_SHIFT)
#define renderer_set_status(elt, var, val) \
    elt->status_update &= ~RENDERER_##var##_MASK; \
    elt->status_update |= RENDERER_STATUS_##val << RENDERER_##var##_SHIFT


#define RENDERER_TYPE_OBJECT             (renderer_object_get_type ())
#define RENDERER_OBJECT(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), RENDERER_TYPE_OBJECT, RendererObject))
#define RENDERER_OBJECT_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), RENDERER_TYPE_OBJECT, RendererObjectClass))
#define RENDERER_IS_OBJECT(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), RENDERER_TYPE_OBJECT))
#define RENDERER_IS_OBJECT_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), RENDERER_TYPE_OBJECT))
#define RENDERER_OBJECT_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), RENDERER_TYPE_OBJECT, RendererObjectClass))

typedef struct _RendererObjectClass RendererObjectClass;



struct _RendererObjectClass
{
	GObjectClass parent_class;

    /* debugable interface */
    gchar*                  (* dump)             (LogDump* object, LogDumpOptions *options);

    /* interactivable interface */
    gboolean                (* hit_test)         (RendererObject* object, cairo_t *cr, RendererHitTestRequest *request, RendererHitTestResult *result);
    /* locatable interface */
    RendererBox*            (* bounding_box)     (RendererObject* object, cairo_t *cr, RendererBoundingMode mode);
    /* transformable interface */
    void                    (* notify_transform) (RendererObject* object);

    /* stylable interface */

    /* drawable interface */
    gboolean                (* draw)             (RendererObject* object, cairo_t *cr);


    /* Signals */
    gboolean(* enter_notify_event)   (RendererObject *self, RendererEvent* event);
    gboolean(* leave_notify_event)   (RendererObject *self, RendererEvent* event);
    gboolean(* motion_notify_event)  (RendererObject *self, RendererEvent* event);
    gboolean(* button_press_event)   (RendererObject *self, RendererEvent* event);
    gboolean(* button_release_event) (RendererObject *self, RendererEvent* event);

};

struct _RendererObject
{
	GObject parent_instance;

    /* public */
    gpointer data;  /* data application */
    char    *name;
    gint     index;

    RendererContainer *parent;
    RendererScene     *scene;

    gboolean sensitive;
    gboolean visible;
    gboolean wired;

    gdouble opacity;

    RendererObject *mask;
    RendererObject *clip;

    cairo_matrix_t  transform;
    gboolean        transform_is_identity;

    //guint           status_update; not used
    RendererCache   cache;
};

GType              renderer_object_get_type (void) G_GNUC_CONST;
RendererObject    *renderer_object_new (RendererScene *scene, gchar* name);

gchar             *renderer_object_dump (LogDump *object, LogDumpOptions *options);

gboolean           renderer_object_draw (RendererObject* object, cairo_t *cr/*, GdkRectangle area*/);

RendererBox       *renderer_object_bounding_box (RendererObject* object, cairo_t *cr, RendererBoundingMode mode);
void               renderer_object_get_transform_abs (RendererObject* object, cairo_matrix_t *matrix);
cairo_matrix_t    *renderer_object_transform (RendererObject* object);
void               renderer_object_get_transform (RendererObject* object, cairo_matrix_t *matrix);
void               renderer_object_set_transform(RendererObject* object, cairo_matrix_t *matrix);
void               renderer_object_translate(RendererObject* object, gdouble tx, gdouble ty);
void               renderer_object_notify_transform(RendererObject *object);

gboolean           renderer_object_hit_test(RendererObject *object, cairo_t *cr, RendererHitTestRequest *request, RendererHitTestResult *result);


gchar   *renderer_matrix_debug(cairo_matrix_t *matrix);
gboolean renderer_matrix_is_identity(cairo_matrix_t *matrix);


void renderer_object_set_visible(RendererObject *object, gboolean visible);
/*
void     renderer_object_set_sensitive(RendererObject* object, gboolean sensitive);
gboolean renderer_object_get_sensitive(RendererObject* object);
void     renderer_object_set_visible(RendererObject* object, gboolean visible);
gboolean renderer_object_get_visible(RendererObject* object);
void     renderer_object_set_wired(RendererObject* object, gboolean wire);
gboolean renderer_object_get_wired(RendererObject* object);

void renderer_item_set_sensitive(RendererItem* object, gboolean sensitive)
{
    object->sensitive = sensitive;
}
gboolean renderer_item_get_sensitive(RendererItem* object)
{
    return object->sensitive;
}

void renderer_item_set_visible(RendererItem* object, gboolean visible)
{
    object->visible = visible;
}
gboolean renderer_item_get_visible(RendererItem* object)
{
    return object->visible;
}

void renderer_item_set_wired(RendererItem* object, gboolean wired)
{
    object->wired = wired;
}
gboolean renderer_item_get_wired(RendererItem* object)
{
    return object->wired;
}
*/

G_END_DECLS

#endif /* _RENDERER_OBJECT_H_ */
