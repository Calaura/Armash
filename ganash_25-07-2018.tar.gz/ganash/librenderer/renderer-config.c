/*
 * renderer-config.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "renderer-config.h"


static void renderer_config_class_init(RendererConfigClass *klass);
static void renderer_config_init(RendererConfig *gobject);

G_DEFINE_TYPE (RendererConfig, renderer_config, G_TYPE_OBJECT)

static void
renderer_config_class_init(RendererConfigClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//    renderer_config_parent_class = g_type_class_peek_parent (klass);
}

static void
renderer_config_init (RendererConfig *object)
{
    RendererConfigPrivate *priv = RENDERER_CONFIG_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

RendererConfig *
renderer_config_new (void)
{
    return g_object_new (renderer_config_get_type (),
	                     NULL);
}

