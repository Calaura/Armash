/*
 * renderer-graphics.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <libgraphics/graphics.h>

#include "renderer-graphics.h"


void renderer_graphics_path(GraphicsPath* path, cairo_t* cr)
{
    cairo_append_path(cr, (cairo_path_t*) path);
}

void renderer_graphics_stroke(GraphicsStroke* stroke, cairo_t* cr)
{
    cairo_set_line_width(cr, stroke->width);
    cairo_set_line_cap(cr, stroke->cap);
    cairo_set_line_join(cr, stroke->join);
    cairo_set_miter_limit(cr, stroke->miter_limit);
    /*TODO dash line*/

    GRAPHICS_PAINTER_GET_INTERFACE (stroke->painter)->to_cairo (stroke->painter, cr);
}

void renderer_graphics_fill(GraphicsFill* fill, cairo_t* cr)
{
    GRAPHICS_PAINTER_GET_INTERFACE (fill->painter)->to_cairo (fill->painter, cr);
}
