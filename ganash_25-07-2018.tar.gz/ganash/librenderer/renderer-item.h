/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _RENDERER_ITEM_H_
#define _RENDERER_ITEM_H_

#include <glib-object.h>

G_BEGIN_DECLS

#define RENDERER_TYPE_ITEM             (renderer_item_get_type ())
#define RENDERER_ITEM(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), RENDERER_TYPE_ITEM, RendererItem))
#define RENDERER_ITEM_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), RENDERER_TYPE_ITEM, RendererItemClass))
#define RENDERER_IS_ITEM(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), RENDERER_TYPE_ITEM))
#define RENDERER_IS_ITEM_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), RENDERER_TYPE_ITEM))
#define RENDERER_ITEM_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), RENDERER_TYPE_ITEM, RendererItemClass))

typedef struct _RendererItemClass RendererItemClass;

typedef struct _RendererItemCache {
    int foo;
} RendererItemCache;

struct _RendererItem
{
	RendererObject parent_instance;

    RendererObject *parent;
    RendererScene  *scene;
};

struct _RendererItemClass
{
    RendererObjectClass parent_class;

    /* interactivable interface */
    //RendererHitTestResult   (* hit_test)      (RendererObject* object, cairo_t *cr, const RendererHitTestRequest *request);
    /* stylable interface */
    /* locatable interface */
    //cairo_rectangle_t*      (* bounding_box)  (RendererObject* object, cairo_t *cr/*mode*/);
    /* transformable interface */
    /* drawable interface */
    /*gboolean                (* draw)          (RendererItem* object, cairo_t *cr);*/

};

GType    renderer_item_get_type    (void) G_GNUC_CONST;
RendererItem *renderer_item_new    (gchar* name);


G_END_DECLS

#endif /* _RENDERER_ITEM_H_ */
