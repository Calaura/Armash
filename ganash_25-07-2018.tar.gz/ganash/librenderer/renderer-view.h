/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
 * Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _RENDERER_VIEW_H_
#define _RENDERER_VIEW_H_


#include <glib-object.h>


G_BEGIN_DECLS

#define RENDERER_TYPE_VIEW             (renderer_view_get_type ())
#define RENDERER_VIEW(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), RENDERER_TYPE_VIEW, RendererView))
#define RENDERER_VIEW_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), RENDERER_TYPE_VIEW, RendererViewClass))
#define RENDERER_IS_VIEW(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), RENDERER_TYPE_VIEW))
#define RENDERER_IS_VIEW_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), RENDERER_TYPE_VIEW))
#define RENDERER_VIEW_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), RENDERER_TYPE_VIEW, RendererViewClass))

typedef struct _RendererViewClass RendererViewClass;


struct _RendererView
{
    GObject parent_instance;

    cairo_surface_t *work_surface;
    cairo_t         *work_context;

    //GraphicsFill    *background;

    RendererScene   *scene;

    gboolean           snap_to_guides;   /*  should the guides be snapped to?   */
    gboolean           snap_to_grid;     /*  should the grid be snapped to?     */
    gboolean           snap_to_canvas;   /*  should the canvas be snapped to?   */
    gboolean           snap_to_vectors;  /*  should the active path be snapped  */

    /*GimpUnit           unit;*/

    gint               offset_x;         /*  offset of display image            */
    gint               offset_y;

    gdouble            scale_x;          /*  horizontal scale factor            */
    gdouble            scale_y;          /*  vertical scale factor              */

    gdouble            rotate;           /*  horizontal scale factor            */

};

struct _RendererViewClass
{
    GObjectClass parent_class;
};

GType renderer_view_get_type (void) G_GNUC_CONST;
RendererView *renderer_view_new(void);



void                   renderer_view_set_scene(RendererView* view, RendererScene* scene);
void                   renderer_view_to_context(RendererView *view, cairo_t *cr);
gboolean               renderer_view_hit_test(RendererView *view, RendererObject *target, RendererHitTestRequest *request, RendererHitTestResult *result);
RendererBox           *renderer_view_bounding_box(RendererView* view, RendererBoundingMode mode);


/*void  renderer_view_set_window(RendererView* view, GdkWindow* window);*/
/*#define renderer_view_set_window(view, drawable) view->window = drawable;*/


G_END_DECLS

#endif /* _RENDERER_VIEW_H_ */
