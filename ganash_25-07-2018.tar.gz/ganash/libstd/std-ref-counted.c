/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * std-ref-counted.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "std-ref-counted.h"


static void std_ref_counted_class_init(StdRefCountedClass *klass);
static void std_ref_counted_init(StdRefCounted *gobject);

G_DEFINE_TYPE (StdRefCounted, std_ref_counted, G_TYPE_OBJECT)

static void
std_ref_counted_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (std_ref_counted_parent_class)->finalize (object);
}
static void
std_ref_counted_class_init(StdRefCountedClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = std_ref_counted_finalize;

//	std_ref_counted_parent_class = g_type_class_peek_parent (klass);
}

static void
std_ref_counted_init (StdRefCounted *object)
{
}

StdRefCounted *
std_ref_counted_new (gpointer data)
{
    StdRefCounted *ref = g_object_new (std_ref_counted_get_type (), NULL);
    ref->data = data;
    return ref;
}

