/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * std-unique-ptr.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __STD_UNIQUE_PTR_H__
#define __STD_UNIQUE_PTR_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define STD_UNIQUE_PTR_TYPE(T)         struct {T *ptr;}
#define STD_UNIQUE_PTR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), std_unique_ptr_get_type(), StdUniquePtr))
#define STD_UNIQUE_PTR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), std_unique_ptr_get_type(), StdUniquePtrClass))
#define STD_IS_UNIQUE_PTR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), std_unique_ptr_get_type()))
#define STD_IS_UNIQUE_PTR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), std_unique_ptr_get_type()))
#define STD_UNIQUE_PTR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), std_unique_ptr_get_type(), StdUniquePtrClass))

typedef struct _StdUniquePtr StdUniquePtr;
typedef struct _StdUniquePtrClass StdUniquePtrClass;

struct _StdUniquePtr {
	GObject parent_instance;
};

struct _StdUniquePtrClass {
	GObjectClass parent_class;
};

GType std_unique_ptr_get_type();
StdUniquePtr *std_unique_ptr_new(void);
void          std_unique_ptr_free(StdUniquePtr *ptr);


G_END_DECLS

#endif /* __STD_UNIQUE_PTR_H__ */

