/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * std-ref-counted.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __STD_REF_COUNTED_H__
#define __STD_REF_COUNTED_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define STD_TYPE_REF_COUNTED            (std_ref_counted_get_type())
#define STD_REF_COUNTED(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), STD_TYPE_REF_COUNTED, StdRefCounted))
#define STD_REF_COUNTED_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), STD_TYPE_REF_COUNTED, StdRefCountedClass))
#define STD_IS_REF_COUNTED(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), STD_TYPE_REF_COUNTED))
#define STD_IS_REF_COUNTED_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), STD_TYPE_REF_COUNTED))
#define STD_REF_COUNTED_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), STD_TYPE_REF_COUNTED, StdRefCountedClass))

typedef struct _StdRefCounted StdRefCounted;
typedef struct _StdRefCountedClass StdRefCountedClass;

struct _StdRefCounted {
	GObject parent_instance;
    /*< public >*/
    gpointer data;
};

struct _StdRefCountedClass {
	GObjectClass parent_class;
};

GType std_ref_counted_get_type();
StdRefCounted *std_ref_counted_new(gpointer data);

G_END_DECLS

#endif /* __STD_REF_COUNTED_H__ */

