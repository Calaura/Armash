/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * std-ref.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "std-ref.h"


static void std_ref_class_init(StdRefClass *klass);
static void std_ref_init(StdRef *gobject);

G_DEFINE_TYPE (StdRef, std_ref, G_TYPE_OBJECT)

static void
std_ref_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (std_ref_parent_class)->finalize (object);
}
static void
std_ref_class_init(StdRefClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = std_ref_finalize;

//	std_ref_parent_class = g_type_class_peek_parent (klass);
}

static void
std_ref_init (StdRef *object)
{
}

StdRef *
std_ref_new (void)
{
	return g_object_new (std_ref_get_type (),
	                     NULL);
}

