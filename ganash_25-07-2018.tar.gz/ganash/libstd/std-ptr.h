/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * std-ptr.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __STD_PTR_H__
#define __STD_PTR_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define STD_TYPE_PTR            (std_ptr_get_type())
#define STD_PTR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), STD_TYPE_PTR, StdPtr))
#define STD_PTR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), STD_TYPE_PTR, StdPtrClass))
#define STD_IS_PTR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), STD_TYPE_PTR))
#define STD_IS_PTR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), STD_TYPE_PTR))
#define STD_PTR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), STD_TYPE_PTR, StdPtrClass))

typedef struct _StdPtr StdPtr;
typedef struct _StdPtrClass StdPtrClass;

struct _StdPtr {
	GObject parent_instance;
};

struct _StdPtrClass {
	GObjectClass parent_class;
};

GType std_ptr_get_type();
StdPtr *std_ptr_new();

G_END_DECLS

#endif /* __STD_PTR_H__ */

