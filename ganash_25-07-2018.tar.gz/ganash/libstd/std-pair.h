/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * std-pair.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __STD_PAIR_H__
#define __STD_PAIR_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define STD_TYPE_PAIR(T1, T2)    (struct { T1 first; T2 second;})
#define STD_PAIR_INIT            {0, 0}

#define STD_PAIR_DEFINE          (struct { T1 first; T2 second;})
//#define DEFINE_STD_PAIR(T1, T2)  (struct { T1 first; T2 second;})
//#define D_STD_PAIR(T1, T2)  (struct { T1 first; T2 second;})

#define STD_PAIR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), std_pair_get_type(), StdPair))
#define STD_PAIR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), std_pair_get_type(), StdPairClass))
#define STD_IS_PAIR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), std_pair_get_type()))
#define STD_IS_PAIR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), std_pair_get_type()))
#define STD_PAIR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), std_pair_get_type(), StdPairClass))

typedef struct _StdPair StdPair;
typedef struct _StdPairClass StdPairClass;

struct _StdPair {
    int first;// key
    int second;// value
};

#define DOM_DOCUMENT_TRAIT_STD_FOREACH(item, collection)
#define STD_FOREACH_DOM_DOCUMENT(item, collection)
#define STD_FOREACH_DOM_NODE(item, collection)
#define STD_FOREACH_DOM_ELEMENT(item, collection)
#define STD_FOREACH_ARRAY(item, collection)
#define STD_FOREACH_SLIST(item, collection)
#define STD_FOREACH_LIST(item, collection)
#define STD_FOREACH_VECTOR(item, collection)

#define STD_FOREACH(item, collection) { \
    std_foreach_vector() \
}

struct _StdPair {
    GObject parent_instance;

};

struct _StdPairClass {
	GObjectClass parent_class;
};

GType std_pair_get_type();
StdPair *std_pair_new();

G_END_DECLS

#endif /* __STD_PAIR_H__ */

