/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-enums-tags.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_ENUMS_TAGS_H__
#define __SVG_ENUMS_TAGS_H__



G_BEGIN_DECLS

#define SVG_ENUMS_TYPE_TAGS            (svg_enums_tags_get_type())
#define SVG_ENUMS_TAGS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_ENUMS_TYPE_TAGS, SVGEnumsTags))
#define SVG_ENUMS_TAGS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_ENUMS_TYPE_TAGS, SVGEnumsTagsClass))
#define SVG_ENUMS_IS_TAGS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_ENUMS_TYPE_TAGS))
#define SVG_ENUMS_IS_TAGS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_ENUMS_TYPE_TAGS))
#define SVG_ENUMS_TAGS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_ENUMS_TYPE_TAGS, SVGEnumsTagsClass))

typedef struct _SVGEnumsTags SVGEnumsTags;
typedef struct _SVGEnumsTagsClass SVGEnumsTagsClass;

struct _SVGEnumsTags {
	GObject parent_instance;
};

struct _SVGEnumsTagsClass {
	GObjectClass parent_class;
};

GType svg_enums_tags_get_type();
SVGEnumsTags *svg_enums_tags_new();

G_END_DECLS

#endif /* __SVG_ENUMS_TAGS_H__ */

