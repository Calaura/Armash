/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-time-container.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "svg-types.h"
#include <liblog/log.h>
#include <libgraphics/graphics.h>
#include <librenderer/renderer.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "libdom/dom.h"

#include "svg-enums.h"
#include "svg-element.h"
#include "svg-time.h"
#include "svg-time-container.h"
#include "svg-element-animation.h"
#include "svg-document.h"


static void svg_time_container_class_init(SvgTimeContainerClass *klass);
static void svg_time_container_init(SvgTimeContainer *gobject);

G_DEFINE_TYPE (SvgTimeContainer, svg_time_container, G_TYPE_OBJECT)

static void
svg_time_container_finalize(GObject *object)
{
    SvgTimeContainer *container = SVG_TIME_CONTAINER(object);
	/* TODO: Add deinitalization code here */
    g_array_free(container->active_animations, FALSE);

	G_OBJECT_CLASS (svg_time_container_parent_class)->finalize (object);
}
static void
svg_time_container_class_init(SvgTimeContainerClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = svg_time_container_finalize;

//	svg_time_container_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_time_container_init (SvgTimeContainer *object)
{
    object->document = NULL;
    //object->active_animations = g_array_new(FALSE, FALSE, sizeof(SvgElementAnimation*));
    //FIXME: linearize scheduled_animations = [1,2,3,4,NULL,5,6,7,8,9,10,NULL]
    object->scheduled_animations = g_array_new(FALSE, FALSE, sizeof(SvgSchedule*));

    object->pause_time = 0;
}

SvgTimeContainer *
svg_time_container_new (SvgDocument *document)
{
    SvgTimeContainer *container = g_object_new (SVG_TYPE_TIME_CONTAINER, NULL);
    container->document = document;

    return container;
}

gboolean
svg_time_container_is_paused(SvgTimeContainer *container)
{
    return container->pause_time;
}

void
svg_time_container_elapsed(SvgTimeContainer *container, SvgTime*elapsed)
{
    if (!container->begin_time)
        elapsed->seconds = 0.0;
    else if (svg_time_container_is_paused(container))
        elapsed->seconds = container->accumulated_active_time;
    else
        elapsed->seconds = /*monotonicallyIncreasingTime()*/1.0 + container->accumulated_active_time - container->resume_time;
}

void
svg_time_container_set_elapsed(SvgTimeContainer *container, SvgTime*elapsed)
{
}

SvgTime* /*Ref<>, Garbage<>*/
svg_time_container_get_elapsed(SvgTimeContainer *container)
{
    return NULL;
}

void
svg_time_container_update_animations(SvgTimeContainer *time_container,
                                     SvgTime *elapsed, gboolean seek_to_time)
{
    SvgTime earliestFireTime = SVG_TIME_UNRESOLVED;

    // when searching, push the time where schedule need computed

    //typedef GArray* AnimationsVector;
    //AnimationsVector animationsToApply;// container->active_animations
    GArray* animationsToApply = g_array_new(FALSE, FALSE, sizeof(SvgElementAnimation*));

    guint i;
    guint len = time_container->scheduled_animations->len;
    for (i=0; i<len; i++) {
        SvgSchedule *scheduled = g_array_index(time_container->scheduled_animations, SvgSchedule*, i);

        //sortByPriority(*scheduled, elapsed);

        SvgElementAnimation* result_element = 0;
        guint n;
        guint size = g_slist_length(scheduled->animations);
        for (n = 0; n < size; n++) {
            SvgElementAnimation* animation = g_slist_nth_data(scheduled->animations, n);
            g_assert(animation->time_container == time_container);
            g_assert(animation->target);
//            ASSERT(animation->hasValidAttributeName());

            // Results are accumulated to the first animation that animates
            // and contributes to a particular element/attribute pair.
            if (!result_element) {
//                if (!animation->hasValidAttributeType())
//                    continue;
                result_element = animation;
            }

            // This will calculate the contribution from the animation and add it to the resultsElement.
            // parse dur : ok, parse end TODO
            // t'en est a : percentage ... end_times; puis svg_element_animation_repeating_duration
            if (!svg_element_animation_progress(animation, elapsed, SVG_ELEMENT(result_element), seek_to_time)
              && result_element == animation
            ) {
                result_element = 0;
            }

            // finding the current interval
//            SMILTime nextFireTime = animation->nextProgressTime();
//            if (nextFireTime.isFinite())
//                earliestFireTime = min(nextFireTime, earliestFireTime);
        }

        if (result_element)
            animationsToApply = g_array_append_val(animationsToApply, result_element);
            //animationsToApply.append(result_element);
    }

    unsigned animationsToApplySize = animationsToApply->len;

    // Apply results to target elements.
    for (i = 0; i < animationsToApplySize; ++i) {
        SvgElementAnimation *animation = g_array_index(animationsToApply, SvgElementAnimation*, i);
        svg_element_animation_apply_results_to_target(animation);
    }

    g_array_free(animationsToApply, FALSE);
}

/*

void SMILTimeContainer::updateAnimations(SMILTime elapsed, bool seekToTime)
{
    SMILTime earliestFireTime = SMILTime::unresolved();

#ifndef NDEBUG
    // This boolean will catch any attempts to schedule/unschedule scheduledAnimations during this critical section.
    // Similarly, any elements removed will unschedule themselves, so this will catch modification of animationsToApply.
    m_preventScheduledAnimationsChanges = true;
#endif

    AnimationsVector animationsToApply;
    GroupedAnimationsMap::iterator end = m_scheduledAnimations.end();
    for (GroupedAnimationsMap::iterator it = m_scheduledAnimations.begin(); it != end; ++it) {
        AnimationsVector* scheduled = it->value;

        // Sort according to priority. Elements with later begin time have higher priority.
        // In case of a tie, document order decides.
        // FIXME: This should also consider timing relationships between the elements. Dependents
        // have higher priority.
        sortByPriority(*scheduled, elapsed);

        SVGSMILElement* resultElement = 0;
        unsigned size = scheduled->size();
        for (unsigned n = 0; n < size; n++) {
            SVGSMILElement* animation = scheduled->at(n);
            ASSERT(animation->timeContainer() == this);
            ASSERT(animation->targetElement());
            ASSERT(animation->hasValidAttributeName());

            // Results are accumulated to the first animation that animates and contributes to a particular element/attribute pair.
            if (!resultElement) {
                if (!animation->hasValidAttributeType())
                    continue;
                resultElement = animation;
            }

            // This will calculate the contribution from the animation and add it to the resultsElement.
            if (!animation->progress(elapsed, resultElement, seekToTime) && resultElement == animation)
                resultElement = 0;

            SMILTime nextFireTime = animation->nextProgressTime();
            if (nextFireTime.isFinite())
                earliestFireTime = min(nextFireTime, earliestFireTime);
        }

        if (resultElement)
            animationsToApply.append(resultElement);
    }

    unsigned animationsToApplySize = animationsToApply.size();
    if (!animationsToApplySize) {
#ifndef NDEBUG
        m_preventScheduledAnimationsChanges = false;
#endif
        startTimer(earliestFireTime, animationFrameDelay);
        return;
    }

    // Apply results to target elements.
    for (unsigned i = 0; i < animationsToApplySize; ++i)
        animationsToApply[i]->applyResultsToTarget();

#ifndef NDEBUG
    m_preventScheduledAnimationsChanges = false;
#endif

    startTimer(earliestFireTime, animationFrameDelay);
    Document::updateStyleForAllDocuments();
}

*/


static SvgSchedule*
svg_time_container_get_schedule(SvgTimeContainer *container,
                                SvgElement *target,
                                DomQualifiedName *attribute)
{
    SvgSchedule *scheduled;
    GArray *scheduled_animations = container->scheduled_animations;
    g_assert(scheduled_animations);

    int i;
    int len = scheduled_animations->len;
    for( i=0; i<len; i++ )
    {
        scheduled = g_array_index(scheduled_animations, SvgSchedule*, i);

        // private: dom_document_get_next_instance_id(target->name());
        // dom_element_get_id();// xml:id="rect368"
        // id_instance = dom_element_get_instance_id(target);
        // id_attribute = ??? attribute
        if (scheduled->target == SVG_ELEMENT(target)
         && dom_qualified_name_equ(&scheduled->attribute, attribute)
        ) {
            return scheduled;
        }
    }

    // Lazy load
    {
        scheduled = g_new(SvgSchedule, 1);
        scheduled->target = target;
        scheduled->animations = NULL;
        scheduled->attribute = *attribute;//FIXME: int dom_qualified_name_hash()
                                          // use struct int:4;

        container->scheduled_animations = g_array_append_val(
                    scheduled_animations, scheduled);






        /*
        GType = svg_document_get_type();
        GType = svg_element_get_type();
        GType = svg_attribute_get_type();

        ### int = svg_document_get_code();
        int = svg_element_get_code();   <-use-> dom_document_get_element_code(doc, elt);
        int = svg_attribute_get_code(); <-use-> dom_element_get_attribute_code();

        ### DomQualifiedName = svg_document_get_qualified_name();// image/svg+xml
        DomQualifiedName = svg_element_get_qualified_name(elt); <-use-> dom_document_get();
        DomQualifiedName = svg_attribute_get_qualified_name(); <-use-> by GType

        */


        // hash = g_hash_table_insert(hash, 0x000368, GList*);
        // hash = g_hash_table_insert(hash, "Virginia", "Richmond");
        //
        // unsigned int tag_id = dom_document_get_tag_id(document);
        // unsigned int tag_id_mask = 0x00FF = dom_document_get_tag_id_mask(document);
        // GHashTable *tag_ids = svg_document_get_tag_ids(document);
        // int id = g_hash_table_lookup(tag_ids, "svg:rect");
        // int id = dom_element_get_attribute_name(tag_ids, "svg:rect");// xml:id
        // int id = dom_element_get_attribute_id(tag_ids, "svg:rect");// xml:id
        // int id = dom_document_lookup("svg:rect");
        // int id = dom_document_lookup(SVG_TYPE_ELEMENT_RECT);
        //
//        GHashTable *names = dom_document_get_tag_names(document);
//        GType type = g_hash_table_lookup(names, tag_name);

//        GType type = dom_document_tag_type_lookup(doc, "svg:rect");
//        int     id = dom_document_tag_id_lookup(doc, "svg:rect");

        // int = dom_document_get_element_code(doc, GType)
        // int = dom_document_get_element_code(doc, GType)
        // GType            = dom_element_get_type(elt)
        // DomQualifiedName = dom_element_get_qualified_name(elt)
        //
        // SVG_TYPE_LENGTH      = dom_element_get_attribute_type(DOM_QUALIFIED_NAME("svg", "stroke-width"))
        // int code:8           = dom_element_get_attribute_code(DOM_QUALIFIED_NAME("svg", "stroke-width"))
        // char* "stroke-width" = dom_element_get_attribute_name()

        // char* "stroke-width" = dom_node_get_name()
        // char* "stroke-width" = dom_node_get_type()
        // char* "stroke-width" = dom_node_get_code()

        // tag_id = document->getTagId(target);
        // attr_id = target->getAttributeId(attribute);
        // instance_id = target->getInstanceId();
    }

    return scheduled;
}

void
svg_time_container_schedule(SvgTimeContainer *container,
                            SvgElementAnimation *animation, SvgElement *target,
                            DomQualifiedName *attribute)
{
    /**
     * @param scheduled The scheduler of SvgElementAnimation
     */
    SvgSchedule *scheduled = svg_time_container_get_schedule(container,
                                                             target,
                                                             attribute);
    // TODO assert !g_slist_find(scheduled->animations, animation);
    scheduled->animations = g_slist_append(scheduled->animations, animation);

    // attache time_container to Animation
    animation->time_container = SVG_DOCUMENT(dom_node_get_document(DOM_NODE(target)))->time_container;
}


/*
void SMILTimeContainer::schedule(SVGSMILElement* animation, SVGElement* target, const QualifiedName& attributeName)
{
    ASSERT(animation->timeContainer() == this);
    ASSERT(target);
    ASSERT(animation->hasValidAttributeName());

#ifndef NDEBUG
    ASSERT(!m_preventScheduledAnimationsChanges);
#endif

    ElementAttributePair key(target, attributeName);
    AnimationsVector* scheduled = m_scheduledAnimations.get(key);
    if (!scheduled) {
        scheduled = new AnimationsVector();
        m_scheduledAnimations.set(key, scheduled);
    }
    ASSERT(!scheduled->contains(animation));
    scheduled->append(animation);

    SMILTime nextFireTime = animation->nextProgressTime();
    if (nextFireTime.isFinite())
        notifyIntervalsChanged();
}
*/
