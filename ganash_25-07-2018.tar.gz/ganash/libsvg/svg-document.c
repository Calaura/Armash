/*
 * svg-document.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>
#include <libgraphics/graphics.h>

#include <liblog/log.h>


//#include <librenderer/renderer.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"

#include <libdom/dom.h>
#include <libdom/dom-parser.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-length.h"
#include "libsvg/svg-number.h"
#include <cairo/cairo.h>
#include "libsvg/svg-matrix.h"
#include "libsvg/svg-transform.h"
#include "libsvg/svg-transform-list.h"
#include "libsvg/svg-color.h"
#include "libsvg/svg-paint.h"
#include "libsvg/svg-time.h"
#include "libsvg/svg-drawable.h"
#include "libsvg/svg-hit-request.h"
#include "libsvg/svg-hit-result.h"
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-updater.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-animated-type-animator.h"
#include "libsvg/properties/svg-animated-property.h"
#include "libsvg/properties/svg-property-info.h"
#include "libsvg/svg-animated-type.h"
#include "libsvg/svg-element-animation.h"
#include "libsvg/svg-element-animate.h"
#include "libsvg/svg-element-animate-color.h"
#include "libsvg/svg-element-defs.h"
#include "libsvg/svg-element-solid-color.h"
#include "libsvg/svg-element-stop.h"
#include "libsvg/svg-element-gradient.h"
#include "libsvg/svg-element-gradient-linear.h"
#include "libsvg/svg-element-gradient-mesh.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-g.h"
#include "libsvg/svg-element-use.h"
#include "libsvg/svg-element-symbol.h"
#include "libsvg/svg-element-rect.h"
#include "libsvg/svg-element-path.h"
#include "libsvg/svg-element-svg.h"
#include "libsvg/svg-time-container.h"
#include "libsvg/svg-document.h"


static GType svg_tag_type_lookup (const guchar * name);


static void svg_document_drawable_interface_init(SvgDrawableInterface *iface);
static void svg_document_class_init(SvgDocumentClass *klass);
static void svg_document_init(SvgDocument *gobject);

/*drawable interface */
static void svg_document_drawable_draw(SvgDrawable *element, cairo_t *cr);

static void              svg_document_log_interface_init (LogDumpInterface *iface);
static LogDumpInterface *svg_document_log_parent_interface = NULL;

/*G_DEFINE_TYPE (SvgDocument, svg_document, G_TYPE_OBJECT)*/
G_DEFINE_TYPE_WITH_CODE (SvgDocument, svg_document, DOM_TYPE_DOCUMENT,
                         /*G_IMPLEMENT_INTERFACE (SVG_TYPE_STYLABLE,
                                                svg_element_rect_stylable_interface_init)*/
                         LOG_IMPLEMENT_INTERFACE_DUMP(svg_document_log_interface_init)
                         G_IMPLEMENT_INTERFACE (SVG_TYPE_DRAWABLE,
                                                svg_document_drawable_interface_init)
                         )


/* Debugger interface                                                         */
/* ************************************************************************** */
#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
static gchar*
svg_document_dump(DomDocument *document, LogDumpOptions *options)
{
#   define PLACE_HOLDER "%%s"
#   define TAB "%s"
#   define TYPE_NAME "%s"

    gchar *ind = g_strdup_printf(TAB""TAB, options->config->indent, "    ");

    gchar *content = svg_document_log_parent_interface->to_string(DOM_DOCUMENT(document), options);

    return content;
}

static void
svg_document_log_interface_init (LogDumpInterface *iface)
{
    svg_document_log_parent_interface = g_type_interface_peek_parent (iface);
    iface->to_string = svg_document_dump;
}
#endif

/* Dom interface                                                              */
/* ************************************************************************** */
static GHashTable* svg_tag_names = NULL;
GHashTable*
svg_document_get_tag_names(DomDocument *document)
{
    if (svg_tag_names) {
        return svg_tag_names;
    }

    svg_tag_names = g_hash_table_new (g_str_hash, g_str_equal);

    /*
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "a"),              GINT_TO_POINTER (SVG_TYPE_ANCHOR));
    */
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "animate"),        GINT_TO_POINTER (SVG_TYPE_ELEMENT_ANIMATE));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "animateColor"),   GINT_TO_POINTER (SVG_TYPE_ELEMENT_ANIMATE_COLOR));
    /*
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "arc"),            GINT_TO_POINTER (SVG_TYPE_ARC));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "circle"),         GINT_TO_POINTER (SVG_TYPE_CIRCLE));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "clipPath"),       GINT_TO_POINTER (SVG_TYPE_CLIPPATH));
    */
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "defs"),           GINT_TO_POINTER (SVG_TYPE_ELEMENT_DEFS));
    /*
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "ellipse"),        GINT_TO_POINTER (SVG_TYPE_ELLIPSE));
    */
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "g"),              GINT_TO_POINTER (SVG_TYPE_ELEMENT_G));
    /*
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "image"),          GINT_TO_POINTER (SVG_TYPE_IMAGE));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "line"),           GINT_TO_POINTER (SVG_TYPE_LINE));
    */
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "linearGradient"), GINT_TO_POINTER (SVG_TYPE_ELEMENT_GRADIENT_LINEAR));
    /*
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "mask"),           GINT_TO_POINTER (SVG_TYPE_MASK));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "marker"),         GINT_TO_POINTER (SVG_TYPE_MARKER));
    */
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "path"),           GINT_TO_POINTER (SVG_TYPE_ELEMENT_PATH));
    /*
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "pattern"),        GINT_TO_POINTER (SVG_TYPE_PATTERN));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "polygon"),        GINT_TO_POINTER (SVG_TYPE_POLYGON));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "polyline"),       GINT_TO_POINTER (SVG_TYPE_POLYLINE));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "radialGradient"), GINT_TO_POINTER (SVG_TYPE_RADIALGRADIENT));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "meshGradient"),   GINT_TO_POINTER (SVG_TYPE_ELEMENT_GRADIENT_MESH));
    */
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "rect"),           GINT_TO_POINTER (SVG_TYPE_ELEMENT_RECT));
    /*
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "spiral"),         GINT_TO_POINTER (SVG_TYPE_SPIRAL));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "star"),           GINT_TO_POINTER (SVG_TYPE_STAR));
    */
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "stop"),           GINT_TO_POINTER (SVG_TYPE_ELEMENT_STOP));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "svg"),            GINT_TO_POINTER (SVG_TYPE_ELEMENT_SVG));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "symbol"),         GINT_TO_POINTER (SVG_TYPE_ELEMENT_SYMBOL));
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "solidColor"),     GINT_TO_POINTER (SVG_TYPE_ELEMENT_SOLID_COLOR));
    /*
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "text"),           GINT_TO_POINTER (SVG_TYPE_TEXT));
    */
    g_hash_table_insert (svg_tag_names, DOM_TAG_NAME("svg", "use"),            GINT_TO_POINTER (SVG_TYPE_ELEMENT_USE));


    return svg_tag_names;
}

static DomQualifiedName svg_tag_root = {"svg", "svg"};

static void
svg_document_default_tag_root(DomQualifiedName *tag)
{
    tag->name   = g_strdup(svg_tag_root.name);
    tag->prefix = g_strdup(svg_tag_root.prefix);
}

static char *svg_default_namespace = "svg";
static void
svg_document_default_namespace(char **prefix)
{
    *prefix = svg_default_namespace;
}

static DomNamespace svg_default_namespaces[] = {
    {"http://www.w3.org/2000/xmlns/", {"xmlns", "svg"},   "http://www.w3.org/2000/svg"},
    {"http://www.w3.org/2000/xmlns/", {"xmlns", "xlink"}, "http://www.w3.org/2000/xlink"},
    NULL
};

static void
svg_document_default_namespaces(DomNamespace** namespaces)
{
    *namespaces = svg_default_namespaces;
}

void
svg_document_xml_new (SvgDocument *document)
{
    DomDocument *doc = DOM_DOCUMENT(document);
    xmlDoc  *xml_doc = doc->xml;

    dom_document_xml_new();

    /*
     * Creates a DTD declaration.
     */
    char *dtd_name = "svg";
    char *dtd_external_id = "-//W3C//DTD SVG 1.1//EN";
    char *dtd_system_id = "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd";
    xmlDtd *dtd = xmlCreateIntSubset(xml_doc, BAD_CAST dtd_name, BAD_CAST dtd_external_id, BAD_CAST dtd_system_id);

}

/* GObject interface                                                          */
/* ************************************************************************** */
static void
svg_document_class_init(SvgDocumentClass *klass)
{
    GObjectClass *gobject_class;
    DomDocumentClass *dom_class;

    gobject_class = (GObjectClass *) klass;
    dom_class     = (DomDocumentClass *) klass;

    dom_class->get_tag_names       = svg_document_get_tag_names;
    dom_class->tag_root            = svg_document_default_tag_root;
    dom_class->default_namespace   = svg_document_default_namespace;
    dom_class->default_namespaces  = svg_document_default_namespaces;

//    svg_document_parent_class = g_type_class_peek_parent (klass);
}


static void
svg_document_drawable_interface_init(SvgDrawableInterface *iface)
{
    iface->draw = svg_document_drawable_draw;
}

static void
svg_document_init (SvgDocument *document)
{
    //DomDocument *dom_doc = (DomDocument*)document;
    document->time = svg_time_new();
    document->time_container  = svg_time_container_new(document);
    document->instance_count = 0;

    //dom_doc->root = g_object_new(SVG_TYPE_ELEMENT_SVG, NULL);
    //DOM_NODE(dom_doc->root)->document = dom_doc;

    RendererScene *scene = renderer_scene_new("scene");
    document->view  = renderer_view_new();
    renderer_view_set_scene(document->view, scene);
    renderer_scene_set_view(scene, document->view);
}

/* public function */
SvgElementSvg *svg_document_get_root(SvgDocument* document)
{
    return SVG_ELEMENT_SVG(dom_document_get_root(DOM_DOCUMENT(document)));
}

static void
svg_document_drawable_draw(SvgDrawable *element, cairo_t *cr)
{
    SvgDocument *doc = SVG_DOCUMENT(element);
    DomDocument *dom_doc;

    SvgElementSvg *svg_element = svg_document_get_root(doc);
    SvgElement    *elt = SVG_ELEMENT(svg_element);
    RendererObject* renderer = svg_element_graphics_get_renderer(elt);

    //renderer_scene_set_root(doc->view->scene, (RendererObject *) renderer);
    //renderer_scene_set_target(doc->view->scene, (RendererObject *) renderer);

//    gchar *str = renderer_object_dump(renderer, "");
//    g_print("%s\n", str);
//    g_free(str);

    svg_element_graphics_update_renderer(svg_element);

    gboolean success = renderer_object_draw(renderer, cr);
}

void
svg_document_draw(SvgDocument *document, cairo_t *cr)
{
    svg_document_drawable_draw((SvgDrawable *) document, cr);
}

SvgDocument*
svg_document_new (void)
{
    DomDocument *document = g_object_new (SVG_TYPE_DOCUMENT, NULL);
    /*dom_document_xml_new(document);// internal data


    DomQualifiedName tag_root;
    dom_document_tag_root(document, &tag_root);
    GHashTable *tag_names = dom_document_get_tag_names(document);
    char *tag_name = g_strdup_printf("svg:%s", tag_root.name);
    GType type = (GType) g_hash_table_lookup (tag_names, tag_name);
    g_free(tag_name);
    if (!type) {
        type = svg_element_get_type();
        g_print("Error: svg:%s type not registered\n", tag_root.name);
    }
    g_assert(type);
    DomNode *root = g_object_new (type, NULL);
    root->document = document;

    xmlNode *root_xml = xmlNewNode(NULL, BAD_CAST tag_root.name);
    root_xml->doc = document->xml;
    root_xml->_private = root;
    root->xml  = root_xml;

    xmlNs *default_ns = NULL;
    int length = G_N_ELEMENTS(svg_default_namespaces)-1;
    DomNamespace *namespaces;
    dom_document_namespaces(document, &namespaces);
    int i;
    for (i=0; i<length; i++) {
        xmlNs *ns = NULL;
        DomNamespace *decl = &namespaces[i];
        if (g_strcmp0(decl->name.name, svg_default_namespace)==0) {
            ns = xmlNewNs(root_xml, decl->href, NULL);
            default_ns = ns;
        } else {
            ns = xmlNewNs(root_xml, decl->href, decl->name.name);
        }
        dom_document_register_ns(document, ns);
    }

    xmlSetNs(root_xml, default_ns);
    xmlDocSetRootElement(document->xml, root_xml);

    document->root = root;*/


    return document;
}



SvgDocument*
svg_document_load (const gchar *uri)
{
    SvgDocument* svg_doc = g_object_new(svg_document_get_type(), NULL);
    DomDocument* document = DOM_DOCUMENT(svg_doc);

    dom_document_load(document, uri);

    DomNode *root = dom_document_get_root(document);
    SvgElementSvg *svg_root = SVG_ELEMENT_SVG(root);
    RendererObject* renderer = svg_element_graphics_get_renderer(svg_root);

    // @FIXME
    renderer_scene_set_root(svg_doc->view->scene, (RendererObject *) renderer);
    renderer_scene_set_target(svg_doc->view->scene, (RendererObject *) renderer);

    svg_element_graphics_update_renderer(svg_root);

    return document;
}

void
svg_document_free (SvgDocument *document)
{
    g_object_unref(document);
}

RendererView*
svg_document_get_view(SvgDocument *document)
{
    return document->view;
}

/*TODO: svg_element_svg_get_renderer() */
/*RendererScene*
svg_document_get_renderer_scene(SvgDocument* document)
{
    SvgElementSvg *svg_element = document->root;
    SvgElement    *element = SVG_ELEMENT(svg_element);

    RendererObject* renderer = svg_element_get_renderer(element);

    return (RendererScene*) renderer;
}
*/

void svg_document_set_time(SvgDocument *document, double time)
{
    document->time->seconds = time;
    svg_time_container_update_animations(document->time_container, document->time, FALSE);

    /*SvgTimeline *timeline->set_time(59); */
    /*renderer_update();*/
    /*motion_animator_set_time();*/
    /*motion_animator_add_state();*/
    /*motion_animator_play();*/
}

SvgElement *svg_document_hit (SvgDocument* doc, gdouble x, gdouble y/*, SvgException *ex*/)
{
    DomDocument *dom_doc = (DomDocument*)doc;
    SvgElement *element = NULL;
    SvgHitRequest *request = svg_hit_request_new();
    //request-> = RENDERER_BOUNDING_VISUAL_MODE;

    SvgHitResult  *result  = svg_hit_result_new();
    request->x = x;
    request->y = y;

    SvgElementSvg *root = svg_document_get_root(doc);
    //SvgElementSvg *root = (SvgElementSvg*) dom_doc->xml->_private;
    svg_element_graphics_hit_test(root, request, result);
    if (g_list_length(result->elements)) {
        element = g_list_last(result->elements)->data;
    }
    return element;
}

