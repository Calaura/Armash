/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-element-animate-color.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <liblog/log.h>

#include <libgraphics/graphics.h>

#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"
#include "libmotion/motion-easing.h"
#include "libmotion/motion-easing-linear.h"

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-time.h"
#include "svg-color.h"
#include "svg-element.h"
#include "svg-element-animation.h"
#include "svg-animated.h"
#include "properties/svg-animated-property.h"
#include "properties/svg-property-info.h"
#include "svg-animated-type.h"
#include "svg-animated-type-animator.h"
#include "svg-element-animate.h"

#include "svg-element-animate-color.h"

static int       svg_element_animate_color_init_from_xml(DomNode* element, xmlNode* node);
static gboolean  svg_element_animate_color_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value);

static void svg_element_animate_color_class_init(SvgElementAnimateColorClass *klass);
static void svg_element_animate_color_init(SvgElementAnimateColor *gobject);

G_DEFINE_TYPE (SvgElementAnimateColor, svg_element_animate_color, SVG_TYPE_ELEMENT_ANIMATE)
#define parent_class svg_element_animate_color_parent_class

static void
svg_element_animate_color_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (svg_element_animate_color_parent_class)->finalize (object);
}
static void
svg_element_animate_color_class_init(SvgElementAnimateColorClass *klass)
{
    DomNodeClass *dom_class;
    SvgElementClass   *svg_class;
    GObjectClass *gobject_class;

    dom_class = (DomNodeClass *) klass;
    svg_class = (SvgElementClass *) klass;
    gobject_class = (GObjectClass *) klass;

    gobject_class->finalize  = svg_element_animate_color_finalize;
    dom_class->init_from_xml = svg_element_animate_color_init_from_xml;
    svg_class->parse_attribute = svg_element_animate_color_parse_attribute;

//	svg_element_animate_color_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_animate_color_init (SvgElementAnimateColor *object)
{
    object->from = NULL; //svg_color_new();
    object->to   = NULL; //svg_color_new();
}

#include "svg-element-graphics.h"
#include "svg-style.h"
#include "svg-animated-color.h"
/* virtual function */
static int
svg_element_animate_color_init_from_xml(DomNode* element, xmlNode* node)
{
    SvgElementAnimation    *animation = SVG_ELEMENT_ANIMATION(element);
    SvgElementAnimateColor *animate   = SVG_ELEMENT_ANIMATE_COLOR(element);
    SvgElement             *target    = SVG_ELEMENT(node->parent->_private);
    SvgElementGraphics     *graphics  = SVG_ELEMENT_GRAPHICS(target);

    int success = DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);


    /* motion_update_times */
    double begin = svg_element_animation_get_start_time(SVG_ELEMENT_ANIMATION(element));
    double end   = begin + svg_element_animation_get_simple_duration(SVG_ELEMENT_ANIMATION(element));
    double from = 0;
    double to   = 0;
    gboolean status = FALSE;


    if (!svg_color_is_none(animate->to)) {
        to = animate->to->value;
        if (!svg_color_is_none(animate->from)) {
            to   = (double) animate->to->value;
            from = (double) animate->from->value;
        } else {
            GValue value = G_VALUE_INIT;
            g_value_init(&value, G_TYPE_UINT);
            g_object_get_property(target, animation->attribute_name, &value);
            from = g_value_get_double(&value);
            g_print("x=%g\n", from);
        }
        status = TRUE;
    }

    /*
     * SvgAnimatedLength *length = svg_element_get_motion_property("x");
     * MotionProperty *property = length->property;
     *
     */

    MotionProperty *property = NULL;
    if (status) {
        // property = SVG_ANIMATE_LENGTH(SVG_ELEMENT_RECT(target)->x)->property
        property = motion_property_new(animation->attribute_name, G_OBJECT(target));
        motion_animation_set_times(MOTION_ANIMATION(property), begin, end);
        motion_animation_set_values(MOTION_ANIMATION(property), from, to);
        MotionEasingLinear *easing = MOTION_EASING_LINEAR(motion_easing_linear_new());
        easing->P0_x = 0.0;
        easing->P0_y = 0.0;
        easing->P1_x = 0.0;
        easing->P1_y = 0.0;
        motion_animation_set_easing(property, easing);
        MOTION_ANIMATION(property)->calculate_value = svg_animated_color_calculate_value;

        //g_object_get_property/svg_element_animatable_get_property(target, "x", &value);
        SvgAnimated *property_fill = svg_element_animatable_get_property(target, animation->attribute_name);
        // svg_element_animatable_get_animated();
        property_fill->property = property;
        g_print("SvgAnimated(fill)=%p - %s\n", property_fill, G_OBJECT_TYPE_NAME(property_fill));
    }


    return success;
}

static gboolean svg_element_animate_color_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_ANIMATE(element));
    /*SvgElement *target = SVG_ELEMENT_ANIMATE(element)->target;*/
    SvgElementAnimateColor *animate = SVG_ELEMENT_ANIMATE_COLOR(element);

    if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "from"))) {
        animate->from = svg_color_new_from_string(value);
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "to"))) {
        animate->to = svg_color_new_from_string(value);
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

SvgElementAnimateColor *
svg_element_animate_color_new (void)
{
	return g_object_new (svg_element_animate_color_get_type (),
	                     NULL);
}

