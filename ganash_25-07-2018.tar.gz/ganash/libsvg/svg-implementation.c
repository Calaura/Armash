/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-implementation.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>
#include <cairo/cairo.h>

#include "liblog/log.h"
#include "librenderer/renderer.h"
#include "libdom/dom.h"
#include "libdom/dom-types.h"

#include "libdom/dom-implementation.h"
#include "svg.h"
#include "svg-implementation.h"

typedef struct _SvgTag SvgTag;
struct _SvgTag {
  gchar *name;
  GType  type;
  guint  code;
};

static SvgTag*
svg_tag_new(gchar *name, GType type, guint code)
{
    SvgTag *tag = g_new0(SvgTag, 1);
    tag->name = g_strdup(name);
    tag->type = type;
    tag->code = code;
    return tag;
}
static void
svg_tag_free(SvgTag *tag)
{
    g_free(tag->name);
    g_free(tag);
}


static GHashTable *svg_tag_table = NULL;

static void svg_implementation_class_init(SvgImplementationClass *klass);
static void svg_implementation_init(SvgImplementation *gobject);

G_DEFINE_TYPE (SvgImplementation, svg_implementation, G_TYPE_OBJECT)

static DomNode*
svg_implementation_create_element_ns(gchar *ns, gchar *name, DomDocument *document, GError **error)
{
    DomNode *node;

    // switch svg:tagName
    // GHashTable table = g_hash_table_lookup(ns);
    // GType type = g_hash_table_lookup(name);

    return node;
}

static void
svg_implementation_class_init(SvgImplementationClass *klass)
{
    DomImplementationClass *dom_implementation_class;

    dom_implementation_class = (DomImplementationClass *) klass;

    dom_implementation_class->create_element_ns = svg_implementation_create_element_ns;
}
/*
 * svg_implementation_create_document("http://www.w3.org/2000/svg", "svg", doctype);
 */
static DomDocument*
svg_implementation_create_document(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype)
{
    /*
    RefPtr<Document> doc;
    if (namespaceURI == SVGNames::svgNamespaceURI)
        doc = SVGDocument::create(0, URL());
    else if (namespaceURI == HTMLNames::xhtmlNamespaceURI)
        doc = Document::createXHTML(0, URL());
    else
        doc = Document::create(0, URL());

    doc->setSecurityOrigin(m_document.securityOrigin());

    RefPtr<Node> documentElement;
    if (!qualifiedName.isEmpty()) {
        documentElement = doc->createElementNS(namespaceURI, qualifiedName, ec);
        if (ec)
            return 0;
    }

    if (doctype)
        doc->appendChild(doctype);
    if (documentElement)
        doc->appendChild(documentElement.release());

    return doc.release();
    */

    return NULL;
}
// createElementNs("svg:svg", document);
// document.getDefaultNs(QualifiedName().prefix)
// document.implementation().createElementNS(tag_name, document, &error);
// document.implementation().createAttributeNS(attr_name, document, &error);
// for each xml::attributes : element.addAttributeNS(attr);


static DomNode*
svg_implementation_create_element(gchar *qualified_name, DomDocument *document)
{
    //if (qualified_name.prefix == NULL && document.defaultNS == "svg") || qualified_name.prefix == "svg"
    //if qualified_name.localName in SVGNames::Tags
    return NULL;
}

static DomNode*
svg_implementation_create_attribute(gchar *qualified_name, DomDocument *document)
{
    //if (qualified_name.prefix == NULL && document.defaultNS == "svg") || qualified_name.prefix == "svg"
    //if qualified_name.localName in SVGNames::Tags
    return NULL;
}

static DomDocumentType*
svg_implementation_create_document_type(gchar *qualified_name, gchar *public_id, gchar *system_id)
{

    return NULL;
}

static gboolean
svg_implementation_has_feature(DomImplementation *self, gchar *feature , gchar *version)
{
    return FALSE;
}

static void
svg_implementation_init (SvgImplementation *object)
{
    if (svg_tag_table==NULL) {
        svg_tag_table = g_hash_table_new(g_str_hash, g_str_equal);
//        g_hash_table_insert(svg_tag_table, "a", svg_tag_new("a", SVG_TYPE_ELEMENT_A, 2));
//        g_hash_table_insert(svg_tag_table, "altglyph", svg_tag_new("altglyph", SVG_TYPE_ELEMENT_ALT_GLYPH, 5));
//        g_hash_table_insert(svg_tag_table, "altglyphdef", svg_tag_new("altglyphdef", SVG_TYPE_ELEMENT_ALT_GLYPH_DEF, 7));
//        g_hash_table_insert(svg_tag_table, "altglyphitem", svg_tag_new("altglyphitem", SVG_TYPE_ELEMENT_ALT_GLYPH_ITEM, 11));
        g_hash_table_insert(svg_tag_table, "animate", svg_tag_new("animate", SVG_TYPE_ELEMENT_ANIMATE, 13));
        g_hash_table_insert(svg_tag_table, "animatecolor", svg_tag_new("animatecolor", SVG_TYPE_ELEMENT_ANIMATE_COLOR, 17));
//        g_hash_table_insert(svg_tag_table, "animatemotion", svg_tag_new("animatemotion", SVG_TYPE_ELEMENT_ANIMATE_MOTION, 19));
//        g_hash_table_insert(svg_tag_table, "animatetransform", svg_tag_new("animatetransform", SVG_TYPE_ELEMENT_ANIMATE_TRANSFORM, 23));
//        g_hash_table_insert(svg_tag_table, "set", svg_tag_new("set", SVG_TYPE_ELEMENT_SET, 29));
//        g_hash_table_insert(svg_tag_table, "circle", svg_tag_new("circle", SVG_TYPE_ELEMENT_CIRCLE, 31));
//        g_hash_table_insert(svg_tag_table, "clippath", svg_tag_new("clippath", SVG_TYPE_ELEMENT_CLIP_PATH, 37));
//        g_hash_table_insert(svg_tag_table, "cursor", svg_tag_new("cursor", SVG_TYPE_ELEMENT_CURSOR, 41));
        g_hash_table_insert(svg_tag_table, "defs", svg_tag_new("defs", SVG_TYPE_ELEMENT_DEFS, 43));
//        g_hash_table_insert(svg_tag_table, "desc", svg_tag_new("desc", SVG_TYPE_ELEMENT_DESC, 47));
//        g_hash_table_insert(svg_tag_table, "ellipse", svg_tag_new("ellipse", SVG_TYPE_ELEMENT_ELLIPSE, 53));
//        g_hash_table_insert(svg_tag_table, "feblend", svg_tag_new("feblend", SVG_TYPE_ELEMENT_FE_BLEND, 59));
//        g_hash_table_insert(svg_tag_table, "fecolormatrix", svg_tag_new("fecolormatrix", SVG_TYPE_ELEMENT_FE_COLOR_MATRIX, 61));
//        g_hash_table_insert(svg_tag_table, "fecomponenttransfer", svg_tag_new("fecomponenttransfer", SVG_TYPE_ELEMENT_FE_COMPONENT_TRANSFER, 67));
//        g_hash_table_insert(svg_tag_table, "fecomposite", svg_tag_new("fecomposite", SVG_TYPE_ELEMENT_FE_COMPOSITE, 71));
//        g_hash_table_insert(svg_tag_table, "feconvolvematrix", svg_tag_new("feconvolvematrix", SVG_TYPE_ELEMENT_FE_CONVOLVE_MATRIX, 73));
//        g_hash_table_insert(svg_tag_table, "fediffuselighting", svg_tag_new("fediffuselighting", SVG_TYPE_ELEMENT_FE_DIFFUSE_LIGHTING, 79));
//        g_hash_table_insert(svg_tag_table, "fedisplacementmap", svg_tag_new("fedisplacementmap", SVG_TYPE_ELEMENT_FE_DISPLACEMENT_MAP, 83));
//        g_hash_table_insert(svg_tag_table, "fedistantlight", svg_tag_new("fedistantlight", SVG_TYPE_ELEMENT_FE_DISTANT_LIGHT, 89));
//        g_hash_table_insert(svg_tag_table, "fedropshadow", svg_tag_new("fedropshadow", SVG_TYPE_ELEMENT_FE_DROP_SHADOW, 97));
//        g_hash_table_insert(svg_tag_table, "feflood", svg_tag_new("feflood", SVG_TYPE_ELEMENT_FE_FLOOD, 101));
//        g_hash_table_insert(svg_tag_table, "fefunca", svg_tag_new("fefunca", SVG_TYPE_ELEMENT_FE_FUNC_A, 103));
//        g_hash_table_insert(svg_tag_table, "fefuncb", svg_tag_new("fefuncb", SVG_TYPE_ELEMENT_FE_FUNC_B, 107));
//        g_hash_table_insert(svg_tag_table, "fefuncg", svg_tag_new("fefuncg", SVG_TYPE_ELEMENT_FE_FUNC_G, 109));
//        g_hash_table_insert(svg_tag_table, "fefuncr", svg_tag_new("fefuncr", SVG_TYPE_ELEMENT_FE_FUNC_R, 113));
//        g_hash_table_insert(svg_tag_table, "fegaussianblur", svg_tag_new("fegaussianblur", SVG_TYPE_ELEMENT_FE_GAUSSIAN_BLUR, 127));
//        g_hash_table_insert(svg_tag_table, "feimage", svg_tag_new("feimage", SVG_TYPE_ELEMENT_FE_IMAGE, 131));
//        g_hash_table_insert(svg_tag_table, "femerge", svg_tag_new("femerge", SVG_TYPE_ELEMENT_FE_MERGE, 137));
//        g_hash_table_insert(svg_tag_table, "femergenode", svg_tag_new("femergenode", SVG_TYPE_ELEMENT_FE_MERGE_NODE, 139));
//        g_hash_table_insert(svg_tag_table, "femorphology", svg_tag_new("femorphology", SVG_TYPE_ELEMENT_FE_MORPHOLOGY, 149));
//        g_hash_table_insert(svg_tag_table, "feoffset", svg_tag_new("feoffset", SVG_TYPE_ELEMENT_FE_OFFSET, 151));
//        g_hash_table_insert(svg_tag_table, "fepointlight", svg_tag_new("fepointlight", SVG_TYPE_ELEMENT_FE_POINT_LIGHT, 157));
//        g_hash_table_insert(svg_tag_table, "fespecularlighting", svg_tag_new("fespecularlighting", SVG_TYPE_ELEMENT_FE_SPECULAR_LIGHTING, 163));
//        g_hash_table_insert(svg_tag_table, "fespotlight", svg_tag_new("fespotlight", SVG_TYPE_ELEMENT_FE_SPOT_LIGHT, 167));
//        g_hash_table_insert(svg_tag_table, "fetile", svg_tag_new("fetile", SVG_TYPE_ELEMENT_FE_TILE, 173));
//        g_hash_table_insert(svg_tag_table, "feturbulence", svg_tag_new("feturbulence", SVG_TYPE_ELEMENT_FE_TURBULENCE, 179));
//        g_hash_table_insert(svg_tag_table, "filter", svg_tag_new("filter", SVG_TYPE_ELEMENT_FILTER, 181));
//        g_hash_table_insert(svg_tag_table, "font", svg_tag_new("font", SVG_TYPE_ELEMENT_FONT, 191));
//        g_hash_table_insert(svg_tag_table, "font_face", svg_tag_new("font_face", SVG_TYPE_ELEMENT_FONT_FACE, 193));
//        g_hash_table_insert(svg_tag_table, "font_face_format", svg_tag_new("font_face_format", SVG_TYPE_ELEMENT_FONT_FACE_FORMAT, 197));
//        g_hash_table_insert(svg_tag_table, "font_face_name", svg_tag_new("font_face_name", SVG_TYPE_ELEMENT_FONT_FACE_NAME, 199));
//        g_hash_table_insert(svg_tag_table, "font_face_src", svg_tag_new("font_face_src", SVG_TYPE_ELEMENT_FONT_FACE_SRC, 211));
//        g_hash_table_insert(svg_tag_table, "font_face_uri", svg_tag_new("font_face_uri", SVG_TYPE_ELEMENT_FONT_FACE_URI, 223));
//        g_hash_table_insert(svg_tag_table, "foreignobject", svg_tag_new("foreignobject", SVG_TYPE_ELEMENT_FOREIGN_OBJECT, 227));
        g_hash_table_insert(svg_tag_table, "g", svg_tag_new("g", SVG_TYPE_ELEMENT_G, 229));
//        g_hash_table_insert(svg_tag_table, "glyph", svg_tag_new("glyph", SVG_TYPE_ELEMENT_GLYPH, 233));
//        g_hash_table_insert(svg_tag_table, "glyphref", svg_tag_new("glyphref", SVG_TYPE_ELEMENT_GLYPH_REF, 239));
//        g_hash_table_insert(svg_tag_table, "hkern", svg_tag_new("hkern", SVG_TYPE_ELEMENT_HKERN, 241));
//        g_hash_table_insert(svg_tag_table, "image", svg_tag_new("image", SVG_TYPE_ELEMENT_IMAGE, 251));
//        g_hash_table_insert(svg_tag_table, "line", svg_tag_new("line", SVG_TYPE_ELEMENT_LINE, 257));
//        g_hash_table_insert(svg_tag_table, "lineargradient", svg_tag_new("lineargradient", SVG_TYPE_ELEMENT_LINEAR_GRADIENT, 263));
//        g_hash_table_insert(svg_tag_table, "marker", svg_tag_new("marker", SVG_TYPE_ELEMENT_MARKER, 269));
//        g_hash_table_insert(svg_tag_table, "mask", svg_tag_new("mask", SVG_TYPE_ELEMENT_MASK, 271));
//        g_hash_table_insert(svg_tag_table, "metadata", svg_tag_new("metadata", SVG_TYPE_ELEMENT_METADATA, 277));
//        g_hash_table_insert(svg_tag_table, "missing_glyph", svg_tag_new("missing_glyph", SVG_TYPE_ELEMENT_MISSING_GLYPH, 281));
//        g_hash_table_insert(svg_tag_table, "mpath", svg_tag_new("mpath", SVG_TYPE_ELEMENT_MPATH, 283));
        g_hash_table_insert(svg_tag_table, "path", svg_tag_new("path", SVG_TYPE_ELEMENT_PATH, 293));
//        g_hash_table_insert(svg_tag_table, "pattern", svg_tag_new("pattern", SVG_TYPE_ELEMENT_PATTERN, 307));
//        g_hash_table_insert(svg_tag_table, "polygon", svg_tag_new("polygon", SVG_TYPE_ELEMENT_POLYGON, 311));
//        g_hash_table_insert(svg_tag_table, "polyline", svg_tag_new("polyline", SVG_TYPE_ELEMENT_POLYLINE, 313));
//        g_hash_table_insert(svg_tag_table, "radialgradient", svg_tag_new("radialgradient", SVG_TYPE_ELEMENT_RADIAL_GRADIENT, 317));
        g_hash_table_insert(svg_tag_table, "rect", svg_tag_new("rect", SVG_TYPE_ELEMENT_RECT, 331));
//        g_hash_table_insert(svg_tag_table, "script", svg_tag_new("script", SVG_TYPE_ELEMENT_SCRIPT, 337));
        g_hash_table_insert(svg_tag_table, "stop", svg_tag_new("stop", SVG_TYPE_ELEMENT_STOP, 347));
        g_hash_table_insert(svg_tag_table, "style", svg_tag_new("style", SVG_TYPE_ELEMENT_STYLE, 349));
        g_hash_table_insert(svg_tag_table, "svg", svg_tag_new("svg", SVG_TYPE_ELEMENT_SVG, 353));
//        g_hash_table_insert(svg_tag_table, "switch", svg_tag_new("switch", SVG_TYPE_ELEMENT_SWITCH, 359));
        g_hash_table_insert(svg_tag_table, "symbol", svg_tag_new("symbol", SVG_TYPE_ELEMENT_SYMBOL, 367));
//        g_hash_table_insert(svg_tag_table, "text", svg_tag_new("text", SVG_TYPE_ELEMENT_TEXT, 373));
//        g_hash_table_insert(svg_tag_table, "textpath", svg_tag_new("textpath", SVG_TYPE_ELEMENT_TEXT_PATH, 379));
//        g_hash_table_insert(svg_tag_table, "title", svg_tag_new("title", SVG_TYPE_ELEMENT_TITLE, 383));
//        g_hash_table_insert(svg_tag_table, "tref", svg_tag_new("tref", SVG_TYPE_ELEMENT_TREF, 389));
//        g_hash_table_insert(svg_tag_table, "tspan", svg_tag_new("tspan", SVG_TYPE_ELEMENT_TSPAN, 397));
        g_hash_table_insert(svg_tag_table, "use", svg_tag_new("use", SVG_TYPE_ELEMENT_USE, 401));
//        g_hash_table_insert(svg_tag_table, "view", svg_tag_new("view", SVG_TYPE_ELEMENT_VIEW, 409));
//        g_hash_table_insert(svg_tag_table, "vkern", svg_tag_new("vkern", SVG_TYPE_ELEMENT_VKERN, 419));
    }

}

SvgImplementation *
svg_implementation_new (void)
{
	return g_object_new (svg_implementation_get_type (),
	                     NULL);
}

