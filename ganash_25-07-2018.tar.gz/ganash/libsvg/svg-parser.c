/*
 * svg-parser.c
 * Copyright (C) 2002, 2003 The Karbon Developers
 * Copyright (C) 2006, 2007 Rob Buis <buis@kde.org>
 * Copyright (C) 2013       Apple Inc. All rights reserved.
 * Copyright (C) 2014       MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>


#include <cairo/cairo.h>
#include <libgraphics/graphics.h>

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libmotion/motion-types.h>
#include <libmotion/motion-animation.h>
#include <libmotion/motion-property.h>

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-color.h"
#include "svg-color-icc.h"
#include "svg-animated.h"
#include "svg-animated-color.h"
#include "svg-time.h"
#include "svg-matrix.h"
#include "svg-paint.h"
#include "svg-transform.h"
#include "svg-transform-list.h"
#include "svg-path.h"
#include "svg-document.h"
#include "svg-element.h"
#include "svg-parser.h"

#include <math.h>
#include <string.h>



#define SVG_PARSER_MAX_EXPONENT 300

gchar*
svg_parser_parse_double(gchar* ptr, gchar* end, gdouble *number, gboolean skip)
{
    gdouble integer, decimal, frac, exponent;
    int sign, expsign;
    const gchar* start = ptr;

    exponent = 0;
    integer = 0;
    frac = 1;
    decimal = 0;
    sign = 1;
    expsign = 1;

    // read the sign
    if (ptr < end && *ptr == '+')
        ptr++;
    else if (ptr < end && *ptr == '-') {
        ptr++;
        sign = -1;
    }

    /* The first character of a number must be one of [0-9+-.] */
    if (ptr == end || ((*ptr < '0' || '9' < *ptr) && *ptr != '.'))
        return NULL;

    /* read the integer part, build right-to-left */
    const gchar* ptrStartIntPart = ptr;
    while (ptr < end && '0' <= *ptr && *ptr <= '9')
        ++ptr; /* Advance to first non-digit. */

    if (ptr != ptrStartIntPart) {
        const gchar* ptrScanIntPart = ptr - 1;
        double multiplier = 1;
        while (ptrScanIntPart >= ptrStartIntPart) {
            integer += multiplier * (double)(*(ptrScanIntPart--) - '0');
            multiplier *= 10;
        }
        /* Bail out early if this overflows. */
        if (integer < -G_MAXDOUBLE || G_MAXDOUBLE < integer)
            return NULL;
    }


    if (ptr < end && *ptr == '.') { /* read the decimals */
        ptr++;

        /* There must be a least one digit following the */
        if (ptr >= end)
            return NULL;

        while (ptr < end && *ptr >= '0' && *ptr <= '9')
            decimal += (*(ptr++) - '0') * (frac *= 0.1);
    }

    /* read the exponent part */
    if (ptr != start && ptr + 1 < end && (*ptr == 'e' || *ptr == 'E')
        && (ptr[1] != 'x' && ptr[1] != 'm')) {
        ptr++;

        // read the sign of the exponent
        if (*ptr == '+')
            ptr++;
        else if (*ptr == '-') {
            ptr++;
            expsign = -1;
        }

        /* There must be an exponent */
        if (ptr >= end || *ptr < '0' || *ptr > '9')
            return NULL;

        while (ptr < end && *ptr >= '0' && *ptr <= '9') {
            exponent *= 10.0;
            exponent += *ptr - '0';
            ptr++;
        }
        /* Make sure exponent is valid */
        if (exponent < -G_MAXDOUBLE || G_MAXDOUBLE < exponent || exponent > SVG_PARSER_MAX_EXPONENT)
            return NULL;
    }

    *number = integer + decimal;
    *number *= sign;

    if (exponent)
        *number *= pow(10.0, expsign * (int)exponent);

    /* Don't return Infinity() or NaN() */
    if ((*number) < -G_MAXDOUBLE || G_MAXDOUBLE < (*number))
        return NULL;

    if (start == ptr)
        return NULL;

    if (skip)
    {
        if (ptr < end && !svg_parser_is_space(*ptr) && *ptr != ',')
            return ptr;
        while (ptr < end && svg_parser_is_space(*ptr))
            ptr++;
        if (ptr < end && *ptr == ',') {
            ptr++;
            while (ptr < end && svg_parser_is_space(*ptr))
                ptr++;
        }
    }

    return ptr;
}


/**
 * @brief svg_parser_parse_integer
 * integer ::= [+-]? [0-9]+
 * example:
 *  1
 * +0
 * -9
 *  0123456789
 *
 * @param value
 * @param ptr
 * @param end
 * @return
 */
gchar *svg_parser_parse_integer(double *value, gchar* ptr, gchar *end)
{
    double integer = 0;
    int sign = 1;

    // read the sign
    if (ptr < end && *ptr == '+')
        ptr++;
    else if (ptr < end && *ptr == '-') {
        ptr++;
        sign = -1;
    }

    gchar *start = ptr;
    while (ptr<end && svg_parser_is_digit(*ptr)) {
        integer = integer * 10 + *ptr - '0';
        ptr++;
    }
    if (start==ptr) {
        return NULL;/*NO DIGIT Found*/
    }
    *value = sign * integer;
    return ptr;
}
/**
 * @brief svg_parser_parse_number
 * number ::= integer | [+-]? [0-9]* "." [0-9]+
 * example:
 * .0
 * -.0
 * +.1
 * -.97
 *
 *
 * @param value
 * @param ptr
 * @param end
 * @return
 */
gchar* svg_parser_parse_number(gdouble *value, gchar *ptr, gchar *end)
{
    gdouble integer = 0;
    gdouble decimal = 0.0;
    gdouble frac = 1.0;
    gdouble sign = 1;
    /*
        *type = SVG_VALUE_INTEGER;
    }*/

    // read the sign
    if (ptr < end && *ptr == '+')
        ptr++;
    else if (ptr < end && *ptr == '-') {
        ptr++;
        sign = -1;
    }

    gchar *start = ptr;
    while (ptr<end && svg_parser_is_digit(*ptr)) {
        integer = integer * 10 + (*ptr - '0');
        ptr++;
    }

    if (ptr < end && *ptr == '.') { /* read the decimals */
        /*if (start == ptr) {
            *type = SVG_VALUE_NUMBER;
        }*/
        ptr++;

        /* There must be a least one digit following the */
        if (ptr >= end)
            return NULL;

        gchar *begin = ptr;
        while (ptr < end && svg_parser_is_digit(*ptr)) {
            decimal += (*ptr - '0') * (frac *= 0.1);
            ptr++;
        }
        if (begin==ptr) {
            return NULL;/*NO STRICT NUMBER .X */
        }
    }

    if (start==ptr) {
        return NULL;/*NO DIGIT Found*/
    }
    *value = sign * (integer + decimal);
    return ptr;
}
/**
 * @brief svg_parser_parse_offset
 * percentage ::= number "%"
 * offset = "<number> | <percentage>"
 *
 * @param value
 * @param type
 * @param ptr
 * @param end
 * @return
 */
gchar* svg_parser_parse_offset(gdouble *value, SvgOffsetType *type, gchar *ptr, gchar *end)
{
    double integer = 0;
    ptr = svg_parser_parse_number(&integer, ptr, end);
    if (!ptr) {
        return NULL;
    }
    if(*ptr=='%') {
        *type = SVG_OFFSET_PERCENTAGE;
        ptr++;
    } else {
        *type = SVG_OFFSET_NUMBER;
    }
    *value = integer;
    return ptr;
}

SvgLengthType svg_parser_parse_length_type(gchar *ptr, gchar *end)
{
    if (ptr == end)
        return SVG_LENGTH_TYPE_NUMBER;

    const gchar firstChar = *ptr;

    if (++ptr == end)
        return firstChar == '%' ? SVG_LENGTH_TYPE_PERCENTAGE : SVG_LENGTH_TYPE_UNKNOW;

    const gchar secondChar = *ptr;

    if (++ptr != end)
        return SVG_LENGTH_TYPE_UNKNOW;

    if (firstChar == 'e' && secondChar == 'm')
        return SVG_LENGTH_TYPE_EMS;
    if (firstChar == 'e' && secondChar == 'x')
        return SVG_LENGTH_TYPE_EXS;
    if (firstChar == 'p' && secondChar == 'x')
        return SVG_LENGTH_TYPE_PX;
    if (firstChar == 'c' && secondChar == 'm')
        return SVG_LENGTH_TYPE_CM;
    if (firstChar == 'm' && secondChar == 'm')
        return SVG_LENGTH_TYPE_MM;
    if (firstChar == 'i' && secondChar == 'n')
        return SVG_LENGTH_TYPE_IN;
    if (firstChar == 'p' && secondChar == 't')
        return SVG_LENGTH_TYPE_PT;
    if (firstChar == 'p' && secondChar == 'c')
        return SVG_LENGTH_TYPE_PC;

    return SVG_LENGTH_TYPE_UNKNOW;
}




static gchar* svg_parser_parse_color_hex(SvgColor *color, gchar* ptr, gchar* end)
{
    gint num = 0;
    guint8 rgb[6];//0-FF * 6

    while (ptr < end) {
      if (svg_parser_is_digit(*ptr)) {
          rgb[num] = *ptr - '0';
          ptr++;
      } else if ('A' <= *ptr && *ptr <= 'F') {
          rgb[num] = *ptr - 'A' + 10;
          ptr++;
      } else if ('a' <= *ptr && *ptr <= 'f') {
          rgb[num] = *ptr - 'a' + 10;
          ptr++;
      } else {
          return NULL; /*ERROR_XDIGIT_EXPECTED*/
      }
      num++;
    }

    if (num==3) {
        color->value = 0xFF;// Alpha
        color->value <<= 8;
        color->value |= rgb[0] * 0x11;// red
        color->value <<= 8;
        color->value |= rgb[1] * 0x11;// green
        color->value <<= 8;
        color->value |= rgb[2] * 0x11;// blue
        return ptr;
    } else if(num==6) {
        color->value = 0xFF;// Alpha
        color->value <<= 8;
        color->value |= rgb[0]<<4 | rgb[1];// red
        color->value <<= 8;
        color->value |= rgb[2]<<4 | rgb[3];// green
        color->value <<= 8;
        color->value |= rgb[4]<<4 | rgb[5];// blue
        return ptr;
    }

    return NULL;
}


/*parse_percentage */
/*parse_uint8 */
gchar* svg_parser_parse_decimal(gdouble *value, SvgNumberType *type, gchar* ptr, gchar* end)
{
    double integer            = 0;
    double decimal            = 0;
    double frac               = 1;
    SvgNumberType number_type = SVG_NUMBER_UINT;
    gchar* start;

    svg_parser_skip_space(ptr, end);
    if (ptr>=end)
        return NULL;/*ERROR_END_REACHED */

    start = ptr;
    while (ptr<=end && svg_parser_is_digit(*ptr)) {
        integer = integer * 10 + *ptr - '0';
        ptr++;
    }

    if (ptr<=end && *ptr=='.') {
        ptr++;
        while (ptr<=end && svg_parser_is_digit(*ptr)) {
            frac *= 0.1;
            decimal += (*ptr - '0') * frac;
            ptr++;
        }
        number_type = SVG_NUMBER_PERCENTAGE;
    }

    if (start == ptr) {
        return NULL;
    }

    if (integer>1.0) {
        if ( decimal>0.0 )
            return NULL; /*FLOAT ERROR_BAD_FORMAT */
        if (number_type==SVG_NUMBER_PERCENTAGE)
            return NULL; /*ERROR_UNEXCEPTD_DOT */
        if (integer>255)
            return NULL; /*ERROR_OVERFLOW_UNIT8*/
    }

    *value = integer + decimal;
    *type  = number_type;

    return ptr;
}

gchar* svg_parser_parse_color(SvgColor *color, gchar *ptr, gchar *end)
{

    while (ptr < end && svg_parser_is_space(*ptr))
        ptr++;
    if (ptr>=end)
        return NULL;

    if (*ptr=='#') {
        ptr++;
        gchar *token = svg_parser_parse_color_hex(color, ptr, end);
        color->type = SVG_COLOR_RGB;
        return token;
    } else if (ptr+4<end && ptr[0]=='r' && ptr[1]=='g' && ptr[2]=='b') {
        if (ptr[3]=='a') {
            /* rgba()*/
            double red, green, blue, alpha;
            SvgNumberType red_type, green_type, blue_type, alpha_type;/*FIXME more elegant*/
            gchar *token;
            ptr += 4;

            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */
            if (*ptr!='(') return NULL;/*ERROR_CHAR_UNEXCEPTED */
            ptr++;
            token = svg_parser_parse_decimal(&red, &red_type, ptr, end);
            if (!token)
                return NULL;/* ERROR_NUMBER_EXCEPTED */

            ptr = token;
            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */
            if (*ptr!=',') return NULL;/*ERROR_CHAR_UNEXCEPTED */
            ptr++;
            token = svg_parser_parse_decimal(&green, &green_type, ptr, end);
            if (!token)
                return NULL;/* ERROR_NUMBER_EXCEPTED */

            ptr = token;
            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */
            if (*ptr!=',') return NULL;/*ERROR_CHAR_UNEXCEPTED */
            ptr++;
            token = svg_parser_parse_decimal(&blue, &blue_type, ptr, end);
            if (!token)
                return NULL;/* ERROR_NUMBER_EXCEPTED */

            ptr = token;
            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */
            if (*ptr!=',') return NULL;/*ERROR_CHAR_UNEXCEPTED */
            ptr++;
            token = svg_parser_parse_decimal(&alpha, &alpha_type, ptr, end);
            if (!token)
                return NULL;/* ERROR_NUMBER_EXCEPTED */
            ptr = token;

            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */
            if (*ptr!=')') return NULL;/*ERROR_CHAR_UNEXCEPTED */
            ptr++;

            if (red_type==green_type && red_type==blue_type && red_type==alpha_type) {
                if (red_type==SVG_NUMBER_UINT) {
                    color->value = (guint8)alpha;
                    color->value <<= 8;
                    color->value |= (guint8)red;
                    color->value <<= 8;
                    color->value |= (guint8)green;
                    color->value <<= 8;
                    color->value |= (guint8)blue;
                    color->type = SVG_COLOR_ARGB;
                } else {
                    color->value = (guint8) round(alpha * 0xFF);
                    color->value <<= 8;
                    color->value |= (guint8) round(red * 0xFF);
                    color->value <<= 8;
                    color->value |= (guint8) round(green * 0xFF);
                    color->value <<= 8;
                    color->value |= (guint8) round(blue * 0xFF);
                    color->type = SVG_COLOR_ARGB;
                }
                return ptr;
            } else {
                return NULL; /*ERROR_MIXED_UNIT*/
            }


        } else {
            /* rgb()*/
            double red, green, blue, alpha;
            SvgNumberType red_type, green_type, blue_type, alpha_type;
            gchar *token;
            ptr += 3;

            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */
            if (*ptr!='(') return NULL;/*ERROR_CHAR_UNEXCEPTED */
            ptr++;
            token = svg_parser_parse_decimal(&red, &red_type, ptr, end);
            if (!token)
                return NULL;/* ERROR_NUMBER_EXCEPTED */

            ptr = token;
            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */
            if (*ptr!=',') return NULL;/*ERROR_CHAR_UNEXCEPTED */
            ptr++;
            token = svg_parser_parse_decimal(&green, &green_type, ptr, end);
            if (!token)
                return NULL;/* ERROR_NUMBER_EXCEPTED */

            ptr = token;
            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */
            if (*ptr!=',') return NULL;/*ERROR_CHAR_UNEXCEPTED */
            ptr++;
            token = svg_parser_parse_decimal(&blue, &blue_type, ptr, end);
            if (!token)
                return NULL;/* ERROR_NUMBER_EXCEPTED */

            ptr = token;

            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */
            if (*ptr!=')') return NULL;/*ERROR_CHAR_UNEXCEPTED */
            ptr++;

            if (red_type==green_type && red_type==blue_type) {
                if (red_type==SVG_NUMBER_UINT) {
                    color->value = 0xFF;
                    color->value <<= 8;
                    color->value |= (guint8)red;
                    color->value <<= 8;
                    color->value |= (guint8)green;
                    color->value <<= 8;
                    color->value |= (guint8)blue;
                    color->type = SVG_COLOR_RGB;
                } else {
                    color->value = 0xFF;
                    color->value <<= 8;
                    color->value |= (guint8) round(red * 0xFF);
                    color->value <<= 8;
                    color->value |= (guint8) round(green * 0xFF);
                    color->value <<= 8;
                    color->value |= (guint8) round(blue * 0xFF);
                    color->type = SVG_COLOR_RGB;
                }
                return ptr;
            } else {
                return NULL; /*ERROR_MIXED_UNIT*/
            }

        }
    } else if (g_ascii_strcasecmp(ptr, "none")==0) {
        color->type  = SVG_COLOR_NONE;
        color->value = 0;
        return ptr+4;
    } else {
        /* try ICC */
        svg_parser_skip_space(ptr, end);
        if (ptr>=end) return NULL;/*ERROR_END_REACHED */
        char* string = ptr;
        while (string<=end && 'a' <= *ptr && *ptr <= 'z') {
            string++;
        }
        string--;
        string = g_strndup(ptr, string-ptr);

        SvgColor* icc = svg_color_icc_lookup(string);
        if (icc) {
            color->type  = icc->type;
            color->value = icc->value;
        } else {
            color->type  = SVG_COLOR_UNKNOWN;
            color->value = 0;
        }

        ptr += strlen(string);
        g_free(string);

        return ptr;
    }

    return NULL;

}

gchar* svg_parser_parse_paint(SvgPaint *paint, gchar* value)
{
    gchar* ptr = value;
    gchar* end = value + strlen(value);

    svg_parser_skip_space(ptr, end);
    if (ptr>=end)
        return NULL;

    if (ptr[0]=='u' && ptr[1]=='r' && ptr[2]=='l') {
        ptr += 3;

        svg_parser_skip_space(ptr, end);
        if (ptr>=end) return NULL;/*ERROR_END_REACHED */
        if (*ptr!='(') return NULL;/*ERROR_CHAR_UNEXCEPTED */
        ptr++;

        svg_parser_skip_space(ptr, end);
        if (ptr>=end) return NULL;/*ERROR_END_REACHED */

        if (*ptr=='#') {
            ptr++;
            gchar* start = ptr;
            while (ptr < end && (    ('a' <= (*ptr) && (*ptr) <= 'z')
                                  || ('A' <= (*ptr) && (*ptr) <= 'Z')
                                  || ('0' <= (*ptr) && (*ptr) <= '9')
                                  || '_' == (*ptr) || '-' == (*ptr) || ':' == (*ptr)|| '.' == (*ptr) ) )
                ptr++;
            if (ptr==start)
                return NULL; /* empty iri*/
            paint->type = SVG_PAINT_TYPE_URI;
            paint->data.uri = g_strndup(start, ptr-start);

            svg_parser_skip_space(ptr, end);
            if (ptr>=end) return NULL;/*ERROR_END_REACHED */

            if (*ptr!=')')
                return NULL; /*Unexpected char*/
             ptr++;

            return ptr;

        } else {
            g_message("Not implemented: <absoluteIRI> | <relativeIRI>; http://www.w3.org/Library/src/HTParse\n");
            /*
             * parser_parse_funciri("url(#myID)")
             * parser_parse_iri("#myID") local
             * parser_parse_iri("http://example.com/someDrawing.svg#Lamppost") non-local <absoluteIRI>
             * parser_parse_iri("library.svg#Lamppost") non-local <relativeIRI>
            token = svg_parser_parse_iri(id, ptr, end);
            if (!token)
                return NULL;
            */
            return NULL;
        }
    } else if ( (end-ptr)>=4 && ptr[0]=='n' && ptr[1]=='o' && ptr[2]=='n' && ptr[3]=='e') {
        return NULL;
    } else {
        SvgColor *color = g_object_new(SVG_TYPE_COLOR, NULL);
        gchar *token = svg_parser_parse_color(color, ptr, end);
        if (!token) {
            //g_object_unref(color);
            return NULL;
        }
        paint->type = SVG_PAINT_TYPE_COLOR;
        paint->data.color = color;
        return (gchar*) token;
    }
    return NULL;/*is not url()*/
}

static gchar* svg_parser_parse_translate(double *tx, double *ty, gchar *ptr, gchar *end)
{
    gchar* token = NULL;

    svg_parser_skip_space(ptr, end);
    if (ptr>=end)
        return NULL;

    if (end-ptr<9)
        return NULL;/*ERROR_END_REACHED*/

    if (ptr[0]=='t' && ptr[1]=='r' && ptr[2]=='a' && ptr[3]=='n' && ptr[4]=='s' && ptr[5]=='l' && ptr[6]=='a' && ptr[7]=='t' && ptr[8]=='e') {
        ptr += 9;
        if (*ptr!='(') {
            svg_parser_skip_space(ptr, end);
            if (ptr>=end)
                return NULL;/*ERROR_END_REACHED*/
            if (*ptr!='(')
                return NULL;/*ERROR_CHAR_EXPECTED*/
        }
        ptr++;
        svg_parser_skip_space(ptr, end);
        if (ptr>=end)
            return NULL;/*ERROR_END_REACHED*/

        double local_tx;
        token = svg_parser_parse_double(ptr, end, &local_tx, FALSE);
        if (!token)
            return NULL;/*ERROR_NUMBER_PARSER*/
        ptr = token;

        if (*ptr!=',') {
            svg_parser_skip_space(ptr, end);
            if (ptr>=end)
                return NULL;/*ERROR_END_REACHED*/
            if (*ptr!=',')
                return NULL;/*ERROR_CHAR_EXPECTED*/
        }
        ptr++;
        svg_parser_skip_space(ptr, end);
        if (ptr>=end)
            return NULL;/*ERROR_END_REACHED*/

        double local_ty;
        token = svg_parser_parse_double(ptr, end, &local_ty, FALSE);
        if (!token)
            return NULL;
        ptr = token;

        if (*ptr!=')') {
            svg_parser_skip_space(ptr, end);
            if (ptr>=end)
                return NULL;/*ERROR_END_REACHED*/
            if (*ptr!=')')
                return NULL;/*ERROR_CHAR_EXPECTED*/
        }
        ptr++;

        *tx = local_tx;
        *ty = local_ty;

    } else {
        g_print("Error: no translate identified\n");
        return NULL;
    }



    return ptr;
}

static gchar *svg_parser_parse_scale(double *sx, double *sy, gchar *ptr, gchar *end)
{
    gchar* token = NULL;
    gdouble local_sx, local_sy;

    svg_parser_skip_space(ptr, end);
    if (ptr>=end)
        return NULL;

    if (end-ptr<6)
        return NULL;/*ERROR_END_REACHED*/
    if (ptr[0]=='s' && ptr[1]=='c' && ptr[2]=='a' && ptr[3]=='l' && ptr[4]=='e') {
        ptr += 5;
        if (*ptr!='(') {
            svg_parser_skip_space(ptr, end);
            if (ptr>=end)
                return NULL;/*ERROR_END_REACHED*/
            if (*ptr!='(')
                return NULL;/*ERROR_CHAR_EXPECTED*/
        }
        ptr++;
        svg_parser_skip_space(ptr, end);
        if (ptr>=end)
            return NULL;/*ERROR_END_REACHED*/

        token = svg_parser_parse_double(ptr, end, &local_sx, FALSE);
        if (!token)
            return NULL;/*ERROR_NUMBER_PARSER*/
        ptr = token;

        if (*ptr!=',') {
            svg_parser_skip_space(ptr, end);
            if (ptr>=end)
                return NULL;/*ERROR_END_REACHED*/
            if (*ptr!=',')
                return NULL;/*ERROR_CHAR_EXPECTED*/
        }
        ptr++;
        svg_parser_skip_space(ptr, end);
        if (ptr>=end)
            return NULL;/*ERROR_END_REACHED*/

        token = svg_parser_parse_double(ptr, end, &local_sy, FALSE);
        if (!token)
            return NULL;
        ptr = token;

        if (*ptr!=')') {
            svg_parser_skip_space(ptr, end);
            if (ptr>=end)
                return NULL;/*ERROR_END_REACHED*/
            if (*ptr!=')')
                return NULL;/*ERROR_CHAR_EXPECTED*/
        }
        ptr++;

        *sx = local_sx;
        *sy = local_sy;

    } else {
        g_print("Error: no translate identified\n");
        return NULL;
    }



    return ptr;
}

static gchar* svg_parser_parse_rotate(double *radians, gchar *ptr, gchar *end)
{
    gchar* token = NULL;
    gdouble degree;


    svg_parser_skip_space(ptr, end);
    if (ptr>=end)
        return NULL;

    if (end-ptr<6)
        return NULL;/*ERROR_END_REACHED*/

    if (ptr[0]=='r' && ptr[1]=='o' && ptr[2]=='t' && ptr[3]=='a' && ptr[4]=='t' && ptr[5]=='e') {
        ptr += 6;
        if (*ptr!='(') {
            svg_parser_skip_space(ptr, end);
            if (ptr>=end)
                return NULL;/*ERROR_END_REACHED*/
            if (*ptr!='(')
                return NULL;/*ERROR_CHAR_EXPECTED*/
        }
        ptr++;
        svg_parser_skip_space(ptr, end);
        if (ptr>=end)
            return NULL;/*ERROR_END_REACHED*/

        token = svg_parser_parse_double(ptr, end, &degree, FALSE);
        if (!token)
            return NULL;
        ptr = token;

        if (*ptr!=')') {
            svg_parser_skip_space(ptr, end);
            if (ptr>=end)
                return NULL;/*ERROR_END_REACHED*/
            if (*ptr!=')')
                return NULL;/*ERROR_CHAR_EXPECTED*/
        }
        ptr++;

        *radians = degree * M_PI / 180;
    }

    return ptr;
}

#define svg_parser_is_alpha(c) ( 'a' <= (c) && (c) <= 'z' )

gchar* svg_parser_parse_transform(SvgTransformList *transforms, gchar *ptr, gchar *end)
{
    gchar *token = NULL;
    /*cairo_matrix_init_identity(&matrix->cairo_matrix);*/

    svg_parser_skip_space(ptr, end);
    if (ptr>=end)
        return NULL;

    while (ptr<end) {
        if (*ptr=='t') {
            /*try parse translate*/
            double tx, ty;
            token = svg_parser_parse_translate(&tx, &ty, ptr, end);
            if (!token) {
                g_print("Error: translate failed\n");
                return NULL;
            }
            ptr = token;
            SvgTransform *transform = svg_transform_new();
            svg_transform_set_translate(transform, tx, ty);
            svg_transform_list_append(transforms, transform);

            /*cairo_matrix_translate(&matrix->cairo_matrix, tx, ty);*/
        } else if (*ptr=='r') {
            /*try parse rotate*/
            double radians;
            token = svg_parser_parse_rotate(&radians, ptr, end);
            if (!token) {
                g_print("Error: rotate failed\n");
                return NULL;
            }
            ptr = token;
            SvgTransform *transform = svg_transform_new();
            svg_transform_set_rotate(transform, radians, 0.0, 0.0);
            svg_transform_list_append(transforms, transform);

            /*cairo_matrix_rotate(&matrix->cairo_matrix, radians);*/
        } else if (ptr[0]=='s' && ptr[1]=='c' ) {
            /*try parse scale*/
            double sx, sy;
            token = svg_parser_parse_scale(&sx, &sy, ptr, end);
            if (!token) {
                g_print("Error: rotate failed\n");
                return NULL;
            }
            ptr = token;
            SvgTransform *transform = svg_transform_new();
            svg_transform_set_scale(transform, sx, sy);
            svg_transform_list_append(transforms, transform);

            /*cairo_matrix_scale(&matrix->cairo_matrix, sx, sy);*/
        } else {
            g_print("Error: unidentified\n");
            return NULL;/*ERROR_CHAR_UNEXPECTED*/
        }
        if(*ptr==',') {
            ptr++;
        }
        svg_parser_skip_space(ptr, end);

    }
    return ptr;
}

gchar *svg_parser_parse_time(SvgTime *time, gchar *ptr, gchar *end)
{
    /*skip_withe_space(); ptr++*/
    double result = 0;
    SvgTimeType type = SVG_TIME_TYPE_UNKNOW;

    gchar *token;
    double integer;
    if (end-ptr>=8 && *(ptr+2)==':' && *(ptr+5)==':') {
        token = svg_parser_parse_integer(&integer, ptr, ptr+2);
        /*g_print("HOURS: %f\n", integer);*/
        /* if (token==ptr+2) ERROR_EXPECTED_INTEGER; */
        result += integer * 60 * 60;
        ptr = token;
        ptr++;

        token = svg_parser_parse_integer(&integer, ptr, ptr+2);
        /* if (token==ptr+2) ERROR_EXPECTED_INTEGER; */
        /* if (integer>=60) ERROR_MINUTES_OVERFLOW; */
        /*g_print("MIN: %f\n", integer);*/
        result += integer * 60;
        ptr = token;
        ptr++;

        token = svg_parser_parse_double(ptr, end, &integer, FALSE);
        /* if (token==ptr+2) ERROR_EXPECTED_INTEGER; */
        /* if (integer>=60) ERROR_SECONDE_OVERFLOW; */
        /*g_print("SECOND: %f\n", integer);*/
        result += integer;
        ptr = token;
        ptr++;

        type   = SVG_TIME_TYPE_FULL;
    } else if (end-ptr>=5 && *(ptr+2)==':' && *(ptr+5)!=':') {
        token = svg_parser_parse_integer(&integer, ptr, ptr+2);
        /* if (token==ptr+2) ERROR_EXPECTED_INTEGER; */
        /* if (integer>=60) ERROR_MINUTES_OVERFLOW; */
        result += integer * 60;
        ptr = token;
        ptr++;

        token = svg_parser_parse_double(ptr, end, &integer, FALSE);
        /* if (token==ptr+2) ERROR_EXPECTED_INTEGER; */
        /* if (integer>=60) ERROR_SECONDE_OVERFLOW; */
        result += integer;
        ptr = token;
        ptr++;
        type   = SVG_TIME_TYPE_PARTIAL;
    } else {
        token = svg_parser_parse_double(ptr, end, &integer, FALSE);
        /* if (token==NULL) ERROR_EXPECTED_INTEGER; */
        ptr = token;
        ptr++;

        if (token==NULL) {
        } else if (end-ptr>=1 && *ptr=='h') {
            result = integer * 60 * 60;
            type   = SVG_TIME_TYPE_COUNT;
        } else if (end-ptr>=3 && *ptr=='m' && *(ptr+1)=='i' && *(ptr+2)=='n') {
            result = integer * 60;
            type   = SVG_TIME_TYPE_COUNT;
        } else if (end-ptr>=2 && *ptr=='m' && *(ptr+1)=='s') {
            result = integer * 1000.0;
            type   = SVG_TIME_TYPE_COUNT;
        } else if (end-ptr>=1 && *ptr=='s') {
            result = integer;
            type   = SVG_TIME_TYPE_COUNT;
        } else {
            result = integer;
            type   = SVG_TIME_TYPE_COUNT;
        }
    }
    time->seconds = result;
    time->type    = type;
    time->empty   = FALSE;

    return ptr;
}

gchar *svg_parser_parse_time_list(GArray *times, gchar *ptr, gchar *end)
{
    while(ptr<end) {
        svg_parser_skip_separator(ptr, end);
        SvgTime time;
        ptr = svg_parser_parse_time(&time, ptr, end);
        g_array_append_val(times, time);
    }

    return ptr;
}


static SvgPathSegment *svg_path_segment_factory(SvgPathCommand command)
{
    SvgPathSegment *segment = NULL;
    switch (command)
    {
    case SVG_PATH_COMMAND_MOVE_TO:
        segment = (SvgPathSegment *) g_new(SvgPathSegmentMove, 1);
    break;
    case SVG_PATH_COMMAND_MOVE_TO_REL:
        segment = (SvgPathSegment *) g_new(SvgPathSegmentMoveRel, 1);
    break;
    case SVG_PATH_COMMAND_LINE_TO:
        segment = (SvgPathSegment *) g_new(SvgPathSegmentLine, 1);
    break;
    case SVG_PATH_COMMAND_LINE_TO_REL:
        segment = (SvgPathSegment *) g_new(SvgPathSegmentLineRel, 1);
    break;
    case SVG_PATH_COMMAND_CUBIC_TO:
        segment = (SvgPathSegment *) g_new(SvgPathSegmentCubic, 1);
    break;
    case SVG_PATH_COMMAND_CUBIC_TO_REL:
        segment = (SvgPathSegment *) g_new(SvgPathSegmentCubicRel, 1);
    break;
    default:
    break;
    }
    segment->command = command;

    return segment;
}

gchar* svg_parser_parse_path_from_buffer(SvgPath *path, char *ptr, char *end)
{
    svg_parser_skip_space(ptr, end);

    SvgPathCommand command = SVG_PATH_COMMAND_UNKNOW;
    int   data_length;
    while(ptr<end) {
        SvgPathSegment *segment;
        if (*ptr=='M') {
            command = SVG_PATH_COMMAND_MOVE_TO;
            data_length = 2;
        } else if (*ptr=='m') {
            command = SVG_PATH_COMMAND_MOVE_TO_REL;
            data_length = 2;
        } else if (*ptr=='L') {
            command = SVG_PATH_COMMAND_LINE_TO;
            data_length = 2;
        } else if (*ptr=='l') {
            command = SVG_PATH_COMMAND_LINE_TO_REL;
            data_length = 2;
        } else if (*ptr=='C') {
            command = SVG_PATH_COMMAND_CUBIC_TO;
            data_length = 4;
        } else if (*ptr=='c') {
            command = SVG_PATH_COMMAND_CUBIC_TO_REL;
            data_length = 4;
        } else {
            /*command=command*/
            if (command == SVG_PATH_COMMAND_UNKNOW) {
                g_print("command=command %s\n", ptr);
            } else {
                ptr--;
            }
        }
        segment = svg_path_segment_factory(command);
        ptr++;

        double number;
        gchar *token;
        int i;
        svg_parser_skip_space(ptr, end);
        int ln = (data_length-1)*2;
        for (i=0; i<ln; i++) {
            token = svg_parser_parse_double(ptr, end, &number, FALSE);
            ptr = token;
            segment->data[i] = number;

            svg_parser_skip_separator(ptr, end);
        }

        path->segments = g_list_append(path->segments, segment);
        path->num_segments++;
        path->cairo_path_num_data += data_length;
    }


}
