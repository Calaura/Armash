/*
 * svg-element-use.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <liblog/log.h>


#include <libgraphics/graphics.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-hit-test-request.h"
#include "librenderer/renderer-hit-test-result.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-rect.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-rect.h"
#include "svg-matrix.h"
#include "svg-hit-request.h"
#include "svg-hit-result.h"
#include "svg-locatable.h"
#include "svg-transformable.h"
#include "svg-document.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-element-graphics.h"
#include "svg-element-g.h"
#include "svg-transform-list.h"
#include "svg-element-use.h"
#include "svg-updater.h"

#define SVG_ELEMENT_USE_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), SVG_TYPE_ELEMENT_USE, SvgElementUsePrivate))
struct _SvgElementUsePrivate {
    gchar *href;/* http://www.domain.dlt/path/file#my_id */

    SvgElementGraphics *m_targetElementInstance;// RefPtr<SVGElementInstance>
};

/* SvgElement interface */
static int       svg_element_use_init_from_xml(DomNode *element, xmlNode* node);
static gchar    *svg_element_use_dump(DomNode *node, LogDumpOptions *options);

static gboolean  svg_element_use_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value);
static gchar    *svg_element_use_to_string(SvgElement* element, gchar *indent, SvgDumpFlags flags);

/* Interactive interface */
void             svg_element_use_hit_test(SvgElement *element, SvgHitRequest *request, SvgHitResult *result);

/* Locatable interface */
static void svg_locatable_use_interface_init (SvgLocatableInterface *iface);

static void svg_element_use_class_init(SvgElementUseClass *klass);
static void svg_element_use_init(SvgElementUse *gobject);


static SvgLocatableInterface *svg_locatable_use_parent_interface = NULL;
G_DEFINE_TYPE_WITH_CODE (SvgElementUse, svg_element_use, SVG_TYPE_ELEMENT_G,
                         G_IMPLEMENT_INTERFACE (SVG_TYPE_LOCATABLE,
                                                svg_locatable_use_interface_init))
#define parent_class svg_element_use_parent_class



static RendererObject*
svg_element_use_create_renderer(SvgElement* element/*RendererStyle *self*/, gboolean attache)
{
    g_log(G_LOG_DOMAIN, G_LOG_LEVEL_DEBUG, "    %s(%s#%s)", G_STRFUNC, G_OBJECT_TYPE_NAME(element), element->attribute_id);

    SvgElementUse* use = SVG_ELEMENT_USE(element);
    SvgElement *target = use->private_member->m_targetElementInstance;

    /* if target is in def it was not */
    if (!target->private_member->renderer) {
        RendererObject* object = svg_element_graphics_create_renderer(target, TRUE);
        //SVG_ELEMENT(use)->private_member->renderer = object;
        //object->data = target;
        //target->private_member->renderer = object;
        svg_element_graphics_update_renderer(target);// crée les style du shadow tree
    }


    // guint status_update = svg_element_use_switch_status_update(element, elt);
    //RendererObject *renderer = svg_element_graphics_create_renderer(target);

    RendererContainer *container;
    RendererObject *renderer;
    SvgDocument *svg_doc = SVG_DOCUMENT(dom_node_get_document(DOM_NODE(element)));

    container = renderer_container_new(svg_doc->view->scene, element->attribute_id);
    renderer = RENDERER_OBJECT(container);
    renderer->data = element;
    g_log(G_LOG_DOMAIN, G_LOG_LEVEL_DEBUG, "        %s@%p", G_OBJECT_TYPE_NAME(renderer), renderer);

    RendererObject* target_renderer = svg_element_graphics_create_renderer(target, FALSE);
    renderer_container_insert(container, target_renderer, -1);

    if (attache) {
        element->private_member->renderer = renderer;
    }

    return renderer;
}

void svg_element_use_renderer_update_transform(RendererContainer *container)
{
    g_debug("        %s", G_STRFUNC);

    gint i;
    for (i=0; i<container->children->len; i++) {
        RendererObject *renderer = g_ptr_array_index(container->children, i);
        SvgElement     *element  = SVG_ELEMENT(renderer->data);

        SvgTransformList *list = svg_element_graphics_get_transform((SvgElementGraphics*)element);
        SvgMatrix *svg_matrix = svg_transform_list_to_matrix(list);
        /*FIXME: code not used: try svg_group>svg_group>svg_rect
        if (RENDERER_IS_CONTAINER(renderer)) {
            svg_element_use_renderer_update_transform(renderer);
        }
        */
        renderer_object_set_transform(renderer, &svg_matrix->cairo_matrix);
        renderer_object_notify_transform((RendererObject*)renderer);
        g_object_unref(svg_matrix);
    }
}

void svg_element_use_update_transform(SvgElement *element)
{
    if (TRUE || get_status(element, TRANSFORM)!=SVG_UPDATE_STATUS_UPDATE) {
        g_debug("    %s: %s#%s", G_STRFUNC,
                G_OBJECT_TYPE_NAME(SVG_ELEMENT(element)->private_member->renderer),
                SVG_ELEMENT(element)->private_member->renderer->name);

        SvgTransformList *list = svg_element_graphics_get_transform((SvgElementGraphics*)element);
        SvgMatrix *svg_matrix = svg_transform_list_to_matrix(list);


        RendererContainer* container = RENDERER_CONTAINER(element->private_member->renderer);

        svg_element_use_renderer_update_transform(container);

        renderer_object_set_transform(element->private_member->renderer, &svg_matrix->cairo_matrix);
        renderer_object_notify_transform((RendererObject*)element->private_member->renderer);
        g_object_unref(svg_matrix);


        ////set_status(element, TRANSFORM, UPDATE);
    } else {
        g_debug("        %s", G_STRFUNC);
    }
}

#include "libsvg/properties/svg-animated-property.h"
#include "libsvg/properties/svg-property-info.h"
#include "libsvg/svg-element-rect.h"
#include "libsvg/svg-length.h"
#include "libmotion/motion-types.h"
//#include "libmotion/motion-enums.h"
#include "libmotion/motion-easing.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"
#include "libsvg/svg-animated.h"
#include "libsvg/svg-animated-type.h"
#include "libsvg/svg-animated-type-animator.h"
#include "libsvg/svg-animated-length.h"

static void svg_element_use_update_shape_rect(RendererObject *renderer/*, */)
{
    SvgElement     *element  = SVG_ELEMENT(renderer->data);
    SvgElementRect *rect = SVG_ELEMENT_RECT(element);

    double seconde = svg_element_get_time(element);
    double value_x      = svg_animated_length_get_value(rect->x, seconde);
    double value_y      = svg_animated_length_get_value(rect->y, seconde);
    double value_width  = svg_animated_length_get_value(rect->width, seconde);
    double value_height = svg_animated_length_get_value(rect->height, seconde);
    //set_status(element, SHAPE, MODIFIED);

    renderer_rect_set(RENDERER_RECT(renderer),
                      value_x,
                      value_y,
                      value_x+rect->width->baseVal->value,
                      value_y+rect->height->baseVal->value,
                      0.0, 0.0);
}

static void svg_element_use_update_shape_container(RendererContainer *container)
{
    gint i;
    for (i=0; i<container->children->len; i++) {
        RendererObject *renderer = g_ptr_array_index(container->children, i);

        g_debug("        %s - %s", G_OBJECT_TYPE_NAME(container), G_OBJECT_TYPE_NAME(SVG_ELEMENT(RENDERER_OBJECT(container)->data)));

        if (RENDERER_IS_CONTAINER(renderer)) {
            svg_element_use_update_shape_container(renderer);
        } else if (RENDERER_IS_RECT(renderer)) {
            svg_element_use_update_shape_rect(renderer);
        }
    }

}

static void
svg_element_use_update_shape(SvgElement *element) {
    if (TRUE || get_status(element, SHAPE)!=SVG_UPDATE_STATUS_UPDATE) {
        g_debug("    %s: %s#%s", G_STRFUNC,
                G_OBJECT_TYPE_NAME(SVG_ELEMENT(element)->private_member->renderer),
                SVG_ELEMENT(element)->private_member->renderer->name);

        RendererContainer* container = RENDERER_CONTAINER(element->private_member->renderer);

        svg_element_use_update_shape_container(container);

        ////set_status(element, SHAPE, UPDATE);
    } else {
        g_debug("        %s", G_STRFUNC);
    }
}

//#include "librenderer/renderer-style.h"
#include "libsvg/svg-style.h"
#include "libsvg/svg-element-graphics.h"

/* ************************************************************************* */
#include "libsvg/svg-element-graphics.h"
static void svg_element_use_update_graphics_rect(SvgElement *graphics, RendererObject *renderer)
{
    RendererShape *shape;
    if (RENDERER_IS_SHAPE(renderer)) {
        shape = RENDERER_SHAPE(renderer);
        GraphicsFill* fill = svg_element_graphics_update_renderer_fill(graphics);
        GraphicsStroke* stroke = svg_element_graphics_update_renderer_stroke(graphics);
    //            RENDERER_SHAPE(element->private_member->renderer)->graphics.path   = (GraphicsPath*) path;
        //if (fill)
            shape->fill   = fill;
        //if (stroke)
            shape->stroke = stroke;
    }

    /*
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);
    RendererContainer *container = RENDERER_CONTAINER(element->private_member->renderer);
    RendererShape *renderer = RENDERER_SHAPE(g_ptr_array_index(container->children, 0));

    GraphicsFill* fill = svg_element_graphics_update_renderer_fill(graphics);
    GraphicsStroke* stroke = svg_element_graphics_update_renderer_stroke(graphics);
//            RENDERER_SHAPE(element->private_member->renderer)->graphics.path   = (GraphicsPath*) path;
    renderer->fill   = fill;
    renderer->stroke = stroke;

    //renderer_shape->path = shape->path;
    // g_object_ref(shape->path);

    // g_object_ref(shape->fill);
    // g_object_ref(shape->stroke);
    */
}

static void svg_element_use_update_graphics_container(SvgElement *shadow, RendererObject *target_renderer)
{

    svg_element_use_update_graphics_rect(shadow, target_renderer);

    xmlNode *children = dom_node_get_children(DOM_NODE(shadow));
    xmlNode *child;
    int i = 0;
    for (child = children; child; child = child->next) {
        if (!child->_private)
            continue;
        RendererContainer *container = RENDERER_CONTAINER(target_renderer);
        RendererObject *renderer = g_ptr_array_index(container->children, i);
        svg_element_use_update_graphics_container(SVG_ELEMENT(child->_private), renderer);
        i++;
    }

    /*RendererContainer *container;
    container = RENDERER_CONTAINER(element->private_member->renderer);

    gint i;
    for (i=0; i<container->children->len; i++) {
        RendererObject *renderer = g_ptr_array_index(container->children, i);

        g_debug("        %s - %s", G_OBJECT_TYPE_NAME(container), G_OBJECT_TYPE_NAME(SVG_ELEMENT(RENDERER_OBJECT(container)->data)));

        if (RENDERER_IS_CONTAINER(renderer)) {
            svg_element_use_update_graphics_container(element);
        } else if (RENDERER_IS_RECT(renderer)) {
            svg_element_use_update_graphics_rect(element);
        }
    }*/

}



static void
svg_element_use_update_graphics(SvgElement *element)
{
    g_debug("    %s: %s#%s", G_STRFUNC,
            G_OBJECT_TYPE_NAME(SVG_ELEMENT(element)->private_member->renderer),
            SVG_ELEMENT(element)->private_member->renderer->name);

    RendererContainer *container = RENDERER_CONTAINER(element->private_member->renderer);
    RendererObject *renderer = g_ptr_array_index(container->children, 0);

    SvgElementUse *use = SVG_ELEMENT_USE(element);

    // copier les styles du symbole shadow tree dans le use renderer tree
    svg_element_use_update_graphics_container(use->private_member->m_targetElementInstance, renderer);

    svg_element_use_update_graphics_rect(element, renderer);

}

static gboolean
svg_element_use_update_renderer(SvgElement *element)
{
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);
    //double time = svg_element_get_time(element);
    g_debug("    %s: %s#%s", G_STRFUNC,
            G_OBJECT_TYPE_NAME(SVG_ELEMENT(element)->private_member->renderer),
            SVG_ELEMENT(element)->private_member->renderer->name);


    /*1) create style */
    //svg_element_rect_update_renderer_style(element);
    svg_element_graphics_update_style(graphics);

    /*2) create transformation */
    //svg_element_rect_update_renderer_transform(element);
    svg_element_use_update_transform(element);

    /*3) create graphics shape */
    svg_element_use_update_shape(element);

    /*4) create graphics stroke&Fill*/
    //svg_element_rect_update_renderer_graphics(element);
    svg_element_use_update_graphics(element);

    //renderer_object_update(element->private_member->renderer);


/*
    SvgElementUse* use = SVG_ELEMENT_USE(element);
    SvgElement *target = use->private_member->m_targetElementInstance;


    guint status_update = target->status_update;
    RendererObject *target_renderer = target->private_member->renderer;

    target->status_update = element->status_update;
    target->private_member->renderer = element->private_member->renderer;
    gboolean ret = svg_element_graphics_update_renderer(target);
    element->status_update = target->status_update;

    target->private_member->renderer = target_renderer;
    target->status_update = status_update;
*/

    /*SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(target);
    gboolean ret = SVG_ELEMENT_GRAPHICS_GET_CLASS(graphics)->update_renderer(element);*/


    return FALSE;
}

static int
svg_element_use_init_from_xml(DomNode* element, xmlNode* node)
{
    return DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);
}

static gchar*
svg_element_use_dump(DomNode *node, LogDumpOptions *options)
{
    SvgElementUse *use = SVG_ELEMENT_USE(node);
    gchar *content = DOM_NODE_CLASS(svg_element_use_parent_class)->dump(node, options);
    /*gchar *tmp = content;

    gchar *str = g_strdup_printf("href: %s%%s", use->private_member->href);
    content = g_strdup_printf(content, str);
    g_free(tmp);
    tmp = content;

    g_free(str);*/

    return content;
}

static void
svg_element_use_parse_attribute_href(SvgElementUse *use, gchar *href)
{
    SvgElement *element = (SvgElement*) use;
    SvgDocument *document = SVG_DOCUMENT(dom_node_get_document(DOM_NODE(use)));

    char *id = g_strdup(href+1);// TODO parse URI

    SvgElement *elt;
    if (dom_document_get_element_by_id(DOM_DOCUMENT(document), id, &elt)) {
        use->private_member->m_targetElementInstance = elt;
    }// else xlink:href="" not set
    g_free(id);
}

static gboolean
svg_element_use_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    SvgElementUse *use = SVG_ELEMENT_USE(element);

    if        (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("xlink", "href"))) {
        use->private_member->href = g_strdup(value);
        svg_element_use_parse_attribute_href(use, use->private_member->href);
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

static gchar*
svg_element_use_content_to_string(SvgElement* element, gchar *indent)
{
    char *tmp;
    char *str = g_strdup_printf("");
    char *ind = g_strdup_printf("%s%s", indent, "    ");

    xmlNode *node;
    int begin = 1;
    for (node = DOM_NODE(element)->xml->children; node; node=node->next) {
        SvgElement* child = SVG_ELEMENT(node->_private);
        char *part = svg_element_to_string(child, ind);
        tmp = part;
        part = g_strdup_printf(part, "");
        g_free(tmp);
        tmp = str;
        if (begin)
            str = g_strdup_printf("%s", part);
        else
            str = g_strdup_printf("%s,\n%s", str, part);
        g_free(part);
        g_free(tmp);
        begin = 0;
    }
    tmp = str;
    g_free(ind);

    return str;
}
/*

    gchar *ind = g_strdup_printf("%s%s", indent, "    ");
    gchar *content;
    gchar *buffer;
    gchar *tmp = NULL;
    gchar *tmp_content = NULL;

    SvgElementClass *svg_element_class = SVG_ELEMENT_CLASS(g_type_class_peek_parent(parent_class));
    buffer = SVG_ELEMENT_CLASS(svg_element_class)->to_string(element, indent);
    //buffer = SVG_ELEMENT_CLASS(svg_element_g_parent_class)->to_string(element, indent);
    tmp = buffer;

    //buffer = g_strdup_printf(buffer, ", targetInstance:[\n%s\n%s]");
    buffer = g_strdup_printf(buffer, ", targetInstance:@%p, renderer:%s");
    g_free(tmp);
    tmp = buffer;

    SvgElementUse *use = SVG_ELEMENT_USE(element);
    //content = SVG_ELEMENT_CLASS(svg_element_use_parent_class)->to_string(use->private_member->m_targetElementInstance, ind);
    content = g_strdup_printf(buffer, use->private_member->m_targetElementInstance, indent);

    //g_free(tmp);
    tmp_content = content;

    buffer = g_strdup_printf(buffer, content, indent);
    g_free(tmp);
    g_free(content);
    tmp = buffer;

    return buffer;
 */

static gchar*
svg_element_use_to_string (SvgElement* element, gchar *indent, SvgDumpFlags flags)
{
    SvgElementUse *use = SVG_ELEMENT_USE(element);

    gchar *content = g_strdup("");
    /*gchar *tmp = content;
    char *ind = g_strdup_printf("%s%s", indent, "    ");

    if (element->attribute_id) {
        content = g_strdup_printf("id: \"%s\"", element->attribute_id);
        g_free(tmp);
        tmp = content;
    }

    if(element->private_member->renderer)
    {
        char *renderer = renderer_object_dump(element->private_member->renderer, ind, flags);
        content = g_strdup_printf("%s, targetInstance: @%p, renderer:\n%s\n%s", content, use->private_member->m_targetElementInstance, renderer, indent);
        g_free(tmp);
        tmp = content;
    }

    content = g_strdup_printf("%s[%s@%p{%s%%s}]", indent, G_OBJECT_TYPE_NAME(element), element, content);
    g_free(tmp);
    tmp = content;*/

//    g_free(ind);
    return content;
}


SvgMatrix*
svg_locatable_use_get_transform (SvgLocatable *locatable)
{
    SvgElementUse      *use      = SVG_ELEMENT_USE(locatable);
    //SvgElementGraphics *graphics = (SvgElementGraphics*)use;
    //SvgElement         *element  = (SvgElement*)graphics;

    SvgElementGraphics *target   = SVG_ELEMENT_GRAPHICS(use->private_member->m_targetElementInstance);

    SvgTransformList *list = svg_element_graphics_get_transform ((SvgElementGraphics*) target);
    SvgMatrix *matrix = svg_transform_list_to_matrix(list);
    /*SvgTransformList *transform_list= svg_element_graphics_get_transform(target);
    gchar *str = svg_transform_list_to_string(transform_list);
    g_print("transform=\"%s\"\n", str);
    g_free(str);*/
    SvgMatrix *svg_matrix = svg_locatable_use_parent_interface->get_transform (locatable);// get_graphics_transform of element
    /*SvgTransformList *list= svg_element_graphics_get_transform(locatable);
    gchar *str2 = svg_transform_list_to_string(list);
    g_print("transform=\"%s\"\n", str2);
    g_free(str2);*/

    //svg_matrix_multiply(svg_matrix, matrix);
    //g_object_unref(matrix);

    return svg_matrix;
}

static void
svg_locatable_use_interface_init (SvgLocatableInterface *iface)
{
    svg_locatable_use_parent_interface = g_type_interface_peek_parent (iface);

    iface->get_transform = svg_locatable_use_get_transform;
}

static void
svg_element_use_class_init(SvgElementUseClass *klass)
{
    DomNodeClass *dom_class;
    SvgElementClass *element_class;
    SvgElementGraphicsClass *graphics_class;

    dom_class  = (DomNodeClass *) klass;
    element_class  = (SvgElementClass *) klass;
    graphics_class = (SvgElementGraphicsClass *) klass;

    graphics_class->create_renderer = svg_element_use_create_renderer;
    graphics_class->update_renderer = svg_element_use_update_renderer;

    graphics_class->hit_test        = svg_element_use_hit_test;

    dom_class->init_from_xml        = svg_element_use_init_from_xml;
    dom_class->dump                 = svg_element_use_dump;
    element_class->parse_attribute  = svg_element_use_parse_attribute;
    element_class->to_string        = svg_element_use_to_string;

    g_type_class_add_private(klass, sizeof(SvgElementUsePrivate));
//	svg_element_use_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_use_init (SvgElementUse *object)
{
    SvgElement *element = SVG_ELEMENT(object);
    element->name = G_OBJECT_TYPE_NAME(object);/*for debug*/

	SvgElementUsePrivate *priv = SVG_ELEMENT_USE_GET_PRIVATE(object);
	object->private_member = priv;
    priv->href = NULL;
    priv->m_targetElementInstance = NULL;
}

void
svg_element_use_hit_test(SvgElement *element, SvgHitRequest *request, SvgHitResult *result)
{
    RendererObject *renderer = element->private_member->renderer;
    RendererView   *view = renderer->scene->view;
    cairo_t *cr = view->work_context;
    //g_print("%s on %s\n", G_STRFUNC, G_OBJECT_TYPE_NAME(element));
    /*char *str = renderer_object_dump(renderer, "  ");
    g_print("%s\n", str);
    g_free(str);*/

    RendererHitTestRequest req;
    req.x      = request->x;
    req.y      = request->y;
    req.type   = RENDERER_HIT_TEST_VISUAL_MODE;
    req.deltat = 0.0;
    RendererHitTestResult rst = {NULL};
    //renderer_view_hit_test(view, renderer, &req, &rst);
    renderer_object_hit_test(renderer, cr, &req, &rst);

    if (g_list_length(rst.items)) {
        result->elements = g_list_append(result->elements, element);
    }
}

SvgElementUse *
svg_element_use_new (void)
{
	return g_object_new (svg_element_use_get_type (),
	                     NULL);
}

void
svg_element_use_set_href(SvgElementUse *element, char *uri)
{
    DomDocument *document = dom_node_get_document(DOM_NODE(element));
    DomElement *symbol;

    char *id = g_strdup(++uri);
    dom_document_get_element_by_id(document, id, &symbol);
    g_free(id);

    element->private_member->m_targetElementInstance = SVG_ELEMENT_GRAPHICS(symbol);
    element->private_member->href = g_strdup(uri);
}
