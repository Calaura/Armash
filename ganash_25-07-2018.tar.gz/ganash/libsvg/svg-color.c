/*
 * svg-color.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>


#include <string.h>

#include <libgraphics/graphics.h>

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libxml/SAX.h>

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-color.h"
#include "svg-parser.h"


static void svg_color_class_init(SvgColorClass *klass);
static void svg_color_init(SvgColor *gobject);

G_DEFINE_TYPE (SvgColor, svg_color, G_TYPE_OBJECT)

static void
svg_color_class_init(SvgColorClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	svg_color_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_color_init (SvgColor *object)
{
}

SvgColor *
svg_color_new_from_string (gchar* string)
{
    SvgColor* color = g_object_new (svg_color_get_type (), NULL);
    gchar* success = svg_parser_parse_color(color, string, string+strlen(string));
    if (success==NULL) {
        /*TODO*/
    }

    return color;
}


SvgColor *
svg_color_new_from_argb(guint32 value)
{
    SvgColor* color = g_object_new (svg_color_get_type (), NULL);
    color->type  = SVG_COLOR_RGB;
    color->value = value;

    return color;
}

guint8 svg_color_value_get_alpha(guint32 value)
{
    return (value & 0xFF000000) >> 24;
}
guint8 svg_color_value_get_red(guint32 value)
{
    return (value & 0x00FF0000) >> 16;
}
guint8 svg_color_value_get_green(guint32 value)
{
    return (value & 0x0000FF00) >> 8;
}
guint8 svg_color_value_get_blue(guint32 value)
{
    return (value & 0x000000FF);
}


void svg_color_value_set_alpha(guint8 alpha, guint32 *value)
{
    *value = (*value & 0x00FFFFFF) | alpha << 24;
}
void svg_color_value_set_red(guint8 red,   guint32 *value)
{
    *value = (*value & 0xFF00FFFF) | red << 16;
}
void svg_color_value_set_green(guint8 green, guint32 *value)
{
    *value = (*value & 0xFFFF00FF) | green << 8;
}
void svg_color_value_set_blue(guint8 blue,  guint32 *value)
{
    *value = (*value & 0xFFFFFF00) | blue;
}


guint8 svg_color_get_alpha(SvgColor* color)
{
    return (color->value & 0xFF000000) >> 24;
}
guint8 svg_color_get_red(SvgColor* color)
{
    return (color->value & 0x00FF0000) >> 16;
}
guint8 svg_color_get_green(SvgColor* color)
{
    return (color->value & 0x0000FF00) >> 8;
}
guint8 svg_color_get_blue(SvgColor* color)
{
    return (color->value & 0x000000FF);
}

void
svg_color_set_alpha(SvgColor* color, guint8 alpha)
{
    color->value = (color->value & 0x00FFFFFF) | alpha << 24;
}
void
svg_color_set_red(SvgColor* color, guint8 red)
{
    color->value = (color->value & 0xFF00FFFF) | red << 16;
}
void
svg_color_set_green(SvgColor* color, guint8 green)
{
    color->value = (color->value & 0xFFFF00FF) | green << 8;
}
void
svg_color_set_blue(SvgColor* color, guint8 blue)
{
    color->value = (color->value & 0xFFFFFF00) | blue;
}

gboolean
svg_color_is_none(SvgColor* color)
{
    return color->type == SVG_COLOR_NONE;
}

GraphicsColor*
svg_color_to_graphics_color(SvgColor *svg_color)
{
    GraphicsColor *color;

    if (svg_color->type == SVG_COLOR_NONE)
        return NULL;

    color = graphics_color_new();

    color->red   = svg_color_get_red  (svg_color) / 255.0;
    color->green = svg_color_get_green(svg_color) / 255.0;
    color->blue  = svg_color_get_blue (svg_color) / 255.0;
    color->alpha = svg_color_get_alpha(svg_color) / 255.0;

    return color;
}

gchar *
svg_color_to_string(SvgColor* color)
{
    gchar* string;
    /*switch (color->type) {
    case SVG_COLOR_ARGB:
        string = g_strdup_printf("rgba(%d, %d, %d, %d)", );
    break;
    case SVG_COLOR_CURRENT:
        string = g_strdup_printf("hinerit");
    break;
    case SVG_COLOR_CURRENT:
        string = g_strdup_printf("hinerit");
    break;
    }*/
    string = g_strdup_printf("0x%X", color->value);
    return string;
}
