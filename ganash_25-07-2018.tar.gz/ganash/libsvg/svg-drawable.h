/*
 * svg-drawable.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_DRAWABLE_H__
#define __SVG_DRAWABLE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_DRAWABLE                (svg_drawable_get_type ())
#define SVG_DRAWABLE(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  SVG_TYPE_DRAWABLE,  SvgDrawable))
#define SVG_IS_DRAWABLE(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  SVG_TYPE_DRAWABLE))
#define SVG_DRAWABLE_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  SVG_TYPE_DRAWABLE,  SvgDrawableInterface))

typedef struct _SvgDrawable  SvgDrawable; /* dummy object */
typedef struct _SvgDrawableInterface  SvgDrawableInterface;

struct _SvgDrawableInterface
{
	GTypeInterface parent;
    void (*draw)   ( SvgDrawable *self, cairo_t *cr);
};

GType  svg_drawable_get_type (void);
void svg_drawable_draw (SvgDrawable *self, cairo_t *cr);

G_END_DECLS

#endif /* __SVG_DRAWABLE_H__ */

