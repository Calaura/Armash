﻿/*
 * svg-element-animation.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib.h>

#include <liblog/log.h>

#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"
#include "libmotion/motion-easing.h"
#include "libmotion/motion-easing-linear.h"

#include <libgraphics/graphics.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-time.h"
#include "svg-animated.h"
#include "svg-element.h"
#include "svg-time-container.h"
#include "svg-document.h"

#include "svg-element-animation.h"




Condition *
svg_condition_new()
{
    Condition *condition;
    condition = g_new(Condition, 1);
    //svg_condition_init(condition);
    return condition;
}
void
svg_condition_free(Condition *condition)
{
    g_free(condition);
}






static float  EPSILON_FL = 0.0;
static double EPSILON_DL = 0.0;

static void      svg_element_animation_resolve_first_interval(SvgElementAnimation *animation);
static void      svg_element_animation_resolve_next_interval(SvgElementAnimation *animation, gboolean notify_dependents);

static int       svg_element_animation_init_from_xml(DomNode *element, xmlNode* node);
static gboolean  svg_element_animation_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value);
static gboolean  svg_element_animation_parse_times(SvgElement *element, GArray *times, guchar* value);

static void svg_element_animation_class_init(SvgElementAnimationClass *klass);
static void svg_element_animation_init(SvgElementAnimation *gobject);

G_DEFINE_TYPE (SvgElementAnimation, svg_element_animation, SVG_TYPE_ELEMENT)
#define parent_class svg_element_animation_parent_class


gboolean
svg_element_animation_default_update_animation(SvgElementAnimation *animation,
                                               float percent,
                                               unsigned repeat,
                                               SvgElementAnimation* resultElement)
{
    g_print("%s\n", G_STRFUNC);
    return FALSE;
}

static void
svg_element_animation_class_init(SvgElementAnimationClass *klass)
{
    GObjectClass    *g_object_class;
    DomNodeClass    *dom_class;
    SvgElementClass *svgelement_class;

    dom_class  = (DomNodeClass *) klass;
    g_object_class   = (GObjectClass *) klass;
    svgelement_class = (SvgElementClass *) klass;

    dom_class->init_from_xml          = svg_element_animation_init_from_xml;
    svgelement_class->parse_attribute = svg_element_animation_parse_attribute;

    klass->update_animation  = svg_element_animation_default_update_animation;
    klass->is_additive = NULL; // Not implemented
    klass->reset_animated_type = NULL; // Not implemented
    klass->clear_animated_type = NULL; // Not implemented
    klass->apply_results_to_target = NULL; // Not implemented
    klass->started_active_interval = NULL; // Not implemented

//	svg_element_animation_parent_class = g_type_class_peek_parent (klass);

    EPSILON_DL = 1.0;
    do{
        EPSILON_DL /= 2.0;
    } while ((double)(1.0 + (EPSILON_DL/2.0)) != 1.0);
    EPSILON_FL = 1.0;
    do{
        EPSILON_FL /= 2.0;
    } while ((float)(1.0 + (EPSILON_FL/2.0)) != 1.0);

}

static void
svg_element_animation_init (SvgElementAnimation *object)
{
    object->attribute_name = NULL;
    object->attribute_type = NULL;

    /* g_object_class->constructor = svg_element_animate_constructor; */
    object->begin = svg_time_new();
    object->dur   = svg_time_new();
    object->end   = svg_time_new();

    object->begin_times = g_array_new(FALSE, FALSE, sizeof(SvgTimeRelative));// of SmilTimeRelative
    object->end_times = g_array_new(FALSE, FALSE, sizeof(SvgTimeRelative));//  of SmilTimeRelative
#if 1
    SvgTimeRelative time = {{2.0, 1, 0}, 0};
    g_array_append_val(object->end_times, time);
#endif

    object->target = NULL;// Ptr<Null>

    object->conditions = NULL;//g_array_new(FALSE, FALSE, sizeof(Condition));// of SmilCondition

    object->conditions_connected = FALSE;
    object->has_end_event_conditions = FALSE;
    object->is_waiting_for_first_interval = TRUE;
    svg_time_set_unresolved(&object->interval_begin);
    svg_time_set_unresolved(&object->interval_end);
    svg_time_set_unresolved(&object->previous_interval_begin);
    object->active_state = SmilStateInactive;
    object->last_percent = 0.0;
    object->last_repeat = 0;
    object->next_progress_time.seconds = 0.0;

    object->cached_dur.seconds = -1.0;
    object->cached_repeat_dur.seconds = -1.0;
    object->cached_repeat_count.seconds = -1.0;
    object->cached_min.seconds = -1.0;
    object->cached_max.seconds = -1.0;

    object->animation_mode = NoAnimation;
}



/* virtual function */


static int
svg_element_animation_init_from_xml(DomNode* element, xmlNode* node)
{
    DomDocument         *doc = dom_node_get_document(element);
    SvgDocument         *document = SVG_DOCUMENT(doc);
    SvgElementAnimation *animation = SVG_ELEMENT_ANIMATION(element);

    int success = DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);

    // Compute the hash [dom_element_get_instance_id(target), css:stroke-width]
    DomQualifiedName attribute_name = {animation->attribute_type, animation->attribute_name};
    if (!animation->attribute_type) {
        attribute_name.prefix = g_strdup("xml");// TODO free it
    }

    // @TODO: check xlink:href
    SvgElement          *target  = SVG_ELEMENT(node->parent->_private);

    animation->time_container = document->time_container;
    animation->target = target;
    svg_time_container_schedule(animation->time_container, animation, animation->target, &attribute_name);

    svg_element_animation_resolve_first_interval(animation);

    return success;
}

static gboolean
svg_element_animation_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_ANIMATION(element));
    SvgElementAnimation *animation = SVG_ELEMENT_ANIMATION(element);

    DomQualifiedName svg_qualified_attributename = {"svg", "attributename"};
    DomQualifiedName svg_qualified_attributetype = {"svg", "attributetype"};
    DomQualifiedName svg_qualified_begin         = {"svg", "begin"};
    DomQualifiedName svg_qualified_end           = {"svg", "end"};
    DomQualifiedName svg_qualified_dur           = {"svg", "dur"};

    if        (dom_qualified_name_equ(qualified_name, &svg_qualified_attributename)) {
        /*svg_element_animatable_is_supported_attribute_name(element->parent, attribute_name);*/
        animation->attribute_name = g_strdup(value);
    } else if (dom_qualified_name_equ(qualified_name, &svg_qualified_attributetype)) {
        /*svg_element_animatable_is_supported_attribute_type(element->parent, attributetype);*/
        animation->attribute_type = g_strdup(value);
    } else if (dom_qualified_name_equ(qualified_name, &svg_qualified_begin)) {
        svg_time_list_set_value_from_string((SvgTimeList*) animation->begin_times, value);
        //svg_time_set_value_from_string(animation->begin, value);
        //animation->begin->empty = FALSE;
    } else if (dom_qualified_name_equ(qualified_name, &svg_qualified_end)) {
        svg_time_list_set_value_from_string((SvgTimeList*) animation->end_times, value);
        //svg_time_set_value_from_string(animation->end, value);
        //animation->end->empty = FALSE;
    } else if (dom_qualified_name_equ(qualified_name, &svg_qualified_dur)) {
        svg_time_set_value_from_string(animation->dur, value);
        animation->dur->empty = FALSE;
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

static gboolean
svg_element_animation_parse_times(SvgElement *element, GArray *times, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_ANIMATION(element));
    SvgElementAnimation *animation = SVG_ELEMENT_ANIMATION(element);


    return TRUE;
}

SvgElementAnimation *
svg_element_animation_new (void)
{
	return g_object_new (svg_element_animation_get_type (),
	                     NULL);
}

SvgElement*
svg_element_animation_get_target(SvgElementAnimation *animation)
{
    return animation->target;
}

gdouble
svg_element_animation_get_start_time(SvgElementAnimation *animation)
{
    gdouble begin, end;

    if (!animation->begin->empty) {
        begin = animation->begin->seconds;
        if (!animation->end->empty) {
            end = animation->end->seconds;
        } else if (!animation->dur->empty) {
            end = begin + animation->dur->seconds;
        } else {
            //times_success = FALSE;
        }
    } else if (!animation->end->empty) {
        end = animation->end->seconds;
        if (!animation->dur->empty) {
            begin = end - animation->dur->seconds;
        } else {
            //times_success = FALSE;
        }
    } else {
        //times_success = FALSE;
    }

    return begin;
}

/**
 * @brief svg_animation_element_get_current_time
 * @param animation
 * @return gdouble Returns the current time in seconds relative to time zero for the given time container.
 */
gdouble
svg_element_animation_get_current_time(SvgElementAnimation *animation)
{

    return 0.0;
}

gdouble
svg_element_animation_get_simple_duration(SvgElementAnimation *animation)
{
    float dur = animation->dur->seconds;
    if (dur < SVG_TIME_INDEFINITE_VALUE) {
        return animation->dur->seconds;
    } else {
        return SVG_TIME_INDEFINITE_VALUE;
    }

    /*
    gdouble begin, end;

    if (!animation->begin->empty) {
        begin = animation->begin->seconds;
        if (!animation->end->empty) {
            end = animation->end->seconds;
        } else if (!animation->dur->empty) {
            end = begin + animation->dur->seconds;
        } else {
            //times_success = FALSE;
        }
    } else if (!animation->end->empty) {
        end = animation->end->seconds;
        if (!animation->dur->empty) {
            begin = end - animation->dur->seconds;
        } else {
            //times_success = FALSE;
        }
    } else {
        //times_success = FALSE;
    }

    return end - begin;
    */
}

void
svg_element_animation_begin_element(SvgElementAnimation *animation)
{
    svg_element_animation_begin_element_at(animation, 0.0);
}

void
svg_element_animation_begin_element_at(SvgElementAnimation *animation, float offset)
{
//    if (std::isnan(offset))
//        return;
    SvgTime eventTime = {0.0, SVG_TIME_TYPE_FULL, TRUE};
    SvgTime elapsed;
    svg_element_animation_elapsed(animation, &elapsed);
//    svg_element_animation_add_begin_time(animation, elapsed, elapsed + offset, SMILTimeWithOrigin::ScriptOrigin);
    eventTime.seconds = elapsed.seconds;
    elapsed.seconds += offset;
    svg_element_animation_add_begin_time(animation, &eventTime, &elapsed, SvgOriginScript);
}

void
svg_element_animation_end_element(SvgElementAnimation *animation)
{
    svg_element_animation_end_element_at(animation, 0.0);
}

void
svg_element_animation_end_element_at(SvgElementAnimation *animation, float offset)
{
//    if (std::isnan(offset))
//        return;
    SvgTime eventTime = {0.0, SVG_TIME_TYPE_FULL, TRUE};
    SvgTime elapsed;
    svg_element_animation_elapsed(animation, &elapsed);
    eventTime.seconds = elapsed.seconds;
    elapsed.seconds += offset;
    svg_element_animation_add_end_time(animation, &eventTime, &elapsed, SvgOriginScript);
}



SvgAnimated *svg_element_animatable_get_property(SvgElement *element, gchar *name)
{
    gchar *property_name = g_strdup_printf("%s", name);

    GValue g_value = G_VALUE_INIT;
    g_value_init(&g_value, G_TYPE_POINTER);
    /*if has*/

    /*svg_element_is_supported_attribute(element, property_name);*/
    if(TRUE)
        g_object_get_property((GObject *) element, property_name, &g_value);
    else {
        g_print("element has not property %s\n", property_name);
        return NULL;
    }

    g_free(property_name);

    return (SvgAnimated *) g_value_get_pointer(&g_value);
}

void
svg_element_animation_elapsed(SvgElementAnimation *animation, SvgTime *elapsed)
{
    if (animation->time_container) {
        svg_time_container_elapsed(animation->time_container, elapsed);
    } else {
        elapsed->seconds = 0.0;
    }
}


void
svg_element_animation_dur(SvgElementAnimation *animation, SvgTime* time)
{
    const gdouble invalidCachedTime = -1.0;
    if (animation->cached_dur.seconds != invalidCachedTime) {
        *time = animation->cached_dur;
        return;
    }

    SvgTime clock_value;
    gchar *value = dom_element_get_attribute(DOM_ELEMENT(animation), &DOM_QUALIFIED_NAME("SVG", "dur"));
    svg_time_set_value_from_string(&clock_value, value);
    animation->cached_dur.seconds = clock_value.seconds <= 0 ? SVG_TIME_UNRESOLVED_VALUE : clock_value.seconds;
    *time = animation->cached_dur;
    //const AtomicString& value = fastGetAttribute(SVGNames::durAttr);
    //SMILTime clockValue = parseClockValue(value);
    //return m_cachedDur = clockValue <= 0 ? SMILTime::unresolved() : clockValue;
}

void
svg_element_animation_repeat_dur(SvgElementAnimation *animation, SvgTime *time)
{
    const gdouble invalidCachedTime = -1.0;

    if (animation->cached_repeat_dur.seconds != invalidCachedTime) {
        *time = animation->cached_repeat_dur;
        return;
    }

    SvgTime clock_value;
    gchar *value = dom_element_get_attribute(DOM_ELEMENT(animation), &DOM_QUALIFIED_NAME("SVG", "repeatDur"));
    svg_time_set_value_from_string(&clock_value, value);
    animation->cached_repeat_dur.seconds = clock_value.seconds <= 0 ? SVG_TIME_UNRESOLVED_VALUE : clock_value.seconds;
    *time = animation->cached_repeat_dur;
//    const AtomicString& value = fastGetAttribute(SVGNames::repeatDurAttr);
//    SMILTime clockValue = parseClockValue(value);
//    m_cachedRepeatDur = clockValue <= 0 ? SMILTime::unresolved() : clockValue;
//    return m_cachedRepeatDur;
}

// So a count is not really a time but let just all pretend we did not notice.
void
svg_element_animation_repeat_count(SvgElementAnimation *animation, SvgTime *time)
{
    const gdouble invalidCachedTime = -1.0;
    if (animation->cached_repeat_count.seconds != invalidCachedTime) {
        *time = animation->cached_repeat_count;
        return;
    }

    //CSS_PROPERTY_STROKE_COLOR;
    //SVG_ATTRIBUTE_REPEAT_COUNT;
    SvgTime clock_value;
    gchar *value = dom_element_get_attribute(DOM_ELEMENT(animation), &DOM_QUALIFIED_NAME("SVG", "repeatCount"));
    if (!value) {
        time->seconds = SVG_TIME_UNRESOLVED_VALUE;
        return;
    }
    svg_time_set_value_from_string(&clock_value, value);
    animation->cached_repeat_dur.seconds = clock_value.seconds <= 0 ? SVG_TIME_UNRESOLVED_VALUE : clock_value.seconds;
    *time = animation->cached_repeat_dur;


//    const AtomicString& value = fastGetAttribute(SVGNames::repeatCountAttr);
//    if (value.isNull())
//        return SMILTime::unresolved();

//    DEFINE_STATIC_LOCAL(const AtomicString, indefiniteValue, ("indefinite", AtomicString::ConstructFromLiteral));
//    if (value == indefiniteValue)
//        return SMILTime::indefinite();
//    bool ok;
//    double result = value.string().toDouble(&ok);
//    return m_cachedRepeatCount = ok && result > 0 ? result : SMILTime::unresolved();
}


static int
approximateBinarySearch(GArray *array, gdouble key)
{
    guint size = array->len;
    size_t offset = 0;
    while (size > 1) {
        int pos = (size - 1) >> 1;
        //KeyType val = extractKey(&array[offset + pos]);
        SvgTimeRelative *time_relative = &g_array_index(array, SvgTimeRelative, offset+pos);
        gdouble val = SVG_TIME(&time_relative->time)->seconds;

        if (val == key)
            return offset+pos;
        // The item we are looking for is smaller than the item being check; reduce the value of 'size',
        // chopping off the right hand half of the array.
        if (key < val)
            size = pos;
        // Discard all values in the left hand half of the array, up to and including the item at pos.
        else {
            size -= (pos + 1);
            offset += (pos + 1);
        }

        //g_assert(mode != KeyMustBePresentInArray || size);
    }


    /*if (mode == KeyMightNotBePresentInArray && !size)
        return 0;*/

    //ArrayElementType* result = &array[offset];

    /*if (mode == KeyMightNotBePresentInArray && key != extractKey(result))
        return 0;*/

    /*if (mode == KeyMustBePresentInArray) {
        ASSERT(size == 1);
        ASSERT(key == extractKey(result));
    }*/

    return offset;
}

int sort_compare(gpointer a, gpointer b) {
 SvgTimeRelative* x = (SvgTimeRelative*)a;
 SvgTimeRelative* y = (SvgTimeRelative*)b;
 return x->time.seconds - y->time.seconds;
}


static
void svg_element_animation_find_instance_time(
        SvgElementAnimation *animation,
        SvgTime *time,
        BeginOrEnd beginOrEnd,
        SvgTime *minimumTime,
        gboolean equalsMinimumOK)
{
    GArray *list = beginOrEnd == SmilBegin ? animation->begin_times : animation->end_times;
    int sizeOfList = list->len;

    if (!sizeOfList) {
        beginOrEnd == SmilBegin ? svg_time_set_unresolved(time) : svg_time_set_indefinite(time);
        return;
    }

    SvgTimeRelative *begin = &g_array_index(list, SvgTimeRelative, 0);
    int indexOfResult = approximateBinarySearch(list, minimumTime->seconds);
    SvgTimeRelative *result = &g_array_index(list, SvgTimeRelative, indexOfResult);
    SvgTime *currentTime = SVG_TIME(result);

    // The special value "indefinite" does not yield an instance time in the begin list.
    if (svg_time_is_indefinite(currentTime) && beginOrEnd == SmilBegin) {
        svg_time_set_unresolved(time);
        return;
    }

    if (currentTime->seconds < minimumTime->seconds) {
        beginOrEnd == SmilBegin ? svg_time_set_unresolved(time) : svg_time_set_indefinite(time);
        return;
    }
    if (currentTime->seconds > minimumTime->seconds) {
        *time = *currentTime;
        return;
    }

    g_assert(currentTime->seconds == minimumTime->seconds);
    if (equalsMinimumOK) {
        *time = *currentTime;
        return;
    }

    // If the equals is not accepted, return the next bigger item in the list.
    while (indexOfResult < sizeOfList - 1) {
        SvgTimeRelative *nextTimeRelative = &g_array_index(list, SvgTimeRelative, indexOfResult+1);
        SvgTime *nextTime = SVG_TIME(nextTimeRelative);

        if (nextTime->seconds > minimumTime->seconds) {
            *time = *nextTime;
            return;
        }

        ++indexOfResult;
    }

    beginOrEnd == SmilBegin ? svg_time_set_unresolved(time) : svg_time_set_indefinite(time);
    return;
}

static
void svg_element_animation_seek_to_interval_corresponding_to_time(
        SvgElementAnimation *animation, SvgTime *elapsed)
{
    g_assert(!animation->is_waiting_for_first_interval);
    g_assert(elapsed->seconds >= animation->interval_begin.seconds);


    // Manually seek from interval to interval, just as if the animation would run regulary.
    while (TRUE) {
        // Figure out the next value in the begin time list after the current interval begin.
        SvgTime next_begin;
        svg_element_animation_find_instance_time(animation, &next_begin, SmilBegin, &animation->interval_begin, FALSE);

        // If the 'nextBegin' time is unresolved (eg. just one defined interval), we're done seeking.
        if (svg_time_is_unresolved(&next_begin))
            return;

        // If the 'nextBegin' time is larger than or equal to the current interval end time, we're done seeking.
        // If the 'elapsed' time is smaller than the next begin interval time, we're done seeking.
        if (next_begin.seconds < animation->interval_end.seconds && elapsed->seconds >= next_begin.seconds) {
            // End current interval, and start a new interval from the 'nextBegin' time.
            animation->interval_end.seconds = next_begin.seconds;
            svg_element_animation_resolve_next_interval(animation, FALSE);
            continue;
        }

        // If the desired 'elapsed' time is past the current interval, advance to the next.
        if (elapsed->seconds >= animation->interval_end.seconds) {
            svg_element_animation_resolve_next_interval(animation, FALSE);
            continue;
        }

        return;
    }

}

static void
svg_element_animation_max(SvgElementAnimation *animation, SvgTime *result)
{
    const double invalidCachedTime = -1.0;
    if (animation->cached_max.seconds != invalidCachedTime) {
        result->seconds = animation->cached_max.seconds;
    }

    SvgTime clock_value = {SVG_TIME_INDEFINITE_VALUE, SVG_TIME_TYPE_FULL, 0};
    gchar *value = dom_element_get_attribute(DOM_ELEMENT(animation), &DOM_QUALIFIED_NAME("SVG", "max"));
    svg_time_set_value_from_string(&clock_value, value);
    gdouble indefinite = SVG_TIME_INDEFINITE_VALUE;
    animation->cached_max.seconds = svg_time_is_unresolved(&clock_value) || clock_value.seconds < 0.0 ? indefinite : clock_value.seconds;
    *result = animation->cached_max;
}

static void
svg_element_animation_min(SvgElementAnimation *animation, SvgTime *result)
{
    const double invalidCachedTime = -1.0;
    if (animation->cached_min.seconds != invalidCachedTime) {
        *result = animation->cached_min;
        return;
    }


    SvgTime clock_value;
    gchar *value = dom_element_get_attribute(DOM_ELEMENT(animation), &DOM_QUALIFIED_NAME("SVG", "min"));
    svg_time_set_value_from_string(&clock_value, value);
    animation->cached_min.seconds = svg_time_is_unresolved(&clock_value) || clock_value.seconds < 0 ? 0.0 : clock_value.seconds;
    *result = animation->cached_min;
}


static void
svg_element_animation_repeating_duration(SvgElementAnimation *animation, SvgTime *result)
{
    // Computing the active duration
    // http://www.w3.org/TR/SMIL2/smil-timing.html#Timing-ComputingActiveDur
    SvgTime repeat_count;
    svg_element_animation_repeat_count(animation, &repeat_count);
    SvgTime repeat_dur;
    svg_element_animation_repeat_dur(animation, &repeat_dur);
    gdouble simple_duration = svg_element_animation_get_simple_duration(animation);
    if (!simple_duration || (svg_time_is_unresolved(&repeat_dur) && svg_time_is_unresolved(&repeat_count)) ) {
        result->seconds = simple_duration;
        return;
    }
    SvgTime repeat_count_duration;
    repeat_count_duration.seconds = simple_duration * repeat_count.seconds;
    result->seconds = MIN(repeat_count_duration.seconds, MIN(repeat_dur.seconds, SVG_TIME_UNRESOLVED_VALUE));
}

static void
svg_element_animation_resolve_active_end(SvgElementAnimation *animation,
                                         SvgTime *resolved_begin,
                                         SvgTime *resolved_end,
                                         SvgTime *result)
{
    // Computing the active duration
    // http://www.w3.org/TR/SMIL2/smil-timing.html#Timing-ComputingActiveDur
    SvgTime preliminary_active_duration;

    SvgTime repeating_duration;
    svg_element_animation_repeating_duration(animation, &repeating_duration);
    SvgTime dur;
    svg_element_animation_dur(animation, &dur);
    SvgTime repeat_dur;
    svg_element_animation_repeat_dur(animation, &repeat_dur);
    SvgTime repeat_count;
    svg_element_animation_repeat_count(animation, &repeat_count);
    if (     svg_time_is_unresolved(resolved_begin)
          && svg_time_is_unresolved(&dur)
          && svg_time_is_unresolved(&repeat_dur)
          && svg_time_is_unresolved(&repeat_count)
    ) {
        preliminary_active_duration.seconds = resolved_end->seconds - resolved_begin->seconds;
    } else if (!svg_time_is_finite(resolved_end)) {
        preliminary_active_duration.seconds = repeating_duration.seconds;
    } else {
        preliminary_active_duration.seconds = MIN(repeating_duration.seconds, resolved_end->seconds - resolved_begin->seconds);
    }

    SvgTime min;
    svg_element_animation_min(animation, &min);
    SvgTime max;
    svg_element_animation_max(animation, &max);

    if (min.seconds > max.seconds) {
        // Ignore both.
        // http://www.w3.org/TR/2001/REC-smil-animation-20010904/#MinMax
        min.seconds = 0;
        max.seconds = SVG_TIME_INDEFINITE_VALUE;
    }

    result->seconds = resolved_begin->seconds + MIN(max.seconds, MAX(min.seconds, preliminary_active_duration.seconds));
}

static void
svg_element_animation_resolve_interval(SvgElementAnimation *animation, gboolean first, SvgTime *beginResult, SvgTime *endResult)
{
    // See the pseudocode in http://www.w3.org/TR/SMIL3/smil-timing.html#q90.
    SvgTime beginAfter;
    beginAfter.seconds = first ? -DBL_MAX : animation->interval_end.seconds;
    SvgTime last_interval_temp_end;
    last_interval_temp_end.seconds = DBL_MAX;
    while (TRUE) {
        gboolean equalsMinimumOK = !first || animation->interval_end.seconds > animation->interval_begin.seconds;
        SvgTime temp_begin;
        svg_time_init(&temp_begin, 0.0, SVG_TIME_TYPE_FULL, FALSE);
        svg_element_animation_find_instance_time(animation, &temp_begin, SmilBegin, &beginAfter, equalsMinimumOK);
        if (svg_time_is_unresolved(&temp_begin))
            break;
        SvgTime temp_end;
        svg_time_init(&temp_end, 0.0, SVG_TIME_TYPE_FULL, FALSE);
        if (!animation->end_times->len) {
            SvgTime indefinite = SVG_TIME_INDEFINITE;
            svg_element_animation_resolve_active_end(animation, &temp_begin, &indefinite, &temp_end);
        }
        else {
            svg_element_animation_find_instance_time(animation, &temp_end, SmilEnd, &temp_begin, TRUE);
            if (  (first
                   && temp_begin.seconds == temp_end.seconds
                   && temp_end.seconds == last_interval_temp_end.seconds)
                 || (!first && temp_end.seconds == animation->interval_end.seconds)
            ) {
                svg_element_animation_find_instance_time(animation, &temp_end, SmilEnd, &temp_begin, FALSE);
            }
            if (svg_time_is_unresolved(&temp_end)) {
                if (animation->end_times->len && animation->has_end_event_conditions)
                    break;
            }
            svg_element_animation_resolve_active_end(animation, &temp_begin, &temp_end, &temp_end);
        }
        if (!first || (temp_end.seconds > 0 || (!temp_begin.seconds && !temp_end.seconds))) {
            beginResult->seconds = temp_begin.seconds;
            endResult->seconds = temp_end.seconds;
            return;
        }

        beginAfter.seconds = temp_end.seconds;
        last_interval_temp_end.seconds = temp_end.seconds;
    }
    beginResult->seconds = SVG_TIME_UNRESOLVED_VALUE;
    endResult->seconds = SVG_TIME_UNRESOLVED_VALUE;
}

static void
svg_element_animation_resolve_first_interval(SvgElementAnimation *animation)
{
    SvgTime begin;
    SvgTime end;
    svg_element_animation_resolve_interval(animation, TRUE, &begin, &end);
    g_assert(!svg_time_is_indefinite(&begin));

    if (!svg_time_is_unresolved(&begin)
        && (begin.seconds != animation->interval_begin.seconds
            || end.seconds != animation->interval_end.seconds)) {
        gboolean was_unresolved = svg_time_is_unresolved(&animation->interval_begin);
        animation->interval_begin = begin;
        animation->interval_end = end;

        svg_element_animation_notify_dependents_interval_changed(animation, was_unresolved ? NewInterval : ExistingInterval);
        animation->next_progress_time.seconds = MIN(animation->next_progress_time.seconds, animation->interval_begin.seconds);

        //if (animation->time_container)
        //    svg_time_container_notify_intervals_changed(animation->time_container);
    }
}

static void
svg_element_animation_resolve_next_interval(SvgElementAnimation *animation,
                                            gboolean notify_dependents)
{
    SvgTime begin;
    SvgTime end;
    svg_element_animation_resolve_interval(animation, FALSE, &begin, &end);
    g_assert(!svg_time_is_indefinite(&begin));

    if (!svg_time_is_unresolved(&begin) && begin.seconds != animation->interval_begin.seconds) {
        animation->interval_begin.seconds = begin.seconds;
        animation->interval_end.seconds = end.seconds;

        if (notify_dependents)
          svg_element_animation_notify_dependents_interval_changed(animation, NewInterval);
        animation->next_progress_time.seconds = MIN(animation->next_progress_time.seconds, animation->interval_begin.seconds);
    }
}

void
svg_element_animation_notify_dependents_interval_changed(SvgElementAnimation *animation, NewOrExistingInterval newOrExisting)
{
    //DEPRECATED_DEFINE_STATIC_LOCAL(HashSet<SVGSMILElement*>, loopBreaker, ());
    static GList *loopBreaker = NULL;

    g_assert(svg_time_is_finite(&animation->interval_begin));
    GList *data = g_list_find(loopBreaker, animation);
    if (data)
        return;

    loopBreaker = g_list_append(loopBreaker, animation);
    GList *list = NULL;
    for (list = g_list_first(animation->time_dependents); list; list = g_list_next(list)) {
        SvgElementAnimation *dependent = list->data;
        svg_element_animation_create_instance_times_from_syncbase(dependent, animation, newOrExisting);
    }
    loopBreaker = g_list_remove(loopBreaker, animation);

}

void
svg_element_animation_create_instance_times_from_syncbase(SvgElementAnimation *animation, SvgElementAnimation *syncbase, NewOrExistingInterval interval)
{
    // FIXME: To be really correct, this should handle updating exising interval by changing
    // the associated times instead of creating new ones.
    GList *list = NULL;
    for (list = g_list_first(animation->conditions); list; list = g_list_next(list)) {
        Condition *condition = list->data;
        if (condition->type == Syncbase && condition->syncbase == syncbase) {
            //g_assert(condition->name == "begin" || condition->name == "end");
            SvgTime time = {0.0, 0, 0};
            if (g_ascii_strcasecmp(condition->name, "begin")==0)
                time.seconds = syncbase->interval_begin.seconds + condition->offset.seconds;
            else
                time.seconds = syncbase->interval_end.seconds + condition->offset.seconds;
            if (!svg_time_is_finite(&time))
                continue;

            SvgTime eventTime;
            svg_element_animation_elapsed(animation, &eventTime);
            if (condition->begin_or_end == SmilBegin)
                svg_element_animation_add_begin_time(animation, &eventTime, &time, SvgOriginParser);
            else
                svg_element_animation_add_end_time(animation, &eventTime, &time, SvgOriginParser);
        }
    }
}

void
svg_element_animation_add_time_dependent(SvgElementAnimation *animation, SvgElementAnimation *element)
{
    animation->time_dependents = g_list_append(animation->time_dependents, element);
    if (svg_time_is_finite(&animation->interval_begin))
        svg_element_animation_create_instance_times_from_syncbase(animation, element, NewInterval);
}

void
svg_element_animation_remove_time_dependent(SvgElementAnimation *animation, SvgElementAnimation *element)
{
    animation->time_dependents = g_list_remove(animation->time_dependents, element);
}


SmilStateType
svg_element_animation_determine_active_state(SvgElementAnimation *animation, SvgTime *elapsed)
{
    if (elapsed->seconds >= animation->interval_begin.seconds && elapsed->seconds < animation->interval_end.seconds)
        return SmilStateActive;

    FillMode fill = svg_element_animation_fill(animation);
    return fill == FillFreeze ? SmilStateFrozen : SmilStateInactive;
}

#include <math.h>
void
svg_element_animation_calculate_animation_percent_and_repeat (
    SvgElementAnimation *animation, SvgTime *elapsed
  , float *percent, unsigned *repeat
) {
    SvgTime simpleDuration;
    simpleDuration.seconds = svg_element_animation_get_simple_duration(animation);
    *repeat = 0;
    if (svg_time_is_indefinite(&simpleDuration)) {
        *repeat = 0;
        return 0.f;
    }
    if (!simpleDuration.seconds) {
        *repeat = 0;
        return 1.f;
    }
    g_assert(svg_time_is_finite(&animation->interval_begin));
    g_assert(svg_time_is_finite(&simpleDuration));
    SvgTime activeTime;
    activeTime.seconds = elapsed->seconds - animation->interval_begin.seconds;

    SvgTime repeatingDuration;
    svg_element_animation_repeating_duration(animation, &repeatingDuration);
    if (elapsed->seconds >= animation->interval_end.seconds || activeTime.seconds > repeatingDuration.seconds) {
        *repeat = (unsigned)(repeatingDuration.seconds / simpleDuration.seconds) - 1;

        double epsilon = EPSILON_FL;
        double dbl_percent = (animation->interval_end.seconds - animation->interval_begin.seconds) / simpleDuration.seconds;
        dbl_percent = dbl_percent - floor(dbl_percent);
        if (dbl_percent < epsilon || 1.0 - dbl_percent < epsilon) {
            *percent = 1.0;
            return;
        }
        *percent = dbl_percent; //narrowPrecisionToFloat(percent);
        return;
    }

    *repeat = (unsigned)(activeTime.seconds / simpleDuration.seconds);
    SvgTime simpleTime;
    simpleTime.seconds = fmod(activeTime.seconds, simpleDuration.seconds);
    *percent = (float)(simpleTime.seconds / simpleDuration.seconds);// narrowPrecisionToFloat(simpleTime.value() / simpleDuration.value());
    return;
}

void
svg_element_animation_calculate_next_progress_time(SvgElementAnimation *animation, SvgTime *elapsed, SvgTime *next_progress_time)
{
    if (animation->active_state == SmilStateActive) {
        // If duration is indefinite the value does not actually change over time. Same is true for <set>.
        SvgTime simple_duration;
        simple_duration.seconds = svg_element_animation_get_simple_duration(animation);
        if (svg_time_is_indefinite(&simple_duration) /*|| hasTagName(SVGNames::setTag)*/) {
            SvgTime repeatingDuration;
            svg_element_animation_repeating_duration(animation, &repeatingDuration);
            SvgTime repeatingDurationEnd;
            repeatingDurationEnd.seconds = animation->interval_begin.seconds + repeatingDuration.seconds;
            // We are supposed to do freeze semantics when repeating ends, even if the element is still active.
            // Take care that we get a timer callback at that point.
            if (elapsed->seconds < repeatingDurationEnd.seconds && repeatingDurationEnd.seconds < animation->interval_end.seconds && svg_time_is_finite(&repeatingDurationEnd))
                next_progress_time->seconds = repeatingDurationEnd.seconds;
            else
                next_progress_time->seconds = animation->interval_end.seconds;
            return;
        }
        next_progress_time->seconds = elapsed->seconds + 0.025;
        return;
    }
    next_progress_time->seconds = animation->interval_begin.seconds >= elapsed->seconds ? animation->interval_begin.seconds : SVG_TIME_UNRESOLVED_VALUE;
    return;
}


FillMode
svg_element_animation_fill(SvgElementAnimation *animation)
{
    gchar *value = dom_element_get_attribute(DOM_ELEMENT(animation), &DOM_QUALIFIED_NAME("SVG", "fill"));
    if (value && g_ascii_strcasecmp(value, "freeze")==0) {
        return FillFreeze;
    }
    return FillRemove;
}

static gboolean
svg_element_animation_is_contributing(SvgElementAnimation* animation, SvgTime* elapsed)
{
    // Animation does not contribute during the active time if it is past its repeating duration and has fill=remove.
//    return (m_activeState == Active && (fill() == FillFreeze || elapsed <= m_intervalBegin + repeatingDuration())) || m_activeState == Frozen;
    FillMode fill = svg_element_animation_fill(animation);
    SvgTime repeating_duration;
    svg_element_animation_repeating_duration(animation, &repeating_duration);

    return (animation->active_state == SmilStateActive && (fill == FillFreeze || elapsed->seconds <= animation->interval_begin.seconds + repeating_duration.seconds)) || animation->active_state == SmilStateFrozen;
}

Restart
svg_element_animation_restart(SvgElementAnimation *animation)
{
    gchar *value = dom_element_get_attribute(DOM_ELEMENT(animation), &DOM_QUALIFIED_NAME("SVG", "restart"));
    if (value && g_ascii_strcasecmp(value, "never")==0) {
        return RestartNever;
    }
    if (value && g_ascii_strcasecmp(value, "whenNotActive")==0) {
        return RestartWhenNotActive;
    }
    return RestartAlways;
}


static void
svg_element_animation_check_restart(SvgElementAnimation *animation, SvgTime *elapsed)
{
    g_assert(!animation->is_waiting_for_first_interval);
    g_assert(elapsed->seconds >= animation->interval_begin.seconds);

    Restart restart = svg_element_animation_restart(animation);
    if (restart == RestartNever)
        return;

    if (elapsed->seconds < animation->interval_end.seconds) {
        if (restart != RestartAlways)
            return;
        SvgTime nextBegin;
        svg_element_animation_find_instance_time(animation, &nextBegin, SmilBegin, &animation->interval_begin, FALSE);
        if (nextBegin.seconds < animation->interval_end.seconds) {
            animation->interval_end.seconds = nextBegin.seconds;
            svg_element_animation_notify_dependents_interval_changed(animation, ExistingInterval);
        }
    }

    if (elapsed->seconds >= animation->interval_end.seconds)
        svg_element_animation_resolve_next_interval(animation, TRUE);
}


static void
clearTimesWithDynamicOrigins(GArray *timeList)
{
    int i;
    for (i = timeList->len - 1; i >= 0; --i) {
        SvgTimeRelative *time = &g_array_index(timeList, SvgTimeRelative, i);
//        if (svg_time_relative_origin_is_script(time))
//            timeList.remove(i);
    }
}

static void
svg_element_animation_ended_active_interval(SvgElementAnimation*animation)
{
    clearTimesWithDynamicOrigins(animation->begin_times);
    clearTimesWithDynamicOrigins(animation->end_times);
}


//inline Element* SVGSMILElement::eventBaseFor(const Condition& condition)
//{
//    return condition.m_baseID.isEmpty() ? targetElement() : treeScope().getElementById(condition.m_baseID);
//}

void
svg_element_animation_connect_conditions(SvgElementAnimation *animation)
{
    if (animation->conditions_connected)
        svg_element_animation_disconnect_conditions(animation);
    animation->conditions_connected = TRUE;

    int n;
    GList *list = NULL;
    for (list = g_list_first(animation->conditions); list; list = g_list_next(list)) {
        Condition *condition = list->data;
        if (condition->type == EventBase) {
            g_assert(!condition->syncbase);
            DomElement* eventBase = NULL;
            if (condition->base_id == NULL )
                svg_element_animation_get_target(animation);
            else
                dom_document_get_element_by_id(DOM_DOCUMENT(dom_node_get_document(DOM_NODE(animation))), condition->base_id, &eventBase);
            if (!eventBase)
                continue;
            g_assert(!condition->event_listener);
//            condition->event_listener = ConditionEventListener::create(animation, &condition);
//            eventBase->addEventListener(condition.m_name, condition.m_eventListener, false);
        } else if (condition->type == Syncbase) {
//            ASSERT(!condition.m_baseID.isEmpty());
//            condition.m_syncbase = treeScope().getElementById(condition.m_baseID);
//            if (!condition.m_syncbase)
//                continue;
//            if (!isSVGSMILElement(*condition.m_syncbase)) {
//                condition.m_syncbase = nullptr;
//                continue;
//            }
//            toSVGSMILElement(*condition.m_syncbase).addTimeDependent(this);
        }
    }
}

void svg_element_animation_disconnect_conditions(SvgElementAnimation *animation)
{
    if (!animation->conditions_connected)
        return;
    animation->conditions_connected = FALSE;
//    for (unsigned n = 0; n < m_conditions.size(); ++n) {
//        Condition& condition = m_conditions[n];
//        if (condition.m_type == Condition::EventBase) {
//            ASSERT(!condition.m_syncbase);
//            if (!condition.m_eventListener)
//                continue;
//            // Note: It's a memory optimization to try to remove our condition
//            // event listener, but it's not guaranteed to work, since we have
//            // no guarantee that eventBaseFor() will be able to find our condition's
//            // original eventBase. So, we also have to disconnect ourselves from
//            // our condition event listener, in case it later fires.
//            Element* eventBase = eventBaseFor(condition);
//            if (eventBase)
//                eventBase->removeEventListener(condition.m_name, condition.m_eventListener.get(), false);
//            condition.m_eventListener->disconnectAnimation();
//            condition.m_eventListener = 0;
//        } else if (condition.m_type == Condition::Syncbase) {
//            if (condition.m_syncbase)
//                toSVGSMILElement(condition.m_syncbase.get())->removeTimeDependent(this);
//        }
//        condition.m_syncbase = 0;
//    }
}


gboolean
svg_element_animation_progress(SvgElementAnimation *animation,
                               SvgTime *elapsed,
                               SvgElement* result_element,
                               gboolean seekToTime)
{
    g_assert(result_element);
    g_assert(animation->time_container);
    g_assert(animation->is_waiting_for_first_interval || svg_time_is_finite(&animation->interval_begin));


    if (!animation->conditions_connected)
        svg_element_animation_connect_conditions(animation);

    if(!svg_time_is_finite(&animation->interval_begin)) {
        g_assert(animation->active_state == SmilStateInactive);
        svg_time_set_unresolved(&animation->next_progress_time);
        return FALSE;
    }

    if (elapsed->seconds < animation->interval_begin.seconds) {
        g_assert(animation->active_state != SmilStateActive);
        if (animation->active_state == SmilStateFrozen)
            svg_element_animation_update_animation(animation, animation->last_percent, animation->last_repeat, result_element);
        animation->next_progress_time = animation->interval_begin;
        return FALSE;
    }

    animation->previous_interval_begin = animation->interval_begin;

    if (animation->is_waiting_for_first_interval) {
        animation->is_waiting_for_first_interval = FALSE;
        svg_element_animation_resolve_first_interval(animation);
    }

    // This call may obtain a new interval -- never call calculateAnimationPercentAndRepeat() before!
    if (seekToTime) {
        svg_element_animation_seek_to_interval_corresponding_to_time(animation, elapsed);
        if (elapsed->seconds < animation->interval_begin.seconds) {
            // elapsed is not within an interval.
            animation->next_progress_time.seconds = animation->interval_begin.seconds;
            return FALSE;
        }
    }

    unsigned repeat = 0;
    float percent = 0.0;
    svg_element_animation_calculate_animation_percent_and_repeat(animation, elapsed, &percent, &repeat);
    g_print("percent: %f\n", percent);
    svg_element_animation_check_restart(animation, elapsed);

    SmilStateType oldActiveState = animation->active_state;
    animation->active_state = svg_element_animation_determine_active_state(animation, elapsed);
    gboolean animation_is_contributing = svg_element_animation_is_contributing(animation, elapsed);

    // Only reset the animated type to the base value once for the lowest priority animation that animates and contributes to a particular element/attribute pair.
    if (animation == result_element && animation_is_contributing)
        svg_element_animation_reset_animated_type(animation);

    if (animation_is_contributing) {
        if (oldActiveState == SmilStateInactive)
            svg_element_animation_started_active_interval(animation);

        svg_element_animation_update_animation(animation, percent, repeat, result_element);
        animation->last_percent = percent;
        animation->last_repeat = repeat;
    }

    if (oldActiveState == SmilStateActive && animation->active_state != SmilStateActive) {
        svg_element_animation_ended_active_interval(animation);
        if (animation->active_state != SmilStateFrozen)
            svg_element_animation_clear_animated_type(animation, animation->target);
    }

    svg_element_animation_calculate_next_progress_time(animation, elapsed, &animation->next_progress_time);
    return animation_is_contributing;
}


/*< virtual >*/
void
svg_element_animation_svg_attribute_changed          (SvgElementAnimation* animation, DomQualifiedName* qualified_name)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->svg_attribute_changed(animation, qualified_name);
}

//InsertionNotificationRequest
//svg_element_animation_inserted_into (SvgElementAnimation* animation, DomNode*node)
//{
//    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->inserted_into(animation, node);
//}

void
svg_element_animation_removed_from                   (SvgElementAnimation* animation, DomNode* node)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->removed_from(animation, node);
}

gboolean
svg_element_animation_has_valid_attribute_type    (SvgElementAnimation* animation)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->has_valid_attribute_type(animation);
}

gboolean
svg_element_animation_has_valid_attribute_name    (SvgElementAnimation* animation)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->has_valid_attribute_name(animation);
}

void
svg_element_animation_animation_attribute_changed (SvgElementAnimation* animation)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->animation_attribute_changed(animation);
}

void
svg_element_animation_started_active_interval(SvgElementAnimation *animation)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->started_active_interval(animation);
}

void
svg_element_animation_is_additive(SvgElementAnimation *animation)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->is_additive(animation);
}

void
svg_element_animation_reset_animated_type(SvgElementAnimation *animation)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->reset_animated_type(animation);
}

void
svg_element_animation_clear_animated_type(SvgElementAnimation *animation, SvgElement* resultElement)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->clear_animated_type(animation, resultElement);
}

void
svg_element_animation_apply_results_to_target(SvgElementAnimation *animation)
{
    SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->apply_results_to_target(animation);
}

/*< function:private >*/


/*< function:protected >*/
void
svg_element_animation_add_begin_time(SvgElementAnimation *animation, SvgTime *eventTime, SvgTime *beginTime, SvgOriginType origin)
{
//    g_assert(!std::isnan(beginTime.value()));
    SvgTimeRelative time = {{0.0, SVG_TIME_TYPE_FULL, FALSE}, SvgOriginParser};
    time.time.seconds = beginTime->seconds;
    time.origin = origin;
    g_array_append_val(animation->begin_times, time);

    //m_beginTimes.append(SMILTimeWithOrigin(beginTime, origin));
//    sortTimeList(m_beginTimes);
//    beginListChanged(eventTime);
}

void
svg_element_animation_add_end_time(SvgElementAnimation *animation, SvgTime *eventTime, SvgTime *endTime, SvgOriginType origin)
{
//    g_assert(!std::isnan(endTime.value()));
    SvgTimeRelative time = {{0.0, SVG_TIME_TYPE_FULL, FALSE}, SvgOriginParser};
    time.time.seconds = endTime->seconds;
    time.origin = origin;
    g_array_append_val(animation->end_times, time);

    //m_endTimes.append(SMILTimeWithOrigin(endTime, origin));
//    sortTimeList(m_endTimes);
//    endListChanged(eventTime);

}

/*< private:virtual >*/
gboolean
svg_element_animation_update_animation(SvgElementAnimation *animation,
                                       float percent,
                                       unsigned repeat,
                                       SvgElement* resultElement)
{
    return SVG_ELEMENT_ANIMATION_GET_CLASS(animation)->update_animation(
                animation,
                percent,
                repeat,
                resultElement
    );

}










AnimationMode
svg_element_animation_mode(SvgElementAnimation *animation)
{
    return animation->animation_mode;
}

void
svg_element_animation_animate_additive_number(SvgElementAnimation *animation, float percentage, unsigned repeatCount, double from, double to, double end, double *animatedNumber)
{
    double number;

/*
    float number;
    if (calcMode() == CalcModeDiscrete)
        number = percentage < 0.5 ? fromNumber : toNumber;
    else
        number = (toNumber - fromNumber) * percentage + fromNumber;

    if (isAccumulated() && repeatCount)
        number += toAtEndOfDurationNumber * repeatCount;

    if (isAdditive() && animationMode() != ToAnimation)
        animatedNumber += number;
    else
        animatedNumber = number;
*/
}
