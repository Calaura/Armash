#include "svg-stylable.h"

void svg_stylable_default_do_action (SvgStylable *stylable);

G_DEFINE_INTERFACE (SvgStylable, svg_stylable, 0)

static void
svg_stylable_default_init (SvgStylableInterface* iface)
{
    iface->do_action = svg_stylable_default_do_action;

    g_object_interface_install_property (iface,
                                         g_param_spec_pointer("style",
                                                              "Get/Set style",
                                                              "Attribute style of SvgStylable",
                                                              G_PARAM_READWRITE));
/*
    g_object_interface_install_property (iface,
                                         g_param_spec_pointer("class",
                                                              "Get/Set class",
                                                              "Attribute class of SvgStylable",
                                                              G_PARAM_READWRITE));
    g_object_interface_install_property (iface,
                                         g_param_spec_pointer("fill",
                                                              "Get/Set fill",
                                                              "Attribute fill of SvgStylable",
                                                              G_PARAM_READWRITE));
    g_object_interface_install_property (iface,
                                         g_param_spec_pointer("stroke",
                                                              "Get/Set stroke",
                                                              "Attribute stroke of SvgStylable",
                                                              G_PARAM_READWRITE));
*/
}

void
svg_stylable_default_do_action (SvgStylable *stylable)
{
    return;
}

void
svg_stylable_do_action (SvgStylable *stylable)
{
    SVG_STYLABLE_GET_INTERFACE(stylable)->do_action(stylable);
}

gboolean svg_stylable_parse_attribute(SvgStylable *stylable, const gchar *name)
{
    gint success = 0;

    /* style */
    if        (0==g_strcmp0(name, "style")) {

    /* class */
    } else if (0==g_strcmp0(name, "class")) {

    /* presentation */
    /*} else if (0==g_strcmp0(name, "alignment-baseline")) {
    } else if (0==g_strcmp0(name, "baseline-shift")) {
    } else if (0==g_strcmp0(name, "clip")) {
    } else if (0==g_strcmp0(name, "clip-path")) {
    } else if (0==g_strcmp0(name, "clip-rule")) {
    } else if (0==g_strcmp0(name, "color")) {
    } else if (0==g_strcmp0(name, "color-interpolation")) {
    } else if (0==g_strcmp0(name, "color-interpolation-filters")) {
    } else if (0==g_strcmp0(name, "color-profile")) {
    } else if (0==g_strcmp0(name, "color-rendering")) {
    } else if (0==g_strcmp0(name, "cursor")) {
    } else if (0==g_strcmp0(name, "direction")) {
    } else if (0==g_strcmp0(name, "display")) {
    } else if (0==g_strcmp0(name, "dominant-baseline")) {
    } else if (0==g_strcmp0(name, "enable-background")) {*/
    } else if (0==g_strcmp0(name, "fill")) {
    /*} else if (0==g_strcmp0(name, "fill-opacity")) {
    } else if (0==g_strcmp0(name, "fill-rule")) {
    } else if (0==g_strcmp0(name, "filter")) {
    } else if (0==g_strcmp0(name, "flood-color")) {
    } else if (0==g_strcmp0(name, "flood-opacity")) {
    } else if (0==g_strcmp0(name, "font-family")) {
    } else if (0==g_strcmp0(name, "font-size")) {
    } else if (0==g_strcmp0(name, "font-size-adjust")) {
    } else if (0==g_strcmp0(name, "font-stretch")) {
    } else if (0==g_strcmp0(name, "font-style")) {
    } else if (0==g_strcmp0(name, "font-variant")) {
    } else if (0==g_strcmp0(name, "font-weight")) {
    } else if (0==g_strcmp0(name, "glyph-orientation-horizontal")) {
    } else if (0==g_strcmp0(name, "glyph-orientation-vertical")) {
    } else if (0==g_strcmp0(name, "image-rendering")) {
    } else if (0==g_strcmp0(name, "kerning")) {
    } else if (0==g_strcmp0(name, "letter-spacing")) {
    } else if (0==g_strcmp0(name, "lighting-color")) {
    } else if (0==g_strcmp0(name, "marker-end")) {
    } else if (0==g_strcmp0(name, "marker-mid")) {
    } else if (0==g_strcmp0(name, "marker-start")) {
    } else if (0==g_strcmp0(name, "mask")) {
    } else if (0==g_strcmp0(name, "opacity")) {
    } else if (0==g_strcmp0(name, "overflow")) {
    } else if (0==g_strcmp0(name, "pointer-events")) {
    } else if (0==g_strcmp0(name, "shape-rendering")) {
    } else if (0==g_strcmp0(name, "stop-color")) {
    } else if (0==g_strcmp0(name, "stop-opacity")) {*/
    } else if (0==g_strcmp0(name, "stroke")) {
    /*} else if (0==g_strcmp0(name, "stroke-dasharray")) {
    } else if (0==g_strcmp0(name, "stroke-dashoffset")) {
    } else if (0==g_strcmp0(name, "stroke-linecap")) {
    } else if (0==g_strcmp0(name, "stroke-linejoin")) {
    } else if (0==g_strcmp0(name, "stroke-miterlimit")) {
    } else if (0==g_strcmp0(name, "stroke-opacity")) {
    } else if (0==g_strcmp0(name, "stroke-width")) {
    } else if (0==g_strcmp0(name, "text-anchor")) {
    } else if (0==g_strcmp0(name, "text-decoration")) {
    } else if (0==g_strcmp0(name, "text-rendering")) {
    } else if (0==g_strcmp0(name, "unicode-bidi")) {
    } else if (0==g_strcmp0(name, "visibility")) {
    } else if (0==g_strcmp0(name, "word-spacing")) {
    } else if (0==g_strcmp0(name, "writing-mode")) {*/

    } else {
        success = 0;
    }

    return success;
}


