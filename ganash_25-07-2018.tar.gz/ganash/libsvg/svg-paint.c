/*
 * svg-paint.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <libgraphics/graphics.h>

#include <libmotion/motion-types.h>
#include <libmotion/motion-animation.h>
#include <libmotion/motion-property.h>

#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>
//#include <librenderer/renderer-style.h>
#include <librenderer/renderer-box.h>
#include "librenderer/renderer-cache.h"
#include <librenderer/renderer-object.h>
#include <librenderer/renderer-item.h>
#include <librenderer/renderer-shape.h>
#include <librenderer/renderer-scene.h>
#include <librenderer/renderer-view.h>

#include <libdom/dom.h>


#include "svg-types.h"
#include "svg-enums.h"
#   include "svg-color.h"
#   include "svg-color-icc.h"
#   include "svg-animated.h"
#   include "svg-animated-color.h"
#include "svg-paint.h"
#include "svg-number.h"
#include "svg-length.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-element-graphics.h"
#include "svg-element-solid-color.h"
#include "svg-element-gradient.h"
#include "svg-element-gradient-linear.h"
#include "svg-element-stop.h"
#include "svg-matrix.h"
#include "svg-transform.h"
#include "svg-transform-list.h"
#include "svg-transformable.h"
#include "svg-style.h"


/* lib croco */
#include <libcroco/libcroco.h>


/* lib xml */
#include <libxml/xpath.h>



static void svg_paint_class_init(SvgPaintClass *klass);
static void svg_paint_init(SvgPaint *gobject);

G_DEFINE_TYPE (SvgPaint, svg_paint, G_TYPE_OBJECT)

static void
svg_paint_class_init(SvgPaintClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	svg_paint_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_paint_init (SvgPaint *object)
{
    object->color   = NULL;
}



/* svg_element_gradient_radial_get_graphics_painter(); */
/* svg_element_gradient_linear_get_graphics_painter(); */
/* svg_element_solid_color_get_graphics_painter(); */

static GraphicsPainter*
create_graphics_gradient_linear_from_svg(SvgElementGradientLinear *element, SvgElementGraphics *target)
{
    SvgElement *elt = SVG_ELEMENT(element);
    RendererObject *renderer = SVG_ELEMENT(target)->private_member->renderer;
    GraphicsGradientLinear *gradient_linear = graphics_gradient_linear_new();
    GraphicsGradient* gradient = (GraphicsGradient*)gradient_linear;
    GraphicsPainter* painter = graphics_painter_new();
    SvgStyle *style = svg_element_graphics_get_style(target);





    /*
    cairo_path_t* path = (cairo_path_t *) RENDERER_SHAPE(renderer)->path;

    SvgTransformList *transforms = svg_transformable_get_transform((SvgTransformable *) target);
    SvgMatrix *transform = svg_transform_list_to_matrix(transforms);
    cairo_matrix_t *matrix = &transform->cairo_matrix;
    cairo_matrix_t *identity = g_new(cairo_matrix_t, 1);
    cairo_matrix_init_identity(identity);
    double x0, y0, x1, y1;
    cairo_surface_t* surface = cairo_image_surface_create (CAIRO_FORMAT_A8, 0, 0);
    cairo_t* cr = cairo_create(surface);
    cairo_append_path(cr, path);
    cairo_set_matrix(cr, matrix);
    //cairo_set_line_width(cr, svg_length_get_value(style->stroke_width, (SvgElement *) target));
    cairo_path_extents(cr, &x0, &y0, &x1, &y1);
    cairo_new_path(cr);

    cairo_destroy(cr);
    cairo_surface_destroy(surface);
    g_print("extends: %f, %f, %f, %f\n", x0, y0, x1, y1);
    */










    // LOCAL
    /*
    RendererObject *tmp = renderer->scene->target;
    renderer_scene_set_target(renderer->scene, renderer);
    RendererBox *box = renderer_view_bounding_box(renderer->scene->view, RENDERER_BOUNDING_PATH_MODE);
    renderer_scene_set_target(renderer->scene, tmp);
    */


    //cairo_matrix_t *transform = ;
    /*g_print("%s\n", G_OBJECT_TYPE_NAME(renderer));
    g_print("Matri{%f, %f, %f, %f, %f, %f}\n",
                renderer->transform->x0,
                renderer->transform->xx,
                renderer->transform->xy,
                renderer->transform->y0,
                renderer->transform->yx,
                renderer->transform->yy);*/

    /*g_print("box: %f, %f, %f, %f\n",
            box->left,
            box->top,
            box->right-box->left,
            box->top-box->bottom);*/

//    g_print("%f, %f, %f, %f\n", x0, y0, x1, y1);

    /*gradient_linear->x0 = svg_length_get_value(element->x1, target);
    gradient_linear->y0 = svg_length_get_value(element->y1, target);
    gradient_linear->x1 = svg_length_get_value(element->x2, target);
    gradient_linear->y1 = svg_length_get_value(element->y2, target);*/

    /*gradient_linear->x0 = 0;
    gradient_linear->y0 = 0;
    gradient_linear->x1 = 50;
    gradient_linear->y1 = 0;*/

    /*gradient_linear->x0 = box->left;
    gradient_linear->y0 = box->top;
    gradient_linear->x1 = box->right;
    gradient_linear->y1 = box->bottom;*/

    gradient_linear->x0 = svg_length_get_value(element->x1, (SvgElement*) target);
    gradient_linear->y0 = svg_length_get_value(element->y1, (SvgElement*) target);
    gradient_linear->x1 = svg_length_get_value(element->x2, (SvgElement*) target);
    gradient_linear->y1 = svg_length_get_value(element->y2, (SvgElement*) target);

    /*gradient_linear->x0 = bb->left;
    gradient_linear->y0 = bb->top;
    gradient_linear->x1 = bb->right;
    gradient_linear->y1 = bb->bottom;*/


    /*g_print("length-box: %f, %f, %f, %f\n",
            svg_length_get_value(element->x1, (SvgElement*) target),
            svg_length_get_value(element->y1, (SvgElement*) target),
            svg_length_get_value(element->x2, (SvgElement*) target),
            svg_length_get_value(element->y2, (SvgElement*) target));*/

    // n'est pas transmis au graphics painter: cf renderer_object->draw
    /*g_print("box-gradient: %f, %f, %f, %f\n",
            gradient_linear->x0,
            gradient_linear->y0,
            gradient_linear->x1,
            gradient_linear->y1);*/

    xmlNode *node;
    for (node = DOM_NODE(element)->xml->children; node; node=node->next) {
        if (!SVG_IS_ELEMENT_STOP(node->_private))
            continue;
        SvgElementStop* stop = SVG_ELEMENT_STOP(node->_private);
        graphics_gradient_add_stop(gradient,
            stop->offset.value,
            svg_color_get_red(&stop->color) / 255.0,
            svg_color_get_green(&stop->color) / 255.0,
            svg_color_get_blue(&stop->color) / 255.0,
            stop->opacity.value
        );
    }

    graphics_painter_set_gradient(painter, gradient);

    return painter;
}

GraphicsPainter* svg_paint_get_graphics_painter(SvgPaint *paint, SvgElementGraphics *target)
{
    GraphicsPainter* painter = NULL;
    SvgElement *element = SVG_ELEMENT(target);
    xmlDoc *doc = DOM_NODE(element)->xml->doc;

    if (paint->type==SVG_PAINT_TYPE_COLOR) {
        GraphicsSolid* solid = graphics_solid_new_init(
            svg_color_get_red(paint->data.color) / 255.0,
            svg_color_get_green(paint->data.color) / 255.0,
            svg_color_get_blue(paint->data.color) / 255.0,
            svg_color_get_alpha(paint->data.color) / 255.0
        );
        painter = graphics_painter_new();
        graphics_painter_set_solid(painter, solid);

    } else if(paint->type==SVG_PAINT_TYPE_URI) {

        DomElement *elt = NULL;
        DomDocument *document = dom_node_get_document(DOM_NODE(element));
        if (dom_document_get_element_by_id(document, paint->data.uri, &elt)) {
            if (SVG_IS_ELEMENT_SOLID_COLOR(elt)) {
                //svg_element_solid_color_to_graphics_painter()
                SvgElementSolidColor* solid_color = SVG_ELEMENT_SOLID_COLOR(elt);
                GraphicsSolid* solid = graphics_solid_new_init(
                    svg_color_get_red(&solid_color->color) / 255.0,
                    svg_color_get_green(&solid_color->color) / 255.0,
                    svg_color_get_blue(&solid_color->color) / 255.0,
                    solid_color->opacity
                );
                painter = graphics_painter_new();
                graphics_painter_set_solid(painter, solid);
            } else if (SVG_IS_ELEMENT_GRADIENT_LINEAR(elt)) {
                //svg_element_gradient_linear_to_graphics_painter()
                //svg_element_gradient_linear_create_graphics_painter
                painter = create_graphics_gradient_linear_from_svg(SVG_ELEMENT_GRADIENT_LINEAR(elt), target);
            //} else if (SVG_IS_ELEMENT_GRADIENT_GRADIENT(element)) {
            } else {
                g_message("Error: Painter factory");
            }
        }

        /*
        xmlXPathContext *xpath;
        xmlXPathObject  *xobject;
        xpath = xmlXPathNewContext(doc);
        if (xpath) {
            gchar *path = g_strdup_printf("//*[@id='%s']", paint->data.uri);
            xobject = xmlXPathEvalExpression(path, xpath);
            g_free(path);
            if (xobject && xobject->nodesetval && xobject->nodesetval->nodeNr>0) {
                xmlNode *node = xobject->nodesetval->nodeTab[0];
                SvgElement *element = (SvgElement*) node->_private;

                if (SVG_IS_ELEMENT_SOLID_COLOR(element)) {
                    //svg_element_solid_color_to_graphics_painter()
                    SvgElementSolidColor* solid_color = SVG_ELEMENT_SOLID_COLOR(element);
                    GraphicsSolid* solid = graphics_solid_new_init(
                        svg_color_get_red(&solid_color->color) / 255.0,
                        svg_color_get_green(&solid_color->color) / 255.0,
                        svg_color_get_blue(&solid_color->color) / 255.0,
                        solid_color->opacity
                    );
                    painter = graphics_painter_new();
                    graphics_painter_set_solid(painter, solid);
                } else if (SVG_IS_ELEMENT_GRADIENT_LINEAR(element)) {
                    //svg_element_gradient_linear_to_graphics_painter()
                    //svg_element_gradient_linear_create_graphics_painter
                    painter = create_graphics_gradient_linear_from_svg(SVG_ELEMENT_GRADIENT_LINEAR(element), target);
                //} else if (SVG_IS_ELEMENT_GRADIENT_GRADIENT(element)) {
                } else {
                    g_message("Error: Painter factory");
                }
                xmlXPathFreeObject(xobject);
            }
            xmlXPathFreeContext(xpath);
        } else {
            g_print("xpath null\n");
        }
        */

    } else {
        ;//g_print("Color NULL\n");
    }


    return painter;
}

SvgPaint *
svg_paint_new (void)
{
	return g_object_new (svg_paint_get_type (),
	                     NULL);
}

void
svg_paint_set_opacity(SvgPaint *paint, gdouble opacity)
{
    if (!paint)
        g_error("Paint is null: not in the order. fill: ; next fill-opacity");

    if (paint->type == SVG_PAINT_TYPE_COLOR) {
        guint8 alpha = opacity * G_MAXUINT8;
        svg_color_set_alpha(paint->data.color, alpha);// TODO move opacity in SvgPaint::opacity
        paint->opacity = opacity;
    } else {
        g_error("Not implemented: %s\n", G_STRFUNC);
    }

}

SvgAnimatedColor*
svg_paint_get_animated_color(SvgPaint *paint)
{
    if (!paint->color) {
        paint->color = svg_animated_color_new();
        paint->color->baseVal = svg_color_new_from_argb(0xFF000000);//FIXME revoir pour les gradient
        paint->color->animVal = svg_color_new_from_argb(0xFF000000);
    }

    return paint->color;
}
