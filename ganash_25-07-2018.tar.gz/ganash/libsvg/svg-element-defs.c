/*
 * svg-element-defs.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <cairo/cairo.h>
#include <glib-object.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-container.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-document.h"
#include "svg-element-defs.h"


static int             svg_element_defs_init_from_xml(DomNode *element, xmlNode* node);
static gboolean        svg_element_defs_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value);

static RendererObject* svg_element_defs_get_renderer(SvgElement *element);

static void            svg_element_defs_class_init(SvgElementDefsClass *klass);
static void            svg_element_defs_init(SvgElementDefs *gobject);


G_DEFINE_TYPE (SvgElementDefs, svg_element_defs, SVG_TYPE_ELEMENT)

#define parent_class svg_element_defs_parent_class

static void
svg_element_defs_class_init(SvgElementDefsClass *klass)
{
    DomNodeClass *dom_class;
    SvgElementClass *element_class;

    dom_class  = (DomNodeClass *) klass;
    element_class = (SvgElementClass *) klass;

    /*element_class->private_class->get_renderer = svg_element_defs_get_renderer;*/
    dom_class->init_from_xml          = svg_element_defs_init_from_xml;
    element_class->parse_attribute    = svg_element_defs_parse_attribute;


    //svg_element_defs_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_defs_init (SvgElementDefs *object)
{

}


static int
svg_element_defs_init_from_xml(DomNode* element, xmlNode* node)
{
    /*svg_element_rect_parse_attribute(element, "width", BAD_CAST xmlGetProp(node, "width"));*/
    return DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);
}

static gboolean
svg_element_defs_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_DEFS(element));
    SvgElementDefs *defs = SVG_ELEMENT_DEFS(element);

    if        (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "externalResourcesRequired"))) {
        /*
         * svg_boolean_set_value_from_string(&external_resources_required, value)
         * false|true, False|True, FALSE|TRUE, 0|1, ""
         */
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

RendererObject*
svg_element_defs_get_renderer(SvgElement* element/*RendererStyle *self*/)
{
    return NULL;
}

