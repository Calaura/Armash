/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-style.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_STYLE_H__
#define __SVG_STYLE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_STYLE            (svg_style_get_type())
#define SVG_STYLE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_STYLE, SvgStyle))
#define SVG_STYLE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_STYLE, SvgStyleClass))
#define SVG_IS_STYLE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_STYLE))
#define SVG_IS_STYLE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_STYLE))
#define SVG_STYLE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_STYLE, SvgStyleClass))

typedef struct _SvgStyleClass SvgStyleClass;

struct _SvgStyle {
	GObject parent_instance;

    SvgPaint          *stroke_paint;
    SvgAnimatedLength *stroke_width;

    SvgLength         *stroke_miter_limit;
    SvgLineJoinType    stroke_join;
    SvgLineCapType     stroke_cap;

    SvgPaint          *fill_paint;
    //SvgFillRuleType     fill_rule;

};

struct _SvgStyleClass {
	GObjectClass parent_class;
};

GType svg_style_get_type();
SvgStyle *svg_style_new();
SvgPaint *svg_style_get_fill(SvgStyle *style);
SvgPaint *svg_style_get_stroke(SvgStyle *style);

gboolean svg_style_set_property(SvgStyle *style, guchar *name, guchar* value/*, SvgElement *context*/);


G_END_DECLS

#endif /* __SVG_STYLE_H__ */
