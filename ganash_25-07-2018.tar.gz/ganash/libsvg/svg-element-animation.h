/*
 * svg-element-animation.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_ELEMENT_ANIMATION_H__
#define __SVG_ELEMENT_ANIMATION_H__

#include <glib-object.h>


G_BEGIN_DECLS

enum _SmilStateType {
    SmilStateInactive,
    SmilStateActive,
    SmilStateFrozen
};
typedef enum _SmilStateType SmilStateType;

enum _FillMode {
    FillRemove,
    FillFreeze
};
typedef enum _FillMode FillMode;

enum _Restart {
    RestartAlways,
    RestartWhenNotActive,
    RestartNever
};
typedef enum _Restart Restart;

enum _BeginOrEnd {
    SmilBegin,
    SmilEnd
};
typedef enum _BeginOrEnd      BeginOrEnd;

/*
 * defined in svg-enums.h
 *
enum _AnimationMode {
    NoAnimation,
    FromToAnimation,
    FromByAnimation,
    ToAnimation,
    ByAnimation,
    ValuesAnimation,
    PathAnimation // Used by AnimateMotion.
};
typedef enum _AnimationMode AnimationMode;
*/

// If we have 'currentColor' or 'inherit' as animation value, we need to grab
// the value during the animation since the value can be animated itself.
enum _AnimatedPropertyValueType {
    RegularPropertyValue,
    CurrentColorValue,
    InheritValue
};
typedef enum _AnimatedPropertyValueType AnimatedPropertyValueType;

enum _CalcMode {
    CalcModeDiscrete,
    CalcModeLinear,
    CalcModePaced,
    CalcModeSpline
};
typedef enum _CalcMode CalcMode;

/*< protected >*/
enum _AttributeType {
    AttributeTypeCSS,
    AttributeTypeXML,
    AttributeTypeAuto
};
typedef enum _AttributeType AttributeType;





// SmilConditionListener -------------------------------------------------------

typedef struct _ConditionEventListener ConditionEventListener;
struct _ConditionEventListener {
    int *map;
};

//ConditionEventListener *condition_event_listener_new();
//GObject                 condition_event_listener_create(SvgElementAnimation *animation, Condition *condition);
//                        condition_event_listener_clear();
//                        condition_event_listener_cpy();
//                        condition_event_listener_handle_event(Script...);
//                        condition_event_listener_handle()
//void                    condition_event_listener_add(ConditionEventListener *listener, ...);
//void                    condition_event_listener_free();

/*
class ConditionEventListener : public EventListener {
public:
    static PassRefPtr<ConditionEventListener> create(SVGSMILElement* animation, SVGSMILElement::Condition* condition)

    static const ConditionEventListener* cast(const EventListener* listener)
    virtual bool operator==(const EventListener& other) override;
    void disconnectAnimation()

private:
    ConditionEventListener(SVGSMILElement* animation, SVGSMILElement::Condition* condition)
    virtual void handleEvent(ScriptExecutionContext*, Event*) override;
bool ConditionEventListener::operator==(const EventListener& listener)
void ConditionEventListener::handleEvent(ScriptExecutionContext*, Event* event)
*/

// SmilCondition ---------------------------------------------------------------
// Syncbase timing
typedef enum _NewOrExistingInterval NewOrExistingInterval;
enum _NewOrExistingInterval {
    NewInterval,
    ExistingInterval
};

typedef enum _Type Type;
enum _Type {
    EventBase,
    Syncbase,
    AccessKey
};

typedef struct _Condition Condition;
// This represents conditions on elements begin or end list that need to be resolved on runtime
// for example <animate begin="otherElement.begin + 8s; button.click" ... />
struct _Condition {

    //Condition(Type, BeginOrEnd, const String& baseID, const String& name, SMILTime offset, int repeats = -1);
    Type type;
    BeginOrEnd begin_or_end;
    gchar *base_id;//String
    gchar *name;//String
    SvgTime offset;
    int repeats;
    DomElement *syncbase;// RefPtr<Element>
    ConditionEventListener *event_listener;// RefPtr<ConditionEventListener>
};
#define SVG_CONDITION(obj)                    ((Condition*)obj)
Condition *svg_condition_new();
//void       svg_condition_init(Condition *condition, ...);
void       svg_condition_free(Condition *condition);



// SvgElementAnimation -> SmilElement ------------------------------------------



#define SVG_TYPE_ELEMENT_ANIMATION            (svg_element_animation_get_type())
#define SVG_ELEMENT_ANIMATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ELEMENT_ANIMATION, SvgElementAnimation))
#define SVG_ELEMENT_ANIMATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ELEMENT_ANIMATION, SvgElementAnimationClass))
#define SVG_IS_ELEMENT_ANIMATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ELEMENT_ANIMATION))
#define SVG_IS_ELEMENT_ANIMATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ELEMENT_ANIMATION))
#define SVG_ELEMENT_ANIMATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ELEMENT_ANIMATION, SvgElementAnimationClass))

typedef struct _SvgElementAnimationClass SvgElementAnimationClass;

struct _SvgElementAnimation {
	SvgElement parent_instance;

    // FIXME -------------------------------------------------------------------
    /*< public >*/
    //DomQualifiedName *attribute_name;
    //DomString *attribute_name;
    gchar      *attribute_name;
    gchar      *attribute_type;

    SvgTime    *begin;//TODO remove from SmilElement, SvgElementAnimation
    SvgTime    *end;
    SvgTime    *dur;









    // SmilElement -------------------------------------------------------------
    /*< public >*/
    SvgElement *target;

    GList *conditions;
    gboolean conditions_connected;
    gboolean has_end_event_conditions;

    gboolean is_waiting_for_first_interval;

    //typedef HashSet<SVGSMILElement*> TimeDependentSet;
    GList* time_dependents;


    // Instance time lists
    GArray *begin_times;// of SmilTimeRelative
    GArray *end_times;//  of SmilTimeRelative

    // This is the upcoming or current interval
    SvgTime    interval_begin;                      // @TODO @see SvgElementAnimation addBeginTime()
    SvgTime    interval_end;

    SvgTime    previous_interval_begin;

    SmilStateType active_state;
    float last_percent;
    unsigned last_repeat;

    SvgTime    next_progress_time;

    SvgTimeContainer *time_container;// Ref<SvgTimeContainer>

    unsigned m_documentOrderIndex;

    SvgTime cached_dur;
    SvgTime cached_repeat_dur;
    SvgTime cached_repeat_count;
    SvgTime cached_min;
    SvgTime cached_max;
    /*< protected >*/
    /*< private >*/


    // SvgAnimationElement -----------------------------------------------------
    gboolean animation_valid;

    //AttributeType attribute_type;// duplicate attribute_type
    GArray *values;// of String
    GArray *key_times;// of float
    GArray *key_points;// of float
    GArray *key_splines;// of UnitBezier
    GString last_values_animation_from;
    GString last_values_animation_to;
    gboolean has_invalid_css_attribute_type;
    CalcMode calc_mode;
    AnimationMode animation_mode;
};

struct _SvgElementAnimationClass {
	SvgElementClass parent_class;

    // SmilElement -------------------------------------------------------------
    /*< public >*/
    //void     (*parse_attribute)(DomQualifiedName* qualified_name, gchar *string);
    void     (*svg_attribute_changed)       (SvgElementAnimation* animation, DomQualifiedName* qualified_name);
    //InsertionNotificationRequest (*inserted_into)(SvgElementAnimation* animation, DomNode*node);
    void     (*removed_from)                (SvgElementAnimation* animation, DomNode* node);

    gboolean (*has_valid_attribute_type)    (SvgElementAnimation* animation);
    gboolean (*has_valid_attribute_name)    (SvgElementAnimation* animation);
    void     (*animation_attribute_changed) (SvgElementAnimation* animation);


    void     (*is_additive)             (SvgElementAnimation* animation);
    void     (*reset_animated_type)     (SvgElementAnimation* animation);
    void     (*clear_animated_type)     (SvgElementAnimation* animation, SvgElement* targetElement);
    void     (*apply_results_to_target) (SvgElementAnimation* animation);
    /*< private >*/
    gboolean (*update_animation)        (SvgElementAnimation* element, float percent, unsigned repeat, SvgElement* resultElement);
    void     (*started_active_interval) (SvgElementAnimation* animation);

    // SvgAnimationElement -----------------------------------------------------

};

GType svg_element_animation_get_type();
SvgElementAnimation *svg_element_animation_new();

// SmilElement -------------------------------------------------------------

/*< virtual >*/
void        svg_element_animation_svg_attribute_changed          (SvgElementAnimation* animation, DomQualifiedName* qualified_name);
//InsertionNotificationRequest svg_element_animation_inserted_into (SvgElementAnimation* animation, DomNode*node);
void        svg_element_animation_removed_from                   (SvgElementAnimation* animation, DomNode* node);

gboolean svg_element_animation_has_valid_attribute_type    (SvgElementAnimation* animation);
gboolean svg_element_animation_has_valid_attribute_name    (SvgElementAnimation* animation);
void     svg_element_animation_animation_attribute_changed (SvgElementAnimation* animation);


void        svg_element_animation_is_additive(SvgElementAnimation *animation);
void        svg_element_animation_reset_animated_type(SvgElementAnimation *animation);
void        svg_element_animation_clear_animated_type(SvgElementAnimation *animation, SvgElement* resultElement);
void        svg_element_animation_apply_results_to_target(SvgElementAnimation *animation);

/*< function:private >*/
void        svg_element_animation_notify_dependents_interval_changed(SvgElementAnimation *animation, NewOrExistingInterval newOrExisting);
void        svg_element_animation_create_instance_times_from_syncbase(SvgElementAnimation *animation, SvgElementAnimation *syncbase, NewOrExistingInterval interval);
void        svg_element_animation_add_time_dependent(SvgElementAnimation *animation, SvgElementAnimation *element);
void        svg_element_animation_remove_time_dependent(SvgElementAnimation *animation, SvgElementAnimation *element);

SmilStateType svg_element_animation_determine_active_state(SvgElementAnimation *animation, SvgTime *elapsed);
void        svg_element_animation_calculate_next_progress_time(SvgElementAnimation *animation, SvgTime *elapsed, SvgTime *next_progress_time);
void        svg_element_animation_calculate_animation_percent_and_repeat(SvgElementAnimation *animation, SvgTime *elapsed, float *percent, unsigned *repeat);

/*< function:protected >*/
void        svg_element_animation_add_begin_time(SvgElementAnimation *animation, SvgTime *eventTime, SvgTime *beginTime, SvgOriginType origin/*SvgTimeWithOrigin::Origin = SMILTimeWithOrigin::ParserOrigin*/);
void        svg_element_animation_add_end_time(SvgElementAnimation *animation, SvgTime *eventTime, SvgTime *endTime, SvgOriginType origin/*SvgTimeWithOrigin::Origin = SMILTimeWithOrigin::ParserOrigin*/);

/*< virtual:private >*/
gboolean    svg_element_animation_update_animation(SvgElementAnimation *animation, float percent, unsigned repeat, SvgElement* resultElement);
void        svg_element_animation_started_active_interval(SvgElementAnimation *animation);

/*< function >*/
Restart     svg_element_animation_restart(SvgElementAnimation *animation);

FillMode    svg_element_animation_fill(SvgElementAnimation *animation);

void        svg_element_animation_dur(SvgElementAnimation *animation, SvgTime *time);
void        svg_element_animation_repeat_dur(SvgElementAnimation *animation, SvgTime *time);
void        svg_element_animation_repeat_count(SvgElementAnimation *animation, SvgTime *time);
void        svg_element_animation_max_value(SvgElementAnimation *animation, SvgTime *time);
void        svg_element_animation_min_value(SvgElementAnimation *animation, SvgTime *time);

void        svg_element_animation_begin_element(SvgElementAnimation *animation);
void        svg_element_animation_begin_element_at(SvgElementAnimation *animation, float offset);
void        svg_element_animation_end_element(SvgElementAnimation *animation);
void        svg_element_animation_end_element_at(SvgElementAnimation *animation, float offset);

// SvgAnimationElement -----------------------------------------------------

void        svg_element_animation_elapsed(SvgElementAnimation *animation, SvgTime *elapsed);

SvgAnimated *svg_element_animatable_get_property(SvgElement *element, gchar *name);

SvgElement *svg_element_animation_get_target(SvgElementAnimation *animation);
gdouble     svg_element_animation_get_start_time(SvgElementAnimation *animation);
gdouble     svg_element_animation_get_current_time(SvgElementAnimation *animation);
gdouble     svg_element_animation_get_simple_duration(SvgElementAnimation *animation);

gboolean svg_element_animation_progress(SvgElementAnimation *animation, SvgTime *elapsed, SvgElement* result_element, gboolean seekToTime);

AnimationMode svg_element_animation_mode(SvgElementAnimation *animation);

void svg_element_animation_animate_additive_number(SvgElementAnimation *animation, float percentage, unsigned repeatCount, double from, double to, double end, double *animatedNumber);


/*< function: private >*/
void svg_elementanimation_connect_conditions(SvgElementAnimation *animation);
void svg_element_animation_disconnect_conditions(SvgElementAnimation *animation);


G_END_DECLS

#endif /* __SVG_ELEMENT_ANIMATION_H__ */

