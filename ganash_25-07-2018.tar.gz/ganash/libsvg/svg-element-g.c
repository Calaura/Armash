/*
 * svg-element-g.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>


#include <libgraphics/graphics.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-rect.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"
//#include "librenderer/renderer-style.h"

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-length.h"
#include "libsvg/svg-rect.h"

#include "libsvg/svg-drawable.h"
#include "libsvg/svg-stylable.h"
#include "libsvg/svg-locatable.h"
#include "libsvg/svg-transformable.h"

#include "libsvg/svg-matrix.h"
#include "libsvg/svg-transform.h"
#include "libsvg/svg-transform-list.h"

#include "libsvg/svg-element.h"
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-g.h"
#include "libsvg/svg-document.h"

#include "libsvg/svg-parser.h"



enum _SvgElementGProperty
{
    PROPERTY_0,

    /* svg stylable attribute */
    PROPERTY_STYLE,
    /*PROPERTY_CLASS,
    PROPERTY_STROKE,
    PROPERTY_FILL,*/

    /* svg locatable attribute */
    /* svg transformable attribute */

    /* svg rect attribute */
    PROPERTY_X,
    PROPERTY_Y,
    /*PROPERTY_WIDTH,
    PROPERTY_HEIGHT,
    PROPERTY_RX,
    PROPERTY_RY,*/


    PROPERTIES_NUM
};

typedef struct { enum _SvgElementGProperty property; const char *name; } PropertyKeyMap;
PropertyKeyMap *map_g =
{
    {PROPERTY_STYLE, (const char *) "style"},
    {PROPERTY_X,     (const char *) "x"},
    {PROPERTY_Y,     (const char *) "y"}

    /*PROPERTY_WIDTH,
    PROPERTY_HEIGHT,
    PROPERTY_RX,
    PROPERTY_RY,*/
};

static void
svg_element_g_get_property (GObject    *object,
                            guint       property_id,
                            GValue     *value,
                            GParamSpec *pspec);
static void
svg_element_g_set_property (GObject      *object,
                            guint         property_id,
                            const GValue *value,
                            GParamSpec   *pspec);

static int             svg_element_g_init_from_xml(DomNode *element, xmlNode* node);
static gboolean        svg_element_g_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value);

static gchar          *svg_element_g_to_string(SvgElement *element, gchar *indent);
#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
static gchar          *svg_element_g_dump(DomNode *dom, LogDumpOptions *options);
#endif

//static RendererObject* svg_element_g_get_renderer(SvgElement *element);
static RendererObject *svg_element_g_create_renderer(SvgElement *element, gboolean attache);
static gboolean        svg_element_g_update_renderer(SvgElement *element);

void                   svg_element_g_hit_test(SvgElement *element, SvgHitRequest *request, SvgHitResult *result);

static void svg_element_g_class_init(SvgElementGClass *klass);
static void svg_element_g_init(SvgElementG *gobject);

static GParamSpec *svg_element_g_properties[PROPERTIES_NUM] = { NULL, };

G_DEFINE_TYPE (SvgElementG, svg_element_g, SVG_TYPE_ELEMENT_GRAPHICS)

#define parent_class svg_element_g_parent_class

static void
svg_element_g_class_init(SvgElementGClass *klass)
{
    GObjectClass    *g_object_class;
    DomNodeClass *dom_class;
    SvgElementClass *element_class;
    SvgElementGraphicsClass *graphics_class;

    g_object_class   = (GObjectClass*) klass;
    dom_class  = (DomNodeClass *) klass;
    element_class = (SvgElementClass *) klass;
    graphics_class = (SvgElementGraphicsClass *) klass;

    graphics_class->create_renderer = svg_element_g_create_renderer;
    graphics_class->update_renderer = svg_element_g_update_renderer;
    graphics_class->hit_test        = svg_element_g_hit_test;

#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
    dom_class->dump                   = svg_element_g_dump;
#endif
    dom_class->init_from_xml          = svg_element_g_init_from_xml;
    element_class->parse_attribute        = svg_element_g_parse_attribute;
    element_class->to_string              = svg_element_g_to_string;

    /*svgelement_class->private_class = g_new(SvgElementPrivateClass, 1);*/
//    svgelement_class->private_class->get_renderer = svg_element_g_get_renderer;
    /*svgelement_class->private_class->update_renderer = svg_element_g_update_renderer;*/
    /*svg_element_g_private_class_init (svgelement_class->private_class);*/

    g_object_class->get_property     = svg_element_g_get_property;
    g_object_class->set_property     = svg_element_g_set_property;

    svg_element_g_properties[PROPERTY_X] =
      g_param_spec_pointer("x",
                           "Get/Set Animated attribute x",
                           "The Rect animated attribute x",
                           G_PARAM_READWRITE);

    svg_element_g_properties[PROPERTY_Y] =
      g_param_spec_pointer("y",
                           "Get/Set Animated attribute y",
                           "The Rect animated attribute y",
                           G_PARAM_READWRITE);

    svg_element_g_properties[PROPERTY_STYLE] =
      g_param_spec_pointer("style",
                           "Get/Set style attribute",
                           "The Rect style attribute",
                           G_PARAM_READWRITE);

    g_object_class_install_properties (g_object_class,
                                       PROPERTIES_NUM,
                                       svg_element_g_properties);

//    svg_element_g_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_g_set_property (GObject      *object,
                            guint         property_id,
                            const GValue *value,
                            GParamSpec   *pspec)
{
  SvgElementG *self = SVG_ELEMENT_G(object);

  switch (property_id)
    {
    case PROPERTY_X:
      self->x = g_value_get_pointer(value);
      break;
    case PROPERTY_Y:
      self->y = g_value_get_pointer(value);
      break;
    default:
      /* We don't have any other property... */
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, property_id, pspec);
      break;
    }
}

static void
svg_element_g_get_property (GObject    *object,
                            guint       property_id,
                            GValue     *value,
                            GParamSpec *pspec)
{
    SvgElementG *self = SVG_ELEMENT_G(object);

  switch (property_id)
    {
  case PROPERTY_X:
    g_value_set_pointer(value, self->x);
    break;
  case PROPERTY_Y:
    g_value_set_pointer(value, self->y);
    break;
    default:
      /* We don't have any other property... */
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, property_id, pspec);
      break;
    }
}

static void
svg_element_g_init (SvgElementG *object)
{
    SvgElement *element = SVG_ELEMENT(object);

    element->name = G_OBJECT_TYPE_NAME(object);/*for debug*/

    object->x      = svg_length_new_width();
    object->y      = svg_length_new_height();
    object->width  = svg_length_new_width();
    object->height = svg_length_new_height();

}

/* virtual function */

static int
svg_element_g_init_from_xml(DomNode* element, xmlNode* node)
{
    SvgElementG *g = SVG_ELEMENT_G(element);
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);
    /*svg_element_rect_parse_attribute(element, "width", BAD_CAST xmlGetProp(node, "width"));*/
    int ret = DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);

/*TODO refactor */
    SvgTransformList *transform_list = svg_element_graphics_get_transform(graphics);
    SvgTransform *transform = svg_transform_list_get_item(transform_list, 0);
    if (!transform || transform->type != SVG_TRANSFORM_TRANSLATE) {
        transform = svg_transform_new();
        svg_transform_set_translate(transform, 0, 0);
        svg_transform_list_prepend(transform_list, transform);
    }
    svg_transform_translate(transform, g->x->value, g->y->value);
/**/

    return ret;
}

static gboolean svg_element_g_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_G(element));
    SvgElementG *g = SVG_ELEMENT_G(element);


    if        (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "width"))) {
        svg_length_set_value_from_string(g->width, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "height"))) {
        svg_length_set_value_from_string(g->height, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "x"))) {
        svg_length_set_value_from_string(g->x, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "y"))) {
        svg_length_set_value_from_string(g->y, value, value+strlen(value));
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

static gchar*
svg_element_g_content_to_string(SvgElement* element, gchar *indent)
{
    SvgElementG* group = SVG_ELEMENT_G(element);

    char *tmp;
    char *str = g_strdup_printf("");
    char *ind = g_strdup_printf("%s%s", indent, "    ");

    int begin = 1;
    xmlNode* node;
    for (node = dom_node_get_children(DOM_NODE(element)); node; node=node->next) {
        SvgElement* child = SVG_ELEMENT(node->_private);
        char *part = svg_element_to_string(child, ind);
        tmp = part;
        part = g_strdup_printf(part, "");
        g_free(tmp);
        tmp = str;
        if (begin)
            str = g_strdup_printf("%s", part);
        else
            str = g_strdup_printf("%s,\n%s", str, part);
        g_free(part);
        g_free(tmp);
        begin = 0;
    }
    tmp = str;
    g_free(ind);

    return str;
}

static gchar*
svg_element_g_to_string (SvgElement* element, gchar *indent)
{
    gchar *ind = g_strdup_printf("%s%s", indent, "    ");
    gchar *content;
    gchar *buffer;
    gchar *tmp = NULL;
    gchar *tmp_content = NULL;
    buffer = SVG_ELEMENT_CLASS(svg_element_g_parent_class)->to_string(element, indent);
    tmp = buffer;

    buffer = g_strdup_printf(buffer, ", children:[\n%s\n%s]");
    g_free(tmp);
    tmp = buffer;

    content = svg_element_g_content_to_string(element, indent);
    //g_free(tmp);
    tmp_content = content;

    buffer = g_strdup_printf(buffer, content, indent);
    g_free(tmp);
    g_free(content);
    tmp = buffer;

    return buffer;
}


static gchar*
svg_element_g_children_debug(SvgElement* element, LogDumpOptions *options)
{
#   define PLACE_HOLDER "%%s"
#   define TAB "%s"
#   define TYPE_NAME "%s"

    SvgElementG* group = SVG_ELEMENT_G(element);

    char *tmp;
    char *str = g_strdup_printf("");
    char *indent1 = g_strdup_printf(TAB""TAB, "", "    ");
    char *indent2 = g_strdup_printf(TAB""TAB, "", "    ");

    /*int begin = 1;
    xmlNode* node;
    for (node = dom_node_get_children(element); node; node=node->next) {
        SvgElement* child = SVG_ELEMENT(node->_private);
        if (!child) continue;

        char *part;
        if (begin)
            part = log_dump_to_string(DOM_NODE(child), indent2, flags);
        else
            part = log_dump_to_string(DOM_NODE(child), indent2, flags);

        tmp = str;
        if (begin)
            str = g_strdup_printf("%s", part);
        else
            str = g_strdup_printf("%s,\n%s", str, part);

        g_free(part);
        g_free(tmp);
        begin = 0;
    }
    tmp = str;
    g_free(indent1);*/

    return str;
}

#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
static gchar*
svg_element_g_dump(DomNode *dom, LogDumpOptions *options)
{
#   define PLACE_HOLDER "%%s"
#   define TAB "%s"
#   define TYPE_NAME "%s"


    //return DOM_NODE_CLASS(svg_element_g_parent_class)->dump(dom, indent, flags);

    SvgElement *element = DOM_NODE(dom);

    gchar *children;
    gchar *tmp_children;
    gchar *content = DOM_NODE_CLASS(svg_element_g_parent_class)->dump(dom, options);
    //gchar *content = log_dump_to_string(dom, indent, flags);
    //gchar *content = SVG_ELEMENT_CLASS(svg_element_g_parent_class)->dump(dom, indent, flags);
    gchar *tmp = content;

    char *indent1 = g_strdup_printf(TAB""TAB, "", "    ");
    char *indent2 = g_strdup_printf(TAB""TAB""TAB, "", "    ");

    /*xmlNode *child = dom_node_get_children(DOM_NODE(dom));
    if ((flags & SVG_DUMP_RECURSIVE_FLAG) && child) {
        children = svg_element_g_children_debug(dom, indent, flags);
        tmp_children = children;

        children = g_strdup_printf("\n"TAB"children:[\n%s\n"TAB"],"PLACE_HOLDER"\n"TAB, indent1, children, indent1, indent);
        g_free(tmp_children);
        tmp_children = children;

        content = g_strdup_printf(content, children);
        g_free(tmp);
        tmp = content;

        g_free(children);
    }*/

    return content;
    /*
    */
}
#endif

static gboolean svg_element_g_update_renderer(SvgElement *element)
{
    //double time = svg_element_get_time(element);
    g_debug("    %s: %s#%s", G_STRFUNC,
            G_OBJECT_TYPE_NAME(SVG_ELEMENT(element)->private_member->renderer),
            SVG_ELEMENT(element)->private_member->renderer->name);

    /*1) create style */
    //svg_element_rect_update_renderer_style(element);
    svg_element_graphics_update_style(element);

    /*2) create transformation */
    //svg_element_rect_update_renderer_transform(element);
    svg_element_graphics_update_transform(element);

    /*3) create graphics shape */
    //svg_element_rect_update_renderer_path(element);

    /*4) create graphics stroke&Fill*/
    //svg_element_rect_update_renderer_graphics(element);
    //svg_element_graphics_update_graphics(element);

    //renderer_object_update(element->private_member->renderer);

    xmlNode* node;
    for (node = dom_node_get_children(DOM_NODE(element)); node; node=node->next) {
        SvgElement* child = SVG_ELEMENT(node->_private);
        if (SVG_IS_ELEMENT_GRAPHICS(child)) {
            svg_element_graphics_update_renderer(child);
        }
    }
}

static RendererObject*
svg_element_g_create_renderer(SvgElement* element/*RendererStyle *self*/, gboolean attache)
{
    g_log(G_LOG_DOMAIN, G_LOG_LEVEL_DEBUG, "    %s(%s#%s)", G_STRFUNC, G_OBJECT_TYPE_NAME(element), element->attribute_id);
    RendererObject* container;
    RendererObject* renderer;

    container = (RendererContainer*) renderer_container_new (
                SVG_DOCUMENT(dom_node_get_document(DOM_NODE(element)))->view->scene,
                element->attribute_id);
    renderer = RENDERER_OBJECT(container);
    renderer->data = element;/*use attache in tree render*/
    g_log(G_LOG_DOMAIN, G_LOG_LEVEL_DEBUG, "        %s@%p", G_OBJECT_TYPE_NAME(renderer), renderer);

    xmlNode* node;
    for (node = dom_node_get_children(DOM_NODE(element)); node; node=node->next) {
        SvgElement* child = SVG_ELEMENT(node->_private);
        if (SVG_IS_ELEMENT_GRAPHICS(child)) {
            RendererObject* object = svg_element_graphics_create_renderer(child, attache);
            if (object) {
                renderer_container_insert(container, object, -1);
            }
            if (attache) {
                child->private_member->renderer = object;
            }
        }
    }
    if (attache) {
        element->private_member->renderer = renderer;
    }

    return renderer;
}

void
svg_element_g_hit_test(SvgElement *element, SvgHitRequest *request, SvgHitResult *result)
{
    SvgElementPrivate  *priv = element->private_member;
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);
    //g_print("%s on %s (%d childs)\n", G_STRFUNC, G_OBJECT_TYPE_NAME(element), g_list_length(element->children));

    xmlNode* node;
    for (node = dom_node_get_children(DOM_NODE(element)); node; node=node->next) {
        SvgElement* child = SVG_ELEMENT(node->_private);
        svg_element_graphics_hit_test(child, request, result);
    }
}

SvgElementG *
svg_element_g_new (void)
{
	return g_object_new (svg_element_g_get_type (),
	                     NULL);
}
