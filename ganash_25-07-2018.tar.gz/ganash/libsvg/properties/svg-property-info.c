/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-property-info.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include <liblog/log.h>
#include <librenderer/renderer.h>
#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "properties/svg-animated-property.h"
#include "properties/svg-property-info.h"
#include "svg-animated-type.h"


static void svg_property_info_class_init(SvgPropertyInfoClass *klass);
static void svg_property_info_init(SvgPropertyInfo *gobject);

G_DEFINE_TYPE (SvgPropertyInfo, svg_property_info, G_TYPE_OBJECT)

static void
svg_property_info_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (svg_property_info_parent_class)->finalize (object);
}
static void
svg_property_info_class_init(SvgPropertyInfoClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = svg_property_info_finalize;

//	svg_property_info_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_property_info_init (SvgPropertyInfo *object)
{
}

SvgPropertyInfo*
svg_property_info_new(AnimatedPropertyType newType,
                      AnimatedPropertyState newState,
                      gchar * /*const QualifiedName&*/ newAttributeName,
                      gchar * /*const AtomicString&*/ newPropertyIdentifier,
                      SynchronizeProperty newSynchronizeProperty,
                      LookupOrCreateWrapperForAnimatedProperty newLookupOrCreateWrapperForAnimatedProperty)
{
    SvgPropertyInfo *info = g_object_new (svg_property_info_get_type (), NULL);
    info->animated_property_type = newType;
    info->animated_property_type = newState;

    return info;
}
