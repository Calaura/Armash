/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-attribute-to-property-map.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_ATTRIBUTE_TO_PROPERTY_MAP_H__
#define __SVG_ATTRIBUTE_TO_PROPERTY_MAP_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_ATTRIBUTE_TO_PROPERTY_MAP            (svg_attribute_to_property_map_get_type())
#define SVG_ATTRIBUTE_TO_PROPERTY_MAP(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ATTRIBUTE_TO_PROPERTY_MAP, SvgAttributeToPropertyMap))
#define SVG_ATTRIBUTE_TO_PROPERTY_MAP_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ATTRIBUTE_TO_PROPERTY_MAP, SvgAttributeToPropertyMapClass))
#define SVG_IS_ATTRIBUTE_TO_PROPERTY_MAP(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ATTRIBUTE_TO_PROPERTY_MAP))
#define SVG_IS_ATTRIBUTE_TO_PROPERTY_MAP_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ATTRIBUTE_TO_PROPERTY_MAP))
#define SVG_ATTRIBUTE_TO_PROPERTY_MAP_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ATTRIBUTE_TO_PROPERTY_MAP, SvgAttributeToPropertyMapClass))

//typedef struct _SvgAttributeToPropertyMap SvgAttributeToPropertyMap;
typedef struct _SvgAttributeToPropertyMapClass SvgAttributeToPropertyMapClass;

struct _SvgAttributeToPropertyKey {
    guint att: 8;          //    8bits
    guint instance_id : 24;// + 24bits
                           // = 32bits
};

struct _SvgAttributeToPropertyMap {
	GObject parent_instance;

    //typedef GArray* Properties;// of SvgPropertyInfo*
    //struct _AttributePropertiesPair {unsigned int attribute; Properties properties;};
    //typedef GHashTable* AttributeToPropertiesMap;// xml/css -> opacity

    GHashTable* map;

};

struct _SvgAttributeToPropertyMapClass {
	GObjectClass parent_class;
};

GType svg_attribute_to_property_map_get_type();
SvgAttributeToPropertyMap *svg_attribute_to_property_map_new();
void svg_attribute_to_property_map_add_property (SvgAttributeToPropertyMap *object, SvgPropertyInfo *info);

G_END_DECLS

#endif /* __SVG_ATTRIBUTE_TO_PROPERTY_MAP_H__ */

