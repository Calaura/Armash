/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-animated-property.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>
#include <librenderer/renderer.h>
#include <libdom/dom.h> // use DomQualifiedName

#include "svg-types.h"
#include "svg-enums.h"

#include "properties/svg-animated-property.h"
#include "properties/svg-property-info.h"
#include "svg-animated-property.h"

static gboolean svg_animated_property_default_is_animated_list_tear_off(SvgAnimatedProperty *property);

static void svg_animated_property_class_init(SvgAnimatedPropertyClass *klass);
static void svg_animated_property_init(SvgAnimatedProperty *gobject);

G_DEFINE_TYPE (SvgAnimatedProperty, svg_animated_property, G_TYPE_OBJECT)

static void
svg_animated_property_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (svg_animated_property_parent_class)->finalize (object);
}
static void
svg_animated_property_class_init(SvgAnimatedPropertyClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = svg_animated_property_finalize;

    klass->is_animated_list_tear_off = svg_animated_property_default_is_animated_list_tear_off;

//	svg_animated_property_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_animated_property_init (SvgAnimatedProperty *object)
{
}

SvgAnimatedProperty*
svg_animated_property_new(SvgElement* element, DomQualifiedName* qualified, AnimatedPropertyType type)
{
    SvgAnimatedProperty *property;
    property = g_object_new (svg_animated_property_get_type (), NULL);
    property->animated_property_type = type;
    property->attribute_name = qualified;
    return property;
}















SvgElement*
svg_animated_property_get_context_element(SvgAnimatedProperty *property)
{
    return property->context_element;
}
DomQualifiedName*
svg_animated_property_get_attribute_name(SvgAnimatedProperty *property)
{
    return property->attribute_name;
}
/*void
svg_animated_property_attribute_name(SvgAnimatedProperty *property, DomQualifiedName* qualified_name)
{
    dom_qualified_name_cpy(property->attribute_name, qualified_name);
}*/
AnimatedPropertyType
svg_animated_property_get_animated_property_type(SvgAnimatedProperty *property)
{
    return property->animated_property_type;
}
gboolean
svg_animated_property_is_animating(SvgAnimatedProperty *property)
{
    return property->is_animating;
}
gboolean
svg_animated_property_is_read_only(SvgAnimatedProperty *property)
{
    return property->is_read_only;
}
void
svg_animated_property_set_read_only(SvgAnimatedProperty *property, gboolean boolean)
{
    property->is_read_only = boolean;
}

void
svg_animated_property_commit_change(SvgAnimatedProperty *property)
{

}

static gboolean
svg_animated_property_default_is_animated_list_tear_off(SvgAnimatedProperty *property)
{
    return FALSE;
}

gboolean
svg_animated_property_is_animated_list_tear_off(SvgAnimatedProperty *property)
{
    return SVG_ANIMATED_PROPERTY_GET_CLASS(property)->is_animated_list_tear_off(property);
}

/*
#define DECLARE_SVG_ANIMATED_PROPERTY_LOOKUP_OR_CREATE_WRAPPER(OwnerName, OwnerType, TearOffType, PropertyType) \
static TearOffType* OwnerName##_lookup_or_create_wrapper(OwnerType* element, SvgPropertyInfo* info, PropertyType* property);

#define DEFINE_SVG_ANIMATED_PROPERTY_LOOKUP_OR_CREATE_WRAPPER(OwnerName, OwnerType, TearOffName, TearOffType, PropertyType) \
static TearOffType* OwnerName##_lookup_or_create_wrapper(OwnerType* element, SvgPropertyInfo* info, PropertyType* property) \
{ \
    g_assert(info); \
    SvgAnimatedPropertyDescription key(element, info->propertyIdentifier);
    SvgAnimatedProperty *wrapper = animatedPropertyCache()->get(key);
    if (!wrapper) {
        wrapper = TearOffName##_create(element, info->attributeName, info->animatedPropertyType, property);
        if (info->animatedPropertyState == PropertyIsReadOnly)
            wrapper->setIsReadOnly();
        animatedPropertyCache()->set(key, wrapper.get());
    }
    return static_pointer_cast<TearOffType>(wrapper);
    return 0; \
}



SVGElement* contextElement() const { return m_contextElement.get(); }
const QualifiedName& attributeName() const { return m_attributeName; }
AnimatedPropertyType animatedPropertyType() const { return m_animatedPropertyType; }
bool isAnimating() const { return m_isAnimating; }
bool isReadOnly() const { return m_isReadOnly; }
void setIsReadOnly() { m_isReadOnly = true; }

void commitChange();

virtual bool isAnimatedListTearOff() const { return false; }

// Caching facilities.
typedef HashMap<SVGAnimatedPropertyDescription, SVGAnimatedProperty*, SVGAnimatedPropertyDescriptionHash, SVGAnimatedPropertyDescriptionHashTraits> Cache;

virtual ~SVGAnimatedProperty();

template<typename OwnerType, typename TearOffType, typename PropertyType>
static PassRefPtr<TearOffType> lookupOrCreateWrapper(OwnerType* element, const SVGPropertyInfo* info, PropertyType& property)
{
    ASSERT(info);
    SVGAnimatedPropertyDescription key(element, info->propertyIdentifier);
    RefPtr<SVGAnimatedProperty> wrapper = animatedPropertyCache()->get(key);
    if (!wrapper) {
        wrapper = TearOffType::create(element, info->attributeName, info->animatedPropertyType, property);
        if (info->animatedPropertyState == PropertyIsReadOnly)
            wrapper->setIsReadOnly();
        animatedPropertyCache()->set(key, wrapper.get());
    }
    return static_pointer_cast<TearOffType>(wrapper);
}

template<typename OwnerType, typename TearOffType>
static TearOffType* lookupWrapper(OwnerType* element, const SVGPropertyInfo* info)
{
    ASSERT(info);
    SVGAnimatedPropertyDescription key(element, info->propertyIdentifier);
    return static_cast<TearOffType*>(animatedPropertyCache()->get(key));
}

template<typename OwnerType, typename TearOffType>
static TearOffType* lookupWrapper(const OwnerType* element, const SVGPropertyInfo* info)
{
    return lookupWrapper<OwnerType, TearOffType>(const_cast<OwnerType*>(element), info);
}
*/
