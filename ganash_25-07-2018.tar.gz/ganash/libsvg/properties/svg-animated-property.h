/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-animated-property.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_ANIMATED_PROPERTY_H__
#define __SVG_ANIMATED_PROPERTY_H__

#include <glib-object.h>

#define G_(foo) foo

G_BEGIN_DECLS

#define SVG_TYPE_ANIMATED_PROPERTY            (svg_animated_property_get_type())
#define SVG_ANIMATED_PROPERTY(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ANIMATED_PROPERTY, SvgAnimatedProperty))
#define SVG_ANIMATED_PROPERTY_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ANIMATED_PROPERTY, SvgAnimatedPropertyClass))
#define SVG_IS_ANIMATED_PROPERTY(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ANIMATED_PROPERTY))
#define SVG_IS_ANIMATED_PROPERTY_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ANIMATED_PROPERTY))
#define SVG_ANIMATED_PROPERTY_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ANIMATED_PROPERTY, SvgAnimatedPropertyClass))

typedef struct _SvgAnimatedPropertyClass SvgAnimatedPropertyClass;

struct _SvgAnimatedProperty {
	GObject parent_instance;

/*< private >*/
    //static Cache* animatedPropertyCache();

    SvgElement *context_element;
    DomQualifiedName *attribute_name;
    AnimatedPropertyType animated_property_type;

/*< protected >*/
    gboolean is_animating;
    gboolean is_read_only;

};

struct _SvgAnimatedPropertyClass {
	GObjectClass parent_class;

    gboolean (*is_animated_list_tear_off)(SvgAnimatedProperty *);

};

GType svg_animated_property_get_type();
SvgAnimatedProperty *svg_animated_property_new(SvgElement*element, DomQualifiedName* qualified, AnimatedPropertyType type);

SvgElement*          svg_animated_property_get_context_element(SvgAnimatedProperty *property);
DomQualifiedName*    svg_animated_property_get_attribute_name(SvgAnimatedProperty *property);
AnimatedPropertyType svg_animated_property_get_animated_property_type(SvgAnimatedProperty *property);
gboolean             svg_animated_property_is_animating(SvgAnimatedProperty *property);
gboolean             svg_animated_property_is_read_only(SvgAnimatedProperty *property);
void                 svg_animated_property_set_read_only(SvgAnimatedProperty *property, gboolean boolean);

void                 svg_animated_property_commit_change(SvgAnimatedProperty *property);

gboolean             svg_animated_property_is_animated_list_tear_off(SvgAnimatedProperty *property);

G_END_DECLS

#endif /* __SVG_ANIMATED_PROPERTY_H__ */

