/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-animated-property-description.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include <liblog/log.h>
#include <librenderer/renderer.h>
#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-animated-property-description.h"


static void svg_animated_property_description_class_init(SvgAnimatedPropertyDescriptionClass *klass);
static void svg_animated_property_description_init(SvgAnimatedPropertyDescription *gobject);

G_DEFINE_TYPE (SvgAnimatedPropertyDescription, svg_animated_property_description, G_TYPE_OBJECT)

static void
svg_animated_property_description_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (svg_animated_property_description_parent_class)->finalize (object);
}
static void
svg_animated_property_description_class_init(SvgAnimatedPropertyDescriptionClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = svg_animated_property_description_finalize;

//	svg_animated_property_description_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_animated_property_description_init (SvgAnimatedPropertyDescription *object)
{
    object->attribute_name = NULL;
    object->element = NULL;
}

SvgAnimatedPropertyDescription *
svg_animated_property_description_new (void)
{
	return g_object_new (svg_animated_property_description_get_type (),
	                     NULL);
}

guint
svg_animated_property_description_hash(SvgAnimatedPropertyDescription *description)
{
    g_assert(description);
    g_assert(description->element);

    guint hash = 0;
    //gchar *attribute = dom_qualified_name_to_string(description->attribute_name, "svg");

    //SvgEnumAttributes attribute_id = svg_attributes_lookup(attribute);
    GEnumClass *enum_class;
    GEnumValue *enum_value;

    enum_class = g_type_class_ref (svg_attributes_get_type());
    enum_value = g_enum_get_value_by_nick (enum_class, description->attribute_name->name);

    g_print ("Max: %d\n", enum_class->maximum);// 0b000011111111 == 0x00FF == 8 bits => 256
    g_print ("Name: %s\n", enum_value->value_name);
    hash += enum_value->value;

    g_type_class_unref (enum_class);

    guint id = dom_element_get_instance_id(description->element);
    g_assert(id < G_MAXUINT-0x00FF);
    hash |= id << 8;

    return hash;
}
