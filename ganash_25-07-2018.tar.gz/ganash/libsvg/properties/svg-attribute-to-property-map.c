/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-attribute-to-property-map.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "liblog/log-enums.h"
#include "librenderer/renderer-enums.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "properties/svg-animated-property.h"
#include "properties/svg-property-info.h"
#include "svg-attribute-to-property-map.h"


static void svg_attribute_to_property_map_class_init(SvgAttributeToPropertyMapClass *klass);
static void svg_attribute_to_property_map_init(SvgAttributeToPropertyMap *gobject);

G_DEFINE_TYPE (SvgAttributeToPropertyMap, svg_attribute_to_property_map, G_TYPE_OBJECT)

static void
svg_attribute_to_property_map_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (svg_attribute_to_property_map_parent_class)->finalize (object);
}
static void
svg_attribute_to_property_map_class_init(SvgAttributeToPropertyMapClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = svg_attribute_to_property_map_finalize;

//	svg_attribute_to_property_map_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_attribute_to_property_map_init (SvgAttributeToPropertyMap *object)
{
    GHashFunc hash_func = g_direct_hash;
    GEqualFunc key_equal_func = g_direct_equal;
    GDestroyNotify key_destroy_func = NULL;
    GDestroyNotify value_destroy_func = g_object_unref;
    //g_direct_hash(); dom_element_get_instance_id() + SVG_ATTRIBUTE_STROKE
    GArray *value = g_array_new(FALSE, FALSE, sizeof(gpointer));// of <SvgPropertyInfo*>
    guint     key = 0;

    object->map = g_hash_table_new_full(hash_func, key_equal_func, key_destroy_func, value_destroy_func);
}

SvgAttributeToPropertyMap *
svg_attribute_to_property_map_new (void)
{
    return g_object_new (svg_attribute_to_property_map_get_type (),
                         NULL);
}

void
svg_attribute_to_property_map_add_property (SvgAttributeToPropertyMap *object, SvgPropertyInfo *info)
{
    guint key = 0;//svg_property_info_get_key(info);
    g_hash_table_insert(object->map, key, info);
}


