/*
 * svg-element-linear-gradient.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <libgraphics/graphics.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-color.h"
#include "svg-color-icc.h"
#include "svg-length.h"
#include "svg-parser.h"
#include "svg-document.h"
#include "svg-element-gradient.h"
#include "svg-element-gradient-linear.h"

#include <string.h>

static int             svg_element_gradient_linear_init_from_xml(DomNode *element, xmlNode* node);
static gboolean        svg_element_gradient_linear_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value);


static void svg_element_gradient_linear_class_init(SvgElementGradientLinearClass *klass);
static void svg_element_gradient_linear_init(SvgElementGradientLinear *gobject);

G_DEFINE_TYPE (SvgElementGradientLinear, svg_element_gradient_linear, SVG_TYPE_ELEMENT_GRADIENT)

#define parent_class svg_element_gradient_linear_parent_class

static void
svg_element_gradient_linear_class_init(SvgElementGradientLinearClass *klass)
{
    SvgElementClass *element_class;
    DomNodeClass *dom_class;

    dom_class  = (DomNodeClass *) klass;
    element_class = (SvgElementClass *) klass;

    dom_class->init_from_xml          = svg_element_gradient_linear_init_from_xml;
    element_class->parse_attribute        = svg_element_gradient_linear_parse_attribute;

    //svg_element_gradient_linear_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_gradient_linear_init (SvgElementGradientLinear *object)
{
    object->x1 = svg_length_new_width();
    object->x2 = svg_length_new_width();
    object->y1 = svg_length_new_height();
    object->y2 = svg_length_new_height();
}

static int
svg_element_gradient_linear_init_from_xml(DomNode* element, xmlNode* node)
{
    /*svg_element_rect_parse_attribute(element, "width", BAD_CAST xmlGetProp(node, "width"));*/
    return DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);
}

static gboolean
svg_element_gradient_linear_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_GRADIENT_LINEAR(element));

    SvgElementGradientLinear *gradient_linear = SVG_ELEMENT_GRADIENT_LINEAR(element);

    if        (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "x1"))) {
        svg_length_set_value_from_string(gradient_linear->x1, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "y1"))) {
        svg_length_set_value_from_string(gradient_linear->y1, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "x2"))) {
        svg_length_set_value_from_string(gradient_linear->x2, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "y2"))) {
        svg_length_set_value_from_string(gradient_linear->y2, value, value+strlen(value));
    } else if(SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

void svg_element_gradient_linear_set_target(SvgElementGradientLinear* gradient, SvgElement *target)
{
    gradient->x1->context = target;
    gradient->y1->context = target;
    gradient->x2->context = target;
    gradient->y2->context = target;
}

