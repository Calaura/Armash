/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-names.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "svg-names.h"

// typedef struct SvgTagNames {gint code; DomQualifiedName name, GType: type}
// typedef struct SvgAttrNames {gint code; DomQualifiedName name, GCallback: parser}

#define SVG_ELEMENT_SVG 1
#define SVG_ELEMENT_A   2
#define SVG_ELEMENT_A   3
#define SVG_ELEMENT_A   5

static DomQualifiedName SVGTags[] = {
    {"svg", "svg"},     // code:1, name:"svg", type:SVG_TYPE_ELEMENT_SVG
    {"svg", "a"},            // 2
    {"svg", "altGlyph"},     // 3
    {"svg", "altGlyphDef"},  // 5
    {"svg", "altGlyphItem"}, // 7
    {"svg", "animate"},      // 11
    {"svg", "animateColor"}, // 13
    //...
    NULL
};

static void svg_names_class_init(SvgNamesClass *klass);
static void svg_names_init(SvgNames *gobject);

G_DEFINE_TYPE (SvgNames, svg_names, G_TYPE_OBJECT)

static void
svg_names_class_init(SvgNamesClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;


	svg_names_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_names_init (SvgNames *object)
{
}

SvgNames *
svg_names_new (void)
{
	return g_object_new (svg_names_get_type (),
	                     NULL);
}

