/*
 * svg-svg-element.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <liblog/log.h>


#include <libgraphics/graphics.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-document.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-element-graphics.h"
#include "svg-element-g.h"
#include "svg-drawable.h"
#include "svg-element-svg.h"

static void svg_drawable_svg_interface_init (SvgDrawableInterface *iface);
static void svg_drawable_svg_draw(SvgDrawable* element, cairo_t* cr);

static int             svg_element_svg_init_from_xml(DomNode *element, xmlNode* node);
static gboolean        svg_element_svg_parse_attribute(SvgElement* element, DomQualifiedName* name, guchar* value);

static RendererObject* svg_element_svg_create_renderer(SvgElement *element, gboolean attache);
static gboolean        svg_element_svg_update_renderer(SvgElement *element/*RendererStyle* style*/);

/*static void svg_element_svg_private_class_init(SvgElementPrivateClass *klass);*/
static void svg_element_svg_class_init(SvgElementSvgClass *klass);
static void svg_element_svg_init(SvgElementSvg *gobject);

G_DEFINE_TYPE_WITH_CODE (SvgElementSvg, svg_element_svg, SVG_TYPE_ELEMENT_G,
                         G_IMPLEMENT_INTERFACE (SVG_TYPE_DRAWABLE,
                                                svg_drawable_svg_interface_init))
#define parent_class svg_element_svg_parent_class

static void
svg_element_svg_class_init(SvgElementSvgClass *klass)
{
    DomNodeClass *dom_class;
    SvgElementClass *svgelement_class;
    SvgElementGraphicsClass *graphics_class;

    dom_class  = (DomNodeClass *) klass;
    svgelement_class = (SvgElementClass *) klass;
    graphics_class = (SvgElementGraphicsClass *) klass;

    //graphics_class->create_renderer = svg_element_svg_create_renderer;
    //graphics_class->update_renderer = svg_element_svg_update_renderer;

    dom_class->init_from_xml        = svg_element_svg_init_from_xml;
    svgelement_class->parse_attribute      = svg_element_svg_parse_attribute;

    /*svgelement_class->get_renderer      = svg_element_svg_get_renderer;*/
    /*svg_element_svg_private_class_init(svgelement_class->private_class);*/
    /*svgelement_class->private_class = g_new(SvgElementPrivateClass, 1);*/
    //svgelement_class->private_class->get_renderer = svg_element_svg_get_renderer;

//    svg_element_svg_parent_class = g_type_class_peek_parent (klass);
}

/*static void
svg_element_svg_private_class_init(SvgElementPrivateClass *klass)
{
    klass->get_renderer   = svg_element_svg_get_renderer;
}*/

static void
svg_drawable_svg_interface_init (SvgDrawableInterface *iface)
{
    iface->draw = svg_drawable_svg_draw;
}

static void
svg_drawable_svg_draw(SvgDrawable* element, cairo_t* cr)
{
    RendererObject* renderer = svg_element_graphics_get_renderer(element);
    svg_element_graphics_update_renderer(element);

    gboolean success = renderer_object_draw(renderer, cr);
}

static void
svg_element_svg_init (SvgElementSvg *object)
{
    //SVG_ELEMENT(object)->name = G_OBJECT_TYPE_NAME(object);/*for debug*/
}

static gboolean svg_element_svg_update_renderer(SvgElement *element)
{
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);

    //double time = svg_element_get_time(element);
    g_debug("    %s", G_STRFUNC);

    /*1) create style */
    //svg_element_rect_update_renderer_style(element);
    svg_element_graphics_update_style(element);

    /*2) create transformation */
    //svg_element_rect_update_renderer_transform(element);
    svg_element_graphics_update_transform(element);

    /*3) create graphics shape */
    //svg_element_rect_update_renderer_path(element);

    /*4) create graphics stroke&Fill*/
    //svg_element_rect_update_renderer_graphics(element);
    //svg_element_graphics_update_graphics(element);


    //renderer_object_update(element->private_member->renderer);
    xmlNode* node;
    for (node = dom_node_get_children(DOM_NODE(element)); node; node=node->next) {
        SvgElement* child = SVG_ELEMENT(node->_private);
        if (SVG_IS_ELEMENT_GRAPHICS(child)) {
            RendererObject* renderer = svg_element_graphics_update_renderer(child);
        }
    }

}

/* virtual functions */

static RendererObject*
svg_element_svg_create_renderer(SvgElement* element, gboolean attache)
{
    g_log(G_LOG_DOMAIN, G_LOG_LEVEL_DEBUG, "    %s(%s#%s)", G_STRFUNC, G_OBJECT_TYPE_NAME(element), element->attribute_id);

    RendererContainer* container;
    RendererObject* renderer;

    container = (RendererContainer*) renderer_container_new (SVG_DOCUMENT(dom_node_get_document(DOM_NODE(element)))->view->scene, element->attribute_id);
    renderer = (RendererObject *) container;
    renderer->data = element;/*use attache in tree render*/

    xmlNode* node;
    for (node = dom_node_get_children(DOM_NODE(element)); node; node=node->next) {
        SvgElement *child = SVG_ELEMENT(node->_private);
        if (SVG_IS_ELEMENT_GRAPHICS(child)) {
            RendererObject* object = svg_element_graphics_create_renderer(child, attache);
            if (object) {
                renderer_container_insert(container, object, -1);
                if (attache) {
                    child->private_member->renderer = object;
                }
            }
        }
    }
    if (attache) {
        element->private_member->renderer = renderer;
    }

    return renderer;
}

static int
svg_element_svg_init_from_xml(DomNode* element, xmlNode* node)
{
    return DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);
}

static gboolean svg_element_svg_parse_attribute(SvgElement* element, DomQualifiedName *name, guchar* value)
{
    return SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, name, value);
}


SvgElementSvg *
svg_element_svg_new (void)
{
    return g_object_new (svg_element_svg_get_type (),
                         NULL);
}
