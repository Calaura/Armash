/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-updater.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_UPDATER_H__
#define __SVG_UPDATER_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define is_update(elt) (elt->status_update == SVG_UPDATE_STATUS_UPDATE)
#define get_status(elt, var)      ((elt->status_update & SVG_UPDATE_##var##_MASK) >> SVG_UPDATE_##var##_SHIFT)
#define set_status(elt, var, val) \
    elt->status_update &= ~SVG_UPDATE_##var##_MASK; \
    elt->status_update |= SVG_UPDATE_STATUS_##val << SVG_UPDATE_##var##_SHIFT



#define SVG_TYPE_UPDATER            (svg_updater_get_type())
#define SVG_UPDATER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_UPDATER, SvgUpdater))
#define SVG_UPDATER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_UPDATER, SvgUpdaterClass))
#define SVG_IS_UPDATER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_UPDATER))
#define SVG_IS_UPDATER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_UPDATER))
#define SVG_UPDATER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_UPDATER, SvgUpdaterClass))

typedef struct _SvgUpdaterClass SvgUpdaterClass;

typedef struct _SvgModification SvgModification;
struct _SvgModification {
    //SvgElement *refs;
    guint types;
    SvgUpdateFlag flags;
};

struct _SvgUpdater {
	GObject parent_instance;

    GTree *elements_modified;
};

struct _SvgUpdaterClass {
	GObjectClass parent_class;
};

GType svg_updater_get_type();
SvgUpdater *svg_updater_new();
void        svg_updater_insert(SvgUpdater *updater, SvgElement *element, SvgUpdateFlags flags, uint types);

G_END_DECLS

#endif /* __SVG_UPDATER_H__ */

