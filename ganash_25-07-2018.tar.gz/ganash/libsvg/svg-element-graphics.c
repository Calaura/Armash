/*
 * svg-element-graphics.c
 * Copyright (C) 2013 Samuel Leibowitz
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>


#include <libgraphics/graphics.h>


/* lib renderer */
#   include <librenderer/renderer-types.h>
#   include <librenderer/renderer-enums.h>
#   include <librenderer/renderer-style.h>
#   include <librenderer/renderer-box.h>
#   include <librenderer/renderer-hit-test-request.h>
#   include <librenderer/renderer-hit-test-result.h>
#   include "librenderer/renderer-cache.h"
#   include <librenderer/renderer-object.h>
#   include <librenderer/renderer-item.h>
#   include <librenderer/renderer-shape.h>
#   include <librenderer/renderer-scene.h>
#   include <librenderer/renderer-view.h>
#include <librenderer/renderer-rect.h>

#include "libmotion/motion-types.h"
#include "libmotion/motion-easing.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"

#include <libdom/dom.h>

/* lib svg */
#   include "svg-types.h"
#   include "svg-enums.h"
#   include "svg-time.h"
#   include "svg-rect.h"
#   include "svg-length.h"
#   include "svg-color.h"
#   include "svg-animated.h"
#   include "svg-animated-type.h"
#   include "svg-animated-type-animator.h"
#   include "svg-animated-length.h"
#   include "svg-animated-color.h"
#   include "svg-hit-request.h"
#   include "svg-hit-result.h"
#   include "svg-number.h"
#   include "svg-matrix.h"
#   include "svg-transform.h"
#   include "svg-transform-list.h"
#   include "svg-color.h"
#   include "svg-color-icc.h"
#   include "svg-paint.h"
#   include "svg-css.h"
#   include "svg-style.h"
#   include "svg-drawable.h"
#   include "svg-stylable.h"
#   include "svg-locatable.h"
#   include "svg-transformable.h"
#   include "svg-parser.h"

#   include "properties/svg-animated-property.h"
#   include "properties/svg-property-info.h"
#   include "svg-document.h"
#   include "svg-element.h"
#   include "svg-element-private.h"
#   include "svg-element.h"
#   include "svg-element-private.h"
#   include "svg-element-graphics.h"
#   include "svg-element-private.h"
#   include "svg-element-solid-color.h"
#   include "svg-element-stop.h"
#   include "svg-element-gradient.h"
#   include "svg-element-gradient-linear.h"
#   include "svg-element-solid-color.h"
#   include "svg-document.h"
#   include "svg-updater.h"

#include "svg-element-g.h"
#include "svg-element-use.h"


/* lib croco */
#include <libcroco/libcroco.h>


/* lib xml */
#include <libxml/xpath.h>


enum _SvgElementGraphicsProperty
{
    PROPERTY_0,

    /* xml property */
    PROPERTY_STYLE,
    PROPERTY_CLASS,
    PROPERTY_STROKE,
    PROPERTY_FILL,

    /* css property */
/*
    SVG_PROPERTY_XML_STROKE,
*/
    /*
    SVG_PROPERTY_CSS_BACKGROUND_ATTACHMENT,
    SVG_PROPERTY_CSS_BACKGROUND_CLIP,
    SVG_PROPERTY_CSS_BACKGROUND_COLOR,
    SVG_PROPERTY_CSS_BACKGROUND_IMAGE,
    SVG_PROPERTY_CSS_BACKGROUND_ORIGIN,
    SVG_PROPERTY_CSS_BACKGROUND_POSITION,
    SVG_PROPERTY_CSS_BACKGROUND_REPEAT,
    SVG_PROPERTY_CSS_BACKGROUND_SIZE,
    SVG_PROPERTY_CSS_BORDER_BOTTOM_COLOR,
    SVG_PROPERTY_CSS_BORDER_BOTTOM_LEFT_RADIUS,
    SVG_PROPERTY_CSS_BORDER_BOTTOM_RIGHT_RADIUS,
    SVG_PROPERTY_CSS_BORDER_BOTTOM_STYLE,
    SVG_PROPERTY_CSS_BORDER_BOTTOM_WIDTH,
    SVG_PROPERTY_CSS_BORDER_COLLAPSE,
    SVG_PROPERTY_CSS_BORDER_IMAGE_OUTSET,
    SVG_PROPERTY_CSS_BORDER_IMAGE_REPEAT,
    SVG_PROPERTY_CSS_BORDER_IMAGE_SLICE,
    SVG_PROPERTY_CSS_BORDER_IMAGE_SOURCE,
    SVG_PROPERTY_CSS_BORDER_IMAGE_WIDTH,
    SVG_PROPERTY_CSS_BORDER_LEFT_COLOR,
    SVG_PROPERTY_CSS_BORDER_LEFT_STYLE,
    SVG_PROPERTY_CSS_BORDER_LEFT_WIDTH,
    SVG_PROPERTY_CSS_BORDER_RIGHT_COLOR,
    SVG_PROPERTY_CSS_BORDER_RIGHT_STYLE,
    SVG_PROPERTY_CSS_BORDER_RIGHT_WIDTH,
    SVG_PROPERTY_CSS_BORDER_TOP_COLOR,
    SVG_PROPERTY_CSS_BORDER_TOP_LEFT_RADIUS,
    SVG_PROPERTY_CSS_BORDER_TOP_RIGHT_RADIUS,
    SVG_PROPERTY_CSS_BORDER_TOP_STYLE,
    SVG_PROPERTY_CSS_BORDER_TOP_WIDTH,
    SVG_PROPERTY_CSS_BOTTOM,
    SVG_PROPERTY_CSS_BOX_SHADOW,
    SVG_PROPERTY_CSS_BOX_SIZING,
    SVG_PROPERTY_CSS_CAPTION_SIDE,
    SVG_PROPERTY_CSS_CLEAR,
    SVG_PROPERTY_CSS_CLIP,
    SVG_PROPERTY_CSS_COLOR,
    SVG_PROPERTY_CSS_CURSOR,
    SVG_PROPERTY_CSS_DIRECTION,
    SVG_PROPERTY_CSS_DISPLAY,
    SVG_PROPERTY_CSS_EMPTY_CELLS,
    SVG_PROPERTY_CSS_FLOAT,
    SVG_PROPERTY_CSS_FONT_FAMILY,
    SVG_PROPERTY_CSS_FONT_SIZE,
    SVG_PROPERTY_CSS_FONT_STYLE,
    SVG_PROPERTY_CSS_FONT_VARIANT,
    SVG_PROPERTY_CSS_FONT_WEIGHT,
    SVG_PROPERTY_CSS_HEIGHT,
    SVG_PROPERTY_CSS_IMAGE_ORIENTATION,
    SVG_PROPERTY_CSS_IMAGE_RENDERING,
    SVG_PROPERTY_CSS_IMAGE_RESOLUTION,
    SVG_PROPERTY_CSS_LEFT,
    SVG_PROPERTY_CSS_LETTER_SPACING,
    SVG_PROPERTY_CSS_LINE_HEIGHT,
    SVG_PROPERTY_CSS_LIST_STYLE_IMAGE,
    SVG_PROPERTY_CSS_LIST_STYLE_POSITION,
    SVG_PROPERTY_CSS_LIST_STYLE_TYPE,
    SVG_PROPERTY_CSS_MARGIN_BOTTOM,
    SVG_PROPERTY_CSS_MARGIN_LEFT,
    SVG_PROPERTY_CSS_MARGIN_RIGHT,
    SVG_PROPERTY_CSS_MARGIN_TOP,
    SVG_PROPERTY_CSS_MAX_HEIGHT,
    SVG_PROPERTY_CSS_MAX_WIDTH,
    SVG_PROPERTY_CSS_MIN_HEIGHT,
    SVG_PROPERTY_CSS_MIN_WIDTH,
    SVG_PROPERTY_CSS_OPACITY,
    SVG_PROPERTY_CSS_ORPHANS,
    SVG_PROPERTY_CSS_OUTLINE_COLOR,
    SVG_PROPERTY_CSS_OUTLINE_OFFSET,
    SVG_PROPERTY_CSS_OUTLINE_STYLE,
    SVG_PROPERTY_CSS_OUTLINE_WIDTH,
    SVG_PROPERTY_CSS_OVERFLOW_WRAP,
    SVG_PROPERTY_CSS_OVERFLOW_X,
    SVG_PROPERTY_CSS_OVERFLOW_Y,
    SVG_PROPERTY_CSS_PADDING_BOTTOM,
    SVG_PROPERTY_CSS_PADDING_LEFT,
    SVG_PROPERTY_CSS_PADDING_RIGHT,
    SVG_PROPERTY_CSS_PADDING_TOP,
    SVG_PROPERTY_CSS_PAGE_BREAK_AFTER,
    SVG_PROPERTY_CSS_PAGE_BREAK_BEFORE,
    SVG_PROPERTY_CSS_PAGE_BREAK_INSIDE,
    SVG_PROPERTY_CSS_POINTER_EVENTS,
    SVG_PROPERTY_CSS_POSITION,
    SVG_PROPERTY_CSS_RESIZE,
    SVG_PROPERTY_CSS_RIGHT,
    SVG_PROPERTY_CSS_SPEAK,
    SVG_PROPERTY_CSS_TABLE_LAYOUT,
    SVG_PROPERTY_CSS_TAB_SIZE,
    SVG_PROPERTY_CSS_TEXT_ALIGN,
    SVG_PROPERTY_CSS_TEXT_DECORATION,
    SVG_PROPERTY_CSS_TEXT_INDENT,
    SVG_PROPERTY_CSS_TEXT_RENDERING,
    SVG_PROPERTY_CSS_TEXT_SHADOW,
    SVG_PROPERTY_CSS_TEXT_OVERFLOW,
    SVG_PROPERTY_CSS_TEXT_TRANSFORM,
    SVG_PROPERTY_CSS_TOP,
    SVG_PROPERTY_CSS_TRANSITION_DELAY,
    SVG_PROPERTY_CSS_TRANSITION_DURATION,
    SVG_PROPERTY_CSS_TRANSITION_PROPERTY,
    SVG_PROPERTY_CSS_TRANSITION_TIMING_FUNCTION,
    SVG_PROPERTY_CSS_UNICODE_BIDI,
    SVG_PROPERTY_CSS_VERTICAL_ALIGN,
    SVG_PROPERTY_CSS_VISIBILITY,
    SVG_PROPERTY_CSS_WHITE_SPACE,
    SVG_PROPERTY_CSS_WIDOWS,
    SVG_PROPERTY_CSS_WIDTH,
    SVG_PROPERTY_CSS_WORD_BREAK,
    SVG_PROPERTY_CSS_WORD_SPACING,
    SVG_PROPERTY_CSS_WORD_WRAP,
    SVG_PROPERTY_CSS_ZINDEX,
    SVG_PROPERTY_CSS_ZOOM,
    SVG_PROPERTY_CSS_BUFFERED_RENDERING,
    SVG_PROPERTY_CSS_CLIP_PATH,
    SVG_PROPERTY_CSS_CLIP_RULE,
    SVG_PROPERTY_CSS_MASK,
    SVG_PROPERTY_CSS_FILTER,
    SVG_PROPERTY_CSS_FLOOD_COLOR,
    SVG_PROPERTY_CSS_FLOOD_OPACITY,
    SVG_PROPERTY_CSS_LIGHTING_COLOR,
    SVG_PROPERTY_CSS_STOP_COLOR,
    SVG_PROPERTY_CSS_STOP_OPACITY,
    SVG_PROPERTY_CSS_COLOR_INTERPOLATION,
    SVG_PROPERTY_CSS_COLOR_INTERPOLATION_FILTERS,
    SVG_PROPERTY_CSS_COLOR_RENDERING,
    SVG_PROPERTY_CSS_FILL,
    SVG_PROPERTY_CSS_FILL_OPACITY,
    SVG_PROPERTY_CSS_FILL_RULE,
    SVG_PROPERTY_CSS_MARKER_END,
    SVG_PROPERTY_CSS_MARKER_MID,
    SVG_PROPERTY_CSS_MARKER_START,
    SVG_PROPERTY_CSS_MASK_TYPE,
    SVG_PROPERTY_CSS_SHAPE_RENDERING,
    SVG_PROPERTY_CSS_STROKE,
    SVG_PROPERTY_CSS_STROKE_DASHARRAY,
    SVG_PROPERTY_CSS_STROKE_DASHOFFSET,
    SVG_PROPERTY_CSS_STROKE_LINECAP,
    SVG_PROPERTY_CSS_STROKE_LINEJOIN,
    SVG_PROPERTY_CSS_STROKE_MITERLIMIT,
    SVG_PROPERTY_CSS_STROKE_OPACITY,
    */
    SVG_PROPERTY_CSS_STROKE_WIDTH,
    /*
    SVG_PROPERTY_CSS_ALIGNMENT_BASELINE,
    SVG_PROPERTY_CSS_BASELINE_SHIFT,
    SVG_PROPERTY_CSS_DOMINANT_BASELINE,
    SVG_PROPERTY_CSS_KERNING,
    SVG_PROPERTY_CSS_TEXT_ANCHOR,
    SVG_PROPERTY_CSS_WRITING_MODE,
    SVG_PROPERTY_CSS_GLYPH_ORIENTATION_HORIZONTAL,
    SVG_PROPERTY_CSS_GLYPH_ORIENTATION_VERTICAL,
    SVG_PROPERTY_CSS_VECTOR_EFFECT,
*/

    PROPERTIES_NUM
};

static GParamSpec *svg_element_graphics_properties[PROPERTIES_NUM] = { NULL, };


#define SVG_ELEMENT_GRAPHICS_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), SVG_TYPE_ELEMENT_GRAPHICS, SvgElementGraphicsPrivate))
struct _SvgElementGraphicsPrivate {
    SvgTransformList* transform_list;

    gchar *style_value;
    gchar *class_value;
    gchar *stroke_value;
    gchar *fill_value;

    SvgStyle *style;
};


static void
svg_element_graphics_get_property ( GObject    *object,
                                    guint       property_id,
                                    GValue     *value,
                                    GParamSpec *pspec);
static void
svg_element_graphics_set_property ( GObject      *object,
                                    guint         property_id,
                                    const GValue *value,
                                    GParamSpec   *pspec);


static RendererObject*   svg_element_graphics_default_create_renderer(SvgElement *element, gboolean attache);
static gboolean          svg_element_graphics_default_update_renderer(SvgElement *element);
void                     svg_element_graphics_default_hit_test(SvgElement *element, SvgHitRequest *request, SvgHitResult *result);

static int               svg_element_graphics_init_from_xml(DomNode *element, xmlNode* node);
static gboolean          svg_element_graphics_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value);
static gchar            *svg_element_graphics_to_string(SvgElement *element, gchar *indent);
#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
static gchar            *svg_element_graphics_dump(DomNode *dom, LogDumpOptions *options);
#endif

static void svg_drawable_graphics_interface_init (SvgDrawableInterface *iface);
static void svg_stylable_graphics_interface_init (SvgStylableInterface *iface);
static void svg_locatable_graphics_interface_init (SvgLocatableInterface *iface);
static void svg_transformable_graphics_interface_init (SvgTransformableInterface *iface);
static void svg_element_graphics_class_init(SvgElementGraphicsClass *klass);
static void svg_element_graphics_init(SvgElementGraphics *gobject);

G_DEFINE_TYPE_WITH_CODE (SvgElementGraphics, svg_element_graphics, SVG_TYPE_ELEMENT,
                         G_IMPLEMENT_INTERFACE (SVG_TYPE_DRAWABLE,
                                                svg_drawable_graphics_interface_init)
                         G_IMPLEMENT_INTERFACE (SVG_TYPE_STYLABLE,/* style, class, ... */
                                                svg_stylable_graphics_interface_init)
                         G_IMPLEMENT_INTERFACE (SVG_TYPE_LOCATABLE,
                                                svg_locatable_graphics_interface_init)
                         G_IMPLEMENT_INTERFACE (SVG_TYPE_TRANSFORMABLE,
                                                svg_transformable_graphics_interface_init))
/*
    SVGElement,
    SVGTests,
    SVGLangSpace,
    SVGExternalResourcesRequired,
    SVGStylable,
    SVGTransformable {
*/

#define parent_class svg_element_graphics_parent_class



static void
svg_drawable_graphics_draw(SvgDrawable* element, cairo_t* cr)
{
    g_debug("%s", G_STRFUNC);
    RendererObject *renderer = svg_element_graphics_get_renderer(element);
    svg_element_graphics_update_renderer(element);

    gboolean success = renderer_object_draw(renderer, cr);
}

static void
svg_drawable_graphics_interface_init (SvgDrawableInterface *iface)
{
    iface->draw = svg_drawable_graphics_draw;
}

static void
svg_stylable_graphics_interface_init (SvgStylableInterface *iface)
{
    /*iface->get_computed_style  = svg_element_rect_stylable_set_attribute_style;
    iface->get_attribute_style = svg_element_rect_stylable_set_attribute_style;
    iface->get_attribute_class = svg_element_rect_stylable_set_attribute_class;*/
}


/*
 * Returns the tight bounding box in current user space
 * (i.e., after application of the ‘transform’ attribute, if any)
 * on the geometry of all contained graphics elements,
 * exclusive of stroking, clipping, masking and filter effects).
 *
 * Note that getBBox must return the actual bounding box at the time the method was called,
 * even in case the element has not yet been rendered.
 */
static SvgRect*
svg_locatable_graphics_get_bbox(SvgLocatable *locatable)
{
    SvgRect* bounding_box = svg_rect_new();/*FIXME: owner*/
    SvgElement     *element = SVG_ELEMENT(locatable);
    SvgDocument    *svg_doc = SVG_DOCUMENT(dom_node_get_document(DOM_NODE(element)));

//    dom_document_get_root();

    /*TODO don't forget stroke width, effect, etc to compute special bounding box */
    RendererObject *tmp = svg_doc->view->scene->target;
    renderer_scene_set_target(svg_doc->view->scene, element->private_member->renderer);
    RendererBox *box = renderer_view_bounding_box(svg_doc->view, RENDERER_BOUNDING_FILL_MODE);
    renderer_scene_set_target(svg_doc->view->scene, tmp);
    //GeomBox *box = renderer_object_bounding_box(RENDERER_OBJECT(element->private_member->renderer), cr, RENDERER_BOUNDING_FILL_MODE);
    bounding_box->x      = box->left;
    bounding_box->y      = box->bottom;
    bounding_box->width  = box->right - box->left;
    bounding_box->height = box->top - box->bottom;


    /*cairo_matrix_t *matrix = renderer_object_get_transform_abs(RENDERER_OBJECT(element->private_member->renderer));
    cairo_matrix_transform_point();

    SvgTransformList *list = svg_transformable_get_transform(rect);
    SvgMatrix *matrix = svg_transform_list_to_matrix(list);*/


    return bounding_box;
}

SvgMatrix*
svg_locatable_graphics_get_transform (SvgLocatable *locatable)
{
    SvgElement* element = SVG_ELEMENT(locatable);
    SvgElementGraphics* graphics = SVG_ELEMENT_GRAPHICS(element);

    SvgMatrix *matrix = svg_matrix_new_identity();
    xmlNode *child;
    for (child = DOM_NODE(element)->xml; child; child = child->parent) {
        SvgTransformList *transform_list = svg_element_graphics_get_transform(SVG_ELEMENT_GRAPHICS(child->_private));
        SvgMatrix *ctm = svg_transform_list_to_matrix(transform_list);
        svg_matrix_multiply(matrix, ctm);
        g_object_unref(ctm);
        //g_object_unref(transform_list);
    }
    return matrix;

    /*
    // TODO
    SvgTransformList *transform_list = graphics->private_member->transform_list;
//    gchar *str = svg_transform_list_to_string(transform_list);
//    g_print("transform=\"%s\"\n", str);
//    g_free(str);
    SvgMatrix *svg_matrix = svg_transform_list_to_matrix(transform_list);
    svg_matrix_multiply(svg_matrix, matrix);

    return svg_matrix;*/
}

static void
svg_locatable_graphics_interface_init (SvgLocatableInterface *iface)
{
    iface->get_bbox = svg_locatable_graphics_get_bbox;
    //iface->hit_test = svg_locatable_graphics_hit_test;
    iface->get_transform = svg_locatable_graphics_get_transform;

    /*
    SVGRect getBBox();
    SVGMatrix getCTM();
    SVGMatrix getScreenCTM();
    SVGMatrix getTransformToElement(in SVGElement element) raises(SVGException);
    */
}


static SvgTransformList*
svg_transformable_graphics_get_transform (SvgTransformable *transformable)
{
    g_debug("%s", G_STRFUNC);
    //SvgElementRect *rect = SVG_ELEMENT_RECT(transformable);
    //SvgElementRect *rect = SVG_ELEMENT_GRAPHICS(transformable)->private_member->transform;

    return svg_element_graphics_get_transform(SVG_ELEMENT_GRAPHICS(transformable));
    //return rect->transform;
}

void svg_transformable_graphics_set_transform(SvgTransformable *transformable, SvgTransformList *transforms)
{
    g_error("Et merde");
    SvgElement *element = SVG_ELEMENT(transformable);
    SvgTransformList *transform_list = svg_element_graphics_get_transform(SVG_ELEMENT_GRAPHICS(transformable));

    if (transform_list) {
        g_object_unref(transform_list);
    }
    //rect->transform = transforms;
    svg_element_graphics_set_transform(SVG_ELEMENT_GRAPHICS(transformable), transforms);
    /*g_object_ref(element->transform);*/

    ////set_status(SVG_ELEMENT(element), TRANSFORM, MODIFIED);
}

static void
svg_transformable_graphics_interface_init (SvgTransformableInterface *iface)
{
    // readonly attribute SVGAnimatedTransformList transform;

    iface->get_transform = svg_transformable_graphics_get_transform;
    iface->set_transform = svg_transformable_graphics_set_transform;
    /*iface->translate     = svg_transformable_rect_translate;*/
}

static void
svg_element_graphics_finalize (GObject *gobject)
{
    SvgElementGraphics *self = SVG_ELEMENT_GRAPHICS (gobject);
    SvgElementGraphicsPrivate *priv = self->private_member;

    if (priv->transform_list) {
        g_list_free_full(priv->transform_list, g_object_unref);
    }

    /* Always chain up to the parent class; as with dispose(), finalize()
     * is guaranteed to exist on the parent's class virtual function table
     */
    G_OBJECT_CLASS (svg_element_graphics_parent_class)->finalize (gobject);
}

static void
svg_element_graphics_class_init(SvgElementGraphicsClass *klass)
{
    GObjectClass    *gobject_class;
    DomNodeClass *dom_class;
    SvgElementClass *element_class;

    dom_class  = (DomNodeClass *) klass;
    gobject_class    = (GObject *) klass;
    element_class = (SvgElementClass *) klass;

    klass->create_renderer  = svg_element_graphics_default_create_renderer;
    klass->update_renderer  = svg_element_graphics_default_update_renderer;
    klass->hit_test         = svg_element_graphics_default_hit_test;


    /*
    typedef struct _SvgRendererClass{
        void (*transform) (SvgElement *element);
        void (*fill)      (SvgElement *element);
        void (*stroke)    (SvgElement *element);
        void (*path)      (SvgElement *element);
    } SvgRendererClass;

        SvgRendererClass renderer_access;
        SvgRendererClass renderer_create;
        SvgRendererClass renderer_update;
        SvgRendererClass renderer_remove;
    */






#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
    dom_class->dump                   = svg_element_graphics_dump;
#endif
    dom_class->init_from_xml          = svg_element_graphics_init_from_xml;
    element_class->parse_attribute        = svg_element_graphics_parse_attribute;
    element_class->to_string              = svg_element_graphics_to_string;

    gobject_class->get_property     = svg_element_graphics_get_property;
    gobject_class->set_property     = svg_element_graphics_set_property;

    svg_element_graphics_properties[PROPERTY_STYLE] =
      g_param_spec_pointer("style",
                           "Get/Set style attribute",
                           "The style css attribute",
                           G_PARAM_READWRITE);
    svg_element_graphics_properties[PROPERTY_CLASS] =
      g_param_spec_pointer("class",
                           "Get/Set class attribute",
                           "The class css attribute",
                           G_PARAM_READWRITE);

    svg_element_graphics_properties[PROPERTY_STROKE] =
      g_param_spec_pointer("stroke",
                           "Get/Set stroke attribute",
                           "The stroke css attribute",
                           G_PARAM_READWRITE);

    svg_element_graphics_properties[PROPERTY_FILL] =
      g_param_spec_pointer("fill",
                           "Get/Set fill attribute",
                           "The fill css attribute",
                           G_PARAM_READWRITE);

    svg_element_graphics_properties[SVG_PROPERTY_CSS_STROKE_WIDTH] =
      g_param_spec_pointer("stroke-width",
                           "Get/Set stroke width",
                           "The stroke width css attribute",
                           G_PARAM_READWRITE);

    g_object_class_install_properties (gobject_class,
                                       PROPERTIES_NUM,
                                       svg_element_graphics_properties);

	g_type_class_add_private(klass, sizeof(SvgElementGraphicsPrivate));
//	svg_element_graphics_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_graphics_set_property ( GObject      *object,
                                    guint         property_id,
                                    const GValue *value,
                                    GParamSpec   *pspec)
{
    SvgElementGraphics        *self = SVG_ELEMENT_GRAPHICS(object);
    SvgElementGraphicsPrivate *priv = self->private_member;

    switch (property_id)
    {
    case PROPERTY_STYLE:
        priv->style_value = g_value_get_pointer(value);
    break;
    case PROPERTY_CLASS:
        priv->class_value = g_value_get_pointer(value);
    break;
    case PROPERTY_STROKE:
        priv->stroke_value = g_value_get_pointer(value);
    break;
    case PROPERTY_FILL:
    {
        //SvgStyle *style    = svg_element_graphics_get_style(self);
        //style->fill_paint->data.color  = g_value_get_pointer(value);
    }
    break;
    case SVG_PROPERTY_CSS_STROKE_WIDTH:
        svg_element_graphics_get_style(self)->stroke_width = g_value_get_pointer(value);
    break;
    default:
        /* We don't have any other property... */
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, property_id, pspec);
    break;
    }
}

static void
svg_element_graphics_get_property ( GObject    *object,
                                    guint       property_id,
                                    GValue     *value,
                                    GParamSpec *pspec)
{
    SvgElementGraphics        *self = SVG_ELEMENT_GRAPHICS(object);
    SvgElementGraphicsPrivate *priv = self->private_member;
    SvgStyle *style;

    switch (property_id)
    {
    case PROPERTY_STYLE:
        g_value_set_pointer(value, priv->style_value);
    break;
    case PROPERTY_CLASS:
        g_value_set_pointer(value, priv->class_value);
    break;
    case PROPERTY_STROKE:
        g_value_set_pointer(value, priv->stroke_value);
    break;
    case PROPERTY_FILL:
    {
        SvgStyle *style      = svg_element_graphics_get_style(self);
        SvgPaint *fill_paint = svg_style_get_fill(style);
        SvgAnimated *color   = svg_paint_get_animated_color(fill_paint);
        g_value_set_pointer(value, color);
        break;
    }
    case SVG_PROPERTY_CSS_STROKE_WIDTH:
        style = svg_element_graphics_get_style(self);
        g_value_set_pointer(value, style->stroke_width);
    break;

    default:
        /* We don't have any other property... */
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, property_id, pspec);
    break;
    }
}

static void
svg_element_graphics_init (SvgElementGraphics *object)
{
    SvgElementGraphicsPrivate *priv = SVG_ELEMENT_GRAPHICS_GET_PRIVATE(object);
    object->private_member = priv;

    priv->style        = NULL;

    priv->style_value  = 0;
    priv->class_value  = 0;
    priv->stroke_value = 0;
    priv->fill_value   = 0;

    priv->transform_list = svg_transform_list_new();

}

static int
svg_element_graphics_init_from_xml(DomNode* element, xmlNode* node)
{
    /*svg_element_rect_parse_attribute(element, "width", BAD_CAST xmlGetProp(node, "width"));*/
    return DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);
}

static gboolean
svg_element_graphics_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);

    if        (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "transform"))) {
        //SvgTransformList *transform_list = svg_transform_list_new();
        SvgTransformList *transform_list = svg_element_graphics_get_transform(graphics);
        svg_parser_parse_transform(transform_list, value, value+strlen(value));
    //} else if (svg_stylable_parse_attribute(element, rect->presentable, attribute_name, "fill")) {
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "class"))) {
        //svg_element_stylable_parse_class(rect, element, value);
        //svg_parser_parse_transform(rect->transform, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "style"))) {
        //svg_element_stylable_parse_style(rect, element, value);
        //svg_parser_parse_transform(rect->transform, value, value+strlen(value));
    //} else if (svg_/*element_*/stylable_parse_attribute(element, attribute_name)) {
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

static gchar*
svg_element_graphics_to_string(SvgElement *element, gchar *indent)
{
    gchar *content = SVG_ELEMENT_CLASS(svg_element_graphics_parent_class)->to_string(element, indent);
    gchar *tmp = content;
    gchar *tmp_transform;

    SvgTransformList *transform_list = svg_element_graphics_get_transform(element);
    gchar *transform = svg_transform_list_to_string(transform_list);
    tmp_transform = transform;

    transform = g_strdup_printf(", transform=\"%s\"%%s", transform);
    g_free(tmp_transform);

    content = g_strdup_printf(content, transform);
    g_free(tmp);
    g_free(transform);
    tmp = content;

    return content;
}

#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
static gchar*
svg_element_graphics_dump(DomNode *dom, LogDumpOptions *options)
{
#   define PLACE_HOLDER "%%s"
#   define GLUE "%s"
#   define EOL "%s"
#   define TAB "%s"
#   define TYPE_NAME "%s"

    // Use indentation
    gchar *indent;
    gchar *indent_;
    gchar *indent__;
    gchar *new_line;
    gchar *endl;
    gchar *glue_ = g_strdup("");
    gchar *glue = glue_;

    if (options->flags & LOG_DUMP_INDENT_FLAG) {
        size_t num_char = strlen(options->config->indent);
        size_t depth = num_char*options->depth +1;
        size_t depth_ = num_char*(options->depth+1)+1;
        size_t depth__ = num_char*(options->depth+2)+1;
        indent = g_new(gchar, depth);
        memset(indent, options->config->indent[0], depth);
        indent_ = g_new(gchar, depth_);
        memset(indent_, options->config->indent[0], depth_);
        indent__ = g_new(gchar, depth__);
        memset(indent__, options->config->indent[0], depth__);
        indent[depth-1] = '\0';
        indent_[depth_-1] = '\0';
        indent__[depth__-1] = '\0';


        if (options->newl) {
            new_line = g_strdup_printf(EOL""TAB, options->config->endl, indent);
        } else {
            new_line = g_strdup("");
        }
        endl = g_strdup(options->config->endl);
    } else {
        indent   = g_strdup("");
        indent_  = g_strdup("");
        new_line = g_strdup("");
        endl     = g_strdup("");
    }

    SvgElement *element = SVG_ELEMENT(dom);

    LogDumpOptions opt = *options;
    char *content = DOM_NODE_CLASS(svg_element_graphics_parent_class)->dump(dom, &opt);
    gchar *tmp = content;

    if (opt.has_content) {
        glue = options->config->glue;
    }

    SvgTransformList *transform_list = svg_element_graphics_get_transform(element);
    if ((options->flags & SVG_DUMP_TRANSFORM_FLAG) && g_list_length(transform_list->list)) {
        gchar *tmp_transform;

        gchar *transform = svg_transform_list_to_string(transform_list);
        tmp_transform = transform;

        transform = g_strdup_printf(EOL""TAB"transform=\"%s\""GLUE""PLACE_HOLDER, endl, indent_, transform, glue);
        g_free(tmp_transform);

        content = g_strdup_printf(content, transform);
        g_free(tmp);
        g_free(transform);
        tmp = content;
    }

    return content;
}
#endif

SvgStyle *svg_element_graphics_get_style(SvgElementGraphics *graphics)
{
    if (!graphics->private_member->style) {
        graphics->private_member->style = svg_style_new();
    }

    return graphics->private_member->style;
}

/*GraphicsFill* svg_element_get_graphics_fill(SvgElementGraphics *target)
{
    GraphicsFill* graphics_fill = NULL;
    SvgElement *element = SVG_ELEMENT(target);
    SvgPaint *paint = target->private_member->style->fill_paint;

    if (paint) {
        graphics_fill = graphics_fill_new();
        graphics_fill->painter = svg_paint_get_graphics_painter(paint, target);
    } else {
        g_log(NULL, G_LOG_LEVEL_INFO , "No SvgPaint Info in fill for %s", element->name);
    }

    return graphics_fill;
}*/

/*GraphicsStroke* svg_element_get_graphics_stroke(SvgElementGraphics *target)
{
    GraphicsStroke* graphics_stroke = NULL;
    SvgElement *element = SVG_ELEMENT(target);

    SvgPaint *paint = target->private_member->style->stroke_paint;
    if (paint) {
        graphics_stroke = graphics_stroke_new();
        graphics_stroke->width       = svg_length_get_value(target->private_member->style->stroke_width, element);
        graphics_stroke->cap         = GRAPHICS_CAP_ROUND;
        graphics_stroke->join        = GRAPHICS_JOIN_MITER;
        graphics_stroke->miter_limit = 2.0;
        graphics_stroke->painter     = svg_paint_get_graphics_painter(paint, target);
    } else {
        g_log(NULL, G_LOG_LEVEL_INFO , "No SvgPaint Info in stroke in %s", element->name);
    }

    return graphics_stroke;
}*/

GraphicsFill* svg_element_graphics_update_renderer_fill(SvgElementGraphics *target)
{
    GraphicsFill* graphics_fill = NULL;
    SvgElement* element = SVG_ELEMENT(target);

    RendererObject *renderer = RENDERER_OBJECT(element->private_member->renderer);

    SvgStyle *style = svg_element_graphics_get_style(target);
    if (style->fill_paint && RENDERER_IS_SHAPE(renderer)) {
        RendererShape *shape = RENDERER_SHAPE(renderer);
        if (!shape->fill) {
            graphics_fill = graphics_fill_new();
            graphics_fill->painter = svg_paint_get_graphics_painter(style->fill_paint, target);
        } else {
            graphics_fill = shape->fill;
            SvgPaint *paint = style->fill_paint;
            if (paint->type==SVG_PAINT_TYPE_COLOR) {
                GraphicsColor *color = graphics_fill->painter->data.solid->color;
                //SvgColor *paint_color = paint->data.color;
                gdouble time = SVG_DOCUMENT(dom_node_get_document(DOM_NODE(target)))->time->seconds;
                if (paint->color/*is_animated()*/) {
                    guint32 current_color = svg_animated_color_get_value(paint->color, time);
                    color->red = svg_color_value_get_red(current_color) / 255.0;
                    color->green = svg_color_value_get_green(current_color) / 255.0;
                    color->blue = svg_color_value_get_blue(current_color) / 255.0;
                    color->alpha = svg_color_value_get_alpha(current_color) / 255.0;
                } else {
                    color->red = svg_color_get_red(paint->data.color) / 255.0;
                    color->green = svg_color_get_green(paint->data.color) / 255.0;
                    color->blue = svg_color_get_blue(paint->data.color) / 255.0;
                    color->alpha = svg_color_get_alpha(paint->data.color) / 255.0;
                }
            }

        }
    } else {
        g_log(G_LOG_DOMAIN, G_LOG_LEVEL_INFO , "No SvgPaint Info to fill in %s", element->name);
    }

    return graphics_fill;
}

#include "svg-time.h"
//#include "svg-element-path.h"
GraphicsStroke* svg_element_graphics_update_renderer_stroke(SvgElementGraphics *target)
{
    GraphicsStroke* graphics_stroke = NULL;
    SvgElement *element = SVG_ELEMENT(target);


    SvgDocument *document = SVG_DOCUMENT(dom_node_get_document(DOM_NODE(element)));


    SvgStyle *style = target->private_member->style;
    if (style && style->stroke_paint) {
        graphics_stroke = graphics_stroke_new();
        graphics_stroke->width       = svg_animated_length_get_value(style->stroke_width, document->time->seconds);
        graphics_stroke->cap         = GRAPHICS_CAP_SQUARE;
        graphics_stroke->join        = GRAPHICS_JOIN_MITER;
        graphics_stroke->miter_limit = 2.0;
        graphics_stroke->painter     = svg_paint_get_graphics_painter(style->stroke_paint, target);
    } else {
        g_log(G_LOG_DOMAIN, G_LOG_LEVEL_INFO , "No SvgPaint Info to stroke in %s", element->name);
    }

    return graphics_stroke;
}

void svg_element_graphics_update_graphics(SvgElementGraphics *graphics)
{
    SvgElement *element = SVG_ELEMENT(graphics);
    if (TRUE || get_status(element, GRAPHICS) != SVG_UPDATE_STATUS_UPDATE) {
        g_debug("       +%s", G_STRFUNC);
        if (graphics->private_member->style) {

            RendererShape *shape = RENDERER_SHAPE(element->private_member->renderer);

            GraphicsFill* fill;
            GraphicsStroke* stroke;
            fill = svg_element_graphics_update_renderer_fill(graphics);
            stroke = svg_element_graphics_update_renderer_stroke(graphics);

            /*
//            RENDERER_SHAPE(element->private_member->renderer)->graphics.path   = (GraphicsPath*) path;
            */
            RENDERER_SHAPE(element->private_member->renderer)->fill   = fill;
            RENDERER_SHAPE(element->private_member->renderer)->stroke = stroke;
        }
        ////set_status(element, GRAPHICS, UPDATE);
    } else {
        g_debug("        %s", G_STRFUNC);
    }

}

void
svg_element_graphics_update_style(SvgElementGraphics *graphics)
{
    SvgStyle *style = NULL;
    SvgElement *element = SVG_ELEMENT(graphics);

    if (get_status(element, STYLE) == SVG_UPDATE_STATUS_UPDATE) {
        g_debug("        %s", G_STRFUNC);
        return;
    } else {
        g_debug("       +%s", G_STRFUNC);
    }

    xmlNode *node        = DOM_NODE(element)->xml;

    GList *list = DOM_DOCUMENT(dom_node_get_document(DOM_NODE(element)))->stylesheet_list;/*TODO merge each stylesheet */
    CRStyleSheet *stylesheet = list ? g_list_last(list)->data : NULL;
    CRCascade    *cascade    = cr_cascade_new(stylesheet, 0, 0);
    CRSelEng     *selector   = cr_sel_eng_new();

    enum CRStatus status;
    CRPropList *prop_list = NULL;

    status = cr_sel_eng_get_matched_properties_from_cascade(selector, cascade, node, &prop_list);

    if (status != CR_OK)
        fprintf(stderr, "Error retrieving properties\n");
    else if (prop_list)
    {
        CRDeclaration *decl = NULL ;
        CRPropList *cur_pair = NULL ;

        style = svg_element_graphics_get_style(graphics);

        for (cur_pair = prop_list ; cur_pair ;
             cur_pair= cr_prop_list_get_next (cur_pair)) {
            gchar *str = NULL ;
            decl = NULL ;

            cr_prop_list_get_decl (cur_pair, &decl) ;
            if (decl) {
                guchar* value = cr_term_to_string (decl->value);
                svg_style_set_property(style, decl->property->stryng->str, value);
                g_free(value);
            } else {
                g_print("No CRDeclaration for cr_prop_list_get_decl\n");
            }
        }
        cr_prop_list_destroy (prop_list);
    }

    cr_sel_eng_destroy(selector);

    graphics->private_member->style = style;
    ////set_status(element, STYLE, UPDATE);
    ////set_status(element, GRAPHICS, EXPIRED);// TODO check different
}

#include "librenderer/renderer-types.h"
//#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"

void svg_element_graphics_update_transform(SvgElement *element)
{
    if (TRUE || get_status(element, TRANSFORM)!=SVG_UPDATE_STATUS_UPDATE) {
        g_debug("       +%s", G_STRFUNC);

        RendererObject     *renderer  = element->private_member->renderer;
        SvgElement         *owner_elt = SVG_ELEMENT(element->private_member->renderer->data);
        SvgElementGraphics *owner     = (SvgElementGraphics*)owner_elt;

        //g_print("%s(%s)\n", G_OBJECT_TYPE_NAME(element), element->attribute_id);
        /*SvgTransformList *list = svg_element_graphics_get_transform(element);
        gchar *str = svg_transform_list_to_string(list);
        g_print("SvgTransformList: %s\n", str);
        g_free(str);*/

        SvgTransformList *list = svg_element_graphics_get_transform((SvgElementGraphics*)element);
        /*gchar *str = svg_transform_list_to_string(list);
        g_print("SvgTransformList(%s): %s\n", element->attribute_id, str);
        g_free(str);*/
        SvgMatrix *matrix;
        SvgMatrix *svg_matrix = svg_transform_list_to_matrix(list);

/*        if (owner!=element) {
            SvgTransformList *l = svg_element_graphics_get_transform((SvgElementGraphics*)element);
            matrix = svg_transform_list_to_matrix(l);
            cairo_matrix_multiply(&svg_matrix->cairo_matrix, &matrix->cairo_matrix, &svg_matrix->cairo_matrix);
            //svg_matrix_multiply(svg_matrix, matrix);
            g_object_unref(matrix);
        }*/
        renderer_object_set_transform(element->private_member->renderer, &svg_matrix->cairo_matrix);
        renderer_object_notify_transform((RendererObject*)element->private_member->renderer);
        g_object_unref(svg_matrix);


        //set_status(element, TRANSFORM, UPDATE);
    } else {
        g_debug("        %s", G_STRFUNC);
    }
}

void
svg_element_graphics_queue_update(SvgElement *element, SvgUpdateFlags flags, uint types)
{
    RendererObject *renderer  = element->private_member->renderer;
    //RendererObject *container = element->private_member->renderer;

    svg_updater_insert(SVG_ELEMENT_GET_CLASS(element)->updater,
                       element,
                       flags,
                       types);


  // svg_element_graphics_update(TRANSFORM)
    // +
    // if (types & RENDERER_TRANSFORM_MASK != RENDERER_STATUS_UPDATE) {
    //    svg_transform_list_to_c_matrix(transform_list, &renderer->transform);
    //    renderer->transform_is_identity = renderer_matrix_is_identity(&renderer->transform);
    //    renderer_object_notify_transform(renderer);
    // }

    //   + foreach renderer->children as child
    //       renderer_object_notify_change_transform()
    //         +set_cache_status();

    // svg_element_graphics_clear_cache(TRANSFORM)

}


SvgTransformList *svg_element_graphics_get_transform(SvgElementGraphics *graphics)
{
    return graphics->private_member->transform_list;
}

void
svg_element_graphics_set_transform(SvgElementGraphics *graphics, SvgTransformList *transforms)
{
    SvgElementGraphicsPrivate *priv = graphics->private_member;
    if (priv->transform_list) {
        g_object_unref(priv->transform_list);
    }
    priv->transform_list = transforms;
}

static void svg_element_graphics_update_path(SvgElement *element)
{
    //@TODO virtualize
    if (get_status(element, SHAPE)!=SVG_UPDATE_STATUS_UPDATE) {
        g_debug("\t%s", G_STRFUNC);
    }
}


void svg_element_graphics_update(SvgElement *element)
{
    SvgElementPrivate *priv = element->private_member;
    if (!priv->renderer) {
        priv->renderer = renderer_rect_new(SVG_DOCUMENT(dom_node_get_document(DOM_NODE(element)))->view->scene, NULL);
        priv->renderer->data = element;/*attache svg to renderer*/
    }
    g_debug("%s", G_STRFUNC);

    /*1) create style */
    svg_element_graphics_update_style(element);

    /*2) create transformation */
    svg_element_graphics_update_transform(element);

    /*3) create graphics shape */
    svg_element_graphics_update_path(element);

    /*4) create graphics stroke&Fill*/
    svg_element_graphics_update_graphics(element);

}

static RendererObject*
svg_element_graphics_default_create_renderer(SvgElement *element, gboolean attache)
{
    return NULL;
}

static gboolean
svg_element_graphics_default_update_renderer(SvgElement *element)
{
    return TRUE;
}

void
svg_element_graphics_default_hit_test(SvgElement *element, SvgHitRequest *request, SvgHitResult *result)
{
    //g_print("%s on %s\n", G_STRFUNC, G_OBJECT_TYPE_NAME(element));
    RendererObject *renderer = element->private_member->renderer;
    RendererView   *view = renderer->scene->view;
    cairo_t *cr = view->work_context;

    RendererHitTestRequest req;
    req.x      = request->x;
    req.y      = request->y;
    req.type   = RENDERER_HIT_TEST_VISUAL_MODE;
    req.deltat = 0.0;
    RendererHitTestResult rst = {NULL};
    //renderer_view_hit_test(view, renderer, &req, &rst);
    renderer_object_hit_test(renderer, cr, &req, &rst);

    GList* item;
    for(item = rst.items; item; item = item->next) {
        RendererObject *object = (RendererObject *)item->data;
        SvgElement *elt = (SvgElement *)object->data;
        result->elements = g_list_append(result->elements, elt);
    }
}

/* public function */

RendererObject*
svg_element_graphics_get_renderer(SvgElement *element)
{
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);
    SvgElementPrivate *priv = element->private_member;
    //g_debug("  ->%s(%s)", G_STRFUNC, G_OBJECT_TYPE_NAME(graphics));
    if (!priv->renderer) {
        // TODO create svg_element_svg and set root & target
        // next compose get_renderer
        priv->renderer = SVG_ELEMENT_GRAPHICS_GET_CLASS(graphics)->create_renderer(element, TRUE);
    }

    return priv->renderer;
}

RendererObject*
svg_element_graphics_create_renderer(SvgElement *element, gboolean attache)
{
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);
    return SVG_ELEMENT_GRAPHICS_GET_CLASS(graphics)->create_renderer(element, attache);
}

gboolean
svg_element_graphics_update_renderer(SvgElement *element)
{
    g_debug("%s - %s\n", G_STRFUNC, G_OBJECT_TYPE_NAME(element));
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);
    return SVG_ELEMENT_GRAPHICS_GET_CLASS(graphics)->update_renderer(element);
}

void
svg_element_graphics_hit_test(SvgElement *element, SvgHitRequest *request, SvgHitResult *result)
{
    if (!SVG_IS_ELEMENT_GRAPHICS(element))
        return;
    SvgElementGraphics *graphics = SVG_ELEMENT_GRAPHICS(element);
    SVG_ELEMENT_GRAPHICS_GET_CLASS(graphics)->hit_test(element, request, result);
}



SvgElementGraphics *
svg_element_graphics_new (void)
{
	return g_object_new (svg_element_graphics_get_type (),
	                     NULL);
}

