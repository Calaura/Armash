/*
 * svg-length.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_LENGTH_H__
#define __SVG_LENGTH_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_LENGTH_GET_MODE(length)        ((SvgLengthMode) (length)->unit >> 4)
#define SVG_LENGTH_SET_MODE(length, mode)  (length)->unit=((length)->unit & 15 | mode << 4)

#define SVG_LENGTH_GET_TYPE(length)        (SvgLengthType) (length)->unit & 15
#define SVG_LENGTH_SET_TYPE(length, type)  (length)->unit=((length)->unit & (G_MAXUINT-15) | type)


#define SVG_TYPE_LENGTH            (svg_length_get_type())
#define SVG_LENGTH(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_LENGTH, SvgLength))
#define SVG_LENGTH_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_LENGTH, SvgLengthClass))
#define SVG_IS_LENGTH(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_LENGTH))
#define SVG_IS_LENGTH_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_LENGTH))
#define SVG_LENGTH_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_LENGTH, SvgLengthClass))

typedef struct _SvgLengthClass SvgLengthClass;
typedef union  _SvgUnit        SvgUnit;

union _SvgUnit {
  struct {
    unsigned mode: 4;
    unsigned type: 20;
  } bits;
  unsigned int word;
};

struct _SvgLength {
	GObject parent_instance;

    double   value;
    guint    unit;
    gboolean empty;// FIXME what's the use of empty

    SvgElement *context;/* the context for relative length: %percentage*/
};

struct _SvgLengthClass {
	GObjectClass parent_class;
};

GType      svg_length_get_type();
SvgLength *svg_length_new();
SvgLength *svg_length_new_width ();
SvgLength *svg_length_new_height ();

gboolean   svg_length_set_value_from_string(SvgLength *length, gchar* ptr, gchar *end);
void       svg_length_set_value(SvgLength *length, double value, guint unit, gboolean empty);
double     svg_length_get_value(SvgLength *length, SvgElement *context);
gchar     *svg_length_to_string(SvgLength *length);

G_END_DECLS

#endif /* __SVG_LENGTH_H__ */

