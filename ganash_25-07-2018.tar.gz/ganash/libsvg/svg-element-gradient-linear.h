/*
 * svg-element-linear-gradient.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_ELEMENT_GRADIENT_LINEAR_H__
#define __SVG_ELEMENT_GRADIENT_LINEAR_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_ELEMENT_GRADIENT_LINEAR            (svg_element_gradient_linear_get_type())
#define SVG_ELEMENT_GRADIENT_LINEAR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ELEMENT_GRADIENT_LINEAR, SvgElementGradientLinear))
#define SVG_ELEMENT_GRADIENT_LINEAR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ELEMENT_GRADIENT_LINEAR, SvgElementGradientLinearClass))
#define SVG_IS_ELEMENT_GRADIENT_LINEAR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ELEMENT_GRADIENT_LINEAR))
#define SVG_IS_ELEMENT_GRADIENT_LINEAR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ELEMENT_GRADIENT_LINEAR))
#define SVG_ELEMENT_GRADIENT_LINEAR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ELEMENT_GRADIENT_LINEAR, SvgElementGradientLinearClass))

typedef struct _SvgElementGradientLinearClass SvgElementGradientLinearClass;

struct _SvgElementGradientLinear {
    SvgElementGradient parent_instance;

    SvgLength *x1;/* SvgAnimatedLength */
    SvgLength *y1;
    SvgLength *x2;
    SvgLength *y2;
};

struct _SvgElementGradientLinearClass {
    SvgElementGradientClass parent_class;
};

GType svg_element_gradient_linear_get_type(void) G_GNUC_CONST;
void  svg_element_gradient_linear_set_target(SvgElementGradientLinear* gradient, SvgElement *target);


G_END_DECLS

#endif /* __SVG_ELEMENT_GRADIENT_LINEAR_H__ */

