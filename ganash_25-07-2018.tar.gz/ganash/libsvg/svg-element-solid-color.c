/*
 * svg-element-solid-color.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <liblog/log.h>


#include <libgraphics/graphics.h>


#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-color.h"
#include "svg-color-icc.h"
#include "svg-parser.h"
#include "svg-document.h"
#include "svg-updater.h"

#include "svg-element-solid-color.h"

#include <string.h>

static int             svg_element_solid_color_init_from_xml(DomNode *element, xmlNode* node);
static gboolean        svg_element_solid_color_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value);

static RendererObject* svg_element_solid_color_get_renderer(SvgElement *element);


static void svg_element_solid_color_class_init(SvgElementSolidColorClass *klass);
static void svg_element_solid_color_init(SvgElementSolidColor *gobject);

G_DEFINE_TYPE (SvgElementSolidColor, svg_element_solid_color, SVG_TYPE_ELEMENT)

#define parent_class svg_element_solid_color_parent_class

static void
svg_element_solid_color_class_init(SvgElementSolidColorClass *klass)
{
    DomNodeClass *dom_class;
	SvgElementClass *svgelement_class;

    dom_class  = (DomNodeClass *) klass;
	svgelement_class = (SvgElementClass *) klass;

    /*svgelement_class->private_class->get_renderer = svg_element_solid_color_get_renderer;*/
    dom_class->init_from_xml          = svg_element_solid_color_init_from_xml;
    svgelement_class->parse_attribute        = svg_element_solid_color_parse_attribute;


    //svg_element_solid_color_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_solid_color_init (SvgElementSolidColor *object)
{
    object->opacity = 1.0;
}

static int
svg_element_solid_color_init_from_xml(DomNode* element, xmlNode* node)
{
    /*svg_element_rect_parse_attribute(element, "width", BAD_CAST xmlGetProp(node, "width"));*/
    return DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);
}

static gboolean svg_element_solid_color_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_SOLID_COLOR(element));
    SvgElementSolidColor *solid_color = SVG_ELEMENT_SOLID_COLOR(element);

    if        (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "solid-color"))) {
        svg_parser_parse_color(&solid_color->color, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "solid-opacity"))) {
        SvgNumberType type;
        gchar* success = svg_parser_parse_decimal(&solid_color->opacity, &type, value, value+strlen(value));
        if (!success || type!=SVG_NUMBER_PERCENTAGE) {
            solid_color->opacity = 1.0;
            g_message("Notice: wrong solid-opacity");
        }
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}


RendererObject*
svg_element_solid_color_get_renderer(SvgElement* element/*RendererStyle *self*/)
{
    return NULL;
}


