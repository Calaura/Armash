/*
 * svg-element-symbol.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>


#include <libgraphics/graphics.h>


#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-rect.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-document.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-element-graphics.h"
#include "svg-element-g.h"
#include "svg-element-symbol.h"


#define SVG_ELEMENT_SYMBOL_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), SVG_TYPE_ELEMENT_SYMBOL, SvgElementSymbolPrivate))
struct _SvgElementSymbolPrivate {
	int foo;
};


static void svg_element_symbol_class_init(SvgElementSymbolClass *klass);
static void svg_element_symbol_init(SvgElementSymbol *gobject);

G_DEFINE_TYPE (SvgElementSymbol, svg_element_symbol, SVG_TYPE_ELEMENT_G)

static void
svg_element_symbol_class_init(SvgElementSymbolClass *klass)
{
    SvgElementClass *element_class;

    element_class = (SvgElementClass *) klass;

    g_type_class_add_private(klass, sizeof(SvgElementSymbolPrivate));
//	svg_element_symbol_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_symbol_init (SvgElementSymbol *object)
{
	SvgElementSymbolPrivate *priv = SVG_ELEMENT_SYMBOL_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

SvgElementSymbol *
svg_element_symbol_new (void)
{
	return g_object_new (svg_element_symbol_get_type (),
	                     NULL);
}

