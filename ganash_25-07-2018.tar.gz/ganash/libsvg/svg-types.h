/*
 * svg-types.h
 * Copyright (C) 2014       MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_TYPES_H__
#define __SVG_TYPES_H__


typedef struct  _SvgParser                  SvgParser;
typedef enum    _SvgStatus                  SvgStatus;

typedef struct  _SvgUpdater                 SvgUpdater;
typedef guint                               SvgUpdateFlags;
typedef enum    _SvgUpdateFlag              SvgUpdateFlag;
typedef enum    _SvgUpdateStatus            SvgUpdateStatus;
typedef enum    _SvgUpdateShift             SvgUpdateShift;
typedef enum    _SvgUpdateMask              SvgUpdateMask;


typedef enum    _SvgLengthMode              SvgLengthMode;
typedef enum    _SvgLengthType              SvgLengthType;
typedef enum    _SvgTimeType                SvgTimeType;
typedef struct _SvgTimeContainer            SvgTimeContainer;


//typedef enum _SvgNumberDataType  SvgNumberDataType; NUMBER, INTEGER, PERCENTAGE
typedef enum    _SvgNumberType              SvgNumberType;
typedef enum    _SvgOffsetType              SvgOffsetType;

typedef enum    _SvgColorType               SvgColorType;

typedef enum    _SvgPaintType               SvgPaintType;

typedef enum    _SvgSpreadMethodType        SvgSpreadMethodType;
typedef enum    _SvgUnitType                SvgUnitType;
typedef enum    _SvgLineJoinType            SvgLineJoinType;
typedef enum    _SvgLineCapType             SvgLineCapType;

typedef enum    _AnimationMode              AnimationMode;
typedef enum    _AnimatedPropertyState      AnimatedPropertyState;
typedef enum    _AnimatedPropertyType       AnimatedPropertyType;

typedef struct  _SvgPropertyInfo            SvgPropertyInfo;
typedef struct  _SvgAnimatedProperty        SvgAnimatedProperty;
typedef struct  _SvgAnimatedPropertyDescription SvgAnimatedPropertyDescription;
typedef struct  _SvgAnimatedType            SvgAnimatedType;
typedef struct  _SvgAnimatedTypeAnimator    SvgAnimatedTypeAnimator;


typedef struct  _SvgHitRequest              SvgHitRequest;
typedef struct  _SvgHitResult               SvgHitResult;

typedef struct  _SvgDocument                SvgDocument;
typedef struct  _SvgElement                 SvgElement;
typedef struct  _SvgElementSvg              SvgElementSvg;
typedef struct  _SvgElementDefs             SvgElementDefs;
typedef struct  _SvgElementSolidColor       SvgElementSolidColor;
typedef struct  _SvgElementGradient         SvgElementGradient;
typedef struct  _SvgElementGradientLinear   SvgElementGradientLinear;
typedef struct  _SvgElementGradientMesh     SvgElementGradientMesh;
typedef struct  _SvgElementStop             SvgElementStop;
typedef struct  _SvgElementGraphics         SvgElementGraphics;
typedef struct _SvgElementRect             SvgElementRect;
/*typedef struct _SvgElementEllipse          SvgElementCircle;
typedef struct _SvgElementEllipse          SvgElementEllipse;*/
typedef struct  _SvgElementPath             SvgElementPath;
typedef struct  _SvgElementUse              SvgElementUse;
typedef struct  _SvgElementAnimation        SvgElementAnimation;
typedef struct  _SvgElementAnimate          SvgElementAnimate;
typedef struct  _SvgElementAnimateColor     SvgElementAnimateColor;
typedef struct  _SvgAttributeToPropertyMap  SvgAttributeToPropertyMap;


typedef struct  _SvgStyle                   SvgStyle;
typedef enum    _SvgCssPropertyName         SvgCssPropertyName;

typedef struct  _SvgColor                   SvgColor;
typedef struct  _SvgNumber                  SvgNumber;
typedef struct  _SvgLength                  SvgLength;
typedef struct  _SvgTime                    SvgTime;
typedef struct  _SvgPath                    SvgPath;
/*typedef struct _SvgLengthList              SvgLengthList; TODO use GList in SvgLengthList*/
typedef struct  GArray                      SvgLengthList;

typedef struct  _SvgPaint                   SvgPaint;
typedef struct  _SvgMatrix                  SvgMatrix;
typedef struct  _SvgTransform               SvgTransform;
typedef struct  _SvgTransformList           SvgTransformList;

typedef struct  _SvgAnimated                SvgAnimated;
typedef struct  _SvgAnimatedLength          SvgAnimatedLength;
typedef struct  _SvgAnimatedColor           SvgAnimatedColor;

typedef guint                               SvgDumpFlags;
typedef enum    _SvgDumpFlag                SvgDumpFlag;
#define SVG_DUMP_ALL \
    ( LOG_DUMP_ALL \
    | RENDERER_DUMP_ALL \
    | DOM_DUMP_ALL \
    | SVG_DUMP_RECURSIVE_FLAG \
    | SVG_DUMP_POINTER_FLAG \
    | SVG_DUMP_TRANSFORM_FLAG \
    | SVG_DUMP_PATH_FLAG \
    | SVG_DUMP_ID_FLAG \
    | SVG_DUMP_ATTRIBUTES_FLAG \
    | SVG_DUMP_RENDERER_FLAG)

#define SVG_DUMP_ALL_TESTABLE \
    ( LOG_DUMP_ALL \
    | RENDERER_DUMP_ALL_TESTABLE \
    | DOM_DUMP_ALL_TESTABLE \
    | SVG_DUMP_RECURSIVE_FLAG \
    \
    | SVG_DUMP_TRANSFORM_FLAG \
    | SVG_DUMP_PATH_FLAG \
    | SVG_DUMP_ID_FLAG \
    | SVG_DUMP_ATTRIBUTES_FLAG \
    | SVG_DUMP_RENDERER_FLAG)

#define SVG_DUMP_QUICK \
    ( LOG_DUMP_INDENT_FLAG \
    | SVG_DUMP_RECURSIVE_FLAG \
    | SVG_DUMP_ID_FLAG \
    | SVG_DUMP_ATTRIBUTES_FLAG \
    | SVG_DUMP_RENDERER_FLAG)

//typedef SmilElement SvgElementAnimation;


#endif /* __SVG_TYPES_H__ */
