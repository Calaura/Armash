#ifndef SVGANIMATORFACTORY_H
#define SVGANIMATORFACTORY_H

#include "svg-types.h"
#include "svg-enums.h"

SvgAnimatedTypeAnimator*
svg_animator_factory_create(
      SvgElementAnimation* animation_element
    , SvgElement* context_element
    , AnimatedPropertyType attribute_type)
{
    g_assert(animation_element);
    g_assert(context_element);

    switch (attribute_type) {
    /*
    case AnimatedAngle:
        return std::make_unique<SVGAnimatedAngleAnimator>(animationElement, contextElement);
    case AnimatedBoolean:
        return std::make_unique<SVGAnimatedBooleanAnimator>(animationElement, contextElement);
    case AnimatedColor:
        return std::make_unique<SVGAnimatedColorAnimator>(animationElement, contextElement);
    case AnimatedEnumeration:
        return std::make_unique<SVGAnimatedEnumerationAnimator>(animationElement, contextElement);
    case AnimatedInteger:
        return std::make_unique<SVGAnimatedIntegerAnimator>(animationElement, contextElement);
    case AnimatedIntegerOptionalInteger:
        return std::make_unique<SVGAnimatedIntegerOptionalIntegerAnimator>(animationElement, contextElement);
    */
    case AnimatedLength:
        return svg_animated_length_animator_new(animation_element, context_element);
    /*
    case AnimatedLengthList:
        return std::make_unique<SVGAnimatedLengthListAnimator>(animationElement, contextElement);
    case AnimatedNumber:
        return std::make_unique<SVGAnimatedNumberAnimator>(animationElement, contextElement);
    case AnimatedNumberList:
        return std::make_unique<SVGAnimatedNumberListAnimator>(animationElement, contextElement);
    case AnimatedNumberOptionalNumber:
        return std::make_unique<SVGAnimatedNumberOptionalNumberAnimator>(animationElement, contextElement);
    case AnimatedPath:
        return std::make_unique<SVGAnimatedPathAnimator>(animationElement, contextElement);
    case AnimatedPoints:
        return std::make_unique<SVGAnimatedPointListAnimator>(animationElement, contextElement);
    case AnimatedPreserveAspectRatio:
        return std::make_unique<SVGAnimatedPreserveAspectRatioAnimator>(animationElement, contextElement);
    case AnimatedRect:
        return std::make_unique<SVGAnimatedRectAnimator>(animationElement, contextElement);
    case AnimatedString:
        return std::make_unique<SVGAnimatedStringAnimator>(animationElement, contextElement);
    case AnimatedTransformList:
        return std::make_unique<SVGAnimatedTransformListAnimator>(animationElement, contextElement);
    case AnimatedUnknown:
        break;
    */
    }

    //ASSERT_NOT_REACHED();
    return 0;
}


#endif // SVGANIMATORFACTORY_H
