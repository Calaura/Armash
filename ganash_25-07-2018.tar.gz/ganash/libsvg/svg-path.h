/*
 * svg-path.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_PATH_H__
#define __SVG_PATH_H__

#include <glib-object.h>


G_BEGIN_DECLS


enum _SvgPathCommand
{
    SVG_PATH_COMMAND_UNKNOW,
    SVG_PATH_COMMAND_MOVE_TO,
    SVG_PATH_COMMAND_MOVE_TO_REL,
    SVG_PATH_COMMAND_LINE_TO,
    SVG_PATH_COMMAND_LINE_TO_REL,
    SVG_PATH_COMMAND_HLINE_TO,
    SVG_PATH_COMMAND_HLINE_TO_REL,
    SVG_PATH_COMMAND_VLINE_TO,
    SVG_PATH_COMMAND_VLINE_TO_REL,
    SVG_PATH_COMMAND_QUAD_TO,
    SVG_PATH_COMMAND_QUAD_TO_REL,
    SVG_PATH_COMMAND_CUBIC_TO,
    SVG_PATH_COMMAND_CUBIC_TO_REL
};

typedef enum _SvgPathCommand  SvgPathCommand;

#define SVG_PATH_SEGMENT(type, size) \
    typedef struct _SvgPathSegment##type { \
        SvgPathCommand command; \
        double data[size]; \
    } SvgPathSegment##type;


#define DIMENSION_2D 2
SVG_PATH_SEGMENT(, )
SVG_PATH_SEGMENT(Move,     1*DIMENSION_2D)
SVG_PATH_SEGMENT(MoveRel,  1*DIMENSION_2D)
SVG_PATH_SEGMENT(HLine,    1*DIMENSION_2D)
SVG_PATH_SEGMENT(HLineRel, 1*DIMENSION_2D)
SVG_PATH_SEGMENT(VLine,    1*DIMENSION_2D)
SVG_PATH_SEGMENT(VLineRel, 1*DIMENSION_2D)
SVG_PATH_SEGMENT(Line,     1*DIMENSION_2D)
SVG_PATH_SEGMENT(LineRel,  1*DIMENSION_2D)
SVG_PATH_SEGMENT(Quad,     2*DIMENSION_2D)
SVG_PATH_SEGMENT(QuadRel,  2*DIMENSION_2D)
SVG_PATH_SEGMENT(Cubic,    3*DIMENSION_2D)
SVG_PATH_SEGMENT(CubicRel, 3*DIMENSION_2D)


#define SVG_TYPE_PATH            (svg_path_get_type())
#define SVG_PATH(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_PATH, SvgPath))
#define SVG_PATH_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_PATH, SvgPathClass))
#define SVG_IS_PATH(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_PATH))
#define SVG_IS_PATH_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_PATH))
#define SVG_PATH_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_PATH, SvgPathClass))

typedef struct _SvgPathClass SvgPathClass;



struct _SvgPath {
    GObject parent_instance;

    GList *segments;
    /*CorePathStatusType status;*/
    guint              num_segments;
    cairo_path_t*      cairo_path;
    guint              cairo_path_num_data;

};




struct _SvgPathClass {
	GObjectClass parent_class;
};

GType svg_path_get_type();
SvgPath *svg_path_new();
cairo_path_t *svg_path_get_cairo_path(SvgPath *path);
GraphicsPath *svg_path_get_graphics_path(SvgPath* path);

G_END_DECLS

#endif /* __SVG_PATH_H__ */

