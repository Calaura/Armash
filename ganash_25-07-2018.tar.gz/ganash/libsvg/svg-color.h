/*
 * svg-color.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_COLOR_H__
#define __SVG_COLOR_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_COLOR            (svg_color_get_type())
#define SVG_COLOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_COLOR, SvgColor))
#define SVG_COLOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_COLOR, SvgColorClass))
#define SVG_IS_COLOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_COLOR))
#define SVG_IS_COLOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_COLOR))
#define SVG_COLOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_COLOR, SvgColorClass))

typedef struct _SvgColorClass SvgColorClass;

struct _SvgColor {
    GObject parent_instance;

    /*private*/
    SvgColorType type;
    guint32 value;/*ARGB*/
};

struct _SvgColorClass {
	GObjectClass parent_class;
};

GType svg_color_get_type();
SvgColor      *svg_color_new_from_argb(guint32 value);
SvgColor      *svg_color_new_from_string(gchar* string);
GraphicsColor *svg_color_to_graphics_color(SvgColor *svg_color);

gboolean       svg_color_is_none(SvgColor* color);

gchar         *svg_color_to_string(SvgColor* color);


guint8 svg_color_value_get_red(guint32 value);
guint8 svg_color_value_get_green(guint32 value);
guint8 svg_color_value_get_blue(guint32 value);
guint8 svg_color_value_get_alpha(guint32 value);

void svg_color_value_set_red(guint8 red,   guint32 *value);
void svg_color_value_set_green(guint8 green, guint32 *value);
void svg_color_value_set_blue(guint8 blue,  guint32 *value);
void svg_color_value_set_alpha(guint8 alpha, guint32 *value);

guint8         svg_color_get_alpha(SvgColor* color);
guint8         svg_color_get_red(SvgColor* color);
guint8         svg_color_get_green(SvgColor* color);
guint8         svg_color_get_blue(SvgColor* color);

void           svg_color_set_alpha(SvgColor* color, guint8 alpha);
void           svg_color_set_red(SvgColor* color, guint8 red);
void           svg_color_set_green(SvgColor* color, guint8 green);
void           svg_color_set_blue(SvgColor* color, guint8 blue);


G_END_DECLS

#endif /* __SVG_COLOR_H__ */

