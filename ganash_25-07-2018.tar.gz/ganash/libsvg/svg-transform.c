/*
 * svg-transform.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <math.h>

#include <glib-object.h>

#include "svg-types.h"
#include <cairo/cairo.h>
#include "svg-matrix.h"
#include "svg-transform.h"


static void svg_transform_class_init(SvgTransformClass *klass);
static void svg_transform_init(SvgTransform *gobject);

G_DEFINE_TYPE (SvgTransform, svg_transform, G_TYPE_OBJECT)

static void
svg_transform_class_init(SvgTransformClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	svg_transform_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_transform_init (SvgTransform *object)
{
    object->type  = SVG_TRANSFORM_UNKNOWN;
    object->angle = 0.0;
    object->matrix;
}

SvgTransform *
svg_transform_new (void)
{
	return g_object_new (svg_transform_get_type (),
	                     NULL);
}

void svg_transform_set_matrix(SvgTransform *transform, SvgMatrix *matrix)
{
    transform->type = SVG_TRANSFORM_MATRIX;
    transform->matrix.cairo_matrix = matrix->cairo_matrix;
}

void svg_transform_set_translate(SvgTransform *transform, double tx, double ty)
{
    transform->type = SVG_TRANSFORM_TRANSLATE;
    cairo_matrix_init_translate(&transform->matrix.cairo_matrix, tx, ty);
}

void svg_transform_set_scale(SvgTransform *transform, double sx, double sy)
{
    transform->type = SVG_TRANSFORM_SCALE;
    cairo_matrix_init_scale(&transform->matrix.cairo_matrix, sx, sy);
}

void svg_transform_set_rotate(SvgTransform *transform, double angle, double cx, double cy)
{
    double C = cos(angle);
    double S = sin(angle);
    double T = tan(angle);
    transform->type = SVG_TRANSFORM_ROTATE;
    transform->angle = angle;
    cairo_matrix_init(&transform->matrix.cairo_matrix, C,S,-S,C,cx-C*cx+S*cy,cy-S*cx-C*cy);
}

void svg_transform_set_skew_x(SvgTransform *transform, double angle)
{
    double T = tan(angle);
    transform->type = SVG_TRANSFORM_SKEWX;
    transform->angle = angle;
    cairo_matrix_init(&transform->matrix.cairo_matrix, 1, 0, T, 1, 0, 0);
}

void svg_transform_set_skew_y(SvgTransform *transform, double angle)
{
    double T = tan(angle);
    transform->type = SVG_TRANSFORM_SKEWY;
    transform->angle = angle;
    cairo_matrix_init(&transform->matrix.cairo_matrix, 1, T, 0, 1, 0, 0);
}

void svg_transform_translate(SvgTransform *transform, double tx, double ty)
{
    transform->matrix.cairo_matrix.x0 += tx;
    transform->matrix.cairo_matrix.y0 += ty;
}
