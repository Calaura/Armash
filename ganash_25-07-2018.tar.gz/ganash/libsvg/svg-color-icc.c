/*
 * svg-color-icc.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <libgraphics/graphics.h>

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-color.h"

#include "svg-color-icc.h"


static GHashTable* svg_color_icc_table = NULL;

void svg_color_icc_init()
{
    GHashTable* table = g_hash_table_new (g_str_hash, g_str_equal);

    g_hash_table_insert (table, "aliceblue",            svg_color_new_from_argb(0xfff0f8ff));
    g_hash_table_insert (table, "antiquewhite",         svg_color_new_from_argb(0xfffaebd7));
    g_hash_table_insert (table, "aqua",                 svg_color_new_from_argb(0xff00ffff));
    g_hash_table_insert (table, "aquamarine",           svg_color_new_from_argb(0xff7fffd4));
    g_hash_table_insert (table, "azure",                svg_color_new_from_argb(0xfff0ffff));
    g_hash_table_insert (table, "beige",                svg_color_new_from_argb(0xfff5f5dc));
    g_hash_table_insert (table, "bisque",               svg_color_new_from_argb(0xffffe4c4));
    g_hash_table_insert (table, "black",                svg_color_new_from_argb(0xff000000));
    g_hash_table_insert (table, "blanchedalmond",       svg_color_new_from_argb(0xffffebcd));
    g_hash_table_insert (table, "blue",                 svg_color_new_from_argb(0xff0000ff));
    g_hash_table_insert (table, "blueviolet",           svg_color_new_from_argb(0xff8a2be2));
    g_hash_table_insert (table, "brown",                svg_color_new_from_argb(0xffa52a2a));
    g_hash_table_insert (table, "burlywood",            svg_color_new_from_argb(0xffdeb887));
    g_hash_table_insert (table, "cadetblue",            svg_color_new_from_argb(0xff5f9ea0));
    g_hash_table_insert (table, "chartreuse",           svg_color_new_from_argb(0xff7fff00));
    g_hash_table_insert (table, "chocolate",            svg_color_new_from_argb(0xffd2691e));
    g_hash_table_insert (table, "coral",                svg_color_new_from_argb(0xffff7f50));
    g_hash_table_insert (table, "cornflowerblue",       svg_color_new_from_argb(0xff6495ed));
    g_hash_table_insert (table, "cornsilk",             svg_color_new_from_argb(0xfffff8dc));
    g_hash_table_insert (table, "crimson",              svg_color_new_from_argb(0xffdc143c));
    g_hash_table_insert (table, "cyan",                 svg_color_new_from_argb(0xff00ffff));
    g_hash_table_insert (table, "darkblue",             svg_color_new_from_argb(0xff00008b));
    g_hash_table_insert (table, "darkcyan",             svg_color_new_from_argb(0xff008b8b));
    g_hash_table_insert (table, "darkgoldenrod",        svg_color_new_from_argb(0xffb8860b));
    g_hash_table_insert (table, "darkgray",             svg_color_new_from_argb(0xffa9a9a9));
    g_hash_table_insert (table, "darkgrey",             svg_color_new_from_argb(0xffa9a9a9));
    g_hash_table_insert (table, "darkgreen",            svg_color_new_from_argb(0xff006400));
    g_hash_table_insert (table, "darkkhaki",            svg_color_new_from_argb(0xffbdb76b));
    g_hash_table_insert (table, "darkmagenta",          svg_color_new_from_argb(0xff8b008b));
    g_hash_table_insert (table, "darkolivegreen",       svg_color_new_from_argb(0xff556b2f));
    g_hash_table_insert (table, "darkorange",           svg_color_new_from_argb(0xffff8c00));
    g_hash_table_insert (table, "darkorchid",           svg_color_new_from_argb(0xff9932cc));
    g_hash_table_insert (table, "darkred",              svg_color_new_from_argb(0xff8b0000));
    g_hash_table_insert (table, "darksalmon",           svg_color_new_from_argb(0xffe9967a));
    g_hash_table_insert (table, "darkseagreen",         svg_color_new_from_argb(0xff8fbc8f));
    g_hash_table_insert (table, "darkslateblue",        svg_color_new_from_argb(0xff483d8b));
    g_hash_table_insert (table, "darkslategray",        svg_color_new_from_argb(0xff2f4f4f));
    g_hash_table_insert (table, "darkslategrey",        svg_color_new_from_argb(0xff2f4f4f));
    g_hash_table_insert (table, "darkturquoise",        svg_color_new_from_argb(0xff00ced1));
    g_hash_table_insert (table, "darkviolet",           svg_color_new_from_argb(0xff9400d3));
    g_hash_table_insert (table, "deeppink",             svg_color_new_from_argb(0xffff1493));
    g_hash_table_insert (table, "deepskyblue",          svg_color_new_from_argb(0xff00bfff));
    g_hash_table_insert (table, "dimgray",              svg_color_new_from_argb(0xff696969));
    g_hash_table_insert (table, "dimgrey",              svg_color_new_from_argb(0xff696969));
    g_hash_table_insert (table, "dodgerblue",           svg_color_new_from_argb(0xff1e90ff));
    g_hash_table_insert (table, "firebrick",            svg_color_new_from_argb(0xffb22222));
    g_hash_table_insert (table, "floralwhite",          svg_color_new_from_argb(0xfffffaf0));
    g_hash_table_insert (table, "forestgreen",          svg_color_new_from_argb(0xff228b22));
    g_hash_table_insert (table, "fuchsia",              svg_color_new_from_argb(0xffff00ff));
    g_hash_table_insert (table, "gainsboro",            svg_color_new_from_argb(0xffdcdcdc));
    g_hash_table_insert (table, "ghostwhite",           svg_color_new_from_argb(0xfff8f8ff));
    g_hash_table_insert (table, "gold",                 svg_color_new_from_argb(0xffffd700));
    g_hash_table_insert (table, "goldenrod",            svg_color_new_from_argb(0xffdaa520));
    g_hash_table_insert (table, "gray",                 svg_color_new_from_argb(0xff808080));
    g_hash_table_insert (table, "grey",                 svg_color_new_from_argb(0xff808080));
    g_hash_table_insert (table, "green",                svg_color_new_from_argb(0xff008000));
    g_hash_table_insert (table, "greenyellow",          svg_color_new_from_argb(0xffadff2f));
    g_hash_table_insert (table, "honeydew",             svg_color_new_from_argb(0xfff0fff0));
    g_hash_table_insert (table, "hotpink",              svg_color_new_from_argb(0xffff69b4));
    g_hash_table_insert (table, "indianred",            svg_color_new_from_argb(0xffcd5c5c));
    g_hash_table_insert (table, "indigo",               svg_color_new_from_argb(0xff4b0082));
    g_hash_table_insert (table, "ivory",                svg_color_new_from_argb(0xfffffff0));
    g_hash_table_insert (table, "khaki",                svg_color_new_from_argb(0xfff0e68c));
    g_hash_table_insert (table, "lavender",             svg_color_new_from_argb(0xffe6e6fa));
    g_hash_table_insert (table, "lavenderblush",        svg_color_new_from_argb(0xfffff0f5));
    g_hash_table_insert (table, "lawngreen",            svg_color_new_from_argb(0xff7cfc00));
    g_hash_table_insert (table, "lemonchiffon",         svg_color_new_from_argb(0xfffffacd));
    g_hash_table_insert (table, "lightblue",            svg_color_new_from_argb(0xffadd8e6));
    g_hash_table_insert (table, "lightcoral",           svg_color_new_from_argb(0xfff08080));
    g_hash_table_insert (table, "lightcyan",            svg_color_new_from_argb(0xffe0ffff));
    g_hash_table_insert (table, "lightgoldenrodyellow", svg_color_new_from_argb(0xfffafad2));
    g_hash_table_insert (table, "lightgray",            svg_color_new_from_argb(0xffd3d3d3));
    g_hash_table_insert (table, "lightgrey",            svg_color_new_from_argb(0xffd3d3d3));
    g_hash_table_insert (table, "lightgreen",           svg_color_new_from_argb(0xff90ee90));
    g_hash_table_insert (table, "lightpink",            svg_color_new_from_argb(0xffffb6c1));
    g_hash_table_insert (table, "lightsalmon",          svg_color_new_from_argb(0xffffa07a));
    g_hash_table_insert (table, "lightseagreen",        svg_color_new_from_argb(0xff20b2aa));
    g_hash_table_insert (table, "lightskyblue",         svg_color_new_from_argb(0xff87cefa));
    g_hash_table_insert (table, "lightslateblue",       svg_color_new_from_argb(0xff8470ff));
    g_hash_table_insert (table, "lightslategray",       svg_color_new_from_argb(0xff778899));
    g_hash_table_insert (table, "lightslategrey",       svg_color_new_from_argb(0xff778899));
    g_hash_table_insert (table, "lightsteelblue",       svg_color_new_from_argb(0xffb0c4de));
    g_hash_table_insert (table, "lightyellow",          svg_color_new_from_argb(0xffffffe0));
    g_hash_table_insert (table, "lime",                 svg_color_new_from_argb(0xff00ff00));
    g_hash_table_insert (table, "limegreen",            svg_color_new_from_argb(0xff32cd32));
    g_hash_table_insert (table, "linen",                svg_color_new_from_argb(0xfffaf0e6));
    g_hash_table_insert (table, "magenta",              svg_color_new_from_argb(0xffff00ff));
    g_hash_table_insert (table, "maroon",               svg_color_new_from_argb(0xff800000));
    g_hash_table_insert (table, "mediumaquamarine",     svg_color_new_from_argb(0xff66cdaa));
    g_hash_table_insert (table, "mediumblue",           svg_color_new_from_argb(0xff0000cd));
    g_hash_table_insert (table, "mediumorchid",         svg_color_new_from_argb(0xffba55d3));
    g_hash_table_insert (table, "mediumpurple",         svg_color_new_from_argb(0xff9370db));
    g_hash_table_insert (table, "mediumseagreen",       svg_color_new_from_argb(0xff3cb371));
    g_hash_table_insert (table, "mediumslateblue",      svg_color_new_from_argb(0xff7b68ee));
    g_hash_table_insert (table, "mediumspringgreen",    svg_color_new_from_argb(0xff00fa9a));
    g_hash_table_insert (table, "mediumturquoise",      svg_color_new_from_argb(0xff48d1cc));
    g_hash_table_insert (table, "mediumvioletred",      svg_color_new_from_argb(0xffc71585));
    g_hash_table_insert (table, "midnightblue",         svg_color_new_from_argb(0xff191970));
    g_hash_table_insert (table, "mintcream",            svg_color_new_from_argb(0xfff5fffa));
    g_hash_table_insert (table, "mistyrose",            svg_color_new_from_argb(0xffffe4e1));
    g_hash_table_insert (table, "moccasin",             svg_color_new_from_argb(0xffffe4b5));
    g_hash_table_insert (table, "navajowhite",          svg_color_new_from_argb(0xffffdead));
    g_hash_table_insert (table, "navy",                 svg_color_new_from_argb(0xff000080));
    g_hash_table_insert (table, "oldlace",              svg_color_new_from_argb(0xfffdf5e6));
    g_hash_table_insert (table, "olive",                svg_color_new_from_argb(0xff808000));
    g_hash_table_insert (table, "olivedrab",            svg_color_new_from_argb(0xff6b8e23));
    g_hash_table_insert (table, "orange",               svg_color_new_from_argb(0xffffa500));
    g_hash_table_insert (table, "orangered",            svg_color_new_from_argb(0xffff4500));
    g_hash_table_insert (table, "orchid",               svg_color_new_from_argb(0xffda70d6));
    g_hash_table_insert (table, "palegoldenrod",        svg_color_new_from_argb(0xffeee8aa));
    g_hash_table_insert (table, "palegreen",            svg_color_new_from_argb(0xff98fb98));
    g_hash_table_insert (table, "paleturquoise",        svg_color_new_from_argb(0xffafeeee));
    g_hash_table_insert (table, "palevioletred",        svg_color_new_from_argb(0xffdb7093));
    g_hash_table_insert (table, "papayawhip",           svg_color_new_from_argb(0xffffefd5));
    g_hash_table_insert (table, "peachpuff",            svg_color_new_from_argb(0xffffdab9));
    g_hash_table_insert (table, "peru",                 svg_color_new_from_argb(0xffcd853f));
    g_hash_table_insert (table, "pink",                 svg_color_new_from_argb(0xffffc0cb));
    g_hash_table_insert (table, "plum",                 svg_color_new_from_argb(0xffdda0dd));
    g_hash_table_insert (table, "powderblue",           svg_color_new_from_argb(0xffb0e0e6));
    g_hash_table_insert (table, "purple",               svg_color_new_from_argb(0xff800080));
    g_hash_table_insert (table, "red",                  svg_color_new_from_argb(0xffff0000));
    g_hash_table_insert (table, "rosybrown",            svg_color_new_from_argb(0xffbc8f8f));
    g_hash_table_insert (table, "royalblue",            svg_color_new_from_argb(0xff4169e1));
    g_hash_table_insert (table, "saddlebrown",          svg_color_new_from_argb(0xff8b4513));
    g_hash_table_insert (table, "salmon",               svg_color_new_from_argb(0xfffa8072));
    g_hash_table_insert (table, "sandybrown",           svg_color_new_from_argb(0xfff4a460));
    g_hash_table_insert (table, "seagreen",             svg_color_new_from_argb(0xff2e8b57));
    g_hash_table_insert (table, "seashell",             svg_color_new_from_argb(0xfffff5ee));
    g_hash_table_insert (table, "sienna",               svg_color_new_from_argb(0xffa0522d));
    g_hash_table_insert (table, "silver",               svg_color_new_from_argb(0xffc0c0c0));
    g_hash_table_insert (table, "skyblue",              svg_color_new_from_argb(0xff87ceeb));
    g_hash_table_insert (table, "slateblue",            svg_color_new_from_argb(0xff6a5acd));
    g_hash_table_insert (table, "slategray",            svg_color_new_from_argb(0xff708090));
    g_hash_table_insert (table, "slategrey",            svg_color_new_from_argb(0xff708090));
    g_hash_table_insert (table, "snow",                 svg_color_new_from_argb(0xfffffafa));
    g_hash_table_insert (table, "springgreen",          svg_color_new_from_argb(0xff00ff7f));
    g_hash_table_insert (table, "steelblue",            svg_color_new_from_argb(0xff4682b4));
    g_hash_table_insert (table, "tan",                  svg_color_new_from_argb(0xffd2b48c));
    g_hash_table_insert (table, "teal",                 svg_color_new_from_argb(0xff008080));
    g_hash_table_insert (table, "thistle",              svg_color_new_from_argb(0xffd8bfd8));
    g_hash_table_insert (table, "tomato",               svg_color_new_from_argb(0xffff6347));
    g_hash_table_insert (table, "transparent",          svg_color_new_from_argb(0x00000000));
    g_hash_table_insert (table, "turquoise",            svg_color_new_from_argb(0xff40e0d0));
    g_hash_table_insert (table, "violet",               svg_color_new_from_argb(0xffee82ee));
    g_hash_table_insert (table, "violetred",            svg_color_new_from_argb(0xffd02090));
    g_hash_table_insert (table, "wheat",                svg_color_new_from_argb(0xfff5deb3));
    g_hash_table_insert (table, "white",                svg_color_new_from_argb(0xffffffff));
    g_hash_table_insert (table, "whitesmoke",           svg_color_new_from_argb(0xfff5f5f5));
    g_hash_table_insert (table, "yellow",               svg_color_new_from_argb(0xffffff00));
    g_hash_table_insert (table, "yellowgreen",          svg_color_new_from_argb(0xff9acd32));


    svg_color_icc_table = table;
}


SvgColor*
svg_color_icc_lookup (const guchar * name)
{
    SvgColor *color;

    if (!name) {
        return NULL;
    }

    if (!svg_color_icc_table) {
        svg_color_icc_init();
    }

    color = (SvgColor*) g_hash_table_lookup (svg_color_icc_table, name);

    if (!color) {
        /*gchar* msg = g_strdup_printf("<%s> is not a color ICC", (gchar*) name);*/
        /*g_warn_message("LibSvg", __FILE__, __LINE__, G_STRFUNC, msg);*/
        g_message("<%s> is not a color ICC", (gchar*) name);
        /*g_free(msg);*/
        return NULL;
    }

    return color;
}
