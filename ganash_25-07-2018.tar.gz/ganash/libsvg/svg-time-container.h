/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-time-container.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_TIME_CONTAINER_H__
#define __SVG_TIME_CONTAINER_H__



G_BEGIN_DECLS

#define SVG_TYPE_TIME_CONTAINER            (svg_time_container_get_type())
#define SVG_TIME_CONTAINER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_TIME_CONTAINER, SvgTimeContainer))
#define SVG_TIME_CONTAINER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_TIME_CONTAINER, SvgTimeContainerClass))
#define SVG_IS_TIME_CONTAINER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_TIME_CONTAINER))
#define SVG_IS_TIME_CONTAINER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_TIME_CONTAINER))
#define SVG_TIME_CONTAINER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_TIME_CONTAINER, SvgTimeContainerClass))

typedef struct _SvgTimeContainerClass SvgTimeContainerClass;

//    typedef std::pair<SVGElement*, QualifiedName> ElementAttributePair;
//    typedef Vector<SVGSMILElement*> AnimationsVector;
//    typedef HashMap<ElementAttributePair, std::unique_ptr<AnimationsVector>> GroupedAnimationsMap;
typedef struct _AttributeHash {
    //unsigned int tag_id : 7;// 0-128 (a|animate|[...])
    unsigned int type_id : 1;// 0-1 (css|xml)
    unsigned int attribute_id : 8;// 0-256 (x, fill-color|stroke-width|[...]|z-index)
    unsigned int remain_instance_id : 16;// element instance count by tagName (0-65'536)
                                   // 23;//
} AttributeHash;
typedef struct _SvgScheduleHash {
    AttributeHash attribute;
    SvgElement* ref_id;
} SvgScheduleHash;
typedef struct _SvgSchedule{
    // GHashTable<AttributeHash> = GList*;
    // GHashTable<AttributeHash, SvgElement*> = GArray<SmilElement*>();
    //
    SvgElement *target;
    DomQualifiedName attribute;
    GSList *animations;// of SvgElementAnimation sorted by priority
} SvgSchedule;


struct _SvgTimeContainer {
	GObject parent_instance;

    SvgDocument *document;//SvgElementSvg* m_ownerSVGElement;

    gdouble begin_time;
    gdouble pause_time;
    gdouble accumulated_active_time;
    gdouble resume_time;
    gdouble preset_start_time;

    //bool m_documentOrderIndexesDirty;

    //Timer<SMILTimeContainer> timer;

    /**
     * @brief reference of SvgElementAnimation
     * @param active_animations GArray<SvgSchedule*> *
     */
    GArray *active_animations;//  animation to apply
    /**
     * @brief The scheduled animations element
     * @param scheduled_animations GArray<SvgSchedule > *
     */
    GArray *scheduled_animations;// scheduled animations
};


struct _SvgTimeContainerClass {
	GObjectClass parent_class;
};

GType svg_time_container_get_type();
SvgTimeContainer *svg_time_container_new(SvgDocument *document);

void              svg_time_container_update_animations(
                                             SvgTimeContainer *time_container,
                                             SvgTime *elapsed,
                                             gboolean seek_to_time/* = false*/);
void              svg_time_container_schedule(SvgTimeContainer *container,
                                              SvgElementAnimation *animation,
                                              SvgElement *target,
                                              DomQualifiedName *attribute);
//void              svg_time_container_unschedule(SVGSMILElement*, SVGElement*, const QualifiedName&);

void svg_time_container_elapsed(SvgTimeContainer *container, SvgTime*elapsed);
//void svg_time_container_timer_fired(Timer<SMILTimeContainer>*);
//void svg_time_container_start_timer(SvgTime *fireTime, SvgTime minimumDelay/*=0*/);


G_END_DECLS

#endif /* __SVG_TIME_CONTAINER_H__ */

