/*
 * svg-element-path.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>


#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"

#include <libgraphics/graphics.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-box.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-rect.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-scene.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-stylable.h"
#include "svg-style.h"
#include "svg-color.h"
#include "svg-paint.h"
#include "svg-drawable.h"
#include "svg-path.h"
#include "svg-length.h"
#include "svg-matrix.h"
#include "svg-transform.h"
#include "svg-transform-list.h"
#include "svg-transformable.h"
#include "svg-rect.h"
#include "svg-locatable.h"
#include "svg-document.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-element-graphics.h"
#include "svg-element-path.h"
#include "svg-updater.h"


#define SVG_ELEMENT_PATH_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), SVG_TYPE_ELEMENT_PATH, SvgElementPathPrivate))
struct _SvgElementPathPrivate {
	int foo;
};


static int               svg_element_path_init_from_xml(DomNode *element, xmlNode* node);
static gboolean          svg_element_path_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value);
static gchar*            svg_element_path_to_string(SvgElement *element);

static RendererObject*   svg_element_path_create_renderer(SvgElement *graphics, gboolean attache);
static gboolean          svg_element_path_update_renderer(SvgElement *element);

static void              svg_element_path_class_init(SvgElementPathClass *klass);
static void              svg_element_path_init(SvgElementPath *gobject);


G_DEFINE_TYPE (SvgElementPath, svg_element_path, SVG_TYPE_ELEMENT_GRAPHICS)
#define parent_class svg_element_path_parent_class

static void
svg_element_path_class_init(SvgElementPathClass *klass)
{
    GObjectClass *object_class;
    DomNodeClass *dom_class;
    SvgElementClass *element_class;
    SvgElementGraphicsClass *graphics_class;

    dom_class  = (DomNodeClass *) klass;
    object_class   = (GObject *) klass;
    element_class  = (SvgElementClass *) klass;
    graphics_class = (SvgElementGraphicsClass *) klass;

    graphics_class->create_renderer       = svg_element_path_create_renderer;
    graphics_class->update_renderer       = svg_element_path_update_renderer;

    dom_class->init_from_xml          = svg_element_path_init_from_xml;
    element_class->parse_attribute        = svg_element_path_parse_attribute;

    element_class->to_string              = svg_element_path_to_string;

	g_type_class_add_private(klass, sizeof(SvgElementPathPrivate));
//    svg_element_path_parent_class = g_type_class_peek_parent (klass);

}


static void
svg_element_path_init (SvgElementPath *object)
{
	SvgElementPathPrivate *priv = SVG_ELEMENT_PATH_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;

    object->path = svg_path_new();
    object->transform = svg_transform_list_new();
}

/* deprecate */
static void
svg_element_path_transformable_translate(SvgTransformable *transformable, double tx, double ty)
{
    SvgElementPath *path = SVG_ELEMENT_PATH(transformable);
    SvgElement     *element = (SvgElement*) path;

    /*set_status(path, SVG_ELEMENT_PATH_TRANSFORM, SVG_ELEMENT_RECT_STATUS_MODIFIED);
    set_status(path, SVG_ELEMENT_PATH_SHAPE, SVG_ELEMENT_RECT_STATUS_EXPIRED);
    set_status(path, SVG_ELEMENT_PATH_STYLE, SVG_ELEMENT_RECT_STATUS_EXPIRED);*/


    GList *list;
    for (list = g_list_first(path->transform->list); list; list = list->next) {
        SvgTransform *transform = list->data;
        if (transform->type == SVG_TRANSFORM_TRANSLATE) {
            svg_matrix_translate(&transform->matrix, tx, ty);
            g_debug("*svg_matrix_translate: tx, ty: %f, %f", tx, ty);

            /*rect->x->baseVal->value += tx;
            rect->y->baseVal->value += ty;*/

            /*SvgAnimated *x_anim = rect->x;
            double from = rect->x->baseVal->value;
            double to = motion_animation_get_to(x_anim->property);
            motion_animation_set_values(x_anim->property, from, to);*/
            return;
        }
    }
    g_print("!!!!!!! svg_matrix_translate: tx, ty: %f, %f\n", tx, ty);

    SvgTransform   *translate = svg_transform_new();
    svg_transform_set_translate(translate, tx, ty);
    svg_transform_list_append(path->transform, translate);

    /*set_status();*/
}


/* deprecate */
/*static void svg_element_path_update_renderer_transform(SvgElement *element)
{
//    if (get_status(SVG_ELEMENT_RECT(element), SVG_ELEMENT_RECT_TRANSFORM)!=SVG_ELEMENT_RECT_STATUS_SUCCESS) {
        SvgTransformList *transform_list = SVG_ELEMENT_PATH(element)->transform;

        SvgMatrix     *transform     = svg_transform_list_to_matrix(transform_list);
        renderer_object_set_transform(SVG_ELEMENT(element)->private_member->renderer, &transform->cairo_matrix);
        g_object_unref(transform);
//        set_status(SVG_ELEMENT_RECT(element), SVG_ELEMENT_RECT_TRANSFORM, SVG_ELEMENT_RECT_STATUS_SUCCESS);
//    }
}*/


static void svg_element_path_update_renderer_path(SvgElement *element)
{
    SvgElementPath *path = SVG_ELEMENT_PATH(element);
    double seconde = svg_element_get_time(element);

    if (get_status(element, SHAPE) != SVG_UPDATE_STATUS_UPDATE) {
        g_debug("       +%s", G_STRFUNC);

        GraphicsPath* p = svg_path_get_graphics_path(path->path);
        renderer_shape_set_path(RENDERER_SHAPE(element->private_member->renderer), p);
        ///cairo_path_t* p = svg_path_get_cairo_path(path->path);
//        GraphicsPath *g_path = renderer_shape_get_path(RENDERER_SHAPE(element->private_member->renderer));
//        graphics_path_set(g_path, p);
        set_status(element, SHAPE, UPDATE);
//        set_status(rect->status_xml, SVG_ELEMENT_RECT_SHAPE, SVG_ELEMENT_STATUS_UPDATE);
//        set_status(rect->status_renderer, SVG_ELEMENT_RECT_SHAPE, SVG_ELEMENT_STATUS_UPDATE);
    } else {
        g_debug("        %s", G_STRFUNC);
    }
}


static gboolean svg_element_path_update_renderer(SvgElement *element)
{
    //double time = svg_element_get_time(element);
    g_debug("    %s", G_STRFUNC);

    /*1) create style */
    //svg_element_rect_update_renderer_style(element);
    svg_element_graphics_update_style(element);

    /*2) create transformation */
    //svg_element_rect_update_renderer_transform(element);
    svg_element_graphics_update_transform(element);

    /*3) create graphics shape */
    svg_element_path_update_renderer_path(element);

    /*4) create graphics stroke&Fill*/
    //svg_element_rect_update_renderer_graphics(element);
    svg_element_graphics_update_graphics(element);

    //renderer_object_update(element->private_member->renderer);
}

static RendererObject*
svg_element_path_create_renderer(SvgElement* element, gboolean attache)
{
    g_log(G_LOG_DOMAIN, G_LOG_LEVEL_DEBUG, "    %s(%s#%s)", G_STRFUNC, G_OBJECT_TYPE_NAME(element), element->attribute_id);

    RendererObject* renderer;

    SvgDocument *document = SVG_DOCUMENT(dom_node_get_document(DOM_NODE(element)));
    renderer = (RendererObject*) renderer_shape_new (document->view->scene, element->attribute_id);
    renderer->data = element;

    if (attache) {
        element->private_member->renderer = renderer;
    }

    return renderer;
}

static int
svg_element_path_init_from_xml(DomNode* element, xmlNode *node)
{
    return DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);
    /*svg_element_graphics_parse_attribute(element, "width", BAD_CAST xmlGetProp(node, "width"));*/
}

static gchar*
svg_element_path_to_string(SvgElement *element)
{
    gchar * str = "SvgElementPath{ }";
    return str;
}

static gboolean
svg_element_path_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_PATH(element));
    SvgElementPath *path = SVG_ELEMENT_PATH(element);

    if        (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "d"))) {
        svg_parser_parse_path_from_buffer(path->path, value, value+strlen(value));
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

SvgElement *
svg_element_path_new (void)
{
    SvgElementPath *path;
    path = g_object_new (SVG_TYPE_ELEMENT_PATH, NULL);
    /**/
    return (SvgElement *) path;
}

