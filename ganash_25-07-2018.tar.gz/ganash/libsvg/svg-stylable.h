/*
 * svg-stylable.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_STYLABLE_H__
#define __SVG_STYLABLE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_STYLABLE                (svg_stylable_get_type ())
#define SVG_STYLABLE(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  SVG_TYPE_STYLABLE,  SvgStylable))
#define SVG_IS_STYLABLE(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  SVG_TYPE_STYLABLE))
#define SVG_STYLABLE_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  SVG_TYPE_STYLABLE,  SvgStylableInterface))

typedef struct _SvgStylable  SvgStylable; /* dummy object */
typedef struct _SvgStylableInterface  SvgStylableInterface;

struct _SvgStylableInterface
{
	GTypeInterface parent;
	void (*do_action) ( SvgStylable *self);
};

GType  svg_stylable_get_type (void);
void svg_stylable_do_action (SvgStylable *self);

/*void svg_stylable_get_attribute_class (SvgStylable *self);
void svg_stylable_get_attribute_style (SvgStylable *self);*/

/*
  readonly attribute SVGAnimatedString className;
  readonly attribute CSSStyleDeclaration style;

  CSSValue getPresentationAttribute(in DOMString name);
*/

G_END_DECLS

#endif /* __SVG_STYLABLE_H__ */

