/*
 * svg-matrix.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <cairo/cairo.h>

#include <glib-object.h>

#include "svg-types.h"
#include "svg-matrix.h"

#include <string.h>

static void svg_matrix_class_init(SvgMatrixClass *klass);
static void svg_matrix_init(SvgMatrix *gobject);

G_DEFINE_TYPE (SvgMatrix, svg_matrix, G_TYPE_OBJECT)

static void
svg_matrix_class_init(SvgMatrixClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	svg_matrix_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_matrix_init (SvgMatrix *object)
{
    object->empty = TRUE;
}

void
svg_matrix_translate(SvgMatrix* matrix, double tx, double ty)
{
    cairo_matrix_translate(&matrix->cairo_matrix, tx, ty);
}

void
svg_matrix_init_translate(SvgMatrix* matrix, double tx, double ty)
{
    cairo_matrix_init_translate(&matrix->cairo_matrix, tx, ty);
}

void
svg_matrix_multiply(SvgMatrix *matrix, SvgMatrix *ctm)
{
    cairo_matrix_multiply(&matrix->cairo_matrix, &matrix->cairo_matrix, &ctm->cairo_matrix);
}


/*
SVGMatrix translate(double tx, double ty)
{
    AffineTransform copy = *this;
    copy.translate(tx, ty);
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix(double a, double b, double c, double d, double e, double f)
    : AffineTransform(a, b, c, d, e, f)
{
}

SVGMatrix translate(double tx, double ty)
{
    AffineTransform copy = *this;
    copy.translate(tx, ty);
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix scale(double s)
{
    AffineTransform copy = *this;
    copy.scale(s, s);
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix scaleNonUniform(double sx, double sy)
{
    AffineTransform copy = *this;
    copy.scale(sx, sy);
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix rotate(double d)
{
    AffineTransform copy = *this;
    copy.rotate(d);
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix flipX()
{
    AffineTransform copy = *this;
    copy.flipX();
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix flipY()
{
    AffineTransform copy = *this;
    copy.flipY();
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix skewX(double angle)
{
    AffineTransform copy = *this;
    copy.skewX(angle);
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix skewY(double angle)
{
    AffineTransform copy = *this;
    copy.skewY(angle);
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix multiply(const SVGMatrix& other)
{
    AffineTransform copy = *this;
    copy *= static_cast<const AffineTransform&>(other);
    return static_cast<SVGMatrix>(copy);
}

SVGMatrix inverse(ExceptionCode& ec) const
{
    AffineTransform transform = AffineTransform::inverse();
    if (!isInvertible())
        ec = SVGException::SVG_MATRIX_NOT_INVERTABLE;

    return transform;
}

SVGMatrix rotateFromVector(double x, double y, ExceptionCode& ec)
{
    if (!x || !y)
        ec = SVGException::SVG_INVALID_VALUE_ERR;

    AffineTransform copy = *this;
    copy.rotateFromVector(x, y);
    return static_cast<SVGMatrix>(copy);
}
*/
SvgMatrix *
svg_matrix_new_init (double a, double b, double c, double d, double e, double f)
{
    SvgMatrix *svg_matrix;
    svg_matrix = (SvgMatrix *) g_object_new (svg_matrix_get_type (), NULL);

    cairo_matrix_init(&svg_matrix->cairo_matrix, a, b, c, d, e, f);
    /*
    svg_matrix->cairo_matrix.xx = a;
    svg_matrix->cairo_matrix.yx = b;
    svg_matrix->cairo_matrix.xy = c;
    svg_matrix->cairo_matrix.yy = d;
    svg_matrix->cairo_matrix.x0 = e;
    svg_matrix->cairo_matrix.y0 = f;
    */

    return svg_matrix;
}

SvgMatrix *svg_matrix_new_identity()
{
    SvgMatrix *svg_matrix;
    svg_matrix = (SvgMatrix *) g_object_new (svg_matrix_get_type (), NULL);

    cairo_matrix_init_identity(&svg_matrix->cairo_matrix);
    /*
    svg_matrix->cairo_matrix.xx = 0.0;
    svg_matrix->cairo_matrix.yx = 0.0;
    svg_matrix->cairo_matrix.xy = 1.0;
    svg_matrix->cairo_matrix.yy = 0.0;
    svg_matrix->cairo_matrix.x0 = 0.0;
    svg_matrix->cairo_matrix.y0 = 1.0;
    */

    return svg_matrix;
}

/*@FIXME */
gboolean svg_matrix_set_value_from_string(SvgMatrix *matrix, gchar *value)
{
    matrix->empty = TRUE;
    size_t len = strlen(value);
    if (len==0) {
        return TRUE;
    }
    gchar *token = svg_parser_parse_transform(matrix, value, value+len);
    if (token) {
        matrix->empty = FALSE;
        return TRUE;
    }
    return FALSE;
}
