/*
 * svg-element.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ELEMENT_SVG_H__
#define __ELEMENT_SVG_H__


G_BEGIN_DECLS


#define SVG_TYPE_ELEMENT            (svg_element_get_type())
#define SVG_ELEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ELEMENT, SvgElement))
#define SVG_ELEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ELEMENT, SvgElementClass))
#define SVG_IS_ELEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ELEMENT))
#define SVG_IS_ELEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ELEMENT))
#define SVG_ELEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ELEMENT, SvgElementClass))

typedef struct _SvgElementPrivate      SvgElementPrivate;
//typedef struct _SvgElementPrivateClass SvgElementPrivateClass;
typedef struct _SvgElementClass        SvgElementClass;

typedef struct _SvgElementList SvgElementList;
struct _SvgElementList {/* used to browse data in qt creator debugger */
    SvgElement*     data;
    SvgElementList* prev;
    SvgElementList* next;
};

struct _SvgElement {
    DomElement parent_instance;

    /*public*/
    gpointer *data; /* application data*/

    //SvgDocument       *document;
    //SvgElementList    *children;
    //SvgElement        *parent;

    const gchar       *name;
    const char        *attribute_id;

    /* private */
    guint status_update;/* 00 00 00 00       Bitwise: 00 UPDATE; 11 EXPIRED */
                        /*  ^  ^  ^  ^                                      */
                        /*  |  |  |  |                                      */
                        /*  |  |  |  +--> shape                             */
                        /*  |  |  +--> transform                            */
                        /*  |  +--> style                                   */
                        /*  +--> graphics/renderer                          */

    SvgElementPrivate *private_member;
};

struct _SvgElementClass {
    DomElementClass parent_class;

    /* DOM interface */
    //int             (* init_from_xml)          (SvgElement*, xmlNode*);/*FIXME: maybe remove this function */
    gboolean        (* parse_attribute)        (SvgElement*, DomQualifiedName *qualified_name, guchar* value);

    gchar*          (* to_string)              (SvgElement *element, gchar *indent);

    /* SVG TRAITS */
    SvgAttributeToPropertyMap* (*attribute_to_property_map) (SvgElement *element);

    SvgUpdater *updater;
};

GType svg_element_get_type();
SvgElement*     svg_element_new_from_xml(GType type, xmlNode* node);
/*gboolean        svg_element_is_renderable(SvgElement *element);*/

//int             svg_element_init_from_xml(SvgElement* element, xmlNode* node);
gboolean        svg_element_parse_attribute(SvgElement* element, DomQualifiedName *qualified_name, guchar* value);
double          svg_element_get_time(SvgElement *element);

gchar*          svg_element_to_string(SvgElement *element, gchar *indent);

SvgAttributeToPropertyMap*
svg_element_attribute_to_property_map(SvgElement *element);

G_END_DECLS

#endif /* __ELEMENT_SVG_H__ */

