/*
 * svg-element-stop.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <liblog/log.h>


#include <libgraphics/graphics.h>


#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include <librenderer/renderer-object.h>

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-document.h"
#include "svg-number.h"
#include "svg-color.h"
#include "svg-color-icc.h"
#include "svg-parser.h"
#include "svg-updater.h"

#include "svg-element-stop.h"


static int             svg_element_stop_init_from_xml(DomNode *element, xmlNode* node);
static gboolean        svg_element_stop_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value);

static RendererObject* svg_element_stop_get_renderer(SvgElement *element);


static void svg_element_stop_class_init(SvgElementStopClass *klass);
static void svg_element_stop_init(SvgElementStop *gobject);

G_DEFINE_TYPE (SvgElementStop, svg_element_stop, SVG_TYPE_ELEMENT)

#define parent_class svg_element_stop_parent_class

static void
svg_element_stop_class_init(SvgElementStopClass *klass)
{
    DomNodeClass *dom_class;
	SvgElementClass *svgelement_class;

    dom_class  = (DomNodeClass *) klass;
	svgelement_class = (SvgElementClass *) klass;

    /*svgelement_class->private_class->get_renderer = svg_element_stop_get_renderer;*/
    dom_class->init_from_xml          = svg_element_stop_init_from_xml;
    svgelement_class->parse_attribute        = svg_element_stop_parse_attribute;

    //svg_element_stop_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_stop_init (SvgElementStop *object)
{
    object->offset.value  = 0.0;
    object->color.type    = SVG_COLOR_CURRENT;
    object->color.value   = 0xFF000000;
    object->opacity.value = 1.0;
}

static int
svg_element_stop_init_from_xml(DomNode* element, xmlNode* node)
{
    return DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);
}

static gboolean svg_element_stop_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_STOP(element));
    SvgElementStop *stop = SVG_ELEMENT_STOP(element);

    if        (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "offset"))) {
        SvgOffsetType type;
        svg_parser_parse_offset(&stop->offset.value, &type, value, value+strlen(value));
        //svg_parser_parse_se_decimal(&stop->offset.value, &type, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "stop-color"))) {
        /*gboolean success = svg_color_set_value_from_string(&stop->color, value);*/
        svg_parser_parse_color(&stop->color, value, value+strlen(value));
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "stop-opacity"))) {
        /*svg_number_set_value_from_string(&stop->opacity, value)*/
        SvgNumberType type;
        svg_parser_parse_decimal(&stop->opacity.value, &type, value, value+strlen(value));
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

static RendererObject*
svg_element_stop_get_renderer(SvgElement *element)
{
    return NULL;
}
