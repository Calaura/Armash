/*
 * svg-element-animate.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "properties/svg-animated-property.h"
#include "properties/svg-property-info.h"
#include "properties/svg-attribute-to-property-map.h"
#include "svg-element.h"
#include "svg-time.h"
#include "svg-length.h"
#include "svg-animated.h"
#include "svg-element.h"
#   include "svg-animated-type.h"
#   include "svg-animated-type-animator.h"
#   include "svg-animated-length.h"
//  include ..., Color, Transform, Number, etc
#   include "svg-animator-factory.h"
#include "svg-element-animation.h"
#include "svg-element-animate.h"

#include <string.h>


static int  svg_element_animate_init_from_xml(DomNode *element, xmlNode* node);
static gboolean  svg_element_animate_parse_attribute(SvgElement *element, DomQualifiedName* qualified_name, guchar* value);

void svg_element_animate_reset_animated_type(SvgElementAnimation *animation);
void svg_element_animate_started_active_interval(SvgElementAnimation *animation);
void svg_element_animate_apply_results_to_target(SvgElementAnimation *animation);

static void svg_element_animate_class_init(SvgElementAnimateClass *klass);
static void svg_element_animate_init(SvgElementAnimate *gobject);

/*SVG_TYPE_RENDERABLE, SVG_TYPE_ANIMATABLE, SVG_TYPE_LOCATABLE, SVG_TYPE_TRANSFORMABLE, SVG_TYPE_STYLABLE, */
G_DEFINE_TYPE (SvgElementAnimate, svg_element_animate, SVG_TYPE_ELEMENT_ANIMATION)
#define parent_class svg_element_animate_parent_class

static void
svg_element_animate_class_init(SvgElementAnimateClass *klass)
{
    GObjectClass    *g_object_class;
    DomNodeClass *dom_class;
    SvgElementClass *svgelement_class;
    SvgElementAnimationClass *animation_class;

    dom_class        = (DomNodeClass *) klass;
    g_object_class   = (GObjectClass *) klass;
    svgelement_class = (SvgElementClass *) klass;
    animation_class    = (SvgElementAnimationClass*) klass;

    //virtual animation_class->update_animation;
    //virtual animation_class->is_additive;
    animation_class->reset_animated_type     = svg_element_animate_reset_animated_type;
    //virtual animation_class->clear_animated_type;
    animation_class->started_active_interval = svg_element_animate_started_active_interval;
    animation_class->apply_results_to_target = svg_element_animate_apply_results_to_target;



    dom_class->init_from_xml          = svg_element_animate_init_from_xml;
    svgelement_class->parse_attribute = svg_element_animate_parse_attribute;

//    svg_element_animate_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_animate_init (SvgElementAnimate *object)
{
    object->from = svg_length_new();
    object->to   = svg_length_new();

    object->animated_property_type = AnimatedString;
    object->animator = NULL;
    object->animated_type = NULL;

}

/* virtual function */

#include "libmotion/motion-easing.h"
#include "libmotion/motion-easing-linear.h"

static int
svg_element_animate_init_from_xml(DomNode* element, xmlNode* node)
{
    SvgElementAnimation *animation = SVG_ELEMENT_ANIMATION(element);
    SvgElementAnimate   *animate = SVG_ELEMENT_ANIMATE(element);

    /*svg_element_rect_parse_attribute(element, "width", BAD_CAST xmlGetProp(node, "width"));*/
    int success = DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);

    SvgElement   *target = animation->target;

    /* motion_update_times */
    double begin = svg_element_animation_get_start_time(SVG_ELEMENT_ANIMATION(animate));
    double end   = begin + svg_element_animation_get_simple_duration(SVG_ELEMENT_ANIMATION(animate));
    double from = 0;
    double to   = 0;
    gboolean status = FALSE;

    if (!animate->to->empty) {
        to = animate->to->value;
        if (!animate->from->empty) {
            from = animate->from->value;
        } else {
            GValue value = G_VALUE_INIT;
            g_value_init(&value, G_TYPE_DOUBLE);
            g_object_get_property(target, animation->attribute_name, &value);
            from = g_value_get_double(&value);
            g_print("x=%f\n", from);
        }
        status = TRUE;
    }

    /*
     * SvgAnimatedLength *length = svg_element_get_motion_property("x");
     * MotionProperty *property = length->property;
     *
     */
    MotionProperty *property = NULL;
    if (status) {
        /* property = SVG_ANIMATE_LENGTH(SVG_ELEMENT_RECT(target)->x)->property */
        property = motion_property_new(animation->attribute_name, target);
        motion_animation_set_times(property, begin, end);

        /*  GValue from_value = G_VALUE_INIT;
            g_value_init(&from_value, G_TYPE_DOUBLE);
            g_value_set_double(&from_value, from);
            GValue to_value = G_VALUE_INIT;
            g_value_init(&to_value, G_TYPE_DOUBLE);
            g_value_set_double(&to_value, to);*/
        motion_animation_set_values(property, from, to);

        MotionEasingLinear *easing = motion_easing_linear_new();
        easing->P0_x = 0.0;
        easing->P0_y = 0.0;
        easing->P1_x = 0.0;
        easing->P1_y = 0.0;
        motion_animation_set_easing(property, easing);

        /*g_object_get_property(target, "x", &value);*/
        SvgAnimated *property_x = svg_element_animatable_get_property(target, animation->attribute_name);
        // svg_element_animatable_get_animated();
        property_x->property = property;

        //AttributeToPropertyMap property_x1, property_x2
    }

    /*
     * SvgAnimateLength *animated_length = svg_element_get_animated_property("x");
     * svg_animated_length_set_motion(animated_length, property);
     *
     */


    return success;
}

static gboolean svg_element_animate_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_ANIMATE(element));
    /*SvgElement *target = SVG_ELEMENT_ANIMATE(element)->target;*/
    SvgElementAnimate *animate = SVG_ELEMENT_ANIMATE(element);

    DomQualifiedName svg_qualified_from = {"svg", "from"};
    DomQualifiedName svg_qualified_to = {"svg", "to"};

    if        (dom_qualified_name_equ(qualified_name, &svg_qualified_from)) {
        svg_length_set_value_from_string(animate->from, value, value+strlen(value));
        animate->from->empty = FALSE;
    } else if (dom_qualified_name_equ(qualified_name, &svg_qualified_to)) {
        svg_length_set_value_from_string(animate->to, value, value+strlen(value));
        animate->to->empty = FALSE;
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

static SvgAnimatedTypeAnimator*
svg_element_animate_ensure_animator(SvgElementAnimation *animation)
{
    SvgElementAnimate *animate = SVG_ELEMENT_ANIMATE(animation);
    if (!animate->animator)
        animate->animator = svg_animator_factory_create(animate, svg_element_animation_get_target(animation), animate->animated_property_type);
    g_assert(animate->animated_property_type == animate->animator->type);
    return animate->animator;
}

void svg_element_animate_reset_animated_type(SvgElementAnimation *animation)
{
    /*
    SVGAnimatedTypeAnimator* animator = ensureAnimator();
    ASSERT(m_animatedPropertyType == animator->type());

    SVGElement* targetElement = this->targetElement();
    const QualifiedName& attributeName = this->attributeName();
    ShouldApplyAnimation shouldApply = shouldApplyAnimation(targetElement, attributeName);

    if (shouldApply == DontApplyAnimation)
        return;

    if (shouldApply == ApplyXMLAnimation || shouldApply == ApplyXMLandCSSAnimation) {
        // SVG DOM animVal animation code-path.
        m_animatedProperties = animator->findAnimatedPropertiesForAttributeName(targetElement, attributeName);
        ASSERT(!m_animatedProperties.isEmpty());

        ASSERT(propertyTypesAreConsistent(m_animatedPropertyType, m_animatedProperties));
        if (!m_animatedType)
            m_animatedType = animator->startAnimValAnimation(m_animatedProperties);
        else {
            animator->resetAnimValToBaseVal(m_animatedProperties, m_animatedType.get());
            animator->animValDidChange(m_animatedProperties);
        }
        return;
    }

    // CSS properties animation code-path.
    ASSERT(m_animatedProperties.isEmpty());
    String baseValue;

    if (shouldApply == ApplyCSSAnimation) {
        ASSERT(SVGAnimationElement::isTargetAttributeCSSProperty(targetElement, attributeName));
        computeCSSPropertyValue(targetElement, cssPropertyID(attributeName.localName()), baseValue);
    }

    if (!m_animatedType)
        m_animatedType = animator->constructFromString(baseValue);
    else
        m_animatedType->setValueAsString(attributeName, baseValue);
    */
}

void svg_element_animate_started_active_interval(SvgElementAnimation *animation)
{
    /*
    m_animationValid = false;

    if (!hasValidAttributeType())
        return;

    // These validations are appropriate for all animation modes.
    if (fastHasAttribute(SVGNames::keyPointsAttr) && m_keyPoints.size() != m_keyTimes.size())
        return;

    AnimationMode animationMode = this->animationMode();
    CalcMode calcMode = this->calcMode();
    if (calcMode == CalcModeSpline) {
        unsigned splinesCount = m_keySplines.size();
        if (!splinesCount
            || (fastHasAttribute(SVGNames::keyPointsAttr) && m_keyPoints.size() - 1 != splinesCount)
            || (animationMode == ValuesAnimation && m_values.size() - 1 != splinesCount)
            || (fastHasAttribute(SVGNames::keyTimesAttr) && m_keyTimes.size() - 1 != splinesCount))
            return;
    }

    String from = fromValue();
    String to = toValue();
    String by = byValue();
    if (animationMode == NoAnimation)
        return;
    if ((animationMode == FromToAnimation || animationMode == FromByAnimation || animationMode == ToAnimation || animationMode == ByAnimation)
        && (fastHasAttribute(SVGNames::keyPointsAttr) && fastHasAttribute(SVGNames::keyTimesAttr) && (m_keyTimes.size() < 2 || m_keyTimes.size() != m_keyPoints.size())))
        return;
    if (animationMode == FromToAnimation)
        m_animationValid = calculateFromAndToValues(from, to);
    else if (animationMode == ToAnimation) {
        // For to-animations the from value is the current accumulated value from lower priority animations.
        // The value is not static and is determined during the animation.
        m_animationValid = calculateFromAndToValues(emptyString(), to);
    } else if (animationMode == FromByAnimation)
        m_animationValid = calculateFromAndByValues(from, by);
    else if (animationMode == ByAnimation)
        m_animationValid = calculateFromAndByValues(emptyString(), by);
    else if (animationMode == ValuesAnimation) {
        m_animationValid = m_values.size() >= 1
            && (calcMode == CalcModePaced || !fastHasAttribute(SVGNames::keyTimesAttr) || fastHasAttribute(SVGNames::keyPointsAttr) || (m_values.size() == m_keyTimes.size()))
            && (calcMode == CalcModeDiscrete || !m_keyTimes.size() || m_keyTimes.last() == 1)
            && (calcMode != CalcModeSpline || ((m_keySplines.size() && (m_keySplines.size() == m_values.size() - 1)) || m_keySplines.size() == m_keyPoints.size() - 1))
            && (!fastHasAttribute(SVGNames::keyPointsAttr) || (m_keyTimes.size() > 1 && m_keyTimes.size() == m_keyPoints.size()));
        if (m_animationValid)
            m_animationValid = calculateToAtEndOfDurationValue(m_values.last());
        if (calcMode == CalcModePaced && m_animationValid)
            calculateKeyTimesForCalcModePaced();
    } else if (animationMode == PathAnimation)
        m_animationValid = calcMode == CalcModePaced || !fastHasAttribute(SVGNames::keyPointsAttr) || (m_keyTimes.size() > 1 && m_keyTimes.size() == m_keyPoints.size());
    */
}

void svg_element_animate_apply_results_to_target(SvgElementAnimation *animation)
{
    SvgElementAnimate *animate = SVG_ELEMENT_ANIMATE(animation);
//    ASSERT(m_animatedPropertyType != AnimatedTransformList || hasTagName(SVGNames::animateTransformTag));
//    ASSERT(m_animatedPropertyType != AnimatedUnknown);
//    ASSERT(m_animator);
    g_assert(animate->animated_property_type != AnimatedTransformList);
    g_assert(animate->animated_property_type != AnimatedUnknown);
    g_assert(animate->animator);

    // Early exit if our animated type got destructed by a previous endedActiveInterval().
//    if (!m_animatedType)
//        return;
    if (!animate->animated_type)
        return;


    SvgElement *target = svg_element_animation_get_target(animation);
//    SVGElement* targetElement = this->targetElement();
//    const QualifiedName& attributeName = this->attributeName();
//    if (m_animatedProperties.isEmpty()) {
//        // CSS properties animation code-path.
//        // Convert the result of the animation to a String and apply it as CSS property on the target & all instances.
//        applyCSSPropertyToTargetAndInstances(targetElement, attributeName, m_animatedType->valueAsString());
//        return;
//    }

//    // We do update the style and the animation property independent of each other.
//    ShouldApplyAnimation shouldApply = shouldApplyAnimation(targetElement, attributeName);
//    if (shouldApply == ApplyXMLandCSSAnimation)
//        applyCSSPropertyToTargetAndInstances(targetElement, attributeName, m_animatedType->valueAsString());

//    // SVG DOM animVal animation code-path.
//    // At this point the SVG DOM values are already changed, unlike for CSS.
//    // We only have to trigger update notifications here.
//    m_animator->animValDidChange(m_animatedProperties);
//    notifyTargetAndInstancesAboutAnimValChange(targetElement, attributeName);

    svg_animated_type_animator_anim_val_did_change(animate->animator, animate->animated_properties);
}

SvgElementAnimate *
svg_element_animate_new (void)
{
	return g_object_new (svg_element_animate_get_type (),
	                     NULL);
}

