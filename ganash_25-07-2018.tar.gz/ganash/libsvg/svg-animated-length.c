/*
 * svg-animated-length.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-time.h"
#include "svg-length.h"
#include "svg-animated.h"
#include "svg-animated-type.h"
#include "svg-animated-type-animator.h"
#include "svg-animated-length.h"

#include "svg-element.h"
#include "svg-element-animation.h"



static SvgAnimatedType* svg_animated_length_animator_construct_from_string      (gchar* string);
static SvgAnimatedType* svg_animated_length_animator_start_anim_val_animation   (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes);
static void             svg_animated_length_animator_stop_anim_val_animation    (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes);
static void             svg_animated_length_animator_reset_anim_val_to_base_val (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes, SvgAnimatedType* type);
static void             svg_animated_length_animator_anim_val_will_change       (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes);
static void             svg_animated_length_animator_anim_val_did_change        (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes);
static void             svg_animated_length_animator_add_animated_types         (SvgAnimatedTypeAnimator *animator, SvgAnimatedType* from, SvgAnimatedType* to);
static void             svg_animated_length_animator_calculate_animated_value   (SvgAnimatedTypeAnimator *animator, float percentage, unsigned repeatCount, SvgAnimatedType* from, SvgAnimatedType* to, SvgAnimatedType* toAtEndOfDuration, SvgAnimatedType* animated);
static float            svg_animated_length_animator_calculate_distance         (SvgAnimatedTypeAnimator *animator, gchar* fromString, gchar* toString);


static void svg_animated_length_animator_class_init(SvgAnimatedLengthAnimatorClass *klass);
static void svg_animated_length_animator_init(SvgAnimatedLengthAnimator *gobject);

G_DEFINE_TYPE (SvgAnimatedLengthAnimator, svg_animated_length_animator, SVG_TYPE_ANIMATED_TYPE_ANIMATOR)

static void
svg_animated_length_animator_class_init(SvgAnimatedLengthAnimatorClass *klass)
{
    GObjectClass *gobject_class;
    SvgAnimatedTypeAnimatorClass *animator_class;

    gobject_class = (GObjectClass *) klass;
    animator_class = (SvgAnimatedTypeAnimatorClass *) klass;

    animator_class->construct_from_string      = svg_animated_length_animator_construct_from_string;
    animator_class->start_anim_val_animation   = svg_animated_length_animator_start_anim_val_animation;
    animator_class->stop_anim_val_animation    = svg_animated_length_animator_stop_anim_val_animation;
    animator_class->reset_anim_val_to_base_val = svg_animated_length_animator_reset_anim_val_to_base_val;
    animator_class->anim_val_will_change       = svg_animated_length_animator_anim_val_will_change;
    animator_class->anim_val_did_change        = svg_animated_length_animator_anim_val_did_change;
    animator_class->add_animated_types         = svg_animated_length_animator_add_animated_types;
    animator_class->calculate_animated_value   = svg_animated_length_animator_calculate_animated_value;
    animator_class->calculate_distance         = svg_animated_length_animator_calculate_distance;


//    svg_animated_length_animator_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_animated_length_animator_init (SvgAnimatedLengthAnimator *object)
{
    /*SvgAnimatedLengthPrivate *priv = SVG_ANIMATED_LENGTH_GET_PRIVATE(object);
    object->private_member = priv;
    priv->foo = 0;*/
}

SvgAnimatedLengthAnimator *
svg_animated_length_animator_new (void)
{
    return g_object_new (svg_animated_length_animator_get_type (),
                         NULL);
}
void
svg_animated_length_anim_val_did_change(SvgAnimatedLength *animated_length)
{

}

// -----------------------------------------------------------------------------

static void svg_animated_length_class_init(SvgAnimatedLengthClass *klass);
static void svg_animated_length_init(SvgAnimatedLength *gobject);

G_DEFINE_TYPE (SvgAnimatedLength, svg_animated_length, SVG_TYPE_ANIMATED)

static void
svg_animated_length_class_init(SvgAnimatedLengthClass *klass)
{
    GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;



//	svg_animated_length_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_animated_length_init (SvgAnimatedLength *object)
{
    /*SvgAnimatedLengthPrivate *priv = SVG_ANIMATED_LENGTH_GET_PRIVATE(object);
	object->private_member = priv;
    priv->foo = 0;*/
}

SvgAnimatedLength *
svg_animated_length_new (void)
{
	return g_object_new (svg_animated_length_get_type (),
	                     NULL);
}

double svg_animated_length_get_value(SvgAnimatedLength *animated_length, gdouble time)
{
    SvgAnimated *animated = (SvgAnimated *) animated_length;
    if (!animated->property) {
        return animated_length->baseVal->value;
    }
    double begin = motion_animation_get_begin(animated->property);
    double end   = motion_animation_get_end(animated->property);

    if (time < begin) {
        return animated_length->baseVal->value;
    } else if (begin <= time && time <= end) {
            double dur = motion_animation_get_dur(animated->property);
            double progress = (time-begin) / dur;
            return motion_animation_interpolate(SVG_ANIMATED(animated_length)->property, progress);
    } else if (time > end) {
        /* motion_animation_get_value(); */
        return motion_animation_interpolate(SVG_ANIMATED(animated_length)->property, 1.0);
    } else {
        return animated_length->baseVal->value;
    }


    return 0.0;
}

static SvgAnimatedType* svg_animated_length_animator_construct_from_string(gchar* string)
{
    //return SVGAnimatedType::createLength(std::make_unique<SVGLength>(m_lengthMode, string));
    return NULL;
}

static SvgAnimatedType* svg_animated_length_animator_start_anim_val_animation(SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes)
{
    //return svg_animated_type_new_length(constructFromBaseValue<SVGAnimatedLength>(animatedTypes));
    return NULL;
}

static void svg_animated_length_animator_stop_anim_val_animation(SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes)
{
    //stopAnimValAnimationForType<SVGAnimatedLength>(animatedTypes);
}

static void svg_animated_length_animator_reset_anim_val_to_base_val(SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes, SvgAnimatedType* type)
{
    //resetFromBaseValue<SVGAnimatedLength>(animatedTypes, type, &SVGAnimatedType::length);
}

static void svg_animated_length_animator_anim_val_will_change(SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes)
{

    /*
    animValWillChangeForType<SVGAnimatedLength>(animatedTypes);

    template<typename AnimValType>
    void animValWillChangeForType(const SVGElementAnimatedPropertyList& animatedTypes)
    {
        ASSERT(animatedTypes[0].properties.size() == 1);
        executeAction<AnimValType>(AnimValWillChangeAction, animatedTypes, 0);

        template<typename AnimValType>
        void executeAction(AnimationAction action, const SVGElementAnimatedPropertyList& animatedTypes, unsigned whichProperty, typename AnimValType::ContentType* type = 0)
        {
            SVGElementInstance::InstanceUpdateBlocker blocker(animatedTypes[0].element);

            SVGElementAnimatedPropertyList::const_iterator end = animatedTypes.end();
            for (SVGElementAnimatedPropertyList::const_iterator it = animatedTypes.begin(); it != end; ++it) {
                ASSERT_WITH_SECURITY_IMPLICATION(whichProperty < it->properties.size());
                AnimValType* property = castAnimatedPropertyToActualType<AnimValType>(it->properties[whichProperty].get());

                switch (action) {
                case StartAnimationAction:
                    ASSERT(type);
                    if (!property->isAnimating())
                        property->animationStarted(type);
                    break;
                case StopAnimationAction:
                    ASSERT(!type);
                    property->animationEnded();
                    break;
                case AnimValWillChangeAction:
                    ASSERT(!type);
                    property->animValWillChange();

                    void animValWillChange()
                    {
                        // no-op for non list types.
                        ASSERT(m_isAnimating);
                        ASSERT(m_animVal);
                    }
                    break;
                case AnimValDidChangeAction:
                    ASSERT(!type);
                    property->animValDidChange();
                    break;
                }
            }
        }

    }
    */
}

void svg_animated_length_animator_anim_val_did_change(SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList* animatedTypes)
{
    /*
    SvgElementAnimatedProperties animated_properties = g_array_index(animatedTypes, SvgElementAnimatedProperties, 0);
    g_assert(animated_properties.properties->len == 1);

    int i;
    for (i=0; i<animatedTypes->len; i++) {
        SvgElementAnimatedProperties element_animated = g_array_index(animatedTypes, SvgElementAnimatedProperties, i);
        SvgAnimatedProperty *animated_property = g_array_index(element_animated.properties, SvgAnimatedProperty*, 0);
        SvgAnimatedLength *animated_length = SVG_ANIMATED_LENGTH(animated_property);
        svg_animated_length_anim_val_did_change(animated_length);
    }
    */
}

void svg_animated_length_animator_add_animated_types(SvgAnimatedTypeAnimator *animator, SvgAnimatedType* from, SvgAnimatedType* to)
{
    g_assert(svg_animated_type_get_type(from) == AnimatedLength);
    g_assert(svg_animated_type_get_type(from) == svg_animated_type_get_type(to));

    //SvgLengthContext lengthContext(m_contextElement);
    SvgElement *length_context = animator->context_element;
    SvgLength *fromLength = svg_animated_type_get_length(from);
    SvgLength *toLength = svg_animated_type_get_length(to);

    svg_length_set_value(toLength
                         , svg_length_get_value(toLength, length_context)+svg_length_get_value(fromLength, length_context)
                         , toLength->unit
                         , FALSE);
}

static SvgLength *svg_animated_length_parse_length_from_string(SvgElementAnimation* animationElement, gchar *string)
{
    //return sharedSVGLength(SVGLength::lengthModeForAnimatedLengthAttribute(animationElement->attributeName()), string);
    return NULL;
}

/*
void svg_animated_length_calculate_animated_value(float percentage, unsigned repeatCount, SVGAnimatedType* from, SVGAnimatedType* to, SVGAnimatedType* toAtEndOfDuration, SVGAnimatedType* animated)
{

    ASSERT(m_animationElement);
    ASSERT(m_contextElement);

    SVGLength fromSVGLength = m_animationElement->animationMode() == ToAnimation ? animated->length() : from->length();
    SVGLength toSVGLength = to->length();
    const SVGLength& toAtEndOfDurationSVGLength = toAtEndOfDuration->length();
    SVGLength& animatedSVGLength = animated->length();

    // Apply CSS inheritance rules.
    m_animationElement->adjustForInheritance<SVGLength>(parseLengthFromString, m_animationElement->fromPropertyValueType(), fromSVGLength, m_contextElement);
    m_animationElement->adjustForInheritance<SVGLength>(parseLengthFromString, m_animationElement->toPropertyValueType(), toSVGLength, m_contextElement);

    SVGLengthContext lengthContext(m_contextElement);
    float animatedNumber = animatedSVGLength.value(lengthContext);
    SVGLengthType unitType = percentage < 0.5 ? fromSVGLength.unitType() : toSVGLength.unitType();
    m_animationElement->animateAdditiveNumber(percentage, repeatCount, fromSVGLength.value(lengthContext), toSVGLength.value(lengthContext), toAtEndOfDurationSVGLength.value(lengthContext), animatedNumber);

    animatedSVGLength.setValue(lengthContext, animatedNumber, m_lengthMode, unitType, ASSERT_NO_EXCEPTION);
}
*/


static void    svg_animated_length_animator_calculate_animated_value     (SvgAnimatedTypeAnimator *animator, float percentage, unsigned repeatCount, SvgAnimatedType* from, SvgAnimatedType* to, SvgAnimatedType* toAtEndOfDuration, SvgAnimatedType* animated)
{
    g_assert(animator->animation_element);
    g_assert(animator->context_element);

    AnimationMode mode = svg_element_animation_mode(SVG_ELEMENT_ANIMATION(animator->animation_element));
    SvgLength *fromSvgLength = mode == ToAnimation ? svg_animated_type_get_length(animated) : svg_animated_type_get_length(from);
    SvgLength *toSvgLength = svg_animated_type_get_length(to);
    // RefPtr(SvgLength) => SvgLength*
    // RefPtr(SvgLength) => SvgLength*
    SvgLength *toAtEndOfDurationSvgLength = svg_animated_type_get_length(toAtEndOfDuration);
    SvgLength *animatedSvgLength = svg_animated_type_get_length(animated);

    //SvgLengthContext lengthContext(m_contextElement);
    SvgElement *length_context = animator->animation_element;
    double animatedNumber = svg_length_get_value(animatedSvgLength, length_context);
    SvgLengthType unitType = percentage < 0.5 ? SVG_LENGTH_GET_TYPE(fromSvgLength) : SVG_LENGTH_GET_TYPE(toSvgLength);
    svg_element_animation_animate_additive_number(animator->animation_element, percentage, repeatCount, svg_length_get_value(fromSvgLength, length_context), svg_length_get_value(toSvgLength, length_context), svg_length_get_value(toAtEndOfDurationSvgLength, length_context), &animatedNumber);


    SvgAnimatedLengthAnimator *lengthAnimator = SVG_ANIMATED_LENGTH_ANIMATOR(animator);
    SvgLengthMode unitMode = lengthAnimator->priv->length_mode;
    SvgUnit unit;
    unit.bits.mode = unitMode;
    unit.bits.type = unitType;
    svg_length_set_value(animatedSvgLength, animatedNumber, unit.word, TRUE);

    /*
    SvgLength fromSVGLength = m_animationElement->animationMode() == ToAnimation ? animated->length() : from->length();
    SvgLength toSVGLength = to->length();
    const SvgLength& toAtEndOfDurationSVGLength = toAtEndOfDuration->length();
    SvgLength& animatedSVGLength = animated->length();

    // Apply CSS inheritance rules.
    m_animationElement->adjustForInheritance<SVGLength>(parseLengthFromString, m_animationElement->fromPropertyValueType(), fromSVGLength, m_contextElement);
    m_animationElement->adjustForInheritance<SVGLength>(parseLengthFromString, m_animationElement->toPropertyValueType(), toSVGLength, m_contextElement);

    SVGLengthContext lengthContext(m_contextElement);
    float animatedNumber = animatedSVGLength.value(lengthContext);
    SVGLengthType unitType = percentage < 0.5 ? fromSVGLength.unitType() : toSVGLength.unitType();
    m_animationElement->animateAdditiveNumber(percentage, repeatCount, fromSVGLength.value(lengthContext), toSVGLength.value(lengthContext), toAtEndOfDurationSVGLength.value(lengthContext), animatedNumber);

    animatedSVGLength.setValue(lengthContext, animatedNumber, m_lengthMode, unitType, ASSERT_NO_EXCEPTION);
    */
}


/*
gdouble svg_animated_length_calculate_distance(SvgLength *from, SvgLength *to)
{
    return svg_length_get_value(to) - svg_length_get_value(from);

    ASSERT(m_animationElement);
    ASSERT(m_contextElement);
    SVGLengthMode lengthMode = SVGLength::lengthModeForAnimatedLengthAttribute(m_animationElement->attributeName());
    SVGLength from = SVGLength(lengthMode, fromString);
    SVGLength to = SVGLength(lengthMode, toString);
    SVGLengthContext lengthContext(m_contextElement);

    return fabsf(to.value(lengthContext) - from.value(lengthContext));
}
*/

static float    svg_animated_length_animator_calculate_distance         (SvgAnimatedTypeAnimator *animator, gchar* fromString, gchar* toString)
{
    g_assert(animator->animation_element);
    g_assert(animator->context_element);

    SvgLength from;
    SvgLength to;

    //SvgLengthMode lengthMode = SVGLength::lengthModeForAnimatedLengthAttribute(m_animationElement->attributeName());
    SvgLengthMode lengthMode = SVG_LENGTH_MODE_WIDTH;
    svg_length_set_value_from_string(&from, fromString, fromString+strlen(fromString));
    svg_length_set_value_from_string(&to, toString, toString+strlen(toString));

    //SvgLengthContext *context = animator->animation_element;
    SvgElement *context = animator->animation_element;
    double from_val = svg_length_get_value(&from, context);
    double to_val = svg_length_get_value(&to, context);

    return to_val - from_val;// todo: return abs()
}

