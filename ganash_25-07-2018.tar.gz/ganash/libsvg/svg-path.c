/*
 * svg-path.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <cairo/cairo.h>

#include <glib-object.h>

#include "libgraphics/graphics.h"
#include "libgraphics/graphics-path.h"

#include "svg-types.h"
#include "svg-path.h"


static void svg_path_class_init(SvgPathClass *klass);
static void svg_path_init(SvgPath *gobject);

G_DEFINE_TYPE (SvgPath, svg_path, G_TYPE_OBJECT)

static void
svg_path_class_init(SvgPathClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	svg_path_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_path_init (SvgPath *object)
{
    object->segments = NULL;
    object->num_segments = 0;
    object->cairo_path = NULL;
    object->cairo_path_num_data = 0;
}

SvgPath *
svg_path_new (void)
{
	return g_object_new (svg_path_get_type (),
	                     NULL);
}

static void
svg_path_segment_get_last_point(SvgPathSegment* segment, double *x, double *y) {
    double c_x;
    double c_y;
    switch(segment->command)
    {
    case SVG_PATH_COMMAND_MOVE_TO:
        c_x = segment->data[0];
        c_y = segment->data[1];
    break;
    case SVG_PATH_COMMAND_LINE_TO:
        c_x = segment->data[0];
        c_y = segment->data[1];
    break;
    case SVG_PATH_COMMAND_QUAD_TO:
        c_x = segment->data[2];
        c_y = segment->data[3];
    break;
    case SVG_PATH_COMMAND_CUBIC_TO:
        c_x = segment->data[4];
        c_y = segment->data[5];
    break;
    }
    if (x)
        *x = c_x;
    if (y)
        *y = c_y;
}

cairo_path_t *svg_path_get_cairo_path(SvgPath* svg_path)
{
    /*if (svg_path->status == CORE_PATH_STATUS_UPDATE) {
        return svg_path->cairo_path;
    }*/

    gint i = 0;
    cairo_path_t* path;
    cairo_path_data_t *data;
    struct {
        gdouble x;
        gdouble y;
    } current;
    path = g_new(cairo_path_t, 1);
    path->status   = CAIRO_STATUS_SUCCESS;
    path->num_data = svg_path->cairo_path_num_data;
    path->data     = (cairo_path_data_t*) g_new(cairo_path_data_t, svg_path->cairo_path_num_data);
    /*check allocation*/

    GList* list;
    for (list=svg_path->segments; list != NULL; list = list->next) {
        SvgPathSegment* segment = (SvgPathSegment*) list->data;
        data = &path->data[i];

        switch(segment->command)
        {
        case SVG_PATH_COMMAND_MOVE_TO:
            data->header.type = CAIRO_PATH_MOVE_TO;
            data->header.length = 2;
            data[1].point.x = segment->data[0];
            data[1].point.y = segment->data[1];

            current.x = data[1].point.x;
            current.y = data[1].point.y;
        break;
        case SVG_PATH_COMMAND_MOVE_TO_REL:
            data->header.type = CAIRO_PATH_MOVE_TO;
            data->header.length = 2;
            data[1].point.x = segment->data[0];// TODO add previous
            data[1].point.y = segment->data[1];

            current.x = data[1].point.x;
            current.y = data[1].point.y;
        break;
        case SVG_PATH_COMMAND_LINE_TO:
            data->header.type = CAIRO_PATH_LINE_TO;
            data->header.length = 2;
            data[1].point.x = segment->data[0];
            data[1].point.y = segment->data[1];

            current.x = data[1].point.x;
            current.y = data[1].point.y;
        break;
        case SVG_PATH_COMMAND_QUAD_TO:
        {
            double c_x;
            double c_y;
            svg_path_segment_get_last_point((SvgPathSegment*) list->prev->data, &c_x, &c_y);

            data->header.type = CAIRO_PATH_CURVE_TO;
            data->header.length = 4;

            data[1].point.x = c_x + 2.0/3.0 * (segment->data[0]-c_x);
            data[1].point.y = c_y + 2.0/3.0 * (segment->data[1]-c_y);

            data[2].point.x = segment->data[2] + 2.0/3.0 * (segment->data[0]-segment->data[2]);
            data[2].point.y = segment->data[3] + 2.0/3.0 * (segment->data[1]-segment->data[3]);

            data[3].point.x = segment->data[2];
            data[3].point.y = segment->data[3];

            current.x = data[3].point.x;
            current.y = data[3].point.y;
        }
        break;
        case SVG_PATH_COMMAND_CUBIC_TO:
            data->header.type = CAIRO_PATH_CURVE_TO;
            data->header.length = 4;
            data[1].point.x = segment->data[0];
            data[1].point.y = segment->data[1];
            data[2].point.x = segment->data[2];
            data[2].point.y = segment->data[3];
            data[3].point.x = segment->data[4];
            data[3].point.y = segment->data[5];

            current.x = data[3].point.x;
            current.y = data[3].point.y;
        break;
        case SVG_PATH_COMMAND_CUBIC_TO_REL:
            data->header.type = CAIRO_PATH_CURVE_TO;
            data->header.length = 4;
            data[1].point.x = segment->data[0] + current.x;
            data[1].point.y = segment->data[1] + current.y;
            data[2].point.x = segment->data[2] + current.x;
            data[2].point.y = segment->data[3] + current.y;
            data[3].point.x = segment->data[4] + current.x;
            data[3].point.y = segment->data[5] + current.y;

            current.x = data[3].point.x;
            current.y = data[3].point.y;
        break;
        default:
            g_print("TODO CAIRO_PATH_CLOSE_PATH(%d)\n", segment->command);
        break;
        }
        i += data->header.length;
    }

    /*svg_path->status = CORE_PATH_STATUS_UPDATE;*/
    svg_path->cairo_path = path;

    return svg_path->cairo_path;
}

#include "libgraphics/graphics.h"

GraphicsPath *svg_path_get_graphics_path(SvgPath* path)
{
    /*if (svg_path->status == CORE_PATH_STATUS_UPDATE) {
        return svg_path->cairo_path;
    }*/

    gint i = 0;
    GraphicsPath *graphics_path = graphics_path_new();
    graphics_path_reset(graphics_path);
    struct {
        gdouble x;
        gdouble y;
    } current = {0.0, 0.0};
    //path->data     = (cairo_path_data_t*) g_new(cairo_path_data_t, svg_path->cairo_path_num_data);
    /*check allocation*/

    GList* list;
    for (list=g_list_first(path->segments); list != NULL; list = list->next) {
        SvgPathSegment* segment = (SvgPathSegment*) list->data;

        switch(segment->command)
        {
        case SVG_PATH_COMMAND_MOVE_TO:
            graphics_path_move_to(graphics_path, segment->data[0], segment->data[1]);
            current.x = segment->data[0];
            current.y = segment->data[1];
        break;
        case SVG_PATH_COMMAND_MOVE_TO_REL:
            graphics_path_move_to(graphics_path, segment->data[0], segment->data[1]);
            current.x += segment->data[0];
            current.y += segment->data[1];
        break;
        case SVG_PATH_COMMAND_LINE_TO:
            graphics_path_line_to(graphics_path, segment->data[0], segment->data[1]);
            current.x = segment->data[0];
            current.y = segment->data[1];
        break;
        case SVG_PATH_COMMAND_LINE_TO_REL:
            graphics_path_line_to(graphics_path, segment->data[0], segment->data[1]);
            current.x += segment->data[0];
            current.y += segment->data[1];
        break;
        case SVG_PATH_COMMAND_QUAD_TO:
        {
            gdouble x1;
            gdouble y1;
            gdouble x2;
            gdouble y2;
            gdouble x3;
            gdouble y3;

            double c_x;
            double c_y;
            svg_path_segment_get_last_point((SvgPathSegment*) list->prev->data, &c_x, &c_y);

            x1 = c_x + 2.0/3.0 * (segment->data[0]-c_x);
            y1 = c_y + 2.0/3.0 * (segment->data[1]-c_y);

            x2 = segment->data[2] + 2.0/3.0 * (segment->data[0]-segment->data[2]);
            y2 = segment->data[3] + 2.0/3.0 * (segment->data[1]-segment->data[3]);

            x3 = segment->data[2];
            y3 = segment->data[3];

            graphics_path_curve_to(graphics_path, x1, y1, x2, y2, x3, y3);
            current.x = segment->data[2];
            current.y = segment->data[3];
        }
        break;
        case SVG_PATH_COMMAND_CUBIC_TO:
        {
            gdouble x1 = segment->data[0];
            gdouble y1 = segment->data[1];
            gdouble x2 = segment->data[2];
            gdouble y2 = segment->data[3];
            gdouble x3 = segment->data[4];
            gdouble y3 = segment->data[5];

            graphics_path_curve_to(graphics_path, x1, y1, x2, y2, x3, y3);
            current.x = segment->data[4];
            current.y = segment->data[5];
        }
        break;
        case SVG_PATH_COMMAND_CUBIC_TO_REL:
        {
            gdouble x1 = segment->data[0] + current.x;
            gdouble y1 = segment->data[1] + current.y;
            gdouble x2 = segment->data[2] + current.x;
            gdouble y2 = segment->data[3] + current.y;
            gdouble x3 = segment->data[4] + current.x;
            gdouble y3 = segment->data[5] + current.y;

            graphics_path_curve_to(graphics_path, x1, y1, x2, y2, x3, y3);
            current.x += segment->data[4];
            current.y += segment->data[5];
        }
        break;
        default:
            g_print("TODO CAIRO_PATH_CLOSE_PATH(%d)\n", segment->command);
        break;
        }
    }
    //return svg_path->cairo_path;
    return graphics_path;
}
