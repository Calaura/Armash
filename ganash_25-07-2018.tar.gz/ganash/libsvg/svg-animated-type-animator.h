/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-animated-type-animator.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_ANIMATED_TYPE_ANIMATOR_H__
#define __SVG_ANIMATED_TYPE_ANIMATOR_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_ANIMATED_TYPE_ANIMATOR            (svg_animated_type_animator_get_type())
#define SVG_ANIMATED_TYPE_ANIMATOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ANIMATED_TYPE_ANIMATOR, SvgAnimatedTypeAnimator))
#define SVG_ANIMATED_TYPE_ANIMATOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ANIMATED_TYPE_ANIMATOR, SvgAnimatedTypeAnimatorClass))
#define SVG_IS_ANIMATED_TYPE_ANIMATOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ANIMATED_TYPE_ANIMATOR))
#define SVG_IS_ANIMATED_TYPE_ANIMATOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ANIMATED_TYPE_ANIMATOR))
#define SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ANIMATED_TYPE_ANIMATOR, SvgAnimatedTypeAnimatorClass))

typedef struct _SvgAnimatedTypeAnimator SvgAnimatedTypeAnimator;
typedef struct _SvgAnimatedTypeAnimatorPrivate SvgAnimatedTypeAnimatorPrivate;
typedef struct _SvgAnimatedTypeAnimatorClass SvgAnimatedTypeAnimatorClass;


struct _SvgElementAnimatedProperties {
    SvgElement* element;
    GArray *properties;// of SvgAnimatedProperty
};
typedef struct _SvgElementAnimatedProperties SvgElementAnimatedProperties;
typedef GArray SvgElementAnimatedPropertyList;// of SvgElementAnimatedProperties

SvgElementAnimatedProperties*
svg_element_animated_properties_new(SvgElement *element, GArray *properties);

//------------------------------------------------------------------------------

struct _SvgAnimatedTypeAnimator {
	GObject parent_instance;

    /*< protected >*/
    AnimatedPropertyType type;
    SvgElementAnimation* animation_element;
    SvgElement* context_element;

    /* private */
	SvgAnimatedTypeAnimatorPrivate *private_member;
};

struct _SvgAnimatedTypeAnimatorClass {
	GObjectClass parent_class;

    /* virtual */
    gpointer (*construct_from_string)      (SvgAnimatedTypeAnimator *animator, gchar *String);/* @return gpointer<SvgAnimatedType>*/
    gpointer (*start_anim_val_animation)   (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);/* @return gpointer<SvgAnimatedType>*/
    void     (*stop_anim_val_animation)    (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
    void     (*reset_anim_val_to_base_val) (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list, SvgAnimatedType*type);
    void     (*anim_val_will_change)       (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
    void     (*anim_val_did_change)        (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
    void     (*add_animated_types)         (SvgAnimatedTypeAnimator *animator, SvgAnimatedType* type1, SvgAnimatedType *type2);
    void     (*calculate_animated_value)   (SvgAnimatedTypeAnimator *animator, float percentage, unsigned repeatCount, SvgAnimatedType*type1, SvgAnimatedType*type2, SvgAnimatedType*type3, SvgAnimatedType*type4);
    float    (*calculate_distance)         (SvgAnimatedTypeAnimator *animator, gchar* fromString, gchar* toString);

};

GType svg_animated_type_animator_get_type();
SvgAnimatedTypeAnimator *svg_animated_type_animator_new();

/* @return gpointer<SvgAnimatedType>*/
gpointer svg_animated_type_animator_construct_from_string      (SvgAnimatedTypeAnimator *animator, gchar *String);
/* @return gpointer<SvgAnimatedType>*/
gpointer svg_animated_type_animator_start_anim_val_animation   (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
void     svg_animated_type_animator_stop_anim_val_animation    (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
void     svg_animated_type_animator_reset_anim_val_to_base_val (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list, SvgAnimatedType*type);
void     svg_animated_type_animator_anim_val_will_change       (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
void     svg_animated_type_animator_anim_val_did_change        (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
void     svg_animated_type_animator_add_animated_types         (SvgAnimatedTypeAnimator *animator, SvgAnimatedType* type1, SvgAnimatedType *type2);
void     svg_animated_type_animator_calculate_animated_value   (SvgAnimatedTypeAnimator *animator, float percentage, unsigned repeatCount, SvgAnimatedType*type1, SvgAnimatedType*type2, SvgAnimatedType*type3, SvgAnimatedType*type4);
float    svg_animated_type_animator_calculate_distance         (SvgAnimatedTypeAnimator *animator, gchar* fromString, gchar* toString);



G_END_DECLS

#endif /* __SVG_ANIMATED_TYPE_ANIMATOR_H__ */

