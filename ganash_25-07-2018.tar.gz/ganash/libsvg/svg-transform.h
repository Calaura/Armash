/*
 * svg-transform.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_TRANSFORM_H__
#define __SVG_TRANSFORM_H__

#include <glib-object.h>


G_BEGIN_DECLS

typedef enum _SvgTransformType {
    SVG_TRANSFORM_UNKNOWN = 0,
    SVG_TRANSFORM_MATRIX,
    SVG_TRANSFORM_TRANSLATE,
    SVG_TRANSFORM_SCALE,
    SVG_TRANSFORM_ROTATE,
    SVG_TRANSFORM_SKEWX,
    SVG_TRANSFORM_SKEWY
} SvgTransformType;

#define SVG_TYPE_TRANSFORM            (svg_transform_get_type())
#define SVG_TRANSFORM(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_TRANSFORM, SvgTransform))
#define SVG_TRANSFORM_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_TRANSFORM, SvgTransformClass))
#define SVG_IS_TRANSFORM(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_TRANSFORM))
#define SVG_IS_TRANSFORM_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_TRANSFORM))
#define SVG_TRANSFORM_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_TRANSFORM, SvgTransformClass))

typedef struct _SvgTransform SvgTransform;
typedef struct _SvgTransformClass SvgTransformClass;

struct _SvgTransform {
	GObject parent_instance;

    SvgTransformType type;
    SvgMatrix        matrix;
    double           angle;
};

struct _SvgTransformClass {
	GObjectClass parent_class;
};

GType svg_transform_get_type();
SvgTransform *svg_transform_new();

void svg_transform_set_matrix(SvgTransform *transform, SvgMatrix *matrix);
void svg_transform_set_translate(SvgTransform *transform, double tx, double ty);
void svg_transform_set_scale(SvgTransform *transform, double sx, double sy);
void svg_transform_set_rotate(SvgTransform *transform, double angle, double cx, double cy);
void svg_transform_set_skew_x(SvgTransform *transform, double angle);
void svg_transform_set_skew_y(SvgTransform *transform, double angle);

void svg_transform_translate(SvgTransform *transform, double tx, double ty);


G_END_DECLS

#endif /* __SVG_TRANSFORM_H__ */
