/*
 * svg-time.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_TIME_H__
#define __SVG_TIME_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TIME(obj)            ((SvgTime *)obj)

#define SVG_TIME_UNRESOLVED_VALUE      DBL_MAX
#define SVG_TIME_UNRESOLVED           {SVG_TIME_UNRESOLVED_VALUE, SVG_TIME_TYPE_FULL, TRUE}

#define SVG_TIME_INDEFINITE_VALUE      FLT_MAX
#define SVG_TIME_INDEFINITE           {SVG_TIME_INDEFINITE_VALUE, SVG_TIME_TYPE_FULL, TRUE}

struct _SvgTime {
	/* private */
    double      seconds;
    SvgTimeType type  : 2;
    gboolean    empty : 1;
};

void     svg_time_init (SvgTime *object, gdouble seconds, SvgTimeType type, gboolean empty);

SvgTime *svg_time_new();
gboolean svg_time_is_finite(SvgTime *time);
gboolean svg_time_is_indefinite(SvgTime *time);
gboolean svg_time_is_unresolved(SvgTime *time);

SvgTime *svg_time_new_from_string(gchar* string);
void     svg_time_set_value(SvgTime *time, double seconds);
void     svg_time_set_value_from_string(SvgTime *time, gchar* string);
void     svg_time_set_indefinite(SvgTime *time);
void     svg_time_set_unresolved(SvgTime *time);

gchar   *svg_time_to_string(SvgTime *time);




enum _SvgOriginType {
    SvgOriginParser,
    SvgOriginScript
};
typedef enum _SvgOriginType SvgOriginType;


#define SVG_TIME_RELATIVE(obj)            ((SvgTimeRelative *)obj)


struct _SvgTimeRelative {
    SvgTime time;

    /*< public >*/

    /*< private >*/
    SvgOriginType origin;
};
typedef struct _SvgTimeRelative SvgTimeRelative;

struct _SvgTimeList {
    GArray times;
};
typedef struct _SvgTimeList SvgTimeList;
SvgTimeList *svg_time_list_new();
void         svg_time_list_free(SvgTimeList *list);
void         svg_time_list_set_value_from_string(SvgTimeList *times, gchar *value);


G_END_DECLS

#endif /* __SVG_TIME_H__ */

