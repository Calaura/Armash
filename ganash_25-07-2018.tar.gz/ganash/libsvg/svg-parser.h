/*
 * svg-parser.h
 * Copyright (C) 2002, 2003 The Karbon Developers
 * Copyright (C) 2006, 2007 Rob Buis <buis@kde.org>
 * Copyright (C) 2013       Apple Inc. All rights reserved.
 * Copyright (C) 2014       MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_PARSER_H__
#define __SVG_PARSER_H__


#define SVG_PARSER_NUMBER_ERROR_BAD_BEGIN          "The first character of a number must be one of [0-9+-.]"
#define SVG_PARSER_NUMBER_ERROR_EXPECTED_EXPONENT  "Expected exponent value"
#define SVG_PARSER_NUMBER_ERROR_RANGE_EXPONENT     "Invalide exponent range"
#define SVG_PARSER_NUMBER_ERROR_OVERFLOW           ""
#define SVG_PARSER_NUMBER_ERROR_NAN                ""


static gchar svg_parser_last_error[500];

#define svg_parser_is_space(c) ((c) == ' ' || (c) == '\t' || (c) == '\n' || (c) == '\r')
#define svg_parser_skip_space(ptr, end) while (ptr<=end && svg_parser_is_space(*ptr)) ptr++
#define svg_parser_skip_separator(ptr, end) while (ptr<=end && (svg_parser_is_space(*ptr) || *ptr == ',' || *ptr == ';')) ptr++
#define svg_parser_is_digit(c)  ( '0' <= (c) && (c) <= '9' )
#define svg_parser_is_xdigit(c) ( svg_parser_is_digit(c) || ('A' <= (c) && (c) <= 'F') )

gchar*        svg_parser_parse_double(gchar* ptr, gchar* end, gdouble *number, gboolean skip);

gchar*        svg_parser_parse_offset(gdouble *value, SvgOffsetType *type, gchar *ptr, gchar *end);

gchar*        svg_parser_parse_decimal(gdouble *value, SvgNumberType *type, gchar* ptr, gchar* end);
SvgLengthType svg_parser_parse_length_type(gchar* ptr, gchar* end);/*refactor*/

gchar*        svg_parser_parse_color(SvgColor *color, gchar *ptr, gchar *end/*, gboolean skip*/);

gchar*        svg_parser_parse_transform(SvgTransformList *transforms, gchar *ptr, gchar *end);

gchar*        svg_parser_parse_time(SvgTime *time, gchar *ptr, gchar *end);
gchar*        svg_parser_parse_path_from_buffer(SvgPath *path, char *ptr, char *end);

gchar*        svg_parser_parse_paint(SvgPaint *paint, gchar* value);

#endif /* __SVG_PARSER_H__ */
