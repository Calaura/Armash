/*
 * svg-animated-length.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_ANIMATED_LENGTH_H__
#define __SVG_ANIMATED_LENGTH_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_ANIMATED_LENGTH            (svg_animated_length_get_type())
#define SVG_ANIMATED_LENGTH(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ANIMATED_LENGTH, SvgAnimatedLength))
#define SVG_ANIMATED_LENGTH_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ANIMATED_LENGTH, SvgAnimatedLengthClass))
#define SVG_IS_ANIMATED_LENGTH(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ANIMATED_LENGTH))
#define SVG_IS_ANIMATED_LENGTH_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ANIMATED_LENGTH))
#define SVG_ANIMATED_LENGTH_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ANIMATED_LENGTH, SvgAnimatedLengthClass))

typedef struct _SvgAnimatedLengthClass SvgAnimatedLengthClass;

struct _SvgAnimatedLength {
    SvgAnimated parent_instance;// SvgAnimatedPropertyTearOff : SvgAnimatedProperty

    SvgLength *property;

    SvgLength *baseVal;
    SvgLength *animVal;

};

struct _SvgAnimatedLengthClass {
    SvgAnimatedClass parent_class;
};


GType svg_animated_length_get_type();
SvgAnimatedLength *svg_animated_length_new();
double             svg_animated_length_get_value(SvgAnimatedLength *animated_length, gdouble time);
void               svg_animated_length_anim_val_did_change(SvgAnimatedLength *animated_length);

// -----------------------------------------------------------------------------

#define SVG_TYPE_ANIMATED_LENGTH_ANIMATOR            (svg_animated_length_animator_get_type())
#define SVG_ANIMATED_LENGTH_ANIMATOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ANIMATED_LENGTH_ANIMATOR, SvgAnimatedLengthAnimator))
#define SVG_ANIMATED_LENGTH_ANIMATOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ANIMATED_LENGTH_ANIMATOR, SvgAnimatedLengthAnimatorClass))
#define SVG_IS_ANIMATED_LENGTH_ANIMATOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ANIMATED_LENGTH_ANIMATOR))
#define SVG_IS_ANIMATED_LENGTH_ANIMATOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ANIMATED_LENGTH_ANIMATOR))
#define SVG_ANIMATED_LENGTH_ANIMATOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ANIMATED_LENGTH_ANIMATOR, SvgAnimatedLengthAnimatorClass))

typedef struct _SvgAnimatedLengthAnimator        SvgAnimatedLengthAnimator;
typedef struct _SvgAnimatedLengthAnimatorClass   SvgAnimatedLengthAnimatorClass;
typedef struct _SvgAnimatedLengthAnimatorPrivate SvgAnimatedLengthAnimatorPrivate;

struct _SvgAnimatedLengthAnimatorPrivate {
    SvgLengthMode length_mode;
};
struct _SvgAnimatedLengthAnimator {
    SvgAnimatedTypeAnimator parent_instance;
    /*< private >*/
    SvgAnimatedLengthAnimatorPrivate *priv;
};

struct _SvgAnimatedLengthAnimatorClass {
    SvgAnimatedTypeAnimatorClass parent_class;
};

GType svg_animated_length_animator_get_type();
SvgAnimatedLengthAnimator *svg_animated_length_animator_new();







G_END_DECLS

#endif /* __SVG_ANIMATED_LENGTH_H__ */

