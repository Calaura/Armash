/*
 * svg-animated.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_ANIMATED_H__
#define __SVG_ANIMATED_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_ANIMATED            (svg_animated_get_type())
#define SVG_ANIMATED(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ANIMATED, SvgAnimated))
#define SVG_ANIMATED_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ANIMATED, SvgAnimatedClass))
#define SVG_IS_ANIMATED(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ANIMATED))
#define SVG_IS_ANIMATED_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ANIMATED))
#define SVG_ANIMATED_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ANIMATED, SvgAnimatedClass))

typedef struct _SvgAnimatedClass SvgAnimatedClass;

struct _SvgAnimated {
	GObject parent_instance;

    /* private */
    MotionProperty *property;
};

struct _SvgAnimatedClass {
	GObjectClass parent_class;
};

GType svg_animated_get_type();
SvgAnimated *svg_animated_new();

G_END_DECLS

#endif /* __SVG_ANIMATED_H__ */

