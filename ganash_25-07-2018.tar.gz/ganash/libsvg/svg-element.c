/*
 * svg-element.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <liblog/log.h>


#include <glib-object.h>
#include <cairo/cairo.h>

#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-container.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-document.h"
#include "svg-time.h"
#include "svg-updater.h"


enum
{
  PROPERTY_0,

  PROPERTY_XML_NODE,

  PROPERTIES_LENGTH
};

static int      svg_element_default_init_from_xml(DomNode *element, xmlNode* node);
static gboolean svg_element_default_parse_attribute(SvgElement* element, DomQualifiedName* name, guchar* value);
static SvgAttributeToPropertyMap*
                svg_element_default_attribute_to_property_map(SvgElement *element);

static gchar*   svg_element_default_to_string(SvgElement *element, gchar *indent);
#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
static gchar*   svg_element_default_dump(DomNode *dom, LogDumpOptions *options);
#endif

static void svg_element_set_property (GObject      *object,
                                      guint         property_id,
                                      const GValue *value,
                                      GParamSpec   *pspec);
static void svg_element_get_property (GObject    *object,
                                      guint       property_id,
                                      GValue     *value,
                                      GParamSpec *pspec);


static void svg_element_class_init(SvgElementClass *klass);
static void svg_element_init(SvgElement *gobject);

static GParamSpec *svg_element_properties[PROPERTIES_LENGTH] = { NULL, };

G_DEFINE_TYPE (SvgElement, svg_element, DOM_TYPE_ELEMENT)

static void
svg_element_class_init(SvgElementClass *klass)
{
    GObjectClass *gobject_class;
    DomNodeClass *dom_class;

    dom_class = (DomNodeClass *) klass;

    gobject_class = (GObjectClass *) klass;
    gobject_class->set_property = svg_element_set_property;
    gobject_class->get_property = svg_element_get_property;

    /* DOM interface */
#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
    dom_class->dump             = svg_element_default_dump;
#endif
    dom_class->init_from_xml    = svg_element_default_init_from_xml;

    /* Debug interface */
    klass->to_string    = svg_element_default_to_string;
    klass->parse_attribute      = svg_element_default_parse_attribute;

    klass->updater = svg_updater_new();// ?

    klass->attribute_to_property_map = svg_element_default_attribute_to_property_map;


    svg_element_properties[PROPERTY_XML_NODE] =
      g_param_spec_pointer ("xml-node",
                            "xmlNode",
                            "Set/Get xml node",
                            G_PARAM_CONSTRUCT | G_PARAM_READABLE | G_PARAM_WRITABLE);

    g_object_class_install_properties (gobject_class,
                                       PROPERTIES_LENGTH,
                                       svg_element_properties);

    /*svg_element_parent_class = g_type_class_peek_parent (klass); done by macro*/
    g_type_class_add_private(klass, sizeof(SvgElementPrivate));
    /*g_type_add_class_private(klass, sizeof(SvgElementPrivate));*/
}


static void
svg_element_init (SvgElement *object)
{
    object->private_member = SVG_ELEMENT_GET_PRIVATE(object);
    object->private_member->renderer = NULL;
    /*g_print("SvgElement {nil}\n", object->xml_node);*/
    object->attribute_id = 0;
    object->name = G_OBJECT_TYPE_NAME(object);/*for debug*/

    object->status_update = 0
            | SVG_UPDATE_STATUS_UNKNOW << SVG_UPDATE_SHAPE_SHIFT
            | SVG_UPDATE_STATUS_UNKNOW << SVG_UPDATE_TRANSFORM_SHIFT
            | SVG_UPDATE_STATUS_UNKNOW << SVG_UPDATE_STYLE_SHIFT
            | SVG_UPDATE_STATUS_UNKNOW << SVG_UPDATE_GRAPHICS_SHIFT;

}

/* private function */
static void
svg_element_set_property (GObject      *object,
                          guint         property_id,
                          const GValue *value,
                          GParamSpec   *pspec)
{
    SvgElement *element = SVG_ELEMENT (object);

    switch (property_id)
    {
    case PROPERTY_XML_NODE:
        svg_element_set_xml(element, (xmlNode*) g_value_get_pointer(value));
    break;
    default:
        /* We don't have any other property... */
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, property_id, pspec);
    break;
    }
}

static void
svg_element_get_property (GObject    *object,
                          guint       property_id,
                          GValue     *value,
                          GParamSpec *pspec)
{
    SvgElement *element = SVG_ELEMENT (object);

    switch (property_id)
    {
    case PROPERTY_XML_NODE:
        g_value_set_pointer(value, (gpointer) svg_element_get_xml(element));
    break;
    default:
        /* We don't have any other property... */
        G_OBJECT_WARN_INVALID_PROPERTY_ID (object, property_id, pspec);
    break;
    }
}

/* virtual function */
/*
 * [SvgElementRect{id: "", transform: "rotate(), translate()", renderer: @0x0000afcff21, children:[]}]
 */
static gchar*
svg_element_default_to_string(SvgElement *element, gchar *indent)
{
    gchar *content = g_strdup("");
    gchar *tmp = content;

    if (element->attribute_id) {
        content = g_strdup_printf("id: \"%s\"", element->attribute_id);
        g_free(tmp);
        tmp = content;
    }

    /*RendererObject *object = element->private_member->renderer;
    if(object)
    {
        gchar *str_renderer = renderer_object_dump(object, "", 0x11111111);
        //content = g_strdup_printf("%s, renderer: [%s@%p{}]", content, G_OBJECT_TYPE_NAME(element->private_member->renderer), element->private_member->renderer);
        content = g_strdup_printf("%s, renderer: %s", content, str_renderer);
        g_free(str_renderer);
        g_free(tmp);
        tmp = content;
    }*/

/*
    if(!renderer_matrix_is_identity(&object->transform))
    {
        if (tmp) {
            gchar *matrix = renderer_matrix_to_string(&object->transform);
            content = g_strdup_printf("%s, transform: %s", content, matrix);
            g_free(matrix);
            g_free(tmp);
            tmp = content;
        } else {
            gchar *matrix = renderer_matrix_to_string(&object->transform);
            content = g_strdup_printf("transform: %s", content, matrix);
            g_free(matrix);
            tmp = content;
        }
    }
*/
    /*if (tmp) {
        content = g_strdup_printf("%s, index: %d", content, object->index);
        g_free(tmp);
        tmp = content;
    } else {
        content = g_strdup_printf("index: %d", object->index);
        tmp = content;
    }*/

    content = g_strdup_printf("%s[%s@%p{%s%%s}]", indent, G_OBJECT_TYPE_NAME(element), element, content);
    g_free(tmp);
    tmp = content;

    return  content;
}

#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
static gchar*
svg_element_default_dump(DomNode *dom, LogDumpOptions *options)
{
#   define CONTENT "%s"
#   define PLACE_HOLDER "%%s"
#   define TAB "%s"
#   define EOL "%s"
#   define GLUE "%s"
#   define TYPE_NAME "%s"

    SvgElement *element = SVG_ELEMENT(dom);


    // Use indentation
    gchar *indent;
    gchar *indent_;
    gchar *indent__;
    gchar *new_line;
    gchar *endl;
    gchar *glue_ = g_strdup("");
    gchar *glue = glue_;

    if (options->flags & LOG_DUMP_INDENT_FLAG) {
        size_t num_char = strlen(options->config->indent);
        size_t depth = num_char*options->depth +1;
        size_t depth_ = num_char*(options->depth+1)+1;
        size_t depth__ = num_char*(options->depth+2)+1;
        indent = g_new(gchar, depth);
        memset(indent, options->config->indent[0], depth);
        indent_ = g_new(gchar, depth_);
        memset(indent_, options->config->indent[0], depth_);
        indent__ = g_new(gchar, depth__);
        memset(indent__, options->config->indent[0], depth__);
        indent[depth-1] = '\0';
        indent_[depth_-1] = '\0';
        indent__[depth__-1] = '\0';


        if (options->newl) {
            new_line = g_strdup_printf(EOL""TAB, options->config->endl, indent);
        } else {
            new_line = g_strdup("");
        }
        endl = g_strdup(options->config->endl);
    } else {
        indent   = g_strdup("");
        indent_  = g_strdup("");
        new_line = g_strdup("");
        endl     = g_strdup("");
    }

    gchar *content = g_strdup("%s");
    gchar *tmp = content;
    gchar *dump;
    gchar *tmp_dump;

    dump = DOM_NODE_CLASS(svg_element_parent_class)->dump(dom, options);
    tmp_dump = dump;
    if (options->has_content)
        glue = options->config->glue;

    if ((options->flags & SVG_DUMP_ID_FLAG) && element->attribute_id) {
        content = g_strdup_printf(GLUE""EOL""TAB"id: \"%s\""PLACE_HOLDER, glue, endl, indent_, element->attribute_id);
        glue = options->config->glue;
        options->has_content = 1;
        g_free(tmp);
        tmp = content;
    }


    LogDumpOptions opt = *options;
    opt.depth++;
    if ((options->flags & SVG_DUMP_RENDERER_FLAG) && element->private_member->renderer) {
        char *renderer = log_dump_to_string(element->private_member->renderer, &opt);

        content = g_strdup_printf(content, "");
        g_free(tmp);
        tmp = content;
        content = g_strdup_printf(CONTENT""GLUE""EOL""TAB"renderer: %s"PLACE_HOLDER, content, glue, endl, indent_, renderer);
        g_free(tmp);
        tmp = content;

        g_free(renderer);

        glue = options->config->glue;
        options->has_content = 1;
    }


    dump = g_strdup_printf(dump, content);
    g_free(tmp_dump);
    g_free(tmp);


    /*
    gchar *content = g_strdup("");
    gchar *tmp = content;
    gchar *indent1 = g_strdup_printf(TAB""TAB, indent, "    ");
    gchar *indent2 = g_strdup_printf(TAB""TAB, indent1, "    ");

    if ((flags & SVG_DUMP_ID_FLAG) && element->attribute_id) {
        content = g_strdup_printf("id: \"%s\", "PLACE_HOLDER, element->attribute_id);
        g_free(tmp);
        tmp = content;
    }

    if ((flags & SVG_DUMP_RENDERER_FLAG) && element->private_member->renderer) {
        gchar *tmp_renderer = renderer_object_dump(element->private_member->renderer, indent1, flags);
        gchar *str_renderer = g_strdup_printf(tmp_renderer, "");// clear PLACE_HOLDER
        g_free(tmp_renderer);
        tmp_renderer = str_renderer;

        content = g_strdup_printf(SHIFT_CONTENT"\n"TAB"renderer:%s, ", content, indent1, str_renderer);// id: "", renderer: [RendererShape]
        g_free(str_renderer);
        g_free(tmp);
        tmp = content;
    }

    if (flags & SVG_DUMP_POINTER_FLAG) {
        content = g_strdup_printf(TAB"["TYPE_NAME"@%p{%s"PLACE_HOLDER"\n"TAB"}]", indent, G_OBJECT_TYPE_NAME(element), element, content, indent);
        g_free(tmp);
        tmp = content;
    } else {
        content = g_strdup_printf(TAB"["TYPE_NAME"{%s"PLACE_HOLDER"\n"TAB"}]", indent, G_OBJECT_TYPE_NAME(element), content, indent);
        g_free(tmp);
        tmp = content;
    }

    return content;*/

    return dump;
}
#endif

RendererObject* svg_element_default_get_renderer(SvgElement* element/*RendererStyle* style*/)
{
    return NULL;
}

static int svg_element_default_init_from_xml(DomNode* element, xmlNode* node)
{
    gboolean ret = DOM_NODE_CLASS(svg_element_parent_class)->init_from_xml(DOM_NODE(element), node);

    node->_private = element;
    xmlAttr* attribute = node->properties;
    while(attribute && attribute->name && attribute->children)
    {
        xmlChar* value = xmlNodeListGetString(node->doc, attribute->children, 1);

        DomQualifiedName attribute_name = {"svg", attribute->name};
        if (attribute->ns && attribute->ns->prefix) {
            attribute_name.prefix = attribute->ns->prefix;
        }
        gboolean ret = SVG_ELEMENT_GET_CLASS(element)->parse_attribute(element, &attribute_name, value);
        /*if(!ret) {
            g_message("Unknown attribute \"%s\" on <%s> in %s:%d",
                      BAD_CAST attribute->name, BAD_CAST node->name, node->doc->URL, node->line);
        }*/
        xmlFree(value);
        attribute = attribute->next;
    }
    return 0;
}

static SvgAttributeToPropertyMap*
svg_element_default_attribute_to_property_map(SvgElement *element)
{
    //element->private_member->renderer;

    return NULL;
}


static gboolean svg_element_default_parse_attribute(SvgElement* element, DomQualifiedName* qualified_name, guchar* value)
{
    if(dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "id"))) {
        // FIXME attribute_id string should be freed with g_free() when no longer needed.
        element->attribute_id = g_strdup (value);
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("xml", "id"))) {// FIXME
        element->attribute_id = g_strdup (value);
    } else {
        return FALSE;
    }

    return TRUE;
}

/* public function */
/*
int svg_element_init_from_xml(SvgElement* element, xmlNode* node)
{
    svg_element_set_xml(element, node);
    //element->private_member->xml_node = node;
    return DOM_NODE_GET_CLASS(element)->init_from_xml(DOM_NODE(element), node);
}
*/

gboolean svg_element_parse_attribute(SvgElement* element, DomQualifiedName *qualified_name, guchar* value)
{
    return SVG_ELEMENT_GET_CLASS(element)->parse_attribute(element, qualified_name, value);
}

SvgElement*
svg_element_new_from_xml(GType type, xmlNode *node)
{
    SvgElement* element = g_object_new (type, NULL);

    return element;
}

double svg_element_get_time(SvgElement *element)
{
    SvgDocument *doc = SVG_DOCUMENT(dom_node_get_document(DOM_NODE(element)));
    SvgTime *time = doc->time;
    return time->seconds;
}

gchar* svg_element_to_string(SvgElement *element, gchar *indent)
{
    SVG_ELEMENT_GET_CLASS(element)->to_string(element, indent);
}

SvgAttributeToPropertyMap*
svg_element_attribute_to_property_map(SvgElement *element)
{
    return SVG_ELEMENT_GET_CLASS(element)->attribute_to_property_map(element);
}
