/*
 * svg-drawable.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>


#include <libgraphics/graphics.h>

#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>
#include <librenderer/renderer-cache.h>
#include <librenderer/renderer-object.h>

#include <glib-object.h>

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-paint.h"
#include "svg-drawable.h"
#include "svg-updater.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-element-graphics.h"

static void svg_drawable_default_draw(SvgDrawable *drawable,
                                      cairo_t *cr);

G_DEFINE_INTERFACE (SvgDrawable, svg_drawable, 0)

static void
svg_drawable_default_init (SvgDrawableInterface* iface)
{
    iface->draw = svg_drawable_default_draw;
}

static void
svg_drawable_default_draw(SvgDrawable *drawable, cairo_t *cr)
{
}

void
svg_drawable_draw (SvgDrawable *drawable, cairo_t *cr)
{
    if(SVG_IS_DRAWABLE(drawable))
        SVG_DRAWABLE_GET_INTERFACE (drawable)->draw(drawable, cr);
}
