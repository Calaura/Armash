/*
 * svg-element-graphics.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_ELEMENT_GRAPHICS_H__
#define __SVG_ELEMENT_GRAPHICS_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_ELEMENT_GRAPHICS            (svg_element_graphics_get_type())
#define SVG_ELEMENT_GRAPHICS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_ELEMENT_GRAPHICS, SvgElementGraphics))
#define SVG_ELEMENT_GRAPHICS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_ELEMENT_GRAPHICS, SvgElementGraphicsClass))
#define SVG_IS_ELEMENT_GRAPHICS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_ELEMENT_GRAPHICS))
#define SVG_IS_ELEMENT_GRAPHICS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_ELEMENT_GRAPHICS))
#define SVG_ELEMENT_GRAPHICS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_ELEMENT_GRAPHICS, SvgElementGraphicsClass))

typedef struct _SvgElementGraphicsPrivate SvgElementGraphicsPrivate;
typedef struct _SvgElementGraphicsClass SvgElementGraphicsClass;

struct _SvgElementGraphics {
	SvgElement parent_instance;
	/* private */
	SvgElementGraphicsPrivate *private_member;
};

/*
typedef struct _SvgRendererClass{
    void (*transform) (SvgElement *element);
    void (*fill)      (SvgElement *element);
    void (*stroke)    (SvgElement *element);
    void (*path)      (SvgElement *element);
} SvgRendererClass;
*/

struct _SvgElementGraphicsClass {
	SvgElementClass parent_class;

    /* drawable feature */
    /*RendererObject* (* get_renderer)           (SvgElement* element);*/
    RendererObject* (* create_renderer)        (SvgElement *element, gboolean attache);
    gboolean        (* update_renderer)        (SvgElement *element/*RendererStyle *self*/);

    /*SvgRendererClass renderer_access;
    SvgRendererClass renderer_create;
    SvgRendererClass renderer_update;
    SvgRendererClass renderer_remove;*/

    /* interactive feature */
    void            (* hit_test)               (SvgElement *element, SvgHitRequest *request, SvgHitResult *result);

};

GType svg_element_graphics_get_type();

SvgElementGraphics *svg_element_graphics_new();

/* stylable interface */
SvgStyle           *svg_element_graphics_get_style(SvgElementGraphics *graphics);

/* locatable interface */
SvgTransformList   *svg_element_graphics_get_transform(SvgElementGraphics *graphics);
void                svg_element_graphics_set_transform(SvgElementGraphics *graphics, SvgTransformList *transforms);

void                svg_element_graphics_update_style(SvgElementGraphics *graphics);
void                svg_element_graphics_update_transform(SvgElement *element);
void                svg_element_graphics_update_graphics(SvgElementGraphics *graphics);

RendererObject     *svg_element_graphics_get_renderer(SvgElement *element);
RendererObject     *svg_element_graphics_create_renderer(SvgElement *element, gboolean attache);
gboolean            svg_element_graphics_update_renderer(SvgElement *element);

void svg_element_graphics_queue_update(SvgElement *element, SvgUpdateFlags flags, uint types);

/* interactive interface */
void                svg_element_graphics_hit_test(SvgElement *element, SvgHitRequest *request, SvgHitResult *result);


G_END_DECLS

#endif /* __SVG_ELEMENT_GRAPHICS_H__ */

