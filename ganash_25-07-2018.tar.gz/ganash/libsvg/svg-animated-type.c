/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-animated-type.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include <liblog/log.h>
#include "librenderer/renderer.h"
#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "properties/svg-animated-property.h"
#include "properties/svg-property-info.h"
#include "svg-animated-type.h"

#define SVG_ANIMATED_TYPE_INIT  { 0, { 0 }}
#define StdPair(T1, T2) struct {T1 first; T2 second;}
#define StdPtr(T1) struct {T1 *ptr;}
#define StdRef(T1) struct {T1 *ptr;}/*REF(SvgLength) width; std_ref(width); std_unref(width); */
#define StdMove(ptr, dest)
#define StdEach(ptr, dest)


#define SVG_ANIMATED_TYPE_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), SVG_TYPE_ANIMATED_TYPE, SvgAnimatedTypePrivate))
struct _SvgAnimatedTypePrivate {
    AnimatedPropertyType type;

    union DataUnion {
        //StdPair(SvgAngle*, int) *angleAndEnumeration;
        gboolean* boolean;
        SvgColor* color;
        unsigned* enumeration;
        int* integer;
        StdPair(int, int)* integerOptionalInteger;
        SvgLength* length;
        SvgLengthList* lengthList;
        float* number;
        /*
        SvgNumberList* numberList;
        */
        StdPair(float, float)* numberOptionalNumber;
        /*
        SVGPathByteStream* path;
        SVGPreserveAspectRatio* preserveAspectRatio;
        SVGPointList* pointList;
        FloatRect* rect;
        */
        gchar/*String*/* string;
        SvgTransformList* transformList;
    } data;
};


static void svg_animated_type_class_init(SvgAnimatedTypeClass *klass);
static void svg_animated_type_init(SvgAnimatedType *gobject);

G_DEFINE_TYPE (SvgAnimatedType, svg_animated_type, G_TYPE_OBJECT)

static void
svg_animated_type_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (svg_animated_type_parent_class)->finalize (object);
}
static void
svg_animated_type_class_init(SvgAnimatedTypeClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = svg_animated_type_finalize;

    g_type_class_add_private(klass, sizeof(SvgAnimatedTypePrivate));
//	svg_animated_type_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_animated_type_init (SvgAnimatedType *object)
{
	SvgAnimatedTypePrivate *priv = SVG_ANIMATED_TYPE_GET_PRIVATE(object);
	object->private_member = priv;

    priv->type = AnimatedBoolean;
    priv->data.boolean = FALSE;
}

SvgAnimatedType *
svg_animated_type_new (AnimatedPropertyType type)
{
    SvgAnimatedType *animated;

    animated = (SvgAnimatedType*) g_object_new (svg_animated_type_get_type (), NULL);
    animated->private_member->type = type;

    return animated;
}

// -----------------------------------------------------------------------------
/*
SVGAnimatedType(AnimatedPropertyType);
virtual ~SVGAnimatedType();

static std::unique_ptr<SVGAnimatedType> createAngleAndEnumeration(std::unique_ptr<std::pair<SVGAngle, unsigned>>);
*/
/*
#define STD_UNIQUE_PTR(type) \
    struct { \
        type *ptr; \
    }

static STD_UNIQUE_PTR(SvgAnimatedType) createBoolean(STD_UNIQUE_PTR<gboolean>);

struct {SvgAnimatedType) svg_animated_type_create_boolean(SvgAnimatedType type, STD_UNIQUE_PTR(gboolean) boolean)
{
    //g_assert(boolean);
    //SvgAnimatedType *animatedType = std::make_unique<SvgAnimatedType>(AnimatedBoolean);
    //animatedType->data.boolean = boolean.release();
    return animatedType;
}

GValue value = G_VALUE_INIT;
g_value_init(&value, INT);
g_value_get_int(&value);
*/

#include "libstd/std-unique-ptr.h"

void svg_animated_type_set_boolean(SvgAnimatedType *animated_type, gboolean boolean)
{
    g_assert(animated_type);
    animated_type->private_member->type = AnimatedBoolean;
    animated_type->private_member->data.boolean = boolean;
}

void svg_animated_type_set_integer(SvgAnimatedType *animated_type, int integer)
{
    g_assert(animated_type);
    animated_type->private_member->type = AnimatedInteger;
    animated_type->private_member->data.integer = integer;
}

/*
std::unique_ptr<SVGAnimatedType> SVGAnimatedType::createBoolean(std::unique_ptr<bool> boolean)
{
    ASSERT(boolean);
    auto animatedType = std::make_unique<SVGAnimatedType>(AnimatedBoolean);
    animatedType->m_data.boolean = boolean.release();
    return animatedType;
}
*/

/*
static std::unique_ptr<SVGAnimatedType> createColor(std::unique_ptr<Color>);
static std::unique_ptr<SVGAnimatedType> createEnumeration(std::unique_ptr<unsigned>);
static std::unique_ptr<SVGAnimatedType> createInteger(std::unique_ptr<int>);
static std::unique_ptr<SVGAnimatedType> createIntegerOptionalInteger(std::unique_ptr<std::pair<int, int>>);
*/
SvgAnimatedType *svg_animated_type_new_length(SvgLength *length)
{
    g_assert(length);
    SvgAnimatedType *type = svg_animated_type_new (AnimatedLength);
    type->private_member->data.length = length;//.release();
    return type;
}

/*
static std::unique_ptr<SVGAnimatedType> createLengthList(std::unique_ptr<SVGLengthList>);
static std::unique_ptr<SVGAnimatedType> createNumber(std::unique_ptr<float>);
static std::unique_ptr<SVGAnimatedType> createNumberList(std::unique_ptr<SVGNumberList>);
static std::unique_ptr<SVGAnimatedType> createNumberOptionalNumber(std::unique_ptr<std::pair<float, float>>);
static std::unique_ptr<SVGAnimatedType> createPath(std::unique_ptr<SVGPathByteStream>);
static std::unique_ptr<SVGAnimatedType> createPointList(std::unique_ptr<SVGPointList>);
static std::unique_ptr<SVGAnimatedType> createPreserveAspectRatio(std::unique_ptr<SVGPreserveAspectRatio>);
static std::unique_ptr<SVGAnimatedType> createRect(std::unique_ptr<FloatRect>);
static std::unique_ptr<SVGAnimatedType> createString(std::unique_ptr<String>);
static std::unique_ptr<SVGAnimatedType> createTransformList(std::unique_ptr<SVGTransformList>);
static bool supportsAnimVal(AnimatedPropertyType);

AnimatedPropertyType type() const { return m_type; }

// Non-mutable accessors.
const std::pair<SVGAngle, unsigned>& angleAndEnumeration() const
{
    ASSERT(m_type == AnimatedAngle);
    return *m_data.angleAndEnumeration;
}

const bool& boolean() const
{
    ASSERT(m_type == AnimatedBoolean);
    return *m_data.boolean;
}

const Color& color() const
{
    ASSERT(m_type == AnimatedColor);
    return *m_data.color;
}

const unsigned& enumeration() const
{
    ASSERT(m_type == AnimatedEnumeration);
    return *m_data.enumeration;
}

const int& integer() const
{
    ASSERT(m_type == AnimatedInteger);
    return *m_data.integer;
}

const std::pair<int, int>& integerOptionalInteger() const
{
    ASSERT(m_type == AnimatedIntegerOptionalInteger);
    return *m_data.integerOptionalInteger;
}

const SVGLength& length() const
{
    ASSERT(m_type == AnimatedLength);
    return *m_data.length;
}
*/
SvgLength       *svg_animated_type_get_length(SvgAnimatedType *animated)
{
    g_assert(animated->private_member->type == AnimatedLength);
    return animated->private_member->data.length;
}

/*
const SVGLengthList& lengthList() const
{
    ASSERT(m_type == AnimatedLengthList);
    return *m_data.lengthList;
}

const float& number() const
{
    ASSERT(m_type == AnimatedNumber);
    return *m_data.number;
}

const SVGNumberList& numberList() const
{
    ASSERT(m_type == AnimatedNumberList);
    return *m_data.numberList;
}

const std::pair<float, float>& numberOptionalNumber() const
{
    ASSERT(m_type == AnimatedNumberOptionalNumber);
    return *m_data.numberOptionalNumber;
}

const SVGPathByteStream* path() const
{
    ASSERT(m_type == AnimatedPath);
    return m_data.path;
}

const SVGPointList& pointList() const
{
    ASSERT(m_type == AnimatedPoints);
    return *m_data.pointList;
}

const SVGPreserveAspectRatio& preserveAspectRatio() const
{
    ASSERT(m_type == AnimatedPreserveAspectRatio);
    return *m_data.preserveAspectRatio;
}

const FloatRect& rect() const
{
    ASSERT(m_type == AnimatedRect);
    return *m_data.rect;
}

const String& string() const
{
    ASSERT(m_type == AnimatedString);
    return *m_data.string;
}

const SVGTransformList& transformList() const
{
    ASSERT(m_type == AnimatedTransformList);
    return *m_data.transformList;
}

// Mutable accessors.
std::pair<SVGAngle, unsigned>& angleAndEnumeration()
{
    ASSERT(m_type == AnimatedAngle);
    return *m_data.angleAndEnumeration;
}

bool& boolean()
{
    ASSERT(m_type == AnimatedBoolean);
    return *m_data.boolean;
}

Color& color()
{
    ASSERT(m_type == AnimatedColor);
    return *m_data.color;
}

unsigned& enumeration()
{
    ASSERT(m_type == AnimatedEnumeration);
    return *m_data.enumeration;
}

int& integer()
{
    ASSERT(m_type == AnimatedInteger);
    return *m_data.integer;
}

std::pair<int, int>& integerOptionalInteger()
{
    ASSERT(m_type == AnimatedIntegerOptionalInteger);
    return *m_data.integerOptionalInteger;
}

SVGLength& length()
{
    ASSERT(m_type == AnimatedLength);
    return *m_data.length;
}

SVGLengthList& lengthList()
{
    ASSERT(m_type == AnimatedLengthList);
    return *m_data.lengthList;
}

float& number()
{
    ASSERT(m_type == AnimatedNumber);
    return *m_data.number;
}

SVGNumberList& numberList()
{
    ASSERT(m_type == AnimatedNumberList);
    return *m_data.numberList;
}

std::pair<float, float>& numberOptionalNumber()
{
    ASSERT(m_type == AnimatedNumberOptionalNumber);
    return *m_data.numberOptionalNumber;
}

SVGPathByteStream* path()
{
    ASSERT(m_type == AnimatedPath);
    return m_data.path;
}

SVGPointList& pointList()
{
    ASSERT(m_type == AnimatedPoints);
    return *m_data.pointList;
}

SVGPreserveAspectRatio& preserveAspectRatio()
{
    ASSERT(m_type == AnimatedPreserveAspectRatio);
    return *m_data.preserveAspectRatio;
}

FloatRect& rect()
{
    ASSERT(m_type == AnimatedRect);
    return *m_data.rect;
}

String& string()
{
    ASSERT(m_type == AnimatedString);
    return *m_data.string;
}

SVGTransformList& transformList()
{
    ASSERT(m_type == AnimatedTransformList);
    return *m_data.transformList;
}

String valueAsString();
bool setValueAsString(const QualifiedName&, const String&);
*/
