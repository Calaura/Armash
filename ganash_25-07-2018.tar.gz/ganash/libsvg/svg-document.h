/*
 * svg-document.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_DOCUMENT_H__
#define __SVG_DOCUMENT_H__


#include <libcroco/libcroco.h>

#include <glib-object.h>

G_BEGIN_DECLS


#define SVG_TYPE_DOCUMENT            (svg_document_get_type())
#define SVG_DOCUMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_DOCUMENT, SvgDocument))
#define SVG_DOCUMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_DOCUMENT, SvgDocumentClass))
#define SVG_IS_DOCUMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_DOCUMENT))
#define SVG_IS_DOCUMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_DOCUMENT))
#define SVG_DOCUMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_DOCUMENT, SvgDocumentClass))

typedef struct _SvgDocumentClass SvgDocumentClass;

struct _SvgDocument {
    DomDocument parent_instance;

    /* private */
    //GList  *stylesheet_list;//GList<CRStyleSheet>

    SvgTime          *time;
    SvgTimeContainer *time_container;

    RendererView     *view;

    guint             instance_count;// g_assert(instance_count<2^(32-8))
};

struct _SvgDocumentClass {
    DomDocumentClass parent_class;
};

GType svg_document_get_type();
/**
 * @brief svg_document_new
 * Creation d'un document
 * @return SvgDocument*
 */
SvgDocument   *svg_document_new();
void           svg_document_xml_new (SvgDocument *document);
SvgElement    *svg_document_create_element(SvgDocument *document, const char *name);

SvgDocument   *svg_document_load (const gchar *uri);
SvgElementSvg *svg_document_get_root(SvgDocument* document);
RendererView  *svg_document_get_view(SvgDocument *document);

/*RendererScene* svg_document_get_renderer_scene(SvgDocument* document);*/
void svg_document_set_time(SvgDocument *document, double time);

void        svg_document_draw(SvgDocument *document, cairo_t *cr);
SvgElement *svg_document_hit(SvgDocument *document, gdouble x, gdouble y);


G_END_DECLS

#endif /* __SVG_DOCUMENT_H__ */
