/*
 * svg-rect.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_RECT_H__
#define __SVG_RECT_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_RECT            (svg_rect_get_type())
#define SVG_RECT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_RECT, SvgRect))
#define SVG_RECT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_RECT, SvgRectClass))
#define SVG_IS_RECT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_RECT))
#define SVG_IS_RECT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_RECT))
#define SVG_RECT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_RECT, SvgRectClass))

typedef struct _SvgRect SvgRect;
typedef struct _SvgRectClass SvgRectClass;

struct _SvgRect {
	GObject parent_instance;

    double x;
    double y;
    double width;
    double height;
};

struct _SvgRectClass {
	GObjectClass parent_class;
};

GType svg_rect_get_type(void) G_GNUC_CONST;
SvgRect *svg_rect_new();

G_END_DECLS

#endif /* __SVG_RECT_H__ */

