/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-style.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <liblog/log.h>

#include <string.h>

#include <libgraphics/graphics.h>

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-paint.h"
#include "svg-length.h"
#include "svg-animated.h"
#include "svg-animated-type.h"
#include "svg-animated-type-animator.h"
#include "svg-animated-length.h"
#include "svg-css.h"
#include "svg-style.h"
#include "svg-parser.h"

static void svg_style_class_init(SvgStyleClass *klass);
static void svg_style_init(SvgStyle *gobject);

G_DEFINE_TYPE (SvgStyle, svg_style, G_TYPE_OBJECT)

static void
svg_style_init (SvgStyle *object)
{
    object->fill_paint            = NULL;

    object->stroke_paint          = NULL;
    object->stroke_width          = svg_animated_length_new();
    object->stroke_width->baseVal = svg_length_new_height();
    object->stroke_width->animVal = svg_length_new_height();
}

static void
svg_style_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (svg_style_parent_class)->finalize (object);
}

static void
svg_style_class_init(SvgStyleClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = svg_style_finalize;

//	svg_style_parent_class = g_type_class_peek_parent (klass);
}

SvgStyle *
svg_style_new (void)
{
	return g_object_new (svg_style_get_type (),
	                     NULL);
}

SvgPaint*
svg_style_get_fill(SvgStyle *style)
{
    if (!style->fill_paint) {
        style->fill_paint = svg_paint_new();
    }
    return style->fill_paint;
}

SvgPaint*
svg_style_get_stroke(SvgStyle *style)
{
    if (!style->stroke_paint) {
        style->stroke_paint = svg_paint_new();
    }
    return style->stroke_paint;
}

/* svg_css_set_style_property(SvgStyle*style, id, value) */
/* svg_style_set_property(SvgStyle*style, id, value, context) */
gboolean svg_style_set_property(SvgStyle *style, guchar *name, guchar *value/*, SvgElement *context*/)
{
    SvgCssPropertyName id;
    GEnumClass *enum_class = g_type_class_ref (svg_css_property_name_get_type());// FIXME: memory
    GEnumValue* enum_value = g_enum_get_value_by_nick(enum_class, name);
    if (!enum_value) {
        g_debug("property not registered '%s'\n", name);
        return FALSE;
    }
    id = enum_value->value;

    switch (id)
    {
    case  SVG_CSS_PROPERTY_BACKGROUND_ATTACHMENT:
    break;
    case  SVG_CSS_PROPERTY_BACKGROUND_CLIP:
    break;
    case  SVG_CSS_PROPERTY_BACKGROUND_COLOR:
    break;
    case  SVG_CSS_PROPERTY_BACKGROUND_IMAGE:
    break;
    case  SVG_CSS_PROPERTY_BACKGROUND_ORIGIN:
    break;
    case  SVG_CSS_PROPERTY_BACKGROUND_POSITION:
    break;
    case  SVG_CSS_PROPERTY_BACKGROUND_REPEAT:
    break;
    case  SVG_CSS_PROPERTY_BACKGROUND_SIZE:
    break;
    case  SVG_CSS_PROPERTY_BORDER_BOTTOM_COLOR:
    break;
    case  SVG_CSS_PROPERTY_BORDER_BOTTOM_LEFT_RADIUS:
    break;
    case  SVG_CSS_PROPERTY_BORDER_BOTTOM_RIGHT_RADIUS:
    break;
    case  SVG_CSS_PROPERTY_BORDER_BOTTOM_STYLE:
    break;
    case  SVG_CSS_PROPERTY_BORDER_BOTTOM_WIDTH:
    break;
    case  SVG_CSS_PROPERTY_BORDER_COLLAPSE:
    break;
    case  SVG_CSS_PROPERTY_BORDER_IMAGE_OUTSET:
    break;
    case  SVG_CSS_PROPERTY_BORDER_IMAGE_REPEAT:
    break;
    case  SVG_CSS_PROPERTY_BORDER_IMAGE_SLICE:
    break;
    case  SVG_CSS_PROPERTY_BORDER_IMAGE_SOURCE:
    break;
    case  SVG_CSS_PROPERTY_BORDER_IMAGE_WIDTH:
    break;
    case  SVG_CSS_PROPERTY_BORDER_LEFT_COLOR:
    break;
    case  SVG_CSS_PROPERTY_BORDER_LEFT_STYLE:
    break;
    case  SVG_CSS_PROPERTY_BORDER_LEFT_WIDTH:
    break;
    case  SVG_CSS_PROPERTY_BORDER_RIGHT_COLOR:
    break;
    case  SVG_CSS_PROPERTY_BORDER_RIGHT_STYLE:
    break;
    case  SVG_CSS_PROPERTY_BORDER_RIGHT_WIDTH:
    break;
    case  SVG_CSS_PROPERTY_BORDER_TOP_COLOR:
    break;
    case  SVG_CSS_PROPERTY_BORDER_TOP_LEFT_RADIUS:
    break;
    case  SVG_CSS_PROPERTY_BORDER_TOP_RIGHT_RADIUS:
    break;
    case  SVG_CSS_PROPERTY_BORDER_TOP_STYLE:
    break;
    case  SVG_CSS_PROPERTY_BORDER_TOP_WIDTH:
    break;
    case  SVG_CSS_PROPERTY_BOTTOM:
    break;
    case  SVG_CSS_PROPERTY_BOX_SHADOW:
    break;
    case  SVG_CSS_PROPERTY_BOX_SIZING:
    break;
    case  SVG_CSS_PROPERTY_CAPTION_SIDE:
    break;
    case  SVG_CSS_PROPERTY_CLEAR:
    break;
    case  SVG_CSS_PROPERTY_CLIP:
    break;
    case  SVG_CSS_PROPERTY_COLOR:
    break;
    case  SVG_CSS_PROPERTY_CURSOR:
    break;
    case  SVG_CSS_PROPERTY_DIRECTION:
    break;
    case  SVG_CSS_PROPERTY_DISPLAY:
    break;
    case  SVG_CSS_PROPERTY_EMPTY_CELLS:
    break;
    case  SVG_CSS_PROPERTY_FLOAT:
    break;
    case  SVG_CSS_PROPERTY_FONT_FAMILY:
    break;
    case  SVG_CSS_PROPERTY_FONT_SIZE:
    break;
    case  SVG_CSS_PROPERTY_FONT_STYLE:
    break;
    case  SVG_CSS_PROPERTY_FONT_VARIANT:
    break;
    case  SVG_CSS_PROPERTY_FONT_WEIGHT:
    break;
    case  SVG_CSS_PROPERTY_HEIGHT:
    break;
    case  SVG_CSS_PROPERTY_IMAGE_ORIENTATION:
    break;
    case  SVG_CSS_PROPERTY_IMAGE_RENDERING:
    break;
    case  SVG_CSS_PROPERTY_IMAGE_RESOLUTION:
    break;
    case  SVG_CSS_PROPERTY_LEFT:
    break;
    case  SVG_CSS_PROPERTY_LETTER_SPACING:
    break;
    case  SVG_CSS_PROPERTY_LINE_HEIGHT:
    break;
    case  SVG_CSS_PROPERTY_LIST_STYLE_IMAGE:
    break;
    case  SVG_CSS_PROPERTY_LIST_STYLE_POSITION:
    break;
    case  SVG_CSS_PROPERTY_LIST_STYLE_TYPE:
    break;
    case  SVG_CSS_PROPERTY_MARGIN_BOTTOM:
    break;
    case  SVG_CSS_PROPERTY_MARGIN_LEFT:
    break;
    case  SVG_CSS_PROPERTY_MARGIN_RIGHT:
    break;
    case  SVG_CSS_PROPERTY_MARGIN_TOP:
    break;
    case  SVG_CSS_PROPERTY_MAX_HEIGHT:
    break;
    case  SVG_CSS_PROPERTY_MAX_WIDTH:
    break;
    case  SVG_CSS_PROPERTY_MIN_HEIGHT:
    break;
    case  SVG_CSS_PROPERTY_MIN_WIDTH:
    break;
    case  SVG_CSS_PROPERTY_OPACITY:
    break;
    case  SVG_CSS_PROPERTY_ORPHANS:
    break;
    case  SVG_CSS_PROPERTY_OUTLINE_COLOR:
    break;
    case  SVG_CSS_PROPERTY_OUTLINE_OFFSET:
    break;
    case  SVG_CSS_PROPERTY_OUTLINE_STYLE:
    break;
    case  SVG_CSS_PROPERTY_OUTLINE_WIDTH:
    break;
    case  SVG_CSS_PROPERTY_OVERFLOW_WRAP:
    break;
    case  SVG_CSS_PROPERTY_OVERFLOW_X:
    break;
    case  SVG_CSS_PROPERTY_OVERFLOW_Y:
    break;
    case  SVG_CSS_PROPERTY_PADDING_BOTTOM:
    break;
    case  SVG_CSS_PROPERTY_PADDING_LEFT:
    break;
    case  SVG_CSS_PROPERTY_PADDING_RIGHT:
    break;
    case  SVG_CSS_PROPERTY_PADDING_TOP:
    break;
    case  SVG_CSS_PROPERTY_PAGE_BREAK_AFTER:
    break;
    case  SVG_CSS_PROPERTY_PAGE_BREAK_BEFORE:
    break;
    case  SVG_CSS_PROPERTY_PAGE_BREAK_INSIDE:
    break;
    case  SVG_CSS_PROPERTY_POINTER_EVENTS:
    break;
    case  SVG_CSS_PROPERTY_POSITION:
    break;
    case  SVG_CSS_PROPERTY_RESIZE:
    break;
    case  SVG_CSS_PROPERTY_RIGHT:
    break;
    case  SVG_CSS_PROPERTY_SPEAK:
    break;
    case  SVG_CSS_PROPERTY_TABLE_LAYOUT:
    break;
    case  SVG_CSS_PROPERTY_TAB_SIZE:
    break;
    case  SVG_CSS_PROPERTY_TEXT_ALIGN:
    break;
    case  SVG_CSS_PROPERTY_TEXT_DECORATION:
    break;
    case  SVG_CSS_PROPERTY_TEXT_INDENT:
    break;
    case  SVG_CSS_PROPERTY_TEXT_RENDERING:
    break;
    case  SVG_CSS_PROPERTY_TEXT_SHADOW:
    break;
    case  SVG_CSS_PROPERTY_TEXT_OVERFLOW:
    break;
    case  SVG_CSS_PROPERTY_TEXT_TRANSFORM:
    break;
    case  SVG_CSS_PROPERTY_TOP:
    break;
    case  SVG_CSS_PROPERTY_TRANSITION:
    break;
    case  SVG_CSS_PROPERTY_TRANSITION_DELAY:
    break;
    case  SVG_CSS_PROPERTY_TRANSITION_DURATION:
    break;
    case  SVG_CSS_PROPERTY_TRANSITION_PROPERTY:
    break;
    case  SVG_CSS_PROPERTY_TRANSITION_TIMING_FUNCTION:
    break;
    case  SVG_CSS_PROPERTY_UNICODE_BIDI:
    break;
    case  SVG_CSS_PROPERTY_VERTICAL_ALIGN:
    break;
    case  SVG_CSS_PROPERTY_VISIBILITY:
    break;
    case  SVG_CSS_PROPERTY_WHITE_SPACE:
    break;
    case  SVG_CSS_PROPERTY_WIDOWS:
    break;
    case  SVG_CSS_PROPERTY_WIDTH:
    break;
    case  SVG_CSS_PROPERTY_WORD_BREAK:
    break;
    case  SVG_CSS_PROPERTY_WORD_SPACING:
    break;
    case  SVG_CSS_PROPERTY_WORD_WRAP:
    break;
    case  SVG_CSS_PROPERTY_ZINDEX:
    break;
    case  SVG_CSS_PROPERTY_ZOOM:
    break;
    case  SVG_CSS_PROPERTY_BUFFERED_RENDERING:
    break;
    case  SVG_CSS_PROPERTY_CLIP_PATH:
    break;
    case  SVG_CSS_PROPERTY_CLIP_RULE:
    break;
    case  SVG_CSS_PROPERTY_MASK:
    break;
    case  SVG_CSS_PROPERTY_FILTER:
    break;
    case  SVG_CSS_PROPERTY_FLOOD_COLOR:
    break;
    case  SVG_CSS_PROPERTY_FLOOD_OPACITY:
    break;
    case  SVG_CSS_PROPERTY_LIGHTING_COLOR:
    break;
    case  SVG_CSS_PROPERTY_STOP_COLOR:
    break;
    case  SVG_CSS_PROPERTY_STOP_OPACITY:
    break;
    case  SVG_CSS_PROPERTY_COLOR_INTERPOLATION:
    break;
    case  SVG_CSS_PROPERTY_COLOR_INTERPOLATION_FILTERS:
    break;
    case  SVG_CSS_PROPERTY_COLOR_RENDERING:
    break;
    case  SVG_CSS_PROPERTY_FILL:
    {
        SvgPaint* paint = svg_style_get_fill(style);
        gchar* success = svg_parser_parse_paint(paint, (gchar*) value);//fill:url(#myId)
        if (!success) {
            return FALSE;
        }
        return TRUE;
    }
    case  SVG_CSS_PROPERTY_FILL_OPACITY:
    {
        gdouble number;
        svg_parser_parse_double(value, value+strlen(value), &number, FALSE);
        svg_paint_set_opacity(style->fill_paint, number);
        return TRUE;
    }
    break;
    case  SVG_CSS_PROPERTY_FILL_RULE:
    break;
    case  SVG_CSS_PROPERTY_MARKER_END:
    break;
    case  SVG_CSS_PROPERTY_MARKER_MID:
    break;
    case  SVG_CSS_PROPERTY_MARKER_START:
    break;
    case  SVG_CSS_PROPERTY_MASK_TYPE:
    break;
    case  SVG_CSS_PROPERTY_SHAPE_RENDERING:
    break;
    case  SVG_CSS_PROPERTY_STROKE:
    {
        SvgPaint* paint = svg_style_get_stroke(style);
        gchar* success = svg_parser_parse_paint(paint, (gchar*)value);
        if (!success) {
            return FALSE;
        }
        return TRUE;
    }
    case  SVG_CSS_PROPERTY_STROKE_DASHARRAY:
    break;
    case  SVG_CSS_PROPERTY_STROKE_DASHOFFSET:
    break;
    case  SVG_CSS_PROPERTY_STROKE_LINECAP:
    break;
    case  SVG_CSS_PROPERTY_STROKE_LINEJOIN:
    break;
    case  SVG_CSS_PROPERTY_STROKE_MITERLIMIT:
    break;
    case  SVG_CSS_PROPERTY_STROKE_OPACITY:
    {
        gdouble number;
        svg_parser_parse_double(value, value+strlen(value), &number, FALSE);
        svg_paint_set_opacity(style->stroke_paint, number);
        return TRUE;
    }
    break;
    case  SVG_CSS_PROPERTY_STROKE_WIDTH:
    {
        svg_length_set_value_from_string(style->stroke_width->baseVal, value, value+strlen(value));
        return TRUE;
    }
    case  SVG_CSS_PROPERTY_ALIGNMENT_BASELINE:
    break;
    case  SVG_CSS_PROPERTY_BASELINE_SHIFT:
    break;
    case  SVG_CSS_PROPERTY_DOMINANT_BASELINE:
    break;
    case  SVG_CSS_PROPERTY_KERNING:
    break;
    case  SVG_CSS_PROPERTY_TEXT_ANCHOR:
    break;
    case  SVG_CSS_PROPERTY_WRITING_MODE:
    break;
    case  SVG_CSS_PROPERTY_GLYPH_ORIENTATION_HORIZONTAL:
    break;
    case  SVG_CSS_PROPERTY_GLYPH_ORIENTATION_VERTICAL:
    break;
    case  SVG_CSS_PROPERTY_VECTOR_EFFECT:
    break;
    default:
        g_message("Bad ID: CSS Attribute not recognized %d/\"%s\"\n", id, name);
        return FALSE;
    break;
    }
    g_debug("Not implemented: CSS Attribute \"%s\" not reached\n", name);
    return FALSE;
}
