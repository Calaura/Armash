/*
 * svg-length.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <libgraphics/graphics.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-box.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-length.h"
#include "svg-parser.h"
#include "svg-rect.h"
#include "svg-locatable.h"

#include <math.h>
#include <string.h>

enum {
        CHANGED,
        LAST_SIGNAL
};
static guint svg_length_signals[LAST_SIGNAL] = { 0 };

static void svg_length_class_init(SvgLengthClass *klass);
static void svg_length_init(SvgLength *length);

G_DEFINE_TYPE (SvgLength, svg_length, G_TYPE_OBJECT)


static void
svg_length_class_init(SvgLengthClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    svg_length_signals[CHANGED] =
                    g_signal_new ("changed",
                                    G_TYPE_FROM_CLASS (klass),
                                    G_SIGNAL_RUN_LAST | G_SIGNAL_NO_RECURSE | G_SIGNAL_NO_HOOKS,
                                    NULL,
                                    NULL,
                                    NULL,
                                    g_cclosure_marshal_VOID__VOID,
                                    G_TYPE_NONE,
                                    0,
                                    NULL);

//	svg_length_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_length_init (SvgLength *length)
{
    length->value = 0.0;
    length->unit  = SVG_LENGTH_MODE_OTHER << 4 | SVG_LENGTH_TYPE_UNKNOW;
    length->empty = TRUE;
}

SvgLength *
svg_length_new (void)
{
    return g_object_new (svg_length_get_type (),
                         NULL);
}

SvgLength *
svg_length_new_width (void)
{
    SvgLength *length;
    length = g_object_new (svg_length_get_type (), NULL);
    length->unit  = SVG_LENGTH_MODE_WIDTH << 4 | SVG_LENGTH_TYPE_UNKNOW;

    return length;
}

SvgLength *
svg_length_new_height (void)
{
    SvgLength *length;
    length = g_object_new (svg_length_get_type (), NULL);
    length->unit  = SVG_LENGTH_MODE_HEIGHT << 4 | SVG_LENGTH_TYPE_UNKNOW;

    return length;
}

void
svg_length_set_value(SvgLength *length, double value, guint unit, gboolean empty)
{
    length->value = value;
    length->unit  = unit;
    length->empty = empty;
    g_signal_emit(length, svg_length_signals[CHANGED], 0);
}

/* todo assume end==-1
 * end = ptr+strlen(ptr)
 */
gboolean svg_length_set_value_from_string(SvgLength* length, gchar* ptr, gchar *end/*, ExceptionCode& ec*/)
{
    double number = 0;
    gchar *token;
    token = svg_parser_parse_double(ptr, end, &number, FALSE);

    if (!token) {
        /*ec = SYNTAX_ERR;*/
        return FALSE;
    }

    SvgLengthType type = svg_parser_parse_length_type(token, end);
    /*ASSERT(ptr <= end);*/
    if (type == SVG_LENGTH_TYPE_UNKNOW) {
        /*ec = SYNTAX_ERR;*/
        return FALSE;
    }

    length->unit = SVG_LENGTH_SET_TYPE(length, type);
    length->value = number;

    g_signal_emit(length, svg_length_signals[CHANGED], 0);
    return TRUE;
}

static gboolean svg_length_context_determineViewport(SvgElement *context, gdouble *width, gdouble *height)
{
    /*
    SvgRect *rect = svg_locatable_get_bbox(context);
    *width  = rect->width;
    *height = rect->height;
    */


    //GeomBox *gbb = graphics_path_get_bounding_box(RENDERER_SHAPE(renderer)->path);
    RendererObject *renderer = context->private_member->renderer;
    RendererObject *tmp = renderer->scene->target;
    renderer->scene->target = renderer;
    RendererBox *bb = renderer_view_bounding_box(renderer->scene->view, RENDERER_BOUNDING_PATH_MODE || RENDERER_BOUNDING_TRANSFORM_FLAG);
    renderer->scene->target = tmp;

    *width  = bb->right - bb->left;
    *height = bb->top - bb->bottom;

    return TRUE;
}

/*
bool SVGLengthContext::determineViewport(float& width, float& height) const
{
    if (!m_context)
        return false;

    // If an overriden viewport is given, it has precedence.
    if (!m_overridenViewport.isEmpty()) {
        width = m_overridenViewport.width();
        height = m_overridenViewport.height();
        return true;
    }

    // SVGLengthContext should NEVER be used to resolve width/height values for <svg> elements,
    // as they require special treatment, due the relationship with the CSS width/height properties.
    ASSERT(m_context->document()->documentElement() != m_context);

    // Take size from nearest viewport element.
    SVGElement* viewportElement = m_context->viewportElement();
    if (!viewportElement || !viewportElement->isSVG())
        return false;

    const SVGSVGElement* svg = static_cast<const SVGSVGElement*>(viewportElement);
    FloatSize viewportSize = svg->currentViewBoxRect().size();
    if (viewportSize.isEmpty())
        viewportSize = svg->currentViewportSize();

    width = viewportSize.width();
    height = viewportSize.height();
    return true;
}
*/

static gdouble svg_length_context_convertValueFromPercentageToUserUnits(SvgElement *context, SvgLength *length)
{
    gdouble width = 0;
    gdouble height = 0;
    gdouble value = 0.0;
    SvgLengthMode mode = SVG_LENGTH_GET_MODE(length);

    svg_length_context_determineViewport(context, &width, &height);


    switch (mode) {
    case SVG_LENGTH_MODE_WIDTH:
        return width * length->value / 100.0;
    case SVG_LENGTH_MODE_HEIGHT:
        return height * length->value / 100.0;
    case SVG_LENGTH_MODE_OTHER:
        return value * sqrt((width * width + height * height) / 2.0);
    };

    return value;
}

/*float SVGLengthContext::convertValueFromPercentageToUserUnits(float value, SVGLengthMode mode, ExceptionCode& ec) const
{
    float width = 0;
    float height = 0;
    if (!determineViewport(width, height)) {
        ec = NOT_SUPPORTED_ERR;
        return 0;
    }

    switch (mode) {
    case LengthModeWidth:
        return value * width;
    case LengthModeHeight:
        return value * height;
    case LengthModeOther:
        return value * sqrtf((width * width + height * height) / 2);
    };

    ASSERT_NOT_REACHED();
    return 0;
}*/

double svg_length_get_value(SvgLength *length, SvgElement *context)
{
    gdouble value = 0;
    if (!length)
        return 0;

    SvgLengthType unit = SVG_LENGTH_GET_TYPE(length);

    switch(unit){
    case SVG_LENGTH_TYPE_PERCENTAGE:
        return svg_length_context_convertValueFromPercentageToUserUnits(context, length);
        break;
    case SVG_LENGTH_TYPE_UNKNOW:
    case SVG_LENGTH_TYPE_NUMBER:
    //case SVG_LENGTH_TYPE_PERCENTAGE:
    case SVG_LENGTH_TYPE_EMS:
    case SVG_LENGTH_TYPE_EXS:
    case SVG_LENGTH_TYPE_PX:
        return length->value;
    case SVG_LENGTH_TYPE_CM:
    case SVG_LENGTH_TYPE_MM:
    case SVG_LENGTH_TYPE_IN:
    case SVG_LENGTH_TYPE_PT:
    case SVG_LENGTH_TYPE_PC:
    default:
        break;
    }

    return value;
}
/*

float SVGLength::value(const SVGLengthContext& context, ExceptionCode& ec) const
{
    return context.convertValueToUserUnits(m_valueInSpecifiedUnits, extractMode(m_unit), extractType(m_unit), ec);
}
*/

/*
float SVGLengthContext::convertValueToUserUnits(float value, SVGLengthMode mode, SVGLengthType fromUnit, ExceptionCode& ec) const
{
    // If the SVGLengthContext carries a custom viewport, force resolving against it.
    if (!m_overridenViewport.isEmpty()) {
        // 100% = 100.0 instead of 1.0 for historical reasons, this could eventually be changed
        if (fromUnit == LengthTypePercentage)
            value /= 100;
        return convertValueFromPercentageToUserUnits(value, mode, ec);
    }

    switch (fromUnit) {
    case LengthTypeUnknown:
        ec = NOT_SUPPORTED_ERR;
        return 0;
    case LengthTypeNumber:
        return value;
    case LengthTypePX:
        return value;
    case LengthTypePercentage:
        return convertValueFromPercentageToUserUnits(value / 100, mode, ec);
    case LengthTypeEMS:
        return convertValueFromEMSToUserUnits(value, ec);
    case LengthTypeEXS:
        return convertValueFromEXSToUserUnits(value, ec);
    case LengthTypeCM:
        return value * cssPixelsPerInch / 2.54f;
    case LengthTypeMM:
        return value * cssPixelsPerInch / 25.4f;
    case LengthTypeIN:
        return value * cssPixelsPerInch;
    case LengthTypePT:
        return value * cssPixelsPerInch / 72;
    case LengthTypePC:
        return value * cssPixelsPerInch / 6;
    }

    ASSERT_NOT_REACHED();
    return 0;
}
*/


gchar* svg_length_type_to_string(SvgLengthType type)
{
    switch (type) {
    case SVG_LENGTH_TYPE_UNKNOW:
    case SVG_LENGTH_TYPE_NUMBER:
        return "";
    case SVG_LENGTH_TYPE_PERCENTAGE:
        return "%";
    case SVG_LENGTH_TYPE_EMS:
        return "em";
    case SVG_LENGTH_TYPE_EXS:
        return "ex";
    case SVG_LENGTH_TYPE_PX:
        return "px";
    case SVG_LENGTH_TYPE_CM:
        return "cm";
    case SVG_LENGTH_TYPE_MM:
        return "mm";
    case SVG_LENGTH_TYPE_IN:
        return "in";
    case SVG_LENGTH_TYPE_PT:
        return "pt";
    case SVG_LENGTH_TYPE_PC:
        return "pc";
    }

    g_message("Unknow SvgLengthType %d\n", type);
    return "";
}

gchar* svg_length_to_string(SvgLength* length)
{
    return g_strdup_printf("%g%s", length->value, svg_length_type_to_string(SVG_LENGTH_GET_TYPE(length)));
}
