/*
 * svg-element-style.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>
#include <liblog/log.h>
#include <librenderer/renderer.h>
#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-element.h"
#include "svg-element-style.h"


#define SVG_ELEMENT_STYLE_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), SVG_TYPE_ELEMENT_STYLE, SvgElementStylePrivate))
struct _SvgElementStylePrivate {
	int foo;
};


static void svg_element_style_class_init(SvgElementStyleClass *klass);
static void svg_element_style_init(SvgElementStyle *gobject);

G_DEFINE_TYPE (SvgElementStyle, svg_element_style, SVG_TYPE_ELEMENT)

static void
svg_element_style_class_init(SvgElementStyleClass *klass)
{
	SvgElementClass *svgelement_class;

	svgelement_class = (SvgElementClass *) klass;

    g_type_class_add_private(klass, sizeof(SvgElementStylePrivate));
//	svg_element_style_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_style_init (SvgElementStyle *object)
{
	SvgElementStylePrivate *priv = SVG_ELEMENT_STYLE_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

SvgElementStyle *
svg_element_style_new (void)
{
	return g_object_new (svg_element_style_get_type (),
	                     NULL);
}

