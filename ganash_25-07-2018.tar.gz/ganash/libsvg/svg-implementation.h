/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-implementation.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_IMPLEMENTATION_H__
#define __SVG_IMPLEMENTATION_H__


G_BEGIN_DECLS

#define SVG_TYPE_IMPLEMENTATION            (svg_implementation_get_type())
#define SVG_IMPLEMENTATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_IMPLEMENTATION, SvgImplementation))
#define SVG_IMPLEMENTATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_IMPLEMENTATION, SvgImplementationClass))
#define SVG_IS_IMPLEMENTATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_IMPLEMENTATION))
#define SVG_IS_IMPLEMENTATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_IMPLEMENTATION))
#define SVG_IMPLEMENTATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_IMPLEMENTATION, SvgImplementationClass))

typedef struct _SvgImplementation SvgImplementation;
typedef struct _SvgImplementationClass SvgImplementationClass;

struct _SvgImplementation {
	GObject parent_instance;
};

struct _SvgImplementationClass {
	GObjectClass parent_class;
};

GType svg_implementation_get_type();
SvgImplementation *svg_implementation_new();

G_END_DECLS

#endif /* __SVG_IMPLEMENTATION_H__ */

