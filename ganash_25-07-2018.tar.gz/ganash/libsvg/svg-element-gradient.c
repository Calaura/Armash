/*
 * svg-element-gradient.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <liblog/log.h>


#include <libgraphics/graphics.h>



#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-color.h"
#include "svg-color-icc.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-parser.h"
#include "svg-document.h"

#include "svg-element-gradient.h"

static int             svg_element_gradient_init_from_xml(DomNode *element, xmlNode* node);
static gboolean        svg_element_gradient_parse_attribute(SvgElement *element, DomQualifiedName* name, guchar* value);

static RendererObject* svg_element_gradient_get_renderer(SvgElement *element);


static void svg_element_gradient_class_init(SvgElementGradientClass *klass);
static void svg_element_gradient_init(SvgElementGradient *gobject);

G_DEFINE_TYPE (SvgElementGradient, svg_element_gradient, SVG_TYPE_ELEMENT)

#define parent_class svg_element_gradient_parent_class

static void
svg_element_gradient_class_init(SvgElementGradientClass *klass)
{
    DomNodeClass *dom_class;
    SvgElementClass *svgelement_class;

    dom_class  = (DomNodeClass *) klass;
    svgelement_class = (SvgElementClass *) klass;

    dom_class->init_from_xml          = svg_element_gradient_init_from_xml;
    svgelement_class->parse_attribute        = svg_element_gradient_parse_attribute;
    /*svgelement_class->private_class->get_renderer = svg_element_gradient_get_renderer;*/

    //svg_element_gradient_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_element_gradient_init (SvgElementGradient *object)
{
    object->transform     = NULL;
    object->spread_method = SVG_SPREAD_METHOD_TYPE_PAD;
    object->units         = SVG_UNIT_TYPE_USERSPACEONUSE;
}

static int
svg_element_gradient_init_from_xml(DomNode* element, xmlNode* node)
{
    return DOM_NODE_CLASS(parent_class)->init_from_xml(element, node);
}

static gboolean svg_element_gradient_parse_attribute(SvgElement *element, DomQualifiedName *qualified_name, guchar* value)
{
    g_return_if_fail(SVG_IS_ELEMENT_GRADIENT(element));
    SvgElementGradient *gradient = SVG_ELEMENT_GRADIENT(element);


    if        (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "gradientunits"))) {
        GEnumClass *enum_class = g_type_class_ref (svg_unit_get_type());
        GEnumValue* enum_value = g_enum_get_value_by_nick(enum_class, value);
        if (enum_value) {
            gradient->units = enum_value->value;
        } else {
            g_message("Error: <ElementGradient> gradientUnit not recognized");
        }
    //} else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "gradienttransform"))) {
        /*TODO parse transform(), */
    } else if (dom_qualified_name_equ(qualified_name, &DOM_QUALIFIED_NAME("svg", "spreadmethod"))) {
        GEnumClass *enum_class = g_type_class_ref (svg_spread_method_get_type());
        gchar* lvalue = g_ascii_strdown(value, -1);
        GEnumValue* enum_value = g_enum_get_value_by_nick(enum_class, lvalue);
        g_free(lvalue);
        if (enum_value) {
            gradient->spread_method = enum_value->value;
        } else {
            g_message("Error: <ElementGradient> spreadmethod not recognized");
        }
    } else if (SVG_ELEMENT_CLASS(parent_class)->parse_attribute(element, qualified_name, value)) {
    } else {
        return FALSE;
    }

    return TRUE;
}

static RendererObject*
svg_element_gradient_get_renderer(SvgElement *element)
{
    return NULL;
}
