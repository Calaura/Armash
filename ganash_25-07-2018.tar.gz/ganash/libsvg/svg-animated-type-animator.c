/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-animated-type-animator.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-animated-type.h"
#include "svg-animated-type-animator.h"


#define SVG_ANIMATED_TYPE_ANIMATOR_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), SVG_TYPE_ANIMATED_TYPE_ANIMATOR, SvgAnimatedTypeAnimatorPrivate))
struct _SvgAnimatedTypeAnimatorPrivate {
	int foo;
};

/* @return gpointer<SvgAnimatedType>*/
static gpointer svg_animated_type_animator_default_construct_from_string      (SvgAnimatedTypeAnimator *animator, gchar *String);
/* @return gpointer<SvgAnimatedType>*/
static gpointer svg_animated_type_animator_default_start_anim_val_animation   (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
static void     svg_animated_type_animator_default_stop_anim_val_animation    (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
static void     svg_animated_type_animator_default_reset_anim_val_to_base_val (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list, SvgAnimatedType*type);
static void     svg_animated_type_animator_default_anim_val_will_change       (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
static void     svg_animated_type_animator_default_anim_val_did_change        (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list);
static void     svg_animated_type_animator_default_add_animated_types         (SvgAnimatedTypeAnimator *animator, SvgAnimatedType* type1, SvgAnimatedType *type2);
static void     svg_animated_type_animator_default_calculate_animated_value   (SvgAnimatedTypeAnimator *animator, float percentage, unsigned repeatCount, SvgAnimatedType*type1, SvgAnimatedType*type2, SvgAnimatedType*type3, SvgAnimatedType*type4);
static float    svg_animated_type_animator_default_calculate_distance         (SvgAnimatedTypeAnimator *animator, gchar* fromString, gchar* toString);


static void svg_animated_type_animator_class_init(SvgAnimatedTypeAnimatorClass *klass);
static void svg_animated_type_animator_init(SvgAnimatedTypeAnimator *gobject);

G_DEFINE_TYPE (SvgAnimatedTypeAnimator, svg_animated_type_animator, G_TYPE_OBJECT)

static void
svg_animated_type_animator_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (svg_animated_type_animator_parent_class)->finalize (object);
}
static void
svg_animated_type_animator_class_init(SvgAnimatedTypeAnimatorClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;


    klass->construct_from_string      = svg_animated_type_animator_default_construct_from_string;
    klass->start_anim_val_animation   = svg_animated_type_animator_default_start_anim_val_animation;
    klass->stop_anim_val_animation    = svg_animated_type_animator_default_stop_anim_val_animation;
    klass->reset_anim_val_to_base_val = svg_animated_type_animator_default_reset_anim_val_to_base_val;
    klass->anim_val_will_change       = svg_animated_type_animator_default_anim_val_will_change;
    klass->anim_val_did_change        = svg_animated_type_animator_default_anim_val_did_change;
    klass->add_animated_types         = svg_animated_type_animator_default_add_animated_types;
    klass->calculate_animated_value   = svg_animated_type_animator_default_calculate_animated_value;
    klass->calculate_distance         = svg_animated_type_animator_default_calculate_distance;


	gobject_class->finalize = svg_animated_type_animator_finalize;

    g_type_class_add_private(klass, sizeof(SvgAnimatedTypeAnimatorPrivate));
//	svg_animated_type_animator_parent_class = g_type_class_peek_parent (klass);
}

static void
svg_animated_type_animator_init (SvgAnimatedTypeAnimator *object)
{
	SvgAnimatedTypeAnimatorPrivate *priv = SVG_ANIMATED_TYPE_ANIMATOR_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

/* @return gpointer<SvgAnimatedType>*/
static gpointer svg_animated_type_animator_default_construct_from_string      (SvgAnimatedTypeAnimator *animator, gchar *String)
{
    return NULL;
}

/* @return gpointer<SvgAnimatedType>*/
static gpointer svg_animated_type_animator_default_start_anim_val_animation   (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list)
{

    return NULL;
}

static void     svg_animated_type_animator_default_stop_anim_val_animation    (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list)
{

}

static void     svg_animated_type_animator_default_reset_anim_val_to_base_val (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list, SvgAnimatedType*type)
{

}

static void     svg_animated_type_animator_default_anim_val_will_change       (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list)
{

}

static void     svg_animated_type_animator_default_anim_val_did_change        (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list)
{

}

static void     svg_animated_type_animator_default_add_animated_types         (SvgAnimatedTypeAnimator *animator, SvgAnimatedType* type1, SvgAnimatedType *type2)
{

}

static void     svg_animated_type_animator_default_calculate_animated_value   (SvgAnimatedTypeAnimator *animator, float percentage, unsigned repeatCount, SvgAnimatedType*type1, SvgAnimatedType*type2, SvgAnimatedType*type3, SvgAnimatedType*type4)
{

}

static float    svg_animated_type_animator_default_calculate_distance         (SvgAnimatedTypeAnimator *animator, gchar* fromString, gchar* toString)
{

}

SvgAnimatedTypeAnimator *
svg_animated_type_animator_new (void)
{
	return g_object_new (svg_animated_type_animator_get_type (),
	                     NULL);
}

//------------------------------------------------------------------------------
SvgElementAnimatedProperties*
svg_element_animated_properties_new(SvgElement *element, GArray *properties)
{
    SvgElementAnimatedProperties* object = g_new(SvgElementAnimatedProperties, 1);
    object->element = element;
    object->properties = properties;

    return object;
}
//------------------------------------------------------------------------------

/* @return gpointer<SvgAnimatedType>*/
gpointer svg_animated_type_animator_construct_from_string      (SvgAnimatedTypeAnimator *animator, gchar *String)
{
    SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(animator)->construct_from_string(animator, String);
}

/* @return gpointer<SvgAnimatedType>*/
gpointer svg_animated_type_animator_start_anim_val_animation   (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list)
{
    SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(animator)->start_anim_val_animation(animator, list);
}

void     svg_animated_type_animator_stop_anim_val_animation    (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list)
{
    SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(animator)->stop_anim_val_animation(animator, list);
}

void     svg_animated_type_animator_reset_anim_val_to_base_val (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list, SvgAnimatedType*type)
{
    SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(animator)->reset_anim_val_to_base_val(animator, list, type);
}

void     svg_animated_type_animator_anim_val_will_change       (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list)
{
    SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(animator)->anim_val_will_change(animator, list);
}

void     svg_animated_type_animator_anim_val_did_change        (SvgAnimatedTypeAnimator *animator, SvgElementAnimatedPropertyList*list)
{
    SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(animator)->anim_val_did_change(animator, list);
}

void     svg_animated_type_animator_add_animated_types         (SvgAnimatedTypeAnimator *animator, SvgAnimatedType* type1, SvgAnimatedType *type2)
{
    SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(animator)->add_animated_types(animator, type1, type2);
}

void     svg_animated_type_animator_calculate_animated_value   (SvgAnimatedTypeAnimator *animator, float percentage, unsigned repeatCount, SvgAnimatedType*type1, SvgAnimatedType*type2, SvgAnimatedType*type3, SvgAnimatedType*type4)
{
    SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(animator)->calculate_animated_value(animator, percentage, repeatCount, type1, type2, type3, type4);
}

float    svg_animated_type_animator_calculate_distance         (SvgAnimatedTypeAnimator *animator, gchar* fromString, gchar* toString)
{
    SVG_ANIMATED_TYPE_ANIMATOR_GET_CLASS(animator)->calculate_distance(animator, fromString, toString);
}

