/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-updater.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <liblog/log.h>

#include <cairo/cairo.h>

#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-element.h"
#include "svg-element-private.h"
#include "svg-element-graphics.h"
#include "svg-updater.h"


static void svg_updater_class_init(SvgUpdaterClass *klass);
static void svg_updater_init(SvgUpdater *gobject);

G_DEFINE_TYPE (SvgUpdater, svg_updater, G_TYPE_OBJECT)


static SvgModification*
svg_modification_new(uint types, uint flags) {
    SvgModification *modification = g_new(SvgModification, 1);
    //modification->refs  = NULL;
    modification->types = types;
    modification->flags = flags;

    return modification;
}
static void
svg_modification_free(SvgModification* modification) {
    //modification->refs  = NULL;
    g_free(modification);
}
static gint
svg_modification_cmp(gconstpointer a,
                     gconstpointer b) {
    if (a>b)
        return 1;
    if (a<b)
        return -1;
    return 0;
}

static void
svg_updater_init (SvgUpdater *object)
{
    object->elements_modified = g_tree_new(svg_modification_cmp);
}

static void
svg_updater_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

    G_OBJECT_CLASS(svg_updater_parent_class)->finalize (object);
}

static void
svg_updater_class_init(SvgUpdaterClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = svg_updater_finalize;

//	svg_updater_parent_class = g_type_class_peek_parent (klass);
}

void
svg_updater_insert(SvgUpdater *updater, SvgElement *element, SvgUpdateFlags flags, uint types)
{
    SvgModification *modification = svg_modification_new(types, flags);

    switch (flags) {/*1*/
    case SVG_UPDATE_SHAPE_FLAG:/* flags && SVG_UPDATE_SHAPE_FLAG */
        set_status(element, SHAPE, MODIFIED);
        break;
    case SVG_UPDATE_TRANSFORM_FLAG:
        set_status(element, TRANSFORM, MODIFIED);
        break;
    case SVG_UPDATE_STYLE_FLAG:
        set_status(element, STYLE, MODIFIED);
        break;
    case SVG_UPDATE_GRAPHICS_FLAG:
        set_status(element, GRAPHICS, MODIFIED);
        break;
    default:
        break;
    }

    g_tree_insert(updater->elements_modified, element, modification);
}
/*
void
svg_updater_remove(SvgUpdater *updater, SvgElement *element, uint types, uint flags)
{
    SvgModification *modification = svg_modification_new(types, flags);
    g_tree_insert(updater->elements_modified, element, modification);
}
*/
void
svg_updater_run(SvgUpdater *updater, uint types, uint flags)
{

}


SvgUpdater *
svg_updater_new (void)
{
	return g_object_new (svg_updater_get_type (),
	                     NULL);
}

