/*
 * svg-time.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "svg-types.h"
#include "svg-enums.h"
#include "svg-time.h"
#include "svg-parser.h"

#include <string.h>


static double svg_time_unresolved_value = DBL_MAX;
// Just a big value smaller than DBL_MAX. Our times are relative to 0, we don't really need the full range.
static double svg_time_indefinite_value = FLT_MAX;

void
svg_time_init (SvgTime *object, gdouble seconds, SvgTimeType type, gboolean empty)
{
    object->seconds = seconds;
    object->type    = type;
    object->empty   = empty;
}

SvgTime *
svg_time_new (void)
{
    SvgTime *time = g_new(SvgTime, 1);
    svg_time_init(time, 0.0, SVG_TIME_TYPE_FULL, TRUE);
    return time;
}

void svg_time_free (SvgTime *object)
{
    g_free(object);
}

SvgTime *svg_time_new_from_string(gchar* string)
{
    SvgTime *time = svg_time_new();
    gchar token = svg_parser_parse_time(time, string, string+strlen(string));

    return time;
}

void svg_time_set_value_from_string(SvgTime *time, gchar* string)
{
    //time->seconds = 0.0;
    if (string) {
        svg_parser_parse_time(time, string, string+strlen(string));
    }
    //time->empty   = TRUE;
}

void svg_time_set_value(SvgTime *time, double seconds)
{
    time->seconds = seconds;
}

gchar * svg_time_to_string(SvgTime *time)
{
    return NULL;
}

void svg_time_set_unresolved(SvgTime *time)
{
    time->seconds = SVG_TIME_UNRESOLVED_VALUE;
}

void svg_time_set_indefinite(SvgTime *time)
{
    time->seconds = SVG_TIME_INDEFINITE_VALUE;
}

gboolean svg_time_is_finite(SvgTime *time)
{
    float seconds = time->seconds;
    return seconds < SVG_TIME_INDEFINITE_VALUE;
}
gboolean svg_time_is_indefinite(SvgTime *time)
{
    float seconds = time->seconds;
    return seconds == SVG_TIME_INDEFINITE_VALUE;
}
gboolean svg_time_is_unresolved(SvgTime *time)
{
    return time->seconds == SVG_TIME_UNRESOLVED_VALUE;
}



SvgTimeList *svg_time_list_new()
{
    GArray *times = g_array_new(FALSE, FALSE, sizeof(SvgTime));

    return (SvgTimeList*)times;
}

void svg_time_list_free(SvgTimeList *list)
{
    g_array_free((GArray*)list, TRUE);
}

void svg_time_list_set_value_from_string(SvgTimeList *times, gchar *value)
{
    gchar *ptr = value;
    gchar *end = ptr + strlen(value);

    gchar *token = svg_parser_parse_time_list(times, ptr, end);
}
