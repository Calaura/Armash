/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svg-hit-request.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVG_HIT_REQUEST_H__
#define __SVG_HIT_REQUEST_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVG_TYPE_HIT_REQUEST            (svg_hit_request_get_type())
#define SVG_HIT_REQUEST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVG_TYPE_HIT_REQUEST, SvgHitRequest))
#define SVG_HIT_REQUEST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVG_TYPE_HIT_REQUEST, SvgHitRequestClass))
#define SVG_IS_HIT_REQUEST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVG_TYPE_HIT_REQUEST))
#define SVG_IS_HIT_REQUEST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVG_TYPE_HIT_REQUEST))
#define SVG_HIT_REQUEST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVG_TYPE_HIT_REQUEST, SvgHitRequestClass))

typedef struct _SvgHitRequestClass SvgHitRequestClass;

struct _SvgHitRequest {
	GObject parent_instance;
    double x;
    double y;
};

struct _SvgHitRequestClass {
	GObjectClass parent_class;
};

GType svg_hit_request_get_type();
SvgHitRequest *svg_hit_request_new();

G_END_DECLS

#endif /* __SVG_HIT_REQUEST_H__ */

