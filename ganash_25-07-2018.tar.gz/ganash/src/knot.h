/*
 * knot.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __GANASH_KNOT_H__
#define __GANASH_KNOT_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define GANASH_TYPE_KNOT            (ganash_knot_get_type())
#define GANASH_KNOT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GANASH_TYPE_KNOT, GanashKnot))
#define GANASH_KNOT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GANASH_TYPE_KNOT, GanashKnotClass))
#define GANASH_IS_KNOT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GANASH_TYPE_KNOT))
#define GANASH_IS_KNOT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GANASH_TYPE_KNOT))
#define GANASH_KNOT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GANASH_TYPE_KNOT, GanashKnotClass))

typedef struct _GanashKnot GanashKnot;
typedef struct _GanashKnotPrivate GanashKnotPrivate;
typedef struct _GanashKnotClass GanashKnotClass;

struct _GanashKnot {
	GObject parent_instance;
	/* private */
	GanashKnotPrivate *private_member;
};

struct _GanashKnotClass {
	GObjectClass parent_class;
};

GType ganash_knot_get_type();
GanashKnot *ganash_knot_new();

G_END_DECLS

#endif /* __GANASH_KNOT_H__ */

