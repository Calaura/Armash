/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * main.c
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
 */

#define USE_SVGTK_VIEW 1

#define USE_SVG_EDITOR 0
#define USE_SVG_VIEW 1
#define USE_TREE_VIEW 0
#define USE_TERMINAL  0
#define USE_SOURCEVIEW 1

/*
#define SVG_TREE_TRACE 1
#define SVG_PARSE_TRACE 1
#define SVG_RENDERER_TRACE 1
#define RENDERER_TREE_TRACE 1
#define RENDERER_GRAPHICS_TRACE 1
*/


#include <config.h>

#include <gtk/gtk.h>
#include <gdk/gdk.h>
#include <gmodule.h>
#if USE_TERMINAL
//#include <vte/vte.h>
#endif
#if USE_SOURCEVIEW
#include <gdk-pixbuf/gdk-pixbuf-animation.h>
#include <gtksourceview/gtksourceview.h>
#include <gtksourceview/gtksourcebuffer.h>
#include <gtksourceview/gtksourcelanguage.h>
#include <gtksourceview/gtksourcelanguagemanager.h>
#endif



#include <glib/gi18n.h>

#include <liblog/log.h>


#include "libgeom/geom-box.h"

#include <libgraphics/graphics.h>
#include <libgraphics/graphics-fill.h>

/* #include "librenderer/renderer.h" */
#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-event.h"
#include "librenderer/renderer-hit-test-request.h"
#include "librenderer/renderer-hit-test-result.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-rect.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"

#include <libdom/dom.h>


#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-document.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-rect.h"
#   include "libsvg/svg-length.h"

#include "libsvgtk/svgtk-types.h"
#include "libsvgtk/svgtk-enums.h"
#include "libsvgtk/svgtk-document.h"

#include "libcore/core-types.h"
#include "libcore/core-enums.h"
#include "libcore/core-path.h"

#include "libwidgets/gan-cell-renderer-graph.h"
#include "libwidgets/svgtk-tool.h"
#include "libwidgets/gan-svg-editor.h"
#include "libwidgets/gan-svg-view.h"
#include "libwidgets/gan-svgtk-view.h"

#include "libwidgets/svgtk-tool.h"
#include "libwidgets/svgtk-tool-transform.h"
#include "libwidgets/svgtk-tool-draw.h"
#include "libwidgets/svgtk-tool-rect.h"
#include "libwidgets/svgtk-tool-path.h"

enum
{
    COL_FIRST_NAME = 0,
    COL_LAST_NAME,
    COL_SCENE,
    COL_HEIGHT,
    NUM_COLS
};

static GtkTreeModel *
create_and_fill_model (RendererScene* scene1, RendererScene* scene2)
{
  GtkTreeStore  *treestore;
  GtkTreeIter    toplevel, child;

  treestore = gtk_tree_store_new(NUM_COLS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_POINTER, G_TYPE_INT);

  /* Append a top level row and leave it empty */
  gtk_tree_store_append(treestore, &toplevel, NULL);

  /* Append a second top level row, and fill it with some data */
  gtk_tree_store_append(treestore, &toplevel, NULL);
  gtk_tree_store_set(treestore, &toplevel,
                     COL_FIRST_NAME, "Joe",
                     COL_LAST_NAME, "Avril",
                     COL_SCENE, scene1,
                     COL_HEIGHT, 40,
                     -1);

  /* Append a child to the second top level row, and fill in some data */
  gtk_tree_store_append(treestore, &child, &toplevel);
  gtk_tree_store_set(treestore, &child,
                     COL_FIRST_NAME, "Jane",
                     COL_LAST_NAME, "Average",
                     COL_SCENE, scene2,
                     COL_HEIGHT, 120,
                     -1);

  return GTK_TREE_MODEL(treestore);
}

static GtkWidget *
create_view_and_model (RendererScene* scene1, RendererScene* scene2)
{
  GtkTreeViewColumn   *col;
  GtkCellRenderer     *renderer;
  GtkWidget           *view;
  GtkTreeModel        *model;

  view = gtk_tree_view_new();

  /* --- Column #1 --- */

  col = gtk_tree_view_column_new();

  gtk_tree_view_column_set_title(col, "First Name");

  /* pack tree view column into tree view */
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);

  renderer = gtk_cell_renderer_text_new();

  /* pack cell renderer into tree view column */
  gtk_tree_view_column_pack_start(col, renderer, TRUE);

  /* set 'text' property of the cell renderer */
  g_object_set(renderer, "text", "Boooo!", NULL);


  /* --- Column #2 --- */

  col = gtk_tree_view_column_new();

  gtk_tree_view_column_set_title(col, "Last Name");

  /* pack tree view column into tree view */
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);

  renderer = gtk_cell_renderer_text_new();

  /* pack cell renderer into tree view column */
  gtk_tree_view_column_pack_start(col, renderer, TRUE);

  gtk_tree_view_column_add_attribute(col, renderer, "text", COL_LAST_NAME);

  /* set 'cell-background' property of the cell renderer */
  g_object_set(renderer,
               "cell-background", "Orange",
               "cell-background-set", TRUE,
               NULL);

  /* --- Column #3 --- */
  col = gtk_tree_view_column_new();

  gtk_tree_view_column_set_title(col, "Graphics scene");

  /* pack tree view column into tree view */
  gtk_tree_view_append_column(GTK_TREE_VIEW(view), col);

  /*renderer = gan_cell_renderer_graph_new();*/
  renderer = g_object_new(GAN_TYPE_CELL_RENDERER_GRAPH, NULL);

  /* pack cell renderer into tree view column */
  gtk_tree_view_column_pack_start(col, renderer, TRUE);

  gtk_tree_view_column_add_attribute(col, renderer, "scene", COL_SCENE);
  gtk_tree_view_column_add_attribute(col, renderer, "height", COL_HEIGHT);



  model = create_and_fill_model(scene1, scene2);

  gtk_tree_view_set_model(GTK_TREE_VIEW(view), model);

  g_object_unref(model); /* destroy model automatically with view */

  gtk_tree_selection_set_mode(gtk_tree_view_get_selection(GTK_TREE_VIEW(view)),
                              GTK_SELECTION_NONE);



  return view;
}

RendererScene* tree_view_get_scene_by_pos(GtkWidget *widget, double x, double y, int* rel_x, int* rel_y)
{
    RendererScene* scene = NULL;
    GtkTreeView* tree_view = GTK_TREE_VIEW(widget);
    GtkTreeViewColumn* column_graph = gtk_tree_view_get_column(tree_view, 2);

    GtkTreePath* path;
    GtkTreeViewColumn* column;
    gboolean success = gtk_tree_view_get_path_at_pos(tree_view, x, y, &path, &column, rel_x, rel_y);

    if (success && column == column_graph) {
        GtkTreeModel* model = gtk_tree_view_get_model(tree_view);
        GtkTreeIter iter;
        success = gtk_tree_model_get_iter(model, &iter, path);
        if (success) {
            gtk_tree_model_get(model, &iter, COL_SCENE, &scene, -1);
            if (scene) {
                return scene;
            }
        }
    }
    return NULL;
}

gboolean tree_motion (GtkWidget *widget, GdkEventMotion *event, gpointer user_data)
{
    /*g_print("%s\n", G_STRFUNC);*/

    /*svg_view_emit_event(view, EventMouse* event); */
    /*Event* event->type = EVENT_MOUSE_MOTION; */
    /*svg_view_emit_mouse_event(view, EventMouse* event); */
    /*svg_view_emit_mouse_motion_event(view, EventMouse* event); */
    /*svg_view_emit_mouse_press_event(view, EventMouse* event); */
    /*svg_view_emit_mouse_release_event(view, EventMouse* event); */

    /*svgtk_view_set_zoom_level(view, 0.75); */
    /*GtkRectangle *rect = svg_view_get_bounding_box(view); */

    g_return_val_if_fail(RENDERER_IS_SCENE(user_data), FALSE);
    RendererScene* scene = RENDERER_SCENE(user_data);

    GtkTreeView* tree_view = GTK_TREE_VIEW(widget);
    GtkTreeViewColumn* column2 = gtk_tree_view_get_column(tree_view, 2);

    int cell_x, cell_y;
    GtkTreePath* path;
    GtkTreeViewColumn* column;
    gboolean success = gtk_tree_view_get_path_at_pos(tree_view, event->x, event->y, &path, &column, &cell_x, &cell_y);

    if (success && column == column2) {
        GtkTreeModel* model = gtk_tree_view_get_model(tree_view);
        GtkTreeIter iter;
        success = gtk_tree_model_get_iter(model, &iter, path);
        if (success) {
            gtk_tree_model_get(model, &iter, COL_SCENE, &scene, -1);
            if (scene) {
                RendererHitTestRequest request;
                request.x      = cell_x;
                request.y      = cell_y;
                request.type   = RENDERER_HIT_TEST_FILL_MODE;
                request.deltat = 0.0;
                cairo_t *cr = gdk_cairo_create(gtk_widget_get_window(widget));

                RendererHitTestResult hit_test_results = {NULL};
                renderer_object_hit_test(RENDERER_OBJECT(scene->root), cr, &request, &hit_test_results);

                cairo_destroy(cr);
            }
        }
    }


    return FALSE;
}

static gboolean         tree_shift_pressed   = FALSE;
static gboolean         tree_control_pressed = FALSE;

gboolean tree_scroll (GtkWidget *widget,
                      GdkEventScroll *event,
                      gpointer user_data)
{
    int cell_x, cell_y;
    RendererScene* scene = tree_view_get_scene_by_pos(widget, event->x,event->y, &cell_x, &cell_y);
    if (!scene) return FALSE;

    switch (event->direction)
    {
    case GDK_SCROLL_UP:
        /*RENDERER_OBJECT(scene->root)->matrix.y0 += 10;*/

        if (tree_shift_pressed) {
            scene->view->offset_x+= 10;
        } else if (tree_control_pressed) {
            scene->view->scale_x*= 1.618;
            scene->view->scale_y*= 1.618;
        } else {
            scene->view->offset_y+= 10;
        }
    break;
    case GDK_SCROLL_DOWN:
        /*RENDERER_OBJECT(scene->root)->matrix.y0 -= 10;*/
        if (tree_shift_pressed) {
            scene->view->offset_x-= 10;
        } else if (tree_control_pressed) {
            scene->view->scale_x/= 1.618;
            scene->view->scale_y/= 1.618;
        } else {
            scene->view->offset_y-= 10;
        }
    break;
    }

    gtk_widget_queue_draw(widget);

    return FALSE;
}

#include "gdk/gdkkeysyms.h"

gboolean tree_key_press   (GtkWidget *widget,
                           GdkEvent  *event,
                           gpointer   user_data)
{
    GtkTreeView *tree_view = GTK_TREE_VIEW(widget);

    switch (event->key.keyval)
    {
    case GDK_KEY_Shift_L:
        tree_shift_pressed   = TRUE;
    break;
    case GDK_KEY_Control_L:
        tree_control_pressed = TRUE;
    break;
    }

    return FALSE;
}

gboolean tree_key_release (GtkWidget *widget,
                           GdkEvent  *event,
                           gpointer   user_data)
{
    switch (event->key.keyval)
    {
    case GDK_KEY_Shift_L:
        tree_shift_pressed   = FALSE;
    break;
    case GDK_KEY_Control_L:
        tree_control_pressed = FALSE;
    break;
    }

    return FALSE;
}

/* ------------------------------------------------------------------------- */

GraphicsPath* create_path_knot()
{
    GraphicsPath *path = graphics_path_new();

    double x_offset = 100.5 - 5;
    double y_offset = 100.5 - 5;

    graphics_path_move_to(path,   0.0+x_offset,   0.0+y_offset);
    graphics_path_line_to(path,  10.0+x_offset,   0.0+y_offset);
    graphics_path_line_to(path,  10.0+x_offset,  10.0+y_offset);
    graphics_path_line_to(path,   0.0+x_offset,  10.0+y_offset);
    graphics_path_line_to(path,   0.0+x_offset,   0.0+y_offset);

    return path;
}

GraphicsPath* create_path_wave()
{
    GraphicsPath *path = graphics_path_new();

    double x_offset = 0.5;
    double y_offset = 0.5;
    graphics_path_move_to(path,   0.0+x_offset,    0.0+y_offset);
    graphics_path_curve_to(path,
                        50.0+x_offset,   0.0+y_offset,
                        50.0+x_offset, 100.0+y_offset,
                       100.0+x_offset, 100.0+y_offset);
    graphics_path_curve_to(path,
                       150.0+x_offset, 100.0+y_offset,
                       150.0+x_offset,   0.0+y_offset,
                       200.0+x_offset,   0.0+y_offset);


    return path;
}

/* ------------------------------------------------------------------------- */

GraphicsFill* create_fill_image()
{
    GraphicsFill* fill = g_object_new(graphics_fill_get_type(), NULL);
    GraphicsPainter *painter = graphics_painter_new();
    graphics_painter_set_image(painter, graphics_image_new_from_uri("/home/instant/Images/Java-logo.png"));
    fill->painter = painter;

    return fill;
}

/* ------------------------------------------------------------------------- */


GraphicsStroke* create_stroke_solid_black()
{
    GraphicsSolid* solid_black = graphics_solid_new_init(0.0, 0.0, 0.0, 1.0);
    GraphicsPainter* painter = graphics_painter_new();
    graphics_painter_set_solid(painter, solid_black);

    GraphicsStroke* stroke = graphics_stroke_new();
    stroke->width       = 1.0;
    stroke->cap         = GRAPHICS_CAP_SQUARE;
    stroke->join        = GRAPHICS_JOIN_MITER;
    stroke->miter_limit = 2.0;
    stroke->painter     = painter;

    return stroke;
}

/* --- */
GraphicsFill* create_fill_solid_green()
{
    GraphicsSolid *solid_green = graphics_solid_new_init(0.0, 1.0, 0.0, 1.0);
    GraphicsPainter *painter = graphics_painter_new();
    graphics_painter_set_solid(painter, solid_green);
    GraphicsFill* fill = graphics_fill_new();
    fill->painter = painter;

    return fill;
}

GraphicsFill* create_fill_solid_red()
{
    GraphicsSolid *solid_red = graphics_solid_new_init(1.0, 0.0, 0.0, 1.0);
    GraphicsPainter *painter = graphics_painter_new();
    graphics_painter_set_solid(painter, solid_red);
    GraphicsFill* fill = graphics_fill_new();
    fill->painter = painter;

    return fill;
}

GraphicsFill* create_fill_solid_white()
{
    GraphicsSolid *solid_red = graphics_solid_new_init(1.0, 1.0, 1.0, 1.0);
    GraphicsPainter *painter = graphics_painter_new();
    graphics_painter_set_solid(painter, solid_red);
    GraphicsFill* fill = graphics_fill_new();
    fill->painter = painter;

    return fill;
}

GraphicsFill* create_fill_gradient_green_red()
{
    GraphicsGradientLinear* linear = graphics_gradient_linear_new();
    linear->x0 = 100.0;
    linear->y0 =   0.0;
    linear->x1 = 120.0;
    linear->y1 = 20.0;
    GraphicsGradient* gradient = (GraphicsGradient*) linear;
    graphics_gradient_add_stop(gradient, 0.0, 1.0, 0.0, 0.0, 1.0);
    graphics_gradient_add_stop(gradient, 1.0, 0.0, 1.0, 0.0, 1.0);
    GraphicsPainter* painter = graphics_painter_new();
    graphics_painter_set_gradient(painter, gradient);
    GraphicsFill* fill = graphics_fill_new();
    fill->painter = painter;

    return fill;
}


/* ------------------------------------------------------------------------- */

gboolean
knot_enter_notify_event(RendererObject* object, RendererEvent* event/*, ... */, gpointer user_data)
{
    g_print("%s; MouseEvent{x:%f, y:%f}\n", G_STRFUNC, event->x, event->y);
    return FALSE;
}

gboolean
knot_leave_notify_event(RendererObject* object, RendererEvent* event/*, ... */, gpointer user_data)
{
    g_print("%s\n", G_STRFUNC);

    return FALSE;
}

RendererScene* create_scene_tree()
{
    RendererScene* scene;
    RendererShape* curve;
    RendererShape* knot;

    scene = renderer_scene_new("scene");
    curve = renderer_shape_new(scene, NULL);
    renderer_shape_set_path(curve, create_path_wave());
    /*curve->graphics.path   = create_path_wave()+...;*/
    curve->fill   = create_fill_image();
    curve->stroke = create_stroke_solid_black();

    //renderer_object_set_sensitive(RENDERER_OBJECT(curve), FALSE);
    RENDERER_OBJECT(curve)->sensitive = FALSE;

    renderer_container_insert(RENDERER_CONTAINER(scene), RENDERER_OBJECT(curve), -1);

    knot = g_object_new(RENDERER_TYPE_SHAPE, NULL);
    renderer_shape_set_path(knot, create_path_knot());
    /*knot->graphics.path   = create_path_knot();*/
    /*knot->graphics.fill   = create_fill_rgb_green();*/
    knot->stroke = create_stroke_solid_black();

    g_signal_connect(knot, "enter_notify_event", G_CALLBACK(knot_enter_notify_event), scene);

    renderer_container_insert(RENDERER_CONTAINER(scene), RENDERER_OBJECT(knot), -1);

    return scene;
}

RendererScene* create_renderer_scene()
{
    RendererScene* scene;
    RendererView* view;
    RendererContainer* root;
    RendererShape* curve;
    RendererShape* knot;

    view = renderer_view_new();
    scene = renderer_scene_new("scene2");
    renderer_view_set_scene(view, scene);
    renderer_scene_set_view(scene, view);

    root = renderer_container_new(scene, NULL);
    renderer_scene_set_root(scene, RENDERER_OBJECT(root));

    curve = renderer_shape_new(scene, NULL);
    renderer_shape_set_path(curve, create_path_wave());
    /*curve->graphics.path   = create_path_wave();*/
    curve->fill   = create_fill_gradient_green_red();
    curve->stroke = create_stroke_solid_black();
    //renderer_object_set_sensitive(RENDERER_OBJECT(curve), FALSE);
    RENDERER_OBJECT(curve)->sensitive = FALSE;

    renderer_container_insert(RENDERER_CONTAINER(root), RENDERER_OBJECT(curve), -1);

    knot = renderer_shape_new(scene, NULL);
    renderer_shape_set_path(knot, create_path_knot());
    /*knot->graphics.path   = create_path_knot();*/
    knot->fill   = create_fill_solid_green();
    knot->stroke = create_stroke_solid_black();

    renderer_container_insert(RENDERER_CONTAINER(root), RENDERER_OBJECT(knot), -1);

    g_signal_connect(knot, "enter_notify_event", G_CALLBACK(knot_enter_notify_event), scene);
    g_signal_connect(knot, "leave_notify_event", G_CALLBACK(knot_leave_notify_event), scene);

    renderer_scene_set_target(scene, root);

    return scene;
}


#include "libsvg/svg-types.h"
#include "libsvg/svg-document.h"
#include "libsvg/svg-element.h"

/* Determines if to continue the timer or not */
static gboolean continue_timer = FALSE;

/* Determines if the timer has started */
static gboolean start_timer = FALSE;

static GTimer* timer = NULL;
GtkWidget *timeline = NULL;

static gboolean
svg_editor_update(gpointer data)
{
    GanSvgEditor *editor = (GanSvgEditor*)data;
    gulong microseconds;
    gdouble elapsed = g_timer_elapsed(timer, &microseconds);
    /*g_print("elapsed: %f\n", elapsed);*/
    gan_svg_editor_set_time(editor, elapsed);

    GtkAdjustment *adj = gtk_range_get_adjustment(timeline);
    gtk_adjustment_set_value(adj, elapsed);

    gtk_widget_queue_draw(editor);

    return continue_timer;
}

static void timeline_on_value_changed(GtkRange *range, gpointer  user_data)
{
    GanSvgEditor *editor = (GanSvgEditor*)user_data;

    GtkAdjustment *adj = gtk_range_get_adjustment(range);
    gdouble val = gtk_adjustment_get_value(adj);

    gan_svg_editor_set_time(editor, val);
    gtk_widget_queue_draw(editor);
}

//static void gan_svg_editor_on_timeline_value_changed(GtkRange *range, gpointer  user_data)
static void gan_svg_view_on_timeline_value_changed(GtkRange *range, gpointer  user_data)
{
    GanSvgView *view = (GanSvgView*)user_data;

    GtkAdjustment *adj = gtk_range_get_adjustment(range);
    gdouble val = gtk_adjustment_get_value(adj);

    gan_svg_view_set_time(view, val);
    gtk_widget_queue_draw(view);
}

void btn_play_on_clicked(GtkButton *button, gpointer user_data)
{
    if(!start_timer)
    {
        timer = g_timer_new();
        g_timer_start(timer);
        g_timeout_add(42, svg_editor_update, user_data);
        start_timer = TRUE;
        continue_timer = TRUE;
    } else {
        g_timer_reset(timer);
    }

    g_print("%s\n", G_STRFUNC);
}

void btn_pause_on_clicked(GtkButton *button, gpointer user_data)
{
    if(timer)
    {
        g_timer_stop(timer);
        start_timer = FALSE;
        continue_timer = FALSE;
    }

    g_print("%s\n", G_STRFUNC);
}

void on_select_edit_tool(GtkToolItem *button, gpointer user_data)
{
    GanSvgEditor *editor = user_data;
    //editor->tool = svgtk_tool_rect_new(editor);
    /*editor->tool = svgtk_tool_path_new(editor);*/

    g_print("%s\n", G_STRFUNC);
}

void on_select_transform_tool(GtkToolItem *button, gpointer user_data)
{
    GanSvgEditor *editor = user_data;
    //editor->tool = svgtk_tool_transform_new(editor);

    g_print("%s\n", G_STRFUNC);
}


int
main (int argc, char *argv[])
{

    GtkWidget *window;
    GtkWidget* tree_view;
    GtkWidget* box;
    int status = 0;


#ifdef ENABLE_NLS
	bindtextdomain (GETTEXT_PACKAGE, PACKAGE_LOCALE_DIR);
	bind_textdomain_codeset (GETTEXT_PACKAGE, "UTF-8");
	textdomain (GETTEXT_PACKAGE);
#endif

    gtk_init (&argc, &argv);
    svg_length_get_type();





    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_widget_set_size_request (window, 600, 400);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);
    g_signal_connect (window, "destroy",
                  G_CALLBACK (gtk_main_quit), NULL);

    /*
        SvgtkView *view = svgtk_view_new();
        svgtk_view_open(view, "/home/emile/Images/motion.svg");
        g_object_connect(view, "on-load", G_CALLBACK(on_load), NULL);
        svgtk_view_draw(view, cr);
        svgtk_view_queue_draw(view, cr);
        svgkit_view_set_mode(view, SVGKIT_VIEW_MODE_EDITOR);
        svgkit_view_set_mode(view, SVGKIT_VIEW_MODE_PLAYER);
        svgkit_view_get_editor(view)->tool = NULL;
        svgkit_view_get_editor(view)->config = NULL;
        svgkit_editor_set_modifier(view, CTRL|MAJ|ALT);
        svgtk_view_emit_event(view, 0, 0);
    */
        /*GanSvgEditorScenario* svg_editor = gan_svg_editor_scenario_new();*/

#if USE_SVGTK_VIEW
    GanSvgtkView* svgtk_view = gan_svgtk_view_new();
    gan_svgtk_view_load_uri(svgtk_view, "/home/gaulouis/local/src/ganash/tests/libsvg/share/controls.svg");
    //gan_svgtk_view_load_uri(svgtk_view, "/home/instant/Images/ghost.svg");

    //gan_svgtk_view_load_uri(svgtk_view, "/home/instant/Images/square.svg");

    gtk_widget_set_size_request(GTK_WIDGET(svgtk_view), 400, 400);
    GtkWidget *scrolledWindowSvgtkView = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledWindowSvgtkView),
            GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolledWindowSvgtkView), GTK_WIDGET(svgtk_view));
    /*gtk_widget_set_size_request(scrolledWindowEditor, 10, 50);*/
#endif

#if USE_TREE_VIEW
    SvgDocument* svg_doc1 = svg_document_load("/home/instant/Images/ghost.svg");
    RendererView* view = svg_document_get_view(svg_doc1);
    RendererScene* scene_row1 = view->scene;
//    scene_row1->root = svg_element_graphics_get_renderer(svg_doc1->root);
//    svg_element_graphics_update_renderer(svg_doc1->root);
//    RendererScene* scene_row1 = create_scene_tree();
    RendererScene* scene_row2 = create_renderer_scene();
    //log_debug("/home/instant/Images/ghost.svg");
    //log_debug("%.*j", RENDERER_DUMP_ALL|LOG_DUMP_INDENT_FLAG, scene_row2->root);

    tree_view = create_view_and_model(scene_row1, scene_row2);
    g_signal_connect(tree_view, "motion-notify-event",
                     G_CALLBACK(tree_motion), scene_row1);
    g_signal_connect(tree_view, "scroll-event",
                     G_CALLBACK(tree_scroll), scene_row1);
    g_signal_connect(tree_view, "key-press-event",
                     G_CALLBACK(tree_key_press), scene_row1);
    g_signal_connect(tree_view, "key-release-event",
                     G_CALLBACK(tree_key_release), scene_row1);
#endif



#if USE_SVG_EDITOR
    GanSvgEditor* svg_editor = gan_svg_editor_new();
    //gan_svg_editor_load_uri(svg_editor, "/home/instant/workspace/Gtk/ganash/0-3/tests/libsvg/share/full.svg");
    // "/home/haier/Workspace/ganash/0-3/tests/libsvg/share/controls.svg"
    //gan_svg_editor_load_uri(svg_editor, "/home/instant/Images/square.svg");
    gan_svg_editor_load_uri(svg_editor, "/home/gaulouis/local/src/ganash/tests/libsvg/share/square.svg");
    gan_svg_editor_set_background(svg_editor, create_fill_solid_white());
    //gan_svg_editor_set_background(svg_editor, create_fill_millimetre());

    gtk_widget_set_size_request(GTK_WIDGET(svg_editor), 400, 400);
    GtkWidget *scrolledWindowEditor = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledWindowEditor),
            GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolledWindowEditor), GTK_WIDGET(svg_editor));
    /*gtk_widget_set_size_request(scrolledWindowEditor, 10, 50);*/
#endif

    GtkWidget *tools   = gtk_toolbar_new();
    GtkToolItem *transform;
    GtkToolItem *edit;
    /*gtk_toggle_tool_button_new_from_stock(GTK_STOCK_CDROM);*/
    /*gtk_toggle_tool_button_set_active(GTK_TOGGLE_TOOL_BUTTON(transform), TRUE);*/
    GSList *group = NULL;
    transform = gtk_radio_tool_button_new_from_stock(group, GTK_STOCK_FULLSCREEN);
    group = gtk_radio_tool_button_get_group(transform);
    gtk_toolbar_insert(GTK_TOOLBAR(tools), transform, -1);
    /*edit = gtk_tool_button_new_from_stock(GTK_STOCK_EDIT);*/
    edit = gtk_radio_tool_button_new_from_stock(group, GTK_STOCK_EDIT);
    gtk_toolbar_insert(GTK_TOOLBAR(tools), edit, -1);


#if USE_SVG_EDITOR
    g_signal_connect(G_OBJECT(transform), "clicked",
                     G_CALLBACK(on_select_transform_tool), svg_editor);
    g_signal_connect(G_OBJECT(edit), "clicked",
                     G_CALLBACK(on_select_edit_tool), svg_editor);
#endif



    GtkWidget *controls  = gtk_hbox_new(FALSE, 0);
    GtkWidget *vbox     = gtk_vbox_new(FALSE, 0);
    GtkWidget *box_btn  = gtk_hbox_new(FALSE, 0);
    GtkWidget *btn_play = gtk_button_new_from_stock(GTK_STOCK_MEDIA_PLAY);
    GtkWidget *btn_pause = gtk_button_new_from_stock(GTK_STOCK_MEDIA_PAUSE);
    /*GtkAdjustment *adjustment = gtk_adjustment_new(0.0, 0.0, 100.0, 0.1, 0.1, 100.0);*/
    timeline = gtk_hscale_new_with_range (0.0, 10.0, 0.01);/*dur=00:02:30.250*/

#if USE_SVG_EDITOR
    g_signal_connect(timeline, "value-changed",
                     G_CALLBACK(timeline_on_value_changed), svg_editor);
#endif

    gtk_box_pack_start(GTK_BOX(box_btn), btn_play, FALSE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(box_btn), btn_pause, FALSE, TRUE, 0);
    gtk_box_pack_end(GTK_BOX(vbox), box_btn, FALSE, TRUE, 0);


    gtk_box_pack_start(GTK_BOX(controls), tools, FALSE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(controls), vbox, FALSE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(controls), timeline, TRUE, TRUE, 0);


#if USE_SVG_EDITOR
    g_signal_connect(btn_play, "clicked",
                     G_CALLBACK(btn_play_on_clicked), svg_editor);
    g_signal_connect(btn_pause, "clicked",
                     G_CALLBACK(btn_pause_on_clicked), svg_editor);
#endif



#if USE_SVG_VIEW
    GanSvgView* svg_view = gan_svg_view_new();
    //gan_svg_view_load_uri(svg_view, "/home/instant/Images/controls.svg");
    gan_svg_view_load_uri(svg_view, "/home/gaulouis/local/src/ganash/tests/libsvg/share/animate-x.svg");
    // onload(): svg_view->getSizeRequest(); Shared<Render> render = svg_view->getRender();
    gtk_widget_set_size_request(GTK_WIDGET(svg_view), 400, 400);

    GtkWidget *scrolledWindowSvgView = gtk_scrolled_window_new(NULL, NULL);
    gtk_scrolled_window_set_policy(GTK_SCROLLED_WINDOW(scrolledWindowSvgView),
            GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC);
    gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolledWindowSvgView), GTK_WIDGET(svg_view));
                /*gtk_widget_set_size_request(scrolledWindow, 10, 50);*/
                /*gtk_container_add(GTK_CONTAINER(scrolledWindow), GTK_WIDGET(webView));*/

    g_signal_connect(timeline, "value-changed",
                     G_CALLBACK(gan_svg_view_on_timeline_value_changed), svg_view);

#endif



#if USE_TERMINAL
//    GtkWidget *terminal = vte_terminal_new();
//    VteTerminal *vte = VTE_TERMINAL(terminal);
//    gtk_widget_set_size_request(terminal, -1, 50);

#endif

    GtkWidget* hbox = gtk_hbox_new(FALSE, 2);
#if USE_SVG_EDITOR
    gtk_box_pack_start(GTK_BOX(hbox),  GTK_WIDGET(scrolledWindowEditor), TRUE, TRUE, 0);
#endif
#if USE_SVG_VIEW
    gtk_box_pack_start(GTK_BOX(hbox),  GTK_WIDGET(scrolledWindowSvgView), TRUE, TRUE, 0);
#endif
#if USE_SVGTK_VIEW
    gtk_box_pack_start(GTK_BOX(hbox),  GTK_WIDGET(scrolledWindowSvgtkView), TRUE, TRUE, 0);
#endif


    box = gtk_vbox_new(FALSE, 0);
#if USE_TREE_VIEW
    gtk_box_pack_start(GTK_BOX(box), GTK_WIDGET(tree_view), FALSE, TRUE, 0);
#endif
    gtk_box_pack_start(GTK_BOX(box),  GTK_WIDGET(hbox), TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX(box),  GTK_WIDGET(controls), FALSE, TRUE, 0);
    //gtk_box_pack_start(GTK_BOX(box),  GTK_WIDGET(tools), FALSE, TRUE, 0);

#if USE_SOURCEVIEW
    static GtkWidget *sView;
    PangoFontDescription *font_desc;
    GtkSourceLanguageManager *lm;
    GtkSourceBuffer *sBuf;

    lm = gtk_source_language_manager_new();

    /* and a GtkSourceBuffer to hold text (similar to GtkTextBuffer) */
    sBuf = GTK_SOURCE_BUFFER (gtk_source_buffer_new (NULL));
    g_object_ref (lm);
    g_object_set_data_full ( G_OBJECT (sBuf), "language-manager",
                             lm, (GDestroyNotify) g_object_unref);

    /* Create the GtkSourceView and associate it with the buffer */
    sView = gtk_source_view_new_with_buffer(sBuf);
       /* Set default Font name,size */
       font_desc = pango_font_description_from_string ("mono 8");
       gtk_widget_modify_font (sView, font_desc);
       pango_font_description_free (font_desc);
    gtk_widget_set_size_request(sView, 100, 100);

    gtk_container_set_border_width(GTK_CONTAINER(sView), 4);
    gtk_box_pack_start(GTK_BOX(box), GTK_WIDGET(sView), FALSE, TRUE, 0);
#endif

#if USE_TERMINAL
//    gtk_box_pack_start(GTK_BOX(box), GTK_WIDGET(terminal), FALSE, TRUE, 0);
#endif

    gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(box));

    gtk_widget_show_all (window);

    gtk_main ();

    /*g_log(NULL, G_LOG_LEVEL_INFO , "This is info");
    g_debug("This is debug");
    g_message("This is message");
    g_warning("This is warning");
    g_critical("This is critical");*/

    g_print("TODO: systeme update cascading\n");

    return status;
}
/* ribbon button group
 * http://stackoverflow.com/questions/16264728/making-qt-buttons-connected-to-each-other
 */

/*

view = svgkit_view_new()

sw = gtk.ScrolledWindow()
sw.add(view)

win = gtk.Window(gtk.WINDOW_TOPLEVEL)
win.add(sw)
win.show_all()

view.open("http://w3.org/")

 */
