/*
 * knot.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "knot.h"


#define GANASH_KNOT_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), GANASH_TYPE_KNOT, GanashKnotPrivate))
struct _GanashKnotPrivate {
	int foo;
};


static void ganash_knot_class_init(GanashKnotClass *klass);
static void ganash_knot_init(GanashKnot *gobject);

G_DEFINE_TYPE (GanashKnot, ganash_knot, G_TYPE_OBJECT)

static void
ganash_knot_class_init(GanashKnotClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    g_type_class_add_private(klass, sizeof(GanashKnotPrivate));
//	ganash_knot_parent_class = g_type_class_peek_parent (klass);
}

static void
ganash_knot_init (GanashKnot *object)
{
	GanashKnotPrivate *priv = GANASH_KNOT_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

GanashKnot *
ganash_knot_new (void)
{
	return g_object_new (ganash_knot_get_type (),
	                     NULL);
}

