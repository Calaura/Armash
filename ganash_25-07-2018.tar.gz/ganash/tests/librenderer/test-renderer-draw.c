#include "test-renderer-draw.h"

#include <liblog/log.h>


#include <libgraphics/graphics.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-rect.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-scene.h"

void test_renderer_draw_set_graphics_data(RendererShape *shape)
{
    /* Fill */
    GraphicsSolid* solid_fill = graphics_solid_new_init(0.0, 0.0, 1.0, 1.0);
    GraphicsPainter* painter_fill = graphics_painter_new(GRAPHICS_PAINTER_SOLID_TYPE);
    graphics_painter_set_solid(painter_fill, solid_fill);

    GraphicsFill* fill = graphics_fill_new();
    fill->painter = painter_fill;

    /* Stroke */
    GraphicsSolid* solid_stroke = graphics_solid_new_init(1.0, 0.0, 0.0, 1.0);
    GraphicsPainter* painter_stroke = graphics_painter_new(GRAPHICS_PAINTER_SOLID_TYPE);
    graphics_painter_set_solid(painter_stroke, solid_stroke);

    GraphicsStroke* stroke = graphics_stroke_new();
    stroke->painter = painter_stroke;

    /* Path */
    RendererRect *rect = renderer_rect_new(RENDERER_OBJECT(shape)->scene, NULL);
    renderer_rect_set(rect, 0, 0, 50, 50, 0.0, 0.0);
    GraphicsPath *path = renderer_shape_get_path(RENDERER_SHAPE(rect));
    g_object_ref(path);
    g_object_unref(rect);

    shape->fill   = fill;
    shape->stroke = NULL;
    shape->path   = path;
}

void
test_renderer_draw_shape(void) {
    cairo_t *cr;
    cairo_surface_t *image;
    int width_image;
    int height_image;
    unsigned char *data_image;
    cairo_surface_t *surface;
    int width_surface;
    int height_surface;
    unsigned char *data_surface;

    surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 100, 100);
    cr = cairo_create(surface);

    RendererView      *view      = renderer_view_new();
    RendererScene     *scene     = renderer_scene_new("my_scene");
    renderer_view_set_scene(view, scene);
    renderer_scene_set_view(scene, view);
    RendererShape     *shape1    = renderer_shape_new(scene, "my_shape1");
                                   test_renderer_draw_set_graphics_data(shape1);

    renderer_scene_set_root(scene, RENDERER_OBJECT(shape1));
    renderer_scene_set_target(scene, RENDERER_OBJECT(shape1));

    renderer_view_to_context(view, cr);
    //cairo_surface_write_to_png(surface, TEST_RENDERER_SHARE_DIR "shape1.png");


    //gchar *file = g_strdup_printf("%s%s", TEST_GRAPHICS_SHARE_DIR, filename);
    image = cairo_image_surface_create_from_png (TEST_RENDERER_SHARE_DIR "shape1.test.png");

    data_surface = cairo_image_surface_get_data(surface);
    width_surface  = cairo_image_surface_get_width(surface);
    height_surface = cairo_image_surface_get_height(surface);

    data_image   = cairo_image_surface_get_data(image);
    width_image  = cairo_image_surface_get_width(image);
    height_image = cairo_image_surface_get_height(image);


    g_assert_cmpint(width_surface, ==, width_image);
    g_assert_cmpint(height_surface, ==, height_image);

    int rst = memcmp (data_surface, data_image, width_image * height_image);
    g_assert_cmpint(rst, ==, 0);



    cairo_surface_destroy(surface);
    cairo_destroy(cr);
}

void
test_renderer_draw_shape_with_transform(void) {
    cairo_t *cr;
    cairo_surface_t *image;
    int width_image;
    int height_image;
    unsigned char *data_image;
    cairo_surface_t *surface;
    int width_surface;
    int height_surface;
    unsigned char *data_surface;

    surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 100, 100);
    cr = cairo_create(surface);

    RendererView      *view      = renderer_view_new();
    view->offset_x = 0.0;
    view->offset_y = 0.0;
    view->rotate   = 0.0;//45*3.14159265359/180;
    RendererScene     *scene     = renderer_scene_new("my_scene");
    RendererShape     *shape1    = renderer_shape_new(scene, "my_shape1");
    renderer_view_set_scene(view, scene);
    renderer_scene_set_view(scene, view);
    RendererObject    *object    = RENDERER_OBJECT(shape1);
                                   test_renderer_draw_set_graphics_data(shape1);
                                   cairo_matrix_translate(&object->transform, 50.0, 50.0);
                                   cairo_matrix_rotate(&object->transform, 45*3.14159265359/180);
                                   cairo_matrix_translate(&object->transform, -30.0, -40.0);

    renderer_scene_set_root(scene, RENDERER_OBJECT(shape1));
    renderer_scene_set_target(scene, RENDERER_OBJECT(shape1));

    renderer_view_to_context(view, cr);
    //cairo_surface_write_to_png(surface, TEST_RENDERER_SHARE_DIR "shape2.png");


    //gchar *file = g_strdup_printf("%s%s", TEST_GRAPHICS_SHARE_DIR, filename);
    image = cairo_image_surface_create_from_png (TEST_RENDERER_SHARE_DIR "shape2.test.png");

    data_surface = cairo_image_surface_get_data(surface);
    width_surface  = cairo_image_surface_get_width(surface);
    height_surface = cairo_image_surface_get_height(surface);

    data_image   = cairo_image_surface_get_data(image);
    width_image  = cairo_image_surface_get_width(image);
    height_image = cairo_image_surface_get_height(image);


    g_assert_cmpint(width_surface, ==, width_image);
    g_assert_cmpint(height_surface, ==, height_image);

    int rst = memcmp (data_surface, data_image, width_image * height_image);
    g_assert_cmpint(rst, ==, 0);



    cairo_surface_destroy(surface);
    cairo_destroy(cr);
}

void
test_renderer_draw_composite_with_transform(void) {
    cairo_t *cr;
    cairo_surface_t *image;
    int width_image;
    int height_image;
    unsigned char *data_image;
    cairo_surface_t *surface;
    int width_surface;
    int height_surface;
    unsigned char *data_surface;

    surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 100, 100);
    cr = cairo_create(surface);

    RendererView      *view      = renderer_view_new();
    view->offset_x = 0.0;
    view->offset_y = 0.0;
    view->rotate   = 0.0;//45*3.14159265359/180;
    RendererScene     *scene     = renderer_scene_new("my_scene");
    renderer_view_set_scene(view, scene);
    renderer_scene_set_view(scene, view);
    cairo_matrix_t container_transform;
    cairo_matrix_init_translate(&container_transform, 50.0, 20.0);
    RendererContainer *container = renderer_container_new(scene, "my_container");
                                   renderer_object_set_transform((RendererObject*)container, &container_transform);
                                   //renderer_object_notify_transform((RendererObject*)container);

    cairo_matrix_t shape1_transform;
    cairo_matrix_init_rotate(&shape1_transform, 45*3.14159265359/180);
    RendererShape     *shape1    = renderer_shape_new(scene, "my_shape1");
                                   test_renderer_draw_set_graphics_data(shape1);
                                   renderer_object_set_transform((RendererObject*)shape1, &shape1_transform);
                                   //renderer_object_notify_transform((RendererObject*)shape1);
    renderer_object_notify_transform((RendererObject*)container);

    renderer_container_insert(container, (RendererObject *) shape1, -1);

    renderer_scene_set_root(scene, RENDERER_OBJECT(container));
    renderer_scene_set_target(scene, RENDERER_OBJECT(container));


    renderer_view_to_context(view, cr);
    //cairo_surface_write_to_png(surface, TEST_RENDERER_SHARE_DIR "shape3.png");

    image = cairo_image_surface_create_from_png (TEST_RENDERER_SHARE_DIR "shape3.test.png");

    data_surface = cairo_image_surface_get_data(surface);
    width_surface  = cairo_image_surface_get_width(surface);
    height_surface = cairo_image_surface_get_height(surface);

    data_image   = cairo_image_surface_get_data(image);
    width_image  = cairo_image_surface_get_width(image);
    height_image = cairo_image_surface_get_height(image);


    g_assert_cmpint(width_surface, ==, width_image);
    g_assert_cmpint(height_surface, ==, height_image);

    int rst = memcmp (data_surface, data_image, width_image * height_image);
    g_assert_cmpint(rst, ==, 0);



    cairo_surface_destroy(surface);
    cairo_destroy(cr);
}

GTestSuite *
test_renderer_draw_create_suite(void) {
    GTestSuite *suite_renderer_draw = g_test_create_suite("draw");

    g_test_suite_add (suite_renderer_draw, TESTCASE_RENDERER_DRAW (shape, NULL));
    g_test_suite_add (suite_renderer_draw, TESTCASE_RENDERER_DRAW (shape_with_transform, NULL));
    g_test_suite_add (suite_renderer_draw, TESTCASE_RENDERER_DRAW (composite_with_transform, NULL));

	return suite_renderer_draw;
}

