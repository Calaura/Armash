#include "test-renderer-box.h"

#include <liblog/log.h>


#include <libgraphics/graphics.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-box.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-scene.h"


void
test_renderer_box_test0(void) {
    cairo_t *cr;
    cairo_surface_t *surface;
    surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 100, 100);
    cr = cairo_create(surface);

    cairo_matrix_t *matrix = g_new(cairo_matrix_t, 1);
    cairo_matrix_init_identity(matrix);
    cairo_matrix_translate(matrix, 35.355469, 0.0);// 2 translate
    cairo_matrix_rotate(matrix, 45*3.1415926535/180);// 1 rotate
    // or
    //cairo_matrix_init_identity(matrix);
    //cairo_matrix_rotate(matrix, 45*3.1415926535/180);// 1 rotate
    //cairo_matrix_t *matrix_translate = g_new(cairo_matrix_t, 1);
    //cairo_matrix_init_translate(matrix_translate, 35.355469, 0);
    //cairo_matrix_multiply(matrix, matrix, matrix_translate);// 2 translate

    cairo_save(cr);
    cairo_set_matrix(cr, matrix);
    cairo_rectangle(cr, 0, 0, 50, 50);
    cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
    cairo_fill_preserve(cr);
    cairo_restore(cr);

    gdouble x1, y1, x2, y2;
    cairo_fill_extents(cr, &x1, &y1, &x2, &y2);
    cairo_new_path(cr);


    cairo_rectangle(cr, x1, y1, x2-x1, y2-y1);
    cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
    cairo_stroke(cr);
    cairo_surface_write_to_png(surface, TEST_RENDERER_SHARE_DIR "test.png");

    cairo_surface_destroy(surface);
    cairo_destroy(cr);
}

void test_renderer_box_set_graphics_data(RendererShape *shape)
{
    /* Fill */
    GraphicsSolid* solid_fill = graphics_solid_new_init(0.0, 0.0, 1.0, 1.0);
    GraphicsPainter* painter_fill = graphics_painter_new(GRAPHICS_PAINTER_SOLID_TYPE);
    painter_fill->data.solid = solid_fill;
    GraphicsFill* fill = graphics_fill_new();
    fill->painter = painter_fill;

    /* Stroke */
    GraphicsSolid* solid_stroke = graphics_solid_new_init(1.0, 0.0, 0.0, 1.0);
    GraphicsPainter* painter_stroke = graphics_painter_new(GRAPHICS_PAINTER_SOLID_TYPE);
    painter_stroke->data.solid = solid_stroke;
    GraphicsStroke* stroke = graphics_stroke_new();
    stroke->painter = painter_stroke;
    stroke->width   = 10.0;

    /* Path */
    RendererRect *rect = renderer_rect_new(RENDERER_OBJECT(shape)->scene, NULL);
    renderer_rect_set(rect, 0, 0, 50, 50);
    GraphicsPath *path = renderer_shape_get_path(RENDERER_SHAPE(rect));
    g_object_ref(path);
    g_object_unref(rect);

    shape->fill   = fill;
    shape->stroke = stroke;
    shape->path   = path;
}

void
test_renderer_box_test1(void) {
    cairo_t *cr;
    cairo_surface_t *surface;
    surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 0, 0);
    cr = cairo_create(surface);

    RendererView      *view      = renderer_view_new();
    RendererScene     *scene     = renderer_scene_new("my_scene");
    renderer_view_set_scene(view, scene);
    renderer_scene_set_view(scene, view);
    RendererShape     *shape1    = renderer_shape_new(scene, "my_shape1");
    RendererObject    *object    = RENDERER_OBJECT(shape1);
                                   test_renderer_box_set_graphics_data(shape1);

    renderer_scene_set_root(scene, RENDERER_OBJECT(shape1));
    renderer_scene_set_target(scene, RENDERER_OBJECT(shape1));

    //cairo_rectangle_t* rect = renderer_view_get_viewbox(view);
    RendererBox* box;
    box = renderer_object_bounding_box((RendererObject *) shape1, cr, RENDERER_BOUNDING_TRANSFORM_FLAG);
    g_print("%f, %f, %f, %f\n", box->left, box->top, box->right, box->bottom);
    g_assert_cmpfloat(box->left, ==, 0.0);
    g_assert_cmpfloat(box->top, ==, 50.0);
    g_assert_cmpfloat(box->right, ==, 50.0);
    g_assert_cmpfloat(box->bottom, ==, 0.0);


    /*box = renderer_object_bounding_box((RendererObject *) shape1, cr, RENDERER_BOUNDING_STROKE_MODE);
    g_print("%f, %f, %f, %f\n", box->left, box->top, box->right, box->bottom);
    g_assert_cmpfloat(box->left, ==, -5.0);
    g_assert_cmpfloat(box->top, ==, 55.0);
    g_assert_cmpfloat(box->right, ==, 55.0);
    g_assert_cmpfloat(box->bottom, ==, -5.0);*/

}

void
test_renderer_box_test2(void) {
    cairo_t *cr;
    cairo_surface_t *surface;
    surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 0, 0);
    cr = cairo_create(surface);

    RendererView      *view      = renderer_view_new();
    RendererScene     *scene     = renderer_scene_new("my_scene");
    renderer_view_set_scene(view, scene);
    renderer_scene_set_view(scene, view);
    RendererContainer *container1 = renderer_container_new(scene, "my_container1");
    RendererObject    *object     = RENDERER_OBJECT(container1);
                                    cairo_matrix_translate(&object->transform, 50.0, 50.0);
                                    //cairo_matrix_rotate(object->transform, 45*3.14159265359/180);
                                    //cairo_matrix_translate(object->transform, -30.0, -40.0);
    RendererShape     *shape1     = renderer_shape_new(scene, "my_shape1");
                                    test_renderer_box_set_graphics_data(shape1);

    renderer_container_insert(container1, (RendererObject *) shape1, -1);

    renderer_scene_set_root(scene, RENDERER_OBJECT(container1));


    //cairo_rectangle_t* rect = renderer_view_get_viewbox(view);
    //cairo_rectangle_t* rect = renderer_view_set_viewbox(view);
    /*renderer_scene_set_target(scene, RENDERER_OBJECT(container1));
    RendererBox* box = renderer_view_bounding_box(view, RENDERER_BOUNDING_FILL_MODE);
    g_print("%f, %f, %f, %f\n", box->left, box->top, box->right, box->bottom);
    g_assert_cmpfloat(box->left, ==, 50.0);
    g_assert_cmpfloat(box->top, ==, 100.0);
    g_assert_cmpfloat(box->right, ==, 100.0);
    g_assert_cmpfloat(box->bottom, ==, 50.0);
    renderer_box_free(box);


    renderer_scene_set_target(scene, RENDERER_OBJECT(shape1));
    RendererBox* box_view  = renderer_view_bounding_box(view, RENDERER_BOUNDING_FILL_MODE);
    g_assert_cmpfloat(box_view->left, ==, 0.0);
    g_assert_cmpfloat(box_view->top, ==, 50.0);
    g_assert_cmpfloat(box_view->right, ==, 50.0);
    g_assert_cmpfloat(box_view->bottom, ==, 0.0);
    renderer_box_free(box_view);


    RendererBox* box_shape = renderer_object_bounding_box(object, cr, RENDERER_BOUNDING_FILL_MODE);
    g_assert_cmpfloat(box_shape->left, ==, 0.0);
    g_assert_cmpfloat(box_shape->top, ==, 50.0);
    g_assert_cmpfloat(box_shape->right, ==, 50.0);
    g_assert_cmpfloat(box_shape->bottom, ==, 0.0);
    renderer_box_free(box_shape);*/

}


void
test_renderer_box_test3(void) {
    cairo_t *cr;
    cairo_surface_t *surface;
    surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 0, 0);
    cr = cairo_create(surface);

    RendererView      *view      = renderer_view_new();
    RendererScene     *scene     = renderer_scene_new("my_scene");
    renderer_view_set_scene(view, scene);
    renderer_scene_set_view(scene, view);
    RendererContainer *container1 = renderer_container_new(scene, "my_container1");
    RendererShape     *shape1     = renderer_shape_new(scene, "my_shape1");
                                    test_renderer_box_set_graphics_data(shape1);
    RendererObject    *object     = RENDERER_OBJECT(shape1);
                                    cairo_matrix_translate(&object->transform, 50.0, 50.0);
                                    //cairo_matrix_rotate(object->transform, 45*3.14159265359/180);
                                    //cairo_matrix_translate(object->transform, -30.0, -40.0);

    renderer_container_insert(container1, (RendererObject *) shape1, -1);

    renderer_scene_set_root(scene, RENDERER_OBJECT(container1));
    renderer_scene_set_target(scene, RENDERER_OBJECT(shape1));

    //cairo_rectangle_t* rect = renderer_view_get_viewbox(view);
    RendererBox* box = renderer_view_bounding_box(view, RENDERER_BOUNDING_FILL_MODE);
    //cairo_rectangle_t* rect = renderer_view_set_viewbox(view);

    /*g_assert_cmpint(box->left, ==, 50);
    g_assert_cmpint(box->top, ==, 100);
    g_assert_cmpint(box->right, ==, 100);
    g_assert_cmpint(box->bottom, ==, 50);*/

    renderer_box_free(box);
}
void
test_renderer_box()
{
    g_message("/librenderer/bounding_box: Not Implemented");
}

GTestSuite *
test_renderer_box_create_suite(void) {
    GTestSuite *suite_renderer_box = g_test_create_suite("bounding_box");

    //g_test_suite_add (suite_renderer_box, TESTCASE (test_renderer_box_test0, NULL));
    //g_test_suite_add (suite_renderer_box, TESTCASE (test_renderer_box_test1, NULL));
    //g_test_suite_add (suite_renderer_box, TESTCASE (test_renderer_box_test2, NULL));
    //g_test_suite_add (suite_renderer_box, TESTCASE (test_renderer_box_test3, NULL));
    g_test_suite_add (suite_renderer_box, TESTCASE (test_renderer_box, NULL));

	return suite_renderer_box;
}
