#include "test-renderer-transform.h"

#include <liblog/log.h>

#include <libgraphics/graphics.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-scene.h"

void test_renderer_transform_init(RendererShape *shape)
{
    /* Fill */
    GraphicsSolid* solid_fill = graphics_solid_new_init(0.0, 0.0, 1.0, 1.0);
    GraphicsPainter* painter_fill = graphics_painter_new(GRAPHICS_PAINTER_SOLID_TYPE);
    painter_fill->data.solid = solid_fill;
    GraphicsFill* fill = graphics_fill_new();
    fill->painter = painter_fill;

    /* Stroke */
    GraphicsSolid* solid_stroke = graphics_solid_new_init(1.0, 0.0, 0.0, 1.0);
    GraphicsPainter* painter_stroke = graphics_painter_new(GRAPHICS_PAINTER_SOLID_TYPE);
    painter_stroke->data.solid = solid_stroke;
    GraphicsStroke* stroke = graphics_stroke_new();
    stroke->painter = painter_stroke;
    stroke->width   = 10.0;

    /* Path */
    RendererRect *rect = renderer_rect_new();
    renderer_rect_set(rect, 0, 0, 50, 50);
    GraphicsPath *path = renderer_shape_get_path(RENDERER_SHAPE(rect));
    g_object_ref(path);
    g_object_unref(rect);

    shape->fill   = fill;
    shape->stroke = stroke;
    shape->path   = path;
}

void
test_renderer_transform_test1(void) {
    RendererView      *view      = renderer_view_new();
    RendererScene     *scene     = renderer_scene_new("my_scene");
    RendererShape     *shape1    = renderer_shape_new(scene, "my_shape1");
                                   test_renderer_transform_init(shape1);

    renderer_view_set_scene(view, scene);
    renderer_scene_set_root(scene, RENDERER_OBJECT(shape1));
    renderer_scene_set_target(scene, RENDERER_OBJECT(shape1));

    //cairo_matrix_t *matrix = renderer_object_transform(shape1);
    //cairo_matrix_t *matrix = renderer_scene_transform(shape1);

}

GTestSuite *
test_renderer_transform_create_suite(void) {
    GTestSuite *suite_renderer_transform = g_test_create_suite("transform");

    //g_test_suite_add (suite_renderer_transform, TESTCASE (test_renderer_transform_test1, NULL));

	return suite_renderer_transform;
}

