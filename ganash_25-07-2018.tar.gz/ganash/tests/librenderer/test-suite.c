/*
 * test-suite.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "test-suite.h"

#include "test-renderer-tree.h"
#include "test-renderer-transform.h"
#include "test-renderer-draw.h"
#include "test-renderer-box.h"
#include "test-renderer-hittest.h"


GTestSuite*
test_renderer_create_suite(void)
{
    GTestSuite *suite_renderer = g_test_create_suite("librenderer");

    GTestSuite *suite_renderer_tree       = test_renderer_tree_create_suite();
    g_test_suite_add_suite(suite_renderer, suite_renderer_tree);

    GTestSuite *suite_renderer_transform  = test_renderer_transform_create_suite();
    g_test_suite_add_suite(suite_renderer, suite_renderer_transform);

    GTestSuite *suite_renderer_draw       = test_renderer_draw_create_suite();
    g_test_suite_add_suite(suite_renderer, suite_renderer_draw);

    GTestSuite *suite_renderer_box        = test_renderer_box_create_suite();
    g_test_suite_add_suite(suite_renderer, suite_renderer_box);

    GTestSuite *suite_renderer_hittest    = test_renderer_hittest_create_suite();
    g_test_suite_add_suite(suite_renderer, suite_renderer_hittest);

    return suite_renderer;
}
