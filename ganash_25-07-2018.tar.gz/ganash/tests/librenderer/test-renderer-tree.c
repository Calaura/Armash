/*
 * test-svg-time.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "config.h"

#include "test-renderer-tree.h"

#include <liblog/log.h>
#include <libgraphics/graphics.h>

#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-scene.h"

#include "libdom/dom-types.h"
#include "libdom/dom-enums.h"

void
test_renderer_tree_dump(void)
{
    /* create display */
    RendererView      *view      = renderer_view_new();
    RendererScene     *scene     = renderer_scene_new("my_scene");

    RendererContainer *root       = renderer_container_new(scene, "root");
    RendererContainer *container1 = renderer_container_new(scene, "my_container1");
    RendererContainer *container2 = renderer_container_new(scene, "my_container2");
    RendererContainer *container3 = renderer_container_new(scene, "my_container3");

    RendererObject    *object1   = renderer_object_new(scene, "my_object1");
    RendererObject    *object2   = renderer_object_new(scene, "my_object2");
    RendererObject    *object3   = renderer_object_new(scene, "my_object3");
    RendererShape     *shape1    = renderer_shape_new(scene, "my_shape1");

    renderer_container_insert(container1, RENDERER_OBJECT(object1), -1);
    renderer_container_insert(container1, RENDERER_OBJECT(container2), -1);
    renderer_container_insert(container1, RENDERER_OBJECT(object3), -1);
    renderer_container_insert(container2, RENDERER_OBJECT(shape1), -1);
    renderer_container_insert(container2, RENDERER_OBJECT(object2), -1);
    renderer_container_insert(root, RENDERER_OBJECT(container1), -1);
    renderer_container_insert(root, RENDERER_OBJECT(container3), -1);

    renderer_scene_set_root(scene, RENDERER_OBJECT(root));
    renderer_scene_set_target(scene, RENDERER_OBJECT(root));
    renderer_view_set_scene(view, scene);

    gchar *rst =
"[RendererContainer{\n"
"    name: \"root\", \n"
"    children:[\n"
"        [RendererContainer{\n"
"            name: \"my_container1\", \n"
"            children:[\n"
"                [RendererObject{\n"
"                    name: \"my_object1\"\n"
"                }],\n"
"                [RendererContainer{\n"
"                    name: \"my_container2\", \n"
"                    children:[\n"
"                        [RendererShape{\n"
"                            name: \"my_shape1\"\n"
"                        }],\n"
"                        [RendererObject{\n"
"                            name: \"my_object2\"\n"
"                        }]\n"
"                    ],\n"
"                }],\n"
"                [RendererObject{\n"
"                    name: \"my_object3\"\n"
"                }]\n"
"            ],\n"
"        }],\n"
"        [RendererContainer{\n"
"            name: \"my_container3\"\n"
"        }]\n"
"    ],\n"
"}]";

    LogDumpOptions options = LogDumpOptionsEmpty;
    options.flags = RENDERER_DUMP_ALL_TESTABLE | LOG_DUMP_INDENT_FLAG;
    options.newl  = 0;
    // renderer_object_dump(root);
    gchar *str = log_dump_to_string(RENDERER_OBJECT(root), &options);
    g_print("%s", str);
    g_assert_cmpint(g_strcmp0(str, rst), ==, 0);
    g_free(str);

    //log_debug("%b", RENDERER_DUMP_ALL_TESTABLE);
    //log_debug("%.*j\n", RENDERER_DUMP_ALL_TESTABLE, root);

    //log_debug("%#3.*j\n", RENDERER_DUMP_ALL_TESTABLE, root);// indentation, 3 recusion max
    //log_debug("%j\n", root);// minimal data: output [ObjectName{name: "my"}]
    //log_debug("%#j\n", root);// indent : output [ObjectName{
                               //                     name: "my",
                               //                     children[4],
                               //                     index: 1
                               //                 }]


}

GTestSuite *
test_renderer_tree_create_suite(void)
{
    GTestSuite *suite_renderer = g_test_create_suite("tree");

    g_test_suite_add (suite_renderer, TESTCASE_RENDERER_TREE (dump, NULL));

    return suite_renderer;
}
