/*
 * test-svg-length.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <liblog/log.h>

#include "test-svg-length.h"

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-length.h"
#include "libsvg/svg-length-list.h"
#include "libsvg/svg-parser.h"

#include <math.h>
#include <string.h>

void
test_svg_parser_parse_double(void)
{
    double result = 123.0;
    gchar *string = "<values=\"123\" >";

    gchar *ptr = &string[9];
    gchar *end = &string[9+3];
    double number;
    gchar* token = svg_parser_parse_double(ptr, end, &number, FALSE);

    g_assert(token != NULL);
    g_assert(number == result);

}


void
test_svg_length_set_value_from_buffer(void)
{
    double result = 123.0;
    gchar *string = "<values=\"123px\" >";

    gchar *ptr = &string[9];
    gchar *end = &string[9+5];
    SvgLength* length = svg_length_new();
    gboolean success = svg_length_set_value_from_string(length, ptr, end);

    g_assert(success == TRUE);
    g_assert(length->value == result);

}



void
test_svg_length_list_parse(void)
{
    gchar *string = "<values=\"1.23px 456 7.8E2em\" >";

    gchar *ptr = &string[9];
    gchar *end = &string[9+18];
    double number;
    gchar* str = g_strndup(ptr, 18);
    GArray* list = svg_length_list_parse(str, SVG_LENGTH_MODE_WIDTH);

    g_assert(list->len == 3);

    SvgLength* length;
    length = g_array_index(list, SvgLength*, 0);
    g_assert(length->value == 1.23);

    length = g_array_index(list, SvgLength*, 1);
    g_assert(length->value == 456);

    length = g_array_index(list, SvgLength*, 2);
    g_assert(length->value == 780.0);

}

void
test_svg_length_parse_percentage(void)
{
    gchar *string = "0%";

    gchar *end = (gchar *) string + strlen(string);
    double number;
    SvgLength *length = svg_length_new_height();
    gboolean success = svg_length_set_value_from_string(length, string, end);

    g_assert(success==TRUE);
    g_assert_cmpint(length->value, ==, 0);
    g_assert_cmpint(SVG_LENGTH_GET_MODE(length), ==, SVG_LENGTH_MODE_HEIGHT);
    g_assert_cmpint(SVG_LENGTH_GET_TYPE(length), ==, SVG_LENGTH_TYPE_PERCENTAGE);
    g_assert_cmpint(length->unit, ==, SVG_LENGTH_MODE_HEIGHT<<4|SVG_LENGTH_TYPE_PERCENTAGE);

}


GTestSuite *
test_svg_length_create_suite(void)
{
    GTestSuite *suite_svg = g_test_create_suite("length");

    g_test_suite_add (suite_svg, TESTCASE (test_svg_parser_parse_double, NULL));
    g_test_suite_add (suite_svg, TESTCASE (test_svg_length_set_value_from_buffer, NULL));
    g_test_suite_add (suite_svg, TESTCASE (test_svg_length_parse_percentage, NULL));

    g_test_suite_add (suite_svg, TESTCASE (test_svg_length_list_parse, NULL));

    return suite_svg;
}
