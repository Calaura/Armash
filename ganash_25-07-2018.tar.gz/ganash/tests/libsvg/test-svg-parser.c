#include "test-svg-parser.h"

#include <liblog/log.h>

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-parser.h"

#include <string.h>

void
test_svg_parser_offset(void) {
    //gchar *string = "offset=\"0%\"";
    //gchar *string = "0";
    //gchar *string = "1.0";
    //gchar *string = "0%";
    gchar *string = "100%";

    gdouble number;
    SvgOffsetType type;
    gchar *end = string + strlen(string);
    gchar *ptr = svg_parser_parse_offset(&number, &type, string, end);

    g_assert(ptr!=NULL);
    g_assert(SVG_OFFSET_PERCENTAGE==type);
    g_assert(number==100);
}




GTestSuite *
test_svg_parser_create_suite(void) {
    GTestSuite *suite_svg_parser = g_test_create_suite("parser");

    g_test_suite_add (suite_svg_parser, TESTCASE (test_svg_parser_offset, NULL));


	return suite_svg_parser;
}

