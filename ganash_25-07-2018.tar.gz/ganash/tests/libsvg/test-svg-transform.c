/*
 * test-svg-transform.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "test-svg-transform.h"

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include <cairo/cairo.h>
#include "libsvg/svg-matrix.h"
#include "libsvg/svg-transform.h"
#include "libsvg/svg-transform-list.h"
#include "libsvg/svg-parser.h"

/*
void
test_svg_parser_parse_transform_translate(void)
{
    gchar *string = "transform=\"translate(1.1, 12.3)\" ";

    gchar *ptr = &string[11];
    gchar *end = &string[31];
    gchar *str = g_strndup(ptr, 20);
    SvgMatrix *matrix = svg_matrix_new_identity();
    gchar *token = svg_parser_parse_transform(matrix, ptr, end);

    g_free(str);

    g_assert(token != NULL);
    g_assert(token == &string[31]);
    g_assert(*token == '"');

    g_assert(matrix->cairo_matrix.x0 == 1.1);
    g_assert(matrix->cairo_matrix.y0 == 12.3);
}

void
test_svg_parser_parse_transform_scale(void)
{
    gchar *string = "transform=\"translate(1.1, 12.3), rotate(0.0), scale(3.0, 2.0)\" ";

    gchar *ptr = &string[11];
    gchar *end = &string[61];
    gchar *str = g_strndup(ptr, 50);
    SvgMatrix *matrix = svg_matrix_new_identity();
    gchar *token = svg_parser_parse_transform(matrix, ptr, end);
    g_free(str);

    g_assert(token != NULL);
    g_assert(token == &string[61]);
    g_assert(*token == '"');

    g_assert(matrix->cairo_matrix.x0 == 1.1);
    g_assert(matrix->cairo_matrix.xy == 0.0);
    g_assert(matrix->cairo_matrix.xx == 3.0);
    g_assert(matrix->cairo_matrix.y0 == 12.3);
    g_assert(matrix->cairo_matrix.yx == 0.0);
    g_assert(matrix->cairo_matrix.yy == 2.0);

}

void
test_svg_parser_parse_transform(void)
{
    gchar *string = "transform=\"translate(1.1, 12.3), rotate(.00)\" ";

    gchar *ptr = &string[11];
    gchar *end = &string[44];
    gchar *str = g_strndup(ptr, 33);
    SvgMatrix *matrix = svg_matrix_new_identity();
    gchar *token = svg_parser_parse_transform(matrix, ptr, end);

    g_free(str);

    g_assert(token != NULL);
    g_assert(token == &string[44]);
    g_assert(*token == '"');

    g_assert(matrix->cairo_matrix.x0 == 1.1);
    g_assert(matrix->cairo_matrix.xy == 0.0);
    g_assert(matrix->cairo_matrix.xx == 1.0);
    g_assert(matrix->cairo_matrix.y0 == 12.3);
    g_assert(matrix->cairo_matrix.yx == 0.0);
    g_assert(matrix->cairo_matrix.yy == 1.0);

}

*/


void
test_svg_parser_parse_transform(void)
{
    gchar *string = "transform=\"translate(1.1, 12.3), rotate(.00)\" ";

    gchar *ptr = &string[11];
    gchar *end = &string[44];
    gchar *str = g_strndup(ptr, 33);

    SvgTransformList *transform_list = svg_transform_list_new();
    gchar *token = svg_parser_parse_transform(transform_list, ptr, end);
    SvgMatrix* matrix = svg_transform_list_to_matrix(transform_list);

    g_free(str);
    g_assert(token != NULL);
    g_assert(token == &string[44]);
    g_assert(*token == '"');

    g_assert(matrix->cairo_matrix.x0 == 1.1);
    g_assert(matrix->cairo_matrix.xy == 0.0);
    g_assert(matrix->cairo_matrix.xx == 1.0);
    g_assert(matrix->cairo_matrix.y0 == 12.3);
    g_assert(matrix->cairo_matrix.yx == 0.0);
    g_assert(matrix->cairo_matrix.yy == 1.0);
}


GTestSuite *
test_svg_transform_create_suite(void)
{
    GTestSuite *suite_svg_transform = g_test_create_suite("transform");
/*
    g_test_suite_add (suite_svg_transform, TESTCASE (test_svg_parser_parse_transform_translate, NULL));
    g_test_suite_add (suite_svg_transform, TESTCASE (test_svg_parser_parse_transform_scale, NULL));
    g_test_suite_add (suite_svg_transform, TESTCASE (test_svg_parser_parse_transform, NULL));
*/
    g_test_suite_add (suite_svg_transform, TESTCASE (test_svg_parser_parse_transform, NULL));

    return suite_svg_transform;
}
