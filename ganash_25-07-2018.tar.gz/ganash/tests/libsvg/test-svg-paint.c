#include "test-svg-paint.h"

#include <liblog/log.h>

#include <libgraphics/graphics.h>

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-paint.h"
#include "libsvg/svg-parser.h"

#include <string.h>

void test_svg_paint_parser_uri (void)
{
    gchar *string = "url(#my_gradient)";
    gchar *end = string + strlen(string);
    SvgPaint* paint = g_new(SvgPaint, 1);

    gchar* ptr = svg_parser_parse_paint(paint, string);

    g_assert(ptr!=NULL);
    g_assert_cmpint(paint->type, ==, SVG_PAINT_TYPE_URI);
    g_assert_cmpstr(paint->data.uri, ==, "my_gradient");
}

GTestSuite *
test_svg_paint_create_suite(void) {
    GTestSuite *suite_svg_paint = g_test_create_suite("paint");

    g_test_suite_add (suite_svg_paint, TESTCASE (test_svg_paint_parser_uri, NULL));

	return suite_svg_paint;
}
