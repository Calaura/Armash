#include "test-svg-new.h"

#include <liblog/log.h>

#include <libgraphics/graphics.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-rect.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-matrix.h"
#include "libsvg/svg-transform.h"
#include "libsvg/svg-transform-list.h"
#include "libsvg/svg-color.h"
#include "libsvg/svg-paint.h"
#include "libsvg/svg-style.h"
#include "libsvg/svg-document.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-g.h"
#include "libsvg/svg-element-svg.h"
#include "libsvg/svg-element-rect.h"
#include "libsvg/svg-element-use.h"


void
test_svg_new_test1(void) {
    SvgDocument    *document = svg_document_new();
    // document->svg->defs
    // document->InstructionPROCES

    // http://php.net/manual/fr/domdocument.createelementns.php

    //dom_document_register_ns()
/*
    //SvgElement *element_svg  = svg_document_create_element(document, "svg");
    SvgElement *element_g1   = svg_document_create_element(document, "g");
    SvgElement *element_g2   = svg_document_create_element(document, "g");
    SvgElement *element_g3   = svg_document_create_element(document, "g");
    SvgElement *element_rect = svg_document_create_element(document, "rect");

    SvgElementList *transform = svg_transform_new();
    svg_transform_set_rotate(transform, 0, 0, 0);
    SvgElementList *transform_list = svg_transform_list_new();
    svg_transform_list_append(transform_list, transform);
    svg_element_graphics_set_transform(element_g2, transform_list);

    //svg_document_append_child(document, element_g);
    svg_element_append(element_g1, element_g2);
    svg_element_append(element_g2, element_rect);
    svg_element_append(document->root, element_g1);
    svg_element_append(document->root, element_g3);

    svg_element_graphics_get_renderer(document->root);
*/
    /*gchar *str = svg_element_debug(SVG_ELEMENT(document->root), "", SVG_ELEMENT_PRINT_ALL_TESTABLE | (RENDERER_DUMP_ALL_TESTABLE & ~RENDERER_DUMP_RECURSIVE_FLAG));
    g_print("\n");
    g_print(str, "");// clear PLACE_HOLDER
    g_free(str);*/

    /*RendererObject *renderer = SVG_ELEMENT(document->root)->private_member->renderer;
    gchar *str_renderer = renderer_object_dump(renderer, "", RENDERER_DUMP_ALL);
    g_print("\n");
    g_print("%s\n", str_renderer);// clear PLACE_HOLDER
    //    g_print(str_renderer, "");// clear PLACE_HOLDER
    g_free(str_renderer);*/






    /*
    SvgElementSvg *element_svg = svg_document_get_root(document);
    SvgElement    *element_g   = svg_document_create_element(document, DOM_QUALIFIED_NAME("svg", "g"));

    SvgElement *element_svg  = svg_document_create_element(document, SVG_TYPE_ELEMENT_SVG);
    SvgElement *element_g    = svg_document_create_element(document, SVG_TYPE_ELEMENT_G);
    SvgElement *element_rect = svg_document_create_element(document, SVG_TYPE_ELEMENT_RECT);
    */
    //SwgElement *element_rect = svg_document_create_element_ns(document, "http://www...xlink.dlt", "xlink", SVG_TYPE_ELEMENT_RECT);

    //svg_document_append_child(document, element_g);// svg_element_appendChild(document->svg, g)


//public DOMElement DOMDocument::createElementNS ( string $namespaceURI , string $qualifiedName [, string $value ] )

    /*
    svg_document_appendChild(doc, g);// svg_element_appendChild(document->svg, g)
    svg_element_attache(svg, g);
    svg_element_attache(g, rect);
    */



}
#include <liblog/log.h>
#include <libxml/debugXML.h>

void
test_svg_new_test_dom(void) {
    SvgDocument    *models       = svg_document_load(TEST_SVG_SHARE_DIR"controls.svg");
    DomDocument    *dom_models   = DOM_DOCUMENT(models);

    SvgDocument    *svg          = svg_document_load(TEST_SVG_SHARE_DIR"empty.svg");
    DomDocument    *dom_svg      = DOM_DOCUMENT(svg);

    log_debug("%.*j\n", SVG_DUMP_ALL, models);

    //xmlDebugCheckDocument(stdout, dom_svg->xml);
    //xmlDebugDumpDocument(stdout, dom_svg->xml);
    //DomNode *root = dom_document_get_root(dom_svg);
    //xmlDebugDumpNode(stdout, root->xml, 1);
    //g_print("name = %s\n", root->xml->name);

    /*char *str = log_dump_to_string(LOG_DUMP(dom_svg), "", SVG_DUMP_ALL);
    g_print("%s", str);
    g_free(str);*/
    //log_debug("%.*j\n", SVG_DUMP_ALL, SVG_DOCUMENT(dom_svg));
    //log_debug("\n%.*j", SVG_DUMP_ALL, document);

    DomElement     *dom_element = NULL;
    gboolean found = dom_document_get_element_by_id(dom_models, "knot_anchor", &dom_element);

    g_assert(found);
    g_assert(dom_element);


    //SvgStyle *style = svg_element_get_style(dom_element);
    //style->fill_paint->data.color;
    //style->stroke_join
    DomElement *clone = dom_node_clone(dom_element, TRUE);
//    log_debug("%.*j\n", SVG_DUMP_ALL, SVG_ELEMENT(clone));

//    log_debug("%.*j\n", SVG_DUMP_ALL, dom_svg);
    SvgElementSvg *svg_root = svg_document_get_root(dom_svg);
    dom_element_append(svg_root, clone);
    //xmlDebugDumpDocument(stdout, dom_svg->xml);
    //xmlDebugDumpNode(stdout, DOM_NODE(clone)->xml, 1);
    svg_element_graphics_get_renderer(SVG_ELEMENT(clone));

    renderer_container_insert(
                SVG_ELEMENT(svg_root)->private_member->renderer,
                SVG_ELEMENT(clone)->private_member->renderer, -1);
   // svg_element_graphics_update_renderer(SVG_ELEMENT(svg_root));
    log_debug("%.*j\n", SVG_DUMP_ALL & ~SVG_DUMP_POINTER_FLAG, dom_svg);


    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 400, 400);
    cairo_t *cr = cairo_create(surface);
    svg_drawable_draw(svg_root, cr);

    cairo_surface_write_to_png(surface, TEST_SVG_BUILD_DIR"test.png");
    cairo_surface_destroy(surface);
    cairo_destroy(cr);


    /*
    //SvgElement* svg_element = dom_element->app_data;
*/
}

void
test_svg_new_use_symbol(void) {
    SvgDocument    *document     = svg_document_load(TEST_SVG_SHARE_DIR"controls.svg");
    DomDocument    *dom_document = DOM_DOCUMENT(document);

    SvgElement     *svg_element_use = dom_document_create_element(document, &DOM_QUALIFIED_NAME("svg", "use"));
    svg_element_use_set_href(svg_element_use, "#cube1");


    DomNode *root = dom_document_get_root(DOM_DOCUMENT(document));
    dom_element_append(DOM_ELEMENT(root), DOM_ELEMENT(svg_element_use));

    SvgElementSvg *svg_root = svg_document_get_root(document);
    RendererObject *renderer = svg_element_graphics_get_renderer(SVG_ELEMENT_GRAPHICS(svg_root));
    //log_debug("%.*j\n", RENDERER_DUMP_ALL, renderer);
    RendererObject *object = svg_element_graphics_get_renderer(SVG_ELEMENT_GRAPHICS(svg_element_use));
    //log_debug("%.*j\n", SVG_DUMP_ALL & ~SVG_DUMP_POINTER_FLAG & ~RENDERER_DUMP_POINTER_FLAG, document);
    renderer_container_insert(RENDERER_CONTAINER(renderer), RENDERER_OBJECT(object), -1);

    svg_element_graphics_update_graphics(SVG_ELEMENT_GRAPHICS(svg_element_use));

    //g_print("\n");
    //SvgElementSvg *svg_root = svg_document_get_root(document);
    //RendererObject *renderer = svg_element_graphics_get_renderer(SVG_ELEMENT_GRAPHICS(svg_root));
    //log_debug("%.*j\n", RENDERER_DUMP_ALL, renderer);

    //log_debug("%.*j\n", SVG_DUMP_ALL_TESTABLE, document);
    //xmlDebugDumpDocument(stdout, dom_document->xml);

    //xmlDebugDumpNode(stdout, DOM_NODE(svg_element_use)->xml, 1);
    //log_debug("%.*j\n", SVG_DUMP_ALL, svg_element_use);

    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 400, 400);
    cairo_t *cr = cairo_create(surface);
    svg_drawable_draw(svg_document_get_root(document), cr);

    cairo_surface_write_to_png(surface, TEST_SVG_BUILD_DIR"test.png");
    cairo_surface_destroy(surface);
    cairo_destroy(cr);
}

GTestSuite *
test_svg_new_create_suite(void) {

    GTestSuite *suite_svg_new = g_test_create_suite("new");

//    g_test_suite_add (suite_svg_new, TESTCASE (test_svg_new_test1, NULL));
//    g_test_suite_add (suite_svg_new, TESTCASE (test_svg_new_test_dom, NULL));
    g_test_suite_add (suite_svg_new, TESTCASE (test_svg_new_use_symbol, NULL));

	return suite_svg_new;
}
