/*
 * test-suite.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "test-suite.h"

#include "test-svg-length.h"
#include "test-svg-time.h"
#include "test-svg-color.h"
#include "test-svg-transform.h"
#include "test-svg-transform-list.h"
#include "test-svg-path.h"
#include "test-svg-new.h"
#include "test-svg-parser.h"
#include "test-svg-paint.h"
#include "test-svg-renderer.h"
#include "test-svg-hit-test.h"


GTestSuite*
test_svg_create_suite(void)
{
    GTestSuite *suite_svg = g_test_create_suite("libsvg");

    GTestSuite *suite_svg_length          = test_svg_length_create_suite();
    GTestSuite *suite_svg_time            = test_svg_time_create_suite();
    GTestSuite *suite_svg_color           = test_svg_color_create_suite();
    GTestSuite *suite_svg_transform       = test_svg_transform_create_suite();
    GTestSuite *suite_svg_transform_list  = test_svg_transform_list_create_suite();
    GTestSuite *suite_svg_path            = test_svg_path_create_suite();
    GTestSuite *suite_svg_new             = test_svg_new_create_suite();
    GTestSuite *suite_svg_parser          = test_svg_parser_create_suite();
    GTestSuite *suite_svg_paint           = test_svg_paint_create_suite();
    GTestSuite *suite_svg_renderer        = test_svg_renderer_create_suite();
    GTestSuite *suite_svg_hit_test        = test_svg_hit_test_create_suite();


    g_test_suite_add_suite(suite_svg, suite_svg_length);
    g_test_suite_add_suite(suite_svg, suite_svg_time);
    g_test_suite_add_suite(suite_svg, suite_svg_color);
    g_test_suite_add_suite(suite_svg, suite_svg_transform);
    g_test_suite_add_suite(suite_svg, suite_svg_transform_list);
    g_test_suite_add_suite(suite_svg, suite_svg_path);
    g_test_suite_add_suite(suite_svg, suite_svg_new);
    g_test_suite_add_suite(suite_svg, suite_svg_parser);
    g_test_suite_add_suite(suite_svg, suite_svg_paint);
    g_test_suite_add_suite(suite_svg, suite_svg_renderer);
    g_test_suite_add_suite(suite_svg, suite_svg_hit_test);


    return suite_svg;
}
