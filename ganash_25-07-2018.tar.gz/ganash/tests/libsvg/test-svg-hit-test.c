#include "test-svg-hit-test.h"

#include <liblog/log.h>

#include <glib-object.h>
#include <cairo/cairo.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-scene.h"

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-time.h"
#include "libsvg/svg-length.h"
#include "libsvg/svg-document.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-element-animation.h"
#include "libsvg/svg-animated-type-animator.h"
#include "libsvg/svg-element-animate.h"


void
test_svg_hit_test_test1(void) {
    SvgDocument *svg_document = svg_document_load(TEST_SVG_SHARE_DIR "square.svg");
    SvgElement  *result       = svg_document_hit(svg_document, 100.0, 150.0);

    g_assert(result);
    g_assert_cmpstr(G_OBJECT_TYPE_NAME(result), ==, "SvgElementRect");
    g_assert_cmpstr(result->attribute_id, ==, "blue_square");
}

void
test_svg_hit_test_test2(void) {
    SvgDocument *svg_document = svg_document_load(TEST_SVG_SHARE_DIR "square.svg");
    SvgElement  *result       = svg_document_hit(svg_document, 80.0, 250.0);

    g_assert(result);
    g_assert_cmpstr(result->attribute_id, ==, "use_blue_square");
    g_assert_cmpstr(G_OBJECT_TYPE_NAME(result), ==, "SvgElementUse");

    result = svg_document_hit(svg_document, 0.0, 0.0);
    g_assert(!result);
}

static gint
my_compare (gconstpointer a,
        gconstpointer b)
{
  const char *cha = a;
  const char *chb = b;

  return *cha - *chb;
}

void
test_svg_hit_test_test3(void) {


/*
    SvgElementRect *rect = svg_element_rect_new();
    SvgElementAnimate *animate = svg_element_animate_new();
    SvgElementAnimation *animation = SVG_ELEMENT_ANIMATION(animate);
    animation->begin = svg_time_new();
    gchar *name = "rect#123:xml#x-x123";
    guint   id = g_str_hash(name);

    //<SvgElement *, AttributeName>, GArray<SvgElementAnimation* >;
    //<"css:x:rect123", GArray<SvgElementAnimation* >;
    gpointer key = &id;
    gchar *value = "A";// {SvgElement*(rect), DomQualifiedName(x), GArray<SvgElementAnimation*>}

    GTree *tree = g_tree_new(my_compare);
    g_tree_insert (tree, key, value);
*/

}

GTestSuite *
test_svg_hit_test_create_suite(void) {
    GTestSuite *suite_svg_hit_test = g_test_create_suite("hit-test");

    g_test_suite_add (suite_svg_hit_test, TESTCASE (test_svg_hit_test_test1, NULL));
    g_test_suite_add (suite_svg_hit_test, TESTCASE (test_svg_hit_test_test2, NULL));
    g_test_suite_add (suite_svg_hit_test, TESTCASE (test_svg_hit_test_test3, NULL));

	return suite_svg_hit_test;
}
