/*
 * test-svg-time.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "test-svg-time.h"

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-time.h"
#include "libsvg/svg-parser.h"

void
test_svg_time_parse_full_clock(void)
{
    gchar *string = "<times=\"01:01:01.001\" >";

    gchar *ptr = &string[8];
    gchar *end = &string[8+13];
    /*gchar* str = g_strndup(ptr, 3);*/

    SvgTime *time = svg_time_new();
    gchar *token = svg_parser_parse_time(time, ptr, end);

    g_assert(token == end);
    g_assert_cmpfloat(time->seconds, ==, 3661.001);/*3600 + 60 + 1.001*/
}
void
test_svg_time_set_value_from_buffer(void)
{
    gchar *string = "<times=\"17.3s\" >";

    gchar *ptr = &string[8];
    gchar *end = &string[8+5];
    /*gchar* str = g_strndup(ptr, 3);*/

    SvgTime *time = svg_time_new();
    gchar *token = svg_parser_parse_time(time, ptr, end);

    g_assert(token == end);
    g_assert_cmpfloat(time->seconds, ==, 17.3);
}


void
test_svg_time_parse_list(void)
{
    gchar *string = "<begin=\"0s; 2s; 4s\" >";

    gchar *ptr = &string[8];
    gchar *end = &string[8+10];
    /*gchar* str = g_strndup(ptr, 3);*/

    GArray *times = (GArray*) svg_time_list_new();
    gchar *token = svg_parser_parse_time_list(times, ptr, end);

    g_assert(times->len == 3);
    //g_assert(token == end);
    SvgTime *time;
    time = &g_array_index(times, SvgTime, 0);
    g_assert_cmpfloat(time->seconds, ==, 0.0);

    time = &g_array_index(times, SvgTime, 1);
    g_assert_cmpfloat(time->seconds, ==, 2.0);

    time = &g_array_index(times, SvgTime, 2);
    g_assert_cmpfloat(time->seconds, ==, 4.0);
}


GTestSuite *
test_svg_time_create_suite(void)
{
    GTestSuite *suite_svg = g_test_create_suite("time");

    g_test_suite_add (suite_svg, TESTCASE (test_svg_time_parse_full_clock, NULL));
    g_test_suite_add (suite_svg, TESTCASE (test_svg_time_set_value_from_buffer, NULL));
    g_test_suite_add (suite_svg, TESTCASE (test_svg_time_parse_list, NULL));

    return suite_svg;
}
