/*
 * test-svg-color.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "test-svg-color.h"

#include <liblog/log.h>

#include <libgraphics/graphics.h>

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>


#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-color.h"
#include "libsvg/svg-color-icc.h"
#include "libsvg/svg-parser.h"

#include <math.h>
#include <string.h>

static void
test_svg_parser_parse_color_hex_short(void)
{
    gchar *string = "stroke: #F07;";

    gchar *ptr = &string[8];
    gchar *end = &string[8+4];
    gchar *str = g_strndup(ptr, 4);

    SvgColor color;
    gchar *token = svg_parser_parse_color(&color, ptr, end);

    g_assert(token != NULL);
    g_assert(token == end);
    g_assert_cmphex(color.value, ==, 0xFFFF0077);
}
static void
test_svg_parser_parse_color_hex(void)
{
    gchar *string = "stroke: #FF007F;";

    gchar *ptr = &string[7];
    gchar *end = &string[7+8];
    gchar *str = g_strndup(ptr, 8);

    SvgColor color;
    gchar *token = svg_parser_parse_color(&color, ptr, end);

    g_assert(token != NULL);
    g_assert(token == end);
    g_assert_cmphex(color.value, ==, 0xFFFF007F);
}

void
test_svg_parser_parse_color_rgba(void)
{
    gchar *string = "stroke: rgba(1.0, 0.0, 0.5, 0.5);";

    gchar *ptr = &string[7];
    gchar *end = &string[7+25];
    gchar *str = g_strndup(ptr, 25);

    SvgColor color;
    gchar *token = svg_parser_parse_color(&color, ptr, end);

    g_assert(token != NULL);
    g_assert(token == end);
    g_assert_cmphex(color.value, ==, 0x80FF0080);
}


void
test_svg_parser_parse_color_rgb_spaced(void)
{
    gchar *string = "stroke: rgb (  127, 0, 255  );";

    gchar *ptr = &string[7];
    gchar *end = &string[7+22];
    gchar *str = g_strndup(ptr, 22);
    SvgColor color;
    gchar *token = svg_parser_parse_color(&color, ptr, end);

    g_assert(token != NULL);
    g_assert(token == end);
    g_assert_cmphex(color.value, ==, 0xFF7F00FF);
}

void
test_svg_parser_parse_color_rgb(void)
{
    gchar *string = "rgb(127,0,255)";

    gchar *end = string + strlen(string);
    SvgColor color;
    gchar *token = svg_parser_parse_color(&color, string, end);

    g_assert(token != NULL);
    g_assert(token == end);
    g_assert_cmphex(color.value, ==, 0xFF7F00FF);
}

void
test_svg_parser_parse_color_icc(void)
{
    gchar *string = "stroke: yellow;";

    gchar *ptr = &string[7];
    gchar *end = &string[7+7];
    gchar *str = g_strndup(ptr, 7);
    SvgColor color;
    gchar *token = svg_parser_parse_color(&color, ptr, end);

    g_assert(token != NULL);
    g_assert(token == end);
    g_assert_cmphex(color.value, ==, 0xFFFFFF00);
}


void
test_svg_parser_parse_color_icc_green(void)
{
    gchar *ptr = "green";
    gchar *end = ptr+strlen(ptr);
    SvgColor color;
    gchar *token = svg_parser_parse_color(&color, ptr, end);

    g_assert(token != NULL);
    g_assert(token == end);
    g_assert_cmphex(color.value, ==, 0xFF008000);
}

void
test_svg_parser_parse_color_icc_red(void)
{
    gchar *ptr = "red";
    gchar *end = ptr+strlen(ptr);
    SvgColor color;
    gchar *token = svg_parser_parse_color(&color, ptr, end);

    g_assert(token != NULL);
    g_assert(token == end);
    g_assert_cmphex(color.value, ==, 0xFFFF0000);
}

GTestSuite *
test_svg_color_create_suite(void)
{
    GTestSuite *suite_svg_color = g_test_create_suite("color");

    g_test_suite_add (suite_svg_color, TESTCASE (test_svg_parser_parse_color_hex_short, NULL));
    g_test_suite_add (suite_svg_color, TESTCASE (test_svg_parser_parse_color_hex, NULL));
    g_test_suite_add (suite_svg_color, TESTCASE (test_svg_parser_parse_color_rgba, NULL));
    g_test_suite_add (suite_svg_color, TESTCASE (test_svg_parser_parse_color_rgb_spaced, NULL));
    g_test_suite_add (suite_svg_color, TESTCASE (test_svg_parser_parse_color_rgb, NULL));
    g_test_suite_add (suite_svg_color, TESTCASE (test_svg_parser_parse_color_icc, NULL));
    g_test_suite_add (suite_svg_color, TESTCASE (test_svg_parser_parse_color_icc_green, NULL));
    g_test_suite_add (suite_svg_color, TESTCASE (test_svg_parser_parse_color_icc_red, NULL));

    return suite_svg_color;
}
