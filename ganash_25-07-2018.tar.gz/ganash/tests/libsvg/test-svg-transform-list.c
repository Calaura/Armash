/*
 * test-svg-transform.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "test-svg-transform-list.h"

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include <cairo/cairo.h>
#include "libsvg/svg-matrix.h"
#include "libsvg/svg-transform.h"
#include "libsvg/svg-transform-list.h"
#include "libsvg/svg-parser.h"


void
test_svg_parser_parse_transform_list(void)
{
    gchar *string = "transform=\"translate(1.1, 12.3), rotate(.00)\" ";

    gchar *ptr = &string[11];
    gchar *end = &string[44];
    gchar *str = g_strndup(ptr, 33);

    SvgTransformList *transform_list = svg_transform_list_new();
    gchar *token = svg_parser_parse_transform(transform_list, ptr, end);
    SvgMatrix* matrix = svg_transform_list_to_matrix(transform_list);

    g_free(str);
    g_assert(token != NULL);
    g_assert(token == &string[44]);
    g_assert(*token == '"');

    g_assert(matrix->cairo_matrix.x0 == 1.1);
    g_assert(matrix->cairo_matrix.xy == 0.0);
    g_assert(matrix->cairo_matrix.xx == 1.0);
    g_assert(matrix->cairo_matrix.y0 == 12.3);
    g_assert(matrix->cairo_matrix.yx == 0.0);
    g_assert(matrix->cairo_matrix.yy == 1.0);
}


GTestSuite *
test_svg_transform_list_create_suite(void)
{
    GTestSuite *suite_svg_transform_list = g_test_create_suite("transform_list");
    g_test_suite_add (suite_svg_transform_list, TESTCASE (test_svg_parser_parse_transform_list, NULL));

    return suite_svg_transform_list;
}
