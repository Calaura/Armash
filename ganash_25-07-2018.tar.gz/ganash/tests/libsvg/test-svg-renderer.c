#include "test-svg-renderer.h"

#include <liblog/log.h>

#include <libgraphics/graphics.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-shape.h"

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-document.h"


void
test_svg_renderer_test1(void)
{
    cairo_t *cr;
    cairo_surface_t *surface;
    unsigned char *data_surface;
    int width_surface  = 300;
    int height_surface = 400;

    cairo_surface_t *image;
    unsigned char *data_image;
    int width_image;
    int height_image;

    surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 300, 400);
    cr = cairo_create(surface);
    SvgDocument *doc = svg_document_load(TEST_SVG_SHARE_DIR "square.test.svg");
    svg_document_draw(doc, cr);



    data_surface   = cairo_image_surface_get_data(surface);
    width_surface  = cairo_image_surface_get_width(surface);
    height_surface = cairo_image_surface_get_height(surface);



    //cairo_surface_write_to_png(surface, TEST_SVG_BUILD_DIR "square.png");
    image = cairo_image_surface_create_from_png (TEST_SVG_SHARE_DIR "square.test.png");


    data_image   = cairo_image_surface_get_data(image);
    width_image  = cairo_image_surface_get_width(image);
    height_image = cairo_image_surface_get_height(image);

    g_assert_cmpint(width_surface, ==, width_image);
    g_assert_cmpint(height_surface, ==, height_image);

    int rst = memcmp (data_surface, data_image, width_surface * height_surface);
    g_assert_cmpint(rst, ==, 0);

    cairo_surface_destroy(image);
    cairo_surface_destroy(surface);
    cairo_destroy(cr);
}


GTestSuite *
test_svg_renderer_create_suite(void) {
    GTestSuite *suite_svg_renderer = g_test_create_suite("renderer");


	g_test_suite_add (suite_svg_renderer, TESTCASE (test_svg_renderer_test1, NULL));

	return suite_svg_renderer;
}

