/*
 * test-svg-path.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"

#include <libgraphics/graphics.h>

#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-rect.h"

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-path.h"
#include "libsvg/svg-length.h"
#include "libsvg/svg-paint.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-path.h"
#include "libsvg/svg-parser.h"

#include <string.h>
#include "test-svg-path.h"

void
test_svg_path_parse(void)
{
    gchar *string = "<path d=\"M 0.5 0.5, C 50.5 0.5 50.5 100.5 100.5 100.5 C 150.5 100.5 150.5 0.5 200.5 0.5\" >";

    gchar *ptr = &string[9];
    gchar *end = &string[9+78];
    gchar* str = g_strndup(ptr, end-ptr);

    SvgPath *svg_path = svg_path_new();
    svg_parser_parse_path_from_buffer(svg_path, ptr, end);

    g_assert(g_list_length(svg_path->segments) == 3);


    /*int i;
    cairo_path_t *path;
    cairo_path_data_t *data;

    path = svg_path_get_cairo_path(svg_path);

    for (i=0; i < path->num_data; i += path->data[i].header.length) {
        data = &path->data[i];
        switch (data->header.type) {
        case CAIRO_PATH_MOVE_TO:
            g_print ("%f, %f\n", data[1].point.x, data[1].point.y);
            break;
        case CAIRO_PATH_LINE_TO:
            g_print ("%f, %f\n", data[1].point.x, data[1].point.y);
            break;
        case CAIRO_PATH_CURVE_TO:
            g_print ("%f, %f, %f, %f, %f, %f\n", data[1].point.x, data[1].point.y,
                                data[2].point.x, data[2].point.y,
                                data[3].point.x, data[3].point.y);
            break;
        case CAIRO_PATH_CLOSE_PATH:
            g_print ("close\n");
            break;
        }
    }
    cairo_path_destroy (path);*/
}

#include <libgraphics/graphics.h>
void
test_svg_path_parse_rel(void)
{
    gchar *string = "m 12.067211,273.42684 c 7.384162,0.11154 14.710714,-6.23562 18.52178,-7.85774 3.811066,-1.62212 6.424475,-5.59033 11.318865,-5.79973 7.870952,-0.14326 16.956153,8.54652 28.9052,9.07379 11.949047,0.52727 30.773394,-9.33387 40.504694,-8.88671 5.56412,0.31487 7.35186,4.22709 16.18317,5.14494 8.83131,0.91785 27.60418,-3.27366 36.10812,-3.64823 8.50394,-0.37457 14.78,0.18709 14.78,0.18709";
/*
Move{12.067211, 273.426840},
Curve{19.451373, 273.538380, 26.777925, 267.191220, 30.588991, 265.569100},
Curve{34.400057, 263.946980, 37.013466, 259.978770, 41.907856, 259.769370},
Curve{49.778808, 259.626110, 58.864009, 268.315890, 70.813056, 268.843160},
Curve{82.762103, 269.370430, 101.586450, 259.509290, 111.317750, 259.956450},
Curve{116.881870, 260.271320, 118.669610, 264.183540, 127.500920, 265.101390},
Curve{136.332230, 266.019240, 155.105100, 261.827730, 163.609040, 261.453160},
Curve{172.112980, 261.078590, 178.389040, 261.640250, 178.389040, 261.640250}
*/

    gchar *ptr = string;
    gchar *end = string + strlen(string);

    SvgPath *svg_path = svg_path_new();
    svg_parser_parse_path_from_buffer(svg_path, ptr, end);

    cairo_path_t* p = svg_path_get_cairo_path(svg_path);
    /*gchar *str = graphics_path_debug(p);
    g_print("%s\n", str);
    g_free(str);*/

    g_assert_cmpint(g_list_length(svg_path->segments), ==, 8);
}

GTestSuite *
test_svg_path_create_suite(void)
{
    GTestSuite *suite_svg = g_test_create_suite("path");

    g_test_suite_add (suite_svg, TESTCASE (test_svg_path_parse, NULL));
    g_test_suite_add (suite_svg, TESTCASE (test_svg_path_parse_rel, NULL));

    return suite_svg;
}
