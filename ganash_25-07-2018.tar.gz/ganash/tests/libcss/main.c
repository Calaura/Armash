

#include "tests/lib.h"

#include "test-svg-length.h"

int
main(int argc, char *argv[])
{
    g_test_init (&argc, &argv, NULL);

    GTestSuite *suite = g_test_get_root();

    GTestSuite *suite_svg_length = testsuite_svg_length();
    g_test_suite_add_suite(suite, suite_svg_length);

    g_test_run_suite(suite);

    return 0;
}
