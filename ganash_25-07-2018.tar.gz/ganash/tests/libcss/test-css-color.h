/*
 * test-svg-length.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __TEST_SVG_LENGTH_H__
#define __TEST_SVG_LENGTH_H__


#include "tests/lib.h"


void test_svg_parser_parse_double(void);

void test_svg_length_set_value_from_buffer(void);

void test_svg_length_list_parse(void);

GTestSuite *
testsuite_svg_length(void);

#endif /* __TEST_SVG_LENGTH_H__ */
