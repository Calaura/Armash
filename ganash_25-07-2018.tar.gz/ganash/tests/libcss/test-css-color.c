/*
 * test-svg-length.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "test-svg-length.h"

/*A revoir*/
/*#include "libsvg/svg-types.h"
#include "libsvg/svg-parser.h"*/
#include "libsvg/svg-length.h"
#include "libsvg/svg-length-list.h"

#include <math.h>


void
test_svg_parser_parse_double(void)
{
    double result = 123.0;
    gchar *string = "<values=\"123\" >";

    gchar *ptr = &string[9];
    gchar *end = &string[9+3];
    double number;
    gchar* token = svg_parser_parse_double(ptr, end, &number, FALSE);

    g_assert(token != NULL);
    g_assert(number == result);

}


void
test_svg_length_set_value_from_buffer(void)
{
    double result = 123.0;
    gchar *string = "<values=\"123px\" >";

    gchar *ptr = &string[9];
    gchar *end = &string[9+5];
    SvgLength* length = g_new(SvgLength, 1);
    gboolean success = svg_length_set_value_from_string(length, ptr, end);

    g_assert(success == TRUE);
    g_assert(length->value == result);

}



void
test_svg_length_list_parse(void)
{
    gchar *string = "<values=\"1.23px 456 7.8E2em\" >";

    gchar *ptr = &string[9];
    gchar *end = &string[9+18];
    double number;
    gchar* str = g_strndup(ptr, 18);
    GArray* list = svg_length_list_parse(str, SVG_LENGTH_MODE_WIDTH);

    g_assert(list->len == 3);

    SvgLength* length;
    length = g_array_index(list, SvgLength*, 0);
    g_assert(length->value == 1.23);

    length = g_array_index(list, SvgLength*, 1);
    g_assert(length->value == 456);

    length = g_array_index(list, SvgLength*, 2);
    g_assert(length->value == 780.0);

}


GTestSuite *
testsuite_svg_length(void)
{
    GTestSuite *suite_svg = g_test_create_suite("libsvg");

    g_test_suite_add (suite_svg, TESTCASE (test_svg_parser_parse_double, NULL));
    g_test_suite_add (suite_svg, TESTCASE (test_svg_length_set_value_from_buffer, NULL));

    g_test_suite_add (suite_svg, TESTCASE (test_svg_length_list_parse, NULL));

    return suite_svg;
}
