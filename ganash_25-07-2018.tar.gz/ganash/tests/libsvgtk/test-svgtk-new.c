#include "test-svgtk-new.h"

#include <liblog/log.h>

#include <libxml/tree.h>

#include <libgraphics/graphics.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-scene.h"

#include "libdom/dom-types.h"
#include "libdom/dom-enums.h"
#include "libdom/dom-document.h"
#include "libdom/dom-parser.h"

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-document.h"

#include "libsvgtk/svgtk-types.h"
#include "libsvgtk/svgtk-enums.h"
#include "libsvgtk/svgtk-document.h"

void
test_svgtk_new_test1(void) {
    SvgtkDocument *document = svgtk_document_load(TEST_SVGTK_SHARE_DIR"bounding.svgtk");
    SvgDocument *doc = SVG_DOCUMENT(document);

    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 400, 400);
    cairo_t *cr = cairo_create(surface);
    //svg_drawable_draw(svg_document_get_root(document), cr);
    svg_document_draw(doc, cr);

    cairo_surface_write_to_png(surface, TEST_SVGTK_BUILD_DIR"test.png");
    cairo_surface_destroy(surface);
    cairo_destroy(cr);

    /*
    LogDumpOptions options = LogDumpOptionsEmpty;
    options.flags = SVG_DUMP_ALL & ~DOM_DUMP_POINTER_FLAG;
    char *str = log_dump_to_string(LOG_DUMP(document), &options);
    g_print("%s\n", str);
    g_free(str);
    log_debug("%.*j\n", SVG_DUMP_ALL, document);
    */

}

GTestSuite *
test_svgtk_new_create_suite(void) {
    GTestSuite *suite_svgtk_new = g_test_create_suite("new");

	g_test_suite_add (suite_svgtk_new, TESTCASE (test_svgtk_new_test1, NULL));

	return suite_svgtk_new;
}

