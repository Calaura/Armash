/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * test-log-debug.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __TEST_LOG_DEBUG_H__
#define __TEST_LOG_DEBUG_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define TEST_TYPE_LOG_DEBUG            (test_log_debug_get_type())
#define TEST_LOG_DEBUG(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), TEST_TYPE_LOG_DEBUG, TestLogDebug))
#define TEST_LOG_DEBUG_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), TEST_TYPE_LOG_DEBUG, TestLogDebugClass))
#define TEST_IS_LOG_DEBUG(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TEST_TYPE_LOG_DEBUG))
#define TEST_IS_LOG_DEBUG_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), TEST_TYPE_LOG_DEBUG))
#define TEST_LOG_DEBUG_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), TEST_TYPE_LOG_DEBUG, TestLogDebugClass))

typedef struct _TestLogDebug TestLogDebug;
typedef struct _TestLogDebugClass TestLogDebugClass;

struct _TestLogDebug {
	GObject parent_instance;
};

struct _TestLogDebugClass {
	GObjectClass parent_class;
};

GType test_log_debug_get_type();
TestLogDebug *test_log_debug_new();



#include "tests/lib.h"
///#define TEST_LOG_DEBUG(t, d) g_test_create_case (#t, 0, d, NULL, (TCFunc) test_log_debug_##t, NULL)

GTestSuite *test_log_debug_create_suite(void);

G_END_DECLS

#endif /* __TEST_LOG_DEBUG_H__ */

