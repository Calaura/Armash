#include "test-suite.h"

#include "test-log-debug.h"

GTestSuite *
test_log_create_suite(void) {
    GTestSuite *suite_log = g_test_create_suite("liblog");

    GTestSuite *suite_log_debug = test_log_debug_create_suite();
    g_test_suite_add_suite(suite_log, suite_log_debug);

    return suite_log;
}

