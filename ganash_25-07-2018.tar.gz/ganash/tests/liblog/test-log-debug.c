/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * test-log-debug.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "test-log-debug.h"

#include "liblog/log-dump.h"
#include "liblog/log-debug.h"


static void test_log_debug_class_init(TestLogDebugClass *klass);
static void test_log_debug_init(TestLogDebug *gobject);

static void test_log_debug_dump_interface_init (LogDumpInterface *iface);

G_DEFINE_TYPE_WITH_CODE (TestLogDebug, test_log_debug, G_TYPE_OBJECT,
                         G_IMPLEMENT_INTERFACE (LOG_TYPE_DUMP,
                                                test_log_debug_dump_interface_init))

/*G_DEFINE_TYPE_WITH_CODE (TestLogDebug, test_log_debug, G_TYPE_OBJECT,
                         LOG_IMPLEMENT_DUMP (test_log_debug_dump_interface_init))*/

//G_DEFINE_TYPE (TestLogDebug, test_log_debug, G_TYPE_OBJECT)

static void
test_log_debug_init (TestLogDebug *object)
{
}
static void
test_log_debug_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (test_log_debug_parent_class)->finalize (object);
}
static void
test_log_debug_class_init(TestLogDebugClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = test_log_debug_finalize;

//	test_log_debug_parent_class = g_type_class_peek_parent (klass);
}

static gchar*
test_log_debug_dump_to_string(LogDump *object, gchar *indent, guint flags) {

    GObject *g_object = G_OBJECT(object);

    return g_strdup_printf("[%s@%p{foo: TRUE, bar:\"%s\"}]", G_OBJECT_TYPE_NAME(g_object), g_object, "baz");
}

static void
test_log_debug_dump_interface_init (LogDumpInterface *iface)
{
    iface->to_string = test_log_debug_dump_to_string;
}

TestLogDebug *
test_log_debug_new (void)
{
	return g_object_new (test_log_debug_get_type (),
	                     NULL);
}

#include "test-log-debug.h"

void
test_log_debug_test1(void) {
    g_test_message("Not implemented");
    /* Add asserts */
    TestLogDebug *test_log_debug = test_log_debug_new();
    //log_debug(test_log_debug);

    /*gchar *str = log_dump_to_string(test_log_debug, 0);
    g_print("%s\n", str);
    g_free(str);*/

    guint max_recursion = 6;
    guint flags_precision = 6;
    log_debug("%*.*j", max_recursion, flags_precision, test_log_debug);// recusion prior
    log_debug("%.*j", flags_precision, test_log_debug);// recusion prior
    log_debug("%j", test_log_debug);
    GObject *obj = NULL;
    log_debug("%j", obj);


    g_object_unref(test_log_debug);
}

GTestSuite *
test_log_debug_create_suite(void) {
    g_type_init();

    GTestSuite *suite_log_debug = g_test_create_suite("debug");

    g_test_suite_add (suite_log_debug, TESTCASE (test_log_debug_test1, NULL));

    return suite_log_debug;
}
