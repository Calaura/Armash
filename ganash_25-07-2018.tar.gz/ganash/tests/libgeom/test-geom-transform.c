#include "test-geom-transform.h"
#include <cairo/cairo.h>

#include <stdlib.h>

#if !defined (M_PI)
#define M_PI 3.14159265358979323846264338327
#endif

/*
typedef struct _Math_Matrix Math_Matrix;
struct _Math_Matrix {
    double xx; double yx;
    double xy; double yy;
    double x0; double y0;
};

Math_Matrix *
math_matrix_new(double xx, double yx, double xy, double yy, double x0, double y0)
{
    Math_Matrix *matrix = (Math_Matrix *) malloc(sizeof(Math_Matrix));

    matrix->xx = xx; matrix->yx = yx;
    matrix->xy = xy; matrix->yy = yy;
    matrix->x0 = x0; matrix->y0 = y0;

    return matrix;
}

//#define math_matrix_new_identity() math_matrix_new(1, 0, 0, 1, 0, 0)
Math_Matrix *
math_matrix_new_identity()
{
    return math_matrix_new(1, 0, 0, 1, 0, 0);
}

void
math_matrix_init_translate (Math_Matrix *matrix, double tx, double ty)
{
    cairo_matrix_init (matrix,
               1, 0,
               0, 1,
               tx, ty);
}

void
math_matrix_translate (Math_Matrix *matrix, double tx, double ty)
{
    Math_Matrix tmp;

    math_matrix_init_translate (&tmp, tx, ty);

    math_matrix_multiply (matrix, &tmp, matrix);
}
*/



void
test_geom_transform_test1(void) {
	g_test_message("Not implemented");

    cairo_matrix_t *matrix_translate = (cairo_matrix_t *) malloc(sizeof(cairo_matrix_t));
    cairo_matrix_init_translate(matrix_translate, 10.0, 10.0);
    cairo_matrix_t *matrix_rotate = (cairo_matrix_t *) malloc(sizeof(cairo_matrix_t));
    cairo_matrix_init_rotate(matrix_rotate, 45*M_PI/180);

    cairo_matrix_t *matrix = (cairo_matrix_t *) malloc(sizeof(cairo_matrix_t));
    cairo_matrix_init_identity(matrix);
    {
        g_assert (matrix->xx == 1);
        g_assert (matrix->yx == 0);
        g_assert (matrix->xy == 0);
        g_assert (matrix->yy == 1);
        g_assert (matrix->x0 == 0);
        g_assert (matrix->y0 == 0);
    }


    cairo_matrix_multiply(matrix, matrix_rotate, matrix_translate);
    g_printf ("%f\n", matrix->xx);
    g_printf ("%f\n", matrix->yx);
    g_printf ("%f\n", matrix->xy);
    g_printf ("%f\n", matrix->yy);
    g_printf ("%f\n", matrix->x0);
    g_printf ("%f\n", matrix->y0);


    free(matrix);
}

GTestSuite *
test_geom_transform_create_suite(void) {
    GTestSuite *suite_geom_transform = g_test_create_suite("transform");

	g_test_suite_add (suite_geom_transform, TESTCASE (test_geom_transform_test1, NULL));

	return suite_geom_transform;
}
