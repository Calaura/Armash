#include "test-geom-box.h"

#include "libgeom/geom-box.h"

void
test_geom_box_test1(void) {
    GeomBox box = {G_MAXDOUBLE, -G_MAXDOUBLE, -G_MAXDOUBLE, G_MAXDOUBLE};

    GeomBox box1;
    box1.left = 10.0;
    box1.top = 50.0;
    box1.right = 50.0;
    box1.bottom = 10.0;

    GeomBox box2;
    box2.left = 20.0;
    box2.top = 60.0;
    box2.right = 60.0;
    box2.bottom = 20.0;

    geom_box_merge(&box2, &box1);

    g_assert_cmpfloat(box2.left, ==, 10);
    g_assert_cmpfloat(box2.top, ==, 60);
    g_assert_cmpfloat(box2.right, ==, 60);
    g_assert_cmpfloat(box2.bottom, ==, 10);
    //g_print("\n");
    //g_print("Box{%f, %f, %f, %f}\n", box1.left, box1.top, box1.right, box1.bottom);
    //g_print("Box{%f, %f, %f, %f}\n", box2.left, box2.top, box2.right, box2.bottom);

}

void
test_geom_box_test2(void) {
    GeomBox box = {G_MAXDOUBLE, -G_MAXDOUBLE, -G_MAXDOUBLE, G_MAXDOUBLE};

    GeomBox box1;
    box1.left = 10.0;
    box1.top = 50.0;
    box1.right = 50.0;
    box1.bottom = 10.0;

    GeomBox box2;
    box2.left = 20.0;
    box2.top = 60.0;
    box2.right = 60.0;
    box2.bottom = 20.0;

    geom_box_merge(&box1, &box2);

    g_assert_cmpfloat(box1.left, ==, 10);
    g_assert_cmpfloat(box1.top, ==, 60);
    g_assert_cmpfloat(box1.right, ==, 60);
    g_assert_cmpfloat(box1.bottom, ==, 10);
    //g_print("\n");
    //g_print("Box{%f, %f, %f, %f}\n", box1.left, box1.top, box1.right, box1.bottom);
    //g_print("Box{%f, %f, %f, %f}\n", box2.left, box2.top, box2.right, box2.bottom);

}

void
test_geom_box_test3(void) {
    GeomBox box = {G_MAXDOUBLE, -G_MAXDOUBLE, -G_MAXDOUBLE, G_MAXDOUBLE};

    GeomBox box1;
    box1.left = 10.0;
    box1.top = 100.0;
    box1.right = 50.0;
    box1.bottom = 50.0;

    GeomBox box2;
    box2.left = 20.0;
    box2.top = 60.0;
    box2.right = 60.0;
    box2.bottom = 20.0;

    geom_box_merge(&box1, &box2);

    g_assert_cmpfloat(box1.left, ==, 10);
    g_assert_cmpfloat(box1.top, ==, 100);
    g_assert_cmpfloat(box1.right, ==, 60);
    g_assert_cmpfloat(box1.bottom, ==, 20);
    //g_print("\n");
    //g_print("Box{%f, %f, %f, %f}\n", box1.left, box1.top, box1.right, box1.bottom);
    //g_print("Box{%f, %f, %f, %f}\n", box2.left, box2.top, box2.right, box2.bottom);
}

void
test_geom_box_test4(void) {
    GeomBox box = {G_MAXDOUBLE, -G_MAXDOUBLE, -G_MAXDOUBLE, G_MAXDOUBLE};

    GeomBox box1;
    box1.left = 10.0;
    box1.top = 100.0;
    box1.right = 50.0;
    box1.bottom = 50.0;

    GeomBox box2;
    box2.left = 20.0;
    box2.top = 60.0;
    box2.right = 60.0;
    box2.bottom = 20.0;

    geom_box_merge(&box2, &box1);

    g_assert_cmpfloat(box2.left, ==, 10);
    g_assert_cmpfloat(box2.top, ==, 100);
    g_assert_cmpfloat(box2.right, ==, 60);
    g_assert_cmpfloat(box2.bottom, ==, 20);
    //g_print("\n");
    //g_print("Box{%f, %f, %f, %f}\n", box1.left, box1.top, box1.right, box1.bottom);
    //g_print("Box{%f, %f, %f, %f}\n", box2.left, box2.top, box2.right, box2.bottom);
}

GTestSuite *
test_geom_box_create_suite(void) {
    GTestSuite *suite_geom_box = g_test_create_suite("box");

    g_test_suite_add (suite_geom_box, TESTCASE (test_geom_box_test1, NULL));
    g_test_suite_add (suite_geom_box, TESTCASE (test_geom_box_test2, NULL));
    g_test_suite_add (suite_geom_box, TESTCASE (test_geom_box_test3, NULL));
    g_test_suite_add (suite_geom_box, TESTCASE (test_geom_box_test4, NULL));

	return suite_geom_box;
}

