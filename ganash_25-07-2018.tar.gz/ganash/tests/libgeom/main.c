

#include "test-suite.h"

#include <math.h>

int
main(int argc, char *argv[])
{
    g_test_init (&argc, &argv, NULL);

    GTestSuite *suite = g_test_get_root();

    GTestSuite *suite_geom = test_geom_create_suite();
    g_test_suite_add_suite(suite, suite_geom);

    g_test_run_suite(suite);

    return 0;
}

/*

static void
test_geom_rectangle_merge (void)
{
  /*
  // a suitable test
  g_assert (g_bit_storage (1) == 1);
  // a test with verbose error message
  g_assert_cmpint (g_bit_storage (1), ==, 1);
  * /
    /* chevauchement * /
    GeomRectangle rect1 = { 0,  0, 10, 10};
    GeomRectangle rect2 = {5, 5, 10, 10};
    geom_rectangle_merge(&rect1, &rect2);
    g_assert (rect1.x == 0);
    g_assert (rect1.y == 0);
    g_assert (rect1.width  == 15);
    g_assert (rect1.height == 15);


    /* colission * /
    GeomRectangle rect3 = {10, 10, 10, 10};
    GeomRectangle rect4 = { 0,  0, 10, 10};
    geom_rectangle_merge(&rect3, &rect4);
    g_assert (rect3.x == 0);
    g_assert (rect3.y == 0);
    g_assert (rect3.width  == 20);
    g_assert (rect3.height == 20);


    /* intersection * /
    GeomRectangle rect5 = {10, 10, 10, 10};
    GeomRectangle rect6 = {12, 12,  6,  6};
    geom_rectangle_merge(&rect5, &rect6);
    g_assert (rect5.x == 10);
    g_assert (rect5.y == 10);
    g_assert (rect5.width  == 10);
    g_assert (rect5.height == 10);

    /* disociate * /
    GeomRectangle rect7 = {10, 10, 10, 10};
    GeomRectangle rect8 = {30, 30,  10,  10};
    geom_rectangle_merge(&rect7, &rect8);
    g_assert (rect7.x == 10);
    g_assert (rect7.y == 10);
    g_assert (rect7.width  == 30);
    g_assert (rect7.height == 30);

    /* separate reverse * /
    GeomRectangle rect9 = {30, 30,  10,  10};
    GeomRectangle rect10 = {10, 10, 10, 10};
    geom_rectangle_merge(&rect9, &rect10);
    g_assert (rect9.x == 10);
    g_assert (rect9.y == 10);
    g_assert (rect9.width  == 30);
    g_assert (rect9.height == 30);
}



static void
test_geom_polygon_new()
{
    GeomPoint points[] = {{0, 0}, {50, 100}, {100, 0}};
    GeomPolygon* polygon = geom_polygon_new(&points, G_N_ELEMENTS(points));
    geom_polygon_free(polygon);
}

*/
