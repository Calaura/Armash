/*
 * test-suite.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "test-suite.h"

#include "test-geom-transform.h"
#include "test-geom-bezier.h"
#include "test-geom-box.h"


GTestSuite*
test_geom_create_suite(void)
{
    GTestSuite *suite_geom = g_test_create_suite("libgeom");

    GTestSuite *suite_geom_bezier = test_geom_bezier_create_suite();
    g_test_suite_add_suite(suite_geom, suite_geom_bezier);

    GTestSuite *suite_geom_box = test_geom_box_create_suite();
    g_test_suite_add_suite(suite_geom, suite_geom_box);

    GTestSuite *suite_geom_transform = test_geom_transform_create_suite();
    g_test_suite_add_suite(suite_geom, suite_geom_transform);

    return suite_geom;
}
