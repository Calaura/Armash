/*
 * test-geom-bezier.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "test-geom-bezier.h"

#include "libgeom/geom-point.h"
#include "libgeom/geom-polygon.h"
#include "libgeom/geom-rectangle.h"
#include "libgeom/geom-bezier.h"

#include "libmath/math-polynomial.h"

#include <math.h>


void
test_geom_bezier_quad_get_controls_bounding_box (void)
{
    GeomRectangle bounding;

    /* positive x/y area :: Point croisant */
    GeomBezierQuad bezier_a_1 = {GEOM_BEZIER_QUAD_LENGTH,
                                 {0, 0}, {50, 100}, {100, 0}};
    GeomRectangle  result_a_1 = {0.0, 100.0, 100.0, 100.0};
    geom_bezier_quad_get_bounding_box_controls(&bezier_a_1, &bounding);
    g_assert (bounding.x == result_a_1.x);
    g_assert (bounding.y == result_a_1.y);
    g_assert (bounding.width  == result_a_1.width);
    g_assert (bounding.height == result_a_1.height);

    /* negative x/y area :: Point decroisant */
    GeomBezierQuad bezier_b_1 = {GEOM_BEZIER_QUAD_LENGTH,
                                 {0, 0}, {-50, -100}, {-100, 0}};
    GeomRectangle  result_b_1 = {-100, -0, 100, 100};
    geom_bezier_quad_get_bounding_box_controls(&bezier_b_1, &bounding);
    g_assert (bounding.x == result_b_1.x);
    g_assert (bounding.y == result_b_1.y);
    g_assert (bounding.width  == result_b_1.width);
    g_assert (bounding.height == result_b_1.height);

    /* mix x mix y area */
    GeomBezierQuad bezier_c_1 = {GEOM_BEZIER_QUAD_LENGTH,
                                 {-100, 0}, {0, 100}, {100, 0}};
    GeomRectangle  result_c_1 = {-100, 100, 200, 100};
    geom_bezier_quad_get_bounding_box_controls(&bezier_c_1, &bounding);
    g_assert (bounding.x == result_c_1.x);
    g_assert (bounding.y == result_c_1.y);
    g_assert (bounding.width  == result_c_1.width);
    g_assert (bounding.height == result_c_1.height);

    /* mix x mix y area */
    GeomBezierQuad bezier_d_1 = {GEOM_BEZIER_QUAD_LENGTH,
                                 {100, -100}, {10, 10}, {-100, 100}};
    GeomRectangle  result_d_1 = {-100, 100, 200, 200};
    geom_bezier_quad_get_bounding_box_controls(&bezier_d_1, &bounding);
    g_assert (bounding.x == result_d_1.x);
    g_assert (bounding.y == result_d_1.y);
    g_assert (bounding.width  == result_d_1.width);
    g_assert (bounding.height == result_d_1.height);

    /* mix x mix y area */
    GeomBezierQuad bezier_d_2 = {GEOM_BEZIER_QUAD_LENGTH,
                                 {-100, -100}, {10, 10}, {100, 100}};
    GeomRectangle  result_d_2 = {-100, 100, 200, 200};
    geom_bezier_quad_get_bounding_box_controls(&bezier_d_2, &bounding);
    g_assert (bounding.x == result_d_2.x);
    g_assert (bounding.y == result_d_2.y);
    g_assert (bounding.width  == result_d_2.width);
    g_assert (bounding.height == result_d_2.height);





    /*g_print("\n");
    GeomBezierQuad bezier = bezier_a_1;
    GeomRectangle  result = result_a_1;
    g_print("Bezier{P0: {x: %f, y: %f}, P1: {x: %f, y: %f}, P2: {x: %f, y: %f}}\n",
            bezier.P0.x, bezier.P0.y,
            bezier.P1.x, bezier.P1.y,
            bezier.P2.x, bezier.P2.y);
    g_print("Rectangle{x: %f, y:%f, width: %f, height: %f}\n",
            bounding.x, bounding.y,
            bounding.width, bounding.height);
    g_print("Rectangle{x: %f, y:%f, width: %f, height: %f}\n",
            result.x, result.y,
            result.width, result.height);*/

}

void
test_geom_bezier_cubic_get_controls_bounding_box (void)
{
    GeomRectangle bounding;

    GeomBezierCubic bezier_d_2 = {GEOM_BEZIER_CUBIC_LENGTH,
                                  {100, -50}, {-100, -100}, {-100, 100}, {100, 50}};
    GeomRectangle  result_d_2 = {-100, 100, 200, 200};

    geom_polygon_get_bounding_box((GeomPolygon*) &bezier_d_2, &bounding);


    /*geom_bezier_cubic_get_controls_bounding_box(&bezier_d_2, &bounding);*/
    g_assert (bounding.x == result_d_2.x);
    g_assert (bounding.y == result_d_2.y);
    g_assert (bounding.width  == result_d_2.width);
    g_assert (bounding.height == result_d_2.height);


}

void
test_geom_bezier_cubic_extrude (void)
{
    gdouble tickness = 1.;
    GeomBezierCubic bezier = {GEOM_BEZIER_CUBIC_LENGTH,
                              {0, 0}, {100, 100}, {300, 100}, {400, 0}};
    GeomBezierCubic result_inter = {GEOM_BEZIER_CUBIC_LENGTH,
                              {100, -50}, {-100, -100}, {-100, 100}, {100, 50}};
    GeomBezierCubic result_extra = {GEOM_BEZIER_CUBIC_LENGTH,
                              {100, -50}, {-100, -100}, {-100, 100}, {100, 50}};
    GeomBezierCubic expect_inter = {GEOM_BEZIER_CUBIC_LENGTH,
                              {100, -50}, {-100, -100}, {-100, 100}, {100, 50}};
    GeomBezierCubic expect_extra = {GEOM_BEZIER_CUBIC_LENGTH,
                              {100, -50}, {-100, -100}, {-100, 100}, {100, 50}};

    //---------------------
    //gdouble polar_module = sqrt(pow(bezier.P0.x, 2.0) + pow(bezier.P0.y, 2.0));
    gdouble polar_argument = atan2(bezier.P1.y-bezier.P0.y, bezier.P1.x - bezier.P0.x);

    double p0x = 0.0;
    double p0y = 0.0;
    double x = tickness*cos(polar_argument+M_PI/2);
    double y = tickness*sin(polar_argument+M_PI/2);
    result_inter.P0.x = bezier.P0.x + x;
    result_inter.P0.y = bezier.P0.y + y;

    result_extra.P0.x = bezier.P0.x - x;
    result_extra.P0.y = bezier.P0.y - y;



    //---------------------
    GeomPoint result_inter_middel;
    GeomPoint result_extra_middel;

    GeomPoint middel;
    geom_bezier_cubic_eval(&bezier, 0.5, &middel);
    //TODO: use math_polynomial3_eval(&polynomial_x, 0.5);

    MathPolynomial3 polynomial_y = MATH_POLYNOMIAL_3_INIT;
    MathPolynomial3 polynomial_x = MATH_POLYNOMIAL_3_INIT;
    MathPolynomial2 dtx = MATH_POLYNOMIAL_2_INIT;
    MathPolynomial2 dty = MATH_POLYNOMIAL_2_INIT;
    GEOM_BEZIER_CUBIC_TO_POLYNOMIAL3(&bezier, &polynomial_y, y);
    GEOM_BEZIER_CUBIC_TO_POLYNOMIAL3(&bezier, &polynomial_x, x);
    MATH_POLYNOMIAL3_TO_DERIV(&polynomial_x, &dtx);
    MATH_POLYNOMIAL3_TO_DERIV(&polynomial_y, &dty);
    middel.x = math_polynomial3_eval(&polynomial_x, 0.5);
    middel.y = math_polynomial3_eval(&polynomial_y, 0.5);
    g_print("Point{%f, %f}\n", middel.x, middel.y);

    double dtx_ = math_polynomial2_eval(dtx.a, dtx.b, dtx.c, 0.5);
    double dty_ = math_polynomial2_eval(dty.a, dty.b, dty.c, 0.5);
    polar_argument = atan2(dty_, dtx_);
    x = tickness*cos(polar_argument+M_PI/2);
    y = tickness*sin(polar_argument+M_PI/2);
    result_inter_middel.x = middel.x + x;
    result_inter_middel.y = middel.y + y;

    result_extra_middel.x = middel.x - x;
    result_extra_middel.y = middel.y - y;

    //---------------------
    polar_argument = atan2(bezier.P3.y-bezier.P2.y, bezier.P3.x-bezier.P2.x);
    x = tickness*cos(polar_argument+M_PI/2);
    y = tickness*sin(polar_argument+M_PI/2);
    result_inter.P3.x = bezier.P3.x + x;
    result_inter.P3.y = bezier.P3.y + y;

    result_extra.P3.x = bezier.P3.x - x;
    result_extra.P3.y = bezier.P3.y - y;

    /*
     * https://pomax.github.io/bezierinfo/
     */

    /// B(t)  = P0(1-t)³ + 3.P1.t(1-t)² + 3.P2.t²(1-t) + P3.t³
    /// B(t)  = (P3-3.P2+3.P1-P0)t³ + (3.P2-6.P1+3.P0)t² + 3(P1-P0)t + (P0)
    ///
    /// B'(t) = 3( (P1-P0)(1-t)² +2(P2-P1)t(1-t) + (P3-P2)t²         )
    /// B'(t) = 3( (P3-3.P2+3.P1-P0)t² + (2.P2-4.P1+2.P0)t + (P1-P0) )
    /// B'(t)/3 = P1.(1-t)(1-3.t) + P2(2t-3t²) - P0(1-t)² + P3t²
    ///
    ///
    /// B'(t)/3 = (P3-3.P2-P0)t² + 3.P1.t² + (2.P2+2.P0)t - 4.P1.t + P1-P0
    /// B'(t)/3 - (P3-3.P2-P0)t² - (2.P2+2.P0)t + P0 = 3.P1.t² - 4.P1.t + P1
    /// B'(t)/3 - (P3-3.P2-P0)t² - (2.P2+2.P0)t + P0 = P1(3.t² - 4.t + 1)
    /// P1(3.t² - 4.t + 1) = B'(t)/3 - (P3-3.P2-P0)t² - (2.P2+2.P0)t + P0
// P1 = [ B'(t)/3 - (P3-3.P2-P0)t² - (2.P2+2.P0)t + P0 ] / (3.t² - 4.t + 1)
// P1 = [ B'(t)/3 - (P3-P0)t² + 3.P2t² - (2.P0)t - 2.P2t + P0 ] / (3.t² - 4.t + 1)
// P1 = [ B'(t)/3 - (P3-P0)t² + P2t(3t - 2) - 2.P0t + P0 ] / (3.t² - 4.t + 1)
// P1 = [ B'(t)/3 - P3t² + P2t(3t - 2) - P0(t²+2t-1)] / (3.t² - 4.t + 1)
    ///
    /// B'(0.5) = dx(t).dt/dy.dt = dtx_/dty_
    /// (x-Px(t))/P'x(t) = (y-Py(t))/P'y(t)
    ///
    /// B(1)  = P3
    /// B(0.5)  = P0(0.5)³ + 3.P1.t(0.5)² + 3.P2.t²(0.5) + P3.t³
    /// B(0)  = P0
// B(t)  = P0(1-t)³ + 3.P1.t(1-t)² + 3.P2.t²(1-t) + P3.t³
// B(t) - P0(1-t)³ - P3.t³ = 3.P1.t(1-t)² + 3.P2.t²(1-t)
// (B(t) - P0(1-t)³ - P3.t³)/3(1-t)t = P1.(1-t) + P2.t
// (B(t) - P0(1-t)³ - P3.t³)/3t(1-t) - [ [ B'(t)/3 - (P3-3.P2-P0)t² - (2.P2+2.P0)t + P0 ] / (3.t² - 4.t + 1) ] * (1-t) = P2.t
// (B(t) - P0(1-t)³ - P3.t³)/3t(1-t) - [ [ B'(t)/3 - P3t² - P0(t²+2t-1)] / (3.t² - 4.t + 1) ] * (1-t) = P2.t + P2t(3t - 2) * (1-t) / (3.t² - 4.t + 1)
// (B(t) - P0(1-t)³ - P3.t³)/3t(1-t) - [ [ B'(t)/3 - P3t² - P0(t²+2t-1)] / (3.t² - 4.t + 1) ] * (1-t) = P2 ( t + t(3t - 2)(1-t) / (3.t² - 4.t + 1) )
// (B(t) - P0(1-t)³ - P3.t³)/3t(1-t) - [ [ B'(t)/3 - P3t² - P0(t²+2t-1)] / (3.t² - 4.t + 1) ] * (1-t) = ( t + t(3t - 2)(1-t) / (3.t² - 4.t + 1) ) * P2

// B'(t)/3 = (P3-3.P2+3.P1-P0)t² + (2.P2-4.P1+2.P0)t + (P1-P0)
// B'(t)/3 = (P3+3.P1-P0)t² -3P2t² + 2.P2t + (-4.P1+2.P0)t + (P1-P0)
// B'(t) = 3(P3+3.P1-P0)t² + 3(-4.P1+2.P0)t + 3(P1-P0) + 3P2(2t-3t²)

// ((P3+3.P1-P0)t² + (-4.P1+2.P0)t + (P1-P0)) * 3 - P0(1-t)³ - P3.t³)/3t(1-t) - [ [ B'(t)/3 - P3t² - P0(t²+2t-1)] / (3.t² - 4.t + 1) ] * (1-t) = ( t + t(3t - 2)(1-t) / (3.t² - 4.t + 1) ) * P2 - 3.P2(2t-3t²)
// ((P3+3.P1-P0)t² + (-4.P1+2.P0)t + (P1-P0)) * 3 - P0(1-t)³ - P3.t³)/3t(1-t) - [ [ B'(t)/3 - P3t² - P0(t²+2t-1)] / (3.t² - 4.t + 1) ] * (1-t)
    //    = ( t + t(3t - 2)(1-t) / (3.t² - 4.t + 1) ) * P2 - 3.P2(2t-3t²)
    //    = P2*( (t + t(3t - 2)(1-t) / (3.t² - 4.t + 1)) - 6t-9t²)

    double t = 0.5;
    // B(t)  = P0(1-t)³ + 3.P1.t(1-t)² + 3.P2.t²(1-t) + P3.t³
    // B(t) - P0(1-t)³ - 3.P2.t²(1-t) - P3.t³ = 3.P1.t(1-t)²
    // P1 = ( B(t) - P0(1-t)³ - 3.P2.t²(1-t) - P3.t³ ) / 3t(1-t)²

    /// B(t)  = P0(1-t)³ + 3.P1.t(1-t)² + 3.P2.t²(1-t) + P3.t³
    /// B(t)  = (P3-3.P2+3.P1-P0)t³ + (3.P2-6.P1+3.P0)t² + 3(P1-P0)t + (P0)
    ///
    /// B'(t) = 3( (P1-P0)(1-t)² +2(P2-P1)t(1-t) + (P3-P2)t²         )
    /// B'(t) = 3( (P3-3.P2+3.P1-P0)t² + (2.P2-4.P1+2.P0)t + (P1-P0) )
    //  B(t) - P0(1-t)³ - 3.P1.t(1-t)² - P3.t³ = 3.P2.t²(1-t)
    ///
    /// (x-Px(t))/P'x(t) = (y-Py(t))/P'y(t)
    /// (x-Px(t))/(y-Py(t)) = P'x(t)/P'y(t) = dxt_/dyt_
    /// (x-Px(t))/(y-Py(t)) = dxt_/dyt_



    /// B(t)  = P0(1-t)³ + 3.P1.t(1-t)² + 3.P2.t²(1-t) + P3.t³                    E1
    /// B'(t) = 3( (P1-P0)(1-t)² +2(P2-P1)t(1-t) + (P3-P2)t²         )            E2
    /// (x-Px(t))/(y-Py(t)) = P'x(t)/P'y(t)                                       E3
    /// P'x(t)/P'y(t) = dxt_/dyt_                                                 E4
    /// B(0.5)= PC                                                                E5

    // P1.x(P2.x)
    // P2.x(P1.x)
    // B(t, P0, P1, P2, P3)

    gdouble p2_x = (
                (result_inter_middel.x-result_inter.P0.x*pow(1.-t, 3.)-result_inter.P3.x*pow(t, 3.)) / (3.*t*(1.-t))
              - ( (dtx_/3. - result_inter.P3.x*pow(t,2) - result_inter.P0.x*(t*t+2.*t-1.)) / (3.*t*t - 4.*t + 1.) ) * (1.-t)
            )
            /
            (
                t + t*(3.*t - 2.)*(1.-t) / (3.*t*t - 4.*t + 1.)
            );
    gdouble p2_y = (
                (result_inter_middel.y-result_inter.P0.y*pow(1.-t, 3.)-result_inter.P3.y*pow(t, 3.)) / (3.*t*(1.-t))
              - ( (dty_/3. - result_inter.P3.y*pow(t,2) - result_inter.P0.y*(t*t+2.*t-1.)) / (3.*t*t - 4.*t + 1.) ) * (1.-t)
            )
            /
            (
                t + t*(3.*t - 2.)*(1.-t) / (3.*t*t - 4.*t + 1.)
            );
    gdouble p1_x = (
                result_inter_middel.x-result_inter.P0.x*pow(1.-t, 3.)-3*p2_x*t*t*(1.-t) - result_inter.P3.x*t*t*t
            ) / (3.*t*pow(1.-t, 2));
    gdouble p1_y = (
                result_inter_middel.y-result_inter.P0.y*pow(1.-t, 3.)-3*p2_y*t*t*(1.-t) - result_inter.P3.y*t*t*t
            ) / (3.*t*pow(1.-t, 2));

    g_print("P0{%f, %f}\n", result_inter.P0.x, result_inter.P0.y);
    g_print("P1{%f, %f}\n", p1_x, p1_y);
    g_print("PC{%f, %f}\n", result_inter_middel.x, result_inter_middel.y);
    g_print("P2{%f, %f}\n", p2_x, p2_y);
    g_print("P3{%f, %f}\n", result_inter.P3.x, result_inter.P3.y);

}

void
test_geom_bezier_quad_get_bounding_box (void)
{


    GeomBezierQuad bezier = {GEOM_BEZIER_QUAD_LENGTH,
                             {0, 0}, {50, 80}, {100, 0}};
    /*
    GeomBezierQuad bezier = {GEOM_BEZIER_QUAD_LENGTH,
                             {0, 0}, {50, 50}, {100, 100}};
    GeomBezierQuad bezier = {GEOM_BEZIER_QUAD_LENGTH,
                             {0, 0}, {300, 200}, {100, 100}};
    */

    GeomRectangle result  = {0, 0, 100, 40};
    GeomRectangle bounding;
    geom_bezier_quad_get_bounding_box(&bezier, &bounding);

    g_assert (bounding.x == result.x);
    g_assert (bounding.y == result.y);
    g_assert (bounding.width  == result.width);
    g_assert (bounding.height == result.height);
}


GTestSuite *
test_geom_bezier_create_suite(void)
{
    GTestSuite *suite_geom = g_test_create_suite("bezier");

    g_test_suite_add (suite_geom, TESTCASE (test_geom_bezier_quad_get_controls_bounding_box, NULL));
    g_test_suite_add (suite_geom, TESTCASE (test_geom_bezier_quad_get_bounding_box, NULL));

    g_test_suite_add (suite_geom, TESTCASE (test_geom_bezier_cubic_get_controls_bounding_box, NULL));
    /*g_test_suite_add (suite_math, TESTCASE (test_geom_bezier_cubic_get_bounding_box, NULL));*/
    g_test_suite_add (suite_geom, TESTCASE (test_geom_bezier_cubic_extrude, NULL));

    return suite_geom;
}
