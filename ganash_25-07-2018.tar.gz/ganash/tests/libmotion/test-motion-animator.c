/*
 * test-svg-color.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "test-motion-animator.h"

#include <liblog/log.h>

#include <libgraphics/graphics.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-shape.h"

#include "libmotion/motion-types.h"
#include "libmotion/motion-animator.h"
#include "libmotion/motion-easing.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-animation-parallel.h"
#include "libmotion/motion-animation-sequential.h"
#include "libmotion/motion-property.h"

#include <math.h>



/*
struct {
    double key_value;
    double key_time;
    struct {
        double c1_x, c1_y;
        double c2_x, c2_y;
    } key_curve;
};
struct _Spline {
    double x1, y1;
    double x2, y2;
} Spline;
struct _Motion {
    double to;
    double at;
    Spline *spline;
} Motion;
*/


typedef struct _Point
{
    double x;
    double y;
}Point;
typedef struct _Spline
{
/*    Point p1;
    Point p2;*/
    double p1_x;
    double p1_y;
    double p2_x;
    double p2_y;

}Spline;



void
test_motion_animator_path(void)
{
    double values[]  = { 0.0,                  100.0,               0.0};
    double times[]   = { 0.0,                  10000.0,             20000.0};
    Spline splines[] = {{0.5, 0.0, 0.5, 1.0}, {0.5, 0.0, 0.5, 1.0}};
    // cairo_move_to(); cairo_curve_to()

    /*MotionPath *path = motion_path_new(values, times, splines);*/

    /*motion_path_set_values(path, values, times, splines);*/
    /*motion_path_set_times(path, values, times, splines);*/
    int ln_values  = G_N_ELEMENTS(values);
    int ln_times   = G_N_ELEMENTS(times);
    int ln_splines = G_N_ELEMENTS(splines);
    if (ln_values!=ln_times || (ln_splines && ln_values!=(ln_splines+1))) {

        return;
    }
    int i;
    for (i=0; i<ln_values; i++) {
        if (i==0) {
            MotionEasing *easing = motion_easing_new();
            motion_easing_set_values(easing, values[i]);
            motion_easing_set_times(easing, times[i]);
            /*motion_path_append(path, easing);*/
        } else if(ln_splines) {
            MotionEasing *easing = motion_easing_cubic_new();
            double from = values[i-1];
            double to   = values[i];
            motion_easing_cubic_set_values(easing, from, to, &splines[i-1]);
            double begin = times[i-1];
            double end   = times[i];
            motion_easing_cubic_set_times(easing, begin, end);
            /*motion_path_append(path, easing);*/
            //double v = motion_property_get_value(easing, 1s);
            double v = motion_easing_interpolate(easing, 0.5);
            g_print("interpolate(0.0) = %f\n", v);
        } else {
            MotionEasing *easing = motion_easing_linear_new();
            double from = values[i-1];
            double to   = values[i];
            motion_easing_linear_set_values(easing, from, to);
            double begin = times[i-1];
            double end   = times[i];
            motion_easing_linear_set_times(easing, begin, end);
            /*motion_path_append(path, easing);*/
        }
    }

    /*motion_path_interpolate(progress);*/
    /*motion_path_get_duration();*/
    /*motion_path_get_from();*/
    /*motion_path_get_to();*/

}

void
test_motion_animator_init(void)
{
    MotionAnimator  *animator = motion_animator_new();
    MotionAnimationSequential *sequential = motion_animation_sequential_new();
    MotionAnimationParallel   *parallel   = motion_animation_parallel_new();
    /*MotionAnimationGroup           *animation  = motion_animation_new();
    MotionAnimationProperty           *animation  = motion_animation_new();
    MotionAnimationVariant           *animation  = motion_animation_new();
    MotionAnimation           *animation  = motion_animation_new();*/

    RendererShape             *shape    = g_object_new(renderer_shape_get_type(), NULL);
    GObject                   *object   = (GObject*) shape;
    MotionProperty            *property = motion_property_new("x", object);
    MotionEasing              *easing = motion_easing_cubic_new();
    motion_animation_set_easing(property, easing);
    /*MotionProperty            *property_fill = motion_property_new("path", object);*/
    /*GValue from = G_VALUE_INIT;
    g_value_init(&from, G_TYPE_POINTER);
    g_value_set_pointer(&from, matrix);
    GValue to = G_VALUE_INIT;
    g_value_init(&to, G_TYPE_POINTER);
    g_value_set_pointer(&to, matrix);
    motion_property_set_times(property, 0.0, 10000.0);
    motion_property_set_values(property, from, to);*/

    /*motion_animatable_play();*/

    /*motion_animation_set_path();*/
    /*motion_animation_set_values(property, values);
    motion_animation_set_times(property, times);
    motion_animation_set_splines(property, splines);*/
    /*motion_animation_play(property);*/

    /*motion_property_set_name(property, "x");
    motion_property_set_target(property, object);
    motion_property_set_duration(property, 10000);
    motion_property_set_first_value(property,  0);
    motion_property_set_last_value(property, 100);

    motion_property_start(property);
    motion_animation_start(property);*/


    /*
    QPushButton button("Animated Button");
    button.show();

    QPropertyAnimation animation(&button, "geometry");
    animation.setDuration(10000);
    animation.setStartValue(QRect(0, 0, 100, 30));
    animation.setEndValue(QRect(250, 250, 100, 30));

    animation.start();
    */
}

void test_motion_animator_state(void)
{
    RendererObject *gobject = g_object_new(renderer_object_get_type(), NULL);
/*
    MotionEngine *engine = motion_engine_new();
    MotionState *s1 = motion_state_new();
    MotionState *s2 = motion_state_new();
    MotionState *s3 = motion_state_new();

//enum
//{
//    HOVER_EVENT,
//    LEAVE_EVENT,
//    MOVE_EVENT,
//    DRAG_EVENT,
//    PRESS_EVENT,
//    RELEASE_EVENT,
//    CLICK_EVENT
//};

    // enter_notify_event, leave_notify_event, motion_notify_event, button_press_event, button_release_event
    motion_state_add_transition(s1, gobject, "button_release_event", s2);
    motion_state_add_transition(s2, gobject, "button_release_event", s3);
    motion_state_add_transition(s3, gobject, "button_release_event", s1);

    motion_state_assign_property(s1, gobject, "text", "In s3");
    g_object_set_property();


    motion_engine_add_state(engine, s1);
    motion_engine_add_state(engine, s2);
    motion_engine_add_state(engine, s3);
//    motion_engine_set_begin(engine, s1);
//    motion_engine_set_final(engine, s1);

    motion_engine_start(engine);

    //motion_engine_notify(engin, "click");
*/


    /*
    QPushButton *button = new QPushButton("Animated Button");
    button->show();

    QStateMachine *machine = new QStateMachine;

    QState *state1 = new QState(machine->rootState());
    state1->assignProperty(button, "geometry", QRect(0, 0, 100, 30));
    machine->setInitialState(state1);

    QState *state2 = new QState(machine->rootState());
    state2->assignProperty(button, "geometry", QRect(250, 250, 100, 30));

    QSignalTransition *transition1 = state1->addTransition(button,
        SIGNAL(clicked()), state2);
    transition1->addAnimation(new QPropertyAnimation(button, "geometry"));

    QSignalTransition *transition2 = state2->addTransition(button,
        SIGNAL(clicked()), state1);
    transition2->addAnimation(new QPropertyAnimation(button, "geometry"));

    machine->start();
    */
}

GTestSuite *
test_motion_animator_create_suite(void)
{
    GTestSuite *suite_motion_animator = g_test_create_suite("animator");

    g_test_suite_add (suite_motion_animator, TESTCASE (test_motion_animator_init, NULL));
    g_test_suite_add (suite_motion_animator, TESTCASE (test_motion_animator_path, NULL));
    g_test_suite_add (suite_motion_animator, TESTCASE (test_motion_animator_state, NULL));

    return suite_motion_animator;
}
