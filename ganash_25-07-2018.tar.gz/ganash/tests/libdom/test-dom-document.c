#include <liblog/log.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>

#include <libdom/dom.h>
#include <libdom/dom-document.h>


#include "test-dom-document.h"

/*
 * @see https://github.com/sardemff7/eventd/blob/master/server/libeventd-event/tests/unit/setters.c
typedef struct {
    DomDocument *document;
} FixtureData;

static void
test_dom_document_data_setup(gpointer fixture, gconstpointer user_data)
{
    FixtureData *data = fixture;

    data->event = eventd_event_new(EVENTD_EVENT_TEST_CATEGORY, EVENTD_EVENT_TEST_NAME);
}

static void
test_dom_document_data_teardown(gpointer fixture, gconstpointer user_data)
{
    FixtureData *data = fixture;

    data->event = eventd_event_new(EVENTD_EVENT_TEST_CATEGORY, EVENTD_EVENT_TEST_NAME);
}

g_test_create_case ("new", sizeof(FixtureData), NULL, test_dom_document_data_setup, (TCFunc) test_dom_document_new, test_dom_document_data_teardown)

*/

void
test_dom_document_example_x(gpointer fixture, gconstpointer user_data)
{
    xmlDoc  *doc = NULL;       /* document pointer */
    xmlNode *root_node = NULL, *node = NULL, *node1 = NULL;/* node pointers */
    xmlDtd  *dtd = NULL;       /* DTD pointer */
    char buff[256];
    int i, j;

//    LIBXML_TEST_VERSION;

    /*
     * Creates a new document, a node and set it as a root node
     */
    doc = xmlNewDoc(BAD_CAST "1.0");
    doc->standalone = 1;// standalone
    xmlNode *style_pi = xmlNewDocPI(doc, BAD_CAST "xml-stylesheet", BAD_CAST "href=\"square.css\" type=\"text/css\"");
    xmlAddChild(doc, style_pi);


    /*
     * Creates namespace
     */
    xmlNs *default_ns = xmlNewNs(NULL,
                                 "http://www.w3.org/2000/xmlns/",
                                 NULL);
    xmlNs *svg_ns = xmlNewNs(NULL,
                             "http://www.w3.org/2014/svg",
                             "svg");

    xmlNs *xmlns_svg = xmlNewNs(NULL,
                             "http://www.w3.org/2014/svg",
                             "xmlns");


    root_node = xmlNewNode(NULL, BAD_CAST "root");
    xmlSetNs(root_node, svg_ns);
    xmlSetNsProp(root_node, default_ns, "xmlns", "http://...");
    xmlSetNsProp(root_node, xmlns_svg, "svg", "http://.../svg");

    xmlDocSetRootElement(doc, root_node);

    xmlDebugDumpDocument(stdout, doc);

/*
    xmlNs *sch_ns = xmlNewNs(root_node,
                             "http://xxx",
                             "schemaLocation");
The status of xsi:schemaLocation in libXML is unclear, see this bug report: https://bugzilla.gnome.org/show_bug.cgi?id=157205. It seems implemented in the library itself but not enabled in the provided xmllint util.
*/

    /*xmlNs *xlink_ns = xmlNewNs(root_node,
                               "http://www.w3.org/1999/xlink",
                               "xlink");*/
    // http://www.w3.org/2000/xmlns/
    // xmlns:xlink="http://www.w3.org/1999/xlink

    /*xmlSetNsProp(root_node, ns, "xlink", "http://.../xlink");*/


    /*
     * Creates a DTD declaration. Isn't mandatory.
     */
    char *dtd_name = "svg";
    char *dtd_external_id = "-//W3C//DTD SVG 1.1//EN";
    char *dtd_system_id = "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd";
    dtd = xmlCreateIntSubset(doc, BAD_CAST dtd_name, BAD_CAST dtd_external_id, BAD_CAST dtd_system_id);
    // xmlGetDtdQAttrDesc

    /*
     * xmlNewChild() creates a new node, which is "attached" as child node
     * of root_node node.
     */
    xmlNewChild(root_node, NULL, BAD_CAST "node1",
                BAD_CAST "content of node 1");
    /*
     * The same as above, but the new child node doesn't have a content
     */
    xmlNewChild(root_node, NULL, BAD_CAST "node2", NULL);

    /*
     * xmlNewProp() creates attributes, which is "attached" to an node.
     * It returns xmlAttrPtr, which isn't used here.
     */
    node =
        xmlNewChild(root_node, NULL, BAD_CAST "node3",
                    BAD_CAST "this node has attributes");
    xmlNewProp(node, BAD_CAST "attribute", BAD_CAST "yes");
    xmlNewProp(node, BAD_CAST "foo", BAD_CAST "bar");

    /*
     * Here goes another way to create nodes. xmlNewNode() and xmlNewText
     * creates a node and a text node separately. They are "attached"
     * by xmlAddChild()
     */
    node = xmlNewNode(NULL, BAD_CAST "node4");
    node1 = xmlNewText(BAD_CAST
                   "other way to create content (which is also a node)");
    xmlAddChild(node, node1);
    xmlAddChild(root_node, node);

    /*
     * A simple loop that "automates" nodes creation
     */
    /*for (i = 5; i < 7; i++) {
        sprintf(buff, "node%d", i);
        node = xmlNewChild(root_node, NULL, BAD_CAST buff, NULL);
        for (j = 1; j < 4; j++) {
            sprintf(buff, "node%d%d", i, j);
            node1 = xmlNewChild(node, NULL, BAD_CAST buff, NULL);
            xmlNewProp(node1, BAD_CAST "odd", BAD_CAST((j % 2) ? "no" : "yes"));
        }
    }*/

    /*
     * Dumping document to stdio or file
     */
    g_print("\n");
    xmlSaveFormatFileEnc("-", doc, "UTF-8", 1);
    //xmlSaveFile(TEST_DOM_BUILD_DIR"dom.xml", doc);

    /*free the document */
    xmlFreeDoc(doc);

    /*
     *Free the global variables that may
     *have been allocated by the parser.
     */
    xmlCleanupParser();

    /*
     * this is to debug memory for regression tests
     */
    xmlMemoryDump();
    return(0);
}
#include <libxml/debugXML.h>
void
test_dom_document_example(gpointer fixture, gconstpointer user_data)
{
    xmlDoc  *doc = NULL;       /* document pointer */
    xmlNode *root_node = NULL, *node = NULL, *node1 = NULL;/* node pointers */
    xmlDtd  *dtd = NULL;       /* DTD pointer */
    char buff[256];
    int i, j;

//    LIBXML_TEST_VERSION;

    /*
     * Creates a new document, a node and set it as a root node
     */
    doc = xmlNewDoc(BAD_CAST "1.0");
    doc->standalone = 1;// standalone

    xmlNode *style_pi = xmlNewDocPI(doc, BAD_CAST "xml-stylesheet", BAD_CAST "href=\"square.css\" type=\"text/css\"");
    xmlAddChild(doc, style_pi);

    /* comment */
    xmlNode *comment = xmlNewComment(" Created with SVGIMP ");
    xmlAddChild(doc, comment);


    /* new line */
    xmlNode *blank = xmlNewText("");
    xmlAddChild(doc, blank);


    root_node = xmlNewNode(NULL, BAD_CAST "root");

    xmlNs *default_ns = xmlNewNs(root_node,
                                 "http://www.w3.org/2000/xmlns/",
                                 NULL);
    xmlNs *xml_ns = xmlNewNs(root_node,
                                 "http://www.w3.org/2000/namespace",
                                 "xml");
    xmlNs *svg_ns = xmlNewNs(root_node,
                             "http://www.w3.org/2014/svg",
                             "svg");
    //xmlSetNs(root_node, svg_ns);


    /*xmlSetNsProp(root_node, ns, "xlink", "http://.../xlink");*/


    /*
     * Creates a DTD declaration. Isn't mandatory.
     */
    char *dtd_name = "svg";
    char *dtd_external_id = "-//W3C//DTD SVG 1.1//EN";
    char *dtd_system_id = "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd";
    dtd = xmlCreateIntSubset(doc, BAD_CAST dtd_name, BAD_CAST dtd_external_id, BAD_CAST dtd_system_id);

    /*
     * xmlNewChild() creates a new node, which is "attached" as child node
     * of root_node node.
     */
    xmlNewChild(root_node, svg_ns, BAD_CAST "node1",
                BAD_CAST "content of node 1");


    /*
     * The same as above, but the new child node doesn't have a content
     */
    //xmlNs *ns = xmlSearchNs(doc, root_node, "svg");
    //g_print("ns=%p\n", ns);

    xmlNode *node2 = xmlNewNode(svg_ns, BAD_CAST "node2");
    xmlAddChild(root_node, node2);


    //xmlNs *new_ns = xmlNewNs(node2, NULL, "svg");
    //xmlSetNs(node2, new_ns);
    //xmlFreeNs(new_ns);

    /*
     * xmlNewProp() creates attributes, which is "attached" to an node.
     * It returns xmlAttrPtr, which isn't used here.
     */
    xmlNs *prop_ns = xmlNewNs(root_node, "http://www/xxx", "my");

    node = xmlNewNode(svg_ns, BAD_CAST "node3");
    xmlAttr *prop = xmlSetNsProp(node, svg_ns, BAD_CAST "attribute", BAD_CAST "yes");
    xmlAttr *my_prop = xmlNewNsProp(node, prop_ns, BAD_CAST "attribute", BAD_CAST "yes");
    prop_ns->context = doc;
    //prop->ns = prop_ns;
    xmlAttr *attr = xmlNewProp(node, BAD_CAST "id", BAD_CAST "bar");
    attr->ns = xml_ns;//xmlNewNs(NULL, "http://www", "xml");
    xmlAddChild(node2, node);

    //xmlNs *new2_ns = xmlNewNs(node, NULL, "svg");
    //xmlSetNs(node, new2_ns);

    xmlDocSetRootElement(doc, root_node);

    xmlDebugDumpDocument(stdout, doc);
    xmlDebugDumpNode(stdout, node2, 1);

    /*
     * Here goes another way to create nodes. xmlNewNode() and xmlNewText
     * creates a node and a text node separately. They are "attached"
     * by xmlAddChild()
     */
    node = xmlNewNode(svg_ns, BAD_CAST "node4");
    node1 = xmlNewText(BAD_CAST
                   "other way to create content (which is also a node)");
    xmlAddChild(node, node1);
    xmlAddChild(root_node, node);

    /*
     * A simple loop that "automates" nodes creation
     */
    /*for (i = 5; i < 7; i++) {
        sprintf(buff, "node%d", i);
        node = xmlNewChild(root_node, NULL, BAD_CAST buff, NULL);
        for (j = 1; j < 4; j++) {
            sprintf(buff, "node%d%d", i, j);
            node1 = xmlNewChild(node, NULL, BAD_CAST buff, NULL);
            xmlNewProp(node1, BAD_CAST "odd", BAD_CAST((j % 2) ? "no" : "yes"));
        }
    }*/

    /*
     * Dumping document to stdio or file
     */
    g_print("\n");
    xmlSaveFormatFileEnc("-", doc, "UTF-8", 1);
    //xmlSaveFile(TEST_DOM_BUILD_DIR"dom.xml", doc);

    /*free the document */
    xmlFreeDoc(doc);

    /*
     *Free the global variables that may
     *have been allocated by the parser.
     */
    xmlCleanupParser();

    /*
     * this is to debug memory for regression tests
     */
    xmlMemoryDump();
    return(0);
}

void
test_dom_document_loadx(gpointer fixture, gconstpointer user_data) {

    g_print("%s\n", user_data);
    DomDocument *document = dom_document_new();

}

void
test_dom_document_get_by_id(gpointer fixture, gconstpointer user_data) {
    g_test_message("Not implemented");
    /* Add asserts */
}

// Beaucoup de bug lié au namespace
void
test_dom_document_new_html(gpointer fixture, gconstpointer user_data) {

    DomElement *root;
    DomElement *tag;

    DomDocument *document = dom_document_new();

    /* default namspace svg */
    root = dom_document_create_element_ns(document, "http://www.w3.org/2000/html", &DOM_QUALIFIED_NAME(NULL, "html"));
    dom_document_set_root(document, root);// bug : neccesaire pour dom_document_create_element()

    tag  = dom_document_create_element(document, &DOM_QUALIFIED_NAME("html", "body"));
    dom_element_append(root, tag);

    // TODO:
    dom_document_save_as(document, "-", "UTF-8", 1);

}

void
test_dom_document_new_svg(gpointer fixture, gconstpointer user_data) {

#if 1
    // <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
    DomDocumentType *doctype = dom_implementation_create_document_type("svg",
        "-//W3C//DTD SVG 1.1//EN",
        "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd");
    DomDocument *document = dom_implementation_create_document(NULL, "svg", doctype);// doctype->ownerDocument

    DomNode *defs = dom_document_create_element(document, &DOM_QUALIFIED_NAME("svg", "defs"));
    //dom_node_append_child(document->svg|document_element, defs);

    g_object_unref(document);

#else
    DomElement *root;
    DomElement *tag;

    DomDocument *document = dom_document_new();

    /* default namspace svg */
//    root = dom_document_create_element_ns(document, "http://www.w3.org/2000/svg", NULL/*&DOM_QUALIFIED_NAME(NULL, "svg")*/);
//    dom_element_set_attribute_ns(root, "http://www.w3.org/2000/xmlns/", NULL/*&DOM_QUALIFIED_NAME("xmlns", "xlink")*/, "http://www.w3.org/2000/xlink");
//    dom_document_set_root(document, root);// bug : neccesaire pour dom_document_create_element()

//    tag  = dom_document_create_element(document, &DOM_QUALIFIED_NAME("svg", "rect"));
//    dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("svg", "name"), "value");
//    dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("xlink", "href"), "#my_id");

//    dom_element_append(root, tag);

    // TODO:
//    dom_document_save_as(document, "-", "UTF-8", 1);
#endif

}


void
test_dom_document_add_ns(gpointer fixture, gconstpointer user_data) {

    DomElement *root;
    DomElement *tag;
/*
    DomDocument *document = dom_document_new();
    //xmlNs *ns = xmlNewNs(DOM_NODE(document->root)->xml, XML_XML_NAMESPACE, "xml");
    //dom_document_register_ns(document, ns); ns == 0
    xmlNs *ns = xmlNewNs(DOM_NODE(document->root)->xml, "http://.../GOOD", "foo");
    dom_document_register_ns(document, ns);
//    dom_document_register_namespace(document, XML_NAMESPACE, "xml",   XML_XML_NAMESPACE);
//    dom_document_register_namespace(document, XML_NAMESPACE, "svg",   XML_SVG_NAMESPACE);

    tag  = dom_document_create_element(document, &DOM_QUALIFIED_NAME("svg", "rect"));
    dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("svg", "name"), "value");
    dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("foo", "baz"), "#my_id2");
    dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("xlink", "href"), "#my_id");
    dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("xlink", "href"), "#my_id2");
    dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("xml", "id"), "#my_id2");

    dom_element_append(document->root, tag);

    dom_document_save_as(document, "-", "UTF-8", 1);
    */
}


void
test_dom_document_copy(gpointer fixture, gconstpointer user_data) {

    DomElement *root;
    DomElement *tag;

    //DomDocument *document = dom_document_new();
    {
#       define XML_SVG_NAMESPACE   "http://www.w3c.com/2014/svg"
#       define XML_XLINK_NAMESPACE "http://www.w3c.com/2014/xlink"

        DomDocument *document = g_object_new(dom_document_get_type(), NULL);
        xmlDoc *doc = dom_document_xml_new();
        dom_document_set_xml(document, doc);

        //xmlNode *node = dom_node_new(doc, &DOM_QUALIFIED_NAME("xml", "tag"));
        xmlNode *root = xmlNewNode(NULL, "root");
        xmlDocSetRootElement(doc, root);
        /*xmlNs *xml_ns = xmlNewNs(root,
                                 XML_XML_NAMESPACE,
                                 NULL);*/
        xmlNs *svg_ns = xmlNewNs(root,
                                 XML_SVG_NAMESPACE,
                                 NULL);
        xmlSetNs(root, svg_ns);

        xmlNs *xlink_ns = xmlNewNs(root,
                                 XML_XLINK_NAMESPACE,
                                 "xlink");
        //xmlSetNsProp(root, svg_ns, "svg", "http://.../svg");

        DomElement *element = g_object_new(dom_element_get_type(), NULL);
        dom_node_set_xml(DOM_NODE(element), root);



        dom_document_save_as(document, "-", "UTF-8", 1);

        xmlDebugDumpDocument(stdout, doc);

    }


    /*
    DomElement *element  = dom_element_new(document);
    xmlNode *node = dom_node_xml_new(doc, &DOM_QUALIFIED_NAME("xml", "tag"));
    dom_node_set_xml(DOM_NODE(element), node);
    */

    //DomElement *element = g_object_new(dom_element_get_type(), NULL);
    /*dom_document_set_xml(document, xml);*/
    /*dom_element_set_xml(element, xml);*/
    /*dom_node_set_xml(node, xml);*/

//    tag  = dom_document_create_element(document, &DOM_QUALIFIED_NAME("xml", "rect")/*"Some content text for this node"*/);
//    dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("svg", "name"), "value");
//    dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("xlink", "href"), "#my_id2");
    /*dom_element_set_attribute(tag, &DOM_QUALIFIED_NAME("xml", "id"), "#my_id2");*/

//    dom_element_append(document->root, tag);
/*
    xmlSearchNs(document->xml, DOM_NODE(document->root)->xml, "xml");
    //xmlDebugDumpNode(stdout, DOM_NODE(tag)->xml, 0);
    //xmlDebugDumpDocument(stdout, document->xml);

    dom_document_save_as(document, "-", "UTF-8", 1);

    xmlNode *tag_xml = DOM_NODE(tag)->xml;

    DomElement *tag_clone = dom_node_clone(tag, TRUE);

    DomDocument *doc = dom_document_new();
    // dom_document_node_link(doc, tag_clone);
    // dom_document_node_link_entities(doc, tag_clone);
    // dom_document_node_link_namespaces(doc, tag_clone);
    // dom_document_node_link_attribute(doc, tag, tag_clone);
    // dom_document_node_link_attribute_namespaces(doc, tag, tag_clone);
    dom_element_append(doc->root, tag_clone);


    //xmlDebugDumpDocument(stdout, doc->xml);

    dom_document_save_as(document, "-", "UTF-8", 1);

    xmlMemoryDump();
*/
}


#include <liblog/log.h>

void
test_dom_document_load(gpointer fixture, gconstpointer user_data) {
    //SvgDocument *document = svg_document_load("square.svg");

    //dom_document_save_as(document, "-", "UTF-8", 1);
    DomDocument *doc = dom_document_new();
    //setting doc->implementation;
    //dom_document_load(doc, "/home/gaulouis/local/src/ganash/tests/libsvg/share/doc.xml");
    dom_document_load(doc, "/home/gaulouis/local/src/ganash/tests/libsvg/share/square.svg");
#if 0
    GTree* t = g_tree_new((GCompareFunc)g_ascii_strcasecmp);
    g_tree_insert(t, "c", "Chicago");
    printf("The tree height is %d because there's only one node\n", g_tree_height(t));
    g_tree_insert(t, "b", "Boston");
    g_tree_insert(t, "d", "Detroit");
    printf("Height is %d since c is root; b and d are children\n", g_tree_height(t));
    printf("There are %d nodes in the tree\n", g_tree_nnodes(t));
    g_tree_remove(t, "d");
    printf("After remove(), there are %d nodes in the tree\n", g_tree_nnodes(t));
    g_tree_destroy(t);
#endif

    //log_debug("%.*j\n", DOM_DUMP_ALL, document);
}

GTestSuite*
test_dom_document_create_suite(void) {
    GTestSuite *suite_dom_document = g_test_create_suite("document");

//    GTestCase* testcase = g_test_create_case ("global xmlNs", 0, 0, NULL, (TCFunc) test_dom_document_example_x, NULL);
//    g_test_suite_add (suite_dom_document, testcase);

//    g_test_suite_add (suite_dom_document, TEST_DOM_DOCUMENT (example, NULL));
    //g_test_suite_add (suite_dom_document, TEST_DOM_DOCUMENT (new_html, NULL));
    //g_test_suite_add (suite_dom_document, TEST_DOM_DOCUMENT (new_svg, NULL));
//    g_test_suite_add (suite_dom_document, TEST_DOM_DOCUMENT (add_ns, NULL));
//    g_test_suite_add (suite_dom_document, TEST_DOM_DOCUMENT (copy, NULL));
    //g_test_suite_add (suite_dom_document, TEST_DOM_DOCUMENT (load, TEST_DOM_SHARE_DIR"foo.svg"));
    //g_test_suite_add (suite_dom_document, TEST_DOM_DOCUMENT (get_by_id, NULL));
    g_test_suite_add (suite_dom_document, TEST_DOM_DOCUMENT (load, NULL));

	return suite_dom_document;
}
