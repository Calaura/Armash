/*
 * test-suite.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "test-suite.h"

#include "test-dom-document.h"


GTestSuite*
test_dom_create_suite(void)
{
    GTestSuite *suite_dom = g_test_create_suite("libdom");

    GTestSuite *suite_dom_document = test_dom_document_create_suite();

    g_test_suite_add_suite(suite_dom, suite_dom_document);

    return suite_dom;
}
