/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * test-js-dom-window.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "test-js-dom-window.h"


static void test_js_dom_window_class_init(TestJsDomWindowClass *klass);
static void test_js_dom_window_init(TestJsDomWindow *gobject);

G_DEFINE_TYPE (TestJsDomWindow, test_js_dom_window, G_TYPE_OBJECT)

/* GObject interface */
/* ************************************************************************* */
static void
test_js_dom_window_init (TestJsDomWindow *object)
{
}

static void
test_js_dom_window_finalize(GObject *object)
{
    /* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (test_js_dom_window_parent_class)->finalize (object);
}

/* JSClassDef interface */
/* ************************************************************************* */
static void
js_dom_window_def_initialize(JSContextRef ctx,
                                  JSObjectRef object)
{
    g_print("window class initialize.");
}

/* window.alert method callback implementation */
static JSValueRef
js_dom_window_def_static_alert(JSContextRef context,
                               JSObjectRef function,
                               JSObjectRef thisObject,
                               size_t argumentCount,
                               const JSValueRef arguments[],
                               JSValueRef *exception)
{
    /* At least, one argument must be received */
    if (argumentCount == 1 && JSValueIsString(context, arguments[0])) {
        /* Converts JSValue to char */
        size_t len;
        char *cstr;
        JSStringRef jsstr = JSValueToStringCopy(context, arguments[0], NULL);
        len = JSStringGetMaximumUTF8CStringSize(jsstr);
        cstr = g_new(char, len);
        JSStringGetUTF8CString(jsstr, cstr, len);

        g_print(cstr);

        g_free(cstr);

        JSStringRelease(jsstr);
    }

    return JSValueMakeUndefined(context);
}

static const JSStaticFunction js_dom_window_def_static_functions[] =
{
    { "trace", js_dom_window_def_static_alert, kJSPropertyAttributeReadOnly },
    { NULL, NULL, 0 }
};

static void
test_js_dom_window_class_init(TestJsDomWindowClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = test_js_dom_window_finalize;


    klass->window_def                 = kJSClassDefinitionEmpty;
    klass->window_def.version         = 0;
    klass->window_def.attributes      = kJSClassAttributeNone;
    klass->window_def.className       = g_strdup("window");
    klass->window_def.staticFunctions = js_dom_window_def_static_functions;
    klass->window_def.initialize      = js_dom_window_def_initialize;

//	test_js_dom_window_parent_class = g_type_class_peek_parent (klass);
}

/* public functions */
/* ************************************************************************* */
TestJsDomWindow *
test_js_dom_window_new (void)
{
	return g_object_new (test_js_dom_window_get_type (),
	                     NULL);
}

