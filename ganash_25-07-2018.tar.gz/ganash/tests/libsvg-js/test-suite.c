#include "test-suite.h"

#include <JavaScriptCore/JavaScript.h>

#include <stdlib.h>























static void my_window_trace(char *message) {
    g_print("%s\n", message);
}

typedef struct _MyWindow MyWindow;
struct _MyWindow {
    void (*trace) (char *message);
};
static MyWindow my_window = {/*trace=*/my_window_trace};

/*typedef struct {
    const char* name;
    JSObjectCallAsFunctionCallback callAsFunction;
    JSPropertyAttributes attributes;
} JSStaticFunction;*/

static const JSClassDefinition js_window_trace_def =
{
    0,                                  // version
    kJSClassAttributeNone,              // attributes
    "trace",                            // className
    NULL,                               // parentClass
    NULL,                               // staticValues
    NULL,                               // staticFunctions
    NULL,//js_window_alert_init_cb,            // initialize
    NULL,//js_window_alert_finalize_cb,        // finalize
    NULL,                               // hasProperty
    NULL,//js_window_alert_get_property,       // getProperty
    NULL,                               // setProperty
    NULL,                               // deleteProperty
    NULL,                               // getPropertyNames
    NULL,                               // callAsFunction
    NULL,//js_window_alert_constructor_cb,     // callAsConstructor
    NULL,                               // hasInstance
    NULL                                // convertToType
};

char *JSChar_cstr(const JSChar*chars, size_t ln) {
    char* str = malloc(ln + 1);
    int i;
    for(i = 0; i < ln; i++) {
        str[i] = (char)chars[i];
    }
    str[ln] = 0;
    return str;
}

static JSValueRef
js_window_get_property(JSContextRef ctx, JSObjectRef object, JSStringRef propertyName, JSValueRef* exception)
{

    size_t ln = JSStringGetLength(propertyName);
    const JSChar* chars = JSStringGetCharactersPtr(propertyName);

    char *str = JSChar_cstr(chars, ln);

    //g_print("is \n", );

    if (0==strcmp(str, "document")) {
        g_print("property=\"%s\"\n", str);
    } else {
        g_print("\"%s\" is not defined\n", str);
    }

    free(str);

    return NULL;//0 parent chain; -1 break chainable;
    return object;

    /*JSValueRef function = JSObjectGetProperty(ctx, object, propertyName, NULL);
    if (!function || !JSValueIsObject(ctx, function))
        return NULL;
    return (JSObjectRef)function;*/

//    JSClassRef js_window_alert_class = JSClassCreate(&js_window_alert_def);
//    JSObjectRef o = JSObjectMake(ctx, js_window_alert_class, NULL);

    /*
    // Get the property name as a NSString
    NSString*	propertyName = (NSString*)JSStringCopyCFString(kCFAllocatorDefault, propertyNameJS);
    [NSMakeCollectable(propertyName) autorelease];
    // From there you can return values, functions, objects, or throw an exception
    if ([propertyName isEqualToString:@"myNumber"])
        return JSValueMakeNumber(ctx, 1.23);
    if ([propertyName isEqualToString:@"hello"]) {
        JSStringRef string = JSStringCreateWithUTF8CString("world");
        JSValueRef result = JSValueMakeString(ctx, string);
        JSStringRelease(string);
        return result;
    }

    // Throw an exception
    if ([propertyName isEqualToString:@"notYet"]) {
        JSStringRef string = JSStringCreateWithUTF8CString("Data not ready");
        JSValueRef exceptionString = JSValueMakeString(ctx, string);
        JSStringRelease(string);
        // Converting the result to an object will let JavascriptCore add source URL and line number to the exception,
        // instead of just returning a raw
        string *exception = JSValueToObject(ctx, exceptionString, NULL);
        return NULL;
    }
    */

    // JavascriptCore might crash if you return NULL in some functions, so always return a Javascript object
    // Here, we return undefined
    return JSValueMakeUndefined(ctx);
}

/* Class initialize */
static void js_window_init_cb(JSContextRef ctx,
                          JSObjectRef object)
{
    g_message("window class initialize.");
}

/* Class finalize */
static void js_window_finalize_cb(JSObjectRef object)
{
    g_message("window class finalize.");
}


/* Class constructor. Called at "new CustomClass()" */
JSObjectRef js_window_constructor_cb(JSContextRef ctx,
                                     JSObjectRef constructor,
                                     size_t argumentCount,
                                     const JSValueRef arguments[],
                                     JSValueRef* exception)
{
    g_message("window class constructor");
    //JSStringRef str = JSStringCreateWithUTF8CString("alert");
    //JSObjectSetProperty(ctx, global_object, str, classObj, kJSPropertyAttributeNone, NULL);

}
typedef struct _My {
    int foo;
} My;

/* window.trace method callback implementation */
static JSValueRef js_window_trace_cb(JSContextRef context,
                                     JSObjectRef function,
                                     JSObjectRef thisObject,
                                     size_t argumentCount,
                                     const JSValueRef arguments[],
                                     JSValueRef *exception)
{
    /* At least, one argument must be received */
    if (argumentCount == 1 && JSValueIsString(context, arguments[0])) {
        /* Converts JSValue to char */
        size_t len;
        char *cstr;
        JSStringRef jsstr = JSValueToStringCopy(context, arguments[0], NULL);
        len = JSStringGetMaximumUTF8CStringSize(jsstr);
        cstr = g_new(char, len);
        JSStringGetUTF8CString(jsstr, cstr, len);

        /* Creates a new NotifyNotification. */
        //NotifyNotification *notification = notify_notification_new(cstr, NULL, NULL);

        /* Sets the timeout of the notification. */
        //notify_notification_set_timeout(notification, 3000);

        /* Sets the urgency level of this notification. */
        //notify_notification_set_urgency(notification, NOTIFY_URGENCY_NORMAL);

        /* Tells the notification server to display the notification on the screen. */
        //GError *error = NULL;
        //notify_notification_show(notification, &error);

        //g_object_unref(G_OBJECT(notification));
        My* my = (My*) JSObjectGetPrivate(thisObject);

        my_window.trace(g_strdup_printf("My->foo = %d", my->foo));// get Active Document
        my_window.trace(cstr);
        g_free(cstr);

        JSStringRelease(jsstr);
    } /*else if (argumentCount == 1 && JSValueIsObject(context, arguments[0])) {

    }*/

    return JSValueMakeUndefined(context);
}
static const JSStaticFunction js_window_staticfuncs[] =
{
    { "trace", js_window_trace_cb, kJSPropertyAttributeReadOnly },
    { NULL, NULL, 0 }
};


static const JSClassDefinition js_window_def =
{
    0,                          // version
    kJSClassAttributeNone,      // attributes
    "Window",                   // className
    NULL,                       // parentClass
    NULL,                       // staticValues
    js_window_staticfuncs,      // staticFunctions
    js_window_init_cb,          // initialize
    NULL,//js_window_finalize_cb,      // finalize
    NULL,                       // hasProperty
    js_window_get_property,     // getProperty
    NULL,                       // setProperty
    NULL,                       // deleteProperty
    NULL,                       // getPropertyNames
    NULL,                       // callAsFunction
    NULL,//js_window_constructor_cb,   // callAsConstructor
    NULL,                       // hasInstance
    NULL                        // convertToType
};

/*
 * http://rvr.typepad.com/wind/2011/10/webkit-extending-javascript-1.html
 * http://rvr.typepad.com/wind/2011/10/webkit-extending-javascript-2.html
 *
 * http://gxjones.blogspot.fr/2008/02/javascript-core-in-leopard-basics.html
 * http://parmanoir.com/Taming_JavascriptCore_within_and_without_WebView
 *
 * https://github.com/evanphx/webui/blob/master/ext/webui_gtk.c
 */

void
test_svg_js_suite_test1(void) {
    my_window.trace("");

    // Init
    JSClassRef classDef = JSClassCreate(&js_window_def);
    JSContextRef context = JSGlobalContextCreate(classDef);
    JSObjectRef globalObj = JSContextGetGlobalObject(context);

    My* my = g_new(My, 1);// GScapeWindow
    my->foo = 365;
    if(!JSObjectSetPrivate(globalObj, my)) {
      printf("JsSvg is busted.\n");
    }
    JSStringRef str = JSStringCreateWithUTF8CString("window");
    JSObjectSetProperty(context, globalObj, str, globalObj, kJSPropertyAttributeNone, NULL);
    JSStringRelease(str);

    /*
    JSClassRef classDef = JSClassCreate(&js_window_def);
    JSContextRef context = JSGlobalContextCreate(classDef);
    JSObjectRef classObj = JSObjectMake(context, classDef, context);
    JSObjectRef globalObj = JSContextGetGlobalObject(context);
    JSStringRef str = JSStringCreateWithUTF8CString("window");
    JSObjectSetProperty(context, globalObj, str, classObj, kJSPropertyAttributeNone, NULL);
    */


    /* Add classes to JavaScriptCore */
/*
    JSClassRef classDef = JSClassCreate(&notification_def);
    JSObjectRef classObj = JSObjectMake(context, classDef, context);
    JSObjectRef globalObj = JSContextGetGlobalObject(context);
    JSStringRef str = JSStringCreateWithUTF8CString("Notification");
    JSObjectSetProperty(context, globalObj, str, classObj, kJSPropertyAttributeNone, NULL);
*/

/*
    JSClassRef window_trace_class = JSClassCreate(&js_window_trace_def);
    JSObjectRef trace_object = JSObjectMake(context, window_trace_class, NULL);
    JSStringRef	name = JSStringCreateWithUTF8CString("trace");
    JSObjectSetProperty(context, global_object, name, trace_object, kJSPropertyAttributeDontDelete, NULL);
    JSStringRelease(name);
*/

    //JSStringRef script = JSStringCreateWithUTF8CString("window.document;");
    JSStringRef script = JSStringCreateWithUTF8CString("trace(\"Hello World!\");");
    JSEvaluateScript(context, script, NULL, NULL, 0, NULL);
    JSStringRelease(script);

    JSStringRef script2 = JSStringCreateWithUTF8CString("window.document;");
    JSEvaluateScript(context, script2, NULL, NULL, 0, NULL);
    JSStringRelease(script2);

    // Release
    JSGlobalContextRelease(context);
}
//GScale
GTestSuite *
test_svg_js_create_suite(void) {
    GTestSuite *suite_suite = g_test_create_suite("libsvgjs");

    g_test_suite_add (suite_suite, TESTCASE (test_svg_js_suite_test1, NULL));

	return suite_suite;
}

#if 0

DomDocument::factory(SVG_TYPE_DOCUMENT);
DomDocument.implementation = libsvgtk

doc = new DomDocument();
doc.createElementNS();
elt = new SvgElementRect();

doc = DomDocument::load("<svg></svg>");
doc.setImplementation();
DomDocument::register(MimeType, SVG_TYPE_DOCUMENT);

#endif
