var func = window.alert("Hello World");
