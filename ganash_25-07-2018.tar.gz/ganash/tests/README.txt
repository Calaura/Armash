/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * main.c
 * Copyright (C) 2014 Unknown <instant@ganash-System-Product-Name>
 *
 * SVGDOM is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SVGDOM is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib/gtestutils.h>
#include <gdk/gdk.h>


#include "libmath/math-polynomial.h"

#include "libgeom/geom-point.h"
#include "libgeom/geom-polygon.h"
#include "libgeom/geom-rectangle.h"
#include "libgeom/geom-bezier.h"

#include <libgraphics/graphics.h>

#include <glib-object.h>
#include <librenderer/renderer-types.h>
#include <librenderer/renderer-enums.h>
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-rect.h"



#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-paint.h"
#include "libsvg/svg-document.h"
#define M_PI 3.1415926535

#include "tests/libmath/test-suite.h"
#include "tests/libgeom/test-suite.h"
#include "tests/librenderer/test-suite.h"
#include "tests/libsvg/test-suite.h"
#include "tests/libmotion/test-suite.h"



cairo_path_t *create_path()
{
    cairo_surface_t *surface;
    cairo_t *cr;
    cairo_path_t *path;

    surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 400, 600);
    cr = cairo_create(surface);

    cairo_move_to(cr,   0.0,   0.0);
    cairo_line_to(cr, 100.0,   0.0);
    cairo_line_to(cr, 100.0, 100.0);
    cairo_line_to(cr,   0.0, 100.0);
    cairo_line_to(cr,   0.0,   0.0);

    path = cairo_copy_path(cr);

    cairo_surface_destroy(surface);
    cairo_destroy(cr);
    return path;
}

int mainZ(void)
{
  cairo_surface_t *surface;
  cairo_t *cr;

  surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 400, 600);
  cr = cairo_create(surface);

  //cairo_rotate(cr, 45*M_PI/180);
  //cairo_translate(cr, 100, 100);
  //cairo_matrix_multiply(matrix, matrix, matrix_translate);
  cairo_matrix_t matrix;
  cairo_matrix_init_translate(&matrix, 10, 10);
  cairo_matrix_invert(&matrix);

  cairo_matrix_t identity;
  cairo_matrix_init_identity(&identity);


  cairo_path_t *path = create_path();
  cairo_append_path(cr, path);
  cairo_set_matrix(cr, &matrix);

  cairo_path_t *tmp_path = cairo_copy_path(cr);
  cairo_set_matrix(cr, &identity);
  //cairo_new_path(cr);

  //g_print("%s\n", graphics_path_debug(path));
  //g_print("\n");
  //g_print("%s\n", graphics_path_debug(tmp_path));



  cairo_set_source_rgb(cr, 0, 0, 1.0);
  cairo_fill(cr);

  cairo_surface_write_to_png(surface, "meshtest.png");

  cairo_destroy(cr);
  cairo_surface_destroy(surface);

  return 0;
}

int mainY(void)
{
  cairo_surface_t *surface;
  cairo_t *cr;

  cairo_matrix_t *mtrx = (cairo_matrix_t *) malloc(sizeof(cairo_matrix_t));
  cairo_matrix_init_translate(mtrx, 141, 0);

  cairo_matrix_t *matrix_translate = (cairo_matrix_t *) malloc(sizeof(cairo_matrix_t));
  cairo_matrix_init_translate(matrix_translate, 100, 100);
  cairo_matrix_t *matrix_rotate = (cairo_matrix_t *) malloc(sizeof(cairo_matrix_t));
  cairo_matrix_init_rotate(matrix_rotate, 45*M_PI/180);
  cairo_matrix_t *matrix = (cairo_matrix_t *) malloc(sizeof(cairo_matrix_t));
  cairo_matrix_init_identity(matrix);
  //cairo_matrix_multiply(matrix, matrix_rotate, matrix_translate);
  cairo_matrix_multiply(matrix, matrix_translate, matrix_rotate);

  surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 400, 600);
  cr = cairo_create(surface);

  //cairo_rotate(cr, 45*M_PI/180);
  //cairo_translate(cr, 100, 100);
  //cairo_matrix_multiply(matrix, matrix, matrix_translate);
  cairo_set_matrix(cr, matrix);

  cairo_move_to(cr,   0.0,   0.0);
  cairo_line_to(cr, 100.0,   0.0);
  cairo_line_to(cr, 100.0, 100.0);
  cairo_line_to(cr,   0.0, 100.0);
  cairo_line_to(cr,   0.0,   0.0);

  cairo_set_source_rgb(cr, 0, 0, 1.0);
  cairo_fill(cr);

  cairo_surface_write_to_png(surface, "meshtest.png");

  cairo_destroy(cr);
  cairo_surface_destroy(surface);

  return 0;
}


int main_a(int argc, char * argv[]) {

    gtk_test_init (&argc, &argv);

    GTestSuite *suite;
    suite = g_test_get_root ();

    //GTestSuite *suite_log = test_log_create_suite();
    //g_test_suite_add_suite(suite, suite_log);

    GTestSuite *suite_math = test_math_create_suite();
    g_test_suite_add_suite(suite, suite_math);

    GTestSuite *suite_geom = test_geom_create_suite();
    g_test_suite_add_suite(suite, suite_geom);

    GTestSuite *suite_svg = test_svg_create_suite();
    g_test_suite_add_suite(suite, suite_svg);

    GTestSuite *suite_motion = test_motion_create_suite();
    g_test_suite_add_suite(suite, suite_motion);

    GTestSuite *suite_renderer = test_renderer_create_suite();
    g_test_suite_add_suite(suite, suite_renderer);

    g_print("\n");
    return g_test_run();












/*
    const gchar* filename = "/home/emile/Images/square.svg";
    SvgDocument* svg_doc = dom_parser_load_svg(filename);
    RendererObject* renderer = svg_element_get_renderer(svg_doc->root);
    return 0;
*/

/*
    cairo_surface_t* surface = cairo_image_surface_create (CAIRO_FORMAT_A8, 0, 0);
    cairo_t* cr = cairo_create(surface);
    cairo_move_to(cr,   0.0,   0.0);
    cairo_line_to(cr, 100.0,   0.0);
    cairo_line_to(cr, 100.0, 100.0);
    //cairo_line_to(cr,   0.0, 100.0);
    //cairo_line_to(cr,   0.0,   0.0);
    double x, y, width, height;
    cairo_rotate(cr, 0.0);
    cairo_fill_extents(cr, &x, &y, &width, &height);
    g_print("\n");
    g_print("{x: %f, y%f, width: %f, height: %f}\n", x, y, width, height);
*/

    cairo_surface_t* cr_s = cairo_image_surface_create ( CAIRO_FORMAT_ARGB32, 200, 200 );
    cairo_t* cr = cairo_create(cr_s);
    cairo_set_source_rgb (cr, 1.0, 1.0, 1.0); /* white */
    cairo_paint (cr);
//  Create first patch
    cairo_save(cr);
    cairo_pattern_t *pattern = cairo_pattern_create_mesh ();

    /* Add a Coons patch */
    cairo_mesh_pattern_begin_patch (pattern);
    cairo_mesh_pattern_move_to (pattern, 0, 0);
    cairo_mesh_pattern_curve_to (pattern, 30, -30,  60,  30, 100, 0);
    cairo_mesh_pattern_curve_to (pattern, 60,  30, 130,  60, 100, 100);
    cairo_mesh_pattern_curve_to (pattern, 60,  70,  30, 130,   0, 100);
    cairo_mesh_pattern_curve_to (pattern, 30,  70, -30,  30,   0, 0);
    cairo_mesh_pattern_set_corner_color_rgb (pattern, 0, 1, 0, 0);
    cairo_mesh_pattern_set_corner_color_rgb (pattern, 1, 0, 1, 0);
    cairo_mesh_pattern_set_corner_color_rgb (pattern, 2, 0, 0, 1);
    cairo_mesh_pattern_set_corner_color_rgb (pattern, 3, 1, 1, 0);
    cairo_mesh_pattern_end_patch (pattern);

    /* Add a Gouraud-shaded triangle */
    /*cairo_mesh_pattern_begin_patch (pattern);
    cairo_mesh_pattern_move_to (pattern, 100, 100);
    cairo_mesh_pattern_line_to (pattern, 130, 130);
    cairo_mesh_pattern_line_to (pattern, 130,  70);
    cairo_mesh_pattern_set_corner_color_rgb (pattern, 0, 1, 0, 0);
    cairo_mesh_pattern_set_corner_color_rgb (pattern, 1, 0, 1, 0);
    cairo_mesh_pattern_set_corner_color_rgb (pattern, 2, 0, 0, 1);
    cairo_mesh_pattern_end_patch (pattern);*/

    cairo_set_source (cr, pattern);
    cairo_rectangle(cr, 0, 0, 300, 300);
    cairo_paint_with_alpha (cr, 1);
    cairo_pattern_destroy (pattern);

    cairo_surface_write_to_png(cr_s, "meshtest.png");
    cairo_destroy (cr);
    cairo_surface_destroy (cr_s);    return 0;


}
