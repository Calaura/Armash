/*
 * test-math-polynomial.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "test-math-polynomial.h"

#include "libmath/math-polynomial.h"

#include <math.h>


void
test_math_polynomial2_solve (void)
{
    MathPolynomial2 poly = {MATH_POLYNOMIAL_QUAD_DEGREE,
                            6, -8, 2};

    double x0;
    double x1;
    int num;

    num = math_polynomial2_solve(poly.a, poly.b, poly.c, &x0, &x1);
    g_assert (num == 2);
    g_assert (x0  == 1);
    g_assert (x1  == 3);

}

void
test_math_polynomial1_solve (void)
{
    MathPolynomial1 poly = {1,
                            6, 1};

    double x0;
    int num;
    num = math_polynomial1_solve(poly.a, poly.b, &x0);
    g_assert (num == 1);
    g_assert (x0  == -6);

}

void
test_math_polynomial2_eval (void)
{
    MathPolynomial2 poly = {MATH_POLYNOMIAL_QUAD_DEGREE,
                            6, -8, 2};

    double eval = math_polynomial2_eval(poly.a, poly.b, poly.c, 1.0);
    g_assert (eval == 0.0);
}

void
test_math_polynomial1_eval (void)
{
    MathPolynomial1 poly = {1,
                            6, 1};
    double eval = math_polynomial1_eval(poly.a, poly.b, 1.0);
    g_assert (eval  == 7.0);
}

GTestSuite *
test_math_polynomial_create_suite(void)
{
    GTestSuite *suite_math = g_test_create_suite("polynomial");

    g_test_suite_add (suite_math, TESTCASE (test_math_polynomial1_solve, NULL));
    g_test_suite_add (suite_math, TESTCASE (test_math_polynomial2_eval, NULL));

    g_test_suite_add (suite_math, TESTCASE (test_math_polynomial1_solve, NULL));
    g_test_suite_add (suite_math, TESTCASE (test_math_polynomial2_solve, NULL));

    return suite_math;
}
