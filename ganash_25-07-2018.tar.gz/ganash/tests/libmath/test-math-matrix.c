#include "test-math-matrix.h"

void
test_math_matrix_test1(void) {
	g_test_message("Not implemented");
	/* Add asserts */
}

GTestSuite *
test_math_matrix_create_suite(void) {
    GTestSuite *suite_math_matrix = g_test_create_suite("matrix");

	g_test_suite_add (suite_math_matrix, TESTCASE (test_math_matrix_test1, NULL));

	return suite_math_matrix;
}
