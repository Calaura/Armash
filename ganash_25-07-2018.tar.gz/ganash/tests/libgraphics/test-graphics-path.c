#include "test-graphics-path.h"

#include "libgraphics/graphics.h"


void
test_graphics_path_test1(void) {
    g_test_message("Not implemented");
    /* Add asserts */

    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_INVALID, 0, 0);
    cairo_t *cr = cairo_create(surface);
    cairo_rectangle(cr, 0, 0, 50, 50);
    cairo_path_t *c_path = cairo_copy_path(cr);
    cairo_surface_destroy(surface);
    cairo_destroy(cr);

/*
    GraphicsPath *path = graphics_path_new();
    graphics_path_set(path, c_path);
    graphics_path_bounding_box(path, cr);
*/
}

void
test_graphics_path_test2(void) {
    cairo_path_t *cr_path = NULL;
    GraphicsPath *path = graphics_path_new();
///    graphics_path_move_to(path, 0.0, 0.0);
///    graphics_path_line_to(path, 50.0, 0.0);
///    graphics_path_line_to(path, 50.0, 50.0);
///    graphics_path_line_to(path, 0.0, 50.0);
    //graphics_path_close(path); // square
    graphics_path_move_to(path, 0.0, 0.0);
    graphics_path_line_to(path, 25.0, 50.0);
    graphics_path_line_to(path, 50.0, 0.0);
    //graphics_path_close(path); // triangle


    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 100, 100);
    cairo_t *cr = cairo_create(surface);

//    cairo_new_path(cr);
//    cairo_move_to(cr, 0.0, 0.0);
//    cairo_line_to(cr, 50.0, 0.0);
//    cairo_line_to(cr, 50.0, 50.0);
//    cairo_line_to(cr, 0.0, 50.0);
//    cairo_close_path(cr);
//    cairo_path_t *cr_path = cairo_copy_path(cr);

    cairo_new_path(cr);
    cairo_move_to(cr,   0.0,   0.0);
    cairo_line_to(cr, 100.0,   0.0);
    cairo_line_to(cr, 100.0, 100.0);
    cairo_line_to(cr,   0.0, 100.0);
    cairo_line_to(cr,   0.0,   0.0);
    cairo_set_source_rgb(cr, 0.0, 0.0, 1.0);
    cairo_fill(cr);

    cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
    cairo_set_line_width(cr, 2.0);
    cr_path = graphics_path_to_cairo(path);
    cairo_append_path(cr, cr_path);
//    cairo_rectangle(cr, 0.0, 0.0, 50.0, 50.0);
    cairo_fill(cr);

    //cairo_status_t success = cairo_surface_write_to_png(surface, TEST_DIR "/path.png");
    //if (CAIRO_STATUS_SUCCESS!=success)
    //    g_print("status %d\n", success);

    cairo_surface_destroy(surface);
    cairo_destroy(cr);


    g_object_unref(path);
}

void
test_graphics_path_line_to(void) {
    GraphicsPath *path = graphics_path_new();
    graphics_path_move_to(path, 10.0, 10.0);
    graphics_path_line_to(path, 35.0, 60.0);
    graphics_path_line_to(path, 60.0, 10.0);
    graphics_path_close(path); // triangle


    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 100, 100);
    cairo_t *cr = cairo_create(surface);
    cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
    cairo_set_line_width(cr, 4.0);
    cairo_path_t *cr_path = graphics_path_to_cairo(path);
    cairo_append_path(cr, cr_path);
    cairo_stroke(cr);

    cairo_status_t success = cairo_surface_write_to_png(surface, TEST_DIR "/path-line-to.png");
    if (CAIRO_STATUS_SUCCESS!=success)
        g_print("status %d\n", success);

    cairo_surface_destroy(surface);
    cairo_destroy(cr);

    g_object_unref(path);
}

void
test_graphics_path_curve_to(void) {
    GraphicsPath *path = graphics_path_new();
    graphics_path_move_to(path, 10.0, 10.0);
    graphics_path_curve_to(path, 10.0, 60.0, 60.0, 60.0, 60.0, 10.0);
    //graphics_path_close(path); // triangle
    //graphics_path_curve_at(path, 10.0, 60.0, 60.0, 60.0, 60.0, 10.0, 1);


    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 100, 100);
    cairo_t *cr = cairo_create(surface);
    cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
    cairo_set_line_width(cr, 4.0);
    cairo_path_t *cr_path = graphics_path_to_cairo(path);
    cairo_append_path(cr, cr_path);
    cairo_stroke(cr);

    cairo_status_t success = cairo_surface_write_to_png(surface, TEST_DIR "/path-curve-to.png");
    if (CAIRO_STATUS_SUCCESS!=success)
        g_print("status %d\n", success);

    cairo_surface_destroy(surface);
    cairo_destroy(cr);

    g_object_unref(path);
}

void
test_graphics_path_arc_to(void) {
    GraphicsPath *path = graphics_path_new();
    graphics_path_move_to(path, 35.0, 35.0);
    graphics_path_arc(path, 35.0, 35.0, 25.0, 0, 3.1415/2);
    graphics_path_close(path); // triangle
    //graphics_path_curve_at(path, 10.0, 60.0, 60.0, 60.0, 60.0, 10.0, 1);


    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 100, 100);
    cairo_t *cr = cairo_create(surface);
    cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
    cairo_set_line_width(cr, 4.0);
    cairo_path_t *cr_path = graphics_path_to_cairo(path);
    cairo_append_path(cr, cr_path);
    cairo_stroke(cr);

    cairo_status_t success = cairo_surface_write_to_png(surface, TEST_DIR "/path-arc-to.png");
    if (CAIRO_STATUS_SUCCESS!=success)
        g_print("status %d\n", success);

    cairo_surface_destroy(surface);
    cairo_destroy(cr);

    g_object_unref(path);
}
#include <math.h>
void
test_graphics_path_rounded_rectangle(void) {
    GraphicsPath *path = graphics_path_new();
        gdouble x = 10;
        gdouble y = 10;
        gdouble width = 50;
        gdouble height = 50;
        gdouble r1 = 14;
        gdouble r2 = 0;
        gdouble r3 = 14;
        gdouble r4 = 0;
        gdouble radius;
        gdouble degrees = M_PI / 180.0;

        if (r1>0.0) {
            radius = r1;
            graphics_path_move_to(path, x + width - radius, y);
            graphics_path_arc (path, x + width - radius, y + radius, radius, -90 * degrees, 0 * degrees);
        } else {
            graphics_path_move_to(path, x + width, y);
        }
        if (r2>0) {
            radius = r2;
            graphics_path_arc (path, x + width - radius, y + height - radius, radius, 0 * degrees, 90 * degrees);
        } else {
            graphics_path_line_to(path, x + width, y + height);
        }
        if (r3>0) {
            radius = r3;
            graphics_path_arc (path, x + radius, y + height - radius, radius, 90 * degrees, 180 * degrees);
        } else {
            graphics_path_line_to(path, x, y + height);
        }
        if (r4>0) {
            radius = r4;
            graphics_path_arc (path, x + radius, y + radius, radius, 180 * degrees, 270 * degrees);
        } else {
            graphics_path_line_to(path, x, y);
        }
        graphics_path_close (path);


    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 100, 100);
    cairo_t *cr = cairo_create(surface);
    cairo_set_source_rgb(cr, 1.0, 0.0, 0.0);
    cairo_set_line_width(cr, 4.0);
    cairo_path_t *cr_path = graphics_path_to_cairo(path);
    cairo_append_path(cr, cr_path);
    cairo_stroke(cr);

    cairo_status_t success = cairo_surface_write_to_png(surface, TEST_DIR "/rounded-rectangle.png");
    if (CAIRO_STATUS_SUCCESS!=success)
        g_print("status %d\n", success);

    cairo_surface_destroy(surface);
    cairo_destroy(cr);

    g_object_unref(path);
}

GTestSuite *
test_graphics_path_create_suite(void) {
    GTestSuite *suite_graphics_path = g_test_create_suite("path");

    g_test_suite_add (suite_graphics_path, TESTCASE_GRAPHICS_PATH (test1, NULL));
    g_test_suite_add (suite_graphics_path, TESTCASE_GRAPHICS_PATH (test2, NULL));
    g_test_suite_add (suite_graphics_path, TESTCASE_GRAPHICS_PATH (line_to, NULL));
    g_test_suite_add (suite_graphics_path, TESTCASE_GRAPHICS_PATH (curve_to, NULL));
    g_test_suite_add (suite_graphics_path, TESTCASE_GRAPHICS_PATH (arc_to, NULL));
    g_test_suite_add (suite_graphics_path, TESTCASE_GRAPHICS_PATH (rounded_rectangle, NULL));


	return suite_graphics_path;
}

