#include "test-graphics-image.h"

#include <cairo/cairo.h>
#include "test-lib.h"

#include <libgraphics/graphics.h>

static void
test_graphics_image_to_context1(cairo_t *cr, gboolean preserve) {
    GraphicsImage   *img     = graphics_image_new_from_uri(TEST_GRAPHICS_SHARE_DIR "pattern.png");
    graphics_image_scale(img, 0.1, 0.1);
    GraphicsPainter *painter = graphics_painter_new();
    graphics_painter_set_image(painter, img);
    GraphicsFill  *fill  = graphics_fill_new();
    fill->painter = painter;

    cairo_move_to(cr,   0.0,   0.0);
    cairo_line_to(cr, 100.0,   0.0);
    cairo_line_to(cr, 100.0, 100.0);
    cairo_line_to(cr,   0.0, 100.0);
    cairo_line_to(cr,   0.0,   0.0);


    graphics_fill_to_context(fill, cr, FALSE);
}

void
test_graphics_image_test1(void) {
    test_lib_graphics_assert_cmpsurface(test_graphics_image_to_context1, "pattern.test.png", FALSE, TEST_SURFACE_GENERATE);
}


GTestSuite *
test_graphics_image_create_suite(void) {
    GTestSuite *suite_graphics_image = g_test_create_suite("image");

	g_test_suite_add (suite_graphics_image, TESTCASE (test_graphics_image_test1, NULL));

	return suite_graphics_image;
}
