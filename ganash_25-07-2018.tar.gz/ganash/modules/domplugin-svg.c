#include <glib-object.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-implementation.h"

static SvgImplementation *implementation = 0;


