/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-path.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "graphics.h"
#include "graphics-path.h"

#include <math.h>

static void graphics_path_class_init(GraphicsPathClass *klass);
static void graphics_path_init(GraphicsPath *gobject);

G_DEFINE_TYPE (GraphicsPath, graphics_path, G_TYPE_OBJECT)

static void
graphics_path_init (GraphicsPath *object)
{
    object->path = NULL;
    object->segments = g_array_sized_new(FALSE, FALSE, sizeof(cairo_path_data_t), 2);
}

static void
graphics_path_finalize(GObject *object)
{
    GraphicsPath *path = GRAPHICS_PATH(object);
    if (path->path)
        cairo_path_destroy(path->path);

    G_OBJECT_CLASS (graphics_path_parent_class)->finalize (object);
}
static void
graphics_path_class_init(GraphicsPathClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = graphics_path_finalize;

//	graphics_path_parent_class = g_type_class_peek_parent (klass);
}


GraphicsPath *
graphics_path_new (void)
{
	return g_object_new (graphics_path_get_type (),
	                     NULL);
}

gboolean graphics_path_is_empty(GraphicsPath *path)
{
    /*
    if (!path)
        return TRUE;
    if (!path->path)
        return TRUE;

    if (path->path->num_data>1)
        return FALSE;

    return TRUE;
    */
    if (path->cr_index>0) {
        return FALSE;
    }
    return TRUE;
}

void graphics_path_reset(GraphicsPath *path)
{
    path->cr_index = 0;
}

void graphics_path_move_to(GraphicsPath *path, gdouble x, gdouble y)
{
    if (path->cr_index >= path->segments->len) {
        cairo_path_data_t data[2];
        data[0].header.type = CAIRO_PATH_MOVE_TO;
        data[0].header.length = 2;
        data[1].point.x = x;
        data[1].point.y= y;
        g_array_append_vals(path->segments, &data, 2);
    } else {
        cairo_path_data_t *data = &g_array_index(path->segments, cairo_path_data_t, path->cr_index);
        data[1].point.x = x;
        data[1].point.y = y;
    }
    path->cr_index += 2;
}

void graphics_path_line_to(GraphicsPath *path, gdouble x, gdouble y)
{
    if (path->cr_index >= path->segments->len) {
        cairo_path_data_t data[2];
        data[0].header.type = CAIRO_PATH_LINE_TO;
        data[0].header.length = 2;
        data[1].point.x = x;
        data[1].point.y= y;
        g_array_append_vals(path->segments, &data, 2);
    } else {
        cairo_path_data_t *data = &g_array_index(path->segments, cairo_path_data_t, path->cr_index);
        data[1].point.x = x;
        data[1].point.y = y;
    }
    path->cr_index += 2;
}

void graphics_path_curve_to(GraphicsPath *path, gdouble x1, gdouble y1, gdouble x2, gdouble y2, gdouble x3, gdouble y3)
{
    if (path->cr_index >= path->segments->len) {
        cairo_path_data_t data[4];
        data[0].header.type = CAIRO_PATH_CURVE_TO;
        data[0].header.length = 4;
        data[1].point.x = x1;
        data[1].point.y = y1;
        data[2].point.x = x2;
        data[2].point.y = y2;
        data[3].point.x = x3;
        data[3].point.y = y3;
        g_array_append_vals(path->segments, &data, 4);
    } else {
        cairo_path_data_t *data = &g_array_index(path->segments, cairo_path_data_t, path->cr_index);
        data[1].point.x = x1;
        data[1].point.y = y1;
        data[2].point.x = x2;
        data[2].point.y = y2;
        data[3].point.x = x3;
        data[3].point.y = y3;
    }
    path->cr_index += 4;
}

#define ARRAY_LENGTH(array) (sizeof(array)/sizeof(array[0]))
typedef enum _cairo_direction {
    CAIRO_DIRECTION_FORWARD,
    CAIRO_DIRECTION_REVERSE
} cairo_direction_t;

void
_cairo_matrix_get_affine (const cairo_matrix_t *matrix,
              double *xx, double *yx,
              double *xy, double *yy,
              double *x0, double *y0)
{
    *xx  = matrix->xx;
    *yx  = matrix->yx;

    *xy  = matrix->xy;
    *yy  = matrix->yy;

    if (x0)
    *x0 = matrix->x0;
    if (y0)
    *y0 = matrix->y0;
}
/* determine the length of the major axis of a circle of the given radius
   after applying the transformation matrix. */
double
_cairo_matrix_transformed_circle_major_axis (cairo_matrix_t *matrix, double radius)
{
    double  a, b, c, d, f, g, h, i, j;

    _cairo_matrix_get_affine (matrix,
                              &a, &b,
                              &c, &d,
                              NULL, NULL);

    i = a*a + b*b;
    j = c*c + d*d;

    f = 0.5 * (i + j);
    g = 0.5 * (i - j);
    h = a*c + b*d;

    return radius * sqrt (f + sqrt (g*g+h*h));

    /*
     * we don't need the minor axis length, which is
     * double min = radius * sqrt (f - sqrt (g*g+h*h));
     */
}
/* Spline deviation from the circle in radius would be given by:
    error = sqrt (x**2 + y**2) - 1
   A simpler error function to work with is:
    e = x**2 + y**2 - 1
   From "Good approximation of circles by curvature-continuous Bezier
   curves", Tor Dokken and Morten Daehlen, Computer Aided Geometric
   Design 8 (1990) 22-41, we learn:
    abs (max(e)) = 4/27 * sin**6(angle/4) / cos**2(angle/4)
   and
    abs (error) =~ 1/2 * e
   Of course, this error value applies only for the particular spline
   approximation that is used in _cairo_gstate_arc_segment.
*/
static double
_arc_error_normalized (double angle)
{
    return 2.0/27.0 * pow (sin (angle / 4), 6) / pow (cos (angle / 4), 2);
}

static double
_arc_max_angle_for_tolerance_normalized (double tolerance)
{
    double angle, error;
    int i;

    /* Use table lookup to reduce search time in most cases. */
    struct {
    double angle;
    double error;
    } table[] = {
    { M_PI / 1.0,   0.0185185185185185036127 },
    { M_PI / 2.0,   0.000272567143730179811158 },
    { M_PI / 3.0,   2.38647043651461047433e-05 },
    { M_PI / 4.0,   4.2455377443222443279e-06 },
    { M_PI / 5.0,   1.11281001494389081528e-06 },
    { M_PI / 6.0,   3.72662000942734705475e-07 },
    { M_PI / 7.0,   1.47783685574284411325e-07 },
    { M_PI / 8.0,   6.63240432022601149057e-08 },
    { M_PI / 9.0,   3.2715520137536980553e-08 },
    { M_PI / 10.0,  1.73863223499021216974e-08 },
    { M_PI / 11.0,  9.81410988043554039085e-09 },
    };
    int table_size = ARRAY_LENGTH (table);

    for (i = 0; i < table_size; i++)
    if (table[i].error < tolerance)
        return table[i].angle;

    ++i;
    do {
    angle = M_PI / i++;
    error = _arc_error_normalized (angle);
    } while (error > tolerance);

    return angle;
}

static int
_arc_segments_needed (double	      angle,
              double	      radius,
              cairo_matrix_t *ctm,
              double	      tolerance)
{
    double major_axis, max_angle;

    /* the error is amplified by at most the length of the
     * major axis of the circle; see cairo-pen.c for a more detailed analysis
     * of this. */
    major_axis = _cairo_matrix_transformed_circle_major_axis (ctm, radius);
    max_angle = _arc_max_angle_for_tolerance_normalized (tolerance / major_axis);

    return (int) ceil (angle / max_angle);
}

/* We want to draw a single spline approximating a circular arc radius
   R from angle A to angle B. Since we want a symmetric spline that
   matches the endpoints of the arc in position and slope, we know
   that the spline control points must be:
    (R * cos(A), R * sin(A))
    (R * cos(A) - h * sin(A), R * sin(A) + h * cos (A))
    (R * cos(B) + h * sin(B), R * sin(B) - h * cos (B))
    (R * cos(B), R * sin(B))
   for some value of h.
   "Approximation of circular arcs by cubic poynomials", Michael
   Goldapp, Computer Aided Geometric Design 8 (1991) 227-238, provides
   various values of h along with error analysis for each.
   From that paper, a very practical value of h is:
    h = 4/3 * tan(angle/4)
   This value does not give the spline with minimal error, but it does
   provide a very good approximation, (6th-order convergence), and the
   error expression is quite simple, (see the comment for
   _arc_error_normalized).
*/
static void
_cairo_arc_segment (GraphicsPath *path,
            double   xc,
            double   yc,
            double   radius,
            double   angle_A,
            double   angle_B)
{
    double r_sin_A, r_cos_A;
    double r_sin_B, r_cos_B;
    double h;

    r_sin_A = radius * sin (angle_A);
    r_cos_A = radius * cos (angle_A);
    r_sin_B = radius * sin (angle_B);
    r_cos_B = radius * cos (angle_B);

    h = 4.0/3.0 * tan ((angle_B - angle_A) / 4.0);

    graphics_path_curve_to (path,
            xc + r_cos_A - h * r_sin_A,
            yc + r_sin_A + h * r_cos_A,
            xc + r_cos_B + h * r_sin_B,
            yc + r_sin_B - h * r_cos_B,
            xc + r_cos_B,
            yc + r_sin_B);
}

static void
_cairo_arc_in_direction (GraphicsPath	  *path,
             double		   xc,
             double		   yc,
             double		   radius,
             double		   angle_min,
             double		   angle_max,
             cairo_direction_t dir)
{
///    if (cairo_status (cr))
///        return;

    while (angle_max - angle_min > 4 * M_PI)
    angle_max -= 2 * M_PI;

    /* Recurse if drawing arc larger than pi */
    if (angle_max - angle_min > M_PI) {
    double angle_mid = angle_min + (angle_max - angle_min) / 2.0;
    if (dir == CAIRO_DIRECTION_FORWARD) {
        _cairo_arc_in_direction (path, xc, yc, radius,
                     angle_min, angle_mid,
                     dir);

        _cairo_arc_in_direction (path, xc, yc, radius,
                     angle_mid, angle_max,
                     dir);
    } else {
        _cairo_arc_in_direction (path, xc, yc, radius,
                     angle_mid, angle_max,
                     dir);

        _cairo_arc_in_direction (path, xc, yc, radius,
                     angle_min, angle_mid,
                     dir);
    }
    } else if (angle_max != angle_min) {
    cairo_matrix_t ctm;
    int i, segments;
    double angle, angle_step;

///    cairo_get_matrix (cr, &ctm);
    cairo_matrix_init_identity (&ctm);
    double tolerance = 0.01; ///cairo_get_tolerance (path);
    segments = _arc_segments_needed (angle_max - angle_min,
                     radius, &ctm,
                     tolerance);
    angle_step = (angle_max - angle_min) / (double) segments;

    if (dir == CAIRO_DIRECTION_FORWARD) {
        angle = angle_min;
    } else {
        angle = angle_max;
        angle_step = - angle_step;
    }

    for (i = 0; i < segments; i++, angle += angle_step) {
        _cairo_arc_segment (path, xc, yc,
                radius,
                angle,
                angle + angle_step);
    }
    }
}

/**
 * _cairo_arc_path
 * @cr: a cairo context
 * @xc: X position of the center of the arc
 * @yc: Y position of the center of the arc
 * @radius: the radius of the arc
 * @angle1: the start angle, in radians
 * @angle2: the end angle, in radians
 *
 * Compute a path for the given arc and append it onto the current
 * path within @cr. The arc will be accurate within the current
 * tolerance and given the current transformation.
 **/
void
_cairo_arc_path (GraphicsPath *path,
         double	  xc,
         double	  yc,
         double	  radius,
         double	  angle1,
         double	  angle2)
{
    _cairo_arc_in_direction (path, xc, yc,
                 radius,
                 angle1, angle2,
                 CAIRO_DIRECTION_FORWARD);
}

void
graphics_path_arc(GraphicsPath *path, gdouble xc, gdouble yc, gdouble radius, gdouble angle1, gdouble angle2)
{
    /* Do nothing, successfully, if radius is <= 0 */
    if (radius <= 0.0)
    return;

    while (angle2 < angle1)
    angle2 += 2 * M_PI;

    graphics_path_line_to (path,
           xc + radius * cos (angle1),
           yc + radius * sin (angle1));

    _cairo_arc_path (path, xc, yc, radius, angle1, angle2);
}

void graphics_path_close(GraphicsPath *path)
{
    if (path->cr_index >= path->segments->len) {
        cairo_path_data_t data[1];
        data[0].header.type = CAIRO_PATH_CLOSE_PATH;
        data[0].header.length = 1;
        g_array_append_val(path->segments, data);
    }
    path->cr_index += 1;
}

cairo_path_t*
graphics_path_to_cairo(GraphicsPath *path)
{
    if (path->path!=NULL) {
        return path->path;
    }
    path->cr_path.data = path->segments->data;
    path->cr_path.num_data = path->cr_index;
    path->cr_path.status = CAIRO_STATUS_SUCCESS;
    return &path->cr_path;
}

void graphics_path_set(GraphicsPath *path, cairo_path_t *c_path)
{
    if (path->path!=NULL) {
        cairo_path_destroy(path->path);
    }
    path->path = c_path;
}

void graphics_path_bounding_box(GraphicsPath *path, cairo_t *cr, double *x1, double *y1, double *x2, double *y2)
{
    cairo_path_extents(cr, x1, y1, x2, y2);
}

void graphics_path_to_context(GraphicsPath *path, cairo_t *cr, gboolean preserve)
{
    g_return_if_fail(GRAPHICS_IS_PATH(path));

    if (preserve) {
        cairo_new_sub_path(cr);
    }
    //graphics_path_get_cairo_path(path, cairo_path_t ** cr_path);// &cr_path
    cairo_append_path(cr, graphics_path_to_cairo(path));
}


gchar* graphics_path_debug(GraphicsPath *path)
{
    cairo_path_t *cairo_path = path->path;
    if (!cairo_path)
        return "";

    gchar *str = g_new(gchar, 1);
    str[0] = '\0';
    gchar *tmp;
    int i;
    for (i=0; i<cairo_path->num_data; i += cairo_path->data[i].header.length) {
        switch(cairo_path->data[i].header.type)
        {
        case CAIRO_PATH_MOVE_TO:
            tmp = g_strdup_printf("%sMove{%f, %f}, ", str, cairo_path->data[i+1].point.x, cairo_path->data[i+1].point.y);
            g_free(str);
            str = tmp;
            break;
        case CAIRO_PATH_LINE_TO:
            tmp = g_strdup_printf("%sLine{%f, %f}, ", str, cairo_path->data[i+1].point.x, cairo_path->data[i+1].point.y);
            g_free(str);
            str = tmp;
            break;
        case CAIRO_PATH_CURVE_TO:
            tmp = g_strdup_printf("%sCurve{%f, %f, %f, %f, %f, %f}, ", str,
                                  cairo_path->data[i+1].point.x, cairo_path->data[i+1].point.y,
                                  cairo_path->data[i+2].point.x, cairo_path->data[i+2].point.y,
                                  cairo_path->data[i+3].point.x, cairo_path->data[i+3].point.y);
            g_free(str);
            str = tmp;
            break;
        case CAIRO_PATH_CLOSE_PATH:
            break;
        default:
            g_error("%s: Not implemented", G_STRFUNC);
        }
    }
    return str;
}
