/*
 * svgtk-tool-rect.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <libgraphics/graphics.h>


#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-event.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-view.h"

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-length.h"
#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"
#include "libsvg/svg-animated.h"
#include "libsvg/svg-animated-type.h"
#include "libsvg/svg-animated-type-animator.h"
#include "libsvg/svg-animated-length.h"
#include "libsvg/svg-path.h"
#include "libsvg/svg-document.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-rect.h"
#include "svgkit-renderer-knot.h"
#include "svgtk-tool.h"
#include "gan-svg-editor.h"

#include "svgtk-tool-rect.h"

static void svgtk_tool_rect_draw(SvgtkTool *tool, cairo_t* cr);
static void svgtk_tool_rect_set_selection(SvgtkTool *tool, SvgElement *element);

static void svgtk_tool_rect_class_init(SvgtkToolRectClass *klass);
static void svgtk_tool_rect_init(SvgtkToolRect *tool);

G_DEFINE_TYPE (SvgtkToolRect, svgtk_tool_rect, SVGTK_TYPE_TOOL)
#define parent_class svgtk_tool_rect_parent_class

static void
svgtk_tool_rect_class_init(SvgtkToolRectClass *klass)
{
    GObjectClass *gobject_class;
    SvgtkToolClass *tool_class;

    gobject_class = (GObjectClass *) klass;
    tool_class = (SvgtkToolClass *) klass;

    /*tool_class->draw          = svgtk_tool_rect_draw;
    tool_class->set_selection = svgtk_tool_rect_set_selection;
    tool_class->update        = svgtk_tool_rect_update;*/

    /*svgtk_tool_rect_parent_class = g_type_class_peek_parent (klass);*/
}


gboolean
svgtk_tool_rect_knot_enter_notify_event(RendererObject* object, RendererEvent* event/*, ... */, gpointer user_data)
{
    g_print("%s; MouseEvent{x:%f, y:%f}\n", G_STRFUNC, event->x, event->y);
    SvgkitRendererKnot *knot = SVGKIT_RENDERER_KNOT(object);
    svgkit_renderer_knot_set_state(knot, STATE_PRELIGHT);

    GanSvgEditor* editor = GAN_SVG_EDITOR(user_data);
    gtk_widget_queue_draw(GTK_WIDGET(editor));

    return FALSE;
}

gboolean
svgtk_tool_rect_knot_leave_notify_event(RendererObject* object, RendererEvent* event/*, ... */, gpointer user_data)
{
    g_print("%s; MouseEvent{x:%f, y:%f}\n", G_STRFUNC, event->x, event->y);
    SvgkitRendererKnot *knot = SVGKIT_RENDERER_KNOT(object);
    svgkit_renderer_knot_set_state(knot, STATE_NORMAL);

    GanSvgEditor* editor = GAN_SVG_EDITOR(user_data);
    gtk_widget_queue_draw(GTK_WIDGET(editor));

    return FALSE;
}

static void
svgtk_tool_rect_init (SvgtkToolRect *tool_rect)
{
    SvgtkTool *tool = SVGTK_TOOL(tool_rect);
    RendererScene *scene = renderer_scene_new("scene");
    RendererView *view = renderer_view_new();
    renderer_scene_set_view(scene, view);
    renderer_view_set_scene(view, scene);

    RendererContainer *renderer        = (RendererContainer *) renderer_container_new(scene, NULL);
    RendererContainer *renderer_shape  = (RendererContainer *) renderer_container_new(scene, NULL);
    RendererContainer *renderer_sketch = (RendererContainer *) renderer_container_new(scene, NULL);
    RendererContainer *renderer_knot   = (RendererContainer *) renderer_container_new(scene, NULL);
    RendererContainer *renderer_handle = (RendererContainer *) renderer_container_new(scene, NULL);


    RendererShape *knot0 = (RendererShape *) svgkit_renderer_knot_new(KNOT_ANCHOR);
    RendererShape *knot1 = (RendererShape *) svgkit_renderer_knot_new(KNOT_ANCHOR);
    RendererShape *ctl_rx = (RendererShape *) svgkit_renderer_knot_new(KNOT_HANDLE);
    RendererShape *ctl_ry = (RendererShape *) svgkit_renderer_knot_new(KNOT_HANDLE);


    /*renderer_style_get_graphics_fill(square, style);*/
    /*renderer_style_get_graphics_stroke(square, style);*/
    /*CssStyleSheet
    SvgStyleSheet *style = svg_style_new();
    SvgStyleRule *rule = svg_style_rule_new();
    SvgStyle *style = svg_style_new("stroke: #006600;");*/
    /*renderer_container_remove_all(priv->renderer_controls);*/

    renderer_container_insert(renderer_knot, knot0, -1);
    renderer_container_insert(renderer_knot, knot1, -1);
    renderer_container_insert(renderer_handle, ctl_rx, -1);
    renderer_container_insert(renderer_handle, ctl_ry, -1);

    renderer_container_insert(renderer, renderer_shape, -1);
    renderer_container_insert(renderer, renderer_sketch, -1);
    renderer_container_insert(renderer, renderer_knot, -1);
    renderer_container_insert(renderer, renderer_handle, -1);

    tool_rect->knot0    = knot0;
    tool_rect->knot1    = knot1;
    tool_rect->ctl_rx   = ctl_rx;
    tool_rect->ctl_ry   = ctl_ry;
    /*tool->renderer = renderer;

    renderer_object_set_visible(tool->renderer, FALSE);*/
}

void
svgtk_tool_rect_update(SvgtkTool *tool)
{
    /*
    SvgtkToolRect *tool_rect = SVGTK_TOOL_RECT(tool);
    if (!tool->selection) {
        return;
    }
    SvgElementRect *rect = tool->selection;
    g_print("SvgElementRect *rect: %p\n", rect);

    gdouble x = rect->x->baseVal->value;
    gdouble y = rect->y->baseVal->value;
    gdouble width  = rect->width->baseVal->value;
    gdouble height = rect->height->baseVal->value;
    gdouble rx     = rect->rx->baseVal->value;
    gdouble ry     = rect->ry->baseVal->value;
    SvgTransformList *t = svg_transformable_get_transform(rect);
    cairo_matrix_t* matrix = renderer_object_get_transform_abs(SVG_ELEMENT(rect)->private_member->renderer);
    gdouble cx = width+x;
    gdouble cy = y;
    cairo_matrix_transform_point(matrix, &cx, &cy);
    width += x;
    height += y;
    cairo_matrix_transform_point(matrix, &width, &height);
    cairo_matrix_transform_point(matrix, &x, &y);

    g_print("x: %f, y: %f, w: %f, h: %f -> %f, %f\n", x, y, width, height, rx, ry);

    cairo_matrix_init_translate(&tool_rect->knot0->matrix, x, y);
    cairo_matrix_init_translate(&tool_rect->knot1->matrix, width, height);
    cairo_matrix_init_translate(&tool_rect->ctl_rx->matrix, cx, cy);
    cairo_matrix_init_translate(&tool_rect->ctl_ry->matrix, cx, cy);

    renderer_object_set_transform(tool_rect->knot0, &tool_rect->knot0->matrix);
    renderer_object_set_transform(tool_rect->knot1, &tool_rect->knot1->matrix);
    renderer_object_set_transform(tool_rect->ctl_rx, &tool_rect->ctl_rx->matrix);
    renderer_object_set_transform(tool_rect->ctl_ry, &tool_rect->ctl_ry->matrix);

    g_signal_connect(tool_rect->knot0, "enter_notify_event", G_CALLBACK(svgtk_tool_rect_knot_enter_notify_event), tool->editor);
    g_signal_connect(tool_rect->knot0, "leave_notify_event", G_CALLBACK(svgtk_tool_rect_knot_leave_notify_event), tool->editor);

    g_signal_connect(tool_rect->knot1, "enter_notify_event", G_CALLBACK(svgtk_tool_rect_knot_enter_notify_event), tool->editor);
    g_signal_connect(tool_rect->knot1, "leave_notify_event", G_CALLBACK(svgtk_tool_rect_knot_leave_notify_event), tool->editor);

    g_signal_connect(tool_rect->ctl_rx, "enter_notify_event", G_CALLBACK(svgtk_tool_rect_knot_enter_notify_event), tool->editor);
    g_signal_connect(tool_rect->ctl_rx, "leave_notify_event", G_CALLBACK(svgtk_tool_rect_knot_leave_notify_event), tool->editor);

    g_signal_connect(tool_rect->ctl_ry, "enter_notify_event", G_CALLBACK(svgtk_tool_rect_knot_enter_notify_event), tool->editor);
    g_signal_connect(tool_rect->ctl_ry, "leave_notify_event", G_CALLBACK(svgtk_tool_rect_knot_leave_notify_event), tool->editor);
*/
}

static void
svgtk_tool_rect_draw(SvgtkTool *tool, cairo_t* cr)
{
    SvgtkToolRect *tool_rect = SVGTK_TOOL_RECT(tool);

    /*svgtk_tool_rect_update(tool);
    renderer_object_draw(tool->renderer, cr);*/
}

static void
svgtk_tool_rect_set_selection(SvgtkTool *tool, SvgElement *element)
{
    SvgtkToolRect *tool_rect = SVGTK_TOOL_RECT(tool);

    /*SVGTK_TOOL_CLASS(parent_class)->set_selection(tool, element);*/
    /*tool->selection = element;
    svgtk_tool_rect_update(tool);


    renderer_object_set_visible(tool->renderer, TRUE);*/
}


SvgtkToolRect *
svgtk_tool_rect_new (GanSvgEditor *editor)
{
    SvgtkToolRect *tool = g_object_new (svgtk_tool_rect_get_type (),
                                        /*"editor", editor,*/
                                        NULL);

    return tool;
}
