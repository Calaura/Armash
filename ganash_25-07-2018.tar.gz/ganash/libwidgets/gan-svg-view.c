/*
 * gan-svg-view.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "gan-svg-view.h"

#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-document.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-g.h"
#include "libsvg/svg-element-svg.h"
#include "libsvg/svg-drawable.h"


#define GAN_SVG_VIEW_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), GAN_TYPE_SVG_VIEW, GanSvgViewPrivate))
struct _GanSvgViewPrivate {
    SvgDocument       *svg_doc;

    RendererScene     *scene;

    RendererContainer *renderer;
};

static void gan_svg_view_size_request(GtkWidget *widget, GtkRequisition *requisition);
static void gan_svg_view_size_allocate(GtkWidget *widget, GtkAllocation *allocation);
static void gan_svg_view_realize(GtkWidget *widget);
static gboolean gan_svg_view_motion_notify_event (GtkWidget *widget,
                                                  GdkEventMotion *event);

static gboolean gan_svg_view_expose(GtkWidget *widget, GdkEventExpose *event);

static void gan_svg_view_class_init(GanSvgViewClass *klass);
static void gan_svg_view_init(GanSvgView *gobject);

G_DEFINE_TYPE (GanSvgView, gan_svg_view, GTK_TYPE_WIDGET)

static void
gan_svg_view_class_init(GanSvgViewClass *klass)
{
    GtkWidgetClass *widget_class;

    widget_class = (GtkWidgetClass *) klass;

    widget_class->realize             = gan_svg_view_realize;
    widget_class->size_request        = gan_svg_view_size_request;
    widget_class->size_allocate       = gan_svg_view_size_allocate;
    widget_class->motion_notify_event = gan_svg_view_motion_notify_event;

    widget_class->expose_event        = gan_svg_view_expose;

    g_type_class_add_private(klass, sizeof(GanSvgViewPrivate));
//	gan_svg_view_parent_class = g_type_class_peek_parent (klass);
}

static void
gan_svg_view_init (GanSvgView *object)
{
	GanSvgViewPrivate *priv = GAN_SVG_VIEW_GET_PRIVATE(object);
	object->private_member = priv;
    priv->svg_doc = NULL;
}

static void
gan_svg_view_size_request(GtkWidget *widget,
    GtkRequisition *requisition)
{
  g_return_if_fail(widget != NULL);
  g_return_if_fail(GAN_IS_SVG_VIEW(widget));
  g_return_if_fail(requisition != NULL);

  requisition->width = 80;
  requisition->height = 100;
}


static void
gan_svg_view_size_allocate(GtkWidget *widget,
    GtkAllocation *allocation)
{
  g_return_if_fail(widget != NULL);
  g_return_if_fail(GAN_IS_SVG_VIEW(widget));
  g_return_if_fail(allocation != NULL);

  widget->allocation = *allocation;

  if (gtk_widget_get_realized(widget)) {
     gdk_window_move_resize(
         widget->window,
         allocation->x, allocation->y,
         allocation->width, allocation->height
     );
   }
}


static void
gan_svg_view_realize(GtkWidget *widget)
{
    GdkWindow* window;
    GtkStyle* style;
    GdkWindowAttr attributes;
    guint attributes_mask;

    g_return_if_fail(widget != NULL);
    g_return_if_fail(GAN_IS_SVG_VIEW(widget));

    gtk_widget_set_realized(widget, TRUE);
    gtk_widget_ensure_style (widget);

    attributes.window_type = GDK_WINDOW_CHILD;
    attributes.x = widget->allocation.x;
    attributes.y = widget->allocation.y;
    attributes.width = widget->allocation.width;
    attributes.height = widget->allocation.height;

    attributes.wclass = GDK_INPUT_OUTPUT;
    attributes.event_mask = gtk_widget_get_events(widget)
                         | GDK_POINTER_MOTION_MASK
                         | GDK_BUTTON_PRESS_MASK
                         | GDK_BUTTON_RELEASE_MASK
                         | GDK_EXPOSURE_MASK;

    attributes_mask = GDK_WA_X | GDK_WA_Y;

    window = gdk_window_new(
        gtk_widget_get_parent_window (widget),
        & attributes, attributes_mask
    );
    gtk_widget_set_window(widget, window);

    gdk_window_set_user_data(window, widget);

    style = gtk_widget_get_style(widget);
    style = gtk_style_attach(style, window);
    gtk_style_set_background(style, window, GTK_STATE_NORMAL);
    gtk_widget_set_style(widget, style);

}

static gboolean gan_svg_view_motion_notify_event (GtkWidget *widget,
                                                  GdkEventMotion *event)
{
    GanSvgView* view = GAN_SVG_VIEW(widget);
    GanSvgViewPrivate* priv = view->private_member;

    SvgDocument    *doc = SVG_DOCUMENT(priv->svg_doc);
    DomDocument    *dom_doc = (DomDocument*)doc;
    SvgElementSvg *root = SVG_ELEMENT_SVG(dom_document_get_root(dom_doc));
    SvgElement *element = SVG_ELEMENT(root);

    //svg_drawable_draw(element, cr);
    //renderer_object_draw(priv->renderer, cr);
    //renderer_scene_draw(priv->scene, cr);
    g_print("gan_svg_view_motion_notify_event\n");

    return FALSE;
}

static gboolean
gan_svg_view_expose(GtkWidget *widget, GdkEventExpose *event)
{
  cairo_t *cr;
  cr = gdk_cairo_create(gtk_widget_get_window(widget));

  GanSvgView* view = GAN_SVG_VIEW(widget);
  GanSvgViewPrivate* priv = view->private_member;

  //renderer_object_draw(priv->renderer, cr);
  //renderer_scene_draw(priv->scene, cr);
  SvgDocument    *doc = SVG_DOCUMENT(priv->svg_doc);
  DomDocument    *dom_doc = (DomDocument*)doc;
  SvgElementSvg *root = SVG_ELEMENT_SVG(dom_document_get_root(dom_doc));
  SvgElement *element = SVG_ELEMENT(root);
  svg_drawable_draw(element, cr);

  cairo_destroy(cr);

  return FALSE;
}

GanSvgView *
gan_svg_view_new (void)
{
	return g_object_new (gan_svg_view_get_type (),
	                     NULL);
}


void
gan_svg_view_load_uri (GanSvgView *view, const gchar *uri)
{
    SvgDocument* doc = svg_document_load(uri);
    GanSvgViewPrivate *priv = view->private_member;
    priv->svg_doc = doc;

    priv->scene             = g_object_new(RENDERER_TYPE_SCENE, NULL);
    priv->renderer          = svg_element_graphics_get_renderer(svg_document_get_root(doc));

    priv->scene->root       = priv->renderer;
}

void
gan_svg_view_set_time(GanSvgView *view, double time)
{
    svg_document_set_time(view->private_member->svg_doc, time);
}
