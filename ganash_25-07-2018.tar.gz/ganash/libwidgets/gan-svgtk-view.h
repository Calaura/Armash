/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * gan-svgtk-view.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __GAN_SVGTK_VIEW_H__
#define __GAN_SVGTK_VIEW_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define GAN_TYPE_SVGTK_VIEW            (gan_svgtk_view_get_type())
#define GAN_SVGTK_VIEW(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAN_TYPE_SVGTK_VIEW, GanSvgtkView))
#define GAN_SVGTK_VIEW_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GAN_TYPE_SVGTK_VIEW, GanSvgtkViewClass))
#define GAN_IS_SVGTK_VIEW(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAN_TYPE_SVGTK_VIEW))
#define GAN_IS_SVGTK_VIEW_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GAN_TYPE_SVGTK_VIEW))
#define GAN_SVGTK_VIEW_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GAN_TYPE_SVGTK_VIEW, GanSvgtkViewClass))

typedef struct _GanSvgtkView GanSvgtkView;
typedef struct _GanSvgtkViewPrivate GanSvgtkViewPrivate;
typedef struct _GanSvgtkViewClass GanSvgtkViewClass;

struct _GanSvgtkView {
	GtkWidget parent_instance;
	/* private */
	GanSvgtkViewPrivate *private_member;
};

struct _GanSvgtkViewClass {
	GtkWidgetClass parent_class;
};

GType gan_svgtk_view_get_type();
GanSvgtkView *gan_svgtk_view_new();
void gan_svgtk_view_load_uri (GanSvgtkView *view, const gchar *uri);

G_END_DECLS

#endif /* __GAN_SVGTK_VIEW_H__ */

