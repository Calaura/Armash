/*
 * svgtk.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "svgtk.h"


static void svgtk_class_init(SvgtkClass *klass);
static void svgtk_init(Svgtk *gobject);

G_DEFINE_TYPE (Svgtk, svgtk, G_TYPE_OBJECT)

static void
svgtk_class_init(SvgtkClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//    svgtk_parent_class = g_type_class_peek_parent (klass);
}

static void
svgtk_init (Svgtk *object)
{
    /*SvgtkPrivate *priv = SVGTK_GET_PRIVATE(object);
	object->private_member = priv;
    priv->foo = 0;*/
}

Svgtk *
svgtk_new (void)
{
    return g_object_new (svgtk_get_type (),
	                     NULL);
}

