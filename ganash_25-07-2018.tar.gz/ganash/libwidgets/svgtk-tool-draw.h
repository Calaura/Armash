/*
 * svgtk-tool-draw.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVGTK_TOOL_DRAW_H__
#define __SVGTK_TOOL_DRAW_H__

#include <gtk/gtk.h>


#include <libgraphics/graphics.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-shape.h"


typedef cairo_path_t GimpBezierDesc;

G_BEGIN_DECLS

#define SVGTK_TYPE_TOOL_DRAW            (svgtk_tool_draw_get_type())
#define SVGTK_TOOL_DRAW(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVGTK_TYPE_TOOL_DRAW, SvgtkToolDraw))
#define SVGTK_TOOL_DRAW_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVGTK_TYPE_TOOL_DRAW, SvgtkToolDrawClass))
#define SVGTK_IS_TOOL_DRAW(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVGTK_TYPE_TOOL_DRAW))
#define SVGTK_IS_TOOL_DRAW_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVGTK_TYPE_TOOL_DRAW))
#define SVGTK_TOOL_DRAW_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVGTK_TYPE_TOOL_DRAW, SvgtkToolDrawClass))

typedef struct _SvgtkToolDraw SvgtkToolDraw;
typedef struct _SvgtkToolDrawClass SvgtkToolDrawClass;

struct _SvgtkToolDraw {
    SvgtkTool parent_instance;

    SvgtkDisplay    *display;       /*  The display we are drawing to (may be
                                     *  a different one than tool->display)
                                     */

    gint            paused_count;   /*  count to keep track of multiple pauses  */
    guint           draw_timeout;   /*  draw delay timeout ID                   */
    guint64         last_draw_time; /*  time of last draw(), monotonically      */

    /*GimpCanvasItem *preview;*/
    RendererItem *item;
    GList          *group_stack;
};

struct _SvgtkToolDrawClass {
    SvgtkToolClass parent_class;

    /*  virtual function  */

    void (* draw) (SvgtkToolDraw *tool_draw);

};

GType svgtk_tool_draw_get_type();
SvgtkToolDraw *svgtk_tool_draw_new();

/*
void             gimp_draw_tool_start                (GimpDrawTool     *draw_tool,
                                                      GimpDisplay      *display);
void             gimp_draw_tool_stop                 (GimpDrawTool     *draw_tool);

gboolean         gimp_draw_tool_is_active            (GimpDrawTool     *draw_tool);

void             gimp_draw_tool_pause                (GimpDrawTool     *draw_tool);
void             gimp_draw_tool_resume               (GimpDrawTool     *draw_tool);

gdouble          gimp_draw_tool_calc_distance        (GimpDrawTool     *draw_tool,
                                                      GimpDisplay      *display,
                                                      gdouble           x1,
                                                      gdouble           y1,
                                                      gdouble           x2,
                                                      gdouble           y2);
gdouble          gimp_draw_tool_calc_distance_square (GimpDrawTool     *draw_tool,
                                                      GimpDisplay      *display,
                                                      gdouble           x1,
                                                      gdouble           y1,
                                                      gdouble           x2,
                                                      gdouble           y2);

void             gimp_draw_tool_add_preview          (GimpDrawTool     *draw_tool,
                                                      GimpCanvasItem   *item);
void             gimp_draw_tool_remove_preview       (GimpDrawTool     *draw_tool,
                                                      GimpCanvasItem   *item);

void             gimp_draw_tool_add_item             (GimpDrawTool     *draw_tool,
                                                      GimpCanvasItem   *item);
void             gimp_draw_tool_remove_item          (GimpDrawTool     *draw_tool,
                                                      GimpCanvasItem   *item);

GimpCanvasGroup* gimp_draw_tool_add_stroke_group     (GimpDrawTool     *draw_tool);
GimpCanvasGroup* gimp_draw_tool_add_fill_group       (GimpDrawTool     *draw_tool);

void             gimp_draw_tool_push_group           (GimpDrawTool     *draw_tool,
                                                      GimpCanvasGroup  *group);
void             gimp_draw_tool_pop_group            (GimpDrawTool     *draw_tool);

GimpCanvasItem * gimp_draw_tool_add_line             (GimpDrawTool     *draw_tool,
                                                      gdouble           x1,
                                                      gdouble           y1,
                                                      gdouble           x2,
                                                      gdouble           y2);
GimpCanvasItem * gimp_draw_tool_add_guide            (GimpDrawTool     *draw_tool,
                                                      GimpOrientationType  orientation,
                                                      gint              position,
                                                      gboolean          guide_style);
GimpCanvasItem * gimp_draw_tool_add_crosshair        (GimpDrawTool     *draw_tool,
                                                      gint              position_x,
                                                      gint              position_y);
GimpCanvasItem * gimp_draw_tool_add_sample_point     (GimpDrawTool     *draw_tool,
                                                      gint              x,
                                                      gint              y,
                                                      gint              index);
GimpCanvasItem * gimp_draw_tool_add_rectangle        (GimpDrawTool     *draw_tool,
                                                      gboolean          filled,
                                                      gdouble           x,
                                                      gdouble           y,
                                                      gdouble           width,
                                                      gdouble           height);
GimpCanvasItem * gimp_draw_tool_add_rectangle_guides (GimpDrawTool     *draw_tool,
                                                      GimpGuidesType    type,
                                                      gdouble           x,
                                                      gdouble           y,
                                                      gdouble           width,
                                                      gdouble           height);
GimpCanvasItem * gimp_draw_tool_add_arc              (GimpDrawTool     *draw_tool,
                                                      gboolean          filled,
                                                      gdouble           x,
                                                      gdouble           y,
                                                      gdouble           width,
                                                      gdouble           height,
                                                      gdouble           start_angle,
                                                      gdouble           slice_angle);
GimpCanvasItem * gimp_draw_tool_add_transform_guides (GimpDrawTool     *draw_tool,
                                                      const GimpMatrix3 *transform,
                                                      GimpGuidesType    type,
                                                      gint              n_guides,
                                                      gdouble           x1,
                                                      gdouble           y1,
                                                      gdouble           x2,
                                                      gdouble           y2);
GimpCanvasItem * gimp_draw_tool_add_transform_preview(GimpDrawTool     *draw_tool,
                                                      GimpDrawable     *drawable,
                                                      const GimpMatrix3 *transform,
                                                      gdouble           x1,
                                                      gdouble           y1,
                                                      gdouble           x2,
                                                      gdouble           y2,
                                                      gboolean          perspective,
                                                      gdouble            opacity);

GimpCanvasItem * gimp_draw_tool_add_handle           (GimpDrawTool     *draw_tool,
                                                      GimpHandleType    type,
                                                      gdouble           x,
                                                      gdouble           y,
                                                      gint              width,
                                                      gint              height,
                                                      GimpHandleAnchor  anchor);
GimpCanvasItem * gimp_draw_tool_add_corner           (GimpDrawTool     *draw_tool,
                                                      gboolean          highlight,
                                                      gboolean          put_outside,
                                                      gdouble           x1,
                                                      gdouble           y1,
                                                      gdouble           x2,
                                                      gdouble           y2,
                                                      gint              width,
                                                      gint              height,
                                                      GimpHandleAnchor  anchor);

GimpCanvasItem * gimp_draw_tool_add_lines            (GimpDrawTool     *draw_tool,
                                                      const GimpVector2 *points,
                                                      gint              n_points,
                                                      gboolean          filled);

GimpCanvasItem * gimp_draw_tool_add_strokes          (GimpDrawTool     *draw_tool,
                                                      const GimpCoords *points,
                                                      gint              n_points,
                                                      gboolean          filled);
*/
RendererItem * svgtk_tool_draw_add_path              (SvgtkToolDraw     *tool_draw,
                                                      const GimpBezierDesc *desc,
                                                      gdouble           x,
                                                      gdouble           y);
/*
GimpCanvasItem * gimp_draw_tool_add_pen              (GimpDrawTool     *draw_tool,
                                                      const GimpVector2 *points,
                                                      gint              n_points,
                                                      GimpContext      *context,
                                                      GimpActiveColor   color,
                                                      gint              width);

GimpCanvasItem * gimp_draw_tool_add_boundary         (GimpDrawTool     *draw_tool,
                                                      const BoundSeg   *bound_segs,
                                                      gint              n_bound_segs,
                                                      GimpMatrix3      *transform,
                                                      gdouble           offset_x,
                                                      gdouble           offset_y);

GimpCanvasItem * gimp_draw_tool_add_text_cursor      (GimpDrawTool     *draw_tool,
                                                      PangoRectangle   *cursor,
                                                      gboolean          overwrite);

gboolean         gimp_draw_tool_on_handle            (GimpDrawTool     *draw_tool,
                                                      GimpDisplay      *display,
                                                      gdouble           x,
                                                      gdouble           y,
                                                      GimpHandleType    type,
                                                      gdouble           handle_x,
                                                      gdouble           handle_y,
                                                      gint              width,
                                                      gint              height,
                                                      GimpHandleAnchor  anchor);
gboolean         gimp_draw_tool_on_vectors_handle    (GimpDrawTool     *draw_tool,
                                                      GimpDisplay      *display,
                                                      GimpVectors      *vectors,
                                                      const GimpCoords *coord,
                                                      gint              width,
                                                      gint              height,
                                                      GimpAnchorType    preferred,
                                                      gboolean          exclusive,
                                                      GimpAnchor      **ret_anchor,
                                                      GimpStroke      **ret_stroke);
gboolean         gimp_draw_tool_on_vectors_curve     (GimpDrawTool     *draw_tool,
                                                      GimpDisplay      *display,
                                                      GimpVectors      *vectors,
                                                      const GimpCoords *coord,
                                                      gint              width,
                                                      gint              height,
                                                      GimpCoords       *ret_coords,
                                                      gdouble          *ret_pos,
                                                      GimpAnchor      **ret_segment_start,
                                                      GimpAnchor      **ret_segment_end,
                                                      GimpStroke      **ret_stroke);

gboolean         gimp_draw_tool_on_vectors           (GimpDrawTool     *draw_tool,
                                                      GimpDisplay      *display,
                                                      const GimpCoords *coord,
                                                      gint              width,
                                                      gint              height,
                                                      GimpCoords       *ret_coords,
                                                      gdouble          *ret_pos,
                                                      GimpAnchor      **ret_segment_start,
                                                      GimpAnchor      **ret_segment_end,
                                                      GimpStroke      **ret_stroke,
                                                      GimpVectors     **ret_vectors);
*/

G_END_DECLS

#endif /* __SVGTK_TOOL_DRAW_H__ */

