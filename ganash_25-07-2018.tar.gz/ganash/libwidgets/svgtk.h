/*
 * svgtk.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVGTK_H__
#define __SVGTK_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define TYPE_SVGTK            (svgtk_get_type())
#define SVGTK(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), TYPE_SVGTK, Svgtk))
#define SVGTK_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), TYPE_SVGTK, SvgtkClass))
#define IS_SVGTK(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), TYPE_SVGTK))
#define IS_SVGTK_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), TYPE_SVGTK))
#define SVGTK_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), TYPE_SVGTK, SvgtkClass))

typedef struct _Svgtk Svgtk;
typedef struct _SvgtkClass SvgtkClass;

struct _Svgtk {
	GObject parent_instance;
};

struct _SvgtkClass {
	GObjectClass parent_class;
};

GType svgtk_get_type();
Svgtk *svgtk_new();

G_END_DECLS

#endif /* __SVGTK_H__ */
