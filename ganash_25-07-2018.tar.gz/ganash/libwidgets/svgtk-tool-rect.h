/*
 * svgtk-tool-rect.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVGTK_TOOL_RECT_H__
#define __SVGTK_TOOL_RECT_H__

#include <glib-object.h>

#include "svgtk-tool.h"

G_BEGIN_DECLS

#define SVGTK_TYPE_TOOL_RECT            (svgtk_tool_rect_get_type())
#define SVGTK_TOOL_RECT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVGTK_TYPE_TOOL_RECT, SvgtkToolRect))
#define SVGTK_TOOL_RECT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVGTK_TYPE_TOOL_RECT, SvgtkToolRectClass))
#define SVGTK_IS_TOOL_RECT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVGTK_TYPE_TOOL_RECT))
#define SVGTK_IS_TOOL_RECT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVGTK_TYPE_TOOL_RECT))
#define SVGTK_TOOL_RECT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVGTK_TYPE_TOOL_RECT, SvgtkToolRectClass))

typedef struct _SvgtkToolRect SvgtkToolRect;
typedef struct _SvgtkToolRectClass SvgtkToolRectClass;

struct _SvgtkToolRect {
    SvgtkTool parent_instance;

    double x;
    double y;
    double width;
    double height;
    double rx;
    double ry;
    /* bool round_mode = GLOBAL|LOCAL; rx_tl; rx_tr; rx_br; rx_bl*/

    SvgElementRect *target;

    RendererObject *knot0;
    RendererObject *knot1;
    RendererObject *ctl_rx;
    RendererObject *ctl_ry;
    /* bool round_mode = GLOBAL|LOCAL|SYMETRY|SYMETRY; ctl_rx_tl; ctl_rx_tr; ctl_rx_br; ctl_rx_bl*/
};

struct _SvgtkToolRectClass {
    SvgtkToolClass parent_class;
};

GType svgtk_tool_rect_get_type();
SvgtkToolRect *svgtk_tool_rect_new(GanSvgEditor *editor);

G_END_DECLS

#endif /* __SVGTK_TOOL_RECT_H__ */

