/*
 * svgtk-tool-draw.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <libgraphics/graphics.h>

#include <liblog/log.h>

#include "svgtk-tool.h"
#include "svgtk-tool-draw.h"


#define DRAW_TIMEOUT              4
#define USE_TIMEOUT               1
#define MINIMUM_DRAW_INTERVAL 50000 /* 50000 microseconds == 20 fps */


static gboolean      svgtk_tool_draw_has_display (SvgtkTool      *tool, SvgtkDisplay *display);

static void          svgtk_tool_draw_draw        (SvgtkToolDraw  *tool_draw);
static void          svgtk_tool_draw_real_draw   (SvgtkToolDraw  *tool_draw);


static void svgtk_tool_draw_class_init(SvgtkToolDrawClass *klass);
static void svgtk_tool_draw_init(SvgtkToolDraw *tool_draw);

G_DEFINE_TYPE (SvgtkToolDraw, svgtk_tool_draw, SVGTK_TYPE_TOOL)
#define parent_class svgtk_tool_draw_parent_class

static void
svgtk_tool_draw_class_init(SvgtkToolDrawClass *klass)
{
    GObjectClass *object_class;
    SvgtkToolClass *tool_class;

    object_class = (GObjectClass *) klass;
    tool_class = (SvgtkToolClass *) klass;

    /*object_class->dispose   = svgtk_tool_dispose;*/

    tool_class->has_display = svgtk_tool_draw_has_display;
/*
    tool_class->has_image   = svgtk_tool_draw_has_image;
    tool_class->control     = svgtk_tool_draw_control;
*/
    klass->draw             = svgtk_tool_draw_real_draw;

//    svgtk_tool_draw_parent_class = g_type_class_peek_parent (klass);
}


static void
svgtk_tool_draw_real_draw (SvgtkToolDraw *tool_draw)
{
  /* the default implementation does nothing */
}

static void
svgtk_tool_draw_draw (SvgtkToolDraw *tool_draw)
{
  guint64 now = g_get_monotonic_time ();

  if (tool_draw->display &&
      tool_draw->paused_count == 0 &&
      (! tool_draw->draw_timeout ||
       (now - tool_draw->last_draw_time) > MINIMUM_DRAW_INTERVAL))
    {
/*
      GimpDisplayShell *shell = gimp_display_get_shell (draw_tool->display);
*/
      if (tool_draw->draw_timeout)
        {
          g_source_remove (tool_draw->draw_timeout);
          tool_draw->draw_timeout = 0;
        }
/*
      gimp_draw_tool_undraw (draw_tool);
*/

      SVGTK_TOOL_DRAW_GET_CLASS (tool_draw)->draw (tool_draw);
/*
      if (draw_tool->group_stack)
        {
          g_warning ("%s: draw_tool->group_stack not empty after calling "
                     "GimpDrawTool::draw() of %s",
                     G_STRFUNC,
                     g_type_name (G_TYPE_FROM_INSTANCE (draw_tool)));

          while (draw_tool->group_stack)
            gimp_draw_tool_pop_group (draw_tool);
        }

      if (draw_tool->preview)
        gimp_display_shell_add_preview_item (shell, draw_tool->preview);

      if (draw_tool->item)
        gimp_display_shell_add_tool_item (shell, draw_tool->item);
*/
      tool_draw->last_draw_time = now;
    }
}

static void
svgtk_tool_draw_init (SvgtkToolDraw *tool_draw)
{
    tool_draw->display      = NULL;
    tool_draw->paused_count = 0;
    /*tool_draw->preview      = NULL;
    tool_draw->item         = NULL;*/
}

static gboolean
svgtk_tool_draw_has_display (SvgtkTool    *tool,
                             SvgtkDisplay *display)
{
  SvgtkToolDraw *tool_draw = SVGTK_TOOL_DRAW (tool);

  return (display == tool_draw->display ||
          SVGTK_TOOL_CLASS (parent_class)->has_display (tool, display));
}

SvgtkToolDraw *
svgtk_tool_draw_new (void)
{
    return g_object_new (svgtk_tool_draw_get_type (),
                         NULL);
}

void
svgtk_tool_draw_add_item (SvgtkToolDraw   *tool_draw,
                          RendererItem    *item)
{

    /*
  GimpCanvasGroup *group;

  g_return_if_fail (SVGTK_IS_TOOL_DRAW (tool_draw));
  g_return_if_fail (RENDERER_IS_ITEM (item));

  if (! tool_draw->item)
    tool_draw->item =
      gimp_canvas_group_new (gimp_display_get_shell (tool_draw->display));

  group = GIMP_CANVAS_GROUP (tool_draw->item);

  if (tool_draw->group_stack)
    group = tool_draw->group_stack->data;

  gimp_canvas_group_add_item (group, item);
  */
  /*svgtk_tool_draw_get_renderer(tool_draw);
  renderer_container_append(group, item, 0);*/
}

/*
void
svgtk_tool_draw_remove_item (SvgtkToolDraw   *tool_draw,
                            RendererItem *item)
{
  g_return_if_fail (GIMP_IS_DRAW_TOOL (tool_draw));
  g_return_if_fail (GIMP_IS_CANVAS_ITEM (item));
  g_return_if_fail (tool_draw->item != NULL);

  gimp_canvas_group_remove_item (GIMP_CANVAS_GROUP (tool_draw->item), item);
}
*/

RendererItem *
svgtk_tool_draw_add_path (SvgtkToolDraw         *tool_draw,
                         const GimpBezierDesc *desc,
                         gdouble               x,
                         gdouble               y)
{
    RendererItem *item;
    RendererShape *shape;
/*
    shape = renderer_shape_new();
    cairo_path_t *path = desc;
    renderer_shape_set_path(shape, path);
*/
    /*
    tool_draw->display->shell->add_item();
  GimpCanvasItem *item;

  g_return_val_if_fail (SVGTK_IS_TOOL_DRAW (tool_draw), NULL);
  g_return_val_if_fail (desc != NULL, NULL);

  item = gimp_canvas_path_new (gimp_display_get_shell (tool_draw->display),
                               desc, x, y, FALSE, GIMP_PATH_STYLE_DEFAULT);

  gimp_draw_tool_add_item (tool_draw, item);
  g_object_unref (item);

  return item;
  */
}
