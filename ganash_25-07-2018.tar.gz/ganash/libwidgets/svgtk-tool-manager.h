/*
 * svgtk-tool-manager.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVGTK_TOOL_MANAGER_H__
#define __SVGTK_TOOL_MANAGER_H__

typedef enum
{
  SVGTK_TOOL_ACTION_PAUSE,
  SVGTK_TOOL_ACTION_RESUME,
  SVGTK_TOOL_ACTION_HALT
} SvgtkToolAction;


/*
void       svgtk_tool_manager_init                       (Gimp             *gimp);
void       svgtk_tool_manager_exit                       (Gimp             *gimp);

SvgtkTool * svgtk_tool_manager_get_active                 (Gimp             *gimp);
*/
void       svgtk_tool_manager_select_tool          (Svgtk             *svgtk,
                                                    SvgtkTool         *tool);
/*
void       svgtk_tool_manager_push_tool                  (Gimp             *gimp,
                                                    SvgtkTool         *tool);
void       svgtk_tool_manager_pop_tool                   (Gimp             *gimp);


gboolean   svgtk_tool_manager_initialize_active          (Gimp             *gimp,
                                                    GimpDisplay      *display);
void       svgtk_tool_manager_control_active             (Gimp             *gimp,
                                                    SvgtkToolAction    action,
                                                    GimpDisplay      *display);
void       svgtk_tool_manager_button_press_active        (Gimp             *gimp,
                                                    const GimpCoords *coords,
                                                    guint32           time,
                                                    GdkModifierType   state,
                                                    GimpButtonPressType press_type,
                                                    GimpDisplay      *display);
void       svgtk_tool_manager_button_release_active      (Gimp             *gimp,
                                                    const GimpCoords *coords,
                                                    guint32           time,
                                                    GdkModifierType   state,
                                                    GimpDisplay      *display);
void       svgtk_tool_manager_motion_active              (Gimp             *gimp,
                                                    const GimpCoords *coords,
                                                    guint32           time,
                                                    GdkModifierType   state,
                                                    GimpDisplay      *display);
gboolean   svgtk_tool_manager_key_press_active           (Gimp             *gimp,
                                                    GdkEventKey      *kevent,
                                                    GimpDisplay      *display);
gboolean   svgtk_tool_manager_key_release_active         (Gimp             *gimp,
                                                    GdkEventKey      *kevent,
                                                    GimpDisplay      *display);

void       svgtk_tool_manager_focus_display_active       (Gimp             *gimp,
                                                    GimpDisplay      *display);
void       svgtk_tool_manager_modifier_state_active      (Gimp             *gimp,
                                                    GdkModifierType   state,
                                                    GimpDisplay      *display);

void     svgtk_tool_manager_active_modifier_state_active (Gimp             *gimp,
                                                    GdkModifierType   state,
                                                    GimpDisplay      *display);

void       svgtk_tool_manager_oper_update_active         (Gimp             *gimp,
                                                    const GimpCoords *coords,
                                                    GdkModifierType   state,
                                                    gboolean          proximity,
                                                    GimpDisplay      *display);
void       svgtk_tool_manager_cursor_update_active       (Gimp             *gimp,
                                                    const GimpCoords *coords,
                                                    GdkModifierType   state,
                                                    GimpDisplay      *display);


GimpUIManager * svgtk_tool_manager_get_popup_active      (Gimp             *gimp,
                                                    const GimpCoords *coords,
                                                    GdkModifierType   state,
                                                    GimpDisplay      *display,
                                                    const gchar     **ui_path);
*/


G_END_DECLS

#endif /* __SVGTK_TOOL_MANAGER_H__ */
