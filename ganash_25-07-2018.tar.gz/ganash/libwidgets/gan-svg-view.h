/*
 * gan-svg-view.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __GAN_SVG_VIEW_H__
#define __GAN_SVG_VIEW_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define GAN_TYPE_SVG_VIEW            (gan_svg_view_get_type())
#define GAN_SVG_VIEW(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAN_TYPE_SVG_VIEW, GanSvgView))
#define GAN_SVG_VIEW_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GAN_TYPE_SVG_VIEW, GanSvgViewClass))
#define GAN_IS_SVG_VIEW(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAN_TYPE_SVG_VIEW))
#define GAN_IS_SVG_VIEW_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GAN_TYPE_SVG_VIEW))
#define GAN_SVG_VIEW_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GAN_TYPE_SVG_VIEW, GanSvgViewClass))

typedef struct _GanSvgView GanSvgView;
typedef struct _GanSvgViewPrivate GanSvgViewPrivate;
typedef struct _GanSvgViewClass GanSvgViewClass;

struct _GanSvgView {
	GtkWidget parent_instance;
	/* private */
	GanSvgViewPrivate *private_member;
};

struct _GanSvgViewClass {
	GtkWidgetClass parent_class;
};

GType gan_svg_view_get_type();
GanSvgView *gan_svg_view_new();
void gan_svg_view_load_uri (GanSvgView *view, const gchar *uri);
void gan_svg_view_set_time(GanSvgView *view, double time);


G_END_DECLS

#endif /* __GAN_SVG_VIEW_H__ */

