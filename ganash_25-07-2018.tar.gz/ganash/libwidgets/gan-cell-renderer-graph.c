/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "libgeom/geom-box.h"

#include <libgraphics/graphics.h>

#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-scene.h"

#include "gan-cell-renderer-graph.h"

GraphicsFill* create_fill_millimetre()
{
    cairo_matrix_t matrix;
    cairo_matrix_init_scale(&matrix, 1.0, 1.0);
    GraphicsImage     *img   = graphics_image_new_from_uri("/home/haier/Workspace/ganash/0-3/tests/libgraphics/share/pattern_my.test.png");
    GraphicsPattern *pattern = graphics_pattern_new();
    graphics_pattern_set_surface(pattern, img->surface);
    graphics_pattern_set_extend(pattern, CAIRO_EXTEND_REPEAT);
    graphics_pattern_set_matrix(pattern, &matrix);

    GraphicsPainter *painter = graphics_painter_new();
    graphics_painter_set_pattern(painter, pattern);

    GraphicsFill  *fill  = graphics_fill_new();
    fill->painter = painter;

    /*
    GraphicsSolid *solid_red = graphics_solid_new_init(1.0, 1.0, 1.0, 1.0);
    GraphicsPainter *painter = graphics_painter_new();
    graphics_painter_set_solid(painter, solid_red);
    GraphicsFill* fill = graphics_fill_new();
    fill->painter = painter;*/

    return fill;
}

enum
{
    PROP_NULL = 0,
    PROP_SCENE
};

static void     gan_cell_renderer_graph_init       (GanCellRendererGraph      *cell_graph);

static void     gan_cell_renderer_graph_class_init (GanCellRendererGraphClass *klass);

static void     gan_cell_renderer_graph_get_property  (GObject                    *object,
                                                             guint                       param_id,
                                                             GValue                     *value,
                                                             GParamSpec                 *pspec);

static void     gan_cell_renderer_graph_set_property  (GObject                    *object,
                                                             guint                       param_id,
                                                             const GValue               *value,
                                                             GParamSpec                 *pspec);

static void     gan_cell_renderer_graph_finalize (GObject *gobject);


/* These functions are the heart of our custom cell renderer: */

static void     gan_cell_renderer_graph_get_size   (GtkCellRenderer            *cell,
                                                          GtkWidget                  *widget,
                                                          GdkRectangle               *cell_area,
                                                          gint                       *x_offset,
                                                          gint                       *y_offset,
                                                          gint                       *width,
                                                          gint                       *height);

static void     gan_cell_renderer_graph_render     (GtkCellRenderer            *cell,
                                                          GdkWindow                  *window,
                                                          GtkWidget                  *widget,
                                                          GdkRectangle               *background_area,
                                                          GdkRectangle               *cell_area,
                                                          GdkRectangle               *expose_area,
                                                          guint                       flags);



G_DEFINE_TYPE (GanCellRendererGraph, gan_cell_renderer_graph, GTK_TYPE_CELL_RENDERER)

static void
gan_cell_renderer_graph_init (GanCellRendererGraph *cell_graph)
{
	/* TODO: Add initialization code here */
    cell_graph->scene = NULL;
}

static void
gan_cell_renderer_graph_finalize (GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (gan_cell_renderer_graph_parent_class)->finalize (object);
}

static void
gan_cell_renderer_graph_class_init (GanCellRendererGraphClass *klass)
{
	GObjectClass* object_class = G_OBJECT_CLASS (klass);
    GtkCellRendererClass* cell_class = GTK_CELL_RENDERER_CLASS (klass);

	object_class->finalize = gan_cell_renderer_graph_finalize;
    object_class->get_property = gan_cell_renderer_graph_get_property;
    object_class->set_property = gan_cell_renderer_graph_set_property;

    cell_class->get_size = gan_cell_renderer_graph_get_size;
    cell_class->render   = gan_cell_renderer_graph_render;


    /* Install our very own properties */
    g_object_class_install_property (object_class,
                                     PROP_SCENE,
                                     g_param_spec_pointer ("scene",
                                                           "Scene",
                                                           "The scene to renderer",
                                                           G_PARAM_READWRITE));

}


static void
gan_cell_renderer_graph_get_property (GObject    *object,
                                            guint       param_id,
                                            GValue     *value,
                                            GParamSpec *psec)
{
  GanCellRendererGraph  *cell_graph = GAN_CELL_RENDERER_GRAPH(object);

  switch (param_id)
  {
    case PROP_SCENE:
      /*g_value_set_boxed(value, cell_graph->scene);*/
      g_value_set_pointer(value, cell_graph->scene);
      break;

    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID (object, param_id, psec);
      break;
  }
}

static void
gan_cell_renderer_graph_set_property (GObject      *object,
                                            guint         param_id,
                                            const GValue *value,
                                            GParamSpec   *pspec)
{
  GanCellRendererGraph *cell_graph = GAN_CELL_RENDERER_GRAPH (object);

  switch (param_id)
  {
    case PROP_SCENE:
      /*cell_graph->scene = g_value_get_boxed(value);*/
      cell_graph->scene = (RendererScene*) g_value_get_pointer(value);
      break;

    default:
      G_OBJECT_WARN_INVALID_PROPERTY_ID(object, param_id, pspec);
      break;
  }
}

#define FIXED_WIDTH   100
#define FIXED_HEIGHT  10

static void
gan_cell_renderer_graph_get_size (GtkCellRenderer *cell,
                                        GtkWidget       *widget,
                                        GdkRectangle    *cell_area,
                                        gint            *x_offset,
                                        gint            *y_offset,
                                        gint            *width,
                                        gint            *height)
{
  gint calc_width;
  gint calc_height;

  calc_width  = (gint) cell->xpad * 2 + FIXED_WIDTH;
  calc_height = (gint) cell->ypad * 2 + FIXED_HEIGHT;
  /*calc_width  = (gint) FIXED_WIDTH;
  calc_height = (gint) FIXED_HEIGHT;*/

  if (width)
    *width = calc_width;

  if (height)
    *height = calc_height;


  if (cell_area)
  {
    if (x_offset)
    {
      *x_offset = cell->xalign * (cell_area->width - calc_width);
      *x_offset = MAX (*x_offset, 0);
    }

    if (y_offset)
    {
      *y_offset = cell->yalign * (cell_area->height - calc_height);
      *y_offset = MAX (*y_offset, 0);
    }
  }

}

static void
gan_cell_renderer_graph_render (GtkCellRenderer *cell,
                                      GdkWindow       *window,
                                      GtkWidget       *widget,
                                      GdkRectangle    *background_area,
                                      GdkRectangle    *cell_area,
                                      GdkRectangle    *expose_area,
                                      guint            flags)
{
  GanCellRendererGraph *cell_graph = GAN_CELL_RENDERER_GRAPH (cell);
  GtkStateType                state;
  gint                        width, height;
  gint                        x_offset, y_offset;

  gan_cell_renderer_graph_get_size (cell, widget, cell_area,
                                          &x_offset, &y_offset,
                                          &width, &height);

  if (GTK_WIDGET_HAS_FOCUS (widget))
    state = GTK_STATE_ACTIVE;
  else
    state = GTK_STATE_NORMAL;

  /*width  -= cell->xpad*2;
  height -= cell->ypad*2;*/
/*
  gtk_paint_box (widget->style,
                 window,
                 GTK_STATE_NORMAL, GTK_SHADOW_IN,
                 NULL, widget, "trough",
                 cell_area->x + x_offset/* + cell->xpad* /,
                 cell_area->y + y_offset/* + cell->ypad* /,
                 width - 1, height - 1);

  gtk_paint_box (widget->style,
                 window,
                 state, GTK_SHADOW_OUT,
                 NULL, widget, "bar",
                 cell_area->x + x_offset/* + cell->xpad* /,
                 cell_area->y + y_offset/* + cell->ypad* /,
                 width * 0.40/*cell_graph->progress* /,
                 height - 1);
*/
  /*g_return_val_if_fail(cell_graph->scene!=NULL, FALSE);*/

  RendererScene* scene = RENDERER_SCENE(cell_graph->scene);
  if (!scene)
      return;
  RendererObject* root_renderer = RENDERER_OBJECT(scene->root);

  /*g_print("%s\n", G_STRFUNC);*/

  cairo_t *cr = gdk_cairo_create(window);
  cairo_rectangle(cr, background_area->x, background_area->y, background_area->width, background_area->height);
  cairo_clip(cr);

  cairo_translate(cr, background_area->x, background_area->y);
  /*cairo_matrix_t matrix;
  cairo_matrix_init_translate(&matrix, background_area->x, background_area->y);
  cairo_set_matrix(cr, &matrix);*/

  g_print("%s\n", G_STRFUNC);
  GraphicsFill *fill = create_fill_millimetre();
  cairo_rectangle(cr, 0, 0, background_area->width, background_area->height);
  graphics_fill_to_context(fill, cr, FALSE);

  //renderer_object_draw(RENDERER_OBJECT(root_renderer), cr);
  renderer_scene_to_context(scene, cr);



  cairo_destroy(cr);

/*  object_scene->matrix = matrix;*/

}
