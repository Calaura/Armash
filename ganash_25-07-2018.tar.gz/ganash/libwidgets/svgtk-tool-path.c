/*
 * svgtk-tool-path.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "svgtk-tool.h"
#include "svgtk-tool-draw.h"
#include "svgtk-tool-path.h"


static void svgtk_tool_path_draw(SvgtkToolDraw *tool_tool);

static void svgtk_tool_path_class_init(SvgtkToolPathClass *klass);
static void svgtk_tool_path_init(SvgtkToolPath *gobject);

G_DEFINE_TYPE (SvgtkToolPath, svgtk_tool_path, SVGTK_TYPE_TOOL_DRAW)
#define parent_class svgtk_tool_path_parent_class

static void
svgtk_tool_path_class_init(SvgtkToolPathClass *klass)
{
    GObjectClass *gobject_class;
    SvgtkToolClass *tool_class;
    SvgtkToolDrawClass *tool_draw_class;

    gobject_class = (GObjectClass *) klass;
    tool_class = (SvgtkToolClass *) klass;
    tool_draw_class = (SvgtkToolDrawClass *) klass;
/*
    tool_class->control        = gimp_vector_tool_control;
    tool_class->button_press   = gimp_vector_tool_button_press;
    tool_class->button_release = gimp_vector_tool_button_release;
    tool_class->motion         = gimp_vector_tool_motion;
    tool_class->key_press      = gimp_vector_tool_key_press;
    tool_class->modifier_key   = gimp_vector_tool_modifier_key;
    tool_class->oper_update    = gimp_vector_tool_oper_update;
    tool_class->cursor_update  = gimp_vector_tool_cursor_update;
*/

    tool_draw_class->draw   = svgtk_tool_path_draw;

//    svgtk_tool_path_parent_class = g_type_class_peek_parent (klass);
}

static void
svgtk_tool_path_draw (SvgtkToolDraw *tool_draw)
{
  SvgtkToolPath *tool_path = SVGTK_TOOL_PATH (tool_draw);
  g_print("%s\n", G_STRFUNC);
  /*
  SvgtkStroke     *cur_stroke;
  SvgtkVectors    *vectors;

  vectors = tool_path->vectors;

  if (! vectors || ! gimp_vectors_get_bezier (vectors))
    return;

  /* the stroke itself * /
  if (! gimp_item_get_visible (GIMP_ITEM (vectors)))
    gimp_draw_tool_add_path (draw_tool, gimp_vectors_get_bezier (vectors), 0, 0);

  for (cur_stroke = gimp_vectors_stroke_get_next (vectors, NULL);
       cur_stroke;
       cur_stroke = gimp_vectors_stroke_get_next (vectors, cur_stroke))
    {
      GArray *coords;
      GList  *draw_anchors;
      GList  *list;

      /* anchor handles * /
      draw_anchors = gimp_stroke_get_draw_anchors (cur_stroke);

      for (list = draw_anchors; list; list = g_list_next (list))
        {
          GimpAnchor *cur_anchor = GIMP_ANCHOR (list->data);

          if (cur_anchor->type == GIMP_ANCHOR_ANCHOR)
            {
              gimp_draw_tool_add_handle (draw_tool,
                                         cur_anchor->selected ?
                                         GIMP_HANDLE_CIRCLE :
                                         GIMP_HANDLE_FILLED_CIRCLE,
                                         cur_anchor->position.x,
                                         cur_anchor->position.y,
                                         GIMP_TOOL_HANDLE_SIZE_CIRCLE,
                                         GIMP_TOOL_HANDLE_SIZE_CIRCLE,
                                         GIMP_HANDLE_ANCHOR_CENTER);
            }
        }

      g_list_free (draw_anchors);

      if (tool_path->sel_count <= 2)
        {
          /* the lines to the control handles * /
          coords = gimp_stroke_get_draw_lines (cur_stroke);

          if (coords)
            {
              if (coords->len % 2 == 0)
                {
                  gint i;

                  for (i = 0; i < coords->len; i += 2)
                    {
                      GimpCanvasItem *item;

                      item = gimp_draw_tool_add_line
                        (draw_tool,
                         g_array_index (coords, GimpCoords, i).x,
                         g_array_index (coords, GimpCoords, i).y,
                         g_array_index (coords, GimpCoords, i + 1).x,
                         g_array_index (coords, GimpCoords, i + 1).y);

                      gimp_canvas_item_set_highlight (item, TRUE);
                    }
                }

              g_array_free (coords, TRUE);
            }

          /* control handles * /
          draw_anchors = gimp_stroke_get_draw_controls (cur_stroke);

          for (list = draw_anchors; list; list = g_list_next (list))
            {
              GimpAnchor *cur_anchor = GIMP_ANCHOR (list->data);

              gimp_draw_tool_add_handle (draw_tool,
                                         GIMP_HANDLE_SQUARE,
                                         cur_anchor->position.x,
                                         cur_anchor->position.y,
                                         GIMP_TOOL_HANDLE_SIZE_CIRCLE - 3,
                                         GIMP_TOOL_HANDLE_SIZE_CIRCLE - 3,
                                         GIMP_HANDLE_ANCHOR_CENTER);
            }

          g_list_free (draw_anchors);
        }
    }
  */
}

static void
svgtk_tool_path_init (SvgtkToolPath *vector_tool)
{
    SvgtkTool *tool = SVGTK_TOOL (vector_tool);
    /*

    gimp_tool_control_set_handle_empty_image (tool->control, TRUE);
    gimp_tool_control_set_motion_mode        (tool->control,
                                              GIMP_MOTION_MODE_COMPRESS);
    gimp_tool_control_set_precision          (tool->control,
                                              GIMP_CURSOR_PRECISION_SUBPIXEL);
    gimp_tool_control_set_tool_cursor        (tool->control,
                                              GIMP_TOOL_CURSOR_PATHS);
*/
    vector_tool->function       = VECTORS_CREATE_VECTOR;
/*
    vector_tool->restriction    = GIMP_ANCHOR_FEATURE_NONE;
    vector_tool->modifier_lock  = FALSE;
    vector_tool->last_x         = 0.0;
    vector_tool->last_y         = 0.0;
    vector_tool->undo_motion    = FALSE;
    vector_tool->have_undo      = FALSE;

    vector_tool->cur_anchor     = NULL;
    vector_tool->cur_anchor2    = NULL;
    vector_tool->cur_stroke     = NULL;
    vector_tool->cur_position   = 0.0;
    vector_tool->cur_vectors    = NULL;
    vector_tool->vectors        = NULL;

    vector_tool->sel_count      = 0;
    vector_tool->sel_anchor     = NULL;
    vector_tool->sel_stroke     = NULL;

    vector_tool->saved_mode     = GIMP_VECTOR_MODE_DESIGN;
    */
}


SvgtkToolPath *
svgtk_tool_path_new (void)
{
    return g_object_new (svgtk_tool_path_get_type (),
                         NULL);
}

