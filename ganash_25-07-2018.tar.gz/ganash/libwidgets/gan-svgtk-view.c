/*
 * gan-svgtk-view.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <glib-object.h>

#include <cairo/cairo.h>
#include <libgraphics/graphics.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-document.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-g.h"
#include "libsvg/svg-element-svg.h"
#include "libsvg/svg-drawable.h"

#include "libsvgtk/svgtk-types.h"
#include "libsvgtk/svgtk-enums.h"
#include "libsvgtk/svgtk-document.h"

#include "gan-svgtk-view.h"

#define GAN_SVGTK_VIEW_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), GAN_TYPE_SVGTK_VIEW, GanSvgtkViewPrivate))
struct _GanSvgtkViewPrivate {
    SvgtkDocument     *svgtk_doc;

    RendererScene     *scene;

    RendererContainer *renderer;
};

static void gan_svgtk_view_size_request(GtkWidget *widget, GtkRequisition *requisition);
static void gan_svgtk_view_size_allocate(GtkWidget *widget, GtkAllocation *allocation);
static void gan_svgtk_view_realize(GtkWidget *widget);

static gboolean gan_svgtk_view_expose(GtkWidget *widget, GdkEventExpose *event);
static gboolean gan_svgtk_view_motion_notify_event (GtkWidget* widget, GdkEventMotion* event);
static gboolean gan_svgtk_view_button_press_event  (GtkWidget* widget, GdkEventButton* event);
static gboolean gan_svgtk_view_button_release_event  (GtkWidget* widget, GdkEventButton* event);

static void gan_svgtk_view_class_init(GanSvgtkViewClass *klass);
static void gan_svgtk_view_init(GanSvgtkView *gobject);

G_DEFINE_TYPE (GanSvgtkView, gan_svgtk_view, GTK_TYPE_WIDGET)

static void
gan_svgtk_view_class_init(GanSvgtkViewClass *klass)
{
    GtkWidgetClass *widget_class;

    widget_class = (GtkWidgetClass *) klass;

    widget_class->realize       = gan_svgtk_view_realize;
    widget_class->size_request  = gan_svgtk_view_size_request;
    widget_class->size_allocate = gan_svgtk_view_size_allocate;

    widget_class->expose_event          = gan_svgtk_view_expose;
    widget_class->button_press_event    = gan_svgtk_view_button_press_event;
    widget_class->button_release_event  = gan_svgtk_view_button_release_event;
    widget_class->motion_notify_event   = gan_svgtk_view_motion_notify_event;

    g_type_class_add_private(klass, sizeof(GanSvgtkViewPrivate));
//    gan_svgtk_view_parent_class = g_type_class_peek_parent (klass);
}

static void
gan_svgtk_view_init (GanSvgtkView *object)
{
    GanSvgtkViewPrivate *priv = GAN_SVGTK_VIEW_GET_PRIVATE(object);
    object->private_member = priv;
    priv->svgtk_doc = NULL;
}

static void
gan_svgtk_view_size_request(GtkWidget *widget,
    GtkRequisition *requisition)
{
  g_return_if_fail(widget != NULL);
  g_return_if_fail(GAN_IS_SVGTK_VIEW(widget));
  g_return_if_fail(requisition != NULL);

  requisition->width = 80;
  requisition->height = 100;
}


static void
gan_svgtk_view_size_allocate(GtkWidget *widget,
    GtkAllocation *allocation)
{
  g_return_if_fail(widget != NULL);
  g_return_if_fail(GAN_IS_SVGTK_VIEW(widget));
  g_return_if_fail(allocation != NULL);

  widget->allocation = *allocation;

  if (gtk_widget_get_realized(widget)) {
     gdk_window_move_resize(
         widget->window,
         allocation->x, allocation->y,
         allocation->width, allocation->height
     );
   }
}


static void
gan_svgtk_view_realize(GtkWidget *widget)
{
    GdkWindow* window;
    GtkStyle* style;
    GdkWindowAttr attributes;
    guint attributes_mask;

    g_return_if_fail(widget != NULL);
    g_return_if_fail(GAN_IS_SVGTK_VIEW(widget));

    gtk_widget_set_realized(widget, TRUE);
    gtk_widget_ensure_style (widget);

    attributes.window_type = GDK_WINDOW_CHILD;
    attributes.x = widget->allocation.x;
    attributes.y = widget->allocation.y;
    attributes.width = widget->allocation.width;
    attributes.height = widget->allocation.height;

    attributes.wclass = GDK_INPUT_OUTPUT;
    attributes.event_mask = gtk_widget_get_events(widget)
                         | GDK_POINTER_MOTION_MASK
                         | GDK_BUTTON_PRESS_MASK
                         | GDK_BUTTON_RELEASE_MASK
                         | GDK_EXPOSURE_MASK;

    attributes_mask = GDK_WA_X | GDK_WA_Y;

    window = gdk_window_new(
        gtk_widget_get_parent_window (widget),
        & attributes, attributes_mask
    );
    gtk_widget_set_window(widget, window);

    gdk_window_set_user_data(window, widget);

    style = gtk_widget_get_style(widget);
    style = gtk_style_attach(style, window);
    gtk_style_set_background(style, window, GTK_STATE_NORMAL);
    gtk_widget_set_style(widget, style);

}

static gboolean
gan_svgtk_view_expose(GtkWidget *widget, GdkEventExpose *event)
{
  cairo_t *cr;
  cr = gdk_cairo_create(gtk_widget_get_window(widget));

  GanSvgtkView* view = GAN_SVGTK_VIEW(widget);
  GanSvgtkViewPrivate* priv = view->private_member;

  //renderer_object_draw(priv->renderer, cr);
  //renderer_scene_draw(priv->scene, cr);
  SvgDocument    *doc = SVG_DOCUMENT(priv->svgtk_doc);
  DomDocument    *dom_doc = (DomDocument*)doc;
  SvgElementSvg *root = SVG_ELEMENT_SVG(dom_document_get_root(dom_doc));
  SvgElement *element = SVG_ELEMENT(root);
  svg_drawable_draw(element, cr);

  cairo_destroy(cr);

  return FALSE;
}

static gboolean
gan_svgtk_view_button_press_event  (GtkWidget* widget, GdkEventButton* event)
{
    GanSvgtkView* view = GAN_SVGTK_VIEW(widget);
}

static gboolean
gan_svgtk_view_button_release_event  (GtkWidget* widget, GdkEventButton* event)
{
    GanSvgtkView* view = GAN_SVGTK_VIEW(widget);

    return FALSE;
}

static gboolean
gan_svgtk_view_motion_notify_event (GtkWidget* widget, GdkEventMotion* event)
{
    GanSvgtkView* view = GAN_SVGTK_VIEW(widget);
    SvgtkDocument *svgtk_document = view->private_member->svgtk_doc;
    SvgDocument *document = SVG_DOCUMENT(svgtk_document);

    svgtk_document_set_pointer(svgtk_document, event->x, event->y);

    return FALSE;
}

GanSvgtkView *
gan_svgtk_view_new (void)
{
    return g_object_new (gan_svgtk_view_get_type (),
                         NULL);
}


void
gan_svgtk_view_load_uri (GanSvgtkView *view, const gchar *uri)
{
    SvgDocument* doc = svg_document_load(uri);
    GanSvgtkViewPrivate *priv = view->private_member;
    priv->svgtk_doc = doc;

    priv->scene             = g_object_new(RENDERER_TYPE_SCENE, NULL);
    priv->renderer          = svg_element_graphics_get_renderer(svg_document_get_root(doc));

    priv->scene->root       = priv->renderer;
}
