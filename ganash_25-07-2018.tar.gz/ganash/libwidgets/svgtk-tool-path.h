/*
 * svgtk-tool-path.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVGTK_TOOL_PATH_H__
#define __SVGTK_TOOL_PATH_H__

#include <glib-object.h>

G_BEGIN_DECLS


/*  possible vector functions  */
typedef enum
{
  VECTORS_SELECT_VECTOR,
  VECTORS_CREATE_VECTOR,
  VECTORS_CREATE_STROKE,
  VECTORS_ADD_ANCHOR,
  VECTORS_MOVE_ANCHOR,
  VECTORS_MOVE_ANCHORSET,
  VECTORS_MOVE_HANDLE,
  VECTORS_MOVE_CURVE,
  VECTORS_MOVE_STROKE,
  VECTORS_MOVE_VECTORS,
  VECTORS_INSERT_ANCHOR,
  VECTORS_DELETE_ANCHOR,
  VECTORS_CONNECT_STROKES,
  VECTORS_DELETE_SEGMENT,
  VECTORS_CONVERT_EDGE,
  VECTORS_FINISHED
} SvgtkVectorFunction;


#define SVGTK_TYPE_TOOL_PATH            (svgtk_tool_path_get_type())
#define SVGTK_TOOL_PATH(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVGTK_TYPE_TOOL_PATH, SvgtkToolPath))
#define SVGTK_TOOL_PATH_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVGTK_TYPE_TOOL_PATH, SvgtkToolPathClass))
#define SVGTK_IS_TOOL_PATH(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVGTK_TYPE_TOOL_PATH))
#define SVGTK_IS_TOOL_PATH_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVGTK_TYPE_TOOL_PATH))
#define SVGTK_TOOL_PATH_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVGTK_TYPE_TOOL_PATH, SvgtkToolPathClass))

typedef struct _SvgtkToolPath SvgtkToolPath;
typedef struct _SvgtkToolPathClass SvgtkToolPathClass;

struct _SvgtkToolPath {
    SvgtkToolDraw parent_instance;
    /*RendererObject *renderer;*/

    SvgtkVectorFunction   function;       /* function we're performing         */
    /*GimpAnchorFeatureType restriction;    /* movement restriction              */
    gboolean              modifier_lock;  /* can we toggle the Shift key?      */
    GdkModifierType       saved_state;    /* modifier state at button_press    */
    gdouble               last_x;         /* last x coordinate                 */
    gdouble               last_y;         /* last y coordinate                 */
    gboolean              undo_motion;    /* we need a motion to have an undo  */
    gboolean              have_undo;      /* did we push an undo at            */
                                          /* ..._button_press?                 */


    gint            paused_count;   /*  count to keep track of multiple pauses  */
    guint           draw_timeout;   /*  draw delay timeout ID                   */
    guint64         last_draw_time; /*  time of last draw(), monotonically      */

};

struct _SvgtkToolPathClass {
    SvgtkToolDrawClass parent_class;
};

GType svgtk_tool_path_get_type();
SvgtkToolPath *svgtk_tool_path_new();

G_END_DECLS

#endif /* __SVGTK_TOOL_PATH_H__ */

