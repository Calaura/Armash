/*
 * svgtk-tool-transform.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVGTK_TOOL_TRANSFORM_H__
#define __SVGTK_TOOL_TRANSFORM_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define SVGTK_TYPE_TOOL_TRANSFORM            (svgtk_tool_transform_get_type())
#define SVGTK_TOOL_TRANSFORM(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVGTK_TYPE_TOOL_TRANSFORM, SvgtkToolTransform))
#define SVGTK_TOOL_TRANSFORM_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVGTK_TYPE_TOOL_TRANSFORM, SvgtkToolTransformClass))
#define SVGTK_IS_TOOL_TRANSFORM(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVGTK_TYPE_TOOL_TRANSFORM))
#define SVGTK_IS_TOOL_TRANSFORM_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVGTK_TYPE_TOOL_TRANSFORM))
#define SVGTK_TOOL_TRANSFORM_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVGTK_TYPE_TOOL_TRANSFORM, SvgtkToolTransformClass))

typedef struct _SvgtkToolTransform SvgtkToolTransform;
typedef struct _SvgtkToolTransformClass SvgtkToolTransformClass;

struct _SvgtkToolTransform {
	SvgtkTool parent_instance;

    SvgElement     *target;

    RendererObject *renderer_shape;
};

struct _SvgtkToolTransformClass {
	SvgtkToolClass parent_class;
};

GType svgtk_tool_transform_get_type();
SvgtkToolTransform *svgtk_tool_transform_new();

G_END_DECLS

#endif /* __SVGTK_TOOL_TRANSFORM_H__ */

