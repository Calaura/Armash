/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "gan-graph-editor.h"



G_DEFINE_TYPE (GanGraphEditor, gan_graph_editor, GTK_TYPE_BIN)

static void
gan_graph_editor_init (GanGraphEditor *gan_graph_editor)
{


	/* TODO: Add initialization code here */
}

static void
gan_graph_editor_finalize (GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (gan_graph_editor_parent_class)->finalize (object);
}

static void
gan_graph_editor_class_init (GanGraphEditorClass *klass)
{
	GObjectClass* object_class = G_OBJECT_CLASS (klass);
	GtkBinClass* parent_class = GTK_BIN_CLASS (klass);

	object_class->finalize = gan_graph_editor_finalize;
}

