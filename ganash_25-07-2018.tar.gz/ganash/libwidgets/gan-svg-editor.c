/*
 * gan-svg-editor.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include "libcore/core-types.h"
#include "libcore/core-enums.h"
#include "libcore/core-path.h"

#include <libgraphics/graphics.h>
//#include <libfilter/filter.h>

//#include <librenderer/renderer.h>


#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-event.h"
#include "librenderer/renderer-box.h"
#include "librenderer/renderer-view.h"
#include "librenderer/renderer-scene.h"
#include "librenderer/renderer-hit-test-request.h"
#include "librenderer/renderer-hit-test-result.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-container.h"
#include "librenderer/renderer-style.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-shape.h"

#include <libdom/dom.h>

//#include <libsvg/svg.h>
#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-paint.h"
#include "libsvg/svg-length.h"
#include <libxml/tree.h>
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-rect.h"
#include "libsvg/svg-element-path.h"
#include "libsvg/svg-element-g.h"
#include "libsvg/svg-element-svg.h"
#include "libsvg/svg.h"
#include "libsvg/svg-document.h"
#include "libsvg/svg-rect.h"
#include "libsvg/svg-path.h"
#include "libsvg/svg-paint.h"
#include "libsvg/svg-locatable.h"
#include "libsvg/svg-transformable.h"
#include "libsvg/svg-length.h"
#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"
#include "libsvg/svg-animated.h"
#include "libsvg/svg-animated-type.h"
#include "libsvg/svg-animated-type-animator.h"
#include "libsvg/svg-animated-length.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-rect.h"
/*#include "libsvg/svg-renderable.h"*/
#include "libsvg/svg-transform.h"
#include "libsvg/svg-transform-list.h"

#include "svgtk-tool.h"
#include "gan-svg-editor.h"
#include "svgkit-renderer-knot.h"
#include "svgtk-tool-rect.h"
#include "svgtk-tool-draw.h"
#include "svgtk-tool-path.h"
#include "svgtk-tool-transform.h"

#include <string.h>

#define GAN_SVG_EDITOR_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), GAN_TYPE_SVG_EDITOR, GanSvgEditorPrivate))
struct _GanSvgEditorPrivate {
    SvgDocument       *svg_doc;

    RendererScene     *scene_controls;
    RendererScene     *scene_guide;
    RendererScene     *scene_sketch;
    RendererScene     *scene_drawing;
    RendererScene     *scene_grid;

    GList   *object_selections;
    gboolean button_pressed;
    gdouble  button_x;
    gdouble  button_y;

    /*
    SPCanvasItem  *acetate;
    SPCanvasGroup *main;
    SPCanvasGroup *gridgroup;
    SPCanvasGroup *guides;
    SPCanvasItem  *drawing;
    SPCanvasGroup *sketch;
    SPCanvasGroup *controls;
    SPCanvasGroup *tempgroup;   ///< contains temporary canvas items
    SPCanvasItem  *table;       ///< outside-of-page background
    SPCanvasItem  *page;        ///< page background
    SPCanvasItem  *page_border; ///< page border
    */

    RendererShape *curve;
    GList *knot_selections;
    gboolean knot_pressed;
    gdouble knot_x;
    gdouble knot_y;


    RendererStyle *style_editor;
};

static void gan_svg_editor_size_request(GtkWidget *widget, GtkRequisition *requisition);
static void gan_svg_editor_size_allocate(GtkWidget *widget, GtkAllocation *allocation);
static void gan_svg_editor_realize(GtkWidget *widget);

static gboolean gan_svg_editor_expose(GtkWidget *widget, GdkEventExpose *event);
static gboolean gan_svg_editor_motion_notify_event (GtkWidget* widget, GdkEventMotion* event);
static gboolean gan_svg_editor_button_press_event  (GtkWidget* widget, GdkEventButton* event);
static gboolean gan_svg_editor_button_release_event  (GtkWidget* widget, GdkEventButton* event);
static gboolean gan_svg_editor_event  (GtkWidget* widget, GdkEvent* event);


static void gan_svg_editor_class_init(GanSvgEditorClass *klass);
static void gan_svg_editor_init(GanSvgEditor *gobject);

/*G_DEFINE_TYPE (GanSvgEditor, gan_svg_editor, GTK_TYPE_WIDGET)*/
G_DEFINE_TYPE (GanSvgEditor, gan_svg_editor, GTK_TYPE_DRAWING_AREA)

#define parent_class gan_svg_editor_parent_class


static GObject*
gan_svg_editor_constructor(GType                  type,
                           guint                  n_properties,
                           GObjectConstructParam *properties)
{
    GObject *obj;

    {
      /* Always chain up to the parent constructor */
      obj = G_OBJECT_CLASS (parent_class)->constructor (type, n_properties, properties);
    }

    /* update the object state depending on constructor properties */

    return obj;
}


static void
gan_svg_editor_finalize(GObject        *object)
{
    GanSvgEditor *self = GAN_SVG_EDITOR (object);

    /* free dynamic objects */
    /*g_free (self->private_member->renderer_string);*/

    /* Always chain up to the parent class; as with dispose(), finalize()
     * is guaranteed to exist on the parent's class virtual function table
     */
    G_OBJECT_CLASS (parent_class)->finalize (object);
}

static void
gan_svg_editor_class_init(GanSvgEditorClass *klass)
{
    GtkWidgetClass *widget_class;
    GObjectClass *object_class;

    widget_class = (GtkWidgetClass *) klass;
    object_class = (GObjectClass *) klass;

    object_class->constructor = gan_svg_editor_constructor;
    object_class->finalize = gan_svg_editor_finalize;

    widget_class->realize       = gan_svg_editor_realize;
    widget_class->size_request  = gan_svg_editor_size_request;
    widget_class->size_allocate = gan_svg_editor_size_allocate;

    widget_class->expose_event  = gan_svg_editor_expose;
    widget_class->event                 = gan_svg_editor_event;
    widget_class->button_press_event    = gan_svg_editor_button_press_event;
    widget_class->button_release_event  = gan_svg_editor_button_release_event;
    widget_class->motion_notify_event   = gan_svg_editor_motion_notify_event;

    g_type_class_add_private(klass, sizeof(GanSvgEditorPrivate));
//	gan_svg_editor_parent_class = g_type_class_peek_parent (klass);
}

static void
gan_svg_editor_init (GanSvgEditor *object)
{
    object->private_member = GAN_SVG_EDITOR_GET_PRIVATE (object);
    GanSvgEditorPrivate *priv = object->private_member;
    priv->object_selections = NULL;
    priv->button_pressed = FALSE;
    /*
    priv->svg_doc       = NULL;
    */
    priv->knot_selections = NULL;
    priv->knot_pressed = FALSE;
    priv->curve = NULL;

    object->background = NULL;

    object->tool = NULL;
}

static void
gan_svg_editor_size_request(GtkWidget *widget,
    GtkRequisition *requisition)
{
  g_return_if_fail(widget != NULL);
  g_return_if_fail(GAN_IS_SVG_EDITOR(widget));
  g_return_if_fail(requisition != NULL);

  requisition->width = 80;
  requisition->height = 100;
}


static void
gan_svg_editor_size_allocate(GtkWidget *widget,
    GtkAllocation *allocation)
{
  g_return_if_fail(widget != NULL);
  g_return_if_fail(GAN_IS_SVG_EDITOR(widget));
  g_return_if_fail(allocation != NULL);

  widget->allocation = *allocation;

  if (gtk_widget_get_realized(widget)) {
     gdk_window_move_resize(
         widget->window,
         allocation->x, allocation->y,
         allocation->width, allocation->height
     );
   }
}


static void
gan_svg_editor_realize(GtkWidget *widget)
{
    GdkWindow* window;
    GtkStyle* style;
    GdkWindowAttr attributes;
    guint attributes_mask;

    g_return_if_fail(widget != NULL);
    g_return_if_fail(GAN_IS_SVG_EDITOR(widget));

    gtk_widget_set_realized(widget, TRUE);
    gtk_widget_ensure_style (widget);

    attributes.window_type = GDK_WINDOW_CHILD;
    attributes.x = widget->allocation.x;
    attributes.y = widget->allocation.y;
    attributes.width = widget->allocation.width;
    attributes.height = widget->allocation.height;

    attributes.wclass = GDK_INPUT_OUTPUT;
    attributes.event_mask = gtk_widget_get_events(widget)
                         | GDK_POINTER_MOTION_MASK
                         | GDK_BUTTON_PRESS_MASK
                         | GDK_BUTTON_RELEASE_MASK
                         | GDK_EXPOSURE_MASK;

    attributes_mask = GDK_WA_X | GDK_WA_Y;

    window = gdk_window_new(
        gtk_widget_get_parent_window (widget),
        & attributes, attributes_mask
    );
    gtk_widget_set_window(widget, window);

    gdk_window_set_user_data(window, widget);

    style = gtk_widget_get_style(widget);
    style = gtk_style_attach(style, window);
    gtk_style_set_background(style, window, GTK_STATE_NORMAL);
    gtk_widget_set_style(widget, style);

}

static gboolean
gan_svg_editor_expose(GtkWidget *widget, GdkEventExpose *event)
{
  g_print("expose\n");
  cairo_t *cr;
  cr = gdk_cairo_create(gtk_widget_get_window(widget));

  GanSvgEditor* editor = GAN_SVG_EDITOR(widget);
  GanSvgEditorPrivate* priv = editor->private_member;

  /*svg_document_draw(priv->svg_doc, cr);*/
  /*g_print("%s\n", renderer_object_dump(editor->private_member->renderer_drawing, ""));*/

  /*if (! priv->renderer) {
      priv->renderer = svg_element_get_renderer(priv->svg_doc->root);
  }*/

  /*svg_element_update_renderer(priv->svg_doc->root);*/

  /*renderer_scene_draw(scene, renderer, cr);
  renderer_scene_draw(priv->scene_controls, cr);
  renderer_scene_draw(priv->scene_drawing, cr);
  renderer_scene_draw(priv->scene_grid, cr);
  renderer_scene_draw(priv->scene_guide, cr);
  renderer_scene_draw(priv->scene_sketch, cr);*/

  /*if (editor->tool) {
      svgtk_tool_update(editor->tool);
  }*/

  /*if (editor->tool && editor->tool->selection) {
      svgtk_tool_draw(editor->tool, cr);
  }*/

  /*
  SvgDocument    *doc = SVG_DOCUMENT(priv->svg_doc);
  SvgElementSvg *root = SVG_ELEMENT_SVG(doc->root);
  SvgElement *element = SVG_ELEMENT(root);
  svg_drawable_draw(element, cr);
  */

    // use a GraphicsFill//GraphicsPaint
    if (editor->background && editor->background->painter) {
        graphics_painter_to_context(editor->background->painter, cr, FALSE);
        cairo_paint(cr);
    }


    svg_element_graphics_update_renderer(svg_document_get_root(priv->svg_doc));

    //renderer_view_to_context(priv->scene_drawing->view, cr);
    renderer_scene_to_context(priv->scene_drawing, cr);

    renderer_scene_to_context(priv->scene_controls, cr);

//  RendererObject* object = svg_element_get_renderer(element);
//  renderer_object_draw(object, cr);

  /*
  if (priv->renderer_controls) {
      renderer_object_draw(priv->renderer_controls, cr);
  }
  */

  cairo_destroy(cr);

  return FALSE;
}



GraphicsFill* create_fill_solid_green_x()
{
    GraphicsSolid   *solid = graphics_solid_new_init(1.0, 1.0, 1.0, 1.0);
    GraphicsPainter *painter = graphics_painter_new(GRAPHICS_PAINTER_SOLID_TYPE);
                     painter->data.solid = solid;

    GraphicsFill* fill = graphics_fill_new();
    fill->painter = painter;

    return fill;
}

GraphicsStroke* create_stroke_solid_red_x()
{
    GraphicsSolid   *solid   = graphics_solid_new_init(0.0, 0.4, 0.6, 1.0);
    GraphicsPainter *painter = graphics_painter_new(GRAPHICS_PAINTER_SOLID_TYPE);
                     painter->data.solid = solid;

    GraphicsStroke* graphics_stroke = graphics_stroke_new();
    graphics_stroke->width       = 1.0;
    graphics_stroke->cap         = GRAPHICS_CAP_SQUARE;
    graphics_stroke->join        = GRAPHICS_JOIN_MITER;
    graphics_stroke->miter_limit = 2.0;
    graphics_stroke->painter     = painter;

    return graphics_stroke;
}

cairo_path_t* create_path_x()
{
    cairo_surface_t *surface = cairo_image_surface_create (CAIRO_FORMAT_A8, 0, 0);
    cairo_t *cr = cairo_create(surface);

    double size = 6;
    double x_offset = -size/2;
    double y_offset = -size/2;
    cairo_move_to(cr,   0.0+x_offset,   0.0+y_offset);
    cairo_line_to(cr,  size+x_offset,   0.0+y_offset);
    cairo_line_to(cr,  size+x_offset,  size+y_offset);
    cairo_line_to(cr,   0.0+x_offset,  size+y_offset);
    cairo_line_to(cr,   0.0+x_offset,   0.0+y_offset);
    cairo_path_t* c_path = cairo_copy_path(cr);

    return c_path;
}


cairo_path_t* create_path_y()
{
    cairo_surface_t *surface = cairo_image_surface_create (CAIRO_FORMAT_A8, 0, 0);
    cairo_t *cr = cairo_create(surface);

    double size = 6;
    double x_offset = -size/2;
    double y_offset = -size/2;

    cairo_move_to(cr, -x_offset, 0.0);
    cairo_arc(cr, 0.0, 0.0, size/2, 0, 6.283);

    cairo_path_t *path = cairo_copy_path(cr);
    cairo_surface_destroy(surface);
    cairo_destroy(cr);
    return path;
}

cairo_path_t* create_path_line(double x1, double y1, double x2, double y2)
{
    cairo_surface_t *surface = cairo_image_surface_create (CAIRO_FORMAT_A8, 0, 0);
    cairo_t *cr = cairo_create(surface);

    cairo_move_to(cr, x1, y1);
    cairo_line_to(cr, x2, y2);

    cairo_path_t *c_path = cairo_copy_path(cr);
    cairo_new_path(cr);

    cairo_surface_destroy(surface);
    cairo_destroy(cr);
    return c_path;
}


gboolean
gan_svg_editor_knot_enter_notify_event(RendererObject* object, RendererEvent* event/*, ... */, gpointer user_data)
{
    g_print("%s; MouseEvent{x:%f, y:%f}\n", G_STRFUNC, event->x, event->y);
    //SvgkitRendererKnot *knot = SVGKIT_RENDERER_KNOT(object);
    //svgkit_renderer_knot_set_state(knot, STATE_PRELIGHT);

    GanSvgEditor* editor = GAN_SVG_EDITOR(user_data);
    gtk_widget_queue_draw(GTK_WIDGET(editor));

    return FALSE;
}

gboolean
gan_svg_editor_knot_leave_notify_event(RendererObject* object, RendererEvent* event/*, ... */, gpointer user_data)
{
    g_print("%s; MouseEvent{x:%f, y:%f}\n", G_STRFUNC, event->x, event->y);
    //SvgkitRendererKnot *knot = SVGKIT_RENDERER_KNOT(object);
    //svgkit_renderer_knot_set_state(knot, STATE_NORMAL);

    GanSvgEditor* editor = GAN_SVG_EDITOR(user_data);
    gtk_widget_queue_draw(GTK_WIDGET(editor));

    return FALSE;
}

gboolean
gan_svg_editor_knot_press_notify_event(RendererObject* object, RendererEvent* event/*, ... */, gpointer user_data)
{
    //SvgkitRendererKnot *knot = SVGKIT_RENDERER_KNOT(object);
    //svgkit_renderer_knot_set_state(knot, STATE_ACTIVE);

    GanSvgEditor* editor = GAN_SVG_EDITOR(user_data);
    gtk_widget_queue_draw(GTK_WIDGET(editor));

    return FALSE;
}
gboolean
gan_svg_editor_knot_release_notify_event(RendererObject* object, RendererEvent* event/*, ... */, gpointer user_data)
{
    //SvgkitRendererKnot *knot = SVGKIT_RENDERER_KNOT(object);
    //svgkit_renderer_knot_set_state(knot, STATE_PRELIGHT);

    GanSvgEditor* editor = GAN_SVG_EDITOR(user_data);
    gtk_widget_queue_draw(GTK_WIDGET(editor));

    return FALSE;
}

static void gan_svg_editor_handle_rectangle(GanSvgEditor *editor, SvgElementRect *rect)
{
    GanSvgEditorPrivate* priv = editor->private_member;

    gdouble x = rect->x->baseVal->value;
    gdouble y = rect->y->baseVal->value;
    gdouble width  = rect->width->baseVal->value;
    gdouble height = rect->height->baseVal->value;
    gdouble rx     = rect->rx->baseVal->value;
    gdouble ry     = rect->ry->baseVal->value;
    cairo_matrix_t matrix;
    renderer_object_get_transform_abs(SVG_ELEMENT(rect)->private_member->renderer, &matrix);
    gdouble cx = width+x;
    gdouble cy = y;
    cairo_matrix_transform_point(&matrix, &cx, &cy);
    width += x;
    height += y;
    cairo_matrix_transform_point(&matrix, &width, &height);
    cairo_matrix_transform_point(&matrix, &x, &y);

    g_print("x: %f, y: %f, w: %f, h: %f -> %f, %f\n", x, y, width, height, rx, ry);

    RendererShape *knot0 = (RendererShape *) svgkit_renderer_knot_new(KNOT_ANCHOR);
    renderer_object_translate(knot0, x, y);
    g_signal_connect(knot0, "enter_notify_event", G_CALLBACK(gan_svg_editor_knot_enter_notify_event), editor);
    g_signal_connect(knot0, "leave_notify_event", G_CALLBACK(gan_svg_editor_knot_leave_notify_event), editor);
    /*g_signal_connect(knot0, "leave_notify_event", G_CALLBACK(gan_svg_editor_knot_press_notify_event), editor);*/

    RendererShape *knot1 = (RendererShape *) svgkit_renderer_knot_new(KNOT_ANCHOR);
    renderer_object_translate(knot1, width, height);
    g_signal_connect(knot1, "enter_notify_event", G_CALLBACK(gan_svg_editor_knot_enter_notify_event), editor);
    g_signal_connect(knot1, "leave_notify_event", G_CALLBACK(gan_svg_editor_knot_leave_notify_event), editor);

    RendererShape *ctl_rx = (RendererShape *) svgkit_renderer_knot_new(KNOT_HANDLE);
    renderer_object_translate(ctl_rx, cx, cy);
    g_signal_connect(ctl_rx, "enter_notify_event", G_CALLBACK(gan_svg_editor_knot_enter_notify_event), editor);
    g_signal_connect(ctl_rx, "leave_notify_event", G_CALLBACK(gan_svg_editor_knot_leave_notify_event), editor);

    RendererShape *ctl_ry = (RendererShape *) svgkit_renderer_knot_new(KNOT_HANDLE);
    renderer_object_translate(ctl_ry, cx, cy);
    g_signal_connect(ctl_ry, "enter_notify_event", G_CALLBACK(gan_svg_editor_knot_enter_notify_event), editor);
    g_signal_connect(ctl_ry, "leave_notify_event", G_CALLBACK(gan_svg_editor_knot_leave_notify_event), editor);


    /*renderer_style_get_graphics_fill(square, style);*/
    /*renderer_style_get_graphics_stroke(square, style);*/

    /*CssStyleSheet

    SvgStyleSheet *style = svg_style_new();
    SvgStyleRule *rule = svg_style_rule_new();
    SvgStyle *style = svg_style_new("stroke: #006600;");*/
    /*renderer_container_remove_all(priv->renderer_controls);*/

    /*renderer_container_remove(priv->renderer, priv->renderer_controls);
    priv->renderer_controls = g_object_new(RENDERER_TYPE_SCENE, NULL);
    renderer_container_append(RENDERER_CONTAINER(priv->renderer), RENDERER_OBJECT(priv->renderer_controls), -1);*/

    renderer_container_insert(priv->scene_controls->root, knot0, -1);
    renderer_container_insert(priv->scene_controls->root, knot1, -1);
    renderer_container_insert(priv->scene_controls->root, ctl_rx, -1);
    renderer_container_insert(priv->scene_controls->root, ctl_ry, -1);
}

static void gan_svg_editor_handle_path(GanSvgEditor *editor, SvgElementPath *path)
{
    GanSvgEditorPrivate* priv = editor->private_member;

    RendererContainer *renderer_controls = priv->scene_controls->root;

    renderer_container_remove_all(renderer_controls);

    RendererShape *curve = renderer_shape_new(priv->scene_controls, NULL);
    cairo_path_t *curve_path = svg_path_get_cairo_path(path->path);
    GraphicsPath *g_path = renderer_shape_get_path(curve);
    graphics_path_set(g_path, curve_path);
    curve->stroke = create_stroke_solid_red_x();
    renderer_container_insert(renderer_controls, curve, -1);
    priv->curve = curve;
    //renderer_object_set_sensitive(RENDERER_OBJECT(curve), FALSE);
    RENDERER_OBJECT(curve)->sensitive = FALSE;

    SvgElement* element = (SvgElement *) path;
    cairo_matrix_t matrix;
    renderer_object_transform_abs(element->private_member->renderer, &matrix);
    renderer_object_set_transform(curve, &matrix);
    renderer_object_notify_transform((RendererObject*)curve);
/*    renderer_object_update(curve);*/

    double x, y;
    SvgkitRendererKnot *last_anchor = NULL;
    SvgkitRendererKnot *last_handle = NULL;
    SvgkitRendererKnot *next_handle = NULL;
    SvgkitRendererKnot *next_anchor = NULL;
    SvgPathSegment     *last_segment= NULL;
    GList *segments = NULL;
    for (segments = path->path->segments; segments; segments = segments->next) {
        SvgPathSegment *segment = segments->data;

        switch (segment->command)
        {
            case SVG_PATH_COMMAND_MOVE_TO:
            {
                x = segment->data[0];
                y = segment->data[1];
            }
            break;
            case SVG_PATH_COMMAND_CUBIC_TO:
            {
                RendererShape *line0 = renderer_shape_new(priv->scene_controls, NULL);
                //renderer_object_set_sensitive(RENDERER_OBJECT(line0), FALSE);
                RENDERER_OBJECT(line0)->sensitive = FALSE;
                //renderer_object_set_visible(RENDERER_OBJECT(line0), FALSE);
                RENDERER_OBJECT(line0)->visible = FALSE;

                double x_0 = x;
                double y_0 = y;
                double x_1 = segment->data[0];
                double y_1 = segment->data[1];
                /*cairo_matrix_invert(matrix);*/
                cairo_matrix_transform_point(&matrix, &x_0, &y_0);
                cairo_matrix_transform_point(&matrix, &x_1, &y_1);
                g_path = renderer_shape_get_path(line0);
                graphics_path_set(g_path, create_path_line(x_0, y_0, x_1, y_1));
                /*renderer_object_set_transform(line0, matrix);*/
                line0->stroke = create_stroke_solid_red_x();

                x_0 = segment->data[2];
                y_0 = segment->data[3];
                x_1 = segment->data[4];
                y_1 = segment->data[5];
                cairo_matrix_transform_point(&matrix, &x_0, &y_0);
                cairo_matrix_transform_point(&matrix, &x_1, &y_1);
                RendererShape *line1 = renderer_shape_new(priv->scene_controls, NULL);
                //renderer_object_set_sensitive(RENDERER_OBJECT(line1), FALSE);
                //renderer_object_set_visible(RENDERER_OBJECT(line1), FALSE);
                RENDERER_OBJECT(line1)->sensitive = FALSE;
                RENDERER_OBJECT(line1)->visible = FALSE;
                g_path = renderer_shape_get_path(line1);
                graphics_path_set(g_path, create_path_line(x_0, y_0, x_1, y_1));
//                renderer_object_set_transform(line1, matrix);
                line1->stroke = create_stroke_solid_red_x();

                RendererShape *anchor0 = (RendererShape *) svgkit_renderer_knot_new(KNOT_ANCHOR);
                renderer_object_set_transform(anchor0, &matrix);
                renderer_object_notify_transform((RendererObject*)anchor0);
                renderer_object_translate(anchor0, x, y);
                //renderer_object_set_visible(anchor0, TRUE);
                RENDERER_OBJECT(anchor0)->visible = TRUE;
                g_signal_connect(anchor0, "enter_notify_event", G_CALLBACK(gan_svg_editor_knot_enter_notify_event), editor);
                g_signal_connect(anchor0, "leave_notify_event", G_CALLBACK(gan_svg_editor_knot_leave_notify_event), editor);

                RendererShape *handle0 = (RendererShape *) svgkit_renderer_knot_new(KNOT_HANDLE);
                renderer_object_set_transform(handle0, &matrix);
                renderer_object_notify_transform((RendererObject*)handle0);
                renderer_object_translate(handle0, segment->data[0], segment->data[1]);
                renderer_object_notify_transform((RendererObject*)handle0);
                //renderer_object_set_visible(handle0, FALSE);
                RENDERER_OBJECT(handle0)->visible = FALSE;
                g_signal_connect(handle0, "enter_notify_event", G_CALLBACK(gan_svg_editor_knot_enter_notify_event), editor);
                g_signal_connect(handle0, "leave_notify_event", G_CALLBACK(gan_svg_editor_knot_leave_notify_event), editor);

                RendererShape *handle1 = (RendererShape *) svgkit_renderer_knot_new(KNOT_HANDLE);
                renderer_object_set_transform(handle1, &matrix);
                renderer_object_translate(handle1, segment->data[2], segment->data[3]);
                //renderer_object_set_visible(handle1, FALSE);
                RENDERER_OBJECT(handle1)->visible = FALSE;
                g_signal_connect(handle1, "enter_notify_event", G_CALLBACK(gan_svg_editor_knot_enter_notify_event), editor);
                g_signal_connect(handle1, "leave_notify_event", G_CALLBACK(gan_svg_editor_knot_leave_notify_event), editor);

                // SvgPathSegment
                if (last_handle) {
                    svgkit_renderer_knot_set_anchor(last_handle, anchor0);
                }

                svgkit_renderer_knot_set_anchor(handle0, anchor0);
                svgkit_renderer_knot_set_path_segment(handle0, segment);
                svgkit_renderer_knot_set_index(handle0, 0);

                /*svgkit_renderer_knot_set_anchor(handle1, next_anchor);*/
                svgkit_renderer_knot_set_path_segment(handle1, segment);
                svgkit_renderer_knot_set_index(handle1, 1);

                svgkit_renderer_knot_set_prev_handle(anchor0, last_handle);
                svgkit_renderer_knot_set_next_handle(anchor0, handle0);
                svgkit_renderer_knot_set_path_segment(anchor0, last_segment);


                svgkit_renderer_knot_set_line(handle0, line0);
                svgkit_renderer_knot_set_line(handle1, line1);


                /*svgkit_renderer_knot_set_modifier(anchor1, MODIFIER_CONTINOUS, TRUE);
                svgkit_renderer_knot_set_modifier(anchor1, MODIFIER_SYMETRY, TRUE);
                svgkit_renderer_knot_set_position(anchor1, 0, 0);*/

                last_anchor = anchor0;
                last_handle = handle1;
                next_handle = NULL;
                next_anchor = NULL;
                /*svgkit_scene(svgkit_frame, last_handle);
                svgkit_scene_pointe(svgkit_frame, x, y);
                svgkit_scene_click(svgkit_frame, x, y);
                svgkit_knot_moveto(knot, x, y);
                svgkit_document;
                svgkit_document_get_selections();
                svgkit_selections_first();
                svgkit_element_move();*/

                renderer_container_insert(renderer_controls, line0, -1);
                renderer_container_insert(renderer_controls, line1, -1);

                renderer_container_insert(renderer_controls, anchor0, -1);
                renderer_container_insert(renderer_controls, handle0, -1);
                renderer_container_insert(renderer_controls, handle1, -1);

                x = segment->data[4];
                y = segment->data[5];
            }
            break;
        }
        last_segment = segment;
    }
    /*RendererShape *knot = g_object_new(RENDERER_TYPE_SHAPE, NULL);
    renderer_object_translate(knot, x, y);
    renderer_shape_set_path(knot, create_path_x());
    knot->graphics.fill = create_fill_solid_green_x();
    knot->graphics.stroke = create_stroke_solid_red_x();*/
    RendererShape *knot = (RendererShape *) svgkit_renderer_knot_new(KNOT_ANCHOR);
    renderer_object_set_transform(knot, &matrix);
    renderer_object_notify_transform((RendererObject*)knot);
    renderer_object_translate(knot, x, y);

    g_signal_connect(knot, "enter_notify_event", G_CALLBACK(gan_svg_editor_knot_enter_notify_event), editor);
    g_signal_connect(knot, "leave_notify_event", G_CALLBACK(gan_svg_editor_knot_leave_notify_event), editor);
    if (last_handle) {
        svgkit_renderer_knot_set_anchor(last_handle, knot);
    }

    svgkit_renderer_knot_set_prev_handle(knot, last_handle);
    svgkit_renderer_knot_set_next_handle(knot, NULL);


    renderer_container_insert(renderer_controls, knot, -1);
    /*renderer_object_set_transform(priv->renderer_controls, matrix);*/
}

static void gan_svg_editor_handle_selections(GanSvgEditor *editor)
{
    GanSvgEditorPrivate* priv = editor->private_member;
    RendererContainer *renderer_controls = priv->scene_controls->root;

    GList *list = priv->object_selections;
    SvgElement *element = (SvgElement *) g_list_first(list)->data;

    /*
     * editor->set_tool(tool);
     * editor->(tool->)set_selection(element);
     */
    if (SVG_IS_ELEMENT_RECT(element)) {
        g_print("Is Element Rect\n");
        editor->tool = svgtk_tool_rect_new(editor); /*TODO memory management*/
        /*
        editor->tool = svgtk_tool_transform_new(editor);
        */

        /*svgtk_tool_set_selection(editor->tool, element);
        renderer_container_remove_all(renderer_controls);
        renderer_container_append(renderer_controls, editor->tool->renderer, -1);*/
        /*renderer_container_append(priv->renderer_controls, SVGTK_TOOL_RECT(editor->tool)->renderer, -1);*/
        //gan_svg_editor_handle_rectangle(editor, SVG_ELEMENT_RECT(element));
    } else if(SVG_IS_ELEMENT_PATH(element)) {
        /*editor->tool = svgtk_tool_transform_new(editor);*/
        editor->tool = svgtk_tool_path_new(editor);
        /*
        */

        /*svgtk_tool_set_selection(editor->tool, element);
        renderer_container_remove_all(renderer_controls);
        renderer_container_insert(renderer_controls, editor->tool->renderer, -1);*/
        /*gan_svg_editor_handle_path(editor, SVG_ELEMENT_PATH(element));*/
    } else {
        return;
    }


    gtk_widget_queue_draw(GTK_WIDGET(editor));
}

static gboolean gan_svg_editor_event  (GtkWidget* widget, GdkEvent* event)
{
    if(GTK_WIDGET_CLASS (gan_svg_editor_parent_class)->event) {
        g_print("%s\n", G_STRFUNC);
        GTK_WIDGET_CLASS (gan_svg_editor_parent_class)->event(widget, event);
    }

    return FALSE;
}

static SvgElement* gan_svg_editor_get_selection(SvgElement* element)
{
    SvgElement* elt = 0;
    SvgElement* cur = element;
    while(cur && !SVG_IS_ELEMENT_SVG(cur)) {
        elt = cur;
        cur = DOM_NODE(cur)->xml->parent->_private;
    }

    return elt;
}

static gboolean gan_svg_editor_button_press_event  (GtkWidget* widget, GdkEventButton* event)
{
    GanSvgEditor* editor = GAN_SVG_EDITOR(widget);
    GanSvgEditorPrivate* priv = editor->private_member;
    RendererContainer *renderer_controls = priv->scene_controls->root;
    RendererContainer *renderer_drawing = priv->scene_drawing->root;

    cairo_t *cr = gdk_cairo_create(gtk_widget_get_window(widget));


    /* Check knot maniputaion */
    RendererHitTestRequest req;
    req.x      = event->x;
    req.y      = event->y;
    req.type   = RENDERER_HIT_TEST_VISUAL_MODE;
    req.deltat = 0.0;
    RendererObject* object_scene = (RendererObject*) renderer_controls;
    RendererHitTestResult rst_controls = {NULL};
    if (renderer_object_hit_test(object_scene, cr, &req, &rst_controls))
    {
        g_print("Control knot hit: %d\n", g_list_length(rst_controls.items));
        GList* items = g_list_last(rst_controls.items);
        RendererObject* renderer = (RendererObject*) items->data;
        gan_svg_editor_knot_press_notify_event(renderer, NULL, widget);

        /*RendererBox *bbox = renderer_object_bounding_box(renderer, NULL, 0);
        g_print("bbox{%f, %f, %f, %f}\n", bbox->left, bbox->bottom,
                bbox->right-bbox->left, bbox->top-bbox->bottom);*/

        if (priv->knot_selections) {
            g_list_free(priv->knot_selections);
            priv->knot_selections = NULL;
        }
        priv->knot_selections = g_list_append(priv->knot_selections, (gpointer) renderer);
        priv->knot_pressed = TRUE;
        priv->knot_x = event->x;
        priv->knot_y = event->y;
#if 0
        if (SVGKIT_IS_RENDERER_KNOT(renderer)) {
            SvgkitRendererKnot *knot = SVGKIT_RENDERER_KNOT(renderer);
            switch(knot->type)
            {
            case KNOT_ANCHOR:
                {
                    SvgkitRendererKnot *handle_prev = knot->private_member->type.anchor.handle_prev;
                    if (handle_prev) {
                        renderer_object_set_visible(handle_prev, TRUE);
                        renderer_object_set_visible(handle_prev->private_member->type.handle.line_renderer, TRUE);
                    }

                    SvgkitRendererKnot *handle_next = knot->private_member->type.anchor.handle_next;
                    if (handle_next) {
                        renderer_object_set_visible(handle_next, TRUE);
                        renderer_object_set_visible(handle_next->private_member->type.handle.line_renderer, TRUE);
                    }
                    gtk_widget_queue_draw(widget);
                }
                break;
            case KNOT_HANDLE:
                {

                }
                break;
            default:
                {

                }
            break;
            }
        }
#endif
        cairo_destroy(cr);

        return TRUE;
    }


    /*FIXME: renderer_scene_hit_test(priv->scene_drawing);*/

    SvgDocument *document = editor->private_member->svg_doc;
    SvgElement* elt = svg_document_hit(document, event->x, event->y);
    if (elt)
    {
        SvgElement* selected = gan_svg_editor_get_selection(elt);
        g_print("selected: %s#%s\n", G_OBJECT_TYPE_NAME(selected), selected->attribute_id);

        if (priv->object_selections) {
            g_list_free(priv->object_selections);
            priv->object_selections = NULL;
        }
        priv->object_selections = g_list_append(priv->object_selections, (gpointer) selected);
        priv->button_pressed = TRUE;
        priv->button_x = event->x;
        priv->button_y = event->y;

        /*add knots to the editor*/
        gan_svg_editor_handle_selections(editor);
    } else {
        if (priv->object_selections) {
            g_list_free(priv->object_selections);
            priv->object_selections = NULL;
        }
        if (editor->tool) {
            /*svgtk_tool_set_selection(editor->tool, NULL);
            renderer_container_remove_all(renderer_controls);*/
        }
        /*remove knot editor*/
        /*renderer_container_remove(priv->renderer, priv->renderer_controls);
        priv->renderer_controls = g_object_new(RENDERER_TYPE_SCENE, NULL);
        renderer_container_append(RENDERER_CONTAINER(priv->renderer), RENDERER_OBJECT(priv->renderer_controls), -1);*/
        gtk_widget_queue_draw(widget);
    }


    cairo_destroy(cr);

    return TRUE;

}

static gboolean gan_svg_editor_button_release_event  (GtkWidget* widget, GdkEventButton* event)
{
    GanSvgEditor* editor = GAN_SVG_EDITOR(widget);
    GanSvgEditorPrivate* priv = editor->private_member;

    priv->button_pressed = FALSE;
    priv->knot_pressed = FALSE;
    /*if (priv->object_selections) {
        g_list_free(priv->object_selections);
        priv->object_selections = NULL;
    }*/
    if (priv->knot_selections) {
        SvgkitRendererKnot* knot = g_list_first(priv->knot_selections)->data;
        gan_svg_editor_knot_release_notify_event(knot, NULL, widget);
    }

    return FALSE;
}

static gboolean
gan_svg_editor_motion_notify_event (GtkWidget* widget, GdkEventMotion* event)
{
    GanSvgEditor* editor = GAN_SVG_EDITOR(widget);
    GanSvgEditorPrivate *priv = editor->private_member;
    RendererContainer *renderer_controls = priv->scene_controls->root;
    SvgDocument *doc = priv->svg_doc;
    RendererView *view = doc->view;

    cairo_t *cr = gdk_cairo_create(gtk_widget_get_window(widget));

    if (priv->knot_pressed) {
        if (g_list_length(priv->knot_selections) > 0) {
            SvgElement *svg_element = (SvgElement*) priv->object_selections->data;
#if 0
            if (SVG_IS_ELEMENT_PATH(svg_element)) {
                SvgtkToolPath * tool_path = SVGTK_TOOL_PATH(editor->tool);
                GList* list;
                for (list = g_list_first(priv->knot_selections); list; list = list->next) {
                    SvgkitRendererKnot* renderer_knot = (SvgkitRendererKnot*)list->data;
                    if (SVGKIT_IS_RENDERER_KNOT(renderer_knot))
                    switch (renderer_knot->type)
                    {
                    case KNOT_ANCHOR:
                        {
                            g_print("event: %f, %f\n", event->x, event->y);
                            /*tool_path->anchors;
                            tool_path->handles;
                            tool_path->shape;*/
                            SvgElement *element = g_list_first(priv->object_selections)->data;
                            RendererObject *element_renderer = svg_element_graphics_get_renderer(element);
                            cairo_matrix_t *matrix = renderer_object_get_transform_abs(element_renderer);
                            cairo_matrix_invert(matrix);
                            /*cairo_matrix_multiply(&result, &renderer->matrix, matrix);*/
                            double x = event->x;
                            double y = event->y;
                            cairo_matrix_transform_point(matrix, &x, &y);
                            g_print("relative: %f, %f (%f, %f)\n", x, y, event->x, event->y);

                            svgkit_renderer_knot_set_position(renderer_knot, event->x, event->y, x, y);


                            /*
                            gdouble deltat_x = event->x - priv->knot_x;
                            gdouble deltat_y = event->y - priv->knot_y;

                            svgkit_renderer_knot_set_position(renderer_knot, deltat_x, deltat_y);


                            */
                            /*SvgElementPath *elt = (SvgElementPath*) priv->object_selections->data;
                            svg_element_get_renderer((SvgElement*) priv->object_selections->data);
                            SvgtkToolPath* tool_path = SVGTK_TOOL_PATH(editor->tool);
                            renderer_shape_set_path(RENDERER_SHAPE(tool_path->renderer_shape), svg_path_get_cairo_path(elt->path));
                            renderer_object_update(RENDERER_SHAPE(tool_path->renderer_shape));*/
                            /*svgtk_tool_update(editor->tool);*/

                            gtk_widget_queue_draw(widget);
                            priv->knot_x = event->x;
                            priv->knot_y = event->y;
                        }
                        break;
                    case KNOT_HANDLE:
                        {
                            gdouble deltat_x = event->x - priv->knot_x;
                            gdouble deltat_y = event->y - priv->knot_y;
                            /*behavior svgkit_path_manager|svgkit_path_manipulator*/

                            SvgElementPath *elt = (SvgElementPath*) priv->object_selections->data;
                            /*renderer_object_translate(RENDERER_OBJECT(renderer_knot), deltat_x, deltat_y);*/
                            /*svgkit_renderer_knot_set_position(renderer_knot, deltat_x, deltat_y);*/
                            RendererObject *renderer = svg_element_graphics_get_renderer(elt);
                            cairo_matrix_t *matrix = renderer_object_get_transform_abs(renderer->parent);
                            cairo_matrix_invert(matrix);
                            double x = event->x;
                            double y = event->y;
                            cairo_matrix_transform_point(matrix, &x, &y);
                            svgkit_renderer_knot_set_position(renderer_knot, x, y, 0, 0);
                            /*svgkit_renderer_knot_set_position_abs(renderer_knot, event->x, event->y);*/


//                            svg_element_get_renderer((SvgElement*) priv->object_selections->data);
//                            /*svg_element_queue_draw((SvgElement*) priv->object_selections->data);*/
//                            renderer_shape_set_path(priv->curve, svg_path_get_cairo_path(elt->path));
//                            renderer_object_update(priv->curve);


                            gtk_widget_queue_draw(widget);
//                            priv->knot_x = event->x;
//                            priv->knot_y = event->y;
                        }
                        break;
                    default:
                        break;
                    }
                }
            } else if (SVG_IS_ELEMENT_RECT(svg_element)) {

                /* TODO: for each selection*/
                GList* list;
                for (list = g_list_first(priv->knot_selections); list; list = list->next) {

                    SvgtkToolRect * tool_rect = SVGTK_TOOL_RECT(editor->tool);

                    RendererObject* anchor  = tool_rect->knot0;
                    RendererObject* control = tool_rect->knot1;
                    RendererObject* knot_x  = tool_rect->ctl_rx;
                    RendererObject* knot_y = tool_rect->ctl_ry;
                    /*
                    RendererObject* anchor  = g_list_first(priv->renderer_controls->children)->data;
                    RendererObject* control = g_list_first(priv->renderer_controls->children)->next->data;
                    RendererObject* knot_x  = g_list_first(priv->renderer_controls->children)->next->next->data;
                    RendererObject* knot_y = g_list_first(priv->renderer_controls->children)->next->next->next->data;
                    */

                    RendererObject* renderer = RENDERER_OBJECT(list->data);
                    if (renderer == control) {
                        gdouble deltat_x = event->x - priv->knot_x;
                        gdouble deltat_y = event->y - priv->knot_y;

                        SvgElement *element = SVG_ELEMENT(g_list_first(priv->object_selections)->data);
                        RendererObject *element_renderer = svg_element_graphics_get_renderer(element);

                        cairo_matrix_t *matrix = renderer_object_get_transform_bas(element_renderer);
                        cairo_matrix_invert(matrix);
                        /*cairo_matrix_multiply(&result, &renderer->matrix, matrix);*/
                        double x = event->x;
                        double y = event->y;
                        cairo_matrix_transform_point(matrix, &x, &y);
                        g_print("relative: %f, %f (%f, %f)\n", x, y, event->x, event->y);

                        renderer_object_translate(renderer, deltat_x, deltat_y);
                        /*set position absolute*/


                        SvgElementRect *rect = (SvgElementRect *) element;
                        svg_length_set_value(rect->width->baseVal, x-rect->x->baseVal->value, rect->width->baseVal->unit, FALSE);
                        svg_length_set_value(rect->height->baseVal, y-rect->y->baseVal->value, rect->height->baseVal->unit, FALSE);
                        set_status(element, SHAPE, EXPIRED);


                        svg_element_graphics_get_renderer(element);

                        cairo_matrix_t *mx = renderer_object_get_transform_abs(element_renderer);
                        double rx = rect->x->baseVal->value + rect->width->baseVal->value;
                        double ry = rect->y->baseVal->value;
                        cairo_matrix_transform_point(mx, &rx, &ry);
                        cairo_matrix_t *m = g_new(cairo_matrix_t, 1);
                        cairo_matrix_init_translate(m, rx, ry);

                        /*renderer_object_translate(knot_x, deltat_x, 0);*/
                        /*renderer_object_translate(knot_y, deltat_x, 0);*/
                        renderer_object_set_transform(knot_x, m);
                        renderer_object_set_transform(knot_y, m);

                        gtk_widget_queue_draw(widget);
                        priv->knot_x = event->x;
                        priv->knot_y = event->y;

                    } else if (renderer == anchor) {
                        gdouble deltat_x = event->x - priv->knot_x;
                        gdouble deltat_y = event->y - priv->knot_y;


                        SvgElement *element = SVG_ELEMENT(g_list_first(priv->object_selections)->data);
                        RendererObject *element_renderer = svg_element_graphics_get_renderer(element);

                        cairo_matrix_t *matrix = renderer_object_get_transform_abs(element_renderer);
                        cairo_matrix_invert(matrix);
                        /*cairo_matrix_multiply(&result, &renderer->matrix, matrix);*/
                        double x = event->x;
                        double y = event->y;
                        cairo_matrix_transform_point(matrix, &x, &y);
                        g_print("relative: %f, %f (%f, %f)\n", x, y, event->x, event->y);

                        SvgElementRect *rect = (SvgElementRect *) element;
                        svg_length_set_value(rect->width->baseVal,  rect->width->baseVal->value-x+rect->x->baseVal->value, rect->width->baseVal->unit, FALSE);
                        svg_length_set_value(rect->height->baseVal, rect->height->baseVal->value-y+rect->y->baseVal->value, rect->height->baseVal->unit, FALSE);
                        svg_length_set_value(rect->x->baseVal, x, rect->x->baseVal->unit, FALSE);
                        svg_length_set_value(rect->y->baseVal, y, rect->y->baseVal->unit, FALSE);
                        set_status(element, SHAPE, EXPIRED);

                        renderer_object_translate(renderer, deltat_x, deltat_y);


/*
                        g_print("deltat: %f, %f\n", deltat_x, deltat_y);
                        renderer_object_translate(renderer, deltat_x, deltat_y);
                        SvgElement *element = g_list_first(priv->object_selections)->data;

                        SvgElementRect *rect = (SvgElementRect *) element;
                        svg_length_set_value(rect->x->baseVal, rect->x->baseVal->value + deltat_x, rect->x->baseVal->unit, FALSE);
                        svg_length_set_value(rect->y->baseVal, rect->y->baseVal->value + deltat_y, rect->y->baseVal->unit, FALSE);
                        svg_length_set_value(rect->width->baseVal, rect->width->baseVal->value - deltat_x, rect->width->baseVal->unit, FALSE);
                        svg_length_set_value(rect->height->baseVal, rect->height->baseVal->value - deltat_y, rect->height->baseVal->unit, FALSE);
                        set_status(rect, SVG_ELEMENT_RECT_SHAPE, SVG_ELEMENT_RECT_STATUS_EXPIRED);
*/

                        svg_element_graphics_get_renderer(element);
                        /*svg_element_graphics_update_renderer(element);*/



                        cairo_matrix_t *mx = renderer_object_get_transform_abs(element_renderer);
                        double rx = rect->x->baseVal->value + rect->width->baseVal->value;
                        double ry = rect->y->baseVal->value;
                        cairo_matrix_transform_point(mx, &rx, &ry);
                        g_print("round: %f, %f (%f, %f)\n", rx, ry, event->x, event->y);
                        cairo_matrix_t *m = g_new(cairo_matrix_t, 1);
                        cairo_matrix_init_translate(m, rx, ry);

                        /*renderer_object_translate(knot_x, 0, deltat_y);*/
                        /*renderer_object_translate(knot_y, 0, deltat_y);*/
                        renderer_object_set_transform(knot_x, m);
                        renderer_object_set_transform(knot_y, m);

                        gtk_widget_queue_draw(widget);
                        priv->knot_x = event->x;
                        priv->knot_y = event->y;
                    } else if (renderer == knot_x) {

                    } else if (renderer == knot_y) {

                    }
                }
            }
#endif

        }
    } else if (priv->button_pressed) {
        if (g_list_length(priv->object_selections) > 0) {
            GList* list;
            for (list = g_list_first(priv->object_selections); list; list = list->next) {
                //SvgElement* element = SVG_ELEMENT(list->data);
                SvgElement* selected = (SvgElement*) list->data;
                //g_print("element(#%p) = %s (%s)\n", element, element->name, element->attribute_id);
                //g_print("selected(#%p) = %s (%s)\n", selected, selected->name, selected->attribute_id);
                // SvgElementRect->getAttribute(SVG_ATTRIBUTE_ID);
                // svg_element_get_attribute_by_enum(SVG_ATTRIBUTE_ID);
                // svg_element_get_attribute_by_name(SVG_ATTRIBUTE_ID);
                // svg_element_get_attribute_by_nick("id");


                //SvgRect *bb = svg_locatable_get_bbox(element);
                //g_print("\tRect{%f, %f, %f, %f}\n", bb->x, bb->y, bb->width, bb->height);

                gdouble del_x = event->x - priv->button_x;
                gdouble del_y = event->y - priv->button_y;
                //g_print("deltat_x: %f; deltat_y: %f\n", del_x, del_y);
                SvgTransformList *transform_list = svg_element_graphics_get_transform(selected);
                /*gchar *str = svg_transform_list_to_string(transform_list);
                g_print("%s\n", str);
                g_free(str);*/

                SvgTransform *transform = svg_transform_list_get_item(transform_list, 0);
                if (!transform || transform->type != SVG_TRANSFORM_TRANSLATE) {
                    transform = svg_transform_new();
                    svg_transform_set_translate(transform, 0, 0);
                    svg_transform_list_prepend(transform_list, transform);
                }
                svg_transform_translate(transform, del_x, del_y);

                // TODO: systeme update cascading
                //set_status(selected, TRANSFORM, MODIFIED);
                //set_status(selected, SHAPE, MODIFIED);
                //svg_element_graphics_set_transform_status(element);

                svg_element_graphics_queue_update(selected,
                                                  SVG_UPDATE_TRANSFORM_FLAG,
                                                  0/*CHILD|PARENT|SELF|NONE*/);
                //svg_element_graphics_update(selected);

                //svg_element_graphics_notify_change();// propagate

                //svg_transformable_set_transform(element, transform_translate);???
                cairo_matrix_t matrix;
                svg_transform_list_get_c_matrix(transform_list, &matrix);
                renderer_object_set_transform(selected->private_member->renderer, &matrix);
                renderer_object_notify_transform((RendererObject*)selected->private_member->renderer);

                //svg_element_graphics_update_renderer(selected);
                //g_print("%s\n", G_OBJECT_TYPE_NAME(selected));

                /*gchar *str1 = svg_element_to_string(selected, "");
                g_print("%s\n", str1);
                g_free(str1);*/

                gtk_widget_queue_draw(widget);
                priv->button_x = event->x;
                priv->button_y = event->y;
            }
        }
    } else {
        SvgElement* elt = svg_document_hit(doc, event->x, event->y);
        if (elt) {
            SvgElement* selected = gan_svg_editor_get_selection(elt);
            g_print("selected: %s#%s\n", G_OBJECT_TYPE_NAME(selected), selected->attribute_id);
            //elt = gan_svg_editor_get_selection(elt);
            //g_print("hit %s; x: %f, y: %f\n", elt->attribute_id, event->x, event->y);
        }

        /*
        RendererHitTestRequest req;
        req.x      = event->x;
        req.y      = event->y;
        req.type   = RENDERER_HIT_TEST_FILL_MODE;
        req.deltat = 0.0;

        RendererHitTestResult rst = {NULL};
        renderer_view_hit_test(view, NULL, &req, &rst);
        if (rst.items) {
            RendererObject* object = g_list_first(rst.items)->data;
            SvgElement *element = RENDERER_OBJECT(object)->data;
            SvgElement* selected = gan_svg_editor_get_selection(element);
            if (selected) {
                element = selected;
            }

            g_print("hit %s (%d Objects); x: %f, y: %f\n", element->attribute_id, g_list_length(rst.items), event->x, event->y);
        }
        */
    }

    cairo_destroy(cr);

    return FALSE;
}

GanSvgEditor *
gan_svg_editor_new (void)
{
	return g_object_new (gan_svg_editor_get_type (),
	                     NULL);
}

// TODO gan_svg_editor_set_document();
// TODO gan_svg_editor_get_document();
// TODO gan_svg_view_set_document();
// TODO gan_svg_view_get_document();
void
gan_svg_editor_load_uri (GanSvgEditor *view, const gchar *uri)
{
    SvgDocument* doc_controls = svg_document_load(uri);

    SvgDocument* doc = svg_document_load(uri);
    GanSvgEditorPrivate *priv = view->private_member;
    priv->svg_doc = doc;

    // FIXME: RendererScene
    priv->scene_controls      = svg_document_get_view(doc_controls)->scene;

    priv->scene_drawing       = svg_document_get_view(doc)->scene;
/*
    priv->scene_grid       = g_object_new(RENDERER_TYPE_SCENE, NULL);
    priv->scene_grid->root = g_object_new(RENDERER_TYPE_CONTAINER, NULL);
    priv->scene_guide       = g_object_new(RENDERER_TYPE_SCENE, NULL);
    priv->scene_guide->root = g_object_new(RENDERER_TYPE_CONTAINER, NULL);
    priv->scene_sketch       = g_object_new(RENDERER_TYPE_SCENE, NULL);
    priv->scene_sketch->root = g_object_new(RENDERER_TYPE_CONTAINER, NULL);
*/

    renderer_scene_set_view(priv->scene_controls, priv->scene_drawing->view);
    //renderer_scene_set_root(priv->scene_controls, priv->scene_controls->root);
    renderer_scene_set_target(priv->scene_controls, priv->scene_controls->root);

}

void gan_svg_editor_set_time(GanSvgEditor *editor, double time)
{
    svg_document_set_time(editor->private_member->svg_doc, time);
}

void gan_svg_editor_set_background(GanSvgEditor *editor, GraphicsFill *fill)
{
    editor->background = fill;
}
