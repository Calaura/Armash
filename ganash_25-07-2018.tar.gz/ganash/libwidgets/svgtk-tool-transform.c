/*
 * svgtk-tool-transform.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <liblog/log.h>

#include <libgraphics/graphics.h>


#include <glib-object.h>
#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"
#include "librenderer/renderer-event.h"
#include "librenderer/renderer-cache.h"
#include "librenderer/renderer-object.h"
#include "librenderer/renderer-item.h"
#include "librenderer/renderer-shape.h"
#include "librenderer/renderer-container.h"

#include <libdom/dom.h>

#include "libsvg/svg-types.h"
#include "libsvg/svg-enums.h"
#include "libsvg/svg-length.h"
#include "libmotion/motion-types.h"
#include "libmotion/motion-animation.h"
#include "libmotion/motion-property.h"
#include "libsvg/svg-animated.h"
#include "libsvg/svg-animated-type.h"
#include "libsvg/svg-animated-type-animator.h"
#include "libsvg/svg-animated-length.h"
#include "libsvg/svg-path.h"
#include "libsvg/svg-paint.h"
#include "libsvg/svg-document.h"
#include "libsvg/svg-element.h"
#include "libsvg/svg-element-private.h"
#include "libsvg/svg-element-graphics.h"
#include "libsvg/svg-element-path.h"
#include "libsvg/svg-rect.h"
#include "libsvg/svg-locatable.h"

#include "svgkit-renderer-knot.h"
#include "svgtk-tool.h"
#include "gan-svg-editor.h"
#include "svgtk-tool-transform.h"

static void svgtk_tool_transform_draw(SvgtkTool *tool, cairo_t* cr);
static void svgtk_tool_transform_set_selection(SvgtkTool *tool, SvgElement *element);
static void svgtk_tool_transform_update(SvgtkTool *tool);


static void svgtk_tool_transform_class_init(SvgtkToolTransformClass *klass);
static void svgtk_tool_transform_init(SvgtkToolTransform *gobject);

G_DEFINE_TYPE (SvgtkToolTransform, svgtk_tool_transform, SVGTK_TYPE_TOOL)

static void
svgtk_tool_transform_class_init(SvgtkToolTransformClass *klass)
{
    GObjectClass *gobject_class;
    SvgtkToolClass *tool_class;

    gobject_class = (GObjectClass *) klass;
    tool_class    = (SvgtkToolClass *) klass;
/*
    tool_class->draw          = svgtk_tool_transform_draw;
    tool_class->set_selection = svgtk_tool_transform_set_selection;
    tool_class->update        = svgtk_tool_transform_update;
*/
}

cairo_path_t* svgtk_tool_transform_create_path(SvgtkToolTransform *tool)
{
    /*
    cairo_surface_t *surface = cairo_image_surface_create (CAIRO_FORMAT_A8, 0, 0);
    cairo_t *cr = cairo_create(surface);

    SvgElement *rect = SVGTK_TOOL(tool)->selection;
    SvgRect *r = svg_locatable_get_bbox(rect);

    double size_w = r->width;
    double size_h = r->height;
    double x_offset = r->x;
    double y_offset = r->y;

    cairo_move_to(cr,       0.0+x_offset,       0.0+y_offset);
    cairo_line_to(cr,    size_w+x_offset,       0.0+y_offset);
    cairo_line_to(cr,    size_w+x_offset,    size_h+y_offset);
    cairo_line_to(cr,       0.0+x_offset,    size_h+y_offset);
    cairo_line_to(cr,       0.0+x_offset,       0.0+y_offset);

    cairo_path_t *path = cairo_copy_path(cr);
    cairo_surface_destroy(surface);
    cairo_destroy(cr);

    return path;
    */
    return NULL;
}

static void
svgtk_tool_transform_update(SvgtkTool *tool)
{
/*
    SvgtkToolTransform *tool_transform = SVGTK_TOOL_TRANSFORM(tool);
    if (!tool->selection) {
        return;
    }
    SvgElement *rect = tool->selection;
    g_print("SvgElementTransformable: %p\n", rect);

    cairo_path_t* path = svgtk_tool_transform_create_path(tool_transform);
    renderer_shape_set_path(tool_transform->renderer_shape, path);
    RENDERER_SHAPE(tool_transform->renderer_shape)->graphics.fill = NULL;
*/
}

static void
svgtk_tool_transform_draw(SvgtkTool *tool, cairo_t* cr)
{
    SvgtkToolTransform *tool_transform = SVGTK_TOOL_TRANSFORM(tool);

    /*svgtk_tool_transform_update(tool);
    renderer_object_draw(tool->renderer, cr);*/
}

static void
svgtk_tool_transform_set_selection(SvgtkTool *tool, SvgElement *element)
{
    SvgtkToolTransform *tool_transform = SVGTK_TOOL_TRANSFORM(tool);

    /*SVGTK_TOOL_CLASS(parent_class)->set_selection(tool, element);*/
    /*tool->selection = element;
    svgtk_tool_transform_update(tool);

    renderer_object_set_visible(tool->renderer, TRUE);*/
}

static void
svgtk_tool_transform_init (SvgtkToolTransform *object)
{
    /*SvgtkTool *tool = SVGTK_TOOL(object);
    tool->renderer = (RendererObject *) renderer_container_new();

    object->renderer_shape = (RendererObject *) svgkit_renderer_knot_new(KNOT_ANCHOR);
    renderer_container_append(tool->renderer, object->renderer_shape, -1);*/
}

SvgtkToolTransform *
svgtk_tool_transform_new (void)
{
	return g_object_new (svgtk_tool_transform_get_type (),
	                     NULL);
}

