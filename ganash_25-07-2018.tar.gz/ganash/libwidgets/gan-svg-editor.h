/*
 * gan-svg-editor.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __GAN_SVG_EDITOR_H__
#define __GAN_SVG_EDITOR_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define GAN_TYPE_SVG_EDITOR            (gan_svg_editor_get_type())
#define GAN_SVG_EDITOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAN_TYPE_SVG_EDITOR, GanSvgEditor))
#define GAN_SVG_EDITOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GAN_TYPE_SVG_EDITOR, GanSvgEditorClass))
#define GAN_IS_SVG_EDITOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAN_TYPE_SVG_EDITOR))
#define GAN_IS_SVG_EDITOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GAN_TYPE_SVG_EDITOR))
#define GAN_SVG_EDITOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GAN_TYPE_SVG_EDITOR, GanSvgEditorClass))

/*typedef struct _GanSvgView GanSvgView;*/
typedef struct _GanSvgEditor GanSvgEditor;
typedef struct _GanSvgEditorPrivate GanSvgEditorPrivate;
typedef struct _GanSvgEditorClass GanSvgEditorClass;

struct _GanSvgEditor {
    /*GtkWidget parent_instance;*/
    GtkDrawingArea parent_instance;

    /* private */
    GraphicsFill *background;
    SvgtkTool *tool;
    GanSvgEditorPrivate *private_member;
};

struct _GanSvgEditorClass {
    /*GtkWidgetClass parent_class;*/
    GtkDrawingAreaClass parent_class;
};

GType gan_svg_editor_get_type();
GanSvgEditor *gan_svg_editor_new();
void gan_svg_editor_load_uri (GanSvgEditor *view, const gchar *uri);
void gan_svg_editor_set_time(GanSvgEditor *editor, double time);
void gan_svg_editor_set_background(GanSvgEditor *editor, GraphicsFill *fill);

G_END_DECLS

#endif /* __GAN_SVG_EDITOR_H__ */

