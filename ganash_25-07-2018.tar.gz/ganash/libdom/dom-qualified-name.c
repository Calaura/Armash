/*
 * dom-qualified-name.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "dom-types.h"
#include "dom-qualified-name.h"

#include <string.h>

gboolean dom_qualified_name_equ(DomQualifiedName *attribute, DomQualifiedName *qualified_name)
{
    if (0!=g_ascii_strcasecmp(attribute->prefix, qualified_name->prefix)) {
        return FALSE;
    }
    if (0!=g_ascii_strcasecmp(attribute->name, qualified_name->name)) {
        return FALSE;
    }
    return TRUE;
}
char*
dom_qualified_name_to_string(DomQualifiedName *name, char *default_prefix)
{
    if (name->prefix) {
        if (default_prefix && g_ascii_strcasecmp(name->prefix, default_prefix)==0) {
            return g_strdup_printf("%s", name->name);
        } else {
            return g_strdup_printf("%s:%s", name->prefix, name->name);
        }
    } else {
        return g_strdup_printf("%s", name->name);
    }
}

gboolean dom_parser_parse_qualified_name(DomQualifiedName *attribute, char *str, char *end)
{
    char *pos = NULL;
    char *ptr = str;

    while(ptr!=NULL && ptr<end) {
        if (*ptr==':') {
            pos = ptr;
            break;
        }
        ptr++;
    }

    if (pos) {
        attribute->prefix = g_strndup(str, pos-str);
        attribute->name   = g_strdup(pos+1);
    } else {
        attribute->prefix = NULL;
        attribute->name   = g_strdup(str);
    }
}
