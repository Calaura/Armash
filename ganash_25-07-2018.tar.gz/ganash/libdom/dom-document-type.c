/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-document-type.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include <liblog/log.h>
#include <librenderer/renderer-enums.h>

#include "dom.h"
#include "dom-node.h"
#include "dom-document-type.h"


static void dom_document_type_class_init(DomDocumentTypeClass *klass);
static void dom_document_type_init(DomDocumentType *gobject);

G_DEFINE_TYPE (DomDocumentType, dom_document_type, DOM_TYPE_NODE)

static void
dom_document_type_class_init(DomDocumentTypeClass *klass)
{
//	DomNodeClass *domnode_class;
//	domnode_class = (DomNodeClass *) klass;
//	dom_document_type_parent_class = g_type_class_peek_parent (klass);
}

static void
dom_document_type_init (DomDocumentType *object)
{
}

DomDocumentType *
dom_document_type_new (DomDocument *document, gchar *qualified_name, gchar *public_id, gchar *system_id)
{
	return g_object_new (dom_document_type_get_type (),
	                     NULL);
}

