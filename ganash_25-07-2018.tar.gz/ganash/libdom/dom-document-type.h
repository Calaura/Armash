/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-document-type.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DOM_DOCUMENT_TYPE_H__
#define __DOM_DOCUMENT_TYPE_H__



G_BEGIN_DECLS

#define DOM_TYPE_DOCUMENT_TYPE            (dom_document_type_get_type())
#define DOM_DOCUMENT_TYPE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DOM_TYPE_DOCUMENT_TYPE, DomDocumentType))
#define DOM_DOCUMENT_TYPE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DOM_TYPE_DOCUMENT_TYPE, DomDocumentTypeClass))
#define DOM_IS_DOCUMENT_TYPE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DOM_TYPE_DOCUMENT_TYPE))
#define DOM_IS_DOCUMENT_TYPE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DOM_TYPE_DOCUMENT_TYPE))
#define DOM_DOCUMENT_TYPE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DOM_TYPE_DOCUMENT_TYPE, DomDocumentTypeClass))

typedef struct _DomDocumentTypeClass DomDocumentTypeClass;

struct _DomDocumentType {
	DomNode parent_instance;

    // DomDocument *ownerDocument = NULL;// Un nouveau noeud DOMDocumentType avec son ownerDocument défini à NULL.
};

struct _DomDocumentTypeClass {
	DomNodeClass parent_class;
};

GType dom_document_type_get_type();
DomDocumentType *dom_document_type_new(DomDocument *document, gchar *qualified_name, gchar *public_id, gchar *system_id);

G_END_DECLS

#endif /* __DOM_DOCUMENT_TYPE_H__ */

