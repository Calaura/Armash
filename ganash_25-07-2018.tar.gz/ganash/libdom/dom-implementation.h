/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-implementation.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DOM_IMPLEMENTATION_H__
#define __DOM_IMPLEMENTATION_H__


G_BEGIN_DECLS

#define DOM_TYPE_IMPLEMENTATION            (dom_implementation_get_type())
#define DOM_IMPLEMENTATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DOM_TYPE_IMPLEMENTATION, DomImplementation))
#define DOM_IMPLEMENTATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DOM_TYPE_IMPLEMENTATION, DomImplementationClass))
#define DOM_IS_IMPLEMENTATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DOM_TYPE_IMPLEMENTATION))
#define DOM_IS_IMPLEMENTATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DOM_TYPE_IMPLEMENTATION))
#define DOM_IMPLEMENTATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DOM_TYPE_IMPLEMENTATION, DomImplementationClass))

typedef struct _DomImplementationClass DomImplementationClass;

struct _DomImplementation {
	GObject parent_instance;
};

struct _DomImplementationClass {
	GObjectClass parent_class;
    //DomDocument     *(*create_document)(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype);
    //DomDocumentType *(*create_document_type)(gchar *qualified_name, gchar *public_id, gchar *system_id);
    //DomDocument     *(*create_element)(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype);
    DomNode           *(*create_element_ns)(gchar *ns, gchar *name, DomDocument *document, GError **error);
    //DomDocument     *(*create_attribute)(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype);
    //DomDocument     *(*create_attribute_ns)(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype);
    //DomDocument     *(*create_comment)(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype);
    //DomDocument     *(*create_cdata_section)(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype);
    //DomDocument     *(*create_document_fragment)(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype);

    gboolean         (*has_feature)(DomImplementation *self, gchar *feature , gchar *version);
};

GType dom_implementation_get_type();
DomImplementation *dom_implementation_new();

DomNode *dom_implementation_create_ns_element(gchar *node_ns, gchar *node_name, DomDocument *document, GError **error);

DomDocument *dom_implementation_create_document(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype);
DomDocumentType *dom_implementation_create_document_type(gchar *qualified_name, gchar *public_id, gchar *system_id);
gboolean         dom_implementation_has_feature(DomImplementation *self, gchar *feature , gchar *version);

// DTD <- xml
// Feature <- DOM

G_END_DECLS

#endif /* __DOM_IMPLEMENTATION_H__ */

