/*
 * dom-types.h
 * Copyright (C) 2014       MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DOM_TYPES_H__
#define __DOM_TYPES_H__

#define XML_DEFAULT_VERSION "1.0"

typedef struct  _DomQualifiedName           DomQualifiedName;
typedef struct  _DomNamespace               DomNamespace;

typedef struct  _DomException               DomException;

typedef struct  _DomImplementation          DomImplementation;
typedef struct  _DomNode                    DomNode;
typedef struct  _DomDocumentType            DomDocumentType;
typedef struct  _DomDocument                DomDocument;
typedef struct  _DomElement                 DomElement;

typedef struct  _DomEventListener           DomEventListener;

#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
typedef guint                               DomDumpFlags;
typedef enum    _DomDumpFlag                DomDumpFlag;
#define DOM_DUMP_ALL \
    ( LOG_DUMP_ALL \
    | DOM_DUMP_RECURSIVE_FLAG \
    | DOM_DUMP_POINTER_FLAG \
    | DOM_DUMP_TRANSFORM_FLAG \
    | DOM_DUMP_PATH_FLAG \
    | DOM_DUMP_ID_FLAG \
    | DOM_DUMP_ATTRIBUTES_FLAG)

#define DOM_DUMP_ALL_TESTABLE \
    ( LOG_DUMP_ALL \
    | DOM_DUMP_RECURSIVE_FLAG \
    | DOM_DUMP_TRANSFORM_FLAG \
    | DOM_DUMP_PATH_FLAG \
    | DOM_DUMP_ID_FLAG \
    | DOM_DUMP_ATTRIBUTES_FLAG)
#endif


#endif /* __DOM_TYPES_H__ */
