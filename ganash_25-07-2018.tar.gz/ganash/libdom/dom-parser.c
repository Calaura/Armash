/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-parser.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include <liblog/log.h>

#include "librenderer/renderer-types.h"
#include "librenderer/renderer-enums.h"

#include <libxml/tree.h>

#include "dom-types.h"
#include "dom-enums.h"
#include "dom-document.h"
#include "dom-node.h"
#include "dom-element.h"
#include "dom-qualified-name.h"
//#include "dom-namespace.h"
#include "dom-implementation.h"

#include "dom-parser.h"


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <libxml/parser.h>
#include <libxml/parserInternals.h>



typedef DomElement* (*fct_parcours_t)(xmlNode*, DomElement*);

DomElement* dom_parser_build(xmlNode *node, DomElement* dom_parent) {
    GError* error = NULL;
    DomElement* dom_element = NULL;
    DomDocument *document = dom_node_get_document(DOM_NODE(dom_parent));

    char *default_namespace;
    dom_document_namespace(document, &default_namespace);
    char *prefix = (node->ns && node->ns->prefix) ? node->ns->prefix : default_namespace;
    char *tag_name = g_strdup_printf("%s:%s", prefix, node->name);

    dom_implementation_create_ns_element(prefix, node->name, document, &error);
    // document.implementation().createElementNS(tag_name, document, &error);
    // document.implementation().createAttributeNS(attr_name, document, &error);
    // for each xml::attributes : element.addAttributeNS(attr);
    GHashTable *names = dom_document_get_tag_names(document);
    //g_print("tag_name = %s\n", tag_name);
    GType type = g_hash_table_lookup(names, tag_name);
    g_free(tag_name);

    if (!type) {
        // %s:, node->ns->prefix
        g_print("%s not implemented tag\n", node->name);
        type = DOM_TYPE_ELEMENT;
    }

        dom_element = g_object_new (type, NULL);
        //DOM_NODE(svg_element)->document = document;
        //dom_node_xml_new(element, tag);
//        xmlNs *ns = dom_document_search_ns(document, prefix);
//        xmlNode *xml = xmlNewNode(ns, BAD_CAST node->name);
//        DOM_NODE(svg_element)->xml      = xml;
//        xml->doc = document->xml;
//        xml->_private = svg_element;
        dom_node_set_xml(DOM_NODE(dom_element), node);


/*
        DomElement *svg_element = dom_document_create_element(DOM_NODE(svg_parent)->document, node);
        svg_element = svg_element_new_from_xml(type, node);
        DOM_NODE(svg_element)->document    = DOM_NODE(svg_parent)->document;
        dom_node_init_from_xml(DOM_NODE(svg_element), node);
*/
        //dom_element_append(DOM_ELEMENT(svg_parent), DOM_ELEMENT(svg_element));

        /*svg_element_attach_xml(svg_parent, svg_element);
        svg_element_attach_render(svg_parent, svg_element);*/


    return dom_element;

/*
    if (noeud->type == XML_ELEMENT_NODE) {
        xmlChar *chemin = xmlGetNodePath(noeud);
        if (noeud->children != NULL && noeud->children->type == XML_TEXT_NODE) {
            xmlChar *contenu = xmlNodeGetContent(noeud);
            printf("%s -> %s\n", chemin, contenu);
            xmlFree(contenu);
        } else {
            printf("%s\n", chemin);
        }
        xmlFree(chemin);
    }
*/
}

void dom_parser_parse(xmlNodePtr xml_node, fct_parcours_t f, DomElement* dom_parent) {
    xmlNodePtr node;
    xmlChar   *node_ns_prefix;


    for (node = xml_node; node != NULL; node = node->next) {
        switch (node->type)
        {
        case XML_ELEMENT_NODE:
        {
            DomElement* dom_element = f(node, dom_parent);
            if (dom_element && node->children != NULL) {
                dom_parser_parse(node->children, f, dom_element);
            }
        }
        break;
        default:
            break;
        }
    }
}

#include <libcroco/libcroco.h>
#include <libxml/tree.h>
#include <libxml/xpath.h>

/*SvgDocument* dom_parser_load_css(gchar* filename)
{

}*/
static void /*CssDocument*/ dom_parser_load_external_ressources(xmlNode* doc)
{

}

#include <gmodule.h>
//#if ENABLE_SVG MODULE|PLUGIN|EXTENSION
#include "libsvg/svg.h"
#include "libsvg/svg-types.h"
#include "libsvg/svg-implementation.h"
//#endif


static void dom_parser_load_implementation(DomDocument *document)
{
    xmlNode* doc = document->xml;
    xmlDoc  *doc_ptr;
    xmlNode *node;

    for (node = doc->children; node != NULL; node = node->next) {
        switch (node->type)
        {
        case XML_DTD_NODE:
        {
            g_print("XML_DTD_NODE: %s\n", node->name);
            //#if ENABLE_SVG EXTENSION|MODULE|PLUGIN
            if (strcmp("svg", node->name)==0) {
                /*
                SvgImplementation *implementation = svg_implementation_new();
                document->implementation = implementation;
                break;
                */
            }
            //#endif

            //#if ENABLE_SMIL EXTENSION|MODULE|PLUGIN
            if (strcmp("smil", node->name)==0) {

            }
            //#endif

            // load_module('libxml-svg').implementation
            gchar *plugin_dom = "domplugin-svg";
            GModule *module_svg = g_module_open (plugin_dom, G_MODULE_BIND_LAZY);
            if (module_svg) {
                g_print ("searching symbol...\n");
            } else {
                g_print ("error: %s\n", g_module_error ());
                //return 1;
            }

        }
        /* XML_DTD_NODE */
        default:
            break;
        }
    }
}

static void /*CssDocument*/ dom_parser_load_css(xmlNode* doc, GList **stylesheet_list/*CRStyleSheet **stylesheet*/)
{
    xmlDoc  *doc_ptr;
    xmlNode *node;

    for (node = doc->children; node != NULL; node = node->next) {
        switch (node->type)
        {
        case XML_ELEMENT_NODE:
        {
            if (xmlStrcmp(node->name, BAD_CAST "svg")==0
             || xmlStrcmp(node->name, BAD_CAST "g")==0
             || xmlStrcmp(node->name, BAD_CAST "defs")==0 ) {
                dom_parser_load_css(node, stylesheet_list);
            } else if (xmlStrcmp(node->name, BAD_CAST "style")==0) {
                xmlChar *buf = xmlNodeGetContent(node);
                CRStyleSheet *cr_stylesheet = NULL;
                enum CRStatus status = cr_om_parser_simply_parse_buf(buf, xmlStrlen(buf), CR_ASCII, &cr_stylesheet);
                if (status==CR_OK) {
                    *stylesheet_list = g_list_append(*stylesheet_list, cr_stylesheet);
                } else {
                    g_print("Error: CRStatus");
                }
                xmlFree(buf);
            }
        }
        break;
        case XML_PI_NODE:
        {
            if (strcmp(BAD_CAST node->name, "xml-stylesheet")==0) {
                xmlChar* attributes = xmlNodeGetContent(node);
                xmlChar* buffer = g_new(xmlChar, xmlStrlen(attributes) + 33);
                g_sprintf(buffer, "<?xml version=\"1.0\"?><attrs %s />", attributes);
                xmlDoc* myDoc = xmlParseMemory(buffer, xmlStrlen(buffer));
                xmlNode* myNode = xmlDocGetRootElement(myDoc);
                xmlChar* href = xmlGetProp(myNode, "href");
                if (href) {
                    doc_ptr = doc;
                    gchar* dirname = g_path_get_dirname (BAD_CAST doc_ptr->URL);
                    gchar* filename = g_build_filename(dirname, href, NULL);

                    CRStyleSheet *cr_stylesheet = NULL;
                    enum CRStatus status = cr_om_parser_simply_parse_file(filename /*sheet*/,
                                                                          CR_ASCII /*the encoding*/,
                                                                          &cr_stylesheet);
                    if (status==CR_OK) {
                        *stylesheet_list = g_list_append(*stylesheet_list, cr_stylesheet);
                    } else {
                        g_print("Error: CRStatus");
                    }

                    g_free(dirname);
                    g_free(filename);
                    g_free(href);
                }
                xmlFreeDoc(myDoc);
                g_free(buffer);
                g_free(attributes);
            }
        }
        break;
        case XML_DTD_NODE:
        {
            g_print("XML_DTD_NODE: %s\n", node->name);
        }
        /* XML_DTD_NODE */
        default:
            break;
        }
    }
}

DomDocument*
dom_document_load (DomDocument *document, const gchar *uri)
{
    xmlDoc *doc;
    xmlNode *root;

    // Ouverture du fichier XML
    doc = xmlParseFile(uri);
    if (doc == NULL) {
        fprintf(stderr, "Document XML invalide\n");
        return NULL;
    }

    // check if DomDocument xml is set
    dom_document_set_xml(document, doc);

    // Récupération de la racine
    root = xmlDocGetRootElement(doc);
    if (root == NULL) {
        fprintf(stderr, "Document XML vierge\n");
        xmlFreeDoc(doc);
        return NULL;
    }
    //dom_parser_load_implementation(doc, );
    dom_parser_load_implementation(document);
    dom_parser_load_css(doc, &document->stylesheet_list);


    DomQualifiedName tag_root;
    dom_document_tag_root(document, &tag_root);
    //dom_qualified_name_to_string(tag_root, NULL);
    char *tag_name = g_strdup_printf("%s:%s", tag_root.prefix, tag_root.name);

    GHashTable *names = dom_document_get_tag_names(document);
    //g_print("tag_name = %s\n", tag_name);
    GType type = g_hash_table_lookup(names, tag_name);
    if (!type)
        type = DOM_TYPE_ELEMENT;

    DomElement* dom_root = g_object_new(type, NULL);
    // SVGDocument.createElementSvg(document);
    // document.implementation().createElementNs("svg:svg", document);
    // document.implementation().createAttributeNs("xmlns", "org/2000/svg");
    // document.implementation().createAttributeNs("xmlns:xlink", "org/1999/xlink");
    dom_node_set_xml(DOM_NODE(dom_root), root);

    dom_parser_parse(root->children, dom_parser_build, dom_root);

    g_free(tag_name);

    return document;
}
