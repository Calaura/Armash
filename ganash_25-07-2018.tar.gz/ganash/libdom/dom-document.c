/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-document.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <libxml/tree.h>
#include <libxml/xpath.h>

#include <libcroco/libcroco.h>

#include <liblog/log.h>
#include <librenderer/renderer-enums.h>

#include <glib-object.h>
#include "dom-types.h"
#include "dom-enums.h"
#include "dom-node.h"
#include "dom-implementation.h"
#include "dom-document-type.h"
#include "dom-document.h"
#include "dom-element.h"
#include "dom-exception.h"
#include "dom-qualified-name.h"


static void dom_document_class_init(DomDocumentClass *klass);
static void dom_document_init(DomDocument *gobject);

static void              dom_document_log_interface_init (LogDumpInterface *iface);
static LogDumpInterface *dom_document_log_parent_interface = NULL;

G_DEFINE_TYPE_WITH_CODE (DomDocument, dom_document, G_TYPE_OBJECT,
                         LOG_IMPLEMENT_INTERFACE_DUMP(dom_document_log_interface_init))


/* Debugger interface                                                         */
/* ************************************************************************** */
#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
static gchar*
dom_document_children_dump(DomDocument* document, LogDumpOptions *options)
{
#   define TAB "%s"
#   define GLUE "%c"


    char *content = g_strdup_printf("");
    char *tmp = content;

/*
    gchar  glue = ' ';
    gchar *ind  = g_strdup("");
    gchar *ind2 = g_strdup_printf(TAB""TAB, indent, LOG_DUMP_TAB);
    gchar *tab  = g_strdup("");


    // Use indentation
    if (flags & LOG_DUMP_INDENT_FLAG) {
        ind = g_strdup_printf("\n"TAB""TAB, indent, LOG_DUMP_TAB);
        tab = g_strdup_printf(TAB, indent);
    }

    xmlNode *last = document->xml->last;
    xmlNode *child;
    if (last && last->_private)
        for(child = dom_node_get_children(DOM_NODE(last->_private)); child; child = child->next) {
            DomNode *node = DOM_NODE(child->_private);
            if (node) {
                gchar *child = log_dump_to_string(node, options);
                content = g_strdup_printf("%s"GLUE""TAB"%s", content, glue, "\n", child);
                g_free(child);

                //content = g_strdup_printf("%s"GLUE""TAB"[%s{N/A}]", content, glue, ind, G_OBJECT_TYPE_NAME(node));
                g_free(tmp);
                tmp = content;
                glue = ',';
            } else if (child->type == XML_ELEMENT_NODE) {
                content = g_strdup_printf("%s"GLUE""TAB"[%s{N/A}]", content, glue, ind, child->name);
                g_free(tmp);
                tmp = content;
                glue = ',';
            }
        }

    g_free(ind);
*/
    return content;
}


static gchar*
dom_document_dump(DomDocument *document, LogDumpOptions *options)
{
#   define PLACE_HOLDER "%%s"
#   define EOL  "%s"
#   define TAB  "%s"
#   define GLUE "%s"
#   define TYPE_NAME "%s"

    // Use indentation
    gchar *indent;
    gchar *indent_;
    gchar *new_line;
    gchar *endl;
    gchar *glue_ = g_strdup("");
    gchar *glue = glue_;

    if (options->flags & LOG_DUMP_INDENT_FLAG) {
        size_t num_char = strlen(options->config->indent);
        size_t depth = num_char*options->depth +1;
        size_t depth_ = num_char*(options->depth+1)+1;
        indent = g_new(gchar, depth);
        memset(indent, options->config->indent[0], depth);
        indent_ = g_new(gchar, depth_);
        memset(indent_, options->config->indent[0], depth_);
        indent[depth-1] = '\0';
        indent_[depth_-1] = '\0';


        if (options->newl) {
            new_line = g_strdup_printf(EOL""TAB, options->config->endl, indent);
        } else {
            new_line = g_strdup("");
        }
        endl = g_strdup(options->config->endl);
    } else {
        indent   = g_strdup("");
        indent_  = g_strdup("");
        new_line = g_strdup("");
        endl     = g_strdup("");
    }

    gchar *content = g_strdup("");
    gchar *tmp = content;

    if (options->flags & DOM_DUMP_ATTRIBUTES_FLAG) {
        //document->xml->URL
        content = g_strdup_printf("%s"GLUE""EOL""TAB"version: %s", content, glue, endl, indent_, BAD_CAST document->xml->version);
        g_free(tmp);
        tmp = content;
        glue = options->config->glue;
    }

    if (options->flags & DOM_DUMP_ATTRIBUTES_FLAG) {
        content = g_strdup_printf("%s"GLUE""EOL""TAB"url: %s", content, glue, endl, indent_, BAD_CAST document->xml->URL);
        g_free(tmp);
        tmp = content;
        glue = options->config->glue;
    }

    if (options->flags & DOM_DUMP_RECURSIVE_FLAG) {
        DomNode *root = dom_document_get_root(document);
        LogDumpOptions opt = *options;
        opt.depth++;
        opt.newl = 0;
        char *str_root = log_dump_to_string(LOG_DUMP(root), &opt);
        content = g_strdup_printf("%s"GLUE""EOL""TAB"root: %s", content, glue, endl, indent_, str_root);
        g_free(str_root);
        g_free(tmp);
        tmp = content;
    }

    gchar *dump;
    if (options->flags & DOM_DUMP_POINTER_FLAG) {
        dump = g_strdup_printf(TAB"["TYPE_NAME"@%p{%s"PLACE_HOLDER""EOL""TAB"}]", new_line, G_OBJECT_TYPE_NAME(document), document, content, endl, indent);
    } else {
        dump = g_strdup_printf(TAB"["TYPE_NAME"{%s"PLACE_HOLDER""EOL""TAB"}]", new_line, G_OBJECT_TYPE_NAME(document), content, endl, indent);
    }
    g_free(content);


    return dump;
}

static void
dom_document_log_interface_init (LogDumpInterface *iface)
{
    dom_document_log_parent_interface = g_type_interface_peek_parent (iface);
    iface->to_string = dom_document_dump;
}
#endif

/* ******** interface                                                         */
/* ************************************************************************** */

static GHashTable* dom_tag_names = NULL;

GHashTable*
dom_document_default_get_tag_names(void)
{
    if (dom_tag_names) {
        return dom_tag_names;
    }

    dom_tag_names = g_hash_table_new (g_str_hash, g_str_equal);

    //g_hash_table_insert (dom_tag_names, "", GINT_TO_POINTER (DOM_TYPE_ELEMENT));

    return dom_tag_names;
}

static void
dom_document_init (DomDocument *document)
{
    // register all namespace associated white DOM_QUALIFIED_NAME(preffix, name)
    document->doctype = NULL;
    document->implementation = NULL;

    document->stylesheet_list = NULL;

    document->instance_count = 0;
    document->remain_id = NULL;
}

static void
dom_document_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */
    DomDocument *document = DOM_DOCUMENT(object);

    G_OBJECT_CLASS (dom_document_parent_class)->finalize (object);
}

static DomQualifiedName dom_tag_root = {"svg", "root"};

static void
dom_document_default_tag_root(DomQualifiedName *tag)
{
    tag->name   = g_strdup(dom_tag_root.name);
    tag->prefix = g_strdup(dom_tag_root.prefix);
}

static char *dom_default_namespace = "xml";
static void
dom_document_default_namespace(char **prefix)
{
    *prefix = dom_default_namespace;
}

static DomNamespace dom_default_namespaces[] = {
    {"http://www.w3.org/2000/xmlns/", {"xmlns", "xml"},   "http://www.w3.org/2000/namespace"},
    //{"http://www.w3.org/2000/xmlns/", {"xmlns", "svg"},   "http://www.w3.org/2000/svg"},
    //{"http://www.w3.org/2000/xmlns/", {"xmlns", "xlink"}, "http://www.w3.org/2000/xlink"},
    NULL
};

static void
dom_document_default_namespaces(DomNamespace** namespaces)
{
    *namespaces = dom_default_namespaces;
}


static void
dom_document_class_init(DomDocumentClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = dom_document_finalize;

    klass->get_tag_names      = dom_document_default_get_tag_names;
    klass->tag_root           = dom_document_default_tag_root;
    klass->default_namespace  = dom_document_default_namespace;
    klass->default_namespaces = dom_document_default_namespaces;

//    dom_document_parent_class = g_type_class_peek_parent (klass);
}

/* virtual */
GHashTable*
dom_document_get_tag_names(DomDocument *document)
{
    return DOM_DOCUMENT_GET_CLASS(document)->get_tag_names();
}

void
dom_document_tag_root(DomDocument *document, DomQualifiedName *tag)
{
    DOM_DOCUMENT_GET_CLASS(document)->tag_root(tag);
}

void
dom_document_namespace(DomDocument *document, char **default_namespace)
{
    DOM_DOCUMENT_GET_CLASS(document)->default_namespace(default_namespace);
}

void
dom_document_namespaces(DomDocument *document, DomNamespace** namespaces)
{
    DOM_DOCUMENT_GET_CLASS(document)->default_namespaces(namespaces);
}

xmlDoc*
dom_document_xml_new (void)
{
    const xmlChar *version = XML_DEFAULT_VERSION;
    xmlDoc *xml = xmlNewDoc(version);
    xml->standalone = 1;// if add refs, set to 0

    return xml;
}


void
dom_document_set_xml (DomDocument *document, xmlDoc *xml)
{
    document->xml = xml;
    xml->_private = document;
}


DomDocument*
dom_document_new (void)
{
    DomDocument *document = g_object_new (DOM_TYPE_DOCUMENT, NULL);

    /*DomQualifiedName tag_root;
    dom_document_tag_root(document, &tag_root);
    GHashTable *tag_names = dom_document_get_tag_names(document);
    GType type = (GType) g_hash_table_lookup (tag_names, tag_root.name);
    if (!type)
        type = dom_element_get_type();
    g_assert(type);
    DomNode *root = g_object_new (type, NULL);
    //dom_node_set_xml(root, );
    //root->document = document;

    xmlNode *root_xml = xmlNewNode(NULL, BAD_CAST tag_root.name);
    dom_node_set_xml(root, root_xml);
    root_xml->doc = document->xml;
    root_xml->_private = root;
    root->xml  = root_xml;

    xmlNs *default_ns = NULL;
    int length = G_N_ELEMENTS(dom_default_namespaces)-1;
    DomNamespace *namespaces;
    dom_document_namespaces(document, &namespaces);
    int i;
    for (i=0; i<length; i++) {
        xmlNs *ns = NULL;
        DomNamespace *decl = &namespaces[i];
        if (g_strcmp0(decl->name.name, dom_default_namespace)==0) {
            ns = xmlNewNs(root_xml, decl->href, NULL);
            default_ns = ns;
        } else {
            ns = xmlNewNs(root_xml, decl->href, decl->name.name);
        }
        dom_document_register_ns(document, ns);
    }

    xmlSetNs(root_xml, default_ns);
    xmlDocSetRootElement(document->xml, root_xml);

    document->root = root;*/


    return document;
}

/*
DomDocument*
dom_document_newww (void)
{
    DomDocument *document = g_object_new (DOM_TYPE_DOCUMENT, NULL);
    dom_document_xml_new(document);// internal data
    xmlDoc *xml_doc = document->xml;

    xmlNs *ns;
    guint length = G_N_ELEMENTS(dom_default_namespaces)-1;
    int i;
    for (i=0; i<length; i++) {
        DomNamespace *ns = &dom_default_namespaces[i];

        if (g_strcmp0(ns->name.name, dom_default_namespace)==0) {
            xmlNs *xml_ns;
            xml_ns = xmlNewNs(NULL,
                              ns->href,
                              NULL);
            xml_ns->context = xml_doc;
            dom_document_register_ns(document, xml_ns);
        } else {
            xmlNs *xml_ns = xmlNewNs(NULL,
                                     ns->href,
                                     ns->name.name);
            xml_ns->context = xml_doc;
            dom_document_register_ns(document, xml_ns);
        }
    }
//    for(ns = document->ns; ns; ns = ns->next) {
//        g_print("[NS{ctx: %p, prefix: %s, href: %s}]\n", ns->context, ns->prefix, ns->href);
//    }

    DomQualifiedName tag;
    dom_document_tag_root(document, &tag);
    DomElement * root = dom_document_create_element(document, &tag);
    dom_document_set_root(document, root);
    ns = dom_document_search_ns(document, "svg");
    xmlSetNs(DOM_NODE(root)->xml, ns);

    for (i=0; i<length; i++) {
        DomNamespace *ns = &dom_default_namespaces[i];
        xmlNs *xml_ns = dom_document_search_ns(document, ns->name.name);
        //xmlSetNs(DOM_NODE(root)->xml, xml_ns);
        if (xml_ns->prefix) {
            xmlNs *_ns = xmlNewNs(NULL, ns->uri, "xmlns");
            //xmlNs *_ns = xml_ns;
            xmlSetNsProp(DOM_NODE(root)->xml, _ns, ns->name.name, ns->href);
        } else {
            xmlNs *_ns = xmlNewNs(NULL, ns->uri, NULL);
            //xmlNs *_ns = xml_ns;
            xmlSetNsProp(DOM_NODE(root)->xml, _ns, "xmlns", ns->href);
        }
    }

    return document;
}
*/

void
dom_document_free (DomDocument* document)
{
    g_object_unref(document);
}


static xmlNs*
dom_document_ns_new(DomDocument *document, char *namespace_uri, char *prefix, char *href) {
    // TODO check if prefix is valid in namespace_uri

    /*
     * Allocate a new Namespace and fill the fields.
     */
    xmlNs *ns = g_new0(xmlNs, 1);
    ns->type = XML_LOCAL_NAMESPACE;

    ns->href = g_strdup(href); //XML_XML_NAMESPACE
    ns->prefix = g_strdup(prefix);// "xml"

    return ns;
}

static int
dom_document_ns_length(DomDocument *document) {
    int length = 0;
    /*xmlNs *ns  = NULL;
    for(ns = document->ns; ns; ns = ns->next) {
        length++;
    }*/

    return length;
}

static int
dom_document_ns_append(DomDocument *document, char *prefix, char *href) {
    return 0;
}

xmlNs*
dom_document_search_ns(DomDocument *document, char *prefix) {
    xmlNs  *ns      = NULL;
    char *default_namespace;
    /*dom_document_default_namespace(&default_namespace);
    if (g_strcmp0(prefix, default_namespace)==0)
        prefix = NULL;

    for(ns = document->ns; ns; ns = ns->next) {
        if (g_strcmp0(ns->prefix, prefix)==0) {
            return ns;
        }
    }*/

    return NULL;
}

xmlNs*
dom_document_search_ns_by_href(DomDocument *document, char *href) {
    xmlNs  *ns      = NULL;
    /*for(ns = document->ns; ns; ns = ns->next) {
        if (g_strcmp0(ns->href, href)==0) {
            return ns;
        }
    }*/
    return NULL;
}

void
dom_document_register_ns(DomDocument *document, xmlNs *ns)
{
    xmlNs  *oldNs  = NULL;
    xmlNs  *lastNs = NULL;


    ((xmlNode*)document)->ns->prefix;
    ((xmlNode*)document)->ns->href;
    // do not duplicate
    /*for(oldNs = document->ns; oldNs; oldNs = oldNs->next) {
        if (g_strcmp0(oldNs->prefix, ns->prefix)==0) {
            return;
        }
        lastNs = oldNs;
    }

    if (document->ns) {
        lastNs->next = ns;
    } else {
        document->ns = ns;
    }*/

}

DomDocument*
dom_document_open (char *filename)
{
    //xmlDoc *doc = xmlReadFile(uri);// file systee

}

/*DomDocument*
dom_document_load (char *uri)
{
    xmlDoc *xml_doc;

    //xml_doc = xmlReadFile(uri);// network
    char *filename = uri;
    xml_doc = xmlParseFile(filename);// filesysteme
    if (xml_doc == NULL) {
        fprintf(stderr, "Document XML invalide\n");
        return NULL;
    }

    DomDocument *document = g_object_new (dom_document_get_type (), NULL);
    document->xml = xml_doc;
    // dtd = xmlCreateIntSubset(doc, BAD_CAST "root", NULL, BAD_CAST "tree2.dtd");

    return document;
}*/

void
dom_document_save_as(DomDocument *document,
                     const char *filename,
                     const char *encoding,
                     int format)
{
    xmlSaveFormatFileEnc(filename, document->xml, encoding, format);
}

DomElement*
dom_document_create_element(DomDocument *document, DomQualifiedName *tag/*, xmlNode *content*/)
{
    DomNode *element;
    xmlDoc *doc = document->xml;

    //element = g_object_new (DOM_TYPE_ELEMENT, NULL);
    //dom_node_set_document(DOM_NODE(element), document);
    //element = dom_element_new(document);


    GHashTable *tag_names = dom_document_get_tag_names(document);

    char *tag_name = dom_qualified_name_to_string(tag, NULL);
    GType type = (GType) g_hash_table_lookup (tag_names, tag_name);
    if (!type) {
        g_print("<%s> not a registered tag. Assume generic type\n", tag_name);
        type = dom_element_get_type();
    }
    element = g_object_new (type, NULL);
    xmlNode *xml = dom_document_create_xml(document, tag);
    dom_node_set_xml(element, xml);


    /*if (type) {
        element = g_object_new (type, NULL);
        element->document = document;
    } else {
        g_print("<%s> not a registered tag. Assume generic type\n", tag_name);
        element = g_object_new (DOM_TYPE_ELEMENT, NULL);
        element->document = document;
//        dom_node_xml_new(element, tag);
    }*/
    g_free(tag_name);

    return element;
}
DomElement*
dom_document_create_element_ns(DomDocument *document, char *namespace_uri, DomQualifiedName *tag)
{
    DomNode *element;
    /*xmlDoc *doc = document->xml;
    xmlNs *ns = NULL;
    GHashTable *tag_names = dom_document_get_tag_names(document);

    GType type = (GType) g_hash_table_lookup (tag_names, tag->name);


    if (type) {
        element = g_object_new (type, NULL);
    } else {
        element = g_object_new (DOM_TYPE_ELEMENT, NULL);
    }
    element->document = document;
    dom_node_xml_new(element, tag);*/

    /*if (namespace_uri) {
        xmlNs *ns = xmlNewNs(element->xml,
                             namespace_uri,
                             NULL);
    }*/
    /*if (tag->prefix) {
        xmlNs *ns = xmlNewNs(element->xml,
                             namespace_uri,
                             tag->prefix);
    }*/

    /*if (tag->prefix && tag->prefix[0]!='\0') {
        ns = xmlNewNs(element->xml,
                      namespace_uri,
                      tag->prefix);
        xmlSetNs(element->xml, ns);
    }*/

    /*xmlNs *self_ns = xmlNewNs(element->xml,
                         namespace_uri,
                         tag->prefix);
    element->xml->ns = self_ns;*/
    //xmlSetNs(element->xml, ns);

    /*if (tag->prefix) {
        xmlNs *self_ns = xmlSearchNsByHref(element->xml->doc, element->xml, tag->prefix);
        g_print("Found:%p-%s\n", self_ns, tag->prefix);
        //xmlSetNs(element->xml, ns);
    }*/


    return element;
}

void
dom_document_set_root(DomDocument *document, DomNode *root)
{
    /*if (root->xml->doc == document->xml) {
        xmlDocSetRootElement(document->xml, root->xml);
    } else {
        g_error("%s: Not implemented; document swap\n", G_STRFUNC);
    }*/
}

DomNode*
dom_document_get_root(DomDocument *document)
{
    return DOM_NODE(document->xml->last->_private);
}

/*
 * 20 cuisine - 25 voiture
 *
 */

gboolean
dom_document_get_element_by_id(DomDocument *document, char *id, DomElement **element)
{
    gboolean found = FALSE;
    xmlDoc *doc = document->xml;
    xmlXPathContext *xpath;
    xmlXPathObject  *xobject;
    xpath = xmlXPathNewContext(doc);
    if (xpath) {
        gchar *path = g_strdup_printf("//*[@id='%s']", id);// FIXME namespace xml:id or svg:id
        xobject = xmlXPathEvalExpression(path, xpath);
        g_free(path);
        if (xobject && xobject->nodesetval && xobject->nodesetval->nodeNr>0) {
            xmlNode *node = xobject->nodesetval->nodeTab[0];
            *element = node->_private;
            found = TRUE;
            xmlXPathFreeObject(xobject);
        }
        xmlXPathFreeContext(xpath);
    }

    return found;
}

guint
dom_document_instance_count_new(DomDocument *document)
{
    guint id = 0;
    if (document->instance_count<G_MAXUINT) {
        document->instance_count++;
        id = document->instance_count;
    } else if (g_slist_length(document->remain_id)) {
        GSList *ids = g_slist_last(document->remain_id);
        id = (guint) ids->data;
        document->remain_id = g_slist_remove(document->remain_id, id);
    } else {
        // error: out of Memory
    }

    return id;
}

void
dom_document_instance_count_free(DomDocument *document, guint id)
{
    document->remain_id = g_slist_append(document->remain_id, (gpointer) id);
}

DomDocumentType*
dom_document_get_doctype(DomDocument *document)
{
    return document->doctype;
}
