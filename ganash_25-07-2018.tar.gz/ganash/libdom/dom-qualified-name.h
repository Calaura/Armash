/*
 * dom-qualified-name.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DOM_QUALIFIED_NAME_H__
#define __DOM_QUALIFIED_NAME_H__



G_BEGIN_DECLS

struct _DomQualifiedName {
    gchar *prefix;
    gchar *name;
};

struct _DomNamespace {
    char *uri;
    DomQualifiedName name;
    char *href;
};

#define DOM_TAG_NAME(prefix, name) prefix":"name
#define DOM_QUALIFIED_NAME(prefix, name) ((DomQualifiedName){prefix, name})

gboolean  dom_qualified_name_equ(DomQualifiedName *attribute, DomQualifiedName *qualified_name);
gboolean  dom_parser_parse_qualified_name(DomQualifiedName *attribute, char *str, char *end);
char     *dom_qualified_name_to_string(DomQualifiedName *name, char *default_prefix);

//dom_qualified_ns_new();
//dom_qualified_ns_append();
//dom_qualified_ns_remove();

//xmlNs *dom_namespace_list_new();
//dom_namespace_list_append();
//dom_namespace_list_remove();

G_END_DECLS

#endif /* __DOM_QUALIFIED_NAME_H__ */
