/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-event-listener-map.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>
#include "dom-types.h"
#include "dom-event-listener.h"
#include "dom-event-listener-map.h"


DomEventListenerMap*
dom_event_listener_map_new (void)
{
    GHashTable *map = 0;//g_hash_table_new_full();
    return (DomEventListenerMap*) map;
}

gboolean
dom_event_listener_map_is_empty(DomEventListenerMap* map)
{
    g_assert(map);
    return g_hash_table_size((GHashTable *) map) > 0;
}

gboolean
dom_event_listener_map_contains(DomEventListenerMap* map, gchar *eventType)
{
    g_assert(map);
    g_assert(eventType);

    DomEventListenerVector* vector = g_hash_table_lookup((GHashTable*) map, eventType);
    return vector != NULL;
}
/*
gboolean
dom_event_listener_map_contains_capturing(DomEventListenerMap* map, gchar *eventType)
{
    g_assert(map);
    g_assert(eventType);

    GHashTableIter iter;
    gpointer key, value;
    g_hash_table_iter_init (&iter, (GHashTable*) map);
    while (g_hash_table_iter_next (&iter, &key, &value)) {
        if (g_ascii_strcasecmp(key, eventType)) {
            GArray *vector = (GArray*) value;
            int j;
            for (j = 0; j < vector->len; ++j) {
                DomEventListener listener = g_array_index(vector, DomEventListener, j);
                if (listener.useCapture)
                    return TRUE;
            }
        }
    }
    return FALSE;
}
*/
void                    dom_event_listener_map_clear(DomEventListenerMap* map);
GArray/*<GString>*/    *dom_event_listener_map_event_types(DomEventListenerMap* map);

gboolean                dom_event_listener_map_add(DomEventListenerMap* map, gchar *eventType, DomEventListener *listener, gboolean useCapture);
gboolean                dom_event_listener_map_remove(DomEventListenerMap* map, gchar *eventType, DomEventListener *listener, gboolean useCapture, size_t* indexOfRemovedListener);
DomEventListenerVector *dom_event_listener_map_find(DomEventListenerMap* map, gchar *eventType);

