/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-document.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DOM_DOCUMENT_H__
#define __DOM_DOCUMENT_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define DOM_DOCUMENT_CAST(obj)       ((DomDocument*)obj)
#define DOM_TYPE_DOCUMENT            (dom_document_get_type())
#define DOM_DOCUMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DOM_TYPE_DOCUMENT, DomDocument))
#define DOM_DOCUMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DOM_TYPE_DOCUMENT, DomDocumentClass))
#define DOM_IS_DOCUMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DOM_TYPE_DOCUMENT))
#define DOM_IS_DOCUMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DOM_TYPE_DOCUMENT))
#define DOM_DOCUMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DOM_TYPE_DOCUMENT, DomDocumentClass))

typedef struct _DomDocumentClass DomDocumentClass;

/*typedef struct _CssStyleSheetList {
    CRStyleSheet *data;
    CRStyleSheet *next;
    CRStyleSheet *prev;
} CssStyleSheetList;*/

struct _DomDocument {
	GObject parent_instance;

    xmlDoc *xml;

    /*GList  *xml_dtd;*/
    /*Chaque DOMDocument a un attribut doctype dont la valeur est soit NULL, soit un objet DOMDocumentType*/
    DomDocumentType *doctype;
    DomImplementation *implementation;// XlinkAttribute, Script, Animation,

    //GList  *css_stylesheets;/*GList<CRStyleSheet> **/
    GList *stylesheet_list;
    //RefPtr<CSSStyleSheet> m_elementSheet;

    //DomElement* root;
    /*
      svg:rect
      svg:rect

     */
    /*
    Document* parentDocument() const;
    Document& topDocument() const;

    ScriptRunner* scriptRunner() { return m_scriptRunner.get(); }

    HTMLScriptElement* currentScript() const { return !m_currentScriptStack.isEmpty() ? m_currentScriptStack.last().get() : 0; }
    void pushCurrentScript(PassRefPtr<HTMLScriptElement>);
    void popCurrentScript();

    std::unique_ptr<ScriptRunner> m_scriptRunner;

    Vector<RefPtr<HTMLScriptElement>> m_currentScriptStack;

    */

    /*< private >*/

    // get_instance_id_by_type(SvgElement *elt);
    guint   instance_count;
    GSList* remain_id;// when a element is freed, remain his id to be reuse
};

struct _DomDocumentClass {
	GObjectClass parent_class;

    /*< protected >*/
    void               (*tag_root)           (DomQualifiedName *tag);
    void               (*default_namespace)  (DomNamespace *tag);
    void               (*default_namespaces) (DomNamespace *tag);

    GHashTable*        (*get_tag_names)      (void);
};

GType dom_document_get_type();
DomDocument *dom_document_new();
void         dom_document_register_ns(DomDocument *document, xmlNs *ns);
xmlNs       *dom_document_search_ns(DomDocument *document, char *prefix);
xmlNs       *dom_document_search_ns_by_href(DomDocument *document, char *href);

void         dom_document_namespace(DomDocument *document, char **default_namespace);
void         dom_document_namespaces(DomDocument *document, DomNamespace** namespaces);
GHashTable  *dom_document_get_tag_names(DomDocument *document);
//GHashTable  *dom_document_get_tag_codes(DomDocument *document);
//GHashTable  *dom_document_get_tag_instances(DomDocument *document, elt);
// dom_document_get_element_hash_tags();
// dom_document_get_element_hash_codes();
// dom_document_get_element_hash_instances();
void         dom_document_tag_root(DomDocument *document, DomQualifiedName *tag);

xmlDoc      *dom_document_xml_new(void);
void         dom_document_set_xml(DomDocument *document, xmlDoc *doc);

//DomDocument *dom_document_load(char *uri);
void         dom_document_save_as(DomDocument *document,
                                  const char *filename,
                                  const char *encoding,
                                  int format);
DomElement  *dom_document_create_element(DomDocument *document, DomQualifiedName *tag/*, xmlNode *content*/);
DomElement  *dom_document_create_element_ns(DomDocument *document, char *namespace_uri, DomQualifiedName *tag);
void         dom_document_set_root(DomDocument *document, DomNode *root);
DomNode     *dom_document_get_root(DomDocument *document);

gboolean     dom_document_get_element_by_id(DomDocument *document, char *id, DomElement **element);

//gboolean     dom_document_get_element_by_instance_count(DomDocument *document, guint id, DomElement **element);
guint        dom_document_instance_count_new(DomDocument *document);
void         dom_document_instance_count_free(DomDocument *document, guint id);

DomDocumentType* dom_document_get_doctype(DomDocument *document);

G_END_DECLS

#endif /* __DOM_DOCUMENT_H__ */

