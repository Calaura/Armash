/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-element.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <string.h>

#include <glib-object.h>
#include <libxml/tree.h>

#include <liblog/log.h>
#include <librenderer/renderer-enums.h>

#include "dom-types.h"
#include "dom-enums.h"
#include "dom-document.h"
#include "dom-qualified-name.h"
#include "dom-node.h"
#include "dom-element.h"

static DomNode* dom_element_clone (DomNode *node, gboolean deep);

static void dom_element_class_init(DomElementClass *klass);
static void dom_element_init(DomElement *gobject);

G_DEFINE_TYPE (DomElement, dom_element, DOM_TYPE_NODE)

/* Debugger interface                                                         */
/* ************************************************************************** */
#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
gchar*
dom_element_children_dump(xmlNode* children, LogDumpOptions *options)
{
#   define EOL "%s"
#   define TAB "%s"
#   define GLUE "%s"

    // Use indentation
    gchar *indent;
    gchar *indent_;
    gchar *new_line;
    gchar *endl;
    gchar *glue_ = g_strdup("");
    gchar *glue = glue_;

    if (options->flags & LOG_DUMP_INDENT_FLAG) {
        size_t num_char = strlen(options->config->indent);
        size_t depth = num_char*options->depth +1;
        size_t depth_ = num_char*(options->depth+1)+1;
        indent = g_new(gchar, depth);
        memset(indent, options->config->indent[0], depth);
        indent_ = g_new(gchar, depth_);
        memset(indent_, options->config->indent[0], depth_);
        indent[depth-1] = '\0';
        indent_[depth_-1] = '\0';


        if (options->newl) {
            new_line = g_strdup_printf(EOL""TAB, options->config->endl, indent);
        } else {
            new_line = g_strdup("");
        }
        endl = g_strdup(options->config->endl);
    } else {
        indent   = g_strdup("");
        indent_  = g_strdup("");
        new_line = g_strdup("");
        endl     = g_strdup("");
    }

    char *content = g_strdup_printf("");
    char *tmp = content;
    xmlNode *child;
    for(child = children; child; child = child->next) {
        DomNode *dom = DOM_NODE(child->_private);
        if (dom) {
            LogDumpOptions opt = *options;
            opt.depth++;
            opt.newl = 0;
            gchar *content_child = log_dump_to_string(LOG_DUMP(dom), &opt);
            content = g_strdup_printf("%s"GLUE""EOL""TAB"%s", content, glue, endl, indent_, content_child);
            g_free(content_child);
            g_free(tmp);
            tmp = content;
            glue = options->config->glue;
            options->has_content = 1;
        }/* else if (0 && child->type == XML_ELEMENT_NODE) {
            content = g_strdup_printf("%s"GLUE""TAB"[%s{N/A}]", content, glue, ind, child->name);
            g_free(tmp);
            tmp = content;
            glue = ',';
        }*/
    }

    g_free(glue_);
    g_free(indent);
    g_free(indent_);
    g_free(new_line);
    g_free(endl);

    return content;
}

static gchar*
dom_element_default_dump(DomNode *node, LogDumpOptions *options)
{
#   define PLACE_HOLDER "%%s"
#   define EOL "%s"
#   define TAB "%s"
#   define TYPE_NAME "%s"


    // Use indentation

    gchar *indent;
    gchar *indent_;
    gchar *indent__;
    gchar *new_line;
    gchar *endl;
    gchar *glue_ = g_strdup("");
    gchar *glue = glue_;

    if (options->flags & LOG_DUMP_INDENT_FLAG) {
        size_t num_char = strlen(options->config->indent);
        size_t depth = num_char*options->depth +1;
        size_t depth_ = num_char*(options->depth+1)+1;
        size_t depth__ = num_char*(options->depth+2)+1;
        indent = g_new(gchar, depth);
        memset(indent, options->config->indent[0], depth);
        indent_ = g_new(gchar, depth_);
        memset(indent_, options->config->indent[0], depth_);
        indent__ = g_new(gchar, depth__);
        memset(indent__, options->config->indent[0], depth__);
        indent[depth-1] = '\0';
        indent_[depth_-1] = '\0';
        indent__[depth__-1] = '\0';


        if (options->newl) {
            new_line = g_strdup_printf(EOL""TAB, options->config->endl, indent);
        } else {
            new_line = g_strdup("");
        }
        endl = g_strdup(options->config->endl);
    } else {
        indent   = g_strdup("");
        indent_  = g_strdup("");
        new_line = g_strdup("");
        endl     = g_strdup("");
    }

    gchar *content = g_strdup("");
    gchar *tmp = content;
    // TODO attribute/properties

    LogDumpOptions opt = *options;
    opt.depth++;
    opt.newl = 1;
    gchar *str = g_strdup("%s");
    gchar *tmp_str = str;
    if (options->flags & DOM_DUMP_RECURSIVE_FLAG) {
        gchar *children = dom_element_children_dump(dom_node_get_children(node), &opt);

        if (options->has_content) {
            glue = options->config->glue;
        }
        if (strlen(children)) {
            str = g_strdup_printf(GLUE""EOL""TAB"children:[%s"EOL""TAB"]"PLACE_HOLDER, glue, endl, indent_, children, endl, indent_);
            g_free(tmp_str);
            tmp_str = str;

            options->has_content = 1;
        }
        g_free(children);
    }

    content = DOM_NODE_CLASS(dom_element_parent_class)->dump(node, options);
    //g_print("%s\n", content);
    content = g_strdup_printf(content, str);
    g_free(tmp);
    g_free(tmp_str);
    tmp = content;


    g_free(glue_);
    g_free(indent);
    g_free(indent_);
    g_free(new_line);
    g_free(endl);

    return content;
}
#endif


static void
dom_element_init (DomElement *object)
{
    object->instance_id = 0;
}

static void
dom_element_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (dom_element_parent_class)->finalize (object);
}

static int
dom_element_init_from_xml(DomNode *node, xmlNode *xml)
{
    return DOM_NODE_CLASS(dom_element_parent_class)->init_from_xml(node, xml);
}

static void
dom_element_class_init(DomElementClass *klass)
{
	GObjectClass *gobject_class;
    DomNodeClass *node_class;

	gobject_class = (GObjectClass *) klass;
    node_class    = (DomNodeClass *) klass;

    node_class->clone         = dom_element_clone;
    node_class->init_from_xml = dom_element_init_from_xml;

#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
    node_class->dump          = dom_element_default_dump;
#endif


    gobject_class->finalize = dom_element_finalize;

//	dom_element_parent_class = g_type_class_peek_parent (klass);
}


DomElement*
dom_element_new (DomDocument *document, DomQualifiedName *tag)
{
    DomElement *element = g_object_new (dom_element_get_type (), NULL);
    DomNode    *node    = DOM_NODE(element);
    dom_document_create_xml(document, &DOM_QUALIFIED_NAME("xml", "element"));

    return element;
}
/*
void xml_namespace_link(xmlDoc *doc, xmlNs *ns) {

}

void xml_namespaces_link(xmlDoc *doc, xmlNs *ns) {

}

void xml_property_link(xmlAttr *node, xmlDoc *doc) {

}

void xml_properties_link(xmlNode *node, xmlDoc *doc) {

}

void dom_element_xml_link(xmlNode *node, xmlDoc *doc) {

    xmlAttr *attr;
    for(attr = node->properties; attr; attr = attr->next) {
        xmlNs *new_ns = dom_document_search_ns(document, attr->ns->prefix);
        attr->ns = new_ns;// todo rebuild namespace list: use xmlCopyNamespaceList
        xmlNode *item;
        for(item = attr->children; item; item = item->next) {
            item->doc = DOM_NODE(element)->document->xml;
        }
        attr->doc = DOM_NODE(element)->document->xml;
    }

}
*/

// dom_element_move(DomElement *src, DomElement* dest);
void dom_element_append(DomElement *element, DomElement* child)
{
    xmlNode *xml_element = DOM_NODE(element)->xml;
    xmlNode *xml_child   = DOM_NODE(child)->xml;
    xml_child->last = NULL;
    xml_child->prev = NULL;
    xml_child->next = NULL;
    xml_child->nsDef;

    xmlDoc *doc = xml_element->doc;
    DomNode *root = dom_document_get_root(dom_node_get_document(xml_element));
    /*if (ns) {
        g_print("ns.context = %p; ns.href: %s; ns.prefix: %s\n", ns->context, ns->href, ns->prefix);
    }*/
    /*xmlNs *node_ns;
    for (node_ns = xml_child->ns; node_ns; node_ns = node_ns->next) {
        g_print("%p, %s, %s\n", node_ns, node_ns->prefix, node_ns->href);
    }
    for (node_ns = xml_element->ns; node_ns; node_ns = node_ns->next) {
        g_print("%p, %s, %s\n", node_ns, node_ns->prefix, node_ns->href);
    }
    for (node_ns = root->xml->ns; node_ns; node_ns = node_ns->next) {
        g_print("%p, %s, %s\n", node_ns, node_ns->prefix, node_ns->href);
    }*/
    xml_child->ns = root->xml->ns;


    //xmlNs *_ns = xmlSearchNs(NULL, root->xml, "xml");

    if (xml_element->doc != xml_child->doc) {

        //xml_child->ns = xmlSearchNs(doc, root->xml, NULL);

        /*xmlNs *node_ns;
        for (node_ns = xml_child->ns; node_ns; node_ns = node_ns->next) {
            node_ns->context = doc;
        }
        xmlAttr *attr;
        for(attr = xml_child->properties; attr; attr = attr->next) {
            xmlNs *attr_ns;
            for (attr_ns = attr->ns; attr_ns; attr_ns = attr_ns->next) {
                attr_ns->context = doc;
            }

            xmlNode *item;
            for(item = attr->children; item; item = item->next) {
                item->doc = doc;
            }
            attr->doc = doc;
        }*/
    }


    xmlNode *xml = xmlAddChild(xml_element, xml_child);

    //dom_document_queue_render();

    //g_print("%p==%s\n", xml_child->prev, xml_child->next->name);


    /*DOM_NODE(element)->children = g_list_append(DOM_NODE(element)->children, (gpointer)child);
    DOM_NODE(child)->parent   = element;
    DOM_NODE(child)->document = DOM_NODE(element)->document;*/

    /*if (DOM_NODE(element)->xml->doc == DOM_NODE(child)->xml->doc) {
        xmlAddChild(DOM_NODE(element)->xml, DOM_NODE(child)->xml);
    } else {
        g_print("moving element...\n");
        DomDocument *document = DOM_NODE(child)->document;
        DomDocument *old_document = DOM_NODE(child)->document;
        DOM_NODE(child)->xml->doc = DOM_NODE(element)->xml->doc;
        xmlNode *node = DOM_NODE(child)->xml;


        xmlNs *new_ns = dom_document_search_ns(document, node->ns->prefix);
        xmlNs *node_ns;
        for (node_ns = node->ns; node_ns; node_ns = node_ns->next) {
            node_ns->context = DOM_NODE(element)->document->xml;
        }


        xmlAttr *attr;
        for(attr = node->properties; attr; attr = attr->next) {
            xmlNs *attr_ns;
            for (attr_ns = attr->ns; attr_ns; attr_ns = attr_ns->next) {
                attr_ns->context = DOM_NODE(element)->document->xml;
            }

            xmlNode *item;
            for(item = attr->children; item; item = item->next) {
                item->doc = DOM_NODE(element)->document->xml;
            }
            attr->doc = DOM_NODE(element)->document->xml;
        }

        // do it recursive...
        xmlAddChild(DOM_NODE(element)->xml, DOM_NODE(child)->xml);
    }*/
}

void dom_element_remove(DomElement *element, DomElement* child)
{
   /* DOM_NODE(element)->children = g_list_remove(DOM_NODE(element)->children, (gpointer)child);
    DOM_NODE(child)->parent = NULL;*/
    /*g_object_unref(child);*/
}

// FIXME: bug if document root not set: how to set namespace
void
dom_element_set_attribute(DomElement *element, DomQualifiedName *attr, char *value)
{
    /*
    DomDocument *document = DOM_NODE(element)->document;
    xmlDoc      *xml_doc  = document->xml;
    xmlNode     *xml      = DOM_NODE(element)->xml;
    xmlNs       *ns       = NULL;

    if (attr->prefix && attr->prefix[0]!='\0') {
        ns = xmlSearchNs(xml_doc, xml, attr->prefix);
        if (!ns || g_strcmp0(attr->prefix, "xml")==0) {
            char *default_namespace;
            char *prefix = attr->prefix;
            dom_document_namespace(DOM_NODE(element)->document, &default_namespace);
            if (g_strcmp0(prefix, default_namespace)==0)
                prefix = NULL;

            ns = dom_document_search_ns(DOM_NODE(element)->document, prefix);
            if (!ns) {
                if (g_strcmp0(attr->prefix, "xml")!=0) {
                    g_warning("namespace %s not found assume xmlns\n", attr->prefix);
                }
                xmlSetProp(DOM_NODE(element)->xml, BAD_CAST attr->name, BAD_CAST value);
                return;
            }
        }
        if (!ns) {
            g_print("namepsace \"%s\" unknow!\n", attr->prefix);
            return;
        }

        //xmlHasNsProp(xml, BAD_CAST attr->name, ns);

        xmlSetNsProp(DOM_NODE(element)->xml, ns, BAD_CAST attr->name, BAD_CAST value);
    } else {
        g_print("namespace attribute \"%s\" unknow!\n", attr->prefix);
        xmlSetProp(DOM_NODE(element)->xml, BAD_CAST attr->name, BAD_CAST value);
    }
    */
}

void
dom_element_set_attribute_ns(DomElement *element, char *namespace_uri, DomQualifiedName *qualified_name, char *value)
{
    /*
    g_error("not use ...");
    char *default_namespace;
    char *prefix = qualified_name->name;
    dom_document_namespace(DOM_NODE(element)->document, &default_namespace);
    if (g_strcmp0(prefix, default_namespace)==0)
        prefix = NULL;

    xmlNs *ns = dom_document_search_ns(DOM_NODE(element)->document, prefix);
    //xmlNs *ns = xmlNewNs(DOM_NODE(element)->xml, value, qualified_name->name);
    if (0 && ns) {
        xmlSetNs(DOM_NODE(element)->xml, ns);
    } else {
        g_print("namespace % not found\n", qualified_name->name);
    }
    */
}



/**
 * @brief dom_element_clone
 * duplicate DomElement
 * @param element
 * @return
 */
static DomNode*
dom_element_clone(DomNode *node, gboolean deep)
{
    DomNode *clone = DOM_NODE_CLASS(dom_element_parent_class)->clone(node, deep);

    return clone;
}

gchar*
dom_element_get_attribute(DomElement *element, DomQualifiedName *name)
{
    xmlNode *node = element->parent_instance.xml;
    // check default namespace
    xmlChar *value = xmlGetProp(node, name->name);
    return (gchar *) value;
}

guint
dom_element_get_instance_id(DomElement *element)
{
    DomDocument *doc = dom_node_get_document(DOM_NODE(element));
    if (!element->instance_id) {
        element->instance_id = dom_document_instance_count_new(doc);
    }
    return element->instance_id;
}
