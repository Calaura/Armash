/*
 * dom-types.h
 * Copyright (C) 2014       MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DOM_H__
#define __DOM_H__

#include <glib-object.h>
#include <libxml/tree.h>
#include <libxml/xpath.h>
#include <libcroco/libcroco.h>
#include <liblog/log.h>

#include <libdom/dom-types.h>
#include <libdom/dom-enums.h>
#include <libdom/dom-implementation.h>
#include <libdom/dom-node.h>
#include <libdom/dom-document-type.h>
#include <libdom/dom-document.h>
#include <libdom/dom-element.h>
#include <libdom/dom-qualified-name.h>

#endif /* __DOM_H__ */
