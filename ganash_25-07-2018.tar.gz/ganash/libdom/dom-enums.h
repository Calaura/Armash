/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-enums.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DOM_ENUMS_H__
#define __DOM_ENUMS_H__


G_BEGIN_DECLS

#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
enum _DomDumpFlag {
    DOM_DUMP_POINTER_FLAG    = 1 << (0 + RENDERER_DUMP_LAST_FLAG),
    DOM_DUMP_RECURSIVE_FLAG  = 1 << (1 + RENDERER_DUMP_LAST_FLAG),
    DOM_DUMP_TRANSFORM_FLAG  = 1 << (2 + RENDERER_DUMP_LAST_FLAG),
    DOM_DUMP_PATH_FLAG       = 1 << (3 + RENDERER_DUMP_LAST_FLAG),
    DOM_DUMP_ID_FLAG         = 1 << (4 + RENDERER_DUMP_LAST_FLAG),
    DOM_DUMP_ATTRIBUTES_FLAG = 1 << (5 + RENDERER_DUMP_LAST_FLAG),
    DOM_DUMP_RENDERER_FLAG   = 1 << (6 + RENDERER_DUMP_LAST_FLAG),

    DOM_DUMP_LAST_FLAG       =      (7 + RENDERER_DUMP_LAST_FLAG)
};
#endif

G_END_DECLS

#endif /* __DOM_ENUMS_H__ */

