/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-namespace.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "dom-namespace.h"


static void dom_namespace_class_init(DomNamespaceClass *klass);
static void dom_namespace_init(DomNamespace *gobject);

G_DEFINE_TYPE (DomNamespace, dom_namespace, G_TYPE_OBJECT)

static void
dom_namespace_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (dom_namespace_parent_class)->finalize (object);
}
static void
dom_namespace_class_init(DomNamespaceClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = dom_namespace_finalize;

//	dom_namespace_parent_class = g_type_class_peek_parent (klass);
}

static void
dom_namespace_init (DomNamespace *object)
{
}

DomNamespace *
dom_namespace_new (void)
{
	return g_object_new (dom_namespace_get_type (),
	                     NULL);
}

void
dom_namespace_get_uri(DomNamespace *self)
{

}
