/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-implementation.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include <libxml/tree.h>
#include <libxml/xpath.h>

#include <libcroco/libcroco.h>

#include <liblog/log.h>
#include <librenderer/renderer-enums.h>


#include "dom-types.h"
#include "dom-node.h"
#include "dom-document.h"
#include "dom-document-type.h"
#include "dom-implementation.h"


static void dom_implementation_class_init(DomImplementationClass *klass);
static void dom_implementation_init(DomImplementation *gobject);

G_DEFINE_TYPE (DomImplementation, dom_implementation, G_TYPE_OBJECT)

static void
dom_implementation_class_init(DomImplementationClass *klass)
{
//	GObjectClass *gobject_class;
//	gobject_class = (GObjectClass *) klass;
//	dom_implementation_parent_class = g_type_class_peek_parent (klass);
}

static void
dom_implementation_init (DomImplementation *object)
{
}

DomImplementation*
dom_implementation_new (void)
{
    return g_object_new (DOM_TYPE_IMPLEMENTATION, NULL);
}

DomNode*
dom_implementation_create_ns_element(gchar *node_ns, gchar *node_name, DomDocument *document, GError **error)
{
    g_return_val_if_fail(error==NULL || *error==NULL, NULL);

    if (DOM_IS_DOCUMENT(document)) {
        *error = g_error_new(g_quark_from_static_string("DOM"), 1, "Invalid 'document' argument type (@0x%p)", document);
        return NULL;
    }

    DomImplementation *implementation = document->implementation;
    if (DOM_IS_IMPLEMENTATION(implementation)) {
        *error = g_error_new(g_quark_from_static_string("DOM"), 2, "Ivalid document implementation (@0x%p)", implementation);
        return NULL;
    }

    return DOM_IMPLEMENTATION_GET_CLASS(implementation)->create_element_ns(node_ns, node_name, document, error);
}

DomDocumentType*
dom_implementation_create_document_type(gchar *qualified_name, gchar *public_id, gchar *system_id)
{

    return dom_document_type_new(NULL/*document*/, qualified_name, public_id, system_id);
}

DomDocument*
dom_implementation_create_document(gchar *namespace_uri, gchar *qualified_name, DomDocumentType *doctype)
{

    return g_object_new(DOM_TYPE_DOCUMENT, NULL);
}

gboolean
dom_implementation_has_feature(DomImplementation *self, gchar *feature , gchar *version)
{
    return FALSE;
}
