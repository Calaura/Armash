/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dom-element.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DOM_ELEMENT_H__
#define __DOM_ELEMENT_H__


G_BEGIN_DECLS

#define DOM_ELEMENT_CAST(obj)       ((DomElement*)obj)
#define DOM_TYPE_ELEMENT            (dom_element_get_type())
#define DOM_ELEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DOM_TYPE_ELEMENT, DomElement))
#define DOM_ELEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DOM_TYPE_ELEMENT, DomElementClass))
#define DOM_IS_ELEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DOM_TYPE_ELEMENT))
#define DOM_IS_ELEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DOM_TYPE_ELEMENT))
#define DOM_ELEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DOM_TYPE_ELEMENT, DomElementClass))

typedef struct _DomElementClass DomElementClass;

struct _DomElement {
    DomNode parent_instance;

    guint instance_id;
};

struct _DomElementClass {
    DomNodeClass parent_class;
};

GType       dom_element_get_type();

DomElement *dom_element_new(DomDocument *document, DomQualifiedName *tag);

void        dom_element_append(DomElement *element, DomElement* child);
void        dom_element_remove(DomElement *element, DomElement* child);

void        dom_element_set_attribute_ns(DomElement *element, char *namespace_uri, DomQualifiedName *qualified_name, char *value);
void        dom_element_set_attribute(DomElement *element, DomQualifiedName *attr, char *value);

gchar      *dom_element_get_attribute(DomElement *element, DomQualifiedName *name);


/*

hash_tag({"svg", "rect", element_instance_id}, {"svg", "x"})
lookup(svg) == 1
lookup(rect) == 255
lookup(svg) == 1
lookup(x) == 256

rect (x, y, width, height)
line (x1, y1, x2, y2)
g (x, y)

0 (0, 1, 2, 3)
1 (4, 5, 6, 7)
2 (0, 1)


|---------|--------------|--------------------|-------//-------------------|
  xml|svg   xml:abbr...x   css:bold...z-index       id (block -> MAX_UINT)


gchar*       dom_element_get_instance_id(DomElement *element);
gchar*
dom_element_get_id(DomNode *node)
{
    char *id;
document->rect,ellipse,...,line

    if (node->xml->type == XML_ELEMENT_NODE) {
        // check if xml:id attribute exists
        // #rect123
        // #rect123
    } else if (node->xml->type == XML_ATTRIBUTE_NODE) {
        // check the xml:id attribute
        // #rect123x
    }

    return id;
}
*/

gchar      *dom_element_children_dump(xmlNode* children, LogDumpOptions *options);

G_END_DECLS

#endif /* __DOM_ELEMENT_H__ */

