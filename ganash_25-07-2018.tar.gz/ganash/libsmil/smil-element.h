/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * smil-element.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SMIL_ELEMENT_H__
#define __SMIL_ELEMENT_H__


G_BEGIN_DECLS

#define SMIL_TYPE_ELEMENT            (smil_element_get_type())
#define SMIL_ELEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SMIL_TYPE_ELEMENT, SmilElement))
#define SMIL_ELEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SMIL_TYPE_ELEMENT, SmilElementClass))
#define SMIL_IS_ELEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SMIL_TYPE_ELEMENT))
#define SMIL_IS_ELEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SMIL_TYPE_ELEMENT))
#define SMIL_ELEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SMIL_TYPE_ELEMENT, SmilElementClass))

typedef struct _SmilElementClass SmilElementClass;

struct _SmilElement {
	DomElement parent_instance;

/*
    gboolean conditions_connected;
    gboolean has_end_event_conditions;

    gboolean is_waiting_for_first_interval;

    //typedef HashSet<SVGSMILElement*> TimeDependentSet;
    //TimeDependentSet m_timeDependents;

    // Instance time lists
    GArray *begin_times;// of SmilTimeRelative
    GArray *end_times;//  of SmilTimeRelative

    // This is the upcoming or current interval
    SmilTime    interval_begin;
    SmilTime    interval_end;

    SmilTime    previous_interval_begin;

    SmilStateType active_state;
    float last_percent;
    unsigned last_repeat;

    SmilTime    next_progress_time;

    SmilTimeContainer *time_container;

    unsigned m_document_order_index;

    SvgTime cached_dur;
    SvgTime cached_repeat_dur;
    SvgTime cached_repeat_count;
    SvgTime cached_min;
    SvgTime cached_max;
*/
};

struct _SmilElementClass {
	DomElementClass parent_class;
};

GType smil_element_get_type();
SmilElement *smil_element_new();

G_END_DECLS

#endif /* __SMIL_ELEMENT_H__ */

