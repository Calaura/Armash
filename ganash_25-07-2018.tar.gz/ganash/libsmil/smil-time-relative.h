/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * smil-time-relative.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SMIL_TIME_RELATIVE_H__
#define __SMIL_TIME_RELATIVE_H__


G_BEGIN_DECLS

enum _SmilOriginType {
    Parser,
    Script
};
typedef enum _SmilContextType SmilContextType;


#define SMIL_TIME_RELATIVE(obj)            ((SmilTimeRelative *)obj)


struct _SmilTimeRelative {
	SmilTime parent_instance;

    /*< public >*/

    /*< private >*/
    SmilOriginType origin;
};

SmilTimeRelative *smil_time_relative_new();

G_END_DECLS

#endif /* __SMIL_TIME_RELATIVE_H__ */

