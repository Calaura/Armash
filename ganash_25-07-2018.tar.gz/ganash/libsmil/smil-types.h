

typedef struct _SmilTime SmilTime;
typedef struct _SmilTimeContainer SmilTimeContainer;
typedef struct _SmilTimeRelative SmilTimeRelative;
typedef struct _SmilElement SmilElement;


typedef enum _SmilTimeType SmilTimeType;
typedef enum _SmilStateType SmilStateType;
typedef enum _SmilOriginType SmilOriginType;

