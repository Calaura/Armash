/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * smil-time.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SMIL_TIME_H__
#define __SMIL_TIME_H__


G_BEGIN_DECLS

#define SMIL_TIME(obj)                 ((SmilTime *)obj)
#define SMIL_TIME_UNRESOLVED(obj)      {DBL_MAX, SMIL_TIME_UNKNOW_TYPE, 0}
#define SMIL_TIME_INDEFINITE(obj)      {FLT_MAX, SMIL_TIME_UNKNOW_TYPE, 0}

struct _SmilTime {
    /*< public >*/
    double value;
    SmilTimeType type;
};

SmilTime *smil_time_new();
void      smil_time_free(SmilTime *time);

//void     svg_time_indefinite_value(SvgTime *time);
//void     svg_time_unresolved_value(SvgTime *time);
gboolean smil_time_is_finite(SmilTime *time);
gboolean smil_time_is_indefinite(SmilTime *time);
gboolean smil_time_is_unresolved(SmilTime *time);

G_END_DECLS

#endif /* __SMIL_TIME_H__ */

