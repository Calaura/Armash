/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * smil-element.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include <liblog/log.h>
#include <librenderer/renderer.h>
#include <libdom/dom.h>

#include "smil-types.h"
#include "smil-enums.h"
#include "smil-time.h"
#include "smil-element.h"


static void smil_element_class_init(SmilElementClass *klass);
static void smil_element_init(SmilElement *gobject);

G_DEFINE_TYPE (SmilElement, smil_element, DOM_TYPE_ELEMENT)

static void
smil_element_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (smil_element_parent_class)->finalize (object);
}
static void
smil_element_class_init(SmilElementClass *klass)
{
    DomElementClass *domelement_class;
    GObjectClass *gobject_class;

	domelement_class = (DomElementClass *) klass;
    gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = smil_element_finalize;

//	smil_element_parent_class = g_type_class_peek_parent (klass);
}

static void
smil_element_init (SmilElement *object)
{
}

SmilElement *
smil_element_new (void)
{
	return g_object_new (smil_element_get_type (),
	                     NULL);
}

