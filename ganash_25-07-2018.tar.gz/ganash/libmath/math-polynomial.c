/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
 * Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <math.h>

#include "math-polynomial.h"

/*
MathPolynomial *
math_polynomial_new (double coef[], int degree)
{
    return 0;
}

int
math_polynomial_solve (const MathPolynomial *polynomial, double *roots)
{

    return 0;
}

double math_polynomial_eval  (double a, double b, double c, double x)
{

}
*/




double
math_polynomial1_eval (double a, double b, double x)
{
    return a*x + b;
}

double
math_polynomial2_eval (double a, double b, double c, double x)
{
    return a*x*x + b*x + c;
}


int
math_polynomial1_solve (double a, double b, double *x_1)
{
    /*if (a == 0)
    {
        return 0;
    }*/
    *x_1 = -b / a;
    return 1;
}

int
math_polynomial2_solve (double a, double b, double c, double *x_1, double *x_2)
{
    double deltat = b*b - 4*a*c;

    if (deltat > 0)
      {
        if (b == 0)
          {
            double r = sqrt (-c / a);
            *x_1 = -r;
            *x_2 =  r;
          }
        else
          {
            double sign = b > 0 ? 1.0 : -1.0;
            double tmp = -0.5 * (b + sign * sqrt (deltat));
            double r1 = tmp / a ;
            double r2 = c / tmp ;

            if (r1 < r2)
              {
                *x_1 = r1 ;
                *x_2 = r2 ;
              }
            else
              {
                *x_1 = r2 ;
                *x_2 = r1 ;
              }
          }
        return 2;
      }
    else if (deltat == 0)
      {
        *x_1 = -0.5 * b/a;
        return 1;
      }
    else
      {
        return 0;
      }
}

int
math_polynomial3_solve (MathPolynomial3 *polynomial, MathPolynomial3Root *root)
{
    return 0;
}

double
math_polynomial3_eval (MathPolynomial3 *polynomial, double x)
{
    double xx = x*x;
    double xxx = x*xx;
    return polynomial->a*xxx + polynomial->b*xx + polynomial->c*x + polynomial->d;
}
