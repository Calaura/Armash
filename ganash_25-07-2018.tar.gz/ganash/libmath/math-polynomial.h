/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _MATH_POLYNOMIAL_H_
#define _MATH_POLYNOMIAL_H_

#define MATH_POLYNOMIAL_QUAD_DEGREE  2
#define MATH_POLYNOMIAL_CUBIC_DEGREE 3

typedef struct _MathPolynomial  MathPolynomial;
typedef struct _MathPolynomial1 MathPolynomial1;
typedef struct _MathPolynomial2 MathPolynomial2;
typedef struct _MathPolynomial3 MathPolynomial3;

typedef struct _MathPolynomialRoot  MathPolynomialRoot;
typedef struct _MathPolynomial1Root MathPolynomial1Root;
typedef struct _MathPolynomial2Root MathPolynomial2Root;
typedef struct _MathPolynomial3Root MathPolynomial3Root;



struct _MathPolynomialRoot
{
    int flags;
    double root[0];
};

struct _MathPolynomial1Root
{
    int flags;// 1 solution, 2 solution, complex
    double root[1];
};

struct _MathPolynomial2Root
{
    int flags;// 1 solution, 2 solution, complex
    double root[2];// sqrt 4ac + b
};

struct _MathPolynomial3Root
{
    int flags;
    double root[3];
};

struct _MathPolynomial
{
    int degree;
    double coef[0];/* coef[0] + coef[1].x */
};

#define MATH_POLYNOMIAL_1_INIT \
    {1, 0.0, 0.0}

struct _MathPolynomial1
{
    int degree;
    double b;
    double a;
};

#define MATH_POLYNOMIAL_2_INIT \
    {2, 0.0, 0.0, 0.0}

struct _MathPolynomial2
{
    int degree;
    double c;
    double b;
    double a;
};

#define MATH_POLYNOMIAL_3_INIT \
    {3, 0.0, 0.0, 0.0, 0.0}

struct _MathPolynomial3
{
    int degree;
    double d;
    double c;
    double b;
    double a;
};

#define MATH_POLYNOMIAL2_TO_DERIV(poly, deriv) \
deriv.a = 2.0*(poly).a; \
deriv.b = (poly).b;

#define MATH_POLYNOMIAL3_TO_DERIV(poly, deriv) \
(deriv)->a = 3.0*(poly)->a; \
(deriv)->b = 2.0*(poly)->b; \
(deriv)->c = (poly)->c;

/*int    math_polynomial_solve (const MathPolynomial* polynomial, double *roots);
double math_polynomial_eval  (double a, double b, double c, double x);*/

int    math_polynomial1_solve (double a, double b, double *x_1);
double math_polynomial1_eval  (double a, double b, double x);

int    math_polynomial2_solve (double a, double b, double c, double *x_1, double *x_2);
double math_polynomial2_eval  (double a, double b, double c, double x);

int    math_polynomial3_solve (MathPolynomial3 *polynomial, MathPolynomial3Root *root);
double math_polynomial3_eval  (MathPolynomial3 *polynomial, double x);


#endif /* _MATH_POLYNOMIAL_H_ */
