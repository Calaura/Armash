/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <config.h>

#include "core-types.h"
#include "core-enums.h"

#include "core-path.h"
#include "core-path-private.h"

#include <cairo/cairo.h>

G_DEFINE_TYPE (CorePath, core_path, G_TYPE_OBJECT)

static void
core_path_init (CorePath *core_path)
{
    core_path->status        = CORE_PATH_STATUS_INVALID;
    core_path->segments      = NULL;
    core_path->num_segments  = 0;

    core_path->cairo_path          = NULL;
    core_path->cairo_path_num_data = 0;

	/* TODO: Add initialization code here */
}

static void
core_path_finalize (GObject *object)
{
	/* TODO: Add deinitalization code here */

    /*g_object_unref(CORE_PATH(object)->graphics_path);*/


	G_OBJECT_CLASS (core_path_parent_class)->finalize (object);
}

static void
core_path_class_init (CorePathClass *klass)
{
	GObjectClass* object_class = G_OBJECT_CLASS (klass);
	GObjectClass* parent_class = G_OBJECT_CLASS (klass);

	object_class->finalize = core_path_finalize;
}

void core_path_move_to (CorePath* path, double x, double y)
{
    CorePathSegmentMove* segment = g_new(CorePathSegmentMove, 1);
    if (!segment) {
        path->status = CORE_PATH_STATUS_INVALID;/*CORE_STATUS_NO_MEMORY;*/
        return;
    }
    segment->command = CORE_PATH_COMMAND_MOVE_TO;
    segment->data[0] = x;
    segment->data[1] = y;

    path->segments = g_list_append(path->segments, (gpointer) segment);
    path->num_segments++;
    path->cairo_path_num_data += 2; /* head + data*/

    path->status = CORE_PATH_STATUS_MODIFIED;
}

void core_path_line_to (CorePath* path, double x, double y)
{
    CorePathSegmentLine* segment = g_new(CorePathSegmentLine, 1);
    if (!segment) {
        path->status = CORE_PATH_STATUS_INVALID;/*CORE_STATUS_NO_MEMORY;*/
        return;
    }
    segment->command = CORE_PATH_COMMAND_LINE_TO;
    segment->data[0] = x;
    segment->data[1] = y;

    path->segments = g_list_append(path->segments, (gpointer) segment);
    path->num_segments++;
    path->cairo_path_num_data += 2; /*sizeof(_cairo_path_data_t) */

    path->status = CORE_PATH_STATUS_MODIFIED;
}


void core_path_quad_to  (CorePath* path, double c_x, double c_y, double x, double y)
{
    CorePathSegmentQuad* segment = g_new(CorePathSegmentQuad, 1);
    if (!segment) {
        path->status = CORE_PATH_STATUS_INVALID;/*CORE_STATUS_NO_MEMORY;*/
        return;
    }
    segment->command = CORE_PATH_COMMAND_QUAD_TO;
    segment->data[0] = c_x;
    segment->data[1] = c_y;
    segment->data[2] = x;
    segment->data[3] = y;

    path->segments = g_list_append(path->segments, (gpointer) segment);
    path->num_segments++;
    path->cairo_path_num_data += 4; /*WARNING cairo do not support QUAD Beizer; cubic is used; sizeof(_cairo_path_data_t) */

    path->status = CORE_PATH_STATUS_MODIFIED;
}

void core_path_cubic_to (CorePath* path, double c1_x, double c1_y, double c2_x, double c2_y, double x, double y)
{
    CorePathSegmentCubic* segment = g_new(CorePathSegmentCubic, 1);
    if (!segment) {
        path->status = CORE_PATH_STATUS_INVALID;/*CORE_STATUS_NO_MEMORY;*/
        return;
    }
    segment->command = CORE_PATH_COMMAND_CUBIC_TO;
    segment->data[0] = c1_x;
    segment->data[1] = c1_y;
    segment->data[2] = c2_x;
    segment->data[3] = c2_y;
    segment->data[4] = x;
    segment->data[5] = y;

    path->segments = g_list_append(path->segments, (gpointer) segment);
    path->num_segments++;
    path->cairo_path_num_data += 4; /* header + data_P1 + data_P2 + data_P3 */

    path->status = CORE_PATH_STATUS_MODIFIED;
}


static void
core_path_segment_get_last_point(CorePathSegment* segment, double *x, double *y) {
    double c_x;
    double c_y;
    switch(segment->command)
    {
    case CORE_PATH_COMMAND_MOVE_TO:
        c_x = segment->data[0];
        c_y = segment->data[1];
    break;
    case CORE_PATH_COMMAND_LINE_TO:
        c_x = segment->data[0];
        c_y = segment->data[1];
    break;
    case CORE_PATH_COMMAND_QUAD_TO:
        c_x = segment->data[2];
        c_y = segment->data[3];
    break;
    case CORE_PATH_COMMAND_CUBIC_TO:
        c_x = segment->data[4];
        c_y = segment->data[5];
    break;
    }
    if (x)
        *x = c_x;
    if (y)
        *y = c_y;
}

/**
 * @see http://cairographics.org/manual/cairo-Paths.html
 *
 * @brief core_path_get_graphics_path
 * @param core_path
 * @return
 */
cairo_path_t *core_path_get_cairo_path(CorePath* core_path)
{
    if (core_path->status == CORE_PATH_STATUS_UPDATE) {
        return core_path->cairo_path;
    }

    gint i = 0;
    cairo_path_t* path;
    cairo_path_data_t *data;
    path = g_new(cairo_path_t, 1);
    path->status   = CAIRO_STATUS_SUCCESS;
    path->num_data = core_path->cairo_path_num_data;
    path->data     = (cairo_path_data_t*) g_new(cairo_path_data_t, core_path->cairo_path_num_data);
    /*check allocation*/

    GList* list;
    for (list=core_path->segments; list != NULL; list = list->next) {
        CorePathSegment* segment = (CorePathSegment*) list->data;
        data = &path->data[i];

        switch(segment->command)
        {
        case CORE_PATH_COMMAND_MOVE_TO:
            data->header.type = CAIRO_PATH_MOVE_TO;
            data->header.length = 2;
            data[1].point.x = segment->data[0];
            data[1].point.y = segment->data[1];
        break;
        case CORE_PATH_COMMAND_LINE_TO:
            data->header.type = CAIRO_PATH_LINE_TO;
            data->header.length = 2;
            data[1].point.x = segment->data[0];
            data[1].point.y = segment->data[1];
        break;
        case CORE_PATH_COMMAND_QUAD_TO:
        {
            double c_x;
            double c_y;
            core_path_segment_get_last_point((CorePathSegment*) list->prev->data, &c_x, &c_y);

            data->header.type = CAIRO_PATH_CURVE_TO;
            data->header.length = 4;

            data[1].point.x = c_x + 2.0/3.0 * (segment->data[0]-c_x);
            data[1].point.y = c_y + 2.0/3.0 * (segment->data[1]-c_y);

            data[2].point.x = segment->data[2] + 2.0/3.0 * (segment->data[0]-segment->data[2]);
            data[2].point.y = segment->data[3] + 2.0/3.0 * (segment->data[1]-segment->data[3]);

            data[3].point.x = segment->data[2];
            data[3].point.y = segment->data[3];
        }
        break;
        case CORE_PATH_COMMAND_CUBIC_TO:
            data->header.type = CAIRO_PATH_CURVE_TO;
            data->header.length = 4;
            data[1].point.x = segment->data[0];
            data[1].point.y = segment->data[1];
            data[2].point.x = segment->data[2];
            data[2].point.y = segment->data[3];
            data[3].point.x = segment->data[4];
            data[3].point.y = segment->data[5];
        break;
        default:
            /* TODO CAIRO_PATH_CLOSE_PATH */
        break;
        }
        i += data->header.length;
    }

    core_path->status = CORE_PATH_STATUS_UPDATE;
    core_path->cairo_path = path;

    return core_path->cairo_path;
}
