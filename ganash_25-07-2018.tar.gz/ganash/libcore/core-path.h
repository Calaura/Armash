/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 * 
Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _CORE_PATH_H_
#define _CORE_PATH_H_

#include <glib-object.h>
#include <cairo/cairo.h>

G_BEGIN_DECLS

#define CORE_TYPE_PATH             (core_path_get_type ())
#define CORE_PATH(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), CORE_TYPE_PATH, CorePath))
#define CORE_PATH_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), CORE_TYPE_PATH, CorePathClass))
#define CORE_IS_PATH(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), CORE_TYPE_PATH))
#define CORE_IS_PATH_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), CORE_TYPE_PATH))
#define CORE_PATH_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), CORE_TYPE_PATH, CorePathClass))

typedef struct _CorePathClass CorePathClass;

struct _CorePathClass
{
	GObjectClass parent_class;
};

struct _CorePath
{
	GObject parent_instance;

    CorePathStatusType status;
    GList*             segments;
    guint              num_segments;

    cairo_path_t*      cairo_path;
    guint              cairo_path_num_data;
};



GType core_path_get_type (void) G_GNUC_CONST;

void core_path_move_to  (CorePath* path, double x, double y);
void core_path_line_to  (CorePath* path, double x, double y);
void core_path_quad_to  (CorePath* path, double c_x, double c_y, double x, double y);
void core_path_cubic_to (CorePath* path, double c1_x, double c1_y, double c2_x, double c2_y, double x, double y);
/*void core_path_arc_to   (CorePath* path, double x, double y, radius, angle1, angle2);*/
cairo_path_t* core_path_get_cairo_path(CorePath* core_path);
/* manipuation path data etc */

G_END_DECLS

#endif /* _CORE_PATH_H_ */
