/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 *
Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _CORE_ENUMS_H_
#define _CORE_ENUMS_H_

enum _CorePathCommand
{
    CORE_PATH_COMMAND_UNKNOW,
    CORE_PATH_COMMAND_MOVE_TO,
    CORE_PATH_COMMAND_LINE_TO,
    CORE_PATH_COMMAND_QUAD_TO,
    CORE_PATH_COMMAND_CUBIC_TO
};

enum _CorePathStatusType
{
    CORE_PATH_STATUS_INVALID,
    CORE_PATH_STATUS_UPDATE,
    CORE_PATH_STATUS_MODIFIED
};

enum _CoreStatus {
    CORE_STATUS_SUCCESS = 0,

    CORE_STATUS_NO_MEMORY,
    CORE_STATUS_INVALID_RESTORE,
    CORE_STATUS_INVALID_POP_GROUP,
    CORE_STATUS_NO_CURRENT_POINT,
    CORE_STATUS_INVALID_MATRIX,
    CORE_STATUS_INVALID_STATUS,
    CORE_STATUS_NULL_POINTER,
    CORE_STATUS_INVALID_STRING,
    CORE_STATUS_INVALID_PATH_DATA,
    CORE_STATUS_READ_ERROR,
    CORE_STATUS_WRITE_ERROR,
    CORE_STATUS_SURFACE_FINISHED,
    CORE_STATUS_SURFACE_TYPE_MISMATCH,
    CORE_STATUS_PATTERN_TYPE_MISMATCH,
    CORE_STATUS_INVALID_CONTENT,
    CORE_STATUS_INVALID_FORMAT,
    CORE_STATUS_INVALID_VISUAL,
    CORE_STATUS_FILE_NOT_FOUND,
    CORE_STATUS_INVALID_DASH,
    CORE_STATUS_INVALID_DSC_COMMENT,
    CORE_STATUS_INVALID_INDEX,
    CORE_STATUS_CLIP_NOT_REPRESENTABLE,
    CORE_STATUS_TEMP_FILE_ERROR,
    CORE_STATUS_INVALID_STRIDE,
    CORE_STATUS_FONT_TYPE_MISMATCH,
    CORE_STATUS_USER_FONT_IMMUTABLE,
    CORE_STATUS_USER_FONT_ERROR,
    CORE_STATUS_NEGATIVE_COUNT,
    CORE_STATUS_INVALID_CLUSTERS,
    CORE_STATUS_INVALID_SLANT,
    CORE_STATUS_INVALID_WEIGHT,
    CORE_STATUS_INVALID_SIZE,
    CORE_STATUS_USER_FONT_NOT_IMPLEMENTED,
    CORE_STATUS_DEVICE_TYPE_MISMATCH,
    CORE_STATUS_DEVICE_ERROR,

    CORE_STATUS_LAST_STATUS
};



#endif // _CORE_ENUMS_H_
