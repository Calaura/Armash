#ifndef _CORE_TYPES_H_
#define _CORE_TYPES_H_

typedef struct _CorePath CorePath;

typedef enum _CorePathCommand    CorePathCommand;
typedef enum _CoreStatus         CoreStatus;
typedef enum _CorePathStatusType CorePathStatusType;


#endif // _CORE_TYPES_H_
