#ifndef _CORE_PATH_PRIVATE_H_
#define _CORE_PATH_PRIVATE_H_

#define DIMENSION_2D 2
#define DIMENSION_3D 3


typedef struct _CorePathSegmentBounding
{
    int convex_hull_approximate;/* via les point de control*/
    int convex_hull;/* exact - represetation de l'elastique */
    int bounding_box_approximate_effect;/* via les point de control*/
    int bounding_box_approximate_shape;/* via les point de control*/
    int bounding_box_approximate_stroke;/* via les point de control*/
    int bounding_box_approximate;/* via les point de control*/
    int bounding_box_effect;/* via les point de control*/
    int bounding_box_shape;/* via les point de control*/
    int bounding_box_stroke;/* via les point de control*/
    int bounding_box;/* via les point de control*/

    int polynome;/*polynome representation */
    int polynome_cache;/*polynome representation */

    /*
    MathPolynomial approximate;
    MathPolynomial box;
    */

} CorePathSegmentBounding;

/*GraphicsBoundingBox box; \ */
#define CORE_PATH_2D_SEGMENT(type, size) \
    typedef struct _CorePathSegment##type { \
        CorePathCommand command; \
        double data[size]; \
    } CorePathSegment##type;


/*#define CORE_PATH_3D_SEGMENT(type, size) \
    typedef struct _CorePath3DSegment##type { \
        CorePathCommand command; \
        double data[size]; \
    } CorePath3DSegment##type;*/

CORE_PATH_2D_SEGMENT(,  2)
CORE_PATH_2D_SEGMENT(Move,  1*DIMENSION_2D)
CORE_PATH_2D_SEGMENT(Line,  1*DIMENSION_2D)
CORE_PATH_2D_SEGMENT(Quad,  2*DIMENSION_2D)
CORE_PATH_2D_SEGMENT(Cubic, 3*DIMENSION_2D)

/*
CORE_PATH_3D_SEGMENT(,  3)
CORE_PATH_3D_SEGMENT(Move,  1*DIMENSION_3D)
CORE_PATH_3D_SEGMENT(Line,  1*DIMENSION_3D)
CORE_PATH_3D_SEGMENT(Quad,  2*DIMENSION_3D)
CORE_PATH_3D_SEGMENT(Cubic, 3*DIMENSION_3D)*/

#endif // _CORE_PATH_PRIVATE_H_
