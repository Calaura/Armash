/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * svgtk-element.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVGTK_ELEMENT_H__
#define __SVGTK_ELEMENT_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define SVGTK_TYPE_ELEMENT            (svgtk_element_get_type())
#define SVGTK_ELEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVGTK_TYPE_ELEMENT, SvgtkElement))
#define SVGTK_ELEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVGTK_TYPE_ELEMENT, SvgtkElementClass))
#define SVGTK_IS_ELEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVGTK_TYPE_ELEMENT))
#define SVGTK_IS_ELEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVGTK_TYPE_ELEMENT))
#define SVGTK_ELEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVGTK_TYPE_ELEMENT, SvgtkElementClass))

typedef struct _SvgtkElement SvgtkElement;
typedef struct _SvgtkElementClass SvgtkElementClass;

struct _SvgtkElement {
	GObject parent_instance;

    // svg_document;
    // svg_manipulator;
};

struct _SvgtkElementClass {
	GObjectClass parent_class;
};

GType svgtk_element_get_type();
SvgtkElement *svgtk_element_new();

G_END_DECLS

#endif /* __SVGTK_ELEMENT_H__ */

