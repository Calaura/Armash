/*
 * log-dump.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __LOG_DUMP_H__
#define __LOG_DUMP_H__


G_BEGIN_DECLS


#if defined(ENABLE_DEBUG) && ENABLE_DEBUG
#   define LOG_IMPLEMENT_INTERFACE_DUMP(interface_init) G_IMPLEMENT_INTERFACE (LOG_TYPE_DUMP, interface_init)
#else
#   define LOG_IMPLEMENT_INTERFACE_DUMP(interface_init)
#endif

#define LOG_IMPLEMENT_DUMP_BEGIN \
#   if defined(ENABLE_DEBUG) && ENABLE_DEBUG

#define LOG_IMPLEMENT_DUMP_END \
#   endif


#define LOG_TYPE_DUMP                (log_dump_get_type ())
#define LOG_DUMP(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  LOG_TYPE_DUMP,  LogDump))
#define LOG_IS_DUMP(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  LOG_TYPE_DUMP))
#define LOG_DUMP_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  LOG_TYPE_DUMP,  LogDumpInterface))

typedef struct _LogDumpConfig      LogDumpConfig;
struct _LogDumpConfig {
    char    endl[2];// config: chaine representant un saut de ligne
    char    indent[12];// config: chaine representant une indentation
    char    glue[3];// config: chaine representant une separation
};
static LogDumpConfig LogDumpConfigIndent = {
    "\n",
    "    ",
    ", "
};
static LogDumpConfig LogDumpConfigInline = {
    "",
    "",
    ", "
};

typedef struct _LogDumpOptions      LogDumpOptions;
struct _LogDumpOptions {
    guint   flags;
    int     depth;// le nombre d'indentation
    int     newl;// commence avec une nouvelle ligne
    int     has_content;// indique si du contenue a été géneré
    LogDumpConfig *config;
};

static LogDumpOptions LogDumpOptionsEmpty = {
    0,
    0,
    0,
    0,
    &LogDumpConfigIndent
};

typedef struct _LogDump  LogDump; /* dummy object */
typedef struct _LogDumpInterface  LogDumpInterface;

struct _LogDumpInterface
{
	GTypeInterface parent_iface;
    gchar* (*to_string) ( LogDump *self, LogDumpOptions *options);
};

GType  log_dump_get_type (void);
gchar *log_dump_to_string(LogDump *self, LogDumpOptions *options);




G_END_DECLS

#endif /* __LOG_DUMP_H__ */

