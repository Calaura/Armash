#include "config.h"

#include <glib-object.h>
#include "log-types.h"
#include "log-enums.h"
#include "log-dump.h"

G_DEFINE_INTERFACE (LogDump, log_dump, 0)

static gchar*
log_dump_interface_default_to_string (LogDump *object, LogDumpOptions *options)
{
    /* add properties and signals to the interface here */
    return "*";
}

static void
log_dump_default_init (LogDumpInterface *iface)
{
    /* add properties and signals to the interface here */
    iface->to_string = log_dump_interface_default_to_string;
}

gchar*
log_dump_to_string (LogDump *self, LogDumpOptions *options)
{
  g_return_if_fail (G_IS_OBJECT (self));

  char *str = LOG_DUMP_GET_INTERFACE (self)->to_string (self, options);
  {
      char *tmp = str;
      str = g_strdup_printf(str, "");// clear PLACE_HOLDER
      g_free(tmp);
  }

  return str;
}
