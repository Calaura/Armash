/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * log-print.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "log-print.h"


static void log_print_class_init(LogPrintClass *klass);
static void log_print_init(LogPrint *gobject);

G_DEFINE_TYPE (LogPrint, log_print, G_TYPE_OBJECT)

static void
log_print_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (gobject_parent_class)->finalize (object);
}
static void
log_print_class_init(LogPrintClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

	gobject_class->finalize = (log_print_finalize;

//	log_print_parent_class = g_type_class_peek_parent (klass);
}

static void
log_print_init (LogPrint *object)
{
}

LogPrint *
log_print_new (void)
{
	return g_object_new (log_print_get_type (),
	                     NULL);
}

