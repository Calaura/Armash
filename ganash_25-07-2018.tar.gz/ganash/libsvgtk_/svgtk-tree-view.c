/*
 * svgtk-tree-view.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "svgtk-tree-view.h"


#define SVGTK_TREE_VIEW_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), SVGTK_TYPE_TREE_VIEW, SvgtkTreeViewPrivate))
struct _SvgtkTreeViewPrivate {
	int foo;
};


static void svgtk_tree_view_class_init(SvgtkTreeViewClass *klass);
static void svgtk_tree_view_init(SvgtkTreeView *gobject);

G_DEFINE_TYPE (SvgtkTreeView, svgtk_tree_view, GTK_TYPE_TREE_VIEW)

static void
svgtk_tree_view_class_init(SvgtkTreeViewClass *klass)
{
	GtkTreeViewClass *gtktreeview_class;

	gtktreeview_class = (GtkTreeViewClass *) klass;

	g_type_class_add_private(klass, sizeof(SvgtkTreeViewPrivate));
//	svgtk_tree_view_parent_class = g_type_class_peek_parent (klass);
}

static void
svgtk_tree_view_init (SvgtkTreeView *object)
{
	SvgtkTreeViewPrivate *priv = SVGTK_TREE_VIEW_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

SvgtkTreeView *
svgtk_tree_view_new (void)
{
	return g_object_new (svgtk_tree_view_get_type (),
	                     NULL);
}

