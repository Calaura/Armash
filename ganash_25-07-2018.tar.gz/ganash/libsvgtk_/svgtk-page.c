/*
 * svgtk-page.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "svgtk-page.h"


static void svgtk_page_class_init(SvgtkPageClass *klass);
static void svgtk_page_init(SvgtkPage *gobject);

G_DEFINE_TYPE (SvgtkPage, svgtk_page, G_TYPE_OBJECT)

static void
svgtk_page_class_init(SvgtkPageClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	svgtk_page_parent_class = g_type_class_peek_parent (klass);
}

static void
svgtk_page_init (SvgtkPage *object)
{
}

SvgtkPage *
svgtk_page_new (void)
{
	return g_object_new (svgtk_page_get_type (),
	                     NULL);
}

