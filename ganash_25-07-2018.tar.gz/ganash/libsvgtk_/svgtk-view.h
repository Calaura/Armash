/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * SvgKit
 * Copyright (C) 2014 Ludovic Schaublore <schaublore@gmail.com>
 *
 * SvgKit is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * SvgKit is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __SVGTK_VIEW_H__
#define __SVGTK_VIEW_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define SVGTK_TYPE_VIEW            (svgtk_view_get_type())
#define SVGTK_VIEW(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVGTK_TYPE_VIEW, SvgtkView))
#define SVGTK_VIEW_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVGTK_TYPE_VIEW, SvgtkViewClass))
#define SVGTK_IS_VIEW(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVGTK_TYPE_VIEW))
#define SVGTK_IS_VIEW_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVGTK_TYPE_VIEW))
#define SVGTK_VIEW_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVGTK_TYPE_VIEW, SvgtkViewClass))

typedef struct _SvgtkView SvgtkView;
typedef struct _SvgtkViewPrivate SvgtkViewPrivate;
typedef struct _SvgtkViewClass SvgtkViewClass;

struct _SvgtkView {
    GtkDrawingArea parent_instance;
	/* private */
	SvgtkViewPrivate *private_member;
};

struct _SvgtkViewClass {
    GtkDrawingAreaClass parent_class;
};

GType svgtk_view_get_type();
SvgtkView *svgtk_view_new();

G_END_DECLS

#endif /* __SVGTK_VIEW_H__ */

