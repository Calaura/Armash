/*
 * svgtk-tool-object.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "svgtk-tool-object.h"


static void svgtk_tool_object_class_init(SvgtkToolObjectClass *klass);
static void svgtk_tool_object_init(SvgtkToolObject *gobject);

G_DEFINE_TYPE (SvgtkToolObject, svgtk_tool_object, G_TYPE_OBJECT)

static void
svgtk_tool_object_class_init(SvgtkToolObjectClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	svgtk_tool_object_parent_class = g_type_class_peek_parent (klass);
}

static void
svgtk_tool_object_init (SvgtkToolObject *object)
{
}

SvgtkToolObject *
svgtk_tool_object_new (void)
{
	return g_object_new (svgtk_tool_object_get_type (),
	                     NULL);
}

