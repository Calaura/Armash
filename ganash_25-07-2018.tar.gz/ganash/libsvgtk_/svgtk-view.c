/*
 * svgtk-view.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "svgtk-view.h"


#define SVGTK_VIEW_GET_PRIVATE(o) (G_TYPE_INSTANCE_GET_PRIVATE ((o), SVGTK_TYPE_VIEW, SvgtkViewPrivate))
struct _SvgtkViewPrivate {
    int foo;

    int mode;
    SvgDocument       *doc;
    SvgtkEditor       *editor;

    RendererContainer *renderer_controls;
    RendererContainer *renderer_guide;
    RendererContainer *renderer_sketch;
    RendererContainer *renderer_drawing;
    RendererContainer *renderer_grid;
    RendererContainer *renderer_background;
    RendererContainer *renderer;
};


static void     svgtk_view_size_request(GtkWidget *widget, GtkRequisition *requisition);
static void     svgtk_view_size_allocate(GtkWidget *widget, GtkAllocation *allocation);
static void     svgtk_view_realize(GtkWidget *widget);
static gboolean svgtk_view_expose(GtkWidget *widget, GdkEventExpose *event);

static gboolean svgtk_view_motion_notify_event (GtkWidget* widget, GdkEventMotion* event);
static gboolean svgtk_view_button_press_event  (GtkWidget* widget, GdkEventButton* event);
static gboolean svgtk_view_button_release_event  (GtkWidget* widget, GdkEventButton* event);


static void svgtk_view_class_init(SvgtkViewClass *klass);
static void svgtk_view_init(SvgtkView *gobject);

G_DEFINE_TYPE (SvgtkView, svgtk_view, GTK_TYPE_DRAWING_AREA)

static void
svgtk_view_class_init(SvgtkViewClass *klass)
{
    GtkWidgetClass *widget_class;

    widget_class = (GtkWidgetClass *) klass;
    object_class = (GObjectClass *) klass;

    /*object_class->constructor = svgtk_view_constructor;
    object_class->finalize = svgtk_view_finalize;*/

    widget_class->realize               = svgtk_view_realize;
    widget_class->size_request          = svgtk_view_size_request;
    widget_class->size_allocate         = svgtk_view_size_allocate;
    widget_class->expose_event          = svgtk_view_expose;

    widget_class->button_press_event    = svgtk_view_button_press_event;
    widget_class->button_release_event  = svgtk_view_button_release_event;
    widget_class->motion_notify_event   = svgtk_view_motion_notify_event;

	g_type_class_add_private(klass, sizeof(SvgtkViewPrivate));
    /*svgtk_view_parent_class = g_type_class_peek_parent (klass);*/
}

static void
svgtk_view_size_request(GtkWidget *widget,
    GtkRequisition *requisition)
{
  g_return_if_fail(widget != NULL);
  g_return_if_fail(SVGTK_IS_VIEW(widget));
  g_return_if_fail(requisition != NULL);

  requisition->width = 80;
  requisition->height = 100;
}


static void
svgtk_view_size_allocate(GtkWidget *widget,
    GtkAllocation *allocation)
{
  g_return_if_fail(widget != NULL);
  g_return_if_fail(SVGTK_IS_VIEW(widget));
  g_return_if_fail(allocation != NULL);

  widget->allocation = *allocation;

  if (gtk_widget_get_realized(widget)) {
     gdk_window_move_resize(
         widget->window,
         allocation->x, allocation->y,
         allocation->width, allocation->height
     );
   }
}


static void
svgtk_view_realize(GtkWidget *widget)
{
    GdkWindow* window;
    GtkStyle* style;
    GdkWindowAttr attributes;
    guint attributes_mask;

    g_return_if_fail(widget != NULL);
    g_return_if_fail(SVGTK_IS_VIEW(widget));

    gtk_widget_set_realized(widget, TRUE);
    gtk_widget_ensure_style (widget);

    attributes.window_type = GDK_WINDOW_CHILD;
    attributes.x = widget->allocation.x;
    attributes.y = widget->allocation.y;
    attributes.width = widget->allocation.width;
    attributes.height = widget->allocation.height;

    attributes.wclass = GDK_INPUT_OUTPUT;
    attributes.event_mask = gtk_widget_get_events(widget)
                         | GDK_POINTER_MOTION_MASK
                         | GDK_BUTTON_PRESS_MASK
                         | GDK_BUTTON_RELEASE_MASK
                         | GDK_EXPOSURE_MASK;

    attributes_mask = GDK_WA_X | GDK_WA_Y;

    window = gdk_window_new(
        gtk_widget_get_parent_window (widget),
        & attributes, attributes_mask
    );
    gtk_widget_set_window(widget, window);

    gdk_window_set_user_data(window, widget);

    style = gtk_widget_get_style(widget);
    style = gtk_style_attach(style, window);
    gtk_style_set_background(style, window, GTK_STATE_NORMAL);
    gtk_widget_set_style(widget, style);

}

static gboolean
svgtk_view_expose(GtkWidget *widget, GdkEventExpose *event)
{
  g_print("expose\n");

  SvgtkView* view = SVGTK_VIEW(widget);
  SvgtkViewPrivate* priv = view->private_member;

  cairo_t *cr;
  cr = gdk_cairo_create(gtk_widget_get_window(widget));
  renderer_object_draw(priv->renderer, cr);
  cairo_destroy(cr);

  return FALSE;
}


static gboolean svgtk_view_button_press_event  (GtkWidget* widget, GdkEventButton* event)
{
    SvgtkView* view = SVGTK_VIEW(widget);
    SvgtkViewPrivate* priv = view->private_member;

    cairo_t *cr = gdk_cairo_create(gtk_widget_get_window(widget));
    /* if (priv->mode == SVGTK_VIEW_MODE_EDITOR) */
    renderer_object_hit_test(priv->renderer_controls, cr);

    renderer_object_hit_test(priv->renderer_drawing, cr);
    cairo_destroy(cr);

    return TRUE;
}

static gboolean svgtk_view_button_release_event  (GtkWidget* widget, GdkEventButton* event)
{
    return FALSE;
}

static gboolean
svgtk_view_motion_notify_event (GtkWidget* widget, GdkEventMotion* event)
{
    SvgtkView* view = SVGTK_VIEW(widget);
    SvgtkViewPrivate *priv = view->private_member;

    cairo_t *cr = gdk_cairo_create(gtk_widget_get_window(widget));



    cairo_destroy(cr);

    return FALSE;
}

static void
svgtk_view_init (SvgtkView *object)
{
	SvgtkViewPrivate *priv = SVGTK_VIEW_GET_PRIVATE(object);
	object->private_member = priv;
	priv->foo = 0;
}

SvgtkView *
svgtk_view_new (void)
{
    return g_object_new (svgtk_view_get_type (),
                         NULL);
}


gboolean
svgtk_view_open (SvgtkView *view, const gchar *filename)
{
    view->private_member->doc = svg_document_load(filename);
    return TRUE;
}

gboolean
svgtk_view_emit_event (SvgtkView *view, SvgtkEvent* event)
{

    return TRUE;
}

void svgtk_view_get_bounding_box (SvgtkView *view)
{

}

void svgtk_view_set_zoom_level (SvgtkView *view)
{

}
