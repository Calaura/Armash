/*
 * svgtk-editor-path.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "svgtk-editor-path.h"


static void svgtk_editor_path_class_init(SvgtkEditorPathClass *klass);
static void svgtk_editor_path_init(SvgtkEditorPath *gobject);

G_DEFINE_TYPE (SvgtkEditorPath, svgtk_editor_path, G_TYPE_OBJECT)

static void
svgtk_editor_path_class_init(SvgtkEditorPathClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	svgtk_editor_path_parent_class = g_type_class_peek_parent (klass);
}

static void
svgtk_editor_path_init (SvgtkEditorPath *object)
{
}

SvgtkEditorPath *
svgtk_editor_path_new (void)
{
	return g_object_new (svgtk_editor_path_get_type (),
	                     NULL);
}

