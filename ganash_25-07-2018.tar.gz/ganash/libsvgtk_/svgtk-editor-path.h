/*
 * svgtk-editor-path.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVGTK_EDITOR_PATH_H__
#define __SVGTK_EDITOR_PATH_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define SVGTK_TYPE_EDITOR_PATH            (svgtk_editor_path_get_type())
#define SVGTK_EDITOR_PATH(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVGTK_TYPE_EDITOR_PATH, SvgtkEditorPath))
#define SVGTK_EDITOR_PATH_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVGTK_TYPE_EDITOR_PATH, SvgtkEditorPathClass))
#define SVGTK_IS_EDITOR_PATH(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVGTK_TYPE_EDITOR_PATH))
#define SVGTK_IS_EDITOR_PATH_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVGTK_TYPE_EDITOR_PATH))
#define SVGTK_EDITOR_PATH_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVGTK_TYPE_EDITOR_PATH, SvgtkEditorPathClass))

typedef struct _SvgtkEditorPath SvgtkEditorPath;
typedef struct _SvgtkEditorPathClass SvgtkEditorPathClass;

struct _SvgtkEditorPath {
	GObject parent_instance;
};

struct _SvgtkEditorPathClass {
	GObjectClass parent_class;
};

GType svgtk_editor_path_get_type();
SvgtkEditorPath *svgtk_editor_path_new();

G_END_DECLS

#endif /* __SVGTK_EDITOR_PATH_H__ */

