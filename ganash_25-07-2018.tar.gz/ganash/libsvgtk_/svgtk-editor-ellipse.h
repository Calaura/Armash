/*
 * svgtk-editor-ellipse.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __SVGTK_EDITOR_ELLIPSE_H__
#define __SVGTK_EDITOR_ELLIPSE_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define SVGTK_TYPE_EDITOR_ELLIPSE            (svgtk_editor_ellipse_get_type())
#define SVGTK_EDITOR_ELLIPSE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), SVGTK_TYPE_EDITOR_ELLIPSE, SvgtkEditorEllipse))
#define SVGTK_EDITOR_ELLIPSE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), SVGTK_TYPE_EDITOR_ELLIPSE, SvgtkEditorEllipseClass))
#define SVGTK_IS_EDITOR_ELLIPSE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), SVGTK_TYPE_EDITOR_ELLIPSE))
#define SVGTK_IS_EDITOR_ELLIPSE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), SVGTK_TYPE_EDITOR_ELLIPSE))
#define SVGTK_EDITOR_ELLIPSE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), SVGTK_TYPE_EDITOR_ELLIPSE, SvgtkEditorEllipseClass))

typedef struct _SvgtkEditorEllipse SvgtkEditorEllipse;
typedef struct _SvgtkEditorEllipseClass SvgtkEditorEllipseClass;

struct _SvgtkEditorEllipse {
	GObject parent_instance;
};

struct _SvgtkEditorEllipseClass {
	GObjectClass parent_class;
};

GType svgtk_editor_ellipse_get_type();
SvgtkEditorEllipse *svgtk_editor_ellipse_new();

G_END_DECLS

#endif /* __SVGTK_EDITOR_ELLIPSE_H__ */

