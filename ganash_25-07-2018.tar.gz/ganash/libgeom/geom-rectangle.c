/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 *
 * Canavs is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * gtk-foobar is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "geom-rectangle.h"


void geom_rectangle_merge(GeomRectangle* rectangle, const GeomRectangle* rect)
{
    int right = rectangle->x+rectangle->width;
    int bottom = rectangle->y+rectangle->height;
    int tmp;

    if (rectangle->x > rect->x) {
        rectangle->x = rect->x;
    }

    if (rectangle->y > rect->y) {
        rectangle->y = rect->y;
    }

    tmp = rect->x+rect->width;
    if (right > tmp) {
        rectangle->width = right - rectangle->x;
    } else {
        rectangle->width = tmp - rectangle->x;
    }

    tmp = rect->y+rect->height;
    if (bottom > tmp) {
        rectangle->height = bottom - rectangle->y;
    } else {
        rectangle->height = tmp - rectangle->y;
    }
}
