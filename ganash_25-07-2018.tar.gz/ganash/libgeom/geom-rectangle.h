/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * gtk-foobar
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 *
 * Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * gtk-foobar is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _GEOM_RECTANGLE_H_
#define _GEOM_RECTANGLE_H_


#define STRUCT_GEOM_RECTANGLE(name, type) typedef struct _GeomRectangle##name \
{ \
  type x; \
  type y; \
  type width; \
  type height; \
} GeomRectangle##name;


STRUCT_GEOM_RECTANGLE(Int , int)
STRUCT_GEOM_RECTANGLE(Float, float)
STRUCT_GEOM_RECTANGLE(, double)

void geom_rectangle_merge (GeomRectangle *rectangle, const GeomRectangle *rect);


#endif /* _GEOM_RECTANGLE_H_ */
