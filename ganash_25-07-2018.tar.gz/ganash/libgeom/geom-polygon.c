/*
 * geom-polygon.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdlib.h>

#include "geom-point.h"

#include "geom-polygon.h"
#include "geom-rectangle.h"

GeomPolygon*
geom_polygon_new(const GeomPoint* points, int length)
{
    GeomPolygon* polygon = (GeomPolygon*) malloc(sizeof(int) + sizeof(GeomPoint) * length);
    polygon->length = length;

    return polygon;
}

geom_polygon_free(GeomPolygon* polygon)
{
    free(polygon);
}

void geom_polygon_get_bounding_box (const GeomPolygon *polygon, GeomRectangle* bounding)
{
    int i;
    double v;

    /* compute left side */
    v = polygon->P[0].x;
    for (i=1; i<polygon->length; i++) {
        if (polygon->P[i].x < v)
            v = polygon->P[i].x;
    }
    bounding->x = v;

    /* compute right side */
    v = polygon->P[0].x;
    for (i=1; i<polygon->length; i++) {
        if (polygon->P[i].x > v)
            v = polygon->P[i].x;
    }
    bounding->width = v - bounding->x;

    /* compute top side */
    v = polygon->P[0].y;
    for (i=1; i<polygon->length; i++) {
        if (polygon->P[i].y > v)
            v = polygon->P[i].y;
    }
    bounding->y = v;

    /* compute bottom side */
    v = polygon->P[0].y;
    for (i=1; i<polygon->length; i++) {
        if (polygon->P[i].y < v)
            v = polygon->P[i].y;
    }
    bounding->height = bounding->y - v;
}
