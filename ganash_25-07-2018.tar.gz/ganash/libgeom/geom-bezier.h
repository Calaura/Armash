/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 *
 * Canvas is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Canvas is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _GEOM_BEZIER_H_
#define _GEOM_BEZIER_H_

#define GEOM_BEZIER_QUAD_LENGTH  3
#define GEOM_BEZIER_CUBIC_LENGTH 4

typedef struct _GeomBezier      GeomBezier;
typedef struct _GeomBezierQuad  GeomBezierQuad;
typedef struct _GeomBezierCubic GeomBezierCubic;

struct _GeomBezier
{
    int length;
    GeomPoint P[0];
};

struct _GeomBezierQuad
{
    int length;
    GeomPoint P0;
    GeomPoint P1;
    GeomPoint P2;
};

struct _GeomBezierCubic
{
    int length;
    GeomPoint P0;
    GeomPoint P1;
    GeomPoint P2;
    GeomPoint P3;
};

#define GEOM_BEZIER_QUAD_TO_POLYNOMIAL2(bezier, poly, property) \
poly.a = (bezier).P0.property - 2.0*(bezier).P1.property + (bezier).P2.property; \
poly.b = 2.0*((bezier).P1.property - (bezier).P0.property); \
poly.c = (bezier).P0.property;

#define GEOM_BEZIER_CUBIC_TO_POLYNOMIAL3(bezier, poly, property) \
(poly)->a = (bezier)->P3.property - 3.0*(bezier)->P2.property + 3.0*(bezier)->P1.property - (bezier)->P0.property; \
(poly)->b = 3.0*(bezier)->P2.property - 6.0*(bezier)->P1.property + 3.0*(bezier)->P0.property; \
(poly)->c = 3.0*((bezier)->P1.property - (bezier)->P0.property); \
(poly)->d = (bezier)->P0.property;


/*MathPolynomial* geom_bezier_to_polynomial (GeomBezier *bezier);*/
/*void geom_bezier_quad_to_polynomial (GeomBezierCubic *bezier, MathPolynomial* x, MathPolynomial* y);*/


void geom_bezier_quad_get_bounding_box (const GeomBezierQuad *bezier, GeomRectangle* bounding);
void geom_bezier_quad_get_bounding_box_controls (const GeomBezierQuad *bezier, GeomRectangle* bounding);
void geom_bezier_cubic_get_bounding_box_controls (const GeomBezierCubic *bezier, GeomRectangle* bounding);

/*GeomRectangleDouble* geom_bezier_get_bounding_box (GeomBezier *bezier);*/
/*GeomRectangleDouble* geom_bezier_get_bounding_box_approximate (GeomBezier *bezier);*/
void geom_bezier_cubic_eval (GeomBezierCubic *bezier, double t, GeomPoint *result);

/*
void geom_bezier_to_polynomial (GeomBezierCubic *bezier, MathPolynomial *polynomial);
void geom_bezier_quad_to_polynomial (GeomBezierCubic *bezier, MathPolynomial2 *polynomial);
void geom_bezier_cubic_to_polynomial (GeomBezierCubic *bezier, MathPolynomial3 *polynomial);
*/

#endif /* _GEOM_BEZIER_H_ */
