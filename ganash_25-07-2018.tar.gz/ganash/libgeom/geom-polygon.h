/*
 * geom-polygon.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef _GEOM_POLYGON_H_
#define _GEOM_POLYGON_H_

typedef struct _GeomPolygon  GeomPolygon;
typedef struct _GeomPolygon1 GeomPolygon1;
typedef struct _GeomPolygon2 GeomPolygon2;
typedef struct _GeomPolygon3 GeomPolygon3;

struct _GeomPolygon {
    int length;
    GeomPoint P[0];
};

#endif /* _GEOM_POLYGON_H_ */

