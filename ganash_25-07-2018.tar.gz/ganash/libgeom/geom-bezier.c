/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * Canvas
 * Copyright (C) Emile 2014 <emile@emile-eMachines-E510>
 *
 * Canavs is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * gtk-foobar is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "libmath/math-polynomial.h"

#include "geom-point.h"
#include "geom-polygon.h"
#include "geom-rectangle.h"
#include "geom-bezier.h"


/*
MathPolynomial* geom_bezier_to_polynomial (GeomBezier *bezier)
{
    if (bezier->degree==2) {
        return (MathPolynomial*) geom_bezier_quad_to_polynomial2((GeomBezierQuad*) bezier);
    }
    if (bezier->degree==3) {
        return (MathPolynomial*) geom_bezier_cubic_to_polynomial3((GeomBezierCubic*) bezier);
    }
}

MathPolynomial2* geom_bezier_quad_to_polynomial (GeomBezierQuad *bezier)
{

}
*/

/*void geom_bezier_cubic_to_polynomial3 (GeomBezierCubic *bezier, MathPolynomial3* x, MathPolynomial3* y)
{
    bezier->P0.x;
    bezier->P1.x;
    bezier->P2.x;
}
*/
void geom_bezier_cubic_eval (GeomBezierCubic *bezier, double t, GeomPoint *result)
{
    double tt = t*t;
    double ttt = tt * t;
    double t_1 = 1 - t;
    double t_2 = t_1*t_1;
    double t_3 = t_2*t_1;
    result->x = bezier->P0.x*t_3 + 3*bezier->P1.x*t*t_2 + 3*bezier->P2.x*tt*t_1 + bezier->P3.x*ttt;
    result->y = bezier->P0.y*t_3 + 3*bezier->P1.y*t*t_2 + 3*bezier->P2.y*tt*t_1 + bezier->P3.y*ttt;
    //result.z = bezier->P0.z*_t_3 + 3*bezier->P1.z*t*_t_2 + 3*bezier->P2.z*tt*_t_1 + bezier->P3.z*ttt;
}

void geom_bezier_quad_get_bounding_box_controls (const GeomBezierQuad *bezier, GeomRectangle* bounding)
{
    double v;

    /* compute left side */
    v = bezier->P0.x;
    if (bezier->P1.x < v)
        v = bezier->P1.x;
    if (bezier->P2.x < v)
        v = bezier->P2.x;
    bounding->x = v;

    /* compute right side */
    v = bezier->P0.x;
    if (bezier->P1.x > v)
        v = bezier->P1.x;
    if (bezier->P2.x > v)
        v = bezier->P2.x;
    bounding->width = v - bounding->x;

    /* compute top side */
    v = bezier->P0.y;
    if (bezier->P1.y > v)
        v = bezier->P1.y;
    if (bezier->P2.y > v)
        v = bezier->P2.y;
    bounding->y = v;

    /* compute bottom side */
    v = bezier->P0.y;
    if (bezier->P1.y < v)
        v = bezier->P1.y;
    if (bezier->P2.y < v)
        v = bezier->P2.y;
    bounding->height = bounding->y - v;
}

void geom_bezier_quad_get_bounding_box (const GeomBezierQuad *bezier, GeomRectangle* bounding)
{

#   define MAX_POINT 4
    struct _Polygon {
        int length;
        GeomPoint P[MAX_POINT];
    } polygon;
    MathPolynomial2 poly_x;
    MathPolynomial2 poly_y;
    MathPolynomial1 derivate_poly_x;
    MathPolynomial1 derivate_poly_y;
    double x, y, xx;
    int num;
    double r;

    GEOM_BEZIER_QUAD_TO_POLYNOMIAL2(*bezier, poly_x, x)
    GEOM_BEZIER_QUAD_TO_POLYNOMIAL2(*bezier, poly_y, y)
    MATH_POLYNOMIAL2_TO_DERIV(poly_x, derivate_poly_x)
    MATH_POLYNOMIAL2_TO_DERIV(poly_y, derivate_poly_y)


    polygon.length = 1;
    polygon.P[0].x = bezier->P0.x;
    polygon.P[0].y = bezier->P0.y;


    /* check for extrem point on x */
    if (poly_x.a!=0.0) {
        num = math_polynomial1_solve(derivate_poly_x.a, derivate_poly_x.b, &r);
        if (num) {/* and 0 < r < 1 */
            xx = r*r;
            x = poly_x.a*xx + poly_x.b*x + poly_x.c;
            y = poly_y.a*xx + poly_y.b*x + poly_y.c;

            polygon.P[polygon.length].x = x;
            polygon.P[polygon.length].y = y;
            polygon.length++;
        }
    }

    /* check for extrem point on y */
    if (poly_y.a!=0.0) {
        num = math_polynomial1_solve(derivate_poly_y.a, derivate_poly_y.b, &r);
        if (num) {
            xx = r*r;
            x = poly_x.a*xx + poly_x.b*x + poly_x.c;
            y = poly_y.a*xx + poly_y.b*x + poly_y.c;

            polygon.P[polygon.length].x = x;
            polygon.P[polygon.length].y = y;
            polygon.length++;
        }
    }

    polygon.P[polygon.length].x = bezier->P2.x;
    polygon.P[polygon.length].y = bezier->P2.y;
    polygon.length++;


    /* switch polygon.length ...*/
    geom_polygon_get_bounding_box((GeomPolygon*) &polygon, bounding);

}

void geom_bezier_cubic_get_bounding_box_controls (const GeomBezierCubic *bezier, GeomRectangle* bounding)
{
    double v;

    /* compute left side */
    v = bezier->P0.x;
    if (bezier->P1.x < v)
        v = bezier->P1.x;
    if (bezier->P2.x < v)
        v = bezier->P2.x;
    if (bezier->P3.x < v)
        v = bezier->P3.x;
    bounding->x = v;

    /* compute right side */
    v = bezier->P0.x;
    if (bezier->P1.x > v)
        v = bezier->P1.x;
    if (bezier->P2.x > v)
        v = bezier->P2.x;
    if (bezier->P3.x > v)
        v = bezier->P3.x;
    bounding->width = v - bounding->x;

    /* compute top side */
    v = bezier->P0.y;
    if (bezier->P1.y > v)
        v = bezier->P1.y;
    if (bezier->P2.y > v)
        v = bezier->P2.y;
    if (bezier->P3.y > v)
        v = bezier->P3.y;
    bounding->y = v;

    /* compute bottom side */
    v = bezier->P0.y;
    if (bezier->P1.y < v)
        v = bezier->P1.y;
    if (bezier->P2.y < v)
        v = bezier->P2.y;
    if (bezier->P3.y < v)
        v = bezier->P3.y;
    bounding->height = bounding->y - v;

}

/*
GeomRectangleDouble* geom_bezier_get_bounding_box (GeomBezier *bezier)
{

}

GeomRectangleDouble* geom_bezier_get_bounding_box_approximate (GeomBezier *bezier)
{

}
*/

/*
void geom_bezier_to_polynomial (GeomBezierCubic *bezier, MathPolynomial *polynomial)
{

}

void geom_bezier_quad_to_polynomial (GeomBezierCubic *bezier, MathPolynomial2 *polynomial)
{
    polynomial->a = bezier->P0.property - 2*bezier->P1.property + bezier->P2.property;
    polynomial->b = 2*(bezier->P1.property - bezier->P0.property);
    polynomial->c = bezier->P0.property;
}

void geom_bezier_cubic_to_polynomial (GeomBezierCubic *bezier, MathPolynomial3 *polynomial)
{

}
*/
