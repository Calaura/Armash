/*
 * style-sheet.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "style-sheet.h"


static void css_style_sheet_class_init(CssStyleSheetClass *klass);
static void css_style_sheet_init(CssStyleSheet *gobject);

G_DEFINE_TYPE (CssStyleSheet, css_style_sheet, G_TYPE_OBJECT)

static void
css_style_sheet_class_init(CssStyleSheetClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

//	css_style_sheet_parent_class = g_type_class_peek_parent (klass);
}

static void
css_style_sheet_init (CssStyleSheet *object)
{
}

CssStyleSheet *
css_style_sheet_new (void)
{
	return g_object_new (css_style_sheet_get_type (),
	                     NULL);
}

