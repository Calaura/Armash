/*
 * style-sheet.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __CSS_STYLE_SHEET_H__
#define __CSS_STYLE_SHEET_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define CSS_TYPE_STYLE_SHEET            (css_style_sheet_get_type())
#define CSS_STYLE_SHEET(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), CSS_TYPE_STYLE_SHEET, CssStyleSheet))
#define CSS_STYLE_SHEET_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), CSS_TYPE_STYLE_SHEET, CssStyleSheetClass))
#define CSS_IS_STYLE_SHEET(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), CSS_TYPE_STYLE_SHEET))
#define CSS_IS_STYLE_SHEET_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), CSS_TYPE_STYLE_SHEET))
#define CSS_STYLE_SHEET_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), CSS_TYPE_STYLE_SHEET, CssStyleSheetClass))

typedef struct _CssStyleSheet CssStyleSheet;
typedef struct _CssStyleSheetClass CssStyleSheetClass;

struct _CssStyleSheet {
	GObject parent_instance;
};

struct _CssStyleSheetClass {
	GObjectClass parent_class;
};

GType css_style_sheet_get_type();
CssStyleSheet *css_style_sheet_new();

G_END_DECLS

#endif /* __CSS_STYLE_SHEET_H__ */

