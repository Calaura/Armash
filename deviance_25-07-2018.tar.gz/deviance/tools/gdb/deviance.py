#!/usr/bin/python

from dumper import *

#execfile("/usr/share/glib-2.0/gdb/glib.py")
#exec(open("/home/gaulouis/local/Qt/Tools/QtCreator/share/qtcreator/debugger/glibtypes.py").read())
#import gdb
#import sys
#sys.path.insert(0, "/usr/share/glib-2.0/gdb/")

#import glib
#import gobject
#from gi.repository import GLib
#from gi.repository import GObject
#exec(open("/usr/share/glib-2.0/gdb/glib.py").read())
#exec(open("/usr/share/glib-2.0/gdb/gobject.py").read())
exec(open("/home/gaulouis/local/Qt/Tools/QtCreator/share/qtcreator/debugger/glibtypes.py").read())
exec(open("/home/gaulouis/local/Qt/Tools/QtCreator/share/qtcreator/debugger/cairotypes.py").read())


import logging
logging.basicConfig(filename='/home/gaulouis/Documents/log.txt',level=logging.DEBUG)
#logging.debug('qdump__GHashTable .........................')

# new GTypePrettyPrinter(x.address)->to_string()

# ---------------------------------------------------------------------
# DevianceStyleColor
# ---------------------------------------------------------------------
def qdump__DevianceStyleColor(d, value):
	name = g_type_name_from_instance(value.address)
	if name!=None and name!="DevianceStyleColor":
		obj = value.cast (gdb.lookup_type(name))
		d.putItem(obj)
	#else:
	#	d.putItem(value)

def qdump___DevianceStyleColor(d, value):
	qdump__DevianceStyleColor(d, value)

# ---------------------------------------------------------------------
# DevianceStyleColorScheme
# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
# DevianceStyleColorShade
# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
# DevianceStyleColorPalette
# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
# DevianceStyleColorStop
# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
# DevianceStyleColorMix
# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
# DevianceStyleColorHtml
# ---------------------------------------------------------------------

# ---------------------------------------------------------------------
# DevianceStyleImage
# ---------------------------------------------------------------------
def qdump__DevianceStyleImage(d, value):
	name = g_type_name_from_instance(value.address)
	if name!=None and name!="DevianceStyleImage":
		obj = value.cast (gdb.lookup_type(name))
		d.putItem(obj)
	else:
		d.putItem(value)

def qdump___DevianceStyleImage(d, value):
	qdump__DevianceStyleImage(d, value)

# ---------------------------------------------------------------------
# DevianceStyleBackground
# ---------------------------------------------------------------------

