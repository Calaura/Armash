/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * display-viewport.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "display.h"
#include "display-object.h"

#include "display-viewport.h"


static void deviance_display_viewport_class_init(DevianceDisplayViewportClass *klass);
static void deviance_display_viewport_init(DevianceDisplayViewport *gobject);

G_DEFINE_TYPE (DevianceDisplayViewport, deviance_display_viewport, G_TYPE_OBJECT)

static void
deviance_display_viewport_class_init(DevianceDisplayViewportClass *klass)
{
}

static void
deviance_display_viewport_init (DevianceDisplayViewport *object)
{
    object->x = 0;
    object->y = 0;
    object->width = 0;
    object->height = 0;
    object->cr = NULL;
}

DevianceDisplayViewport *
deviance_display_viewport_new (void)
{
    return g_object_new (DEVIANCE_TYPE_DISPLAY_VIEWPORT, NULL);
}

DevianceDisplayViewport *
deviance_display_viewport_new_full (cairo_t *cr, int x, int y, int width, int height)
{
    // TODO CHECK TYPES / cr state...
    DevianceDisplayViewport *viewport = g_object_new (DEVIANCE_TYPE_DISPLAY_VIEWPORT, NULL);
    viewport->cr = cr;
    viewport->x = x;
    viewport->y = y;
    viewport->width = width;
    viewport->height = height;
    return viewport;
}

void
deviance_display_viewport_set_root(DevianceDisplayViewport *viewport, DevianceDisplayObject*root)
{
    // ref
    viewport->root = root;
    viewport->root->viewport = viewport;
    viewport->root->parent = root;
}

void
deviance_display_viewport_render(DevianceDisplayViewport *viewport)
{
    deviance_display_object_render(viewport->root, NULL);
}
