/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-box-shadow.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_STYLE_BOX_SHADOW_H__
#define __DEVIANCE_STYLE_BOX_SHADOW_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define DEVIANCE_TYPE_STYLE_SHADOW            (deviance_style_shadow_get_type())
#define DEVIANCE_STYLE_SHADOW(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_STYLE_SHADOW, DevianceStyleShadow))
#define DEVIANCE_STYLE_SHADOW_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_STYLE_SHADOW, DevianceStyleShadowClass))
#define DEVIANCE_IS_STYLE_SHADOW(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_STYLE_SHADOW))
#define DEVIANCE_IS_STYLE_SHADOW_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_STYLE_SHADOW))
#define DEVIANCE_STYLE_SHADOW_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_STYLE_SHADOW, DevianceStyleShadowClass))

typedef struct _DevianceStyleShadowClass DevianceStyleShadowClass;

struct _DevianceStyleShadow {
    GObject parent_instance;

    gboolean inset;
    gdouble h;
    gdouble v;
    gdouble blur;
    gdouble spread;
    DevianceStyleColor *color;
    DevianceStyleImage *image;

};

struct _DevianceStyleShadowClass {
    GObjectClass parent_class;
};

GType deviance_style_shadow_get_type();
DevianceStyleShadow *deviance_style_shadow_new();
DevianceGraphicsData   *deviance_style_shadow_to_graphics_data_fill(DevianceStyleShadow *self, GtkRcStyle *style);


// ----------------------------------------------------------------------------

#define DEVIANCE_TYPE_STYLE_BOX_SHADOW            (deviance_style_box_shadow_get_type())
#define DEVIANCE_STYLE_BOX_SHADOW(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_STYLE_BOX_SHADOW, DevianceStyleBoxShadow))
#define DEVIANCE_STYLE_BOX_SHADOW_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_STYLE_BOX_SHADOW, DevianceStyleBoxShadowClass))
#define DEVIANCE_IS_STYLE_BOX_SHADOW(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_STYLE_BOX_SHADOW))
#define DEVIANCE_IS_STYLE_BOX_SHADOW_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_STYLE_BOX_SHADOW))
#define DEVIANCE_STYLE_BOX_SHADOW_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_STYLE_BOX_SHADOW, DevianceStyleBoxShadowClass))

typedef struct _DevianceStyleBoxShadowClass DevianceStyleBoxShadowClass;
typedef GList GList_DevianceStyleShadow;

struct _DevianceStyleBoxShadow {
	GObject parent_instance;

    DevianceStyleSelector *selectors;
    GList_DevianceStyleShadow *shadows;
};

struct _DevianceStyleBoxShadowClass {
	GObjectClass parent_class;
};

GType deviance_style_box_shadow_get_type();
DevianceStyleBoxShadow *deviance_style_box_shadow_new();
guint                   deviance_style_box_shadow_hash(gconstpointer  key);
gboolean                deviance_box_shadow_equal(gconstpointer  a, gconstpointer  b);
DevianceGraphicsData   *deviance_style_box_shadow_to_graphics_data_fill(DevianceStyleBoxShadow *self, GtkRcStyle *style, DevianceStyleBorder *border);

G_END_DECLS

#endif /* __DEVIANCE_STYLE_BOX_SHADOW_H__ */

