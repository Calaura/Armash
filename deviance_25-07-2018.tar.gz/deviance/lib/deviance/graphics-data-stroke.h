/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-data-stroke.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_GRAPHICS_DATA_STROKE_H__
#define __DEVIANCE_GRAPHICS_DATA_STROKE_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define DEVIANCE_TYPE_GRAPHICS_DATA_STROKE            (deviance_graphics_data_stroke_get_type())
#define DEVIANCE_GRAPHICS_DATA_STROKE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_GRAPHICS_DATA_STROKE, DevianceGraphicsDataStroke))
#define DEVIANCE_GRAPHICS_DATA_STROKE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_GRAPHICS_DATA_STROKE, DevianceGraphicsDataStrokeClass))
#define DEVIANCE_IS_GRAPHICS_DATA_STROKE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_GRAPHICS_DATA_STROKE))
#define DEVIANCE_IS_GRAPHICS_DATA_STROKE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_GRAPHICS_DATA_STROKE))
#define DEVIANCE_GRAPHICS_DATA_STROKE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_GRAPHICS_DATA_STROKE, DevianceGraphicsDataStrokeClass))

typedef struct _DevianceGraphicsDataStroke DevianceGraphicsDataStroke;
typedef struct _DevianceGraphicsDataStrokeClass DevianceGraphicsDataStrokeClass;

struct _DevianceGraphicsDataStroke {
	DevianceGraphicsData parent_instance;

    /*< public >*/
    cairo_pattern_t *pattern;
    double width;
    cairo_line_cap_t cap;
    cairo_line_join_t join;
    double miter_limit;
};

struct _DevianceGraphicsDataStrokeClass {
	DevianceGraphicsDataClass parent_class;
};

GType deviance_graphics_data_stroke_get_type();
DevianceGraphicsDataStroke *deviance_graphics_data_stroke_new();

G_END_DECLS

#endif /* __DEVIANCE_GRAPHICS_DATA_STROKE_H__ */

