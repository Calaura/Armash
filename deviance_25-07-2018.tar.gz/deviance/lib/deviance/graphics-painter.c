/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-painter.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "graphics.h"
#include "styles.h"

#include "style-color.h"
#include "style-color-scheme.h"

#include "graphics-painter.h"


static void deviance_graphics_painter_class_init(DevianceGraphicsPainterClass *klass);
static void deviance_graphics_painter_init(DevianceGraphicsPainter *gobject);

G_DEFINE_TYPE (DevianceGraphicsPainter, deviance_graphics_painter, G_TYPE_OBJECT)

static void
deviance_graphics_painter_class_init(DevianceGraphicsPainterClass *klass)
{
}

static void
deviance_graphics_painter_init (DevianceGraphicsPainter *object)
{
}

DevianceGraphicsPainter *
deviance_graphics_painter_new (void)
{
    return g_object_new (deviance_graphics_painter_get_type (),
                         NULL);
}

DevianceGraphicsPainter *
deviance_graphics_painter_new_from_style_color (DevianceStyleColor *color)
{
    DevianceGraphicsPainter *painter = g_object_new (DEVIANCE_TYPE_GRAPHICS_PAINTER, NULL);
    //cairo_pattern_t *pattern = deviance_style_color_to_graphics();

    return painter;
}

DevianceGraphicsPainter *
deviance_graphics_painter_new_from_style_linear_gradient (DevianceStyleColor *color)
{
    DevianceGraphicsPainter *painter = g_object_new (DEVIANCE_TYPE_GRAPHICS_PAINTER, NULL);
    //cairo_pattern_t *pattern = deviance_style_color_to_graphics();

    return painter;
}

DevianceGraphicsPainter *
deviance_graphics_painter_new_from_style_radial_gradient (DevianceStyleColor *color)
{
    DevianceGraphicsPainter *painter = g_object_new (DEVIANCE_TYPE_GRAPHICS_PAINTER, NULL);
    //cairo_pattern_t *pattern = deviance_style_color_to_graphics();

    return painter;
}

DevianceGraphicsPainter *
deviance_graphics_painter_new_from_style_bixmap (DevianceStyleColor *color)
{
    DevianceGraphicsPainter *painter = g_object_new (DEVIANCE_TYPE_GRAPHICS_PAINTER, NULL);
    //cairo_pattern_t *pattern = deviance_style_color_to_graphics();

    return painter;
}

void
deviance_graphics_painter_paint(DevianceGraphicsPainter *self)
{
    gboolean preserve;
    gpointer cr;
    DEVIANCE_GRAPHICS_PAINTER_GET_CLASS(self)->paint(self, cr, preserve);
}
