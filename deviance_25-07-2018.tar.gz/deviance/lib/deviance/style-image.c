/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-image.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <cairo.h>

#include "display.h"
#include "graphics.h"
#include "styles.h"
#include "style-color.h"
#include "graphics-data.h"

#include "style-image.h"


static void deviance_style_image_class_init(DevianceStyleImageClass *klass);
static void deviance_style_image_init(DevianceStyleImage *gobject);

G_DEFINE_TYPE (DevianceStyleImage, deviance_style_image, G_TYPE_OBJECT)

static void
deviance_style_image_class_init(DevianceStyleImageClass *klass)
{
}

static void
deviance_style_image_init (DevianceStyleImage *object)
{
}

DevianceStyleImage *
deviance_style_image_new (void)
{
	return g_object_new (deviance_style_image_get_type (),
	                     NULL);
}

DevianceGraphicsData*
deviance_style_image_to_graphics (DevianceStyleImage *style, GtkStyle *gtk_style)
{
    return DEVIANCE_STYLE_IMAGE_GET_CLASS(style)->to_graphics(style, gtk_style);
}

DevianceGraphicsData*
deviance_style_image_to_graphics_data_stroke (DevianceStyleImage *style, GtkStyle *gtk_style)
{
    return DEVIANCE_STYLE_IMAGE_GET_CLASS(style)->to_graphics_data_stroke(style, gtk_style);
}

DevianceGraphicsData*
deviance_style_image_to_graphics_data_fill (DevianceStyleImage *style, GtkStyle *gtk_style)
{
    return DEVIANCE_STYLE_IMAGE_GET_CLASS(style)->to_graphics_data_fill(style, gtk_style);
}

void
deviance_style_image_update_graphics (DevianceStyleImage *style, GtkStyle *gtk_style, DevianceDisplayObject *object, DevianceGraphicsData *data)
{
    return DEVIANCE_STYLE_IMAGE_GET_CLASS(style)->update_graphics(style, gtk_style, object, data);
}

DevianceStyleImage*
deviance_style_image_clone(DevianceStyleImage *self)
{
    return DEVIANCE_STYLE_IMAGE_GET_CLASS(self)->clone(self);
}

void
deviance_style_image_copy(DevianceStyleImage *self, DevianceStyleImage *image)
{
    DEVIANCE_STYLE_IMAGE_GET_CLASS(self)->copy(self, image);
}
