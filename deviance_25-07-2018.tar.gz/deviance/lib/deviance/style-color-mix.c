/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-color-mix.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "display.h"
#include "graphics.h"
#include "styles.h"

#include "style-color.h"
#include "style-color-mix.h"


static DevianceStyleColor *deviance_style_color_mix_class_style_color_clone(DevianceStyleColor *self);
static void                deviance_style_color_mix_class_style_color_copy(DevianceStyleColor *self, DevianceStyleColor *color);

static void deviance_style_color_mix_class_init(DevianceStyleColorMixClass *klass);
static void deviance_style_color_mix_init(DevianceStyleColorMix *gobject);

G_DEFINE_TYPE (DevianceStyleColorMix, deviance_style_color_mix, DEVIANCE_TYPE_STYLE_COLOR)


static DevianceGraphicsData*
deviance_style_color_mix_class_style_color_to_graphics(DevianceStyleColor *style_color, GtkStyle *gtk_style)
{
/*
    DevianceStyleColorScheme *style_color = DEVIANCE_STYLE_COLOR_SCHEME(self);

    DevianceGraphicsDataFill *data = deviance_graphics_data_fill_new();
    GdkColor gdk_color;
    gboolean success = gtk_style_lookup_color(style, style_color->scheme, &gdk_color);
    //g_print("TODO: GdkColor{%0.2X, %0.2X, %0.2X}\n", gdk_color.red/0x100, gdk_color.green/0x100, gdk_color.blue/0x100);
    //g_print("TODO: GdkColor{%f, %f, %f}\n", gdk_color.red/(float)0x10000, gdk_color.green/(float)0x10000, gdk_color.blue/(float)0x10000);
    cairo_pattern_t *pattern = cairo_pattern_create_rgb(gdk_color.red/(float)0x10000, gdk_color.green/(float)0x10000, gdk_color.blue/(float)0x10000);
    data->pattern = pattern;
    return data;
*/
    return DEVIANCE_STYLE_COLOR_CLASS(deviance_style_color_mix_parent_class)->to_graphics(style_color, gtk_style);
}

static void
deviance_style_color_mix_class_init(DevianceStyleColorMixClass *klass)
{
    DEVIANCE_STYLE_COLOR_CLASS(klass)->to_graphics = deviance_style_color_mix_class_style_color_to_graphics;
    DEVIANCE_STYLE_COLOR_CLASS(klass)->clone = deviance_style_color_mix_class_style_color_clone;
    DEVIANCE_STYLE_COLOR_CLASS(klass)->copy = deviance_style_color_mix_class_style_color_copy;
}

static void
deviance_style_color_mix_init (DevianceStyleColorMix *object)
{
    object->color_a = NULL;
    object->color_b = NULL;
    object->ratio = 1.0;
}

DevianceStyleColorMix *
deviance_style_color_mix_new (void)
{
	return g_object_new (deviance_style_color_mix_get_type (),
	                     NULL);
}

static void
deviance_style_color_mix_class_style_color_copy(DevianceStyleColor *self, DevianceStyleColor *color)
{
    DevianceStyleColorMix *self_mix = DEVIANCE_STYLE_COLOR_MIX(self);
    DevianceStyleColorMix *color_mix = DEVIANCE_STYLE_COLOR_MIX(color);

    if (color_mix->color_a) {
        deviance_style_color_copy(self_mix->color_a, color_mix->color_a);
    } else {
        color_mix->color_a = deviance_style_color_clone(self_mix->color_a);
    }
    if (color_mix->color_b) {
        deviance_style_color_copy(self_mix->color_b, color_mix->color_b);
    } else {
        color_mix->color_b = deviance_style_color_clone(self_mix->color_b);
    }
    color_mix->ratio = self_mix->ratio;

    DEVIANCE_STYLE_COLOR_CLASS(deviance_style_color_mix_parent_class)->copy(self, color);
}

static DevianceStyleColor*
deviance_style_color_mix_class_style_color_clone(DevianceStyleColor *self)
{
    DevianceStyleColorMix *clone = g_object_new (DEVIANCE_TYPE_STYLE_COLOR_MIX, NULL);
    deviance_style_color_mix_class_style_color_copy(self, DEVIANCE_STYLE_COLOR(clone));

    return clone;
}
