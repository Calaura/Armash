/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-image-gradient-linear.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "display.h"
#include "graphics.h"
#include "styles.h"

#include "style-color.h"
#include "style-color-stop.h"
#include "style-image.h"
#include "style-image-gradient.h"
#include "style-image-gradient-linear.h"

#include "graphics-data.h"
#include "graphics-data-fill.h"
#include "graphics-data-stroke.h"

#include "deviance_style.h"

static void deviance_style_image_gradient_linear_class_init(DevianceStyleImageGradientLinearClass *klass);
static void deviance_style_image_gradient_linear_init(DevianceStyleImageGradientLinear *gobject);

G_DEFINE_TYPE (DevianceStyleImageGradientLinear, deviance_style_image_gradient_linear, DEVIANCE_TYPE_STYLE_IMAGE_GRADIENT)

static DevianceGraphicsData*
deviance_style_image_gradient_linear_class_style_image_to_graphics(DevianceStyleImage *self, GtkStyle *gtk_style)
{
    //DevianceStyle *deviance_style = DEVIANCE_STYLE(gtk_style);
    DevianceStyleImageGradientLinear *gradient = DEVIANCE_STYLE_IMAGE_GRADIENT_LINEAR(self);


    DevianceGraphicsDataFill *data = deviance_graphics_data_fill_new();


    cairo_pattern_t *pattern = cairo_pattern_create_linear(0, 0, 0, 100);
#if 0
//    cairo_pattern_add_color_stop_rgb(pattern, 0, 0.263, 0.263, 0.243);
//    cairo_pattern_add_color_stop_rgb(pattern, 1, 0.204, 0.204, 0.220);
////
    cairo_pattern_add_color_stop_rgb(pattern, 0, 0.0, 0.0, 1.0);
    cairo_pattern_add_color_stop_rgb(pattern, 1, 1.0, 0.0, 0.0);
#else
    gint i;
    for (i=0; i<gradient->stops->len; i++) {
        DevianceStyleColorStop *color_stop = g_ptr_array_index(gradient->stops, i);
        // TODO Make the stuff
        deviance_style_color_to_graphics(color_stop->color, gtk_style);
        //g_print("ColorStop{color:Color{%f, %f, %f}, offset:%0.2f}: %d\n", color_stop->color->r, color_stop->color->g, color_stop->color->b, color_stop->offset, i);
        ///cairo_pattern_add_color_stop_rgb(pattern, (float)i, color_stop->color->r, color_stop->color->g, color_stop->color->b);
        cairo_pattern_add_color_stop_rgba(pattern, (float)i, color_stop->color->r, color_stop->color->g, color_stop->color->b, color_stop->color->a);
        //color_stop->offset
    }
#endif


    data->pattern = pattern;


    return data;
}

static DevianceGraphicsData*
deviance_style_image_gradient_linear_class_style_image_to_graphics_data_storke(DevianceStyleImage *self, GtkStyle *gtk_style)
{
    //DevianceStyle *deviance_style = DEVIANCE_STYLE(gtk_style);
    DevianceStyleImageGradientLinear *gradient = DEVIANCE_STYLE_IMAGE_GRADIENT_LINEAR(self);


    DevianceGraphicsDataStroke *data = deviance_graphics_data_stroke_new();


    cairo_pattern_t *pattern = cairo_pattern_create_linear(0, 0, 0, 100);
//    cairo_pattern_add_color_stop_rgb(pattern, 0, 0.263, 0.263, 0.243);
//    cairo_pattern_add_color_stop_rgb(pattern, 1, 0.204, 0.204, 0.220);
////
//    cairo_pattern_add_color_stop_rgb(pattern, 0, 0.0, 0.0, 1.0);
//    cairo_pattern_add_color_stop_rgb(pattern, 1, 1.0, 0.0, 0.0);

    gint i;
    for (i=0; i<gradient->stops->len; i++) {
        DevianceStyleColorStop *color_stop = g_ptr_array_index(gradient->stops, i);
        // TODO Make the stuff
        deviance_style_color_to_graphics(color_stop->color, gtk_style);
        //g_print("ColorStop{color:Color{%f, %f, %f}, offset:%0.2f}: %d\n", color_stop->color->r, color_stop->color->g, color_stop->color->b, color_stop->offset, i);
        ///cairo_pattern_add_color_stop_rgb(pattern, (float)i, color_stop->color->r, color_stop->color->g, color_stop->color->b);
        cairo_pattern_add_color_stop_rgba(pattern, (float)i, color_stop->color->r, color_stop->color->g, color_stop->color->b, color_stop->color->a);
        //color_stop->offset
    }



    data->pattern = pattern;


    return data;
}

static DevianceGraphicsData*
deviance_style_image_gradient_linear_class_style_image_to_graphics_data_fill(DevianceStyleImage *self, GtkStyle *gtk_style)
{
    //DevianceStyle *deviance_style = DEVIANCE_STYLE(gtk_style);
    DevianceStyleImageGradientLinear *gradient = DEVIANCE_STYLE_IMAGE_GRADIENT_LINEAR(self);


    DevianceGraphicsDataStroke *data = deviance_graphics_data_fill_new();


    cairo_pattern_t *pattern = cairo_pattern_create_linear(0, 0, 0, 20);
//    cairo_pattern_add_color_stop_rgb(pattern, 0, 0.263, 0.263, 0.243);
//    cairo_pattern_add_color_stop_rgb(pattern, 1, 0.204, 0.204, 0.220);
////
//    cairo_pattern_add_color_stop_rgb(pattern, 0, 0.0, 0.0, 1.0);
//    cairo_pattern_add_color_stop_rgb(pattern, 1, 1.0, 0.0, 0.0);

    gint i;
    for (i=0; i<gradient->stops->len; i++) {
        DevianceStyleColorStop *color_stop = g_ptr_array_index(gradient->stops, i);
        // TODO Make the stuff
        deviance_style_color_to_graphics(color_stop->color, gtk_style);
        //g_print("ColorStop{color:Color{%f, %f, %f}, offset:%0.2f}: %d\n", color_stop->color->r, color_stop->color->g, color_stop->color->b, color_stop->offset, i);
        ///cairo_pattern_add_color_stop_rgb(pattern, (float)i, color_stop->color->r, color_stop->color->g, color_stop->color->b);
        cairo_pattern_add_color_stop_rgba(pattern, (float)i, color_stop->color->r, color_stop->color->g, color_stop->color->b, color_stop->color->a);
        //color_stop->offset
    }



    data->pattern = pattern;


    return data;
}

static void
deviance_style_image_gradient_linear_class_style_image_update_graphics(DevianceStyleImage *self, GtkStyle *gtk_style, DevianceDisplayObject *object, DevianceGraphicsData *data)
{
    //DevianceStyle *deviance_style = DEVIANCE_STYLE(gtk_style);
    DevianceStyleImageGradientLinear *gradient = DEVIANCE_STYLE_IMAGE_GRADIENT_LINEAR(self);
    DevianceGraphicsDataFill *graphics_data = DEVIANCE_GRAPHICS_DATA_FILL(data);

    cairo_pattern_t *pattern = graphics_data->pattern;//cairo_pattern_create_linear(0, 0, 0, 20);
    //cairo_pattern_get_linear_points(pattern, &x0, &y0, &x1, &y1);

///    cairo_surface_t *surface = NULL;
///    cairo_pattern_get_surface(pattern, &surface);
///    cairo_image_surface_get_height(surface);
///    cairo_image_surface_get_width(surface);
///    cairo_pattern_set_matrix()

//    cairo_matrix_t matrix;
//    cairo_matrix_init_scale (&matrix, 1.0, 1.0);
//    cairo_pattern_set_matrix(pattern, &matrix);

#if 0
    gint i;
    for (i=0; i<gradient->stops->len; i++) {
        DevianceStyleColorStop *color_stop = g_ptr_array_index(gradient->stops, i);
        // TODO Make the stuff
        deviance_style_color_to_graphics(color_stop->color, gtk_style);
        //g_print("ColorStop{color:Color{%f, %f, %f}, offset:%0.2f}: %d\n", color_stop->color->r, color_stop->color->g, color_stop->color->b, color_stop->offset, i);
        cairo_pattern_add_color_stop_rgb(pattern, (float)i, color_stop->color->r, color_stop->color->g, color_stop->color->b);
        //color_stop->offset
    }
#endif

}

static DevianceStyleImage*
deviance_style_image_gradient_linear_clone(DevianceStyleImage *image)
{
    DevianceStyleImageGradientLinear *self = DEVIANCE_STYLE_IMAGE_GRADIENT_LINEAR(image);
    DevianceStyleImageGradientLinear *clone = g_object_new (DEVIANCE_TYPE_STYLE_IMAGE_GRADIENT_LINEAR, NULL);

    gsize i;
    for (i=0; i<self->stops->len; i++) {
        DevianceStyleColorStop *stop = g_ptr_array_index(self->stops, i);
        DevianceStyleColorStop *stop_clone = deviance_style_color_stop_clone(stop);
        g_ptr_array_add(clone->stops, stop_clone);
    }


    return DEVIANCE_STYLE_IMAGE(clone);
}

static void
deviance_style_image_gradient_linear_copy(DevianceStyleImage *self, DevianceStyleImage *image)
{
    DevianceStyleImageGradientLinear *self_linear = DEVIANCE_STYLE_IMAGE_GRADIENT_LINEAR(self);
    DevianceStyleImageGradientLinear *image_linear = DEVIANCE_STYLE_IMAGE_GRADIENT_LINEAR(image);

    g_printerr("deviance_style_image_gradient_linear_copy not implemented\n");
}

static void
deviance_style_image_gradient_linear_class_init(DevianceStyleImageGradientLinearClass *klass)
{
    DEVIANCE_STYLE_IMAGE_CLASS(klass)->to_graphics = deviance_style_image_gradient_linear_class_style_image_to_graphics;
    DEVIANCE_STYLE_IMAGE_CLASS(klass)->to_graphics_data_stroke = deviance_style_image_gradient_linear_class_style_image_to_graphics_data_storke;
    DEVIANCE_STYLE_IMAGE_CLASS(klass)->to_graphics_data_fill   = deviance_style_image_gradient_linear_class_style_image_to_graphics_data_fill;
    DEVIANCE_STYLE_IMAGE_CLASS(klass)->update_graphics = deviance_style_image_gradient_linear_class_style_image_update_graphics;
    DEVIANCE_STYLE_IMAGE_CLASS(klass)->clone = deviance_style_image_gradient_linear_clone;
    DEVIANCE_STYLE_IMAGE_CLASS(klass)->copy = deviance_style_image_gradient_linear_copy;
}

static void
deviance_style_image_gradient_linear_init (DevianceStyleImageGradientLinear *object)
{
    object->stops = g_ptr_array_new_full(2, (GDestroyNotify)g_object_unref);
}

DevianceStyleImageGradientLinear *
deviance_style_image_gradient_linear_new (void)
{
    return g_object_new (deviance_style_image_gradient_linear_get_type (),
                         NULL);
}


void
deviance_style_image_gradient_linear_add_color_stop (DevianceStyleImageGradientLinear *self, DevianceStyleColorStop *stop)
{
//    if (self->stops==NULL) {
//        self->stops = g_ptr_array_new_full(2, (GDestroyNotify)g_object_unref);
//    }
    g_ptr_array_add(self->stops, stop);
}
