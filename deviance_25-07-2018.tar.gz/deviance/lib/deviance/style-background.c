/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-background.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "display.h"
#include "graphics.h"
#include "styles.h"

#include "graphics-data.h"
#include "style-image.h"
#include "style-image-gradient.h"
#include "style-image-url.h"
#include "style-color.h"
#include "style-length.h"
#include "style-background.h"
#include "style-border.h"
#include "style-selector.h"

#include "deviance_rc_style.h"


enum
{
    STYLE_BACKGROUND_TOKEN_LEFT = 10000 + 1,
    STYLE_BACKGROUND_TOKEN_TOP,
    STYLE_BACKGROUND_TOKEN_RIGHT,
    STYLE_BACKGROUND_TOKEN_BOTTOM,

    STYLE_BACKGROUND_TOKEN_ID,
    STYLE_BACKGROUND_TOKEN_URL,
    STYLE_BACKGROUND_TOKEN_REPEAT,
    STYLE_BACKGROUND_TOKEN_NO_REPEAT,
    STYLE_BACKGROUND_TOKEN_REPEAT_X,
    STYLE_BACKGROUND_TOKEN_REPEAT_Y,

    STYLE_BACKGROUND_TOKEN_GRADIENT,
    STYLE_BACKGROUND_TOKEN_LINEAR,
    STYLE_BACKGROUND_TOKEN_RADIAL,

    STYLE_BACKGROUND_TOKEN_LAST
};

static struct
{
    const gchar *name;
    guint        token;
}
theme_symbols[] =
{

    { "@",                    STYLE_BACKGROUND_TOKEN_ID },

    { "left",                 STYLE_BACKGROUND_TOKEN_LEFT },
    { "top",                  STYLE_BACKGROUND_TOKEN_TOP },
    { "right",                STYLE_BACKGROUND_TOKEN_RIGHT },
    { "bottom",               STYLE_BACKGROUND_TOKEN_BOTTOM },

    /* stuff to ignore */
    { "url",                  STYLE_BACKGROUND_TOKEN_URL },
    { "repeat",               STYLE_BACKGROUND_TOKEN_REPEAT },
    { "no-repeat",            STYLE_BACKGROUND_TOKEN_NO_REPEAT },
    { "repeat-x",             STYLE_BACKGROUND_TOKEN_REPEAT_X },
    { "repeat-y",             STYLE_BACKGROUND_TOKEN_REPEAT_Y },

    { "gradient",             STYLE_BACKGROUND_TOKEN_GRADIENT },
    { "linear",               STYLE_BACKGROUND_TOKEN_LINEAR },
    { "radial",               STYLE_BACKGROUND_TOKEN_RADIAL }
};

static void deviance_style_background_class_init(DevianceStyleBackgroundClass *klass);
static void deviance_style_background_init(DevianceStyleBackground *gobject);

G_DEFINE_TYPE (DevianceStyleBackground, deviance_style_background, G_TYPE_OBJECT)

static void
deviance_style_background_class_init(DevianceStyleBackgroundClass *klass)
{
}

static void
deviance_style_background_init (DevianceStyleBackground *object)
{
    object->color = NULL;
    object->image = NULL;

    object->selectors = NULL;
}

DevianceStyleBackground *
deviance_style_background_new (void)
{
    return g_object_new (DEVIANCE_TYPE_STYLE_BACKGROUND, NULL);
}

#if 0
guint
deviance_style_background_parse (GtkRcStyle *rc_style,
                        GtkSettings  *settings,
                        GScanner   *scanner)
{
    static GQuark scope_id = 0;
    DevianceRcStyle *deviance_style = DEVIANCE_RC_STYLE (rc_style);

    guint old_scope;
    guint token;
    guint i;

    /* Set up a new scope in this scanner. */

    if (!scope_id)
        scope_id = g_quark_from_string("deviance_css_engine");

    /* If we bail out due to errors, we *don't* reset the scope, so the
    * error messaging code can make sense of our tokens.
    */
    old_scope = g_scanner_set_scope(scanner, scope_id);

    /* Now check if we already added our symbols to this scope
    * (in some previous call to deviance_rc_style_parse for the
    * same scanner.
    */

    if (!g_scanner_lookup_symbol(scanner, theme_symbols[0].name))
    {
        g_scanner_freeze_symbol_table(scanner);
        for (i = 0; i < G_N_ELEMENTS (theme_symbols); i++)
            g_scanner_scope_add_symbol(scanner, scope_id, theme_symbols[i].name, GINT_TO_POINTER(theme_symbols[i].token));
        g_scanner_thaw_symbol_table(scanner);
    }

    /* We're ready to go, now parse the top level */
    token = g_scanner_peek_next_token(scanner);
    while (token != G_TOKEN_RIGHT_CURLY)
    {
        switch (token)
        {
            case STYLE_BACKGROUND_TOKEN_ID:
            case STYLE_BACKGROUND_TOKEN_URL:
            case STYLE_BACKGROUND_TOKEN_REPEAT:
            case STYLE_BACKGROUND_TOKEN_NO_REPEAT:
            case STYLE_BACKGROUND_TOKEN_REPEAT_X:
            case STYLE_BACKGROUND_TOKEN_REPEAT_Y:
            case STYLE_BACKGROUND_TOKEN_LEFT:
            case STYLE_BACKGROUND_TOKEN_TOP:
            case STYLE_BACKGROUND_TOKEN_RIGHT:
            case STYLE_BACKGROUND_TOKEN_BOTTOM:
            case STYLE_BACKGROUND_TOKEN_GRADIENT:
            case STYLE_BACKGROUND_TOKEN_LINEAR:
            case STYLE_BACKGROUND_TOKEN_RADIAL:
//                token = theme_parse_boolean (settings, scanner, &deviance_style->animation);
//                deviance_style->bflags |= MRN_FLAG_ANIMATION;
                break;
            default:
                g_scanner_get_next_token(scanner);
                token = G_TOKEN_RIGHT_CURLY;
                break;
        }

        if (token != G_TOKEN_NONE)
            return token;

        token = g_scanner_peek_next_token(scanner);
    }

    g_scanner_get_next_token(scanner);

    g_scanner_set_scope(scanner, old_scope);

    return G_TOKEN_NONE;
}
#endif

guint
deviance_style_background_hash(gconstpointer  key)
{
    DevianceStyleBackground *self = DEVIANCE_STYLE_BACKGROUND(key);
    guint hash = deviance_style_selector_to_int(self->selectors);
    return hash;
}

gboolean
deviance_style_background_equal(gconstpointer  a, gconstpointer  b)
{
    g_print("deviance_style_background_equal\n");
    DevianceStyleBackground *self = DEVIANCE_STYLE_BACKGROUND(a);
    DevianceStyleBackground *background = DEVIANCE_STYLE_BACKGROUND(b);
    if (a==b) {
        return TRUE;
    }
    guint hash = deviance_style_background_hash(background);
    guint self_hash = deviance_style_background_hash(self);
    if (hash==self_hash) {
        return TRUE;
    }

    return FALSE;
}


DevianceStyleState
deviance_style_background_get_first_state(DevianceStyleBackground *self)
{
    return deviance_style_selector_get_state(self->selectors);
}

gboolean
deviance_style_background_has_state(DevianceStyleBackground *self, DevianceStyleState state)
{
    return FALSE;
}

void
deviance_style_background_copy(DevianceStyleBackground *self, DevianceStyleBackground *background)
{
    DevianceStyleBackground *copy;

    return copy;
}

DevianceStyleBackground*
deviance_style_background_clone(DevianceStyleBackground *self)
{
    g_return_val_if_fail(DEVIANCE_IS_STYLE_BACKGROUND(self), NULL);
    DevianceStyleBackground *clone = deviance_style_background_new();
    if (self->selectors) {
        clone->selectors = deviance_style_selector_clone(self->selectors);
    }
    if (self->color) {
        clone->color = deviance_style_color_clone(self->color);
    }
    if (self->image) {
        clone->image = deviance_style_image_clone(self->image);
    }

    return clone;
}


void
deviance_style_background_merge(DevianceStyleBackground *self, DevianceStyleBackground *background)
{
    g_return_val_if_fail(DEVIANCE_IS_STYLE_BACKGROUND(self), NULL);

    if (self->color && !background->color->is_set) {
        deviance_style_color_copy(self->color, background->color);
    }
    if (self->image /*&& !background->image->is_set*/) {
        deviance_style_image_copy(self->image, background->image);
    }

    return background;
}
