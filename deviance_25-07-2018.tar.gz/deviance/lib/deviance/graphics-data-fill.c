/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-data-fill.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <cairo/cairo.h>

#include "graphics.h"
#include "styles.h"

#include "style-color.h"
#include "style-color-scheme.h"
#include "graphics-painter.h"
#include "graphics.h"
#include "graphics-data.h"

#include "graphics-data-fill.h"


static void deviance_graphics_data_fill_class_init(DevianceGraphicsDataFillClass *klass);
static void deviance_graphics_data_fill_init(DevianceGraphicsDataFill *gobject);

G_DEFINE_TYPE (DevianceGraphicsDataFill, deviance_graphics_data_fill, DEVIANCE_TYPE_GRAPHICS_DATA)

static void
deviance_graphics_data_fill_class_graphics_data_draw(DevianceGraphicsData *data, cairo_t *cr, gboolean preserve)
{
    DevianceGraphicsDataFill *self = DEVIANCE_GRAPHICS_DATA_FILL(data);

    //self->pattern = cairo_pattern_create_rgb(0.5, 0.5, 0.5);
    cairo_pattern_type_t type = cairo_pattern_get_type(self->pattern);
    switch(type)
    {
    case CAIRO_PATTERN_TYPE_SOLID:
        cairo_set_source(cr, self->pattern);
        break;
    case CAIRO_PATTERN_TYPE_SURFACE:
        cairo_set_source(cr, self->pattern);
        break;
    case CAIRO_PATTERN_TYPE_LINEAR:
        cairo_set_source(cr, self->pattern);
        break;
    case CAIRO_PATTERN_TYPE_RADIAL:
        cairo_set_source(cr, self->pattern);
        break;
    case CAIRO_PATTERN_TYPE_MESH:
        break;
    case CAIRO_PATTERN_TYPE_RASTER_SOURCE:
        break;
    default :
        break;
    }
//    int count;
//    cairo_pattern_get_color_stop_count(self->pattern, &count);
    //g_print("pattern_type: %d(%d); %d\n", type, CAIRO_PATTERN_TYPE_LINEAR, count);
    cairo_set_fill_rule(cr, self->rule);

    preserve ? cairo_fill_preserve(cr) : cairo_fill(cr);
}

#include <math.h>
double
polar_module(cairo_rectangle_t *rect)
{
    double dx = rect->width - rect->x;
    double dy = rect->height - rect->y;

    double module = sqrt(dx*dx + dy*dy);
    return module;
}

double
polar_argument(cairo_rectangle_t *rect)
{
    double dx = rect->width;
    double dy = rect->height;

    double argument = atan2(dy, dx);
    return argument;

}

static void
deviance_graphics_data_fill_class_graphics_data_update_resize(DevianceGraphicsData *data, cairo_rectangle_t *rectangle)
{
    DevianceGraphicsDataFill *self = DEVIANCE_GRAPHICS_DATA_FILL(data);

    // update_resize
    cairo_pattern_type_t type = cairo_pattern_get_type(self->pattern);
    switch (type)
    {
    case CAIRO_PATTERN_TYPE_SOLID:
        break;
    case CAIRO_PATTERN_TYPE_LINEAR:
        {
#if 0
            cairo_matrix_t m;
            cairo_matrix_init_identity(&m);
            cairo_pattern_get_matrix(self->pattern, &m);
            cairo_rectangle_t rect;
            cairo_pattern_get_linear_points(self->pattern, &rect.x, &rect.y, &rect.width, &rect.height);
            rect.width -= rect.x;
            rect.height -= rect.y;
            double module = polar_module(&rect);
            double argument = polar_argument(&rect);
            double module_rectangle = polar_module(rectangle);
            double argument_rectangle = polar_argument(rectangle);
            //cairo_surface_t *surface;
            //cairo_pattern_get_surface(self->pattern, &surface);
            m.x0;
            cairo_matrix_t matrix;
            cairo_matrix_init_identity(&matrix);
            //cairo_matrix_translate(&matrix, rectangle->x-rect.x, rectangle->y-rect.y);
            //cairo_matrix_rotate(&matrix, argument_rectangle-argument);
            cairo_matrix_scale(&matrix, 1, 100.0/rectangle->height);
            //cairo_matrix_scale(&matrix, rectangle->width==0? 0: rect.width/rectangle->width, rect.height/rectangle->height);
            cairo_pattern_set_matrix(self->pattern, &matrix);

#else
            cairo_pattern_t *pattern = cairo_pattern_create_linear(rectangle->x, rectangle->y, rectangle->x, rectangle->y+rectangle->height);
            gint count;
            cairo_pattern_get_color_stop_count(self->pattern, &count);
            gdouble offset, red, green, blue, alpha;
            gint i;
            for(i=0; i<count; i++) {
                cairo_pattern_get_color_stop_rgba(self->pattern, i, &offset, &red, &green, &blue, &alpha);
                cairo_pattern_add_color_stop_rgba(pattern, offset, red, green, blue, alpha);
            }
            self->pattern = pattern;
#endif


        }
        break;
    case CAIRO_PATTERN_TYPE_RADIAL:
    case CAIRO_PATTERN_TYPE_MESH:
    case CAIRO_PATTERN_TYPE_SURFACE:
    case CAIRO_PATTERN_TYPE_RASTER_SOURCE:
    default:
        break;
    }

}

static void
deviance_graphics_data_fill_class_init(DevianceGraphicsDataFillClass *klass)
{
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->draw = deviance_graphics_data_fill_class_graphics_data_draw;
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->update_resize = deviance_graphics_data_fill_class_graphics_data_update_resize;
}

static void
deviance_graphics_data_fill_init (DevianceGraphicsDataFill *object)
{
    object->pattern = NULL; //cairo_pattern_create_rgb(0.5, 0.5, 0.5);
    object->rule = CAIRO_FILL_RULE_EVEN_ODD;
}

DevianceGraphicsDataFill *
deviance_graphics_data_fill_new (void)
{
    return g_object_new (deviance_graphics_data_fill_get_type (),
                         NULL);
}
