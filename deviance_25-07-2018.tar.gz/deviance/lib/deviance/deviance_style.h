/* Deviance theme engine
 * Copyright (C) 2006-2007-2008-2009 Andrea Cimitan
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <gtk/gtkstyle.h>

#ifndef DEVIANCE_STYLE_H
#define DEVIANCE_STYLE_H

#include "animation.h"
#include "deviance_types.h"


typedef struct _DevianceStyle DevianceStyle;
typedef struct _DevianceStyleClass DevianceStyleClass;

#define DEVIANCE_TYPE_STYLE              (deviance_style_get_type())
#define DEVIANCE_STYLE(object)           (G_TYPE_CHECK_INSTANCE_CAST ((object), DEVIANCE_TYPE_STYLE, DevianceStyle))
#define DEVIANCE_STYLE_CLASS(klass)      (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_STYLE, DevianceStyleClass))
#define DEVIANCE_IS_STYLE(object)        (G_TYPE_CHECK_INSTANCE_TYPE ((object), DEVIANCE_TYPE_STYLE))
#define DEVIANCE_IS_STYLE_CLASS(klass)   (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_STYLE))
#define DEVIANCE_STYLE_GET_CLASS(obj)    (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_STYLE, DevianceStyleClass))

struct _DevianceStyle
{
	GtkStyle parent_instance;

    // :last-child
    // :last-of-type
    // :first-child {}
    // :nth-child(2) {}
    // :nth-child(odd) {}
    // :nth-child(even) {}
    //? = hash_table;
    //DevianceDisplayContainer *display[?];

    GHashTable      *display;
    DevianceRcStyle *rc;


    DevianceDisplayObject    *normal_background_color;
    DevianceDisplayObject    *normal_background_image;
    DevianceDisplayObject    *normal_border_color;
    DevianceDisplayObject    *normal_border_image;
    DevianceDisplayObject    *normal_box_shadow;
    DevianceDisplayObject    *normal_text_shadow;
    DevianceDisplayObject    *normal_box_glass;
/*  ========================================== */
    DevianceDisplayContainer *normal_display;

    DevianceDisplayObject    *active_background_color;
    DevianceDisplayObject    *active_background_image;
    DevianceDisplayObject    *active_border_color;
    DevianceDisplayObject    *active_border_image;
    DevianceDisplayObject    *active_box_shadow;
    DevianceDisplayObject    *active_text_shadow;
    DevianceDisplayObject    *active_box_glass;
/*  ========================================== */
    DevianceDisplayContainer *active_display;

    DevianceDisplayObject    *prelight_background_color;
    DevianceDisplayObject    *prelight_background_image;
    DevianceDisplayObject    *prelight_border_color;
    DevianceDisplayObject    *prelight_border_image;
    DevianceDisplayObject    *prelight_box_shadow;
    DevianceDisplayObject    *prelight_text_shadow;
    DevianceDisplayObject    *prelight_box_glass;
/*  ========================================== */
    DevianceDisplayContainer *prelight_display;

    DevianceDisplayObject    *selected_background_color;
    DevianceDisplayObject    *selected_background_image;
    DevianceDisplayObject    *selected_border_color;
    DevianceDisplayObject    *selected_border_image;
    DevianceDisplayObject    *selected_box_shadow;
    DevianceDisplayObject    *selected_text_shadow;
    DevianceDisplayObject    *selected_box_glass;
/*  ========================================== */
    DevianceDisplayContainer *selected_display;

    DevianceDisplayObject    *insensitive_background_color;
    DevianceDisplayObject    *insensitive_background_image;
    DevianceDisplayObject    *insensitive_border_color;
    DevianceDisplayObject    *insensitive_border_image;
    DevianceDisplayObject    *insensitive_box_shadow;
    DevianceDisplayObject    *insensitive_text_shadow;
    DevianceDisplayObject    *insensitive_box_glass;
/*  ========================================== */
    DevianceDisplayContainer *insensitive_display;

    DevianceColors colors;

	double   border_shades[2];
	double   contrast;
	double   glow_shade;
	double   gradient_shades[4];
	double   highlight_shade;
	double   lightborder_shade;
	double   prelight_shade;
	double   shadow_shades[2];
	double   text_shade;
	double   trough_border_shades[2];
	double   trough_shades[2];

	guint8   arrowstyle;
	guint8   cellstyle;
	guint8   comboboxstyle;
	guint8   expanderstyle;
	guint8   focusstyle;
	guint8   glazestyle;
	guint8   glowstyle;
	guint8   handlestyle;
	guint8   lightborderstyle;
	guint8   listviewheaderstyle;
	guint8   listviewstyle;
	guint8   menubaritemstyle;
	guint8   menubarstyle;
	guint8   menuitemstyle;
	guint8   menustyle;
	guint8   progressbarstyle;
	guint8   reliefstyle;
	guint8   roundness;
	guint8   scrollbarstyle;
	guint8   separatorstyle;
	guint8   sliderstyle;
	guint8   spinbuttonstyle;
	guint8   stepperstyle;
	guint8   textstyle;
	guint8   toolbarstyle;

	gboolean animation;
	gboolean colorize_scrollbar;
	gboolean has_border_colors;
	gboolean has_default_button_color;
	gboolean has_focus_color;
	gboolean has_gradient_colors;
	gboolean rgba;

	GdkColor border_colors[2];
	GdkColor default_button_color;
	GdkColor focus_color;
    GdkColor gradient_colors[4];

};

struct _DevianceStyleClass
{
	GtkStyleClass parent_class;

    DevianceStyleFunctions style_functions[MRN_NUM_DRAW_STYLES];
};

GType deviance_style_get_type (void);
// virtual deviance_style_render();
void deviance_style_register_types (GTypeModule *module);


#endif /* DEVIANCE_STYLE_H */
