/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DVN_STYLE_H__
#define __DVN_STYLE_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS


//#include "graphics.h"
//#include "display.h"
//#include "style.h"

typedef enum _DevianceStyleState DevianceStyleState;
typedef enum _DevianceStyleChild DevianceStyleChild;
#define DEVIANCE_STYLE_ALL_STATE DEVIANCE_STYLE_NORMAL_STATE // au lieu de ALL_STATE => DEFAULT_STATE
enum _DevianceStyleState { // 3bits 0-7
    DEVIANCE_STYLE_NORMAL_STATE      = GTK_STATE_NORMAL,
    DEVIANCE_STYLE_ACTIVE_STATE      = GTK_STATE_ACTIVE,
    DEVIANCE_STYLE_PRELIGHT_STATE    = GTK_STATE_PRELIGHT,
    DEVIANCE_STYLE_SELECTED_STATE    = GTK_STATE_SELECTED,
    DEVIANCE_STYLE_INSENSITIVE_STATE = GTK_STATE_INSENSITIVE,

    DEVIANCE_STYLE_NUM_STATES = 5
};

enum _DevianceStyleChild { // 4bits 0-7
    DEVIANCE_STYLE_ALL_CHILD     = 0,
    DEVIANCE_STYLE_FIRST_CHILD   = 1,
    DEVIANCE_STYLE_ODD_CHILD     = 2,
    DEVIANCE_STYLE_EVEN_CHILD    = 3,
    DEVIANCE_STYLE_NTH_CHILD     = 4,
    DEVIANCE_STYLE_FORMULA_CHILD = 5,
    DEVIANCE_STYLE_LAST_CHILD    = 6,

    DEVIANCE_STYLE_NUM_CHILDS    = 7
};
// :first-child:hover
// :nth-child(odd|even|[0-9]*|3n+0):active=
// last-child
typedef struct _DevianceStyleSelectorHash DevianceStyleSelectorHash;// van it be removed
typedef struct _DevianceStyleSelector DevianceStyleSelector;

typedef struct _DevianceStyleLength              DevianceStyleLength;
typedef struct _DevianceStyleImage               DevianceStyleImage;
typedef struct _DevianceStyleImageUrl            DevianceStyleImageUrl;
typedef struct _DevianceStyleImageGradient       DevianceStyleImageGradient;
typedef struct _DevianceStyleImageGradientRadial DevianceStyleImageGradientRadial;
typedef GPtrArray                                GPtrArray_StyleColorStop;
typedef struct _DevianceStyleImageGradientLinear DevianceStyleImageGradientLinear;
typedef struct _DevianceStyleColor               DevianceStyleColor;
typedef struct _DevianceStyleColorStop           DevianceStyleColorStop;
typedef struct _DevianceStyleColorShade          DevianceStyleColorShade;
typedef struct _DevianceStyleColorMix            DevianceStyleColorMix;
typedef struct _DevianceStyleColorScheme         DevianceStyleColorScheme;
typedef struct _DevianceStyleColorPalette        DevianceStyleColorPalette;
typedef struct _DevianceStyleColorHtml           DevianceStyleColorHtml;
typedef struct _DevianceStyleBorderImage         DevianceStyleBorderImage;
typedef struct _DevianceStyleBorder              DevianceStyleBorder;
typedef struct _DevianceStyleBackground          DevianceStyleBackground;
typedef struct _DevianceStyleShadow              DevianceStyleShadow;
typedef struct _DevianceStyleBoxShadow           DevianceStyleBoxShadow;
typedef struct _DevianceStyleTextShadow          DevianceStyleTextShadow;

typedef struct _DevianceRcStyle                  DevianceRcStyle;

//#include "style-image.h"
//#include "style-image-gradient.h"
//#include "style-image-url.h"
//#include "style-color.h"
//#include "style-background.h"


G_END_DECLS

#endif /* __DVN_STYLE_H__ */

