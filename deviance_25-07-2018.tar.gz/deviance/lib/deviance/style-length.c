/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-length.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "styles.h"

#include "style-length.h"


static void deviance_style_length_class_init(DevianceStyleLengthClass *klass);
static void deviance_style_length_init(DevianceStyleLength *gobject);

G_DEFINE_TYPE (DevianceStyleLength, deviance_style_length, G_TYPE_OBJECT)

static void
deviance_style_length_class_init(DevianceStyleLengthClass *klass)
{
}

static void
deviance_style_length_init (DevianceStyleLength *object)
{
    object->is_set=FALSE;

    object->context = NULL;
    object->unit = DEVIANCE_STYLE_LENGTH_TYPE_PX;
    object->value = 0.0;
}

DevianceStyleLength *
deviance_style_length_new (void)
{
	return g_object_new (deviance_style_length_get_type (),
	                     NULL);
}
void
deviance_style_length_copy (DevianceStyleLength *self, DevianceStyleLength *length)
{
    length->context = self->context;
    length->unit = self->unit;
    length->value = self->value;

    length->is_set = self->is_set;
}

DevianceStyleLength*
deviance_style_length_clone (DevianceStyleLength *self)
{
    DevianceStyleLength *clone = g_object_new (DEVIANCE_TYPE_STYLE_LENGTH, NULL);
    deviance_style_length_copy (self, clone);

    return clone;
}


gdouble
deviance_style_length_get_value(DevianceStyleLength *length, gpointer context)
{
    return length->value;
}
