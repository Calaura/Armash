/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * display.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_DISPLAY_H__
#define __DEVIANCE_DISPLAY_H__

#include <glib-object.h>


G_BEGIN_DECLS

typedef GPtrArray                        GArray_GraphicsData;

typedef struct _DevianceDisplayObject    DevianceDisplayObject;
typedef struct _DevianceDisplayContainer DevianceDisplayContainer;
typedef struct _DevianceDisplayShape     DevianceDisplayShape;
typedef struct _DevianceDisplayRectangle DevianceDisplayRectangle;

typedef struct _DevianceDisplayViewport  DevianceDisplayViewport;
typedef struct _DevianceDisplayStyle     DevianceDisplayStyle;
typedef struct _DevianceDisplayState     DevianceDisplayState;


/*
#define DEVIANCE_TYPE_DISPLAY            (deviance_display_get_type())
#define DEVIANCE_DISPLAY(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_DISPLAY, DevianceDisplay))
#define DEVIANCE_DISPLAY_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_DISPLAY, DevianceDisplayClass))
#define DEVIANCE_IS_DISPLAY(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_DISPLAY))
#define DEVIANCE_IS_DISPLAY_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_DISPLAY))
#define DEVIANCE_DISPLAY_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_DISPLAY, DevianceDisplayClass))

typedef struct _DevianceDisplay DevianceDisplay;
typedef struct _DevianceDisplayClass DevianceDisplayClass;

struct _DevianceDisplay {
    DevianceDisplayObject parent_instance;

    //DevianceDisplayStyle *default;

    DevianceDisplayStyle *normal;
    DevianceDisplayStyle *active;
    DevianceDisplayStyle *prelight;
    DevianceDisplayStyle *insensitive;
}


struct _DevianceDisplayClass {
	GObjectClass parent_class;
};

GType deviance_display_get_type();
DevianceDisplay *deviance_display_new();
*/

G_END_DECLS

#endif /* __DEVIANCE_DISPLAY_H__ */

