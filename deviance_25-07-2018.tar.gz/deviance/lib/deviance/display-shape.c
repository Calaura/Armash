/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * display-shape.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <math.h>

#include "graphics.h"
#include "display.h"
#include "styles.h"

#include "style-color.h"
//#include "style-color.h"

#include "graphics-data.h"
#include "graphics-data-path.h"
#include "graphics-painter.h"

#include "display-viewport.h"
#include "display-object.h"
#include "display-container.h"

#include "display-shape.h"


static void deviance_display_shape_class_init(DevianceDisplayShapeClass *klass);
static void deviance_display_shape_init(DevianceDisplayShape *gobject);

G_DEFINE_TYPE (DevianceDisplayShape, deviance_display_shape, DEVIANCE_TYPE_DISPLAY_OBJECT)
static void
deviance_display_shape_class_object_render(DevianceDisplayObject *self, gpointer data)
{
    int i;
    gboolean preserve = TRUE;
    DevianceDisplayShape *shape = DEVIANCE_DISPLAY_SHAPE(self);
    if(shape->datas==NULL)
        return;
    int len = shape->datas->len;
    for (i=0; i<len; i++) {
        DevianceGraphicsData *graphics_data = g_ptr_array_index(DEVIANCE_DISPLAY_SHAPE(self)->datas, i);
        deviance_graphics_data_draw(graphics_data, self->viewport->cr, preserve);
    }
}

static void
deviance_display_shape_class_object_update(DevianceDisplayObject *self, gpointer data)
{
    DevianceDisplayShape *shape = DEVIANCE_DISPLAY_SHAPE(self);
    //DEVIANCE_DISPLAY_SHAPE(self)->border_path_factory = NULL;
    //DEVIANCE_DISPLAY_SHAPE(self)->fill_path_factory = NULL;
    // = deviance_draw_factory_rounded_rectangle(self->viewport);
    // queue_resize
//    DevianceGraphicsDataPath *border_path = shape->border_path_factory(self->viewport->x, self->viewport->y, self->viewport->width, self->viewport->height, 4, 4, 4, 4);
//    DEVIANCE_DISPLAY_SHAPE(self)->border_path = border_path;
//    DEVIANCE_DISPLAY_SHAPE(self)->datas->pdata[0] = border_path;
    g_warning("%s", "::update Not implemented");
}


static void
deviance_display_shape_class_init(DevianceDisplayShapeClass *klass)
{
    DEVIANCE_DISPLAY_OBJECT_CLASS(klass)->render = deviance_display_shape_class_object_render;
    DEVIANCE_DISPLAY_OBJECT_CLASS(klass)->update = deviance_display_shape_class_object_update;
}

static void
deviance_display_shape_init (DevianceDisplayShape *object)
{
    object->path  = NULL;
    object->datas = NULL;
}

DevianceDisplayShape *
deviance_display_shape_new (void)
{
	return g_object_new (deviance_display_shape_get_type (),
	                     NULL);
}

