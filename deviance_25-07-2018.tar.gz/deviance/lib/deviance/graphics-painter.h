/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-painter.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_GRAPHICS_PAINTER_H__
#define __DEVIANCE_GRAPHICS_PAINTER_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define DEVIANCE_TYPE_GRAPHICS_PAINTER            (deviance_graphics_painter_get_type())
#define DEVIANCE_GRAPHICS_PAINTER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_GRAPHICS_PAINTER, DevianceGraphicsPainter))
#define DEVIANCE_GRAPHICS_PAINTER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_GRAPHICS_PAINTER, DevianceGraphicsPainterClass))
#define DEVIANCE_IS_GRAPHICS_PAINTER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_GRAPHICS_PAINTER))
#define DEVIANCE_IS_GRAPHICS_PAINTER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_GRAPHICS_PAINTER))
#define DEVIANCE_GRAPHICS_PAINTER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_GRAPHICS_PAINTER, DevianceGraphicsPainterClass))

typedef struct _DevianceGraphicsPainterClass DevianceGraphicsPainterClass;

struct _DevianceGraphicsPainter {
	GObject parent_instance;

    /*< public >*/
    cairo_pattern_t *pattern;
    // ??? borer-image slice
};

struct _DevianceGraphicsPainterClass {
	GObjectClass parent_class;

    /*< public >*/
    void (*paint) (DevianceGraphicsPainter *painter, cairo_t *cr, gboolean preserve);
    // begin end...
};

GType deviance_graphics_painter_get_type();
DevianceGraphicsPainter *deviance_graphics_painter_new();
DevianceGraphicsPainter *deviance_graphics_painter_new_from_style_color (DevianceStyleColor *color);

void deviance_graphics_painter_paint(DevianceGraphicsPainter *self);

G_END_DECLS

#endif /* __DEVIANCE_GRAPHICS_PAINTER_H__ */

