/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * display-container.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "display.h"
#include "display-viewport.h"
#include "display-object.h"

#include "display-container.h"


static void deviance_display_container_class_init(DevianceDisplayContainerClass *klass);
static void deviance_display_container_init(DevianceDisplayContainer *gobject);

G_DEFINE_TYPE (DevianceDisplayContainer, deviance_display_container, DEVIANCE_TYPE_DISPLAY_OBJECT)

static void
deviance_display_container_class_display_object_render(DevianceDisplayObject *object, gpointer data)
{
    DevianceDisplayContainer *self = DEVIANCE_DISPLAY_CONTAINER(object);
    GList *it;
    for (it=g_list_first(self->children); it; it=it->next) {
        DevianceDisplayObject *child = it->data;
        deviance_display_object_render(child, data);
    }
}

static void
deviance_display_container_class_init(DevianceDisplayContainerClass *klass)
{
    DEVIANCE_DISPLAY_OBJECT_CLASS(klass)->render = deviance_display_container_class_display_object_render;
}

static void
deviance_display_container_init (DevianceDisplayContainer *object)
{
}

DevianceDisplayContainer *
deviance_display_container_new (void)
{
    return g_object_new (deviance_display_container_get_type (),
                         NULL);
}

void
deviance_display_container_add (DevianceDisplayContainer *self, DevianceDisplayObject *child)
{
    DEVIANCE_DISPLAY_OBJECT(child)->parent = self;
    self->children = g_list_append(self->children, child);
}

