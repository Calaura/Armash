/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-data-path.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_GRAPHICS_DATA_PATH_H__
#define __DEVIANCE_GRAPHICS_DATA_PATH_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define DEVIANCE_TYPE_GRAPHICS_DATA_PATH            (deviance_graphics_data_path_get_type())
#define DEVIANCE_GRAPHICS_DATA_PATH(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_GRAPHICS_DATA_PATH, DevianceGraphicsDataPath))
#define DEVIANCE_GRAPHICS_DATA_PATH_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_GRAPHICS_DATA_PATH, DevianceGraphicsDataPathClass))
#define DEVIANCE_IS_GRAPHICS_DATA_PATH(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_GRAPHICS_DATA_PATH))
#define DEVIANCE_IS_GRAPHICS_DATA_PATH_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_GRAPHICS_DATA_PATH))
#define DEVIANCE_GRAPHICS_DATA_PATH_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_GRAPHICS_DATA_PATH, DevianceGraphicsDataPathClass))

typedef GArray Array_DataSegment;
typedef struct _DevianceGraphicsDataSegment {
    cairo_path_data_t *header;// no operation ...
    cairo_path_data_t *points;// reserved
} DevianceGraphicsDataSegment;

typedef struct _DevianceGraphicsDataPath DevianceGraphicsDataPath;
typedef struct _DevianceGraphicsDataPathClass DevianceGraphicsDataPathClass;

struct _DevianceGraphicsDataPath {
	DevianceGraphicsData parent_instance;

    /*< public >*/
    cairo_path_t *cr_path;

    /*< private >*/
    Array_DataSegment *segments;

    gint data_index;
    gint segment_index;
    gint last_move;
};

struct _DevianceGraphicsDataPathClass {
	DevianceGraphicsDataClass parent_class;

    /*< public >*/
    cairo_t *cr;
};

GType deviance_graphics_data_path_get_type();
DevianceGraphicsDataPath *deviance_graphics_data_path_new();

void deviance_graphics_data_path_reset(DevianceGraphicsDataPath *self);
void deviance_graphics_data_path_move_to(DevianceGraphicsDataPath *self, gdouble x, gdouble y);
void deviance_graphics_data_path_line_to(DevianceGraphicsDataPath *self, gdouble x, gdouble y);
void deviance_graphics_data_path_curve_to(DevianceGraphicsDataPath *self, gdouble x1, gdouble y1, gdouble x2, gdouble y2, gdouble x3, gdouble y3);
void deviance_graphics_data_path_arc(DevianceGraphicsDataPath *self, gdouble xc, gdouble yc, gdouble radius, gdouble angle_start, gdouble angle_end);
void deviance_graphics_data_path_close(DevianceGraphicsDataPath *self);
void deviance_graphics_data_path_destroy(DevianceGraphicsDataPath *self);
// n_element
void deviance_graphics_data_path_append(DevianceGraphicsDataPath *self, cairo_path_data_t *data);
cairo_path_data_t *deviance_graphics_data_path_remove(DevianceGraphicsDataPath *self, gint index);

typedef struct _cairo_path_data_header_t {
    cairo_path_data_type_t type;
    int length;
} cairo_path_data_header_t;

typedef struct _cairo_path_data_point_t {
    double x, y;
} cairo_path_data_point_t;

typedef struct _DevianceGraphicsDataSegmentMove {
    cairo_path_data_header_t header;
    cairo_path_data_point_t point_1;
} DevianceGraphicsDataSegmentMove;

typedef struct _DevianceGraphicsDataSegmentLine {
    cairo_path_data_header_t header;
    cairo_path_data_point_t point_1;
}DevianceGraphicsDataSegmentLine;

typedef struct _DevianceGraphicsDataSegmentCurve {
    cairo_path_data_header_t header;
    cairo_path_data_point_t point_1;
    cairo_path_data_point_t point_2;
    cairo_path_data_point_t point_3;
} DevianceGraphicsDataSegmentCurve;

typedef struct _DevianceGraphicsDataSegmentArc {
    cairo_path_data_header_t header;
    cairo_path_data_point_t point_1;
    cairo_path_data_point_t point_2;
    cairo_path_data_point_t point_3;
} DevianceGraphicsDataSegmentArc;

typedef struct _DevianceGraphicsDataSegmentClose {
    cairo_path_data_header_t header;
} DevianceGraphicsDataSegmentClose;

typedef struct _DevianceGraphicsDataSegmentNop {
    cairo_path_data_header_t header;
    cairo_path_data_point_t points;
} DevianceGraphicsDataSegmentNop;

DevianceGraphicsDataSegment* deviance_graphics_data_path_segment_at(DevianceGraphicsDataPath *self, gint index);
void deviance_graphics_data_path_get_cairo(DevianceGraphicsDataPath *object, cairo_path_t *cr_path);

G_END_DECLS

#endif /* __DEVIANCE_GRAPHICS_DATA_PATH_H__ */

