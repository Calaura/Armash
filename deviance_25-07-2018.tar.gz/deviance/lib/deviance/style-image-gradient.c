/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-image-gradient.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <cairo.h>

#include "display.h"
#include "graphics.h"
#include "styles.h"

#include "graphics-data.h"
#include "style-color.h"
#include "style-image.h"

#include "graphics-data.h"
#include "graphics-data-fill.h"

#include "style-image-gradient.h"


static void deviance_style_image_gradient_class_init(DevianceStyleImageGradientClass *klass);
static void deviance_style_image_gradient_init(DevianceStyleImageGradient *gobject);

G_DEFINE_TYPE (DevianceStyleImageGradient, deviance_style_image_gradient, DEVIANCE_TYPE_STYLE_IMAGE)

static DevianceGraphicsData*
deviance_style_image_gradient_class_style_image_to_graphics(DevianceStyleImage *self, GtkStyle *gtk_style)
{
    /*
    DevianceGraphicsDataFill *data = deviance_graphics_data_fill_new();

    cairo_pattern_t *pattern = cairo_pattern_create_linear(0, 0, 0, 30);
    cairo_pattern_add_color_stop_rgb(pattern, 0, 0.263, 0.263, 0.243);
    cairo_pattern_add_color_stop_rgb(pattern, 1, 0.204, 0.204, 0.220);
    data->pattern = pattern;

    return data;
    */
    return NULL;
}

static DevianceStyleImage*
deviance_style_image_gradient_clone(DevianceStyleImage *image)
{
    DevianceStyleImageGradient *self = DEVIANCE_STYLE_IMAGE_GRADIENT(image);
    DevianceStyleImageUrl *clone = g_object_new (DEVIANCE_TYPE_STYLE_IMAGE_GRADIENT, NULL);

    // self -> clone
    // not used ?

    return DEVIANCE_STYLE_IMAGE(clone);
}

static void
deviance_style_image_gradient_copy(DevianceStyleImage *self, DevianceStyleImage *image)
{
    DevianceStyleImageGradient *self_gradient = DEVIANCE_STYLE_IMAGE_GRADIENT(self);
    DevianceStyleImageGradient *image_gradient = DEVIANCE_STYLE_IMAGE_GRADIENT(image);

}

static void
deviance_style_image_gradient_class_init(DevianceStyleImageGradientClass *klass)
{
    DEVIANCE_STYLE_IMAGE_CLASS(klass)->to_graphics = deviance_style_image_gradient_class_style_image_to_graphics;
    DEVIANCE_STYLE_IMAGE_CLASS(klass)->clone = deviance_style_image_gradient_clone;
    DEVIANCE_STYLE_IMAGE_CLASS(klass)->copy = deviance_style_image_gradient_copy;
}

static void
deviance_style_image_gradient_init (DevianceStyleImageGradient *object)
{
}

DevianceStyleImageGradient*
deviance_style_image_gradient_new (void)
{
	return g_object_new (deviance_style_image_gradient_get_type (),
	                     NULL);
}
