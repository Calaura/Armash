/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-text-shadow.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "styles.h"

#include "style-text-shadow.h"


static void deviance_style_text_shadow_class_init(DevianceStyleTextShadowClass *klass);
static void deviance_style_text_shadow_init(DevianceStyleTextShadow *gobject);

G_DEFINE_TYPE (DevianceStyleTextShadow, deviance_style_text_shadow, G_TYPE_OBJECT)

static void
deviance_style_text_shadow_class_init(DevianceStyleTextShadowClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;


	deviance_style_text_shadow_parent_class = g_type_class_peek_parent (klass);
}

static void
deviance_style_text_shadow_init (DevianceStyleTextShadow *object)
{
}

DevianceStyleTextShadow *
deviance_style_text_shadow_new (void)
{
	return g_object_new (deviance_style_text_shadow_get_type (),
	                     NULL);
}

