/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-data-shadow-stack.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "styles.h"

#include "graphics.h"
#include "graphics-data.h"
#include "graphics-data-shadow.h"
#include "style-border.h"

#include "graphics-data-shadow-stack.h"


static void deviance_graphics_data_shadow_stack_class_init(DevianceGraphicsDataShadowStackClass *klass);
static void deviance_graphics_data_shadow_stack_init(DevianceGraphicsDataShadowStack *gobject);

G_DEFINE_TYPE (DevianceGraphicsDataShadowStack, deviance_graphics_data_shadow_stack, DEVIANCE_TYPE_GRAPHICS_DATA)

static void
deviance_graphics_data_shadow_stack_class_graphics_data_draw(DevianceGraphicsData *data, cairo_t*cr, gboolean preserve)
{
    DevianceGraphicsDataShadowStack * self = DEVIANCE_GRAPHICS_DATA_SHADOW_STACK(data);

    GList *it;
    for (it=g_list_first(self->shadows); it; it=it->next) {
        DevianceGraphicsDataShadow *shadow = DEVIANCE_GRAPHICS_DATA_SHADOW(it->data);
        gboolean p = it->next==NULL?preserve:TRUE;
        deviance_graphics_data_draw(shadow, cr, p);
    }
}

static void
deviance_graphics_data_shadow_stack_class_graphics_data_update_resize(DevianceGraphicsData *graphics_data, cairo_rectangle_t *rectangle)
{
    DevianceGraphicsDataShadowStack *self = DEVIANCE_GRAPHICS_DATA_SHADOW_STACK(graphics_data);
    GList *it;
    for (it=g_list_first(self->shadows); it; it=it->next) {
        DevianceGraphicsDataShadow *shadow = DEVIANCE_GRAPHICS_DATA_SHADOW(it->data);
        deviance_graphics_data_update_resize(shadow, rectangle);
    }
}

static void
deviance_graphics_data_shadow_stack_class_init(DevianceGraphicsDataShadowStackClass *klass)
{
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->draw = deviance_graphics_data_shadow_stack_class_graphics_data_draw;
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->update_resize = deviance_graphics_data_shadow_stack_class_graphics_data_update_resize;
}

static void
deviance_graphics_data_shadow_stack_init (DevianceGraphicsDataShadowStack *object)
{
    object->shadows = NULL;
}

DevianceGraphicsDataShadowStack *
deviance_graphics_data_shadow_stack_new (void)
{
    return g_object_new (DEVIANCE_TYPE_GRAPHICS_DATA_SHADOW_STACK, NULL);
}

