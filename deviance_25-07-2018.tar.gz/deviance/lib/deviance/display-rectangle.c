/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * display-rectangle.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <math.h>

#include "styles.h"
#include "graphics.h"
#include "display.h"

#include "deviance_rc_style.h"
#include "deviance_style.h"

#include "style-color.h"
#include "style-image.h"
#include "style-border.h"
#include "style-border-image.h"
#include "style-box-shadow.h"
#include "style-background.h"
#include "style-selector.h"

#include "graphics-data.h"
#include "graphics-data-path.h"
#include "graphics-data-path-rectangle.h"


#include "display-viewport.h"
#include "display-object.h"
#include "display-shape.h"
#include "display-rectangle.h"










static void deviance_display_rectangle_class_init(DevianceDisplayRectangleClass *klass);
static void deviance_display_rectangle_init(DevianceDisplayRectangle *gobject);

static void deviance_display_rectangle_class_display_object_apply_style(DevianceDisplayObject *object, DevianceRcStyle *style);
static void deviance_display_rectangle_class_display_object_render(DevianceDisplayObject *object, gpointer data);


G_DEFINE_TYPE (DevianceDisplayRectangle, deviance_display_rectangle, DEVIANCE_TYPE_DISPLAY_SHAPE)

static void
deviance_display_rectangle_class_display_object_render(DevianceDisplayObject *object, gpointer data)
{
    int i;
    gboolean preserve = TRUE;
    DevianceDisplayObject *root; for(root = DEVIANCE_DISPLAY_OBJECT(object); root->parent!=NULL && root->parent!=root; root=root->parent);
    DevianceDisplayViewport *viewport = DEVIANCE_DISPLAY_OBJECT(root)->viewport;
    cairo_t *cr = viewport->cr;
    int len = DEVIANCE_DISPLAY_SHAPE(object)->datas ? DEVIANCE_DISPLAY_SHAPE(object)->datas->len : 0;
    DevianceStyle *style = DEVIANCE_DISPLAY_OBJECT(object)->style;
    for (i=0; i<len; i++) {
        cairo_rectangle_t rect;
        rect.x = viewport->x;
        rect.y = viewport->y;
        rect.width = viewport->width;
        rect.height = viewport->height;

        // ensure update
        DevianceGraphicsData *graphics_data = g_ptr_array_index(DEVIANCE_DISPLAY_SHAPE(object)->datas, i);
        deviance_graphics_data_update_resize(graphics_data, &rect);

        // paint
        //!deviance_graphics_data_update_draw(graphics_data, DEVIANCE_DISPLAY_OBJECT(root)->style);// GtkStyle
        deviance_graphics_data_draw(graphics_data, cr, (i+1)<len ? preserve : FALSE);
    }
}

static void
deviance_display_rectangle_class_display_object_update(DevianceDisplayRectangle *object, gpointer data)
{
    //DEVIANCE_DISPLAY_QUEUES queue_resize;
    //DEVIANCE_DISPLAY_FLAGS queue_resize;
//    DEVIANCE_DISPLAY_FILL_FLAG;
//    DEVIANCE_DISPLAY_STROKE_FLAG;
//    DEVIANCE_DISPLAY_EFFECT_FLAG;
//    DEVIANCE_DISPLAY_ANIME_FLAG;
//    if (DEVIANCE_DISPLAY_OBJECT(object)->flag)
//    deviance_graphics_data_update_resize(DEVIANCE_DISPLAY_SHAPE(object)->path, );
    //deviance_display_rectangle_update_path(object, object->x, object->y, object->width, object->height, object->border_radius_top_left, object->border_radius_top_right, object->border_radius_bottom_right, object->border_radius_bottom_left);
    //deviance_display_rectangle_update_painter(object, object->x, object->y, object->width, object->height, object->border_radius_top_left, object->border_radius_top_right, object->border_radius_bottom_right, object->border_radius_bottom_left);
    // foreach GraphicsData: deviance_graphics_update_size();
    // foreach GraphicsData: deviance_graphics_update_painter();
}

static void
deviance_display_rectangle_class_init(DevianceDisplayRectangleClass *klass)
{
    DEVIANCE_DISPLAY_OBJECT_CLASS(klass)->render = deviance_display_rectangle_class_display_object_render;
    DEVIANCE_DISPLAY_OBJECT_CLASS(klass)->update = deviance_display_rectangle_class_display_object_update;
    DEVIANCE_DISPLAY_OBJECT_CLASS(klass)->apply_style = deviance_display_rectangle_class_display_object_apply_style;
}

static void
deviance_display_rectangle_init (DevianceDisplayRectangle *object)
{
}

DevianceDisplayObject *
deviance_display_rectangle_new (void)
{
    return g_object_new (deviance_display_rectangle_get_type (),
                         NULL);
}



static void
deviance_display_rectangle_class_display_object_apply_style(DevianceDisplayObject *object, DevianceRcStyle *style)
{
    g_print("deviance_display_rectangle_class_display_object_apply_style\n");
    DevianceDisplayRectangle *rectangle = DEVIANCE_DISPLAY_RECTANGLE(object);
    DevianceDisplayShape *shape = DEVIANCE_DISPLAY_SHAPE(object);
    g_assert(DEVIANCE_IS_RC_STYLE(style));

    ///deviance_style_render();
    // DevianceStyleBackground
    DevianceStyleBorder *border = NULL;//style->border;
    //border->top.radius
    // DevianceStyleTextShadow
    // DevianceStyleBoxShadow




#if 0
    if (style->background) {
        gdouble x=object->x, y=object->y,
                width=object->width, height=object->height,
                r1=object->border_radius_top_left,
                r2=object->border_radius_top_right,
                r3=object->border_radius_bottom_right,
                r4=object->border_radius_bottom_left;
        if (style->background->color || style->background->image) {
            if (shape->datas==NULL) {
                shape->datas = g_ptr_array_new_full(2, (GDestroyNotify)g_object_unref);
            }
            DevianceGraphicsDataPath *data_path = deviance_graphics_data_path_rectangle_new();
            shape->path = data_path;
            g_ptr_array_add(shape->datas, data_path);

            if (style->background->color) {
                DevianceGraphicsData *data_color = deviance_style_color_to_graphics_data_fill(style->background->color, DEVIANCE_DISPLAY_OBJECT(object)->style);
                g_ptr_array_add(shape->datas, data_color);
            }
            if (style->background->image) {
                DevianceGraphicsData *data_image = deviance_style_image_to_graphics(style->background->image, DEVIANCE_DISPLAY_OBJECT(object)->style);
                g_ptr_array_add(shape->datas, data_image);
            }
        }
    }

    if (style->border) {
        gdouble x=object->x, y=object->y,
                width=object->width, height=object->height,
                r1=object->border_radius_top_left,
                r2=object->border_radius_top_right,
                r3=object->border_radius_bottom_right,
                r4=object->border_radius_bottom_left;
        if (TRUE/*style->border->top.width */) {
            if (shape->datas==NULL) {
                shape->datas = g_ptr_array_new_full(2, (GDestroyNotify)g_object_unref);
            }
            DevianceGraphicsDataPath *data_path = deviance_graphics_data_path_rectangle_new();
            shape->path = data_path;

            if (style->border->top.color!=NULL) {
                g_ptr_array_add(shape->datas, data_path);

                DevianceGraphicsData *data_color = deviance_style_color_to_graphics_data_stroke(style->border->top.color, DEVIANCE_DISPLAY_OBJECT(object)->style);
                g_ptr_array_add(shape->datas, data_color);
            }

        }

    }
#endif
}


#include "style-length.h"
// todo path modifier (stay in bbox malgré le border-width)



#include "styles.h"
#include "graphics.h"
#include "display.h"

#include "style-length.h"
#include "style-border.h"



// radius, clip
static void
deviance_graphics_data_path_rectangle_default_modifier(cairo_rectangle_t *rect, cairo_rectangle_t *rectangle, gpointer/*DevianceStyleBorder**/ user_data)
{
    cairo_rectangle_t modifier;// = {1.5, 1.5, -3, -3};
    DevianceStyleBorder *border = user_data;
    modifier.y = border->top.width->value/2.0;
    modifier.height = -border->top.width->value/2.0 - border->bottom.width->value/2.0;
    modifier.x = border->left.width->value/2.0;
    modifier.width = -border->left.width->value/2.0 - border->right.width->value/2.0;

    //cairo_rectangle_t modifier = {0, 0, 0, 0};
    rect[0].x = modifier.x;
    rect[0].y = modifier.y;
    rect[0].width = rectangle->width + modifier.width;
    rect[0].height = rectangle->height + modifier.height;

    rect[1].x = border->top_left.rx->value;
    rect[1].y = border->top_right.rx->value;
    rect[1].width = border->bottom_left.rx->value;
    rect[1].height = border->bottom_right.rx->value;
}


static void
deviance_graphics_data_path_rectangle_fill_modifier(cairo_rectangle_t *rect, cairo_rectangle_t *rectangle, gpointer user_data)
{
    cairo_rectangle_t modifier = {0.0, 0.0, 0.0, 0.0};
    DevianceStyleBorder *border = user_data;
    if (border) {
        modifier.y = border->top.width->value;
        modifier.height = -border->top.width->value - border->bottom.width->value;// TODO: deviance_style_border_get_width(border, viewport);
        modifier.x = border->left.width->value;
        modifier.width = -border->left.width->value - border->right.width->value;
    }

    //cairo_rectangle_t modifier = {0, 0, 0, 0};
    rect[0].x = modifier.x;
    rect[0].y = modifier.y;
    rect[0].width = rectangle->width + modifier.width;
    rect[0].height = rectangle->height + modifier.height;


//    rect[1].x = border->top_left.rx->value;
//    rect[1].y = border->top_right.rx->value;
//    rect[1].width = border->bottom_left.rx->value;
//    rect[1].height = border->bottom_right.rx->value;
    if (border) {
        rect[1].x = border->top_left.rx->value;
        rect[1].y = border->top_right.rx->value;
        rect[1].width = border->bottom_left.rx->value;
        rect[1].height = border->bottom_right.rx->value;
    } else {
        rect[1].x = 0.0;
        rect[1].y = 0.0;
        rect[1].width = 0.0;
        rect[1].height = 0.0;
    }
}

#include "graphics-data-path-background.h"
void
deviance_display_rectangle_apply_style_background(DevianceDisplayRectangle *object, DevianceRcStyle *style, DevianceStyleBackground *bg, DevianceStyleBorder *border/*DevianceStyleState *state*/)
{
    DevianceDisplayShape *shape = DEVIANCE_DISPLAY_SHAPE(object);
    g_assert(DEVIANCE_IS_RC_STYLE(style));

//    g_hash_table_
//    style->_background;
    //DevianceStyleBackground *bg = NULL;
    //DevianceStyleState state = deviance_style_background_get_first_state(bg);// get_state(); background:normal:nth-child(odd)


    if (bg) {
        if (bg->color || bg->image) {
            if (shape->datas==NULL) {
                shape->datas = g_ptr_array_new_full(2, (GDestroyNotify)g_object_unref);
            }
            DevianceGraphicsDataPathBackground *data_path = deviance_graphics_data_path_background_new();
            //data_path->modifier = deviance_graphics_data_path_rectangle_fill_modifier;
            data_path->border = border;// ici utiliser le border qui correspond au state via selector
            shape->path = DEVIANCE_GRAPHICS_DATA_PATH(data_path);
            g_ptr_array_add(shape->datas, data_path);

            if (bg->color) {
                DevianceGraphicsData *data_color = deviance_style_color_to_graphics_data_fill(bg->color, DEVIANCE_DISPLAY_OBJECT(object)->style);
                g_ptr_array_add(shape->datas, data_color);
            }
            if (bg->image) {
                DevianceGraphicsData *data_image = deviance_style_image_to_graphics(bg->image, DEVIANCE_DISPLAY_OBJECT(object)->style);
                g_ptr_array_add(shape->datas, data_image);
            }
        }
    }
}

#include "style-border-image.h"
void
deviance_display_rectangle_apply_style_border(DevianceDisplayRectangle *object, DevianceRcStyle *style, DevianceStyleBorder *border)
{
    DevianceDisplayShape *shape = DEVIANCE_DISPLAY_SHAPE(object);
    gsize data_len = 2;

    if (/*style->*/border) {
        if (TRUE/*style->border->top.width */) {
            if (border->image!=NULL) {
                data_len += 1;
            }
            if (shape->datas==NULL) {
                shape->datas = g_ptr_array_new_full(data_len, (GDestroyNotify)g_object_unref);
            }

            if (/*style->*/border->top.color!=NULL) {
                DevianceGraphicsDataPathRectangle *data_path = deviance_graphics_data_path_rectangle_new();
                //data_path->modifier = deviance_graphics_data_path_rectangle_update_fill;
                //data_path->modifier = deviance_graphics_data_path_rectangle_update_border;
                data_path->modifier = deviance_graphics_data_path_rectangle_default_modifier;
                data_path->modifier_data = /*style->*/border;
                //DisplayViewportModifier *= ;
                //data_path.update(); data_path->setViewportModifier(object, style->border[->top.width]);
                shape->path = DEVIANCE_GRAPHICS_DATA_PATH(data_path);
                g_ptr_array_add(shape->datas, data_path);

                DevianceGraphicsData *data_color = deviance_style_border_to_graphics_data_fill(/*style->*/border, DEVIANCE_DISPLAY_OBJECT(object)->style);
                //DevianceGraphicsData *data_color = deviance_style_border_to_graphics_data_stroke(/*style->*/border, DEVIANCE_DISPLAY_OBJECT(object)->style);
                g_ptr_array_add(shape->datas, data_color);
                // if
            }
            if (border->image!=NULL && border->image->source!=NULL) {
                g_printerr("style->border_image: %d\n", DEVIANCE_IS_STYLE_BORDER_IMAGE(border->image));
                DevianceGraphicsData *data_image = deviance_style_image_to_graphics_data_fill(border->image, DEVIANCE_DISPLAY_OBJECT(object)->style);
                g_ptr_array_add(shape->datas, data_image);
            }

        }

    }
    // DevianceGraphicsData *datas = deviance_style_to_graphics(DEVIANCE_STYLE_COLOR(deviance_style));
    //style_color->background = NULL;
    //style_color->border = NULL;
}

void
deviance_display_rectangle_apply_style_border_image(DevianceDisplayRectangle *object, DevianceRcStyle *style)
{
    DevianceDisplayShape *shape = DEVIANCE_DISPLAY_SHAPE(object);

    /**
    if (style->border_image) {
        if (style->border_image->source) {
            if (shape->datas==NULL) {
                shape->datas = g_ptr_array_new_full(2, (GDestroyNotify)g_object_unref);
            }
            DevianceGraphicsDataPathRectangle *data_path = deviance_graphics_data_path_rectangle_new();
            data_path->modifier = deviance_graphics_data_path_rectangle_default_modifier;
            data_path->modifier_data = NULL;//style->border;
            shape->path = DEVIANCE_GRAPHICS_DATA_PATH(data_path);
            g_ptr_array_add(shape->datas, data_path);

            DevianceGraphicsData *data_image = deviance_style_image_to_graphics_data_stroke(DEVIANCE_STYLE_IMAGE(style->border_image), DEVIANCE_DISPLAY_OBJECT(object)->style);
            g_ptr_array_add(shape->datas, data_image);
        }
    }
    */
}

void
deviance_display_rectangle_apply_style_box_shadow(DevianceDisplayRectangle *object, DevianceRcStyle *style, DevianceStyleBoxShadow *box_shadow, DevianceStyleBorder*border)
{
    DevianceDisplayShape *shape = DEVIANCE_DISPLAY_SHAPE(object);

    if (box_shadow) {
        if (shape->datas==NULL) {
            shape->datas = g_ptr_array_new_full(2, (GDestroyNotify)g_object_unref);
        }
        DevianceGraphicsDataPathRectangle *data_path = deviance_graphics_data_path_rectangle_new();
        data_path->inset = TRUE;
        //data_path->modifier = deviance_graphics_data_path_rectangle_default_modifier;
        data_path->modifier_data = border;
        shape->path = DEVIANCE_GRAPHICS_DATA_PATH(data_path);
        g_ptr_array_add(shape->datas, data_path);

        DevianceGraphicsData *data_box_shadow = deviance_style_box_shadow_to_graphics_data_fill(DEVIANCE_STYLE_BOX_SHADOW(box_shadow), DEVIANCE_DISPLAY_OBJECT(object)->style, border);
        g_ptr_array_add(shape->datas, data_box_shadow);
    }

}
