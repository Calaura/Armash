/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-data-shadow.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "display.h"
#include "styles.h"
#include "graphics.h"

#include "graphics-data.h"

#include "style-border.h"
#include "style-length.h"
#include "cairo-support.h"
#include "raico-blur.h"


#include "graphics-data-shadow.h"

static void deviance_graphics_data_shadow_class_init(DevianceGraphicsDataShadowClass *klass);
static void deviance_graphics_data_shadow_init(DevianceGraphicsDataShadow *gobject);

G_DEFINE_TYPE (DevianceGraphicsDataShadow, deviance_graphics_data_shadow, DEVIANCE_TYPE_GRAPHICS_DATA)

static void
deviance_graphics_data_shadow_class_graphics_data_draw(DevianceGraphicsData *data, cairo_t*cr, gboolean preserve)
{
    DevianceGraphicsDataShadow * self = DEVIANCE_GRAPHICS_DATA_SHADOW(data);
    //self->shadows

#if 0
    raico_blur_t* blur = NULL;
    cairo_t *cr_surface;
    cairo_surface_t *surface;
    DevianceRGB *glow = g_new(DevianceRGB, 1);
    glow->r = 0.22287205822977893;
    glow->g = 0.23790614327063211;
    glow->b = 0.23790614327063211;
/*
*/
    glow->r = 1.0;
    glow->g = 0.0;
    glow->b = 0.0;




    gint roundness = deviance_style_length_get_value(self->border->top_left.rx, NULL);
    guint corners = 1+2+4+8;

    double x1, y1, x2, y2;
    cairo_path_extents(cr, &x1, &y1, &x2, &y2);
    double width=x2-x1;
    double height=y2-y1;
    double bradius = self->blur;


    /* draw glow */
    surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, width+bradius*2, height+bradius*2);
    cr_surface = cairo_create (surface);
    blur = raico_blur_create (RAICO_BLUR_QUALITY_LOW);
    raico_blur_set_radius (blur, bradius);
    cairo_set_line_width (cr_surface, self->spread);

    //deviance_rounded_rectangle_closed (cr_surface, bradius, bradius, width, height, roundness, corners);
        /**/
        cairo_surface_t *path_surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, 10, 10);
        cairo_t *path_cr = cairo_create (path_surface);
        cairo_append_path(path_cr, cairo_copy_path(cr));
        cairo_matrix_t matrix;
        cairo_matrix_init_identity(&matrix);
        cairo_matrix_translate(&matrix, x1+self->x_offset, y1+self->y_offset);
        cairo_set_matrix(path_cr, &matrix);
        cairo_fill_preserve(path_cr);
        cairo_path_t *path = cairo_copy_path(path_cr);
        cairo_append_path(cr_surface, path);
        cairo_surface_destroy (path_surface);
        cairo_destroy (path_cr);
        /**/

    //deviance_set_color_rgb (cr_surface, glow);

    cairo_set_source (cr_surface, self->pattern);
    cairo_stroke (cr_surface);
    if (bradius>0.001) {
        raico_blur_apply (blur, surface);
    }
    cairo_set_source_surface (cr, surface, x1, y1);
    //cairo_stroke_preserve (cr);
    preserve ? cairo_fill_preserve(cr):cairo_fill(cr);

    cairo_surface_destroy (surface);
    cairo_destroy (cr_surface);


#elif 1
    gdouble inset = self->spread;
    raico_blur_t* blur = NULL;
    double bradius = self->blur;
    double x1, y1, x2, y2;
    cairo_path_extents(cr, &x1, &y1, &x2, &y2);
    //g_print("extends{x1: %f, y1: %f, x2: %f, y2: %f}\n", x1, y1, x2, y2);

    cairo_surface_t *target = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, x2-x1+bradius*2, y2-y1+bradius*2);
    cairo_t *cr_target = cairo_create(target);
    blur = raico_blur_create (RAICO_BLUR_QUALITY_LOW);
    raico_blur_set_radius (blur, bradius);

    cairo_path_t *path = cairo_copy_path(cr);


    cairo_set_source (cr_target, self->pattern);
    cairo_paint(cr_target);
    cairo_set_operator(cr_target, CAIRO_OPERATOR_CLEAR);
    cairo_translate(cr_target, -x1-self->x_offset, -y1-self->y_offset);
    cairo_append_path(cr_target, path);
    cairo_fill_preserve(cr_target);// mask out
    cairo_set_operator(cr_target, CAIRO_OPERATOR_SOURCE);
    cairo_set_line_width(cr_target, self->spread*2);// mask out
    cairo_stroke(cr_target);// mask out
    raico_blur_apply (blur, target);


    cairo_set_source_surface(cr, target, x1, y1);
    preserve ? cairo_fill_preserve(cr):cairo_fill(cr);


/*
    cairo_set_source_rgb(cairo_mask, 0.0, 0.0, 0.0);
    cairo_paint(cairo_mask);
    cairo_set_operator(cairo_mask, CAIRO_OPERATOR_CLEAR);
    cairo_append_path(cairo_mask, path);
    cairo_fill(cairo_mask);// mask out

    cairo_set_source_rgb(cairo_target, 0.0, 0.0, 0.0);
    cairo_paint(cairo_target);
    cairo_set_operator(cairo_target, CAIRO_OPERATOR_CLEAR);
    cairo_append_path(cairo_target, path);
    cairo_fill_preserve(cairo_target);
    cairo_set_operator(cairo_target, CAIRO_OPERATOR_SOURCE);
    cairo_set_source_rgb(cairo_target, 0.0, 0.0, 0.0);
    cairo_set_line_width(cairo_target, self->spread*2.0);
    cairo_stroke(cairo_target);


    cairo_mask_surface(cairo_target, mask, 0, 0);
    cairo_set_source_surface (cr, target, x1+blur, y1+blur);
    preserve ? cairo_fill_preserve(cr):cairo_fill(cr);
*/
    //cairo_destroy(cairo);
    //cairo_surface_destroy(target);

#else
    cairo_surface_t *mask = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 900, 900);
    cairo_surface_t *target = cairo_image_surface_create(CAIRO_FORMAT_ARGB32, 900, 900);
    cairo_t *cairo_mask = cairo_create(mask);
    cairo_t *cairo = cairo_create(target);

    gdouble inset = 2;
    guint blur = 0;
    // Painter: create a shadow inset
    ///GraphicsPainterShadow(inset)
    cairo_set_source_rgb(cairo_mask, 0.0, 0.0, 0.0);
    cairo_paint(cairo_mask);

    cairo_set_operator(cairo_mask, CAIRO_OPERATOR_CLEAR);
    cairo_path_t *path = cairo_copy_path(cr);
    cairo_append_path(cairo_mask, path);
    cairo_fill_preserve(cairo_mask);

    cairo_set_operator(cairo_mask, CAIRO_OPERATOR_SOURCE);
    cairo_set_line_width(cairo_mask, MAX(0, inset*2));// MAX(0, (inset-0.5)*2)
    cairo_stroke(cairo_mask);
    if (blur) {
        surface_gaussian_blur (mask, blur);
        //surface_exponential_blur(mask, 2);
    }

    //
    self->pattern = cairo_pattern_create_linear(0, 1, 0, 17);
    cairo_pattern_add_color_stop_rgb(self->pattern, 0.0, 0.294117647, 0.294117647, 0.274509804);// 75, 75, 70
    cairo_pattern_add_color_stop_rgb(self->pattern, 1.0, 0.250980392, 0.250980392, 0.231372549);// 52, 52, 49

//    self->pattern = cairo_pattern_create_rgba(0.294117647, 0.294117647, 0.274509804, 1.0);
//    self->pattern = cairo_pattern_create_rgba(0.250980392, 0.250980392, 0.231372549, 1.0);

    cairo_set_source(cairo, self->pattern);
    cairo_mask_surface(cairo, mask, 0, 0);


    cairo_set_source_surface(cr, target, 0.0, 0.0);//cairo_set_source_surface(); ???
//    cairo_pattern_type_t type = cairo_pattern_get_type(self->pattern);
//    int count;
//    cairo_pattern_get_color_stop_count(self->pattern, &count);
    //g_print("pattern_type: %d(%d); %d\n", type, CAIRO_PATTERN_TYPE_LINEAR, count);
    ///cairo_set_fill_rule(cr, self->rule);

    preserve ? cairo_fill_preserve(cr):cairo_fill(cr);

    cairo_destroy(cairo);
    cairo_surface_destroy(target);
#endif
}

static void
deviance_graphics_data_shadow_class_graphics_data_update_resize(DevianceGraphicsData *graphics_data, cairo_rectangle_t *rectangle)
{
    DevianceGraphicsDataShadow *self = DEVIANCE_GRAPHICS_DATA_SHADOW(graphics_data);

    if (self->pattern) {
        cairo_pattern_t *pattern = cairo_pattern_create_linear(0.0, 0.0, 0.0, rectangle->height);
        //cairo_pattern_t *pattern = cairo_pattern_create_linear(rectangle->x, rectangle->y, rectangle->x, rectangle->y+rectangle->height);
        gint count;
        cairo_pattern_get_color_stop_count(self->pattern, &count);
        gdouble offset, red, green, blue, alpha;
        gint i;
        for(i=0; i<count; i++) {
            cairo_pattern_get_color_stop_rgba(self->pattern, i, &offset, &red, &green, &blue, &alpha);
            cairo_pattern_add_color_stop_rgba(pattern, offset, red, green, blue, alpha);
        }
        cairo_pattern_destroy(self->pattern);
        self->pattern = pattern;
    }


}

static void
deviance_graphics_data_shadow_class_init(DevianceGraphicsDataShadowClass *klass)
{
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->draw = deviance_graphics_data_shadow_class_graphics_data_draw;
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->update_resize = deviance_graphics_data_shadow_class_graphics_data_update_resize;
}

static void
deviance_graphics_data_shadow_init (DevianceGraphicsDataShadow *object)
{
    object->x_offset = 0;
    object->y_offset = 0;
    object->spread = 0;
    object->blur = 0.0;
    object->image = NULL;
    object->color = NULL;
}

DevianceGraphicsDataShadow *
deviance_graphics_data_shadow_new (void)
{
	return g_object_new (deviance_graphics_data_shadow_get_type (),
	                     NULL);
}

