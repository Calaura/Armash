/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-border.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "display.h"
#include "graphics.h"
#include "styles.h"

#include "graphics-data.h"
#include "graphics-data-stroke.h"
#include "graphics-data-fill.h"

#include "style-color.h"
#include "style-length.h"
#include "style-image.h"
#include "style-selector.h"
//#include "style-background.h"
#include "style-border-image.h"

#include "style-border.h"


static void deviance_style_border_class_init(DevianceStyleBorderClass *klass);
static void deviance_style_border_init(DevianceStyleBorder *gobject);

G_DEFINE_TYPE (DevianceStyleBorder, deviance_style_border, G_TYPE_OBJECT)

static void
deviance_style_border_dispose (GObject *gobject)
{
  DevianceStyleBorder *border = DEVIANCE_STYLE_BORDER(gobject);
  /* dispose() might be called multiple times, so we must guard against
   * calling g_object_unref() on an invalid GObject by setting the member
   * NULL; g_clear_object() does this for us.
   */
  g_clear_object (&border->top.color);
  g_clear_object (&border->top.width);

  g_clear_object (&border->right.color);
  g_clear_object (&border->right.width);

  g_clear_object (&border->bottom.color);
  g_clear_object (&border->bottom.width);

  g_clear_object (&border->left.color);
  g_clear_object (&border->left.width);



  g_clear_object (&border->top_left.rx);
  g_clear_object (&border->top_left.ry);
  g_clear_object (&border->top_right.rx);
  g_clear_object (&border->top_right.ry);
  g_clear_object (&border->bottom_right.rx);
  g_clear_object (&border->bottom_right.ry);
  g_clear_object (&border->bottom_left.rx);
  g_clear_object (&border->bottom_left.ry);


  /* Always chain up to the parent class; there is no need to check if
   * the parent class implements the dispose() virtual function: it is
   * always guaranteed to do so
   */
  G_OBJECT_CLASS (deviance_style_border_parent_class)->dispose (gobject);
}

static void
deviance_style_border_class_init(DevianceStyleBorderClass *klass)
{
    G_OBJECT_CLASS(klass)->dispose = deviance_style_border_dispose;
    //G_OBJECT_CLASS(klass)->finalize = NULL;
}

static void
deviance_style_border_init (DevianceStyleBorder *object)
{
    object->selectors = NULL;
    object->image = NULL;

    /// TODO use static default color
    object->top.color = NULL;//deviance_style_color_new();
    object->top.width = deviance_style_length_new();
    object->top.style = DEVIANCE_STYLE_BORDER_SOLID_STYLE;
    //object->top.path = NULL;

    object->right.color = NULL;//deviance_style_color_new();
    object->right.width = deviance_style_length_new();
    object->right.style = DEVIANCE_STYLE_BORDER_SOLID_STYLE;
    //object->right.path = NULL;

    object->bottom.color = NULL;//deviance_style_color_new();
    object->bottom.width = deviance_style_length_new();
    object->bottom.style = DEVIANCE_STYLE_BORDER_SOLID_STYLE;
    //object->bottom.path = NULL;

    object->left.color = NULL;//deviance_style_color_new();
    object->left.width = deviance_style_length_new();
    object->left.style = DEVIANCE_STYLE_BORDER_SOLID_STYLE;
    //object->left.path = NULL;

    object->top_left.rx = deviance_style_length_new();
    object->top_left.ry = deviance_style_length_new();
    object->top_right.rx = deviance_style_length_new();
    object->top_right.ry = deviance_style_length_new();
    object->bottom_right.rx = deviance_style_length_new();
    object->bottom_right.ry = deviance_style_length_new();
    object->bottom_left.rx = deviance_style_length_new();
    object->bottom_left.ry = deviance_style_length_new();
}

DevianceStyleBorder *
deviance_style_border_new (void)
{
    return g_object_new (deviance_style_border_get_type (),
                         NULL);
}

guint
deviance_style_border_hash(gconstpointer  key)
{
    DevianceStyleBorder *self = DEVIANCE_STYLE_BORDER(key);
    guint hash = deviance_style_selector_to_int(self->selectors);
    return hash;
}

gboolean
deviance_style_border_equal(gconstpointer  a, gconstpointer  b)
{
    DevianceStyleBorder *self = DEVIANCE_STYLE_BORDER(a);
    DevianceStyleBorder *border = DEVIANCE_STYLE_BORDER(b);
    if (a==b) {
        return TRUE;
    }
    guint hash = deviance_style_border_hash(border);
    guint self_hash = deviance_style_border_hash(self);
    if (hash==self_hash) {
        return TRUE;
    }

    return FALSE;
}

DevianceGraphicsData*
deviance_style_border_to_graphics_path (DevianceStyleBorder *self)
{
    DevianceGraphicsData *data_path = NULL;

//    self->top.width = 1.0;
//    self->right.width = 1.0;
//    self->bottom.width = 1.0;
//    self->left.width = 1.0;

    return data_path;
}


DevianceGraphicsData*
deviance_style_border_to_graphics_data_stroke(DevianceStyleBorder *self, GtkStyle *style)
{
    DevianceGraphicsDataStroke *data = deviance_graphics_data_stroke_new();

    DevianceStyleColor *color = self->top.color;
    deviance_style_color_to_graphics(self->top.color, style);
    //deviance_style_color_to_graphics_data_stroke(self->top.color, style);

    data->width = self->top.width->value;
    data->pattern = cairo_pattern_create_rgba(self->top.color->r, self->top.color->g, self->top.color->b, self->top.color->a);

    return data;
}

DevianceGraphicsData*
deviance_style_border_to_graphics_data_fill(DevianceStyleBorder *self, GtkStyle *style)
{
    DevianceGraphicsDataFill *data = deviance_graphics_data_fill_new();

    DevianceStyleColor *color = self->top.color;
    deviance_style_color_to_graphics(self->top.color, style);
    data->pattern = cairo_pattern_create_rgba(self->top.color->r, self->top.color->g, self->top.color->b, self->top.color->a);

    //data->pattern = cairo_pattern_create_rgba(self->top.color->r, self->top.color->g, self->top.color->b, self->top.color->a);

    return data;
}



DevianceStyleState
deviance_style_border_get_first_state(DevianceStyleBorder *self)
{
    return deviance_style_selector_get_state(self->selectors);
}

static void
deviance_style_border_description_copy(DevianceStyleBorderDescription *self, DevianceStyleBorderDescription *clone)
{
    if (self->color) {
        deviance_style_color_merge(self->color, &clone->color);
    }
    if (self->width) {
        deviance_style_length_copy(self->width, clone->width);
    }
    clone->style = self->style;
}

static void
deviance_style_border_radius_copy(DevianceStyleBorderRadius *self, DevianceStyleBorderRadius *clone)
{
    if (self->rx) {
        deviance_style_length_copy(self->rx, clone->rx);
    }
    if (self->ry) {
        deviance_style_length_copy(self->ry, clone->ry);
    }
}

void
deviance_style_border_copy(DevianceStyleBorder *self, DevianceStyleBorder *border)
{
    if (self->image) {
        border->image = deviance_style_border_image_clone(self->image);
    }
    deviance_style_border_description_copy(&self->top, &border->top);
    deviance_style_border_description_copy(&self->right, &border->right);
    deviance_style_border_description_copy(&self->bottom, &border->bottom);
    deviance_style_border_description_copy(&self->left, &border->left);

    deviance_style_border_radius_copy(&self->top_left, &border->top_left);
    deviance_style_border_radius_copy(&self->top_right, &border->top_right);
    deviance_style_border_radius_copy(&self->bottom_right, &border->bottom_right);
    deviance_style_border_radius_copy(&self->bottom_left, &border->bottom_left);
}

DevianceStyleBorder*
deviance_style_border_clone(DevianceStyleBorder *self)
{
    g_return_val_if_fail(DEVIANCE_IS_STYLE_BORDER(self), NULL);
    DevianceStyleBorder *clone = deviance_style_border_new();

    // TODO clone selector
    if (self->selectors) {
        clone->selectors = deviance_style_selector_clone(self->selectors);
    }

    if (self->image) {
        clone->image = deviance_style_border_image_clone(self->image);
    }
    deviance_style_border_description_copy(&self->top, &clone->top);
    deviance_style_border_description_copy(&self->right, &clone->right);
    deviance_style_border_description_copy(&self->bottom, &clone->bottom);
    deviance_style_border_description_copy(&self->left, &clone->left);

    deviance_style_border_radius_copy(&self->top_left, &clone->top_left);
    deviance_style_border_radius_copy(&self->top_right, &clone->top_right);
    deviance_style_border_radius_copy(&self->bottom_right, &clone->bottom_right);
    deviance_style_border_radius_copy(&self->bottom_left, &clone->bottom_left);

    return clone;
}

static void
deviance_style_border_description_merge(DevianceStyleBorderDescription *self, DevianceStyleBorderDescription *dest)
{
    DevianceStyleBorderDescription *border = dest;
    if (self->color && !border->color->is_set) {
        deviance_style_color_merge(self->color, &border->color);
    }
    if (self->width && !border->width->is_set ) {
        deviance_style_length_copy(self->width, border->width);
    }
    border->style = self->style;
}

void
deviance_style_border_merge(DevianceStyleBorder *self, DevianceStyleBorder *border)
{
    g_return_val_if_fail(DEVIANCE_IS_STYLE_BORDER(self), NULL);

    // if not set clone/clopy

    if (self->image) {
        border->image = deviance_style_border_image_clone(self->image);
    }
    deviance_style_border_description_merge(&self->top, &border->top);
    deviance_style_border_description_merge(&self->right, &border->right);
    deviance_style_border_description_merge(&self->bottom, &border->bottom);
    deviance_style_border_description_merge(&self->left, &border->left);

    // if is_set do not override dest with src
    if (!border->top_left.rx->is_set)
        deviance_style_border_radius_copy(&self->top_left, &border->top_left);
    if (!border->top_right.rx->is_set)
        deviance_style_border_radius_copy(&self->top_right, &border->top_right);
    if (!border->bottom_right.rx->is_set)
        deviance_style_border_radius_copy(&self->bottom_right, &border->bottom_right);
    if (!border->bottom_left.rx->is_set)
        deviance_style_border_radius_copy(&self->bottom_left, &border->bottom_left);

}
