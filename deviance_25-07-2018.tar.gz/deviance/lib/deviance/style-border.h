/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-border.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_STYLE_BORDER_H__
#define __DEVIANCE_STYLE_BORDER_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define DEVIANCE_TYPE_STYLE_BORDER            (deviance_style_border_get_type())
#define DEVIANCE_STYLE_BORDER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_STYLE_BORDER, DevianceStyleBorder))
#define DEVIANCE_STYLE_BORDER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_STYLE_BORDER, DevianceStyleBorderClass))
#define DEVIANCE_IS_STYLE_BORDER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_STYLE_BORDER))
#define DEVIANCE_IS_STYLE_BORDER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_STYLE_BORDER))
#define DEVIANCE_STYLE_BORDER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_STYLE_BORDER, DevianceStyleBorderClass))


typedef enum   _DevianceStyleBorderStyle        DevianceStyleBorderStyle;
typedef struct _DevianceStyleBorderDescription  DevianceStyleBorderDescription;
typedef struct _DevianceStyleBorderRadius       DevianceStyleBorderRadius;
typedef struct _DevianceStyleBorderClass DevianceStyleBorderClass;

enum _DevianceStyleBorderStyle {
    DEVIANCE_STYLE_BORDER_NONE_STYLE,   // Default value. Specifies no border
    DEVIANCE_STYLE_BORDER_HIDDEN_STYLE, // The same as "none", except in border conflict resolution for table elements
    DEVIANCE_STYLE_BORDER_DOTTED_STYLE, // Specifies a dotted border
    DEVIANCE_STYLE_BORDER_DASHED_STYLE, // Specifies a dashed border
    DEVIANCE_STYLE_BORDER_SOLID_STYLE,  // Specifies a solid border

    DEVIANCE_STYLE_BORDER_NUM_STYLES
};

struct _DevianceStyleBorderDescription {
    DevianceStyleColor        *color;
    DevianceStyleLength       *width;
    DevianceStyleBorderStyle   style;
    //DevianceStylePathFactory *path;
};

struct _DevianceStyleBorderRadius {
    DevianceStyleLength       *rx;
    DevianceStyleLength       *ry;
};

struct _DevianceStyleBorder {
	GObject parent_instance;
    DevianceStyleSelector *selectors;

    /*< public >*/
//    GList_DevianceStyleColor *colors;
//    GList_DevianceStyleLength *widths;

    DevianceStyleBorderImage  *image;
    DevianceStyleBorderDescription top;
    DevianceStyleBorderDescription right;
    DevianceStyleBorderDescription bottom;
    DevianceStyleBorderDescription left;

    DevianceStyleBorderRadius top_left;
    DevianceStyleBorderRadius top_right;
    DevianceStyleBorderRadius bottom_right;
    DevianceStyleBorderRadius bottom_left;
};

struct _DevianceStyleBorderClass {
	GObjectClass parent_class;
};

GType deviance_style_border_get_type();
DevianceStyleBorder *deviance_style_border_new();
guint deviance_style_border_hash(gconstpointer  key);
gboolean deviance_style_border_equal(gconstpointer  a, gconstpointer  b);
DevianceStyleState deviance_style_border_get_first_state(DevianceStyleBorder *self);
DevianceGraphicsData *deviance_style_border_to_graphics_data_stroke(DevianceStyleBorder *self, GtkStyle *style);
DevianceGraphicsData *deviance_style_border_to_graphics_data_fill(DevianceStyleBorder *self, GtkStyle *style);

void                 deviance_style_border_copy(DevianceStyleBorder *self, DevianceStyleBorder *border);
DevianceStyleBorder *deviance_style_border_clone(DevianceStyleBorder *self);
void                 deviance_style_border_merge(DevianceStyleBorder *self, DevianceStyleBorder *border);

G_END_DECLS


#endif /* __DEVIANCE_STYLE_BORDER_H__ */

