/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-data-stroke.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <cairo/cairo.h>

#include "graphics.h"
#include "styles.h"

#include "style-color.h"
#include "style-color-scheme.h"
#include "graphics-painter.h"
#include "graphics-data.h"

#include "graphics-data-stroke.h"


static void deviance_graphics_data_stroke_class_init(DevianceGraphicsDataStrokeClass *klass);
static void deviance_graphics_data_stroke_init(DevianceGraphicsDataStroke *gobject);

G_DEFINE_TYPE (DevianceGraphicsDataStroke, deviance_graphics_data_stroke, DEVIANCE_TYPE_GRAPHICS_DATA)

static void
deviance_graphics_data_stroke_class_graphics_data_draw(DevianceGraphicsData *data, cairo_t *cr, gboolean preserve)
{
    DevianceGraphicsDataStroke *self = DEVIANCE_GRAPHICS_DATA_STROKE(data);
    gdouble red, green, blue, alpha;
    cairo_pattern_get_rgba(self->pattern, &red, &green, &blue, &alpha);
    cairo_set_source(cr, self->pattern);//cairo_set_source_surface(); ???
    cairo_set_line_width(cr, self->width);
    cairo_set_line_cap(cr, self->cap);
    cairo_set_line_join(cr, self->join);
    cairo_set_miter_limit(cr, self->miter_limit);

    preserve ? cairo_stroke_preserve(cr):cairo_stroke(cr);
}

static void
deviance_graphics_data_stroke_class_graphics_data_update_resize(DevianceGraphicsData *data, cairo_rectangle_t *rectangle)
{
    //g_message("deviance_graphics_data_stroke::update_resize not implemented");
}

static void
deviance_graphics_data_stroke_class_init(DevianceGraphicsDataStrokeClass *klass)
{
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->draw = deviance_graphics_data_stroke_class_graphics_data_draw;
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->update_resize = deviance_graphics_data_stroke_class_graphics_data_update_resize;
    //DEVIANCE_GRAPHICS_DATA_CLASS(klass)->update_style = deviance_graphics_data_stroke_class_graphics_data_update_style;
}

static void
deviance_graphics_data_stroke_init (DevianceGraphicsDataStroke *object)
{
    object->pattern = NULL;
    object->width = 1.0;
    object->cap = CAIRO_LINE_CAP_BUTT;
    object->join = CAIRO_LINE_JOIN_MITER;
    object->miter_limit = 10.0;
}

DevianceGraphicsDataStroke *
deviance_graphics_data_stroke_new (void)
{
	return g_object_new (deviance_graphics_data_stroke_get_type (),
	                     NULL);
}

