/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * parser.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "display.h"
#include "graphics.h"
#include "styles.h"

#include "graphics-data.h"

#include "style-image.h"
#include "style-image-gradient.h"
#include "style-image-url.h"
#include "style-color.h"
#include "style-length.h"
#include "style-background.h"
#include "style-border-image.h"
#include "style-border.h"
#include "style-selector.h"

#include "deviance_rc_style.h"
#include "parser.h"

#include <string.h>

#if 0
enum {
    UX_TOKEN_LINEAR_GRADIENT = G_TOKEN_LAST + 200, // TOKEN_STYLE + 1
    UX_TOKEN_RADIAL_GRADIENT,
    UX_TOKEN_TOP,
    UX_TOKEN_RIGHT,
    UX_TOKEN_BOTTOM,
    UX_TOKEN_LEFT,
    UX_TOKEN_CENTER,
    UX_TOKEN_REPEAT,
    UX_TOKEN_NO_REPEAT,
    UX_TOKEN_REPEAT_X,
    UX_TOKEN_REPEAT_Y,
    UX_TOKEN_URL,
    UX_TOKEN_SHADE,
    UX_TOKEN_INSET,
    UX_TOKEN_OUTSET,
    UX_TOKEN_RGB,
    UX_TOKEN_RGBA,

    UX_TOKEN_LAST
};

static const struct {
    gchar *name;
    guint  token;
} theme_symbols[] = {
    { "bottom",          UX_TOKEN_BOTTOM },
    { "center",          UX_TOKEN_CENTER },
    { "inset",           UX_TOKEN_INSET },
    { "outset",          UX_TOKEN_OUTSET },
    { "left",            UX_TOKEN_LEFT },
    { "linear-gradient", UX_TOKEN_LINEAR_GRADIENT },
    { "no-repeat",       UX_TOKEN_NO_REPEAT },
    { "radial-gradient", UX_TOKEN_RADIAL_GRADIENT },
    { "repeat",          UX_TOKEN_REPEAT },
    { "repeat-x",        UX_TOKEN_REPEAT_X },
    { "repeat-y",        UX_TOKEN_REPEAT_Y },
    { "right",           UX_TOKEN_RIGHT },
    { "rgb",             UX_TOKEN_RGB },
    { "rgba",            UX_TOKEN_RGBA },
    { "shade",           UX_TOKEN_SHADE },
    { "top",             UX_TOKEN_TOP },
    { "url",             UX_TOKEN_URL }
};


static GScanner *ux_parser_scanner = NULL;

GScanner*
ux_parser_new (void)
{
    if (ux_parser_scanner) {
        return ux_parser_scanner;
    }


    static GQuark scope_id = 0;
    gint i = 0;
    GScanner *scanner = g_scanner_new (NULL);

    /* adjust lexing behaviour to suit our needs
     */
    /* convert non-floats (octal values, hex values...) to G_TOKEN_INT */
//    scanner->config->numbers_2_int = TRUE;
    /* convert G_TOKEN_INT to G_TOKEN_FLOAT */
//    scanner->config->int_2_float = TRUE;
    /* don't return G_TOKEN_SYMBOL, but the symbol's value */
//    scanner->config->symbol_2_token = FALSE;
///    scanner->config->symbol_2_token = FALSE;
//    scanner->config->identifier_2_string = TRUE;
//    scanner->config->cset_identifier_first = "@";
///    scanner->config->cset_identifier_nth = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-";
    //scanner->config->scan_identifier = TRUE;
    //scanner->config->scan_symbols = TRUE;
    ///scanner->config->cpair_comment_single = "// \n";
    //scanner->config->skip_comment_multi = TRUE;
    //scanner->config->skip_comment_single = FALSE;

    //scope_id = g_quark_from_string("ux_theme_engine");
    //g_scanner_set_scope(scanner, scope_id);

//    if (!g_scanner_lookup_symbol(scanner, theme_symbols[0].name))
//    {
        //g_scanner_freeze_symbol_table(scanner);
        for (i = 0; i < G_N_ELEMENTS (theme_symbols); i++) {
            //g_scanner_scope_add_symbol(scanner, scope_id, theme_symbols[i].name, GINT_TO_POINTER(theme_symbols[i].token));
            g_scanner_add_symbol(scanner, theme_symbols[i].name, GINT_TO_POINTER(theme_symbols[i].token));
        }
        //g_scanner_thaw_symbol_table(scanner);
//    }

    ux_parser_scanner = scanner;
    return ux_parser_scanner;
}

GTokenType
ux_parser_parse_color_scheme(GScanner *scanner, gpointer data)
{
    gchar *start_text = scanner->text;
    guint start_position = scanner->position;
    gchar *color_name;
    GTokenType token = g_scanner_get_next_token(scanner);
    if (token!='@') {
        scanner->position = start_position;
        scanner->text = start_text;
        return '@';
    }
    token = g_scanner_get_next_token(scanner);
    switch (token) {
    case G_TOKEN_IDENTIFIER:
        color_name = g_scanner_cur_value(scanner).v_identifier;
        g_print("\tID=> @\"%s\"\n", color_name);
        GdkColor gdk_color;
//        gboolean success = gtk_style_lookup_color (style, color_name, &gdk_color);
//        if (success) {
//            g_print("\tGdkColor{%0.2X, %0.2X, %0.2X}\n", gdk_color.red, gdk_color.green, gdk_color.blue);
//        }
        break;
    default:
        g_print("parse_background_color\n");
        break;
    }

    return G_TOKEN_NONE;
}

GTokenType
ux_parser_parse_color_rgb(GScanner *scanner, gpointer data)
{
    GTokenType token;
    guint start_text = scanner->text;
    guint start_position = scanner->position;
    token = g_scanner_get_next_token(scanner);
    if (G_TOKEN_SYMBOL==token) {
        guint symbol = g_scanner_cur_value(scanner).v_symbol; //scanner->value.v_symbol;
        switch (symbol) {
        case UX_TOKEN_RGB:
        case UX_TOKEN_RGBA:
            token = g_scanner_get_next_token(scanner);
            if (G_TOKEN_LEFT_PAREN!=token) {

            }
            token = g_scanner_get_next_token(scanner);
            if (G_TOKEN_IDENTIFIER==token) {
                g_print("\t%s\n", scanner->value.v_identifier);
            } else {
                g_print("\t%d\n", scanner->token);
            }
            token = g_scanner_get_next_token(scanner);
            if (G_TOKEN_RIGHT_PAREN!=token) {

            }
            break;
        default:
            g_print("unmatch parse_background_color_rgb\n");
            break;
        }
    }

    return G_TOKEN_NONE;
}
GTokenType
ux_parser_parse_color_rgba(GScanner *scanner, gpointer data)
{
    guint start_position = scanner->position;
    GTokenType token = g_scanner_get_next_token(scanner);
    if (token=='@') {
        token = g_scanner_get_next_token(scanner);
    }
    switch (token) {
    case G_TOKEN_IDENTIFIER:
        g_print("\tID=> \"%s\"\n", g_scanner_cur_value(scanner).v_identifier);
        break;
    default:
        g_print("parse_background_color\n");
        break;
    }

    return G_TOKEN_NONE;
}
GTokenType
ux_parser_parse_color_hexa(GScanner *scanner, gpointer data)
{
    guint start_position = scanner->position;
    GTokenType token = g_scanner_get_next_token(scanner);
    if (token=='@') {
        token = g_scanner_get_next_token(scanner);
    }
    switch (token) {
    case G_TOKEN_IDENTIFIER:
        g_print("\tID=> \"%s\"\n", g_scanner_cur_value(scanner).v_identifier);
        break;
    default:
        g_print("parse_background_color\n");
        break;
    }

    return G_TOKEN_NONE;
}

GTokenType
ux_parser_parse_color_hexadecimal(GScanner *scanner, gpointer data)
{
    gchar *start_text = scanner->text;
    guint start_position = scanner->position;
    GdkColor color;
    //guint token = gtk_rc_parse_color(scanner, &color);
    gboolean success = gdk_color_parse(scanner->text, &color);
    if (success) {
        //g_scanner_get_next_token(scanner);
        g_print ("GdkColor{%0.2X, %0.2X, %0.2X} -> %d\n", color.red/0x100, color.green/0x100, color.blue/0x100, scanner->position);
    }
    /*
    GTokenType token = g_scanner_get_next_token(scanner);
    if (token!='#') {
        scanner->position = start_position;
        scanner->text = start_text;
        return '#';
    }
    token = g_scanner_get_next_token(scanner);
    switch (token) {
    case G_TOKEN_IDENTIFIER:
        g_print("\t0x%s\n", g_scanner_cur_value(scanner).v_identifier);
        break;
    default:
        g_print("1) unexpected token: %d\n", token);
        break;
    }
    */

    return G_TOKEN_NONE;
}

GTokenType
ux_parser_parse_color_shade(GScanner *scanner, gpointer data)
{
    guint start_position = scanner->position;
    GTokenType token = g_scanner_get_next_token(scanner);
    if (token=='@') {
        token = g_scanner_get_next_token(scanner);
    }
    switch (token) {
    case G_TOKEN_IDENTIFIER:
        g_print("\tID=> @\"%s\"\n", g_scanner_cur_value(scanner).v_identifier);
        break;
    default:
        g_print("2) unexpected token: %d\n", token);
        break;
    }

    return G_TOKEN_NONE;
}

/**
 * @bg_color
 * #FF0077
 * #F07
 * rgb()
 * rgba()
 * shade()
 * red
 */
GTokenType
ux_parser_parse_color(GScanner *scanner, gpointer data)
{
    GTokenType token;
    // try identifier

/*
    gchar *start_text = scanner->text;
    guint start_position = scanner->position;
    token = g_scanner_get_next_token(scanner);
    g_print("1]token: %c(%p)\n", token, start_text);
    if (token!='@') {
        scanner->position = start_position;
        scanner->text = start_text;

    } else {
        return G_TOKEN_NONE;
    }
    g_print("scanner->text: %s\n", scanner->text);
    token = g_scanner_get_next_token(scanner);
    g_print("2]token: %c (%d)\n", token, scanner->position);
    if (token!='#') {
        scanner->position = start_position;
    } else {
        return G_TOKEN_NONE;
    }
*/


    token = ux_parser_parse_color_scheme(scanner, data);
    if (G_TOKEN_NONE==token) {
        return G_TOKEN_NONE;
    }
    token = ux_parser_parse_color_hexadecimal(scanner, data);
    if (G_TOKEN_NONE==token) {
        return G_TOKEN_NONE;
    }
    token = ux_parser_parse_color_rgb(scanner, data);
    if (G_TOKEN_NONE==token) {
        return G_TOKEN_NONE;
    }

    // try hexadecimal
    // try hexa
    // try rgb
    // try rgba
    // try shade
    // try ICC

    return G_TOKEN_NONE;
}


void
ux_parser_parse_background(gchar *text, gpointer data)
{
    GScanner *scanner = ux_parser_new ();
    g_scanner_input_text (scanner, text, strlen (text));
    /* give the error handler an idea on how the input is named */
    scanner->input_name = g_strdup("ux_theme_engine");

    g_print("ux_parser_parse_background>%s\n", text);


    // Try background-color
    GTokenType token;
    token = ux_parser_parse_color(scanner, NULL);
    if (G_TOKEN_NONE==token) {

    } else {
        g_print("No color\n");
    }
//    token = ux_parser_parse_background_image(scanner, NULL);
//    if (G_TOKEN_NONE==token) {
//    }

    /*
    //token = g_scanner_peek_next_token (scanner);
    token = g_scanner_get_next_token(scanner);
    if (token=='@') {
        token = g_scanner_get_next_token(scanner);
    }
    g_print("token=> %d - %c\n", scanner->token, token);
    switch (token) {
    case G_TOKEN_IDENTIFIER:
        g_print("\tID=> \"%s\"\n", g_scanner_cur_value(scanner).v_identifier);
    break;
    case G_TOKEN_SYMBOL:
        switch (g_scanner_cur_value(scanner).v_symbol) {
        case UX_TOKEN_SHADE:
        break;
        }
        g_print("\tSYMBOL=> %d\n", g_scanner_cur_value(scanner).v_symbol);
    break;
    case G_TOKEN_STRING:
        g_print("\tSTRING=> %s\n", g_scanner_cur_value(scanner).v_string);
    break;
    case UX_TOKEN_TOP:
        g_print("\tTOKEN=> %d\n", g_scanner_cur_value(scanner).v_string);
    break;
    default:
        g_print("\t?=> %d\n", G_TOKEN_SYMBOL);
    break;
    }
    */



}

#endif


