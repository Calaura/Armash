/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-length.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_STYLE_LENGTH_H__
#define __DEVIANCE_STYLE_LENGTH_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS


typedef enum _DevianceStyleLengthType DevianceStyleLengthType;
enum _DevianceStyleLengthType {
    DEVIANCE_STYLE_LENGTH_TYPE_UNKNOW = 0,
    DEVIANCE_STYLE_LENGTH_TYPE_NUMBER,
    DEVIANCE_STYLE_LENGTH_TYPE_PERCENTAGE,
    DEVIANCE_STYLE_LENGTH_TYPE_PX
};

#define DEVIANCE_TYPE_STYLE_LENGTH            (deviance_style_length_get_type())
#define DEVIANCE_STYLE_LENGTH(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_STYLE_LENGTH, DevianceStyleLength))
#define DEVIANCE_STYLE_LENGTH_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_STYLE_LENGTH, DevianceStyleLengthClass))
#define DEVIANCE_IS_STYLE_LENGTH(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_STYLE_LENGTH))
#define DEVIANCE_IS_STYLE_LENGTH_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_STYLE_LENGTH))
#define DEVIANCE_STYLE_LENGTH_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_STYLE_LENGTH, DevianceStyleLengthClass))

typedef struct _DevianceStyleLengthClass DevianceStyleLengthClass;

struct _DevianceStyleLength {
	GObject parent_instance;

    /*< public >*/
    gboolean  is_set;

    gdouble  value;
    DevianceStyleLengthType unit;
    gpointer context;/* the context for relative length %percentage : UxDisplayViewport(GtkWidget) */
};

struct _DevianceStyleLengthClass {
	GObjectClass parent_class;
};

GType deviance_style_length_get_type();
DevianceStyleLength *deviance_style_length_new();
void deviance_style_length_copy (DevianceStyleLength *self, DevianceStyleLength *length);
gdouble deviance_style_length_get_value(DevianceStyleLength *length, gpointer context);
DevianceStyleLength *deviance_style_length_clone (DevianceStyleLength *self);

G_END_DECLS

#endif /* __DEVIANCE_STYLE_LENGTH_H__ */

