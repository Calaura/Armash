/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-color.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <cairo/cairo.h>


#include "display.h"
#include "graphics.h"
#include "styles.h"

#include "style-color.h"

#include "graphics-data.h"
#include "graphics-data-path.h"
#include "graphics-data-fill.h"
#include "graphics-data-stroke.h"
#include "display-object.h"
#include "display-shape.h"


#include "deviance_style.h"

#include "style-color.h"
#include "style-color-html.h"
#include "style-color-scheme.h"
#include "style-color-palette.h"
#include "style-color-shade.h"
#include "style-color-mix.h"

#include "cairo-support.h"

static DevianceStyleColor *deviance_style_color_default_clone(DevianceStyleColor *self);
static void                deviance_style_color_default_copy(DevianceStyleColor *self, DevianceStyleColor *color);

static void deviance_style_color_class_init(DevianceStyleColorClass *klass);
static void deviance_style_color_init(DevianceStyleColor *gobject);

G_DEFINE_TYPE (DevianceStyleColor, deviance_style_color, G_TYPE_OBJECT)

static DevianceGraphicsData*
deviance_style_color_class_style_color_to_graphics(DevianceStyleColor *self, GtkStyle *gtk_style)
{
    DevianceStyle *style = DEVIANCE_STYLE(gtk_style);

    if (DEVIANCE_IS_STYLE_COLOR_SCHEME(self)) {
        GdkColor gdk_color;
        gboolean succes = gtk_style_lookup_color(gtk_style, DEVIANCE_STYLE_COLOR_SCHEME(self)->scheme, &gdk_color);
        self->r = gdk_color.red/(double)0x10000;
        self->g = gdk_color.green/(double)0x10000;
        self->b = gdk_color.blue/(double)0x10000;
    } else if (DEVIANCE_IS_STYLE_COLOR_HTML(self)) {
        GdkColor gdk_color;
        DevianceStyleColorHtml *color_html = DEVIANCE_STYLE_COLOR_HTML(self);
        gdk_color_parse(color_html->string, &gdk_color);
        self->r = gdk_color.red/(double)0x10000;
        self->g = gdk_color.green/(double)0x10000;
        self->b = gdk_color.blue/(double)0x10000;
    } else if (DEVIANCE_IS_STYLE_COLOR_PALETTE(self)) {
        GdkColor *gdk_color;
        DevianceStyleColorPalette*color_palette = DEVIANCE_STYLE_COLOR_PALETTE(self);
//        color_palette->name;// bg, fg, ...
//        color_palette->state;// NORMAL, ACTIVE, ...
        if (g_strcmp0(color_palette->name, "bg")==0) {
            // TODO:
            if (g_strcmp0(color_palette->state, "NORMAL")==0) {
                gdk_color = &gtk_style->bg[GTK_STATE_NORMAL];
            } else if (g_strcmp0(color_palette->state, "ACTIVE")==0) {
                gdk_color = &gtk_style->bg[GTK_STATE_ACTIVE];
            } else if (g_strcmp0(color_palette->state, "PRELIGHT")==0) {
                gdk_color = &gtk_style->bg[GTK_STATE_PRELIGHT];
            } else if (g_strcmp0(color_palette->state, "INSENSITIVE")==0) {
                gdk_color = &gtk_style->bg[GTK_STATE_INSENSITIVE];
            }
            self->r = gdk_color->red/(double)0x10000;
            self->g = gdk_color->green/(double)0x10000;
            self->b = gdk_color->blue/(double)0x10000;
        } else if (g_strcmp0(color_palette->name, "fg")==0) {
        }
    } else if (DEVIANCE_IS_STYLE_COLOR_SHADE(self)) {
        deviance_style_color_to_graphics(DEVIANCE_STYLE_COLOR_SHADE(self)->color, gtk_style);
        // shade.ratio|color.get_color()
        DevianceRGB a = {DEVIANCE_STYLE_COLOR_SHADE(self)->color->r, DEVIANCE_STYLE_COLOR_SHADE(self)->color->g, DEVIANCE_STYLE_COLOR_SHADE(self)->color->b};
        DevianceRGB b;
        float k = DEVIANCE_STYLE_COLOR_SHADE(self)->ratio;
        deviance_shade(&a, k, &b);
        self->r = b.r;
        self->g = b.g;
        self->b = b.b;
    } else if (DEVIANCE_IS_STYLE_COLOR_MIX(self)) {
        deviance_style_color_to_graphics(DEVIANCE_STYLE_COLOR_MIX(self)->color_a, gtk_style);
        deviance_style_color_to_graphics(DEVIANCE_STYLE_COLOR_MIX(self)->color_b, gtk_style);
        DevianceRGB a = {DEVIANCE_STYLE_COLOR_MIX(self)->color_a->r, DEVIANCE_STYLE_COLOR_MIX(self)->color_a->g, DEVIANCE_STYLE_COLOR_MIX(self)->color_a->b};
        DevianceRGB b = {DEVIANCE_STYLE_COLOR_MIX(self)->color_b->r, DEVIANCE_STYLE_COLOR_MIX(self)->color_b->g, DEVIANCE_STYLE_COLOR_MIX(self)->color_b->b};
        DevianceRGB color;
        float k = DEVIANCE_STYLE_COLOR_MIX(self)->ratio;
        deviance_mix_color(&a, &b, k, &color);
        self->r = color.r;
        self->g = color.g;
        self->b = color.b;
    } else if (DEVIANCE_IS_STYLE_COLOR(self)) {
        self->r = self->r;
        self->g = self->g;
        self->b = self->b;
    }

    return NULL;
}

static void
deviance_style_color_class_init(DevianceStyleColorClass *klass)
{
    klass->to_graphics = deviance_style_color_class_style_color_to_graphics;
    klass->clone       = deviance_style_color_default_clone;
    klass->copy        = deviance_style_color_default_copy;
}

static void
deviance_style_color_init (DevianceStyleColor *object)
{
    object->r = 0.00;
    object->g = 0.00;
    object->b = 0.00;

    object->a = 1.00;

    object->is_set = FALSE;
}

DevianceStyleColor *
deviance_style_color_new (void)
{
	return g_object_new (deviance_style_color_get_type (),
	                     NULL);

}

static void
deviance_style_color_default_copy(DevianceStyleColor *self, DevianceStyleColor *color)
{
    color->r = self->r;
    color->g = self->g;
    color->b = self->b;

    color->a = self->a;

    color->is_set = self->is_set;
}

static DevianceStyleColor*
deviance_style_color_default_clone(DevianceStyleColor *self)
{
    DevianceStyleColor *clone = g_object_new (DEVIANCE_TYPE_STYLE_COLOR, NULL);

    deviance_style_color_default_copy(self, clone);

    return clone;
}

DevianceStyleColor*
deviance_style_color_clone(DevianceStyleColor *self)
{
    g_assert(DEVIANCE_IS_STYLE_COLOR(self));

    return DEVIANCE_STYLE_COLOR_GET_CLASS(self)->clone(self);
}

void
deviance_style_color_copy(DevianceStyleColor *self, DevianceStyleColor *color)
{
    g_assert(DEVIANCE_IS_STYLE_COLOR(self));

    DEVIANCE_STYLE_COLOR_GET_CLASS(self)->copy(self, color);
}
void
deviance_style_color_merge(DevianceStyleColor *self, DevianceStyleColor **dest)
{
    DevianceStyleColor *color = *dest;
    if (color!=NULL && color->is_set) {
        return;
    }

    if (color && G_TYPE_FROM_INSTANCE(color)==G_TYPE_FROM_INSTANCE(self)) {
        deviance_style_color_copy(self, color);
    } else {
        if (color) {
            g_object_unref(color);
        }
        color = deviance_style_color_clone(self);
        *dest = color;
    }
}

DevianceGraphicsData*
deviance_style_color_to_graphics(DevianceStyleColor *self, GtkStyle *style)
{
    g_assert(DEVIANCE_IS_STYLE_COLOR(self));

    return DEVIANCE_STYLE_COLOR_GET_CLASS(self)->to_graphics(self, style);
}

DevianceGraphicsData*
deviance_style_color_to_graphics_data_fill(DevianceStyleColor *self, GtkStyle *style)
{
    DevianceGraphicsDataFill *data = deviance_graphics_data_fill_new();

    deviance_style_color_to_graphics(self, style);

    //data->pattern = cairo_pattern_create_rgb(self->r, self->g, self->b);
    data->pattern = cairo_pattern_create_rgba(self->r, self->g, self->b, self->a);

    return data;
}

DevianceGraphicsData*
deviance_style_color_to_graphics_data_stroke(DevianceStyleColor *self, GtkStyle *style)
{
    DevianceGraphicsDataStroke *data = deviance_graphics_data_stroke_new();

    deviance_style_color_to_graphics(self, style);

    data->width = 1.0;
    data->pattern = cairo_pattern_create_rgba(self->r, self->g, self->b, self->a);

    return data;
}
