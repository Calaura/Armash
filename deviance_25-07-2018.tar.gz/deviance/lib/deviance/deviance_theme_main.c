/* Deviance theme engine
 * Copyright (C) 2006-2007-2008-2009 Andrea Cimitan
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <gmodule.h>
#include <gtk/gtk.h>

#include <cairo/cairo.h>

#include "display.h"
#include "graphics.h"
#include "styles.h"

#include "graphics-data.h"

#include "style-length.h"
#include "style-color.h"
#include "style-image.h"
#include "style-image-gradient.h"
#include "style-image-url.h"
#include "style-background.h"
#include "style-border.h"
#include "styles.h"

#include "display-object.h"

#include "deviance_style.h"
#include "deviance_rc_style.h"

G_MODULE_EXPORT void
theme_init (GTypeModule *module)
{
    g_print("-> %s\n", G_STRFUNC);
//	printf ("Deviance 0.91.x Development Snapshot, Copyright Andrea Cimitan\n"); 
	deviance_rc_style_register_types (module);
	deviance_style_register_types (module);
}

G_MODULE_EXPORT void
theme_exit (void)
{
    g_print("-> %s\n", G_STRFUNC);
}

G_MODULE_EXPORT GtkRcStyle *
theme_create_rc_style (void)
{
    GtkRcStyle *rc_style = GTK_RC_STYLE (g_object_new (DEVIANCE_TYPE_RC_STYLE, NULL));
    g_print("-> %s (%p)\n", G_STRFUNC, rc_style);
    return rc_style;
}

/* The following function will be called by GTK+ when the module
 * is loaded and checks to see if we are compatible with the
 * version of GTK+ that loads us.
 */
G_MODULE_EXPORT const gchar* g_module_check_init (GModule *module);
const gchar*
g_module_check_init (GModule *module)
{
    g_print("-> %s\n", G_STRFUNC);
    return gtk_check_version (GTK_MAJOR_VERSION,
	                          GTK_MINOR_VERSION,
	                          GTK_MICRO_VERSION - GTK_INTERFACE_AGE);
}
