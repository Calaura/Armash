/* Deviance theme engine
 * Copyright (C) 2006-2007-2008-2009 Andrea Cimitan
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <cairo/cairo.h>

#include "styles.h"
#include "graphics.h"
#include "display.h"

#include "style-length.h"
#include "style-color.h"
#include "style-color-stop.h"
#include "style-color-html.h"
#include "style-color-scheme.h"
#include "style-color-shade.h"
#include "style-color-mix.h"
#include "style-color-palette.h"
#include "style-image.h"
#include "style-image-gradient.h"
#include "style-image-gradient-linear.h"
#include "style-image-gradient-radial.h"
#include "style-image-url.h"
#include "style-background.h"
#include "style-border.h"
#include "style-box-shadow.h"
#include "style-background.h"
#include "style-selector.h"

#include "cairo-support.h"
#include "parser.h"


#include "graphics-data.h"
#include "graphics-data-path.h"
#include "graphics-data-fill.h"
#include "graphics-data-stroke.h"

#include "display-object.h"
#include "display-container.h"
#include "display-shape.h"

#include "deviance_style.h"
#include "deviance_rc_style.h"



#include "animation.h"

#ifdef HAVE_ANIMATION
static void deviance_rc_style_finalize (GObject *object);
#endif
static GtkRcStyle *deviance_rc_style_create_rc_style(GtkRcStyle *rc_style);
static GtkStyle *deviance_rc_style_create_style (GtkRcStyle *rc_style);
static guint deviance_rc_style_parse (GtkRcStyle  *rc_style,
                                     GtkSettings *settings,
                                     GScanner    *scanner);
static void deviance_rc_style_merge (GtkRcStyle *dest,
                                    GtkRcStyle *src);

enum
{
    TOKEN_ACTIVE = G_TOKEN_LAST + 1,

    TOKEN_ANIMATION,
	TOKEN_ARROWSTYLE,
    TOKEN_BORDER_COLORS,
	TOKEN_BORDER_SHADES,
    TOKEN_BORDER_TOP_LEFT_RADIUS,
    TOKEN_BORDER_TOP_RIGHT_RADIUS,
    TOKEN_BORDER_BOTTOM_LEFT_RADIUS,
    TOKEN_BORDER_BOTTOM_RIGHT_RADIUS,
    TOKEN_BOX_SHADOW,
	TOKEN_COLORIZE_SCROLLBAR,
	TOKEN_CELLSTYLE,
	TOKEN_COMBOBOXSTYLE,
	TOKEN_CONTRAST,
	TOKEN_DEFAULT_BUTTON_COLOR,
	TOKEN_EXPANDERSTYLE,
	TOKEN_FOCUS_COLOR,
    TOKEN_FOCUSSTYLE,
    TOKEN_FIRST_CHILD,
	TOKEN_GLAZESTYLE,
	TOKEN_GLOW_SHADE,
	TOKEN_GLOWSTYLE,
	TOKEN_GRADIENT_COLORS,
	TOKEN_GRADIENT_SHADES,
	TOKEN_HANDLESTYLE,
    TOKEN_HIGHLIGHT_SHADE,
    TOKEN_INSET,
    TOKEN_INSENSITIVE,
    TOKEN_LIGHTBORDER_SHADE,
	TOKEN_LIGHTBORDERSTYLE,
	TOKEN_LISTVIEWHEADERSTYLE,
	TOKEN_LISTVIEWSTYLE,
    TOKEN_MENUBARITEMSTYLE,
	TOKEN_MENUBARSTYLE,
	TOKEN_MENUITEMSTYLE,
	TOKEN_MENUSTYLE,
    TOKEN_NORMAL,
    TOKEN_PRELIGHT,
    TOKEN_PRELIGHT_SHADE,
	TOKEN_PROGRESSBARSTYLE,
	TOKEN_RELIEFSTYLE,
    TOKEN_RGB,
    TOKEN_RGBA,
    TOKEN_ROUNDNESS,
    TOKEN_SELECTED,
	TOKEN_SCROLLBARSTYLE,
	TOKEN_SEPARATORSTYLE,
	TOKEN_SHADOW_SHADES,
	TOKEN_SLIDERSTYLE,
	TOKEN_SPINBUTTONSTYLE,
	TOKEN_STEPPERSTYLE,
	TOKEN_TEXTSTYLE,
	TOKEN_TEXT_SHADE,
	TOKEN_TOOLBARSTYLE,
	TOKEN_TROUGH_BORDER_SHADES,
	TOKEN_TROUGH_SHADES,	

	TOKEN_TRUE,
	TOKEN_FALSE,

	/* stuff to ignore */
	TOKEN_GRADIENTS,
	TOKEN_HILIGHT_RATIO,
	TOKEN_HIGHLIGHT_RATIO,
	TOKEN_LIGHTBORDER_RATIO,
	TOKEN_PROFILE,
	TOKEN_SCROLLBAR_COLOR,
    TOKEN_SQUAREDSTYLE,
    TOKEN_BACKGROUND,
    TOKEN_BORDER,
    TOKEN_BORDER_COLOR,
    TOKEN_BORDER_WIDTH,
    TOKEN_BORDER_RADIUS,
    TOKEN_BORDER_IMAGE,
    TOKEN_COLOR,
    TOKEN_TRANSPARENT,
    TOKEN_LINEAR_GRADIENT,
    TOKEN_RADIAL_GRADIENT,
    TOKEN_TO,
    TOKEN_CENTER,
    TOKEN_TOP,
    TOKEN_RIGHT,
    TOKEN_BOTTOM,
    TOKEN_LEFT,
//    TOKEN_SHADE,
    TOKEN_STYLE,
    TOKEN_URL
};


static struct
{
	const gchar *name;
	guint        token;
}
theme_symbols[] =
{
    { "active",              TOKEN_ACTIVE },
    { "animation",           TOKEN_ANIMATION },
    { "arrowstyle",          TOKEN_ARROWSTYLE },
	{ "border_colors",       TOKEN_BORDER_COLORS },
	{ "border_shades",       TOKEN_BORDER_SHADES },
    { "border-top-left-radius", TOKEN_BORDER_TOP_LEFT_RADIUS },
    { "border-top-right-radius", TOKEN_BORDER_TOP_RIGHT_RADIUS },
    { "border-bottom-left-radius", TOKEN_BORDER_BOTTOM_LEFT_RADIUS },
    { "border-bottom-right-radius", TOKEN_BORDER_BOTTOM_RIGHT_RADIUS },
    { "box-shadow",          TOKEN_BOX_SHADOW },
	{ "colorize_scrollbar",  TOKEN_COLORIZE_SCROLLBAR },
	{ "cellstyle",           TOKEN_CELLSTYLE },	
	{ "comboboxstyle",       TOKEN_COMBOBOXSTYLE },
	{ "contrast",            TOKEN_CONTRAST },
	{ "default_button_color", TOKEN_DEFAULT_BUTTON_COLOR },
	{ "expanderstyle",       TOKEN_EXPANDERSTYLE },
	{ "focus_color",         TOKEN_FOCUS_COLOR },
	{ "focusstyle",          TOKEN_FOCUSSTYLE },
	{ "glazestyle",          TOKEN_GLAZESTYLE },
	{ "glow_shade",          TOKEN_GLOW_SHADE },
	{ "glowstyle",           TOKEN_GLOWSTYLE },
	{ "gradient_colors",     TOKEN_GRADIENT_COLORS },
	{ "gradient_shades",     TOKEN_GRADIENT_SHADES },
	{ "handlestyle",         TOKEN_HANDLESTYLE },
	{ "highlight_shade",     TOKEN_HIGHLIGHT_SHADE },
    { "inset",               TOKEN_INSET },
    { "insensitive",         TOKEN_INSENSITIVE },
    { "lightborder_shade",   TOKEN_LIGHTBORDER_SHADE },
	{ "lightborderstyle",    TOKEN_LIGHTBORDERSTYLE },
	{ "listviewheaderstyle", TOKEN_LISTVIEWHEADERSTYLE },
	{ "listviewstyle",       TOKEN_LISTVIEWSTYLE },
	{ "menubaritemstyle",    TOKEN_MENUBARITEMSTYLE },
	{ "menubarstyle",        TOKEN_MENUBARSTYLE },
	{ "menuitemstyle",       TOKEN_MENUITEMSTYLE },
	{ "menustyle",           TOKEN_MENUSTYLE },
    { "normal",              TOKEN_NORMAL },
    { "prelight",            TOKEN_PRELIGHT },
	{ "prelight_shade",      TOKEN_PRELIGHT_SHADE },
	{ "progressbarstyle",    TOKEN_PROGRESSBARSTYLE },
	{ "reliefstyle",         TOKEN_RELIEFSTYLE },
    { "rgb",                 TOKEN_RGB },
    { "rgba",                TOKEN_RGBA },
    { "roundness",           TOKEN_ROUNDNESS },
	{ "scrollbarstyle",      TOKEN_SCROLLBARSTYLE },
    { "selected",            TOKEN_SELECTED },
	{ "separatorstyle",      TOKEN_SEPARATORSTYLE },
	{ "shadow_shades",       TOKEN_SHADOW_SHADES },
	{ "sliderstyle",         TOKEN_SLIDERSTYLE },
	{ "spinbuttonstyle",     TOKEN_SPINBUTTONSTYLE },
	{ "stepperstyle",        TOKEN_STEPPERSTYLE },
	{ "textstyle",           TOKEN_TEXTSTYLE },
	{ "text_shade",          TOKEN_TEXT_SHADE },
	{ "toolbarstyle",        TOKEN_TOOLBARSTYLE },
	{ "trough_border_shades", TOKEN_TROUGH_BORDER_SHADES },
	{ "trough_shades",       TOKEN_TROUGH_SHADES },

	{ "TRUE",                TOKEN_TRUE },
	{ "FALSE",               TOKEN_FALSE },

	/* stuff to ignore */
	{ "gradients",           TOKEN_GRADIENTS },
	{ "hilight_ratio",       TOKEN_HILIGHT_RATIO },
	{ "highlight_ratio",     TOKEN_HIGHLIGHT_RATIO },
	{ "lightborder_ratio",   TOKEN_LIGHTBORDER_RATIO },
	{ "profile",             TOKEN_PROFILE },
	{ "scrollbar_color",     TOKEN_SCROLLBAR_COLOR },
    { "squaredstyle",        TOKEN_SQUAREDSTYLE },
    { "background",          TOKEN_BACKGROUND },
    { "border",              TOKEN_BORDER },
    { "border-color",        TOKEN_BORDER_COLOR },
    { "border-width",        TOKEN_BORDER_WIDTH },
    { "border-radius",       TOKEN_BORDER_RADIUS },
    { "border-image",        TOKEN_BORDER_IMAGE },
    { "color",               TOKEN_COLOR },
    { "transparent",         TOKEN_TRANSPARENT },
    { "linear-gradient",     TOKEN_LINEAR_GRADIENT },
    { "radial-gradient",     TOKEN_RADIAL_GRADIENT },
    { "to",                  TOKEN_TO },
    { "center",              TOKEN_CENTER },
    { "top",                 TOKEN_TOP },
    { "right",               TOKEN_RIGHT },
    { "bottom",              TOKEN_BOTTOM },
    { "left",                TOKEN_LEFT },
//    { "shade",               TOKEN_SHADE },
    { "style",               TOKEN_STYLE },
    { "url",                 TOKEN_URL }
};

G_DEFINE_DYNAMIC_TYPE (DevianceRcStyle, deviance_rc_style, GTK_TYPE_RC_STYLE)

void
deviance_rc_style_register_types (GTypeModule *module)
{
	deviance_rc_style_register_type (module);
}

static void
deviance_rc_style_init (DevianceRcStyle *deviance_rc)
{
	deviance_rc->flags = 0;

	deviance_rc->animation = FALSE;
	deviance_rc->arrowstyle = 0;
	deviance_rc->border_shades[0] = 1.0;
	deviance_rc->border_shades[1] = 1.0;
	deviance_rc->cellstyle = 1;
	deviance_rc->colorize_scrollbar = TRUE;
	deviance_rc->comboboxstyle = 0;
	deviance_rc->contrast = 1.0;
	deviance_rc->expanderstyle = 0;
	deviance_rc->focusstyle = 2;
	deviance_rc->has_border_colors = FALSE;
	deviance_rc->has_default_button_color = FALSE;
	deviance_rc->has_gradient_colors = FALSE;
	deviance_rc->handlestyle = 0;
	deviance_rc->glazestyle = 1;
	deviance_rc->glow_shade = 1.0;
	deviance_rc->glowstyle = 0;
	deviance_rc->gradient_shades[0] = 1.1;
	deviance_rc->gradient_shades[1] = 1.0;
	deviance_rc->gradient_shades[2] = 1.0;
	deviance_rc->gradient_shades[3] = 1.1;
	deviance_rc->highlight_shade = 1.1;
	deviance_rc->lightborder_shade = 1.1;
	deviance_rc->lightborderstyle = 0;
	deviance_rc->listviewheaderstyle = 1;
	deviance_rc->listviewstyle = 0;
	deviance_rc->menubaritemstyle = 0;
	deviance_rc->menubarstyle = 0;
	deviance_rc->menuitemstyle = 1;
	deviance_rc->menustyle = 1;
	deviance_rc->prelight_shade = 1.04;
	deviance_rc->progressbarstyle = 1;
	deviance_rc->reliefstyle = 2;
	deviance_rc->rgba = FALSE;
	deviance_rc->roundness = 1;
	deviance_rc->scrollbarstyle = 0;
	deviance_rc->separatorstyle = 0;
	deviance_rc->shadow_shades[0] = 1.0;
	deviance_rc->shadow_shades[1] = 1.0;
	deviance_rc->sliderstyle = 0;
	deviance_rc->spinbuttonstyle = 0;
	deviance_rc->stepperstyle = 0;
	deviance_rc->textstyle = 0;
	deviance_rc->text_shade = 1.12;
	deviance_rc->toolbarstyle = 0;
	deviance_rc->trough_border_shades[0] = 1.0;
	deviance_rc->trough_border_shades[1] = 1.0;
	deviance_rc->trough_shades[0] = 1.0;
    deviance_rc->trough_shades[1] = 1.0;

    deviance_rc->_background = g_hash_table_new((GHashFunc)deviance_style_background_hash, (GEqualFunc)deviance_style_background_equal);
    deviance_rc->_border = g_hash_table_new((GHashFunc)deviance_style_border_hash, (GEqualFunc)deviance_style_border_equal);
    deviance_rc->_box_shadow = g_hash_table_new((GHashFunc)deviance_style_box_shadow_hash, (GEqualFunc)deviance_box_shadow_equal);
    deviance_rc->background = NULL;
    deviance_rc->border = NULL;
}

#ifdef HAVE_ANIMATION
static void
deviance_rc_style_finalize (GObject *object)
{
	/* cleanup all the animation stuff */
	deviance_animation_cleanup ();

	if (G_OBJECT_CLASS (deviance_rc_style_parent_class)->finalize != NULL)
		G_OBJECT_CLASS (deviance_rc_style_parent_class)->finalize(object);
}
#endif


static void
deviance_rc_style_class_init (DevianceRcStyleClass *klass)
{
	GtkRcStyleClass *rc_style_class = GTK_RC_STYLE_CLASS (klass);
#ifdef HAVE_ANIMATION
	GObjectClass    *g_object_class = G_OBJECT_CLASS (klass);
#endif

    rc_style_class->create_rc_style = deviance_rc_style_create_rc_style;
    rc_style_class->parse = deviance_rc_style_parse;
    rc_style_class->merge = deviance_rc_style_merge;
    rc_style_class->create_style = deviance_rc_style_create_style;

#ifdef HAVE_ANIMATION
	g_object_class->finalize = deviance_rc_style_finalize;
#endif
}

static void
deviance_rc_style_class_finalize (DevianceRcStyleClass *klass)
{
}

static guint
theme_parse_boolean (GtkSettings *settings,
                     GScanner     *scanner,
                     gboolean     *retval)
{
	guint token;

	/* Skip 'ANIMATION' */
	token = g_scanner_get_next_token(scanner);

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_EQUAL_SIGN)
		return G_TOKEN_EQUAL_SIGN;

	token = g_scanner_get_next_token(scanner);
	if (token == TOKEN_TRUE)
		*retval = TRUE;
	else if (token == TOKEN_FALSE)
		*retval = FALSE;
	else
		return TOKEN_TRUE;

	return G_TOKEN_NONE;
}

static guint
theme_parse_color (GtkSettings  *settings,
                   GScanner     *scanner,
                   GtkRcStyle   *style,
                   GdkColor     *color)
{
	guint token;

	/* Skip 'blah_color' */
	token = g_scanner_get_next_token(scanner);

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_EQUAL_SIGN)
		return G_TOKEN_EQUAL_SIGN;

	return gtk_rc_parse_color_full (scanner, style, color);
}

static guint
deviance_gtk2_rc_parse_dummy_color (GtkSettings      *settings,
                                   GScanner         *scanner,
                                   gchar            *name,
                                   GtkRcStyle       *style,
                                   GdkColor         *color)
{
	guint token;

	/* Skip option */
	token = g_scanner_get_next_token (scanner);

	/* print a warning. Isn't there a way to get the string from the scanner? */
	g_scanner_warn (scanner, "Deviance configuration option \"%s\" is no longer supported and will be ignored.", name);

	/* equal sign */
	/* Skip 'blah_color' */
	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_EQUAL_SIGN)
		return G_TOKEN_EQUAL_SIGN;

	return  gtk_rc_parse_color_full (scanner, style, color);
}

static guint
theme_parse_shade (GtkSettings  *settings,
                   GScanner     *scanner,
                   double       *ratio)
{
	guint token;

	/* Skip 'ratio' */
	token = g_scanner_get_next_token(scanner);

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_EQUAL_SIGN)
		return G_TOKEN_EQUAL_SIGN;

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_FLOAT)
		return G_TOKEN_FLOAT;

	*ratio = scanner->value.v_float;

	return G_TOKEN_NONE;
}

static guint
theme_parse_int (GtkSettings  *settings,
                 GScanner     *scanner,
                 guint8       *style)
{
	guint token;

	/* Skip '*style' */
	token = g_scanner_get_next_token(scanner);

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_EQUAL_SIGN)
		return G_TOKEN_EQUAL_SIGN;

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_INT)
		return G_TOKEN_INT;

	*style = scanner->value.v_int;

	return G_TOKEN_NONE;
}

static guint
theme_parse_gradient (GtkSettings  *settings,
                      GScanner     *scanner,
                      double       gradient_shades[4])
{
	guint               token;

	/* Skip 'blah_border' */
	token = g_scanner_get_next_token(scanner);

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_EQUAL_SIGN)
		return G_TOKEN_EQUAL_SIGN;

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_LEFT_CURLY)
		return G_TOKEN_LEFT_CURLY;

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_FLOAT)
		return G_TOKEN_FLOAT;
	gradient_shades[0] = scanner->value.v_float;
	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_COMMA)
		return G_TOKEN_COMMA;

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_FLOAT)
		return G_TOKEN_FLOAT;
	gradient_shades[1] = scanner->value.v_float;
	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_COMMA)
		return G_TOKEN_COMMA;

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_FLOAT)
		return G_TOKEN_FLOAT;
	gradient_shades[2] = scanner->value.v_float;
	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_COMMA)
		return G_TOKEN_COMMA;

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_FLOAT)
		return G_TOKEN_FLOAT;
	gradient_shades[3] = scanner->value.v_float;

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_RIGHT_CURLY)
		return G_TOKEN_RIGHT_CURLY;

	/* save those values */

	return G_TOKEN_NONE;
}

static guint
theme_parse_gradient_colors (GtkSettings  *settings,
                             GScanner     *scanner,
                             GtkRcStyle   *style,
                             gboolean     *retval,
                             GdkColor     gradient_colors[4])
{
	guint token;
	*retval = TRUE;

	/* Skip 'blah_border' */
	token = g_scanner_get_next_token(scanner);

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_EQUAL_SIGN)
		return G_TOKEN_EQUAL_SIGN;

	token = g_scanner_get_next_token(scanner);
	if (token == TOKEN_FALSE)
	{
		*retval = FALSE;
		return G_TOKEN_NONE;
	}
	else if (token != G_TOKEN_LEFT_CURLY)
		return G_TOKEN_LEFT_CURLY;

	gtk_rc_parse_color_full (scanner, style, &gradient_colors[0]);
	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_COMMA)
		return G_TOKEN_COMMA;

	gtk_rc_parse_color_full (scanner, style, &gradient_colors[1]);
	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_COMMA)
		return G_TOKEN_COMMA;

	gtk_rc_parse_color_full (scanner, style, &gradient_colors[2]);
	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_COMMA)
		return G_TOKEN_COMMA;

	gtk_rc_parse_color_full (scanner, style, &gradient_colors[3]);

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_RIGHT_CURLY)
		return G_TOKEN_RIGHT_CURLY;

	/* save those values */

	return G_TOKEN_NONE;
}

static guint
theme_parse_border_colors (GtkSettings  *settings,
                             GScanner     *scanner,
                             GtkRcStyle   *style,
                             gboolean     *retval,
                             GdkColor     border_colors[2])
{
	guint token;
	*retval = TRUE;

	/* Skip 'blah_border' */
	token = g_scanner_get_next_token(scanner);

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_EQUAL_SIGN)
		return G_TOKEN_EQUAL_SIGN;

	token = g_scanner_get_next_token(scanner);
	if (token == TOKEN_FALSE)
	{
		*retval = FALSE;
		return G_TOKEN_NONE;
	}
	else if (token != G_TOKEN_LEFT_CURLY)
		return G_TOKEN_LEFT_CURLY;

	gtk_rc_parse_color_full (scanner, style, &border_colors[0]);
	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_COMMA)
		return G_TOKEN_COMMA;

	gtk_rc_parse_color_full (scanner, style, &border_colors[1]);

	token = g_scanner_get_next_token(scanner);
	if (token != G_TOKEN_RIGHT_CURLY)
		return G_TOKEN_RIGHT_CURLY;

	/* save those values */

	return G_TOKEN_NONE;
}

static guint
theme_parse_border (GtkSettings  *settings,
                    GScanner     *scanner,
                    double       border_shades[2])
{
    guint               token;

    /* Skip 'blah_border' */
    token = g_scanner_get_next_token(scanner);

    token = g_scanner_get_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;

    token = g_scanner_get_next_token(scanner);
    if (token != G_TOKEN_LEFT_CURLY)
        return G_TOKEN_LEFT_CURLY;

    token = g_scanner_get_next_token(scanner);
    if (token != G_TOKEN_FLOAT)
        return G_TOKEN_FLOAT;
    border_shades[0] = scanner->value.v_float;
    token = g_scanner_get_next_token(scanner);
    if (token != G_TOKEN_COMMA)
        return G_TOKEN_COMMA;

    token = g_scanner_get_next_token(scanner);
    if (token != G_TOKEN_FLOAT)
        return G_TOKEN_FLOAT;
    border_shades[1] = scanner->value.v_float;

    token = g_scanner_get_next_token(scanner);
    if (token != G_TOKEN_RIGHT_CURLY)
        return G_TOKEN_RIGHT_CURLY;

    /* save those values */

    return G_TOKEN_NONE;
}


static guint
ux_parse_length (GtkSettings          *settings,
                 GScanner             *scanner,
                 GtkRcStyle           *rc_style,
                 DevianceStyleLength **length)
{
    GTokenType token;
    gdouble value;
    DevianceStyleLengthType unit;
    DevianceStyleLength *style_length;
    gdouble sign = 1.0;

    // 1
    token = g_scanner_peek_next_token(scanner);
    if (token == '-') {
        sign = -1.0;
        token = g_scanner_get_next_token(scanner);
    }
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_INT) {
        return G_TOKEN_INT;
    }
    token = g_scanner_get_next_token(scanner);
    value = (double)scanner->value.v_int;
    g_print("%d, %d\n", scanner->token, G_TOKEN_INT);

    // px, in, mm, %, etc...
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_IDENTIFIER && token != '%' ) {
        return G_TOKEN_IDENTIFIER;
    }

    token = g_scanner_get_next_token(scanner);
    if (G_TOKEN_IDENTIFIER==token) {
        if (0==g_strcmp0("px", scanner->value.v_identifier)) {
            unit = DEVIANCE_STYLE_LENGTH_TYPE_PX;
        } else {
            return G_TOKEN_IDENTIFIER;
        }
    } else if ('%'==token) {
        unit = DEVIANCE_STYLE_LENGTH_TYPE_PERCENTAGE;
    } else {
        return G_TOKEN_IDENTIFIER;
    }

    style_length = *length;
    if (style_length==NULL) {
        style_length = deviance_style_length_new();
    }
    style_length->value = value*sign;
    style_length->unit = unit;
    style_length->is_set = TRUE;

    *length = style_length;

    return G_TOKEN_NONE;
}

/*
static guint
theme_parse_background_image(settings, scanner, background)
{
    guint               token;

    token = g_scanner_get_next_token(scanner);

    token = g_scanner_get_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;

    token = g_scanner_get_next_token(scanner);
    if (token != G_TOKEN_STRING)
        return G_TOKEN_STRING;

    return token;
}
*/

static guint
ux_parse_selector (GtkSettings  *settings,
                   GScanner     *scanner,
                   GtkRcStyle   *rc_style,
                   DevianceStyleSelector **selector)
{
    DevianceStyleSelector *style_selector = *selector;
    if (style_selector==NULL) {
        style_selector = deviance_style_selector_new();
    }
    GTokenType token;

    DevianceStyleSelectorHash hash = style_selector->hash;

    // background:active
    token = g_scanner_peek_next_token(scanner);
    if (token == ':') {
        token = g_scanner_get_next_token(scanner);

        token = g_scanner_peek_next_token(scanner);
        switch (token) {
        case TOKEN_NORMAL:
            token = g_scanner_get_next_token(scanner);
            hash.state = DEVIANCE_STYLE_NORMAL_STATE;
            break;
        case TOKEN_ACTIVE:
            token = g_scanner_get_next_token(scanner);
            hash.state = DEVIANCE_STYLE_ACTIVE_STATE;
            break;
        case TOKEN_SELECTED:
            token = g_scanner_get_next_token(scanner);
            hash.state = DEVIANCE_STYLE_SELECTED_STATE;
            break;
        case TOKEN_PRELIGHT:
            token = g_scanner_get_next_token(scanner);
            hash.state = DEVIANCE_STYLE_PRELIGHT_STATE;
            break;
        case TOKEN_INSENSITIVE:
            token = g_scanner_get_next_token(scanner);
            hash.state = DEVIANCE_STYLE_INSENSITIVE_STATE;
            break;
        case G_TOKEN_IDENTIFIER:
            if (0==g_strcmp0("first-child", scanner->next_value.v_string)) {
                token = g_scanner_get_next_token(scanner);
                hash.child = DEVIANCE_STYLE_FIRST_CHILD;
            } else if (0==g_strcmp0("nth-child", scanner->next_value.v_string)) {
                token = g_scanner_get_next_token(scanner);
                hash.child = DEVIANCE_STYLE_NTH_CHILD;
                token = g_scanner_get_next_token(scanner);
                token==G_TOKEN_LEFT_PAREN;
                token = g_scanner_get_next_token(scanner);
                token==G_TOKEN_INT;
                hash.arg = scanner->value.v_int;
                token = g_scanner_get_next_token(scanner);
                token==G_TOKEN_RIGHT_PAREN;
            } else if (0==g_strcmp0("last-child", scanner->next_value.v_string)) {
                token = g_scanner_get_next_token(scanner);
                hash.child = DEVIANCE_STYLE_LAST_CHILD;
            } else if (0==g_strcmp0("odd-child", scanner->next_value.v_string)) {
                token = g_scanner_get_next_token(scanner);
                hash.child = DEVIANCE_STYLE_ODD_CHILD;
                hash.arg = 0;
            } else if (0==g_strcmp0("even-child", scanner->next_value.v_string)) {
                token = g_scanner_get_next_token(scanner);
                hash.child = DEVIANCE_STYLE_EVEN_CHILD;
                hash.arg = 0;
            } else if (0==g_strcmp0("formula-child", scanner->next_value.v_string)) {
                token = g_scanner_get_next_token(scanner);
                hash.child = DEVIANCE_STYLE_FORMULA_CHILD;
                token = g_scanner_get_next_token(scanner);
                token==G_TOKEN_LEFT_PAREN;
                token = g_scanner_get_next_token(scanner);
                token==G_TOKEN_INT;
                token = g_scanner_get_next_token(scanner);
                token==G_TOKEN_COMMA;
                token = g_scanner_get_next_token(scanner);
                token==G_TOKEN_INT;
                hash.arg = 1024 + scanner->value.v_int;
                token = g_scanner_get_next_token(scanner);
                token==G_TOKEN_RIGHT_PAREN;
            } else {
                return G_TOKEN_ERROR;
            }
            break;
        // nth-child(2)
        // nth-child(odd|even|[0-9]*)
        default:
            return G_TOKEN_ERROR;
            break;
        }
    } else {
        return ':';
    }

    style_selector->hash = hash;
     *selector = style_selector;
    return G_TOKEN_NONE;
}
static guint
ux_parse_selectors (GtkSettings  *settings,
                   GScanner     *scanner,
                   GtkRcStyle   *rc_style,
                   DevianceStyleSelector **selectors)
{
    GTokenType token = G_TOKEN_NONE;
    GTokenType token_part = G_TOKEN_NONE;

    do {
        token = ux_parse_selector(settings, scanner, rc_style, selectors);
        if (token!=G_TOKEN_NONE) {
            break;
        }
        token_part = g_scanner_peek_next_token(scanner);
    }while (token_part==':');

    return token;
}

static guint
ux_parse_color (GtkSettings  *settings,
                GScanner     *scanner,
                GtkRcStyle   *rc_style,
                DevianceStyleColor **color)
{
    DevianceStyleColor *style_color = NULL;
    //deviance_style_image_new();//  = // style_background

    GTokenType token = g_scanner_peek_next_token(scanner);
    if (TOKEN_TRANSPARENT==token) {
        style_color = deviance_style_color_new();
        style_color->a = 0.0;
        token = g_scanner_get_next_token(scanner);
    } else if (G_TOKEN_IDENTIFIER==token) { // shade(1.1, @bg_color)
         if (g_strcmp0(scanner->next_value.v_identifier, "shade")==0) {
             style_color = deviance_style_color_shade_new();
             token = g_scanner_get_next_token(scanner);
             float ratio;
             //DEVIANCE_STYLE_COLOR_SHADE(style_color)->level = 1.0;

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_LEFT_PAREN)
                 return G_TOKEN_LEFT_PAREN;

             token = g_scanner_get_next_token(scanner);
             switch(token) {
             case G_TOKEN_FLOAT:
                 //g_print("%f\n", scanner->value.v_float);
                 //style_color->r = scanner->value.v_float;
                 ratio = scanner->value.v_float;
                 break;
             case G_TOKEN_INT:
                 //g_print("%d\n", scanner->value.v_int);
                 ratio = scanner->value.v_int;
                 //style_color->r = scanner->value.v_int/255.0;
                 break;
             default:
                 return G_TOKEN_FLOAT;
                 break;
             }

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_COMMA)
                 return G_TOKEN_COMMA;

             DevianceStyleColor *color = NULL;
             token = ux_parse_color (settings, scanner, rc_style, &color);
             // TODO: shade the color : color->[r|g|b] = shade * color->[r|g|b]
             DEVIANCE_STYLE_COLOR_SHADE(style_color)->color = color;
             DEVIANCE_STYLE_COLOR_SHADE(style_color)->ratio = ratio;

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_RIGHT_PAREN)
                 return G_TOKEN_RIGHT_PAREN;


         } else if (g_strcmp0(scanner->next_value.v_identifier, "mix")==0) {
             style_color = deviance_style_color_mix_new();
             token = g_scanner_get_next_token(scanner);
             float ratio;
             //DEVIANCE_STYLE_COLOR_SHADE(style_color)->level = 1.0;

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_LEFT_PAREN)
                 return G_TOKEN_LEFT_PAREN;

             token = g_scanner_get_next_token(scanner);
             switch(token) {
             case G_TOKEN_FLOAT:
                 //g_print("%f\n", scanner->value.v_float);
                 //style_color->r = scanner->value.v_float;
                 ratio = scanner->value.v_float;
                 break;
             case G_TOKEN_INT:
                 //g_print("%d\n", scanner->value.v_int);
                 ratio = scanner->value.v_int;
                 //style_color->r = scanner->value.v_int/255.0;
                 break;
             default:
                 return G_TOKEN_FLOAT;
                 break;
             }

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_COMMA)
                 return G_TOKEN_COMMA;

             DevianceStyleColor *color_a = NULL;
             token = ux_parse_color (settings, scanner, rc_style, &color_a);
             if (token != G_TOKEN_NONE)
                 return G_TOKEN_ERROR;

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_COMMA)
                 return G_TOKEN_COMMA;

             DevianceStyleColor *color_b = NULL;
             token = ux_parse_color (settings, scanner, rc_style, &color_b);
             if (token != G_TOKEN_NONE)
                 return G_TOKEN_ERROR;

             DEVIANCE_STYLE_COLOR_MIX(style_color)->color_a = color_a;
             DEVIANCE_STYLE_COLOR_MIX(style_color)->color_b = color_b;
             DEVIANCE_STYLE_COLOR_MIX(style_color)->ratio = ratio;

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_RIGHT_PAREN)
                 return G_TOKEN_RIGHT_PAREN;

         } else if (g_strcmp0(scanner->next_value.v_identifier, "bg")==0) {
             style_color = deviance_style_color_palette_new();
             token = g_scanner_get_next_token(scanner);

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_LEFT_PAREN)
                 return G_TOKEN_LEFT_PAREN;

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_IDENTIFIER)
                 return G_TOKEN_IDENTIFIER;
             //gtk_state_type_get_type();
             DEVIANCE_STYLE_COLOR_PALETTE(style_color)->name = g_strdup("bg");
             DEVIANCE_STYLE_COLOR_PALETTE(style_color)->state = g_strdup(scanner->value.v_identifier);

             token = g_scanner_get_next_token(scanner);
             if (token != G_TOKEN_RIGHT_PAREN)
                 return G_TOKEN_RIGHT_PAREN;

         } else {
            return G_TOKEN_IDENTIFIER;
         }

    } else if (TOKEN_RGBA==token) {
        style_color = deviance_style_color_new();
        token = g_scanner_get_next_token(scanner);

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_LEFT_PAREN)
            return G_TOKEN_LEFT_PAREN;

        token = g_scanner_get_next_token(scanner);
        switch(token) {
        case G_TOKEN_FLOAT:
            g_print("%f\n", scanner->value.v_float);
            style_color->r = scanner->value.v_float;
            break;
        case G_TOKEN_INT:
            g_print("%d\n", scanner->value.v_int);
            style_color->r = scanner->value.v_int/255.0;
            break;
        default:
            return G_TOKEN_FLOAT;
            break;
        }

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_COMMA)
            return G_TOKEN_COMMA;

        token = g_scanner_get_next_token(scanner);
        switch(token) {
        case G_TOKEN_FLOAT:
            g_print("%f\n", scanner->value.v_float);
            style_color->g = scanner->value.v_float;
            break;
        case G_TOKEN_INT:
            g_print("%d\n", scanner->value.v_int);
            style_color->g = scanner->value.v_int/255.0;
            break;
        default:
            return G_TOKEN_FLOAT;
            break;
        }

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_COMMA)
            return G_TOKEN_COMMA;

        token = g_scanner_get_next_token(scanner);
        switch(token) {
        case G_TOKEN_FLOAT:
            g_print("%f\n", scanner->value.v_float);
            style_color->b = scanner->value.v_float;
            break;
        case G_TOKEN_INT:
            g_print("%d\n", scanner->value.v_int);
            style_color->b = scanner->value.v_int/255.0;
            break;
        default:
            return G_TOKEN_FLOAT;
            break;
        }

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_COMMA)
            return G_TOKEN_COMMA;

        token = g_scanner_get_next_token(scanner);
        switch(token) {
        case G_TOKEN_FLOAT:
            g_print("%f\n", scanner->value.v_float);
            style_color->a = scanner->value.v_float;
            break;
        case G_TOKEN_INT:
            g_print("%d\n", scanner->value.v_int);
            style_color->a = scanner->value.v_int/255.0;
            break;
        default:
            return G_TOKEN_FLOAT;
            break;
        }

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_RIGHT_PAREN)
            return G_TOKEN_RIGHT_PAREN;
    } else if (TOKEN_RGB==token) {
        style_color = deviance_style_color_new();
        token = g_scanner_get_next_token(scanner);

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_LEFT_PAREN)
            return G_TOKEN_LEFT_PAREN;

        token = g_scanner_get_next_token(scanner);
        switch(token) {
        case G_TOKEN_FLOAT:
            g_print("%f\n", scanner->value.v_float);
            style_color->r = scanner->value.v_float;
            break;
        case G_TOKEN_INT:
            g_print("%d\n", scanner->value.v_int);
            style_color->r = scanner->value.v_int/255.0;
            break;
        default:
            return G_TOKEN_FLOAT;
            break;
        }

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_COMMA)
            return G_TOKEN_COMMA;

        token = g_scanner_get_next_token(scanner);
        switch(token) {
        case G_TOKEN_FLOAT:
            //g_print("%f\n", scanner->value.v_float);
            style_color->g = scanner->value.v_float;
            break;
        case G_TOKEN_INT:
            //g_print("%d\n", scanner->value.v_int);
            style_color->g = scanner->value.v_int/255.0;
            break;
        default:
            return G_TOKEN_FLOAT;
            break;
        }

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_COMMA)
            return G_TOKEN_COMMA;

        token = g_scanner_get_next_token(scanner);
        switch(token) {
        case G_TOKEN_FLOAT:
            g_print("%f\n", scanner->value.v_float);
            style_color->b = scanner->value.v_float;
            break;
        case G_TOKEN_INT:
            g_print("%d\n", scanner->value.v_int);
            style_color->b = scanner->value.v_int/255.0;
            break;
        default:
            return G_TOKEN_FLOAT;
            break;
        }

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_RIGHT_PAREN)
            return G_TOKEN_RIGHT_PAREN;
    } else if (token==G_TOKEN_STRING) {// "#00FF00"
        token = g_scanner_get_next_token(scanner);
        style_color = deviance_style_color_html_new();
        DEVIANCE_STYLE_COLOR_HTML(style_color)->string = g_strdup(scanner->value.v_string);
        g_print("----------------expect %s\n", scanner->value.v_string);

    } else if (token=='@') {
        style_color = deviance_style_color_scheme_new();
        token = g_scanner_get_next_token(scanner);

        token = g_scanner_get_next_token(scanner);
        g_print("token %d\n", token);
        if (token != G_TOKEN_IDENTIFIER)
            return G_TOKEN_IDENTIFIER;

        DEVIANCE_STYLE_COLOR_SCHEME(style_color)->scheme = g_strdup(scanner->value.v_identifier);

        //GdkColor color;
        //gboolean success = gtk_style_lookup_color(GTK_STYLE(rc_style), scanner->value.v_identifier, &color);
        //g_print("success: %d; GdkColor{%0.2X, %0.2X, %0.2X}\n", success, color.red/0x100, color.green/0x100, color.blue/0x100);

        g_print("expect @%s\n", scanner->value.v_identifier);
    }
    *color = style_color;
    style_color->is_set = TRUE;

    return G_TOKEN_NONE;
}

static guint
ux_parse_color_stop (GtkSettings  *settings,
                     GScanner     *scanner,
                     GtkRcStyle   *rc_style,
                     DevianceStyleColorStop **stop)
{
    GTokenType token;

    DevianceStyleColor *color = NULL;
    token = ux_parse_color (settings, scanner, rc_style, &color);
    float offset;
    token = g_scanner_get_next_token(scanner);
    switch(token) {
    case G_TOKEN_FLOAT:
        //g_print("%f\n", scanner->value.v_float);
        offset = scanner->value.v_float;
        break;
    case G_TOKEN_INT:
        //g_print("%d%\n", scanner->value.v_int);
        token = g_scanner_get_next_token(scanner);
        if ('%'!=token)
            return '%';
        offset = scanner->value.v_int/100.0;
        break;
    default:
        return G_TOKEN_FLOAT;
        break;
    }

    DevianceStyleColorStop*
    color_stop= deviance_style_color_stop_new();
    color_stop->color = color;
    color_stop->offset = offset;
    *stop = color_stop;

    return G_TOKEN_NONE;
}

static guint
ux_parse_background_image (GtkSettings  *settings,
                           GScanner     *scanner,
                           GtkRcStyle   *rc_style,
                           DevianceStyleImage **image)
{
    DevianceStyleImage *style_image = NULL;

    GTokenType token = g_scanner_peek_next_token(scanner);
    if (TOKEN_LINEAR_GRADIENT==token) {
        style_image = deviance_style_image_gradient_linear_new();
        //DevianceStyleImageGradientLinear *image_gradient = deviance_style_image_gradient_linear_new();
        //image_gradient;

        token = g_scanner_get_next_token(scanner);

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_LEFT_PAREN)
            return G_TOKEN_LEFT_PAREN;

        token = g_scanner_get_next_token(scanner);
        if (token != TOKEN_TO)
            return TOKEN_TO;

        token = g_scanner_get_next_token(scanner);
        switch (token) {
        case TOKEN_TOP:
            g_print("TOP\n");
            break;
        case TOKEN_RIGHT:
            g_print("RIGHT\n");
            break;
        case TOKEN_BOTTOM:
            g_print("BOTTOM\n");
            break;
        case TOKEN_LEFT:
            g_print("LEFT\n");
            break;
        default:
            return TOKEN_TO;
            break;
        }

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_COMMA)
            return G_TOKEN_COMMA;

        DevianceStyleColorStop *color_stop = NULL;
        token = ux_parse_color_stop(settings, scanner, rc_style, &color_stop);
        if (token != G_TOKEN_NONE)
            return G_TOKEN_ERROR;
        deviance_style_image_gradient_linear_add_color_stop(DEVIANCE_STYLE_IMAGE_GRADIENT_LINEAR(style_image), color_stop);

        token = g_scanner_peek_next_token(scanner);
        while(token==G_TOKEN_COMMA) {
            token = g_scanner_get_next_token(scanner);// COMMA

            token = ux_parse_color_stop(settings, scanner, rc_style, &color_stop);
            if (token != G_TOKEN_NONE)
                return G_TOKEN_ERROR;
            deviance_style_image_gradient_linear_add_color_stop(DEVIANCE_STYLE_IMAGE_GRADIENT_LINEAR(style_image), color_stop);
        }

        token = g_scanner_get_next_token(scanner);
        if (token != G_TOKEN_RIGHT_PAREN)
            return G_TOKEN_RIGHT_PAREN;
    }//! TODO: RADIAL_GRADIENT
    //! TODO: URL

    *image = style_image;

    return G_TOKEN_NONE;
}

static guint
ux_parse_background_position (GtkSettings  *settings,
                              GScanner     *scanner,
                              GtkRcStyle   *rc_style,
                              DevianceStyleBackground *background)
{
    GTokenType token;

    token = g_scanner_peek_next_token(scanner);
    switch (token) {
    case TOKEN_RIGHT:
        token = g_scanner_get_next_token(scanner);
        g_print("RIGHT\n");
        break;
    case TOKEN_CENTER:
        token = g_scanner_get_next_token(scanner);
        g_print("CENTER\n");
        break;
    case TOKEN_LEFT:
        token = g_scanner_get_next_token(scanner);
        g_print("LEFT\n");
        break;
    default:
        break;
    }

    token = g_scanner_peek_next_token(scanner);
    switch (token) {
    case TOKEN_TOP:
        token = g_scanner_get_next_token(scanner);
        g_print("TOP\n");
        break;
    case TOKEN_CENTER:
        token = g_scanner_get_next_token(scanner);
        g_print("RIGHT\n");
        break;
    case TOKEN_BOTTOM:
        token = g_scanner_get_next_token(scanner);
        g_print("BOTTOM\n");
        break;
    default:
        break;
    }

    return G_TOKEN_NONE;
}

//static guint
//ux_parse_background_color (GtkSettings  *settings,
//                           GScanner     *scanner,
//                           GtkRcStyle   *rc_style,
//                           gpointer     *background_color)
//{
//    guint token;
//    token = ux_parse_color(settings, scanner, rc_style, background_color);
//    if (token != G_TOKEN_NONE)
//        return G_TOKEN_ERROR;

//    return G_TOKEN_NONE;
//}

static guint
ux_parse_border_width (GtkSettings          *settings,
                       GScanner             *scanner,
                       GtkRcStyle           *rc_style,
                       DevianceStyleBorder **border)
{
    GTokenType token;
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    // border-width
    token = g_scanner_get_next_token(scanner);


    // [:(normal|active|prelight|selected|insensitive)]
    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);


    // =
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);

    // 1 px 2px 86px 2px
    DevianceStyleLength *widths[4] = {NULL, NULL, NULL, NULL};
    gint count = 0;
    while(count<4)
    {
        DevianceStyleLength *width = NULL;
        token = ux_parse_length(settings, scanner, rc_style, &width);
        if (token== G_TOKEN_INT) {// or G_TOKEN_FLOAT
            break;
        }
        if (token!= G_TOKEN_NONE) {
            return token;
        }

        widths[count] = width;
        count++;
    }
    // ;
    token = g_scanner_peek_next_token(scanner);
    if (token != ';')
        return ';';
    token = g_scanner_get_next_token(scanner);


    DevianceStyleBorder *style_border = deviance_style_border_new();
    style_border->selectors = selectors;

    /// todo: foreach selectors in _border
    DevianceStyleBorder *existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
    if (existing_border!=NULL) {
        g_object_unref(style_border);
        g_object_unref(selectors);
    } else {
        g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
        existing_border = style_border;
    }

    if (count==4) {
        deviance_style_length_copy(widths[0], existing_border->top.width);
        deviance_style_length_copy(widths[1], existing_border->right.width);
        deviance_style_length_copy(widths[2], existing_border->bottom.width);
        deviance_style_length_copy(widths[3], existing_border->left.width);
        g_object_unref(widths[0]);
        g_object_unref(widths[1]);
        g_object_unref(widths[2]);
        g_object_unref(widths[3]);
    } else if (count==2) {
        deviance_style_length_copy(widths[0], existing_border->top.width);
        deviance_style_length_copy(widths[1], existing_border->right.width);
        deviance_style_length_copy(widths[0], existing_border->bottom.width);
        deviance_style_length_copy(widths[1], existing_border->left.width);
        g_object_unref(widths[0]);
        g_object_unref(widths[1]);
    } else if (count==1) {
        deviance_style_length_copy(widths[0], existing_border->top.width);
        deviance_style_length_copy(widths[0], existing_border->right.width);
        deviance_style_length_copy(widths[0], existing_border->bottom.width);
        deviance_style_length_copy(widths[0], existing_border->left.width);
        g_object_unref(widths[0]);
    }
//    existing_border->top.width->is_set = TRUE;
//    existing_border->right.width->is_set = TRUE;
//    existing_border->bottom.width->is_set = TRUE;
//    existing_border->left.width->is_set = TRUE;

    *border = existing_border;

    return G_TOKEN_NONE;

}

// ux_parse_border_image_source
// ux_parse_border_image_slice
// ux_parse_border_image_width
// ux_parse_border_image_outset
// ux_parse_border_image_repeat


// TODO parse selector and get existing border
#include "style-border-image.h"
static guint
ux_parse_border_image (GtkSettings  *settings,
                       GScanner     *scanner,
                       GtkRcStyle   *rc_style,
                       DevianceStyleBorder **border)
{
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    DevianceStyleBorder *style_border = NULL;
    GTokenType token;
    // border-image
    token = g_scanner_get_next_token(scanner);// TOKEN_BORDER_IMAGE

    // [:(normal|active|prelight|selected|insensitive)]
    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);

    style_border = deviance_style_border_new();
    style_border->selectors = selectors;
    /// todo: foreach selectors in _border
    DevianceStyleBorder *existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
    if (existing_border!=NULL) {
        g_object_unref(style_border);
        g_object_unref(selectors);
    } else {
        g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
        existing_border = style_border;
    }

    // =
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);

    // linear-gradient() | radial() | url()
    token = g_scanner_peek_next_token(scanner);
    switch (token) {
    case TOKEN_LINEAR_GRADIENT:
    {
        DevianceStyleImage *border_image_source = NULL;
        token = ux_parse_background_image(settings, scanner, rc_style, &border_image_source);// image_source
        if (G_TOKEN_NONE!=token) {
            return TOKEN_LINEAR_GRADIENT;
        }
        existing_border->image = deviance_style_border_image_new();
        existing_border->image->source = border_image_source;
        //token = g_scanner_get_next_token(scanner);
        break;
    }
    case TOKEN_RADIAL_GRADIENT:
        //token = g_scanner_get_next_token(scanner);
        break;
    case TOKEN_URL:
        //token = g_scanner_get_next_token(scanner);
        break;
    default:
        // error
        return TOKEN_LINEAR_GRADIENT;
        break;

    }


    // ;
    token = g_scanner_peek_next_token(scanner);
    if (token != ';')
        return ';';
    token = g_scanner_get_next_token(scanner);

    // make stuff

    if (border!=NULL) {
        *border = existing_border;
    }

    return G_TOKEN_NONE;
}

static guint
ux_parse_border_top_left_radius (GtkSettings          *settings,
                                 GScanner             *scanner,
                                 GtkRcStyle           *rc_style,
                                 DevianceStyleBorder **border)
{
    GTokenType token;
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    // border-top-left-radius
    token = g_scanner_get_next_token(scanner);

    // [:(normal|active|prelight|selected|insensitive)]
    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);


    // =
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);


    // 1 px
    DevianceStyleLength *radius = NULL;
    token = ux_parse_length(settings, scanner, rc_style, &radius);
    if (token!= G_TOKEN_NONE) {
        return token;
    }


    // ;
    token = g_scanner_peek_next_token(scanner);
    if (token != ';')
        return ';';
    token = g_scanner_get_next_token(scanner);


    /*
    DevianceStyleSelector *selector=deviance_style_selector_get_state(g_list_first(style_border->selectors)->data);
    GList *state_selectors = g_list_append(NULL, selector);
    */
    DevianceStyleSelector *selector = deviance_style_selector_new();
    selector->hash.state = deviance_style_selector_get_state(selectors);
    DevianceStyleSelector *style_selectors = selector;

    DevianceStyleBorder *style_border = deviance_style_border_new();
    style_border->selectors = selectors;

    /// todo: foreach selectors in _border
    DevianceStyleBorder *existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
    if (existing_border!=NULL) {
        g_object_unref(style_border);
        g_object_unref(selectors);
    } else {
        style_border->selectors = style_selectors;
        existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
        if (existing_border!=NULL) {
            style_border->selectors = selectors;
            deviance_style_border_copy(existing_border, style_border);
            g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
            existing_border = style_border;
        } else {
            g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
            existing_border = style_border;
        }
    }
    deviance_style_length_copy(radius, existing_border->top_left.rx);
    deviance_style_length_copy(radius, existing_border->top_left.ry);
    existing_border->top_left.rx->is_set = TRUE;
    existing_border->top_left.ry->is_set = TRUE;

    g_object_unref(radius);

    *border = existing_border;


    return G_TOKEN_NONE;
}

static guint
ux_parse_border_top_right_radius(GtkSettings          *settings,
                                 GScanner             *scanner,
                                 GtkRcStyle           *rc_style,
                                 DevianceStyleBorder **border)
{
    GTokenType token;
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    // border-top-right-radius
    token = g_scanner_get_next_token(scanner);

    // [:(normal|active|prelight|selected|insensitive)]
    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);


    // =
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);


    // 1 px
    DevianceStyleLength *radius = NULL;
    token = ux_parse_length(settings, scanner, rc_style, &radius);
    if (token!= G_TOKEN_NONE) {
        return token;
    }


    // ;
    token = g_scanner_peek_next_token(scanner);
    if (token != ';')
        return ';';
    token = g_scanner_get_next_token(scanner);


    /*
    DevianceStyleSelector *selector=deviance_style_selector_get_state(g_list_first(style_border->selectors)->data);
    GList *state_selectors = g_list_append(NULL, selector);
    */
    DevianceStyleSelector *selector = deviance_style_selector_new();
    selector->hash.state = deviance_style_selector_get_state(selectors);
    DevianceStyleSelector *style_selectors = selector;

    DevianceStyleBorder *style_border = deviance_style_border_new();
    style_border->selectors = selectors;

    /// todo: foreach selectors in _border
    DevianceStyleBorder *existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
    if (existing_border!=NULL) {
        g_object_unref(style_border);
        g_object_unref(selectors);
    } else {
        style_border->selectors = style_selectors;
        existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
        if (existing_border!=NULL) {
            style_border->selectors = selectors;
            deviance_style_border_copy(existing_border, style_border);
            g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
            existing_border = style_border;
        } else {
            g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
            existing_border = style_border;
        }
    }
    deviance_style_length_copy(radius, existing_border->top_right.rx);
    deviance_style_length_copy(radius, existing_border->top_right.ry);
    existing_border->top_right.rx->is_set = TRUE;
    existing_border->top_right.ry->is_set = TRUE;

    g_object_unref(radius);

    *border = existing_border;


    return G_TOKEN_NONE;
}

static guint
ux_parse_border_bottom_left_radius (GtkSettings          *settings,
                                 GScanner             *scanner,
                                 GtkRcStyle           *rc_style,
                                 DevianceStyleBorder **border)
{
    // border-bottom-left-radius
    GTokenType token;
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    // border-top-left-radius
    token = g_scanner_get_next_token(scanner);

    // [:(normal|active|prelight|selected|insensitive)]
    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);


    // =
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);


    // 1 px
    DevianceStyleLength *radius = NULL;
    token = ux_parse_length(settings, scanner, rc_style, &radius);
    if (token!= G_TOKEN_NONE) {
        return token;
    }


    // ;
    token = g_scanner_peek_next_token(scanner);
    if (token != ';')
        return ';';
    token = g_scanner_get_next_token(scanner);

    DevianceStyleBorder *style_border = deviance_style_border_new();
    style_border->selectors = selectors;

    /// todo: foreach selectors in _border
    DevianceStyleBorder *existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
    if (existing_border!=NULL) {
        g_object_unref(style_border);
        g_object_unref(selectors);
    } else {
        g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
        existing_border = style_border;
    }
    deviance_style_length_copy(radius, existing_border->bottom_left.rx);
    deviance_style_length_copy(radius, existing_border->bottom_left.ry);
    existing_border->bottom_left.rx->is_set = TRUE;
    existing_border->bottom_left.ry->is_set = TRUE;

    g_object_unref(radius);

    *border = existing_border;


    return G_TOKEN_NONE;
}

static guint
ux_parse_border_bottom_right_radius (GtkSettings          *settings,
                                 GScanner             *scanner,
                                 GtkRcStyle           *rc_style,
                                 DevianceStyleBorder **border)
{
    // border-bottom-right-radius
    GTokenType token;
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    // border-bottom-right-radius
    token = g_scanner_get_next_token(scanner);

    // [:(normal|active|prelight|selected|insensitive)]
    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);


    // =
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);


    // 1 px
    DevianceStyleLength *radius = NULL;
    token = ux_parse_length(settings, scanner, rc_style, &radius);
    if (token!= G_TOKEN_NONE) {
        return token;
    }


    // ;
    token = g_scanner_peek_next_token(scanner);
    if (token != ';')
        return ';';
    token = g_scanner_get_next_token(scanner);


    /*
    DevianceStyleSelector *selector=deviance_style_selector_get_state(g_list_first(style_border->selectors)->data);
    GList *state_selectors = g_list_append(NULL, selector);
    */
    DevianceStyleSelector *selector = deviance_style_selector_new();
    selector->hash.state = deviance_style_selector_get_state(selectors);
    DevianceStyleSelector *style_selectors = selector;

    DevianceStyleBorder *style_border = deviance_style_border_new();
    style_border->selectors = selectors;

    /// todo: foreach selectors in _border
    DevianceStyleBorder *existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
    if (existing_border!=NULL) {
        g_object_unref(style_border);
        g_object_unref(selectors);
    } else {
        style_border->selectors = style_selectors;
        existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
        if (existing_border!=NULL) {
            style_border->selectors = selectors;
            deviance_style_border_copy(existing_border, style_border);
            g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
            existing_border = style_border;
        } else {
            g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
            existing_border = style_border;
        }
    }
    deviance_style_length_copy(radius, existing_border->bottom_right.rx);
    deviance_style_length_copy(radius, existing_border->bottom_right.ry);
    existing_border->bottom_right.rx->is_set = TRUE;
    existing_border->bottom_right.ry->is_set = TRUE;

    g_object_unref(radius);

    *border = existing_border;


    return G_TOKEN_NONE;
}


static guint
ux_parse_border_radius (GtkSettings  *settings,
                        GScanner     *scanner,
                        GtkRcStyle   *rc_style,
                        DevianceStyleBorder **border)
{
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    GTokenType token;
    // border-radius
    token = g_scanner_get_next_token(scanner);

    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);

    // =
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);

    // 1 px 2px 86px 2px
    DevianceStyleLength *radius[4];
    gint count = 0;
    while(count<4)
    {
        DevianceStyleLength *r = NULL;
        token = ux_parse_length(settings, scanner, rc_style, &r);
        if (token== G_TOKEN_INT) {// or maybe FLOAT
            break;
        }
        if (token!= G_TOKEN_NONE) {
            return token;
        }

        radius[count] = r;
        count++;
    }
    // ;
    token = g_scanner_peek_next_token(scanner);
    if (token != ';')
        return ';';
    token = g_scanner_get_next_token(scanner);


    DevianceStyleBorder *style_border = deviance_style_border_new();
    style_border->selectors = selectors;

    /// todo: foreach selectors in _border
    DevianceStyleBorder *existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
    if (existing_border!=NULL) {
        g_object_unref(style_border);
        g_object_unref(selectors);
    } else {
        g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
        existing_border = style_border;
    }

    if (count==4) {
        deviance_style_length_copy(radius[0], existing_border->top_left.rx);
        deviance_style_length_copy(radius[0], existing_border->top_left.ry);
        deviance_style_length_copy(radius[1], existing_border->top_right.rx);
        deviance_style_length_copy(radius[1], existing_border->top_right.ry);
        deviance_style_length_copy(radius[2], existing_border->bottom_right.rx);
        deviance_style_length_copy(radius[2], existing_border->bottom_right.ry);
        deviance_style_length_copy(radius[3], existing_border->bottom_left.rx);
        deviance_style_length_copy(radius[3], existing_border->bottom_left.ry);

        g_object_unref(radius[0]);
        g_object_unref(radius[1]);
        g_object_unref(radius[2]);
        g_object_unref(radius[3]);
    } else if (count==2) {
        deviance_style_length_copy(radius[0], existing_border->top_left.rx);
        deviance_style_length_copy(radius[0], existing_border->top_left.ry);
        deviance_style_length_copy(radius[1], existing_border->top_right.rx);
        deviance_style_length_copy(radius[1], existing_border->top_right.ry);
        deviance_style_length_copy(radius[0], existing_border->bottom_right.rx);
        deviance_style_length_copy(radius[0], existing_border->bottom_right.ry);
        deviance_style_length_copy(radius[1], existing_border->bottom_left.rx);
        deviance_style_length_copy(radius[1], existing_border->bottom_left.ry);

        g_object_unref(radius[0]);
        g_object_unref(radius[1]);
    } else if (count==1) {
        deviance_style_length_copy(radius[0], existing_border->top_left.rx);
        deviance_style_length_copy(radius[0], existing_border->top_left.ry);
        deviance_style_length_copy(radius[0], existing_border->top_right.rx);
        deviance_style_length_copy(radius[0], existing_border->top_right.ry);
        deviance_style_length_copy(radius[0], existing_border->bottom_right.rx);
        deviance_style_length_copy(radius[0], existing_border->bottom_right.ry);
        deviance_style_length_copy(radius[0], existing_border->bottom_left.rx);
        deviance_style_length_copy(radius[0], existing_border->bottom_left.ry);

        g_object_unref(radius[0]);
    }

    *border = existing_border;

    return G_TOKEN_NONE;
}

static guint
ux_parse_border (GtkSettings  *settings,
                 GScanner     *scanner,
                 GtkRcStyle   *rc_style,
                 DevianceStyleBorder **border)
{
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    GTokenType token;
    // border
    token = g_scanner_get_next_token(scanner);

    // [:(normal|active|prelight|selected|insensitive)]
    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);


    // =
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);


    // 1 px
    DevianceStyleLength *width = NULL;
    token = ux_parse_length(settings, scanner, rc_style, &width);
    if (token!= G_TOKEN_NONE) {
        return token;
    }


    // solid
    token = g_scanner_get_next_token(scanner);
    g_print("%d == %d : %s\n", token, G_TOKEN_IDENTIFIER, scanner->value.v_identifier);

    // red
    DevianceStyleColor *color = NULL;//deviance_style_color_new();
    token = ux_parse_color(settings, scanner, rc_style, &color);
    //token = g_scanner_get_next_token(scanner);
    //g_print("-------------------------> %s\n", scanner->value.v_identifier);
    if (token!=G_TOKEN_NONE) {
        g_print("token!=G_TOKEN_NONE\n");
    }


    // ;
    token = g_scanner_get_next_token(scanner);
    g_print("%d %c\n", token, token/*, G_TOKEN_IDENTIFIER, scanner->value.v_identifier*/);

    // get existing or no ?
    DevianceStyleBorder *style_border = deviance_style_border_new();
    style_border->selectors = selectors;

    DevianceStyleBorder *existing_border = g_hash_table_lookup(deviance_rc_style->_border, style_border);
    if (existing_border!=NULL) {
        g_object_unref(style_border);
        g_object_unref(selectors);
    } else {
        g_hash_table_insert(deviance_rc_style->_border, style_border, style_border);
        existing_border = style_border;
    }

    //g_print("width: %f\n", width->value);
    //g_print("type: %s\n", g_type_name_from_instance((GTypeInstance*)color));



    if (color && color->is_set) {
        deviance_style_color_merge(color, &existing_border->top.color);
        deviance_style_color_merge(color, &existing_border->right.color);
        deviance_style_color_merge(color, &existing_border->bottom.color);
        deviance_style_color_merge(color, &existing_border->left.color);
    }

    if (width && width->is_set) {
        deviance_style_length_copy(width, existing_border->top.width);
        deviance_style_length_copy(width, existing_border->right.width);
        deviance_style_length_copy(width, existing_border->bottom.width);
        deviance_style_length_copy(width, existing_border->left.width);
    }


    g_object_unref(color);
    g_object_unref(width);

    *border = existing_border;
    //existing_border->is_set = TRUE;

    return G_TOKEN_NONE;
}

static guint
ux_parse_background (GtkSettings  *settings,
                     GScanner     *scanner,
                     GtkRcStyle   *rc_style,
                     DevianceStyleBackground **background)
{
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    GTokenType token;

    // background
    token = g_scanner_get_next_token(scanner);

    // background:active:first-child
    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);


    // background:active=
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);


    /* background color */
    DevianceStyleColor *color = NULL;
    token = ux_parse_color(settings, scanner, rc_style, &color);
    if (G_TOKEN_NONE!=token) {
        return G_TOKEN_ERROR;
    }
    /* !background color */


    /* background image */
    DevianceStyleImage *image = NULL;
    token = ux_parse_background_image(settings, scanner, rc_style, &image);
    if (G_TOKEN_NONE!=token) {
        return G_TOKEN_ERROR;
    }
    /* !background image */

    /* background position */
    token = ux_parse_background_position(settings, scanner, rc_style, NULL);
    if (G_TOKEN_NONE!=token) {
        return G_TOKEN_ERROR;
    }
    /* !background position */

    /* background repeat */
    /* !background repeat */

    /* background size */
    /* !background size */

    /* background origin */
    /* !background origin */

    /* background clip */
    /* !background clip */

    /* background attachment */
    /* !background attachment */


    token = g_scanner_get_next_token(scanner);
    if (token != ';')
        return ';';


    DevianceStyleBackground *style_background = deviance_style_background_new();
    style_background->selectors = selectors;

    DevianceStyleBackground *existing_background = g_hash_table_lookup(deviance_rc_style->_background, style_background);
    if (existing_background!=NULL) {
        g_object_unref(style_background);
        g_object_unref(selectors);
    } else {
        g_hash_table_insert(deviance_rc_style->_background, style_background, style_background);
        existing_background = style_background;
    }

    // FIXME Copy ... and unref color|image
    if (color!=NULL) {
        existing_background->color = color;// color None ???
        existing_background->color->is_set = TRUE;
    }
    if (image!=NULL) {
        existing_background->image = image;// image none ???
    }

    *background = existing_background;

    return G_TOKEN_NONE;
}

static guint
ux_parse_shadow (GtkSettings  *settings,
                 GScanner     *scanner,
                 GtkRcStyle   *rc_style,
                 DevianceStyleShadow **shadow)
{
    GTokenType token;
    DevianceStyleShadow *style_shadow = NULL;
    if (shadow==NULL || *shadow==NULL) {
        style_shadow = deviance_style_shadow_new();
    } else {
        style_shadow = *shadow;
    }

    // inset?
    token = g_scanner_peek_next_token(scanner);
    if (token != TOKEN_INSET)
        return TOKEN_INSET;
    token = g_scanner_get_next_token(scanner);

    // while number
    // 1 px 2px 86px 2px
    DevianceStyleLength *lengths[4];
    gint count = 0;
    while(count<4)
    {
        DevianceStyleLength *length = NULL;
        token = ux_parse_length(settings, scanner, rc_style, &length);
        if (token!= G_TOKEN_NONE) {
            return token;
        }

        lengths[count] = length;
        count++;
    }

    DevianceStyleImage *image = NULL;
    token = ux_parse_background_image(settings, scanner, rc_style, &image);
    if (G_TOKEN_NONE!=token) {
        return G_TOKEN_ERROR;
    }

    style_shadow->h = deviance_style_length_get_value(lengths[0], NULL);
    style_shadow->v = deviance_style_length_get_value(lengths[1], NULL);
    style_shadow->blur = deviance_style_length_get_value(lengths[2], NULL);
    style_shadow->spread = deviance_style_length_get_value(lengths[3], NULL);

    style_shadow->color = deviance_style_color_new();
    style_shadow->color->r = 0.0;
    style_shadow->color->g = 1.0;
    style_shadow->color->b = 0.0;
    style_shadow->color->a = 1.0;

    style_shadow->image = image;

    // ,|;
    token = g_scanner_get_next_token(scanner);

    if (shadow!=NULL) {
        *shadow = style_shadow;
    }

    return token;
}

static guint
ux_parse_box_shadow (GtkSettings  *settings,
                 GScanner     *scanner,
                 GtkRcStyle   *rc_style,
                 DevianceStyleBoxShadow **box_shadow)
{
    DevianceRcStyle *deviance_rc_style = DEVIANCE_RC_STYLE(rc_style);
    GTokenType token;

    // box-shadow
    token = g_scanner_get_next_token(scanner);

    // [:(normal|active|prelight|selected|insensitive)]
    DevianceStyleSelector *selectors = deviance_style_selector_new();
    ux_parse_selectors(settings, scanner, rc_style, &selectors);

    DevianceStyleBoxShadow *style_box_shadow = deviance_style_box_shadow_new();
    style_box_shadow->selectors = selectors;

    /// todo: foreach selectors in _border
    DevianceStyleBoxShadow *existing_box_shadow = g_hash_table_lookup(deviance_rc_style->_box_shadow, style_box_shadow);
    if (existing_box_shadow!=NULL) {
        g_object_unref(style_box_shadow);
        g_object_unref(selectors);
    } else {
        g_hash_table_insert(deviance_rc_style->_box_shadow, style_box_shadow, style_box_shadow);
        existing_box_shadow = style_box_shadow;
    }


    // =
    token = g_scanner_peek_next_token(scanner);
    if (token != G_TOKEN_EQUAL_SIGN)
        return G_TOKEN_EQUAL_SIGN;
    token = g_scanner_get_next_token(scanner);


    do {
        DevianceStyleShadow *shadow = deviance_style_shadow_new();
        token = ux_parse_shadow(settings, scanner, rc_style, &shadow);
        if (token==G_TOKEN_COMMA || token==';') {
            existing_box_shadow->shadows = g_list_append(existing_box_shadow->shadows, shadow);
        }
    } while(token==G_TOKEN_COMMA);

    if (box_shadow!=NULL) {
        *box_shadow = existing_box_shadow;
    }

    return G_TOKEN_NONE;
}

static guint
deviance_gtk2_rc_parse_dummy (GtkSettings      *settings,
                             GScanner         *scanner,
                             gchar            *name)
{
	guint token;

	/* Skip option */
	token = g_scanner_get_next_token (scanner);

	/* print a warning. Isn't there a way to get the string from the scanner? */
	g_scanner_warn (scanner, "Deviance configuration option \"%s\" is no longer supported and will be ignored.", name);

	/* equal sign */
	token = g_scanner_get_next_token (scanner);
	if (token != G_TOKEN_EQUAL_SIGN)
		return G_TOKEN_EQUAL_SIGN;

	/* eat whatever comes next */
	token = g_scanner_get_next_token (scanner);

	return G_TOKEN_NONE;
}


static guint
deviance_rc_style_parse (GtkRcStyle *rc_style,
                        GtkSettings  *settings,
                        GScanner   *scanner)
{
    g_print("-> %s(%p)\n", G_STRFUNC, rc_style);
    static GQuark scope_id = 0;
	DevianceRcStyle *deviance_style = DEVIANCE_RC_STYLE (rc_style);

	guint old_scope;
	guint token;
	guint i;

	/* Set up a new scope in this scanner. */

	if (!scope_id)
		scope_id = g_quark_from_string("deviance_theme_engine");

	/* If we bail out due to errors, we *don't* reset the scope, so the
	* error messaging code can make sense of our tokens.
	*/
	old_scope = g_scanner_set_scope(scanner, scope_id);

	/* Now check if we already added our symbols to this scope
	* (in some previous call to deviance_rc_style_parse for the
	* same scanner.
	*/

	if (!g_scanner_lookup_symbol(scanner, theme_symbols[0].name))
	{
		g_scanner_freeze_symbol_table(scanner);
		for (i = 0; i < G_N_ELEMENTS (theme_symbols); i++)
			g_scanner_scope_add_symbol(scanner, scope_id, theme_symbols[i].name, GINT_TO_POINTER(theme_symbols[i].token));
		g_scanner_thaw_symbol_table(scanner);
	}

	/* We're ready to go, now parse the top level */
	token = g_scanner_peek_next_token(scanner);
	while (token != G_TOKEN_RIGHT_CURLY)
	{
		switch (token)
		{
            case TOKEN_ANIMATION:
g_print("\tTOKEN_ANIMATION\n");
                token = theme_parse_boolean (settings, scanner, &deviance_style->animation);
				deviance_style->bflags |= MRN_FLAG_ANIMATION;
				break;
			case TOKEN_ARROWSTYLE:
g_print("\tTOKEN_ARROWSTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->arrowstyle);
				deviance_style->flags |= MRN_FLAG_ARROWSTYLE;
				break;
			case TOKEN_BORDER_COLORS:
g_print("\tTOKEN_BORDER_COLORS\n");
				token = theme_parse_border_colors (settings, scanner, rc_style, &deviance_style->has_border_colors, deviance_style->border_colors);
				deviance_style->gflags |= MRN_FLAG_BORDER_COLORS;
				break;
			case TOKEN_BORDER_SHADES:
g_print("\tTOKEN_BORDER_SHADES\n");
                token = theme_parse_border (settings, scanner, deviance_style->border_shades);
				deviance_style->gflags |= MRN_FLAG_BORDER_SHADES;
				break;

        case TOKEN_BORDER_TOP_LEFT_RADIUS:
g_print("\tTOKEN_BORDER_TOP_LEFT_RADIUS\n");
        {
            DevianceStyleBorder *border = deviance_style->border;
            token = ux_parse_border_top_left_radius (settings, scanner, rc_style, &border);
            if (token==G_TOKEN_NONE)
                deviance_style->border = border;
            break;
        }
        case TOKEN_BORDER_TOP_RIGHT_RADIUS:
g_print("\tTOKEN_BORDER_TOP_RIGHT_RADIUS\n");
        {
            DevianceStyleBorder *border = deviance_style->border;
            token = ux_parse_border_top_right_radius (settings, scanner, rc_style, &border);
            if (token==G_TOKEN_NONE)
                deviance_style->border = border;
            break;
        }
        case TOKEN_BORDER_BOTTOM_LEFT_RADIUS:
g_print("\tTOKEN_BORDER_BOTTOM_LEFT_RADIUS\n");
        {
            DevianceStyleBorder *border = deviance_style->border;
            token = ux_parse_border_bottom_left_radius (settings, scanner, rc_style, &border);
            if (token==G_TOKEN_NONE)
                deviance_style->border = border;
            break;
        }
        case TOKEN_BORDER_BOTTOM_RIGHT_RADIUS:
g_print("\tTOKEN_BORDER_BOTTOM_RIGHT_RADIUS\n");
        {
            DevianceStyleBorder *border = deviance_style->border;
            token = ux_parse_border_bottom_right_radius (settings, scanner, rc_style, &border);
            if (token==G_TOKEN_NONE)
                deviance_style->border = border;
            break;
        }

            case TOKEN_BOX_SHADOW:
            {
g_print("\tTOKEN_BOX_SHADOW\n");
                DevianceStyleBoxShadow *shadow = deviance_style->box_shadow;
                token = ux_parse_box_shadow (settings, scanner, rc_style, NULL);
                if (token==G_TOKEN_NONE)
                    deviance_style->box_shadow = shadow;
                break;
            }
			case TOKEN_CELLSTYLE:
g_print("\tTOKEN_CELLSTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->cellstyle);
				deviance_style->flags |= MRN_FLAG_CELLSTYLE;
				break;
            case TOKEN_COLORIZE_SCROLLBAR:
g_print("\tTOKEN_COLORIZE_SCROLLBAR\n");
				token = theme_parse_boolean (settings, scanner, &deviance_style->colorize_scrollbar);
				deviance_style->bflags |= MRN_FLAG_COLORIZE_SCROLLBAR;
				break;
			case TOKEN_COMBOBOXSTYLE:
g_print("\tTOKEN_COMBOBOXSTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->comboboxstyle);
				deviance_style->flags |= MRN_FLAG_COMBOBOXSTYLE;
				break;
        case TOKEN_CONTRAST:
g_print("\tTOKEN_CONTRAST\n");
                token = theme_parse_shade (settings, scanner, &deviance_style->contrast);
				deviance_style->bflags |= MRN_FLAG_CONTRAST;
				break;
        case TOKEN_DEFAULT_BUTTON_COLOR:
g_print("\tTOKEN_DEFAULT_BUTTON_COLOR\n");
                token = theme_parse_color (settings, scanner, rc_style, &deviance_style->default_button_color);
				deviance_style->flags |= MRN_FLAG_DEFAULT_BUTTON_COLOR;
				break;
        case TOKEN_EXPANDERSTYLE:
g_print("\tTOKEN_EXPANDERSTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->expanderstyle);
				deviance_style->flags |= MRN_FLAG_EXPANDERSTYLE;
				break;
        case TOKEN_FOCUS_COLOR:
g_print("\tTOKEN_FOCUS_COLOR\n");
                token = theme_parse_color (settings, scanner, rc_style, &deviance_style->focus_color);
				deviance_style->flags |= MRN_FLAG_FOCUS_COLOR;
				break;
        case TOKEN_FOCUSSTYLE:
g_print("\tTOKEN_FOCUSSTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->focusstyle);
				deviance_style->flags |= MRN_FLAG_FOCUSSTYLE;
				break;
        case TOKEN_GLAZESTYLE:
g_print("\tTOKEN_GLAZESTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->glazestyle);
				deviance_style->flags |= MRN_FLAG_GLAZESTYLE;
				break;
        case TOKEN_GLOW_SHADE:
g_print("\tTOKEN_GLOW_SHADE\n");
                token = theme_parse_shade (settings, scanner, &deviance_style->glow_shade);
				deviance_style->flags |= MRN_FLAG_GLOW_SHADE;
				break;
        case TOKEN_GLOWSTYLE:
g_print("\tTOKEN_GLOWSTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->glowstyle);
				deviance_style->flags |= MRN_FLAG_GLOWSTYLE;
				break;
        case TOKEN_GRADIENT_COLORS:
g_print("\tTOKEN_GRADIENT_COLORS\n");
                token = theme_parse_gradient_colors (settings, scanner, rc_style, &deviance_style->has_gradient_colors, deviance_style->gradient_colors);
				deviance_style->gflags |= MRN_FLAG_GRADIENT_COLORS;
				break;
        case TOKEN_GRADIENT_SHADES:
g_print("\tTOKEN_GRADIENT_SHADES\n");
                token = theme_parse_gradient (settings, scanner, deviance_style->gradient_shades);
				deviance_style->gflags |= MRN_FLAG_GRADIENT_SHADES;
				break;
        case TOKEN_HANDLESTYLE:
g_print("\tTOKEN_HANDLESTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->handlestyle);
				deviance_style->flags |= MRN_FLAG_HANDLESTYLE;
				break;
        case TOKEN_HIGHLIGHT_SHADE:
g_print("\tTOKEN_HIGHLIGHT_SHADE\n");
                token = theme_parse_shade (settings, scanner, &deviance_style->highlight_shade);
				deviance_style->flags |= MRN_FLAG_HIGHLIGHT_SHADE;
				break;
        case TOKEN_LIGHTBORDER_SHADE:
g_print("\tTOKEN_LIGHTBORDER_SHADE\n");
                token = theme_parse_shade (settings, scanner, &deviance_style->lightborder_shade);
				deviance_style->flags |= MRN_FLAG_LIGHTBORDER_SHADE;
				break;
        case TOKEN_LIGHTBORDERSTYLE:
g_print("\tTOKEN_LIGHTBORDERSTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->lightborderstyle);
				deviance_style->flags |= MRN_FLAG_LIGHTBORDERSTYLE;
				break;
        case TOKEN_LISTVIEWHEADERSTYLE:
g_print("\tTOKEN_LISTVIEWHEADERSTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->listviewheaderstyle);
				deviance_style->flags |= MRN_FLAG_LISTVIEWHEADERSTYLE;
				break;
        case TOKEN_LISTVIEWSTYLE:
g_print("\tTOKEN_LISTVIEWSTYLE\n");
                token = theme_parse_int (settings, scanner, &deviance_style->listviewstyle);
				deviance_style->flags |= MRN_FLAG_LISTVIEWSTYLE;
				break;
        case TOKEN_MENUBARITEMSTYLE:
g_print("\tTOKEN_MENUBARITEMSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->menubaritemstyle);
				deviance_style->flags |= MRN_FLAG_MENUBARITEMSTYLE;
				break;
        case TOKEN_MENUBARSTYLE:
            g_print("\tTOKEN_MENUBARSTYLE\n");
            token = theme_parse_int (settings, scanner, &deviance_style->menubarstyle);
            deviance_style->flags |= MRN_FLAG_MENUBARSTYLE;
            break;
        case TOKEN_MENUITEMSTYLE:
g_print("\tTOKEN_MENUITEMSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->menuitemstyle);
				deviance_style->flags |= MRN_FLAG_MENUITEMSTYLE;
				break;
			case TOKEN_MENUSTYLE:
g_print("\tTOKEN_MENUSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->menustyle);
				deviance_style->flags |= MRN_FLAG_MENUSTYLE;
				break;
			case TOKEN_PRELIGHT_SHADE:
g_print("\tTOKEN_PRELIGHT_SHADE\n");
				token = theme_parse_shade (settings, scanner, &deviance_style->prelight_shade);
				deviance_style->flags |= MRN_FLAG_PRELIGHT_SHADE;
				break;
			case TOKEN_PROGRESSBARSTYLE:
g_print("\tTOKEN_PROGRESSBARSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->progressbarstyle);
				deviance_style->flags |= MRN_FLAG_PROGRESSBARSTYLE;
				break;
			case TOKEN_RELIEFSTYLE:
g_print("\tTOKEN_RELIEFSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->reliefstyle);
				deviance_style->flags |= MRN_FLAG_RELIEFSTYLE;
				break;
			case TOKEN_RGBA:
g_print("\tTOKEN_RGBA\n");
				token = theme_parse_boolean (settings, scanner, &deviance_style->rgba);
				deviance_style->bflags |= MRN_FLAG_RGBA;
				break;
			case TOKEN_ROUNDNESS:
g_print("\tTOKEN_ROUNDNESS\n");
				token = theme_parse_int (settings, scanner, &deviance_style->roundness);
				deviance_style->bflags |= MRN_FLAG_ROUNDNESS;
				break;
			case TOKEN_SCROLLBARSTYLE:
g_print("\tTOKEN_SCROLLBARSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->scrollbarstyle);
				deviance_style->flags |= MRN_FLAG_SCROLLBARSTYLE;
				break;
			case TOKEN_SEPARATORSTYLE:
g_print("\tTOKEN_SEPARATORSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->separatorstyle);
				deviance_style->flags |= MRN_FLAG_SEPARATORSTYLE;
				break;
			case TOKEN_SHADOW_SHADES:
g_print("\tTOKEN_SHADOW_SHADES\n");
				token = theme_parse_border (settings, scanner, deviance_style->shadow_shades);
				deviance_style->gflags |= MRN_FLAG_SHADOW_SHADES;
				break;
			case TOKEN_SLIDERSTYLE:
g_print("\tTOKEN_SLIDERSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->sliderstyle);
				deviance_style->flags |= MRN_FLAG_SLIDERSTYLE;
				break;
			case TOKEN_SPINBUTTONSTYLE:
g_print("\tTOKEN_SPINBUTTONSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->spinbuttonstyle);
				deviance_style->flags |= MRN_FLAG_SPINBUTTONSTYLE;
				break;
			case TOKEN_STEPPERSTYLE:
g_print("\tTOKEN_STEPPERSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->stepperstyle);
				deviance_style->flags |= MRN_FLAG_STEPPERSTYLE;
				break;
			case TOKEN_TEXTSTYLE:
g_print("\tTOKEN_TEXTSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->textstyle);
				deviance_style->flags |= MRN_FLAG_TEXTSTYLE;
				break;
			case TOKEN_TEXT_SHADE:
g_print("\tTOKEN_TEXT_SHADE\n");
				token = theme_parse_shade (settings, scanner, &deviance_style->text_shade);
				deviance_style->flags |= MRN_FLAG_TEXT_SHADE;
				break;
			case TOKEN_TOOLBARSTYLE:
g_print("\tTOKEN_TOOLBARSTYLE\n");
				token = theme_parse_int (settings, scanner, &deviance_style->toolbarstyle);
				deviance_style->flags |= MRN_FLAG_TOOLBARSTYLE;
				break;
			case TOKEN_TROUGH_BORDER_SHADES:
g_print("\tTOKEN_TROUGH_BORDER_SHADES\n");
				token = theme_parse_border (settings, scanner, deviance_style->trough_border_shades);
				deviance_style->gflags |= MRN_FLAG_TROUGH_BORDER_SHADES;
				break;
			case TOKEN_TROUGH_SHADES:
g_print("\tTOKEN_TROUGH_SHADES\n");
				token = theme_parse_border (settings, scanner, deviance_style->trough_shades);
				deviance_style->gflags |= MRN_FLAG_TROUGH_SHADES;
				break;

			/* stuff to ignore */
			case TOKEN_GRADIENTS:
g_print("\tTOKEN_GRADIENTS\n");
				token = deviance_gtk2_rc_parse_dummy (settings, scanner, "gradients");
				break;
			case TOKEN_HILIGHT_RATIO:
g_print("\tTOKEN_HILIGHT_RATIO\n");
                g_scanner_warn (scanner, "Deviance configuration option \"%s\" will be deprecated in future releases. Please use \"highlight_shade\" instead.", "hilight_ratio");
				double hilight_ratio;
				token = theme_parse_shade (settings, scanner, &hilight_ratio);
				deviance_style->highlight_shade = hilight_ratio/0.909090;
				deviance_style->flags |= MRN_FLAG_HIGHLIGHT_SHADE;
				break;
			case TOKEN_HIGHLIGHT_RATIO:
g_print("\tTOKEN_HIGHLIGHT_RATIO\n");
                g_scanner_warn (scanner, "Deviance configuration option \"%s\" will be deprecated in future releases. Please use \"highlight_shade\" instead.", "highlight_ratio");
				token = theme_parse_shade (settings, scanner, &deviance_style->highlight_shade);
				deviance_style->flags |= MRN_FLAG_HIGHLIGHT_SHADE;
				break;
			case TOKEN_LIGHTBORDER_RATIO:
g_print("\tTOKEN_LIGHTBORDER_RATIO\n");
                g_scanner_warn (scanner, "Deviance configuration option \"%s\" will be deprecated in future releases. Please use \"lightborder_shade\" instead.", "lightborder_ratio");
				token = theme_parse_shade (settings, scanner, &deviance_style->lightborder_shade);
				deviance_style->flags |= MRN_FLAG_LIGHTBORDER_SHADE;
				break;
			case TOKEN_PROFILE:
g_print("\tTOKEN_PROFILE\n");
				token = deviance_gtk2_rc_parse_dummy (settings, scanner, "profile");
				break;
			case TOKEN_SCROLLBAR_COLOR:
g_print("\tTOKEN_SCROLLBAR_COLOR\n");
			{
				GdkColor dummy_color;
				token = deviance_gtk2_rc_parse_dummy_color (settings, scanner, "scrollbar_color", rc_style, &dummy_color);
				break;
			}
            case TOKEN_SQUAREDSTYLE:
g_print("\tTOKEN_SQUAREDSTYLE\n");
                token = deviance_gtk2_rc_parse_dummy (settings, scanner, "squaredstyle");
                break;
            case TOKEN_BACKGROUND:
g_print("\tTOKEN_BACKGROUND\n");
            {
            DevianceStyleBackground *background = deviance_style->background;
                token = ux_parse_background (settings, scanner, rc_style, &background);
                if (token==G_TOKEN_NONE) {
                    deviance_style->background = background;
                }
                /*
                DevianceStyleBackground *bg = NULL;
                background = bg;
                    g_hash_table_insert(deviance_style->_background, (gpointer)background, (gpointer)background);
                */
            }
            break;
            case TOKEN_BORDER:
g_print("\tTOKEN_BORDER %d @ %p\n", g_hash_table_size(deviance_style->_border), deviance_style);
            {
            DevianceStyleBorder *border = deviance_style->border;
                token = ux_parse_border (settings, scanner, rc_style, &border);
                if (token==G_TOKEN_NONE) {
                    deviance_style->border = border;
                    //g_hash_table_insert(deviance_style->_border, (gpointer)border, (gpointer)border);
                }
            }
            break;
            case TOKEN_BORDER_COLOR:
g_print("\tTOKEN_BORDER_COLOR\n");
            {
            break;
            }
            case TOKEN_BORDER_RADIUS:
g_print("\tTOKEN_BORDER_RADIUS\n");
            {
                DevianceStyleBorder *border = deviance_style->border;
                token = ux_parse_border_radius (settings, scanner, rc_style, &border);
                if (token==G_TOKEN_NONE)
                    deviance_style->border = border;
                break;
            }
            case TOKEN_BORDER_WIDTH:
g_print("\tTOKEN_BORDER_WIDTH\n");
            {
                DevianceStyleBorder *border = deviance_style->border;// ne sert a rien, car il faut prendre en compte le hash table
                token = ux_parse_border_width (settings, scanner, rc_style, &border);
                if (token==G_TOKEN_NONE)
                    deviance_style->border = border;
                break;
            }
            case TOKEN_BORDER_IMAGE:
g_print("\tTOKEN_BORDER_IMAGE\n");
            {
            DevianceStyleBorder *border = deviance_style->border;
            token = ux_parse_border_image (settings, scanner, rc_style, NULL);
            /*if (token==G_TOKEN_NONE)
                deviance_style->border = border;
            deviance_style->border_image = border->image;*/
            break;
            }
            case TOKEN_COLOR:
g_print("\tTOKEN_COLOR\n");
                //token = theme_parse_background_color(settings, scanner, &deviance_style->background);
                break;
            case TOKEN_STYLE:
g_print("\tTOKEN_STYLE\n");
				token = deviance_gtk2_rc_parse_dummy (settings, scanner, "style");
				break;

			default:
				g_scanner_get_next_token(scanner);
				token = G_TOKEN_RIGHT_CURLY;
				break;
		}

		if (token != G_TOKEN_NONE)
			return token;

		token = g_scanner_peek_next_token(scanner);
	}

	g_scanner_get_next_token(scanner);

	g_scanner_set_scope(scanner, old_scope);

	return G_TOKEN_NONE;
}

static void
deviance_rc_style_merge (GtkRcStyle *dest,
                        GtkRcStyle *src)
{
    g_print("-> %s (%s{%p} -> %s{%p})\n", G_STRFUNC, g_type_name_from_instance(src), src, g_type_name_from_instance(dest), dest);

    DevianceRcStyle *dest_w, *src_w;
	DevianceRcFlags flags;
	DevianceRcBasicFlags bflags;
	DevianceRcGradientFlags gflags;

	GTK_RC_STYLE_CLASS (deviance_rc_style_parent_class)->merge (dest, src);

	if (!DEVIANCE_IS_RC_STYLE (src))
		return;

	src_w = DEVIANCE_RC_STYLE (src);
	dest_w = DEVIANCE_RC_STYLE (dest);
    g_print("\t %d -> %d\n", g_hash_table_size(src_w->_border), g_hash_table_size(dest_w->_border));

	/* Flags */
	flags = (~dest_w->flags) & src_w->flags;

	if (flags & MRN_FLAG_ARROWSTYLE)
		dest_w->arrowstyle = src_w->arrowstyle;
	if (flags & MRN_FLAG_CELLSTYLE)
		dest_w->cellstyle = src_w->cellstyle;
	if (flags & MRN_FLAG_COMBOBOXSTYLE)
		dest_w->comboboxstyle = src_w->comboboxstyle;
	if (flags & MRN_FLAG_DEFAULT_BUTTON_COLOR)
	{
		dest_w->has_default_button_color = src_w->has_default_button_color;
		dest_w->default_button_color = src_w->default_button_color;
	}
	if (flags & MRN_FLAG_EXPANDERSTYLE)
		dest_w->expanderstyle = src_w->expanderstyle;
	if (flags & MRN_FLAG_FOCUS_COLOR)
	{
		dest_w->has_focus_color = src_w->has_focus_color;
		dest_w->focus_color = src_w->focus_color;
	}
	if (flags & MRN_FLAG_FOCUSSTYLE)
		dest_w->focusstyle = src_w->focusstyle;
	if (flags & MRN_FLAG_GLAZESTYLE)
		dest_w->glazestyle = src_w->glazestyle;
	if (flags & MRN_FLAG_GLOW_SHADE)
		dest_w->glow_shade = src_w->glow_shade;
	if (flags & MRN_FLAG_GLOWSTYLE)
		dest_w->glowstyle = src_w->glowstyle;
	if (flags & MRN_FLAG_HANDLESTYLE)
		dest_w->handlestyle = src_w->handlestyle;
	if (flags & MRN_FLAG_HIGHLIGHT_SHADE)
		dest_w->highlight_shade = src_w->highlight_shade;
	if (flags & MRN_FLAG_LIGHTBORDER_SHADE)
		dest_w->lightborder_shade = src_w->lightborder_shade;
	if (flags & MRN_FLAG_LIGHTBORDERSTYLE)
		dest_w->lightborderstyle = src_w->lightborderstyle;
	if (flags & MRN_FLAG_LISTVIEWHEADERSTYLE)
		dest_w->listviewheaderstyle = src_w->listviewheaderstyle;
	if (flags & MRN_FLAG_LISTVIEWSTYLE)
		dest_w->listviewstyle = src_w->listviewstyle;
	if (flags & MRN_FLAG_MENUBARITEMSTYLE)
		dest_w->menubaritemstyle = src_w->menubaritemstyle;
	if (flags & MRN_FLAG_MENUBARSTYLE)
		dest_w->menubarstyle = src_w->menubarstyle;
	if (flags & MRN_FLAG_MENUITEMSTYLE)
		dest_w->menuitemstyle = src_w->menuitemstyle;
	if (flags & MRN_FLAG_MENUSTYLE)
		dest_w->menustyle = src_w->menustyle;
	if (flags & MRN_FLAG_PRELIGHT_SHADE)
		dest_w->prelight_shade = src_w->prelight_shade;
	if (flags & MRN_FLAG_PROGRESSBARSTYLE)
		dest_w->progressbarstyle = src_w->progressbarstyle;
	if (flags & MRN_FLAG_RELIEFSTYLE)
		dest_w->reliefstyle = src_w->reliefstyle;
	if (flags & MRN_FLAG_SCROLLBARSTYLE)
		dest_w->scrollbarstyle = src_w->scrollbarstyle;
	if (flags & MRN_FLAG_SEPARATORSTYLE)
		dest_w->separatorstyle = src_w->separatorstyle;
	if (flags & MRN_FLAG_SLIDERSTYLE)
		dest_w->sliderstyle = src_w->sliderstyle;
	if (flags & MRN_FLAG_SPINBUTTONSTYLE)
		dest_w->spinbuttonstyle = src_w->spinbuttonstyle;
	if (flags & MRN_FLAG_STEPPERSTYLE)
		dest_w->stepperstyle = src_w->stepperstyle;
	if (flags & MRN_FLAG_TEXTSTYLE)
		dest_w->textstyle = src_w->textstyle;
	if (flags & MRN_FLAG_TEXT_SHADE)
		dest_w->text_shade = src_w->text_shade;
	if (flags & MRN_FLAG_TOOLBARSTYLE)
		dest_w->toolbarstyle = src_w->toolbarstyle;

	dest_w->flags |= src_w->flags;

	/* Basic Flags */
	bflags = (~dest_w->bflags) & src_w->bflags;

	if (bflags & MRN_FLAG_ANIMATION)
		dest_w->animation = src_w->animation;
	if (bflags & MRN_FLAG_COLORIZE_SCROLLBAR)
		dest_w->colorize_scrollbar = src_w->colorize_scrollbar;
	if (bflags & MRN_FLAG_CONTRAST)
		dest_w->contrast = src_w->contrast;
	if (bflags & MRN_FLAG_RGBA)
		dest_w->rgba = src_w->rgba;
	if (bflags & MRN_FLAG_ROUNDNESS)
		dest_w->roundness = src_w->roundness;

	dest_w->bflags |= src_w->bflags;

	/* Gradient Flags */
	gflags = (~dest_w->gflags) & src_w->gflags;

	if (gflags & MRN_FLAG_BORDER_COLORS)
	{
		dest_w->has_border_colors = src_w->has_border_colors;
		dest_w->border_colors[0]  = src_w->border_colors[0];
		dest_w->border_colors[1]  = src_w->border_colors[1];
	}
	if (gflags & MRN_FLAG_BORDER_SHADES)
	{
		dest_w->border_shades[0] = src_w->border_shades[0];
		dest_w->border_shades[1] = src_w->border_shades[1];
	}
	if (gflags & MRN_FLAG_GRADIENT_COLORS)
	{
		dest_w->has_gradient_colors = src_w->has_gradient_colors;
		dest_w->gradient_colors[0]  = src_w->gradient_colors[0];
		dest_w->gradient_colors[1]  = src_w->gradient_colors[1];
		dest_w->gradient_colors[2]  = src_w->gradient_colors[2];
		dest_w->gradient_colors[3]  = src_w->gradient_colors[3];
	}
	if (gflags & MRN_FLAG_GRADIENT_SHADES)
	{
		dest_w->gradient_shades[0] = src_w->gradient_shades[0];
		dest_w->gradient_shades[1] = src_w->gradient_shades[1];
		dest_w->gradient_shades[2] = src_w->gradient_shades[2];
		dest_w->gradient_shades[3] = src_w->gradient_shades[3];
	}
	if (gflags & MRN_FLAG_SHADOW_SHADES)
	{
		dest_w->shadow_shades[0] = src_w->shadow_shades[0];
		dest_w->shadow_shades[1] = src_w->shadow_shades[1];
	}
	if (gflags & MRN_FLAG_TROUGH_BORDER_SHADES)
	{
		dest_w->trough_border_shades[0] = src_w->trough_border_shades[0];
		dest_w->trough_border_shades[1] = src_w->trough_border_shades[1];
	}
    if (gflags & MRN_FLAG_TROUGH_SHADES)
    {
        dest_w->trough_shades[0] = src_w->trough_shades[0];
        dest_w->trough_shades[1] = src_w->trough_shades[1];
    }

    if (src_w->_background!=NULL && dest_w->_background!=NULL)
    {
        GHashTableIter iter;
        gpointer key, value;
        g_hash_table_iter_init (&iter, src_w->_background);
        g_print("how many background merged: %d\n", g_hash_table_size(src_w->_background));
        while (g_hash_table_iter_next (&iter, &key, &value))
        {
            DevianceStyleBackground *exists = g_hash_table_lookup(dest_w->_background, value);
            if (!exists) {
                DevianceStyleBackground *background = deviance_style_background_clone(value);
                g_hash_table_insert(dest_w->_background, background, background);
            } else {
                deviance_style_background_merge(value, exists);
            }
        }
    }

    if (src_w->_border!=NULL && dest_w->_border!=NULL) {
        GHashTableIter iter;
        gpointer key, value;
        g_hash_table_iter_init (&iter, src_w->_border);
        g_print("how many border merged: %d\n", g_hash_table_size(src_w->_border));
        while (g_hash_table_iter_next (&iter, &key, &value))
        {
            DevianceStyleBorder *border_src = DEVIANCE_STYLE_BORDER(value);
            DevianceStyleBorder *border_dest = g_hash_table_lookup(dest_w->_border, value);
            if (!border_dest) {
                DevianceStyleBorder *border = deviance_style_border_clone(value);
                g_hash_table_insert(dest_w->_border, border, border);
            } else {
                deviance_style_border_merge(value, border_dest);// border_dest = value
            }
        }
    }

    if (src_w->_box_shadow!=NULL && dest_w->_box_shadow!=NULL) {
        GHashTableIter iter;
        gpointer key, value;
        g_hash_table_iter_init (&iter, src_w->_box_shadow);
        g_print("how many border merged: %d\n", g_hash_table_size(src_w->_box_shadow));
        while (g_hash_table_iter_next (&iter, &key, &value))
        {
            DevianceStyleBoxShadow *box_shadow_src = DEVIANCE_STYLE_BOX_SHADOW(value);
            DevianceStyleBoxShadow *box_shadow_dest = g_hash_table_lookup(dest_w->_box_shadow, value);
            /*
            if (!box_shadow_dest) {
                DevianceStyleBoxShadow *border = deviance_style_box_shadow_clone(value);
                g_hash_table_insert(dest_w->_box_shadow, border, border);
            } else {
                deviance_style_box_shadow_merge(box_shadow_src, box_shadow_dest);// box_shadow_dest = value
            }
            */
            g_hash_table_insert(dest_w->_box_shadow, value, value);
        }
    }

    if (src_w->border_image!=NULL) {
        dest_w->border_image = src_w->border_image;
    }

    if (src_w->box_shadow!=NULL) {
        dest_w->box_shadow = src_w->box_shadow;
    }

    dest_w->gflags |= src_w->gflags;
}

static GtkRcStyle*
deviance_rc_style_create_rc_style(GtkRcStyle *rc_style)
{
    return GTK_RC_STYLE (g_object_new (DEVIANCE_TYPE_RC_STYLE, NULL));
}

/* Create an empty style suitable to this RC style
 */
static GtkStyle *
deviance_rc_style_create_style (GtkRcStyle *rc_style)
{
    g_print("-> %s\n", G_STRFUNC);
    return GTK_STYLE (g_object_new (DEVIANCE_TYPE_STYLE, NULL));
}

#if 0
DevianceStyleBackground*
deviance_rc_style_get_background_by_selector (GtkRcStyle *rc_style, DevianceStyleSelector *selector)
{
    DevianceRcStyle *rc = DEVIANCE_RC_STYLE(rc_style);
    // not used ...
    return NULL;
}
#endif


// DevianceStyleSelectorQuery { DevianceStyleState state, gint index, gint length}
typedef GList GList_DevianceStyleBorder;
DevianceStyleBorder*
deviance_rc_style_compute_border (DevianceRcStyle *rc, GList_DevianceStyleBorder *border)
{
    return NULL;
}


DevianceStyleBorder*
deviance_rc_style_get_border_by_state (GtkRcStyle *rc_style, DevianceStyleState state, gint index, gint length)
{
    DevianceRcStyle *rc = DEVIANCE_RC_STYLE(rc_style);
    DevianceStyleBorder *result = deviance_style_border_new();
    GHashTable *borders = rc->_border;
    GHashTableIter iter;
    gpointer key, value;

    DevianceStyleBorder *border_normal_all = NULL;
    DevianceStyleBorder *border_normal_first = NULL;
    DevianceStyleBorder *border_normal_last = NULL;

    DevianceStyleBorder *border_state_first = NULL;
    DevianceStyleBorder *border_state_last = NULL;
    DevianceStyleBorder *border_state_all = NULL;

    gboolean is_first = index==0;
    gboolean is_last = index==(length-1);

    g_hash_table_iter_init (&iter, borders);
    while (g_hash_table_iter_next (&iter, &key, &value))
    {
        DevianceStyleBorder *border = DEVIANCE_STYLE_BORDER(value);
        DevianceStyleSelector *selectors = border->selectors;
        DevianceStyleState selector_state = deviance_style_selector_get_state(selectors);

        //g_print("\t\t%s\n", deviance_style_selector_to_string(selectors));
        if (selector_state == DEVIANCE_STYLE_NORMAL_STATE) {
            if (selectors->hash.child == DEVIANCE_STYLE_FIRST_CHILD && is_first) {
                border_normal_first = border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_LAST_CHILD && is_last) {
                border_normal_last = border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_ALL_CHILD) {
                border_normal_all = border;
            }
        }

        if (selector_state == state) {
            if (selectors->hash.child == DEVIANCE_STYLE_FIRST_CHILD && is_first) {
                border_state_first = border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_LAST_CHILD && is_last) {
                border_state_last = border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_ALL_CHILD) {
                border_state_all = border;
            }
        }
    }

    if (state==DEVIANCE_STYLE_NORMAL_STATE) {
        if (border_normal_all) {
            deviance_style_border_merge(border_normal_all, result);
        }
        if (border_normal_first) {
            deviance_style_border_merge(border_normal_first, result);
        }
        if (border_normal_last) {
            deviance_style_border_merge(border_normal_last, result);
        }
    }

    return result;
}

DevianceStyleBorder*
deviance_rc_style_get_border (GtkRcStyle *rc_style, DevianceStyleState state, gint index, gint length)
{
    DevianceRcStyle *rc = DEVIANCE_RC_STYLE(rc_style);

    GHashTable *borders = rc->_border;
    GHashTableIter iter;
    gpointer key, value;
    DevianceStyleBorder *found = NULL;
    DevianceStyleBorder *default_border = NULL;
    DevianceStyleBorder *all_border = NULL;

#if 0
    DevianceStyleBorder *use_border;
    DevianceStyleBorder *query_border = deviance_style_border_new();
    DevianceStyleSelector *query_selectors = deviance_style_selector_new();
    query_border->selectors = query_selectors;

    GList * = deviance_rc_style_get_border_by_state(state, ...);
    // search for same state selector
    // --------------------------------------
    query_selectors->hash.state = state;

    query_selectors->hash.child = DEVIANCE_STYLE_ALL_CHILD;
    g_hash_table_lookup(rc->_border, query_border)
    if (index==0) {
        query_selectors->hash.child = DEVIANCE_STYLE_FIRST_CHILD;
        g_hash_table_lookup(rc->_border, query_border)
    }
    if (index==(length-1)) {
        query_selectors->hash.child = DEVIANCE_STYLE_LAST_CHILD;
        g_hash_table_lookup(rc->_border, query_border)
    }
    // DEVIANCE_STYLE_ODD_CHILD
    // DEVIANCE_STYLE_EVEN_CHILD
    if list empty
    deviance_rc_style_compute_border()


    // search for default state selector
    // --------------------------------------
    search for all_child

    then filter by state

    if first and last, merge to make a new Border from all_child

    query_selectors->hash.child = index==0?FIRST_CHILD:ALL_CHILD;
    query_selectors->hash.child = index==(length-1)?LAST_CHILD:ALL_CHILD;
    use_border = g_hash_table_lookup(borders, query_border);
    if (use_border) {
        return use_border;
    }

    // search for child selector

    // search for state selector

    // search for default selector

    g_object_unref(query_border);
#endif





#define my_debug(selectors) g_print("\tSelect border: %s\n", deviance_style_selector_to_string(selectors));
    g_print("deviance_rc_style_get_border (%d, %d, %d)---------------------------------------------------\n", state, index, length);
    g_hash_table_iter_init (&iter, borders);
    while (g_hash_table_iter_next (&iter, &key, &value))
    {
        DevianceStyleBorder *border = DEVIANCE_STYLE_BORDER(value);
        DevianceStyleSelector *selectors = border->selectors;
        DevianceStyleState selector_state = deviance_style_selector_get_state(selectors);

        g_print("\t\t%s\n", deviance_style_selector_to_string(selectors));
        if (selector_state == DEVIANCE_STYLE_NORMAL_STATE) {
            if (selectors->hash.child == DEVIANCE_STYLE_FIRST_CHILD
                    && index==0) {
                default_border = border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_NTH_CHILD
                       && index==selectors->hash.arg) {
                default_border = border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_LAST_CHILD
                       && index==(length-1)) {
                default_border = border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_ALL_CHILD) {
                default_border = border;
            }
        }
        if (selector_state == state) {
            if (selectors->hash.child == DEVIANCE_STYLE_FIRST_CHILD
                    && index==0) {
                my_debug(border->selectors)
                return border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_NTH_CHILD
                       && index==selectors->hash.arg) {
                my_debug(border->selectors)
                return border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_LAST_CHILD
                       && index==(length-1)) {
                my_debug(border->selectors)
                return border;
            } else if (selectors->hash.child == DEVIANCE_STYLE_ALL_CHILD) {
                found = border;
            }
        }
    }
    if (found)
        my_debug(found->selectors)
    else
        my_debug(default_border->selectors)
    return found!=NULL?found:default_border;
}

DevianceStyleBackground*
deviance_rc_style_get_background (GtkRcStyle *rc_style, DevianceStyleState state, gint index, gint length)
{
    DevianceRcStyle *rc = DEVIANCE_RC_STYLE(rc_style);

    GHashTable *backgrounds = rc->_background;
    GHashTableIter iter;
    gpointer key, value;
    DevianceStyleBackground *found = NULL;
    DevianceStyleBackground *default_background = NULL;

#define my_debug(selectors) g_print("\tSelect background: %s\n", deviance_style_selector_to_string(selectors));
    g_print("deviance_rc_style_get_background-----------------------------------------------\n");
    g_hash_table_iter_init (&iter, backgrounds);
    while (g_hash_table_iter_next (&iter, &key, &value))
    {
        DevianceStyleBackground *background = DEVIANCE_STYLE_BACKGROUND(value);
        DevianceStyleSelector *selectors = background->selectors;
        DevianceStyleState selector_state = deviance_style_selector_get_state(selectors);

        g_print("\t\t%s\n", deviance_style_selector_to_string(selectors));
        if (selector_state == DEVIANCE_STYLE_NORMAL_STATE) {
            if (selectors->hash.child == DEVIANCE_STYLE_FIRST_CHILD
                    && index==0) {
                default_background = background;
            } else if (selectors->hash.child == DEVIANCE_STYLE_NTH_CHILD
                       && index==selectors->hash.arg) {
                default_background = background;
            } else if (selectors->hash.child == DEVIANCE_STYLE_LAST_CHILD
                       && index==(length-1)) {
                default_background = background;
            } else if (selectors->hash.child == DEVIANCE_STYLE_ALL_CHILD) {
                default_background = background;
            }
        }
        if (selector_state == state) {
            if (selectors->hash.child == DEVIANCE_STYLE_FIRST_CHILD
                    && index==0) {
                return background;
            } else if (selectors->hash.child == DEVIANCE_STYLE_NTH_CHILD
                       && index==selectors->hash.arg) {
                return background;
            } else if (selectors->hash.child == DEVIANCE_STYLE_LAST_CHILD
                       && index==(length-1)) {
                return background;
            } else if (selectors->hash.child == DEVIANCE_STYLE_ALL_CHILD) {
                found = background;
            }
        }
    }
    if (found)
        my_debug(found->selectors)
    else if (default_background)
        my_debug(default_background->selectors)
    return found!=NULL?found:default_background;
}



DevianceStyleBoxShadow*
deviance_rc_style_get_box_shadow (GtkRcStyle *rc_style, DevianceStyleState state, gint index, gint length)
{
    DevianceRcStyle *rc = DEVIANCE_RC_STYLE(rc_style);

    GHashTable *box_shadows = rc->_box_shadow;
    GHashTableIter iter;
    gpointer key, value;
    DevianceStyleBoxShadow *found = NULL;
    DevianceStyleBoxShadow *default_box_shadow = NULL;

#define my_debug(selectors) g_print("\tSelect box shadow: %s\n", deviance_style_selector_to_string(selectors));
    g_print("deviance_rc_style_get_box_shadow-----------------------------------------------\n");
    g_hash_table_iter_init (&iter, box_shadows);
    while (g_hash_table_iter_next (&iter, &key, &value))
    {
        DevianceStyleBoxShadow *box_shadow = DEVIANCE_STYLE_BOX_SHADOW(value);
        DevianceStyleSelector *selectors = box_shadow->selectors;
        DevianceStyleState selector_state = deviance_style_selector_get_state(selectors);

        g_print("\t\t%s\n", deviance_style_selector_to_string(selectors));
        if (selector_state == DEVIANCE_STYLE_NORMAL_STATE) {
            if (selectors->hash.child == DEVIANCE_STYLE_FIRST_CHILD
                    && index==0) {
                default_box_shadow = box_shadow;
            } else if (selectors->hash.child == DEVIANCE_STYLE_NTH_CHILD
                       && index==selectors->hash.arg) {
                default_box_shadow = box_shadow;
            } else if (selectors->hash.child == DEVIANCE_STYLE_LAST_CHILD
                       && index==(length-1)) {
                default_box_shadow = box_shadow;
            } else if (selectors->hash.child == DEVIANCE_STYLE_ALL_CHILD) {
                default_box_shadow = box_shadow;
            }
        }
        if (selector_state == state) {
            if (selectors->hash.child == DEVIANCE_STYLE_FIRST_CHILD
                    && index==0) {
                return box_shadow;
            } else if (selectors->hash.child == DEVIANCE_STYLE_NTH_CHILD
                       && index==selectors->hash.arg) {
                return box_shadow;
            } else if (selectors->hash.child == DEVIANCE_STYLE_LAST_CHILD
                       && index==(length-1)) {
                return box_shadow;
            } else if (selectors->hash.child == DEVIANCE_STYLE_ALL_CHILD) {
                found = box_shadow;
            }
        }
    }
    if (found)
        my_debug(found->selectors)
    else
        my_debug(default_box_shadow->selectors)
    return found!=NULL?found:default_box_shadow;
}
