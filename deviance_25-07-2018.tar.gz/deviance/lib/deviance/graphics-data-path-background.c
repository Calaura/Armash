/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-data-path-background.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <math.h>
#include <cairo.h>


#include "graphics.h"
#include "display.h"
#include "styles.h"
#include "deviance_style.h"

#include "graphics-data.h"
#include "graphics-data-path.h"
#include "graphics-data-path-rectangle.h"


#include "style-length.h"
#include "style-border.h"

#include "graphics-data-path-background.h"

typedef struct _DevianceCorners DevianceCorners;
typedef struct _DevianceRadius DevianceRadius;
#define DEVIANCE_RADIUS_INIT(v) {v, v}
#define DEVIANCE_CORNERS_INIT(v) {DEVIANCE_RADIUS_INIT(v), DEVIANCE_RADIUS_INIT(v), DEVIANCE_RADIUS_INIT(v), DEVIANCE_RADIUS_INIT(v)}
//#define DEVIANCE_DISPLAY_APPROX 0.552284749831
#define DEVIANCE_DISPLAY_APPROX (1-0.552284749831)

struct _DevianceRadius {
    gdouble rx;
    gdouble ry;
};

struct _DevianceCorners {
    DevianceRadius top_left;
    DevianceRadius top_right;
    DevianceRadius bottom_right;
    DevianceRadius bottom_left;
};

static gboolean
display_is_epsilon(gdouble value)
{
    if (-0.01<value && value<0.01) {
        return TRUE;
    }
    return FALSE;
}

static gboolean
display_is_positive(gdouble value)
{
    if (value>=0.0) {
        return TRUE;
    }
    return FALSE;
}

static void
graphics_create_rounded_rectangle(cairo_t *cr, DevianceRectangle* rect, DevianceCorners *corners)
{
    double x         = rect->x,
           y         = rect->y,
           width     = rect->width,
           height    = rect->height;


    if (display_is_epsilon(corners->top_left.rx) || display_is_epsilon(corners->top_left.ry) ) {
        cairo_move_to(cr, x, y);
    } else {
        cairo_move_to(cr, x+corners->top_left.rx, y);
    }


    if (display_is_epsilon(corners->top_right.rx) || display_is_epsilon(corners->top_right.ry) ) {
        cairo_line_to(cr, x+width, y);
        cairo_curve_to(cr,
                       x+width, y,
                       x+width, y,
                       x+width, y);
    } else {
        cairo_line_to(cr, x+width-corners->top_right.rx, y);
        cairo_curve_to(cr,
                       x+width-corners->top_right.rx*(1-DEVIANCE_DISPLAY_APPROX), y,
                       x+width, y+corners->top_right.ry*(1-DEVIANCE_DISPLAY_APPROX),
                       x+width, y+corners->top_right.ry);
    }


    if (display_is_epsilon(corners->bottom_right.rx) || display_is_epsilon(corners->bottom_right.ry) ) {
        cairo_line_to(cr, x+width, y+height);
        cairo_curve_to(cr,
                       x+width, y+height,
                       x+width, y+height,
                       x+width, y+height);
    } else {
        cairo_line_to(cr, x+width, y+height-corners->bottom_right.ry);
        cairo_curve_to(cr,
                       x+width, y+height-corners->bottom_right.ry*(1-DEVIANCE_DISPLAY_APPROX),
                       x+width-corners->bottom_right.rx*(1-DEVIANCE_DISPLAY_APPROX), y+height,
                       x+width-corners->bottom_right.rx, y+height);
    }

    if (display_is_epsilon(corners->bottom_left.rx) || display_is_epsilon(corners->bottom_left.ry) ) {
        cairo_line_to(cr, x+corners->bottom_left.rx, y+height);
        cairo_curve_to(cr,
                       x+corners->bottom_left.rx, y+height,
                       x+corners->bottom_left.rx, y+height,
                       x+corners->bottom_left.rx, y+height);
    } else {
        cairo_line_to(cr, x+corners->bottom_left.rx, y+height);
        cairo_curve_to(cr,
                       x+corners->bottom_left.rx*(1-DEVIANCE_DISPLAY_APPROX), y+height,
                       x, y+height-corners->bottom_left.ry*(1-DEVIANCE_DISPLAY_APPROX),
                       x, y+height-corners->bottom_left.ry);
    }


    if (display_is_epsilon(corners->top_left.rx) || display_is_epsilon(corners->top_left.ry) ) {
        cairo_line_to(cr, x, y);
        cairo_curve_to(cr,
                       x, y,
                       x, y,
                       x, y);
    } else {
        cairo_line_to(cr, x, y+corners->top_left.ry);
        cairo_curve_to(cr,
                       x, y+corners->top_left.ry*(1-DEVIANCE_DISPLAY_APPROX),
                       x+corners->top_left.rx*(1-DEVIANCE_DISPLAY_APPROX), y,
                       x+corners->top_left.rx, y);
    }

}


static void
graphics_update_rounded_rectangle(cairo_path_t *path,
                                  DevianceRectangle *rect,
                                  DevianceCorners *corners)
{
    double x         = rect->x,
           y         = rect->y,
           width     = rect->width,
           height    = rect->height;

    cairo_path_data_t *path_data = path->data;
    gint index = 0;

    index += 1;
    if (display_is_epsilon(corners->top_left.rx) || display_is_epsilon(corners->top_left.ry) ) {
        path_data[index].point.x = x;
        path_data[index].point.y = y;
    } else {
        path_data[index].point.x = x+corners->top_left.rx;
        path_data[index].point.y = y;
    }
    index += 1;

    if (display_is_epsilon(corners->top_right.rx) || display_is_epsilon(corners->top_right.ry) ) {
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y;
        index += 2;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y;
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y;
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y;
        index += 1;
    } else {
        index += 1;
        path_data[index].point.x = x+width-corners->top_right.rx;
        path_data[index].point.y = y;
        index += 2;
        path_data[index].point.x = x+width-corners->top_right.rx*(1-DEVIANCE_DISPLAY_APPROX);
        path_data[index].point.y = y;
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+corners->top_right.ry*(1-DEVIANCE_DISPLAY_APPROX);
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+corners->top_right.ry;
        index += 1;
    }

    if (display_is_epsilon(corners->bottom_right.rx) || display_is_epsilon(corners->bottom_right.ry) ) {
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+height;
        index += 2;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+height;
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+height;
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+height;
        index += 1;
    } else {
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+height-corners->bottom_right.ry;
        index += 2;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+height-corners->bottom_right.ry*(1-DEVIANCE_DISPLAY_APPROX);
        index += 1;
        path_data[index].point.x = x+width-corners->bottom_right.rx*(1-DEVIANCE_DISPLAY_APPROX);
        path_data[index].point.y = y+height;
        index += 1;
        path_data[index].point.x = x+width-corners->bottom_right.rx;
        path_data[index].point.y = y+height;
        index += 1;
    }

    if (display_is_epsilon(corners->bottom_left.rx) || display_is_epsilon(corners->bottom_left.ry) ) {
        index += 1;
        path_data[index].point.x = x+corners->bottom_left.rx;
        path_data[index].point.y = y+height;
        index += 2;
        path_data[index].point.x = x+corners->bottom_left.rx;
        path_data[index].point.y = y+height;
        index += 1;
        path_data[index].point.x = x+corners->bottom_left.rx;
        path_data[index].point.y = y+height;
        index += 1;
        path_data[index].point.x = x+corners->bottom_left.rx;
        path_data[index].point.y = y+height;
        index += 1;
    } else {
        index += 1;
        path_data[index].point.x = x+corners->bottom_left.rx;
        path_data[index].point.y = y+height;
        index += 2;
        path_data[index].point.x = x+corners->bottom_left.rx*(1-DEVIANCE_DISPLAY_APPROX);
        path_data[index].point.y = y+height;
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y+height-corners->bottom_left.ry*(1-DEVIANCE_DISPLAY_APPROX);
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y+height-corners->bottom_left.ry;
        index += 1;
    }

    if (display_is_epsilon(corners->top_left.rx) || display_is_epsilon(corners->top_left.ry) ) {
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y;
        index += 2;
        path_data[index].point.x = x;
        path_data[index].point.y = y;
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y;
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y;
        index += 1;
    } else {
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y+corners->top_left.ry;
        index += 2;
        path_data[index].point.x = x;
        path_data[index].point.y = y+corners->top_left.ry*(1-DEVIANCE_DISPLAY_APPROX);
        index += 1;
        path_data[index].point.x = x+corners->top_left.rx*(1-DEVIANCE_DISPLAY_APPROX);
        path_data[index].point.y = y;
        index += 1;
        path_data[index].point.x = x+corners->top_left.rx;
        path_data[index].point.y = y;
        index += 1;
    }

}

static void
deviance_graphics_data_path_background_class_graphics_data_update_resize(DevianceGraphicsData* data,
                                                                         cairo_rectangle_t *rectangle)
{
    DevianceGraphicsDataPath *data_path = DEVIANCE_GRAPHICS_DATA_PATH(data);
    DevianceGraphicsDataPathBackground *self = DEVIANCE_GRAPHICS_DATA_PATH_BACKGROUND(data);
    DevianceStyleBorder *border = self->border;
    gdouble border_top_left_rx = 0.0;
    gdouble border_top_left_ry = 0.0;
    gdouble border_top_right_rx = 0.0;
    gdouble border_top_right_ry = 0.0;
    gdouble border_bottom_left_rx = 0.0;
    gdouble border_bottom_left_ry = 0.0;
    gdouble border_bottom_right_rx = 0.0;
    gdouble border_bottom_right_ry = 0.0;

    gdouble border_top = 0.0;
    gdouble border_right = 0.0;
    gdouble border_left = 0.0;
    gdouble border_bottom = 0.0;
    if (border) {
        border_top_left_rx = deviance_style_length_get_value(border->top_left.rx, NULL);
        border_top_left_ry = deviance_style_length_get_value(border->top_left.ry, NULL);
        border_top_right_rx = deviance_style_length_get_value(border->top_right.rx, NULL);
        border_top_right_ry = deviance_style_length_get_value(border->top_right.ry, NULL);
        border_bottom_left_rx = deviance_style_length_get_value(border->bottom_left.rx, NULL);
        border_bottom_left_ry = deviance_style_length_get_value(border->bottom_left.ry, NULL);
        border_bottom_right_rx = deviance_style_length_get_value(border->bottom_right.rx, NULL);
        border_bottom_right_ry = deviance_style_length_get_value(border->bottom_right.ry, NULL);

        border_top = deviance_style_length_get_value(border->top.width, NULL);
        border_right = deviance_style_length_get_value(border->right.width, NULL);
        border_left = deviance_style_length_get_value(border->left.width, NULL);
        border_bottom = deviance_style_length_get_value(border->bottom.width, NULL);
    }
    // TODO self->modifier rectangle

    g_assert(border_top_left_rx>=0.0);
    g_assert(border_top_left_ry>=0.0);
    g_assert(border_top_right_rx>=0.0);
    g_assert(border_top_right_ry>=0.0);
    g_assert(border_bottom_right_rx>=0.0);
    g_assert(border_bottom_right_ry>=0.0);
    g_assert(border_bottom_left_rx>=0.0);
    g_assert(border_bottom_left_ry>=0.0);

    g_assert(border_top>=0.0);
    g_assert(border_right>=0.0);
    g_assert(border_bottom>=0.0);
    g_assert(border_left>=0.0);


    gdouble tmp;
    gdouble ratio = 1.0;

    /// corner sanity check
    /// =======================================================================

    tmp = border_top_left_ry + border_bottom_left_ry;
    if (tmp > rectangle->height) {
        ratio = rectangle->height / tmp;
        border_top_left_ry *= ratio;
        border_bottom_left_ry *= ratio;
        border_top_left_rx *= ratio;
        border_bottom_left_rx *= ratio;
    }

    tmp = border_top_right_ry + border_bottom_right_ry;
    if (tmp > rectangle->height) {
        ratio = rectangle->height / tmp;
        border_top_right_ry *= ratio;
        border_bottom_right_ry *= ratio;
        border_top_right_rx *= ratio;
        border_bottom_right_rx *= ratio;
    }

    tmp = border_top_right_rx + border_bottom_right_rx;
    if (tmp > rectangle->width) {
        ratio = rectangle->width / tmp;
        border_top_left_ry *= ratio;
        border_bottom_left_ry *= ratio;
        border_top_left_rx *= ratio;
        border_bottom_left_rx *= ratio;
    }

    tmp = border_top_right_rx + border_bottom_right_rx;
    if (tmp > rectangle->width) {
        ratio = rectangle->width / tmp;
        border_top_right_ry *= ratio;
        border_bottom_right_ry *= ratio;
        border_top_right_rx *= ratio;
        border_bottom_right_rx *= ratio;
    }


    /// create cairo path
    /// =======================================================================


    cairo_path_t *path_rounded_rectangle = data_path->cr_path;

    if (path_rounded_rectangle==NULL) {
        cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_A8, 100, 100);
        cairo_t *cr = cairo_create(surface);
        DevianceRectangle r = {0.0, 0.0, 100.0, 100.0};
        DevianceCorners c = DEVIANCE_CORNERS_INIT(2.0);
        graphics_create_rounded_rectangle(cr, &r, &c);
        path_rounded_rectangle = cairo_copy_path(cr);
        cairo_destroy(cr);
        cairo_surface_destroy(surface);
    }

    DevianceCorners corners = {
        border_top_left_rx, border_top_left_ry,
        border_top_right_rx, border_top_right_ry,
        border_bottom_right_rx, border_bottom_right_ry,
        border_bottom_left_rx, border_bottom_left_ry
    };
    graphics_update_rounded_rectangle(path_rounded_rectangle, (DevianceRectangle*)rectangle, &corners);



    data_path->cr_path = path_rounded_rectangle;
}

static void
deviance_graphics_data_path_background_class_graphics_data_draw(DevianceGraphicsData *data, cairo_t *cr, gboolean preserve)
{
    DevianceGraphicsDataPathBackground *path_rectangle = DEVIANCE_GRAPHICS_DATA_PATH_BACKGROUND(data);
    DevianceGraphicsDataPath *path = DEVIANCE_GRAPHICS_DATA_PATH(data);
    cairo_append_path(cr, path->cr_path);
}

static void deviance_graphics_data_path_background_class_init(DevianceGraphicsDataPathBackgroundClass *klass);
static void deviance_graphics_data_path_background_init(DevianceGraphicsDataPathBackground *gobject);

G_DEFINE_TYPE (DevianceGraphicsDataPathBackground, deviance_graphics_data_path_background, DEVIANCE_TYPE_GRAPHICS_DATA_PATH)

static void
deviance_graphics_data_path_background_class_init(DevianceGraphicsDataPathBackgroundClass *klass)
{
//	DevianceGraphicsDataPathClass *deviancegraphicsdatapath_class;
//	deviancegraphicsdatapath_class = (DevianceGraphicsDataPathClass *) klass;
//    deviance_graphics_data_path_background_parent_class = g_type_class_peek_parent (klass);
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->draw = deviance_graphics_data_path_background_class_graphics_data_draw;
    DEVIANCE_GRAPHICS_DATA_CLASS(klass)->update_resize = deviance_graphics_data_path_background_class_graphics_data_update_resize;

}

static void
deviance_graphics_data_path_background_init (DevianceGraphicsDataPathBackground *object)
{
}

DevianceGraphicsDataPathBackground *
deviance_graphics_data_path_background_new (void)
{
	return g_object_new (deviance_graphics_data_path_background_get_type (),
	                     NULL);
}

