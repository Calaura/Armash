/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-color-stop.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "graphics.h"
#include "display.h"
#include "styles.h"

#include "style-color.h"
#include "style-color-stop.h"


static void deviance_style_color_stop_class_init(DevianceStyleColorStopClass *klass);
static void deviance_style_color_stop_init(DevianceStyleColorStop *gobject);

G_DEFINE_TYPE (DevianceStyleColorStop, deviance_style_color_stop, G_TYPE_OBJECT)

//static DevianceGraphicsData*
//deviance_style_color_stop_class_style_color_to_graphics(DevianceStyleColor *color, GtkStyle *gtk_style)
//{
//    // TODO remove this methode
//    return NULL;
//}

static void
deviance_style_color_stop_class_init(DevianceStyleColorStopClass *klass)
{
//    DEVIANCE_STYLE_COLOR_CLASS(klass)->to_graphics = deviance_style_color_stop_class_style_color_to_graphics;
}

static void
deviance_style_color_stop_init (DevianceStyleColorStop *object)
{
    object->color = NULL;
    object->offset = 0.0;
}

DevianceStyleColorStop *
deviance_style_color_stop_new (void)
{
	return g_object_new (deviance_style_color_stop_get_type (),
	                     NULL);
}

DevianceStyleColorStop*
deviance_style_color_stop_clone(DevianceStyleColorStop *self)
{
    DevianceStyleColorStop*clone = g_object_new (DEVIANCE_TYPE_STYLE_COLOR_STOP, NULL);

    if (self->color) {
        clone->color = deviance_style_color_clone(self->color);
    }
    clone->offset = self->offset;

    return clone;
}
