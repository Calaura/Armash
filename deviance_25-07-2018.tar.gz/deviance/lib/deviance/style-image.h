/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-image.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_STYLE_IMAGE_H__
#define __DEVIANCE_STYLE_IMAGE_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

typedef enum _DevianceStyleImageType DevianceStyleImageType;
enum _DevianceStyleImageType
{
    DEVIANCE_STYLE_IMAGE_URL = 0,
    DEVIANCE_STYLE_IMAGE_GRADIENT
};

#define DEVIANCE_TYPE_STYLE_IMAGE            (deviance_style_image_get_type())
#define DEVIANCE_STYLE_IMAGE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_STYLE_IMAGE, DevianceStyleImage))
#define DEVIANCE_STYLE_IMAGE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_STYLE_IMAGE, DevianceStyleImageClass))
#define DEVIANCE_IS_STYLE_IMAGE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_STYLE_IMAGE))
#define DEVIANCE_IS_STYLE_IMAGE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_STYLE_IMAGE))
#define DEVIANCE_STYLE_IMAGE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_STYLE_IMAGE, DevianceStyleImageClass))

typedef struct _DevianceStyleImageClass DevianceStyleImageClass;

struct _DevianceStyleImage {
    GObject parent_instance;
    DevianceStyleImageType type;
};

struct _DevianceStyleImageClass {
	GObjectClass parent_class;
    DevianceGraphicsData*     (*to_graphics)(DevianceStyleImage *style, GtkStyle *gtk_style);
    DevianceGraphicsData*     (*to_graphics_data_stroke)(DevianceStyleImage *style, GtkStyle *gtk_style);
    DevianceGraphicsData*     (*to_graphics_data_fill)(DevianceStyleImage *style, GtkStyle *gtk_style);
    void                      (*update_graphics)(DevianceStyleImage *style, GtkStyle *gtk_style, DevianceDisplayObject *object, DevianceGraphicsData *data);

    DevianceStyleImage*       (*clone)(DevianceStyleImage *self);
    void                      (*copy) (DevianceStyleImage *self, DevianceStyleImage *image);
};

GType                 deviance_style_image_get_type();
DevianceStyleImage   *deviance_style_image_new();
DevianceGraphicsData *deviance_style_image_to_graphics(DevianceStyleImage *style, GtkStyle *gtk_style);
DevianceGraphicsData *deviance_style_image_to_graphics_data_stroke(DevianceStyleImage *style, GtkStyle *gtk_style);
DevianceGraphicsData *deviance_style_image_to_graphics_data_fill(DevianceStyleImage *style, GtkStyle *gtk_style);
void                  deviance_style_image_update_graphics(DevianceStyleImage *style, GtkStyle *gtk_style, DevianceDisplayObject *object, DevianceGraphicsData *data);

DevianceStyleImage* deviance_style_image_clone(DevianceStyleImage *self);
void                deviance_style_image_copy(DevianceStyleImage *self, DevianceStyleImage *image);


G_END_DECLS

#endif /* __DEVIANCE_STYLE_IMAGE_H__ */

