/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * display-state.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "display.h"
#include "styles.h"

#include "display-object.h"
#include "display-container.h"
#include "display-style.h"
#include "display-state.h"


static void deviance_display_state_class_init(DevianceDisplayStateClass *klass);
static void deviance_display_state_init(DevianceDisplayState *gobject);

G_DEFINE_TYPE (DevianceDisplayState, deviance_display_state, DEVIANCE_TYPE_DISPLAY_OBJECT)

static void
deviance_display_state_class_init(DevianceDisplayStateClass *klass)
{
}

static void
deviance_display_state_init (DevianceDisplayState *object)
{
    //object->default = NULL;
    object->normal = NULL;
    object->active = NULL;
    object->prelight = NULL;
    object->selected = NULL;
    object->insensitive = NULL;
}

DevianceDisplayState*
deviance_display_state_new (void)
{
    return g_object_new (deviance_display_state_get_type (),
                         NULL);
}

DevianceDisplayObject*
deviance_display_state_get_display (DevianceDisplayState *self, DevianceStyleState state)
{
    DevianceDisplayObject *display = NULL;
    switch (state)
    {
    case DEVIANCE_STYLE_ACTIVE_STATE:
        if (NULL!=self->active) {
            display = self->active;
        }
        break;
    case DEVIANCE_STYLE_PRELIGHT_STATE:
        if (NULL!=self->prelight) {
            display = self->prelight;
        }
        break;
    case DEVIANCE_STYLE_INSENSITIVE_STATE:
        if (NULL!=self->insensitive) {
            display = self->insensitive;
        }
        break;
    case DEVIANCE_STYLE_SELECTED_STATE:
        if (NULL!=self->selected) {
            display = self->selected;
        }
        break;
    case DEVIANCE_STYLE_NORMAL_STATE:
    default:
        display = self->normal;
        break;
    }

    return display;
}
