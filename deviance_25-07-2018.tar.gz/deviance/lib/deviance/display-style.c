/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * display-style.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "display.h"

#include "display-object.h"
#include "display-container.h"
//#include "display-shape.h"
//#include "display-rectangle.h"
#include "display-style.h"


static void deviance_display_style_class_init(DevianceDisplayStyleClass *klass);
static void deviance_display_style_init(DevianceDisplayStyle *gobject);

G_DEFINE_TYPE (DevianceDisplayStyle, deviance_display_style, DEVIANCE_TYPE_DISPLAY_CONTAINER)

static void
deviance_display_style_class_init(DevianceDisplayStyleClass *klass)
{
}

static void
deviance_display_style_init (DevianceDisplayStyle *object)
{
    object->background_color = NULL;
    object->background_image = NULL;
    object->border_color     = NULL;
    object->border_image     = NULL;
    object->box_shadow       = NULL;
    object->text_shadow      = NULL;
}

DevianceDisplayStyle *
deviance_display_style_new (void)
{
	return g_object_new (deviance_display_style_get_type (),
	                     NULL);
}

