/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-color.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_STYLE_COLOR_H__
#define __DEVIANCE_STYLE_COLOR_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

typedef enum _DevianceStyleColorType DevianceStyleColorType;


/*
enum _DevianceStyleColorType
{
    DEVIANCE_STYLE_COLOR_UNKNOWN = 0,
    DEVIANCE_STYLE_COLOR_NONE,
    DEVIANCE_STYLE_COLOR_TRANSPARENT,
    DEVIANCE_STYLE_COLOR_RGB,
    DEVIANCE_STYLE_COLOR_RGBA,
    DEVIANCE_STYLE_COLOR_SCHEME,
    DEVIANCE_STYLE_COLOR_ICC
};
*/

#define DEVIANCE_TYPE_STYLE_COLOR            (deviance_style_color_get_type())
#define DEVIANCE_STYLE_COLOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_STYLE_COLOR, DevianceStyleColor))
#define DEVIANCE_STYLE_COLOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_STYLE_COLOR, DevianceStyleColorClass))
#define DEVIANCE_IS_STYLE_COLOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_STYLE_COLOR))
#define DEVIANCE_IS_STYLE_COLOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_STYLE_COLOR))
#define DEVIANCE_STYLE_COLOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_STYLE_COLOR, DevianceStyleColorClass))

typedef struct _DevianceStyleColorClass DevianceStyleColorClass;

struct _DevianceStyleColor {
	GObject parent_instance;

    /*< public >*/
    double r;
    double g;
    double b;
    double a;

    gboolean is_set;
};

struct _DevianceStyleColorClass {
    GObjectClass parent_class;
    DevianceGraphicsData* (*to_graphics)(DevianceStyleColor *self, GtkStyle *style);
    void                  (*copy)      (DevianceStyleColor *self, DevianceStyleColor *color);
    DevianceStyleColor*   (*clone)      (DevianceStyleColor *self);
};

GType                    deviance_style_color_get_type();
DevianceStyleColor      *deviance_style_color_new();
void                     deviance_style_color_copy(DevianceStyleColor *self, DevianceStyleColor *color);
DevianceGraphicsData    *deviance_style_color_to_graphics(DevianceStyleColor *self, GtkStyle *style);
DevianceGraphicsData    *deviance_style_color_to_graphics_data_fill(DevianceStyleColor *self, GtkStyle *style);
DevianceGraphicsData    *deviance_style_color_to_graphics_data_stroke(DevianceStyleColor *self, GtkStyle *style);
DevianceStyleColor      *deviance_style_color_clone(DevianceStyleColor *color);
void                     deviance_style_color_merge(DevianceStyleColor *self, DevianceStyleColor **dest);

G_END_DECLS

#endif /* __DEVIANCE_STYLE_COLOR_H__ */

