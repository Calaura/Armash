/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-border-image.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "styles.h"
#include "graphics.h"
#include "display.h"

#include "graphics-data.h"

//#include "display-object.h"

#include "style-image.h"
#include "style-border-image.h"

static void                  deviance_style_border_image_class_graphics_image_update_graphics(DevianceStyleImage *style, GtkStyle *gtk_style, DevianceDisplayObject *object, DevianceGraphicsData *data);
static DevianceGraphicsData *deviance_style_border_image_class_graphics_image_to_graphics(DevianceStyleImage *style, GtkStyle *gtk_style);

static DevianceGraphicsData*
deviance_style_border_image_class_graphics_image_to_graphics(DevianceStyleImage *style, GtkStyle *gtk_style)
{
    return NULL;
}

static DevianceGraphicsData*
deviance_style_border_image_class_graphics_image_to_graphics_data_stroke(DevianceStyleImage *style, GtkStyle *gtk_style)
{
    return NULL;
}

static DevianceGraphicsData*
deviance_style_border_image_class_graphics_image_to_graphics_data_fill(DevianceStyleImage *style, GtkStyle *gtk_style)
{
    DevianceStyleBorderImage *self = DEVIANCE_STYLE_BORDER_IMAGE(style);
    return deviance_style_image_to_graphics_data_fill(self->source, gtk_style);
}

static void
deviance_style_border_image_class_graphics_image_update_graphics(DevianceStyleImage *style, GtkStyle *gtk_style, DevianceDisplayObject *object, DevianceGraphicsData *data)
{

}

static void deviance_style_border_image_class_init(DevianceStyleBorderImageClass *klass);
static void deviance_style_border_image_init(DevianceStyleBorderImage *gobject);

G_DEFINE_TYPE (DevianceStyleBorderImage, deviance_style_border_image, DEVIANCE_TYPE_STYLE_IMAGE)

static void
deviance_style_border_image_class_init(DevianceStyleBorderImageClass *klass)
{
    DevianceStyleImageClass *image_class = DEVIANCE_STYLE_IMAGE_CLASS(klass);

    image_class->to_graphics             = deviance_style_border_image_class_graphics_image_to_graphics;
    image_class->to_graphics_data_stroke = deviance_style_border_image_class_graphics_image_to_graphics_data_stroke;
    image_class->to_graphics_data_fill   = deviance_style_border_image_class_graphics_image_to_graphics_data_fill;
    image_class->update_graphics = deviance_style_border_image_class_graphics_image_update_graphics;
}

static void
deviance_style_border_image_init (DevianceStyleBorderImage *object)
{
    object->source = NULL;
    object->slice = NULL;
    object->width = NULL;
    object->outset = NULL;
    object->repeat = NULL;
}

DevianceStyleBorderImage *
deviance_style_border_image_new (void)
{
	return g_object_new (deviance_style_border_image_get_type (),
	                     NULL);
}

DevianceStyleBorderImage*
deviance_style_border_image_clone(DevianceStyleBorderImage *self)
{
    DevianceStyleBorderImage *clone = g_object_new (DEVIANCE_TYPE_STYLE_BORDER_IMAGE, NULL);
    clone->source = deviance_style_image_clone(self->source);

    return clone;
}
