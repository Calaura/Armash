/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-selector.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "styles.h"

#include "style-selector.h"


static void deviance_style_selector_class_init(DevianceStyleSelectorClass *klass);
static void deviance_style_selector_init(DevianceStyleSelector *gobject);

G_DEFINE_TYPE (DevianceStyleSelector, deviance_style_selector, G_TYPE_OBJECT)

static void
deviance_style_selector_class_init(DevianceStyleSelectorClass *klass)
{
}

static void
deviance_style_selector_init (DevianceStyleSelector *object)
{
    object->hash.state = DEVIANCE_STYLE_NORMAL_STATE;
    object->hash.child = DEVIANCE_STYLE_ALL_CHILD;
    object->hash.arg = 0;
}

DevianceStyleSelector *
deviance_style_selector_new (void)
{
	return g_object_new (deviance_style_selector_get_type (),
	                     NULL);
}

guint
deviance_style_selector_to_int(DevianceStyleSelector *self)
{
    guint hash = 0;

    if (self!=NULL) {
        hash += self->hash.state << 0;
        hash += self->hash.child << 3;
        hash += self->hash.arg << 6;// maybe many args ...
    }

    return hash;
}

guint
deviance_style_selector_max_int()
{
    guint max = 8*8*256;// DEVIANCE_STYLE_NUM_STATES*DEVIANCE_STYLE_NUM_CHILDS*256
    return max;
}

DevianceStyleState
deviance_style_selector_get_state(DevianceStyleSelector *self)
{
    guint state = self->hash.state;
    return (DevianceStyleState)state;
}

DevianceStyleChild
deviance_style_selector_get_child(DevianceStyleSelector *self)
{
    guint child = self->hash.child;
    return (DevianceStyleChild)child;
}

gchar*
deviance_style_selector_to_string(DevianceStyleSelector *self)
{
    GString *output = g_string_new("");
    if (self==NULL) {
        return g_string_free(output, FALSE);
    }

    switch (self->hash.state) {
    case DEVIANCE_STYLE_NORMAL_STATE:
        g_string_append(output, "NORMAL");
        break;
    case DEVIANCE_STYLE_ACTIVE_STATE:
        g_string_append(output, "ACTIVE");
        break;
    case DEVIANCE_STYLE_PRELIGHT_STATE:
        g_string_append(output, "PRELIGHT");
        break;
    case DEVIANCE_STYLE_SELECTED_STATE:
        g_string_append(output, "SELECTED");
        break;
    case DEVIANCE_STYLE_INSENSITIVE_STATE:
        g_string_append(output, "INSENSITIVE");
        break;
    default:
        break;
    }

    g_string_append(output, ", ");

    switch (self->hash.child) {
    case DEVIANCE_STYLE_ALL_CHILD:
        g_string_append(output, "ALL_CHILD");
        break;
    case DEVIANCE_STYLE_FIRST_CHILD:
        g_string_append(output, "FIRST_CHILD");
        break;
    case DEVIANCE_STYLE_ODD_CHILD:
        g_string_append(output, "ODD_CHILD");
        break;
    case DEVIANCE_STYLE_EVEN_CHILD:
        g_string_append(output, "EVEN_CHILD");
        break;
    case DEVIANCE_STYLE_NTH_CHILD:
        g_string_append(output, "NTH_CHILD");
        break;
    case DEVIANCE_STYLE_FORMULA_CHILD:
        g_string_append(output, "FORMULA_CHILD");
        break;
    case DEVIANCE_STYLE_LAST_CHILD:
        g_string_append(output, "LAST_CHILD");
        break;
    default:
        break;
    }



    return g_string_free(output, FALSE);
}

DevianceStyleSelector*
deviance_style_selector_clone(DevianceStyleSelector *self)
{
    DevianceStyleSelector *clone = g_object_new (DEVIANCE_TYPE_STYLE_SELECTOR, NULL);

    clone->hash.state = self->hash.state;
    clone->hash.child = self->hash.child;
    clone->hash.arg = self->hash.arg;

    return clone;
}
