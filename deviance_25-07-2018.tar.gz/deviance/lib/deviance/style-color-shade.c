/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-color-shade.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "display.h"
#include "graphics.h"
#include "styles.h"

#include "style-color.h"
#include "style-color-shade.h"

static DevianceStyleColor *deviance_style_color_shade_class_style_color_clone(DevianceStyleColor *self);
static void                deviance_style_color_shade_class_style_color_copy(DevianceStyleColor *self, DevianceStyleColor *color);

static void deviance_style_color_shade_class_init(DevianceStyleColorShadeClass *klass);
static void deviance_style_color_shade_init(DevianceStyleColorShade *gobject);

G_DEFINE_TYPE (DevianceStyleColorShade, deviance_style_color_shade, DEVIANCE_TYPE_STYLE_COLOR)

static DevianceGraphicsData*
deviance_style_color_shade_class_style_color_to_graphics(DevianceStyleColor *style_color, GtkStyle *gtk_style)
{
/*
    DevianceStyleColorScheme *style_color = DEVIANCE_STYLE_COLOR_SCHEME(self);

    DevianceGraphicsDataFill *data = deviance_graphics_data_fill_new();
    GdkColor gdk_color;
    gboolean success = gtk_style_lookup_color(style, style_color->scheme, &gdk_color);
    //g_print("TODO: GdkColor{%0.2X, %0.2X, %0.2X}\n", gdk_color.red/0x100, gdk_color.green/0x100, gdk_color.blue/0x100);
    //g_print("TODO: GdkColor{%f, %f, %f}\n", gdk_color.red/(float)0x10000, gdk_color.green/(float)0x10000, gdk_color.blue/(float)0x10000);
    cairo_pattern_t *pattern = cairo_pattern_create_rgb(gdk_color.red/(float)0x10000, gdk_color.green/(float)0x10000, gdk_color.blue/(float)0x10000);
    data->pattern = pattern;
    return data;
*/
    return DEVIANCE_STYLE_COLOR_CLASS(deviance_style_color_shade_parent_class)->to_graphics(style_color, gtk_style);
}

static void
deviance_style_color_shade_class_init(DevianceStyleColorShadeClass *klass)
{
    DEVIANCE_STYLE_COLOR_CLASS(klass)->to_graphics = deviance_style_color_shade_class_style_color_to_graphics;
    DEVIANCE_STYLE_COLOR_CLASS(klass)->clone       = deviance_style_color_shade_class_style_color_clone;
    DEVIANCE_STYLE_COLOR_CLASS(klass)->copy        = deviance_style_color_shade_class_style_color_copy;
}

static void
deviance_style_color_shade_init (DevianceStyleColorShade *object)
{
    object->color = NULL;
    object->ratio = 1.0;
}

DevianceStyleColorShade *
deviance_style_color_shade_new (void)
{
	return g_object_new (deviance_style_color_shade_get_type (),
	                     NULL);
}
static void
deviance_style_color_shade_class_style_color_copy(DevianceStyleColor *self, DevianceStyleColor *color)
{
    DevianceStyleColorShade *self_shade = DEVIANCE_STYLE_COLOR_SHADE(self);
    DevianceStyleColorShade *color_shade = DEVIANCE_STYLE_COLOR_SHADE(color);

    color_shade->ratio = self_shade->ratio;
    if (color_shade->color) {
        deviance_style_color_copy(self_shade->color, color_shade->color);
    } else {
        color_shade->color = deviance_style_color_clone(self_shade->color);
    }

    DEVIANCE_STYLE_COLOR_CLASS(deviance_style_color_shade_parent_class)->copy(self, color);
}

static DevianceStyleColor*
deviance_style_color_shade_class_style_color_clone(DevianceStyleColor *self)
{
    DevianceStyleColorShade *clone = g_object_new (DEVIANCE_TYPE_STYLE_COLOR_SHADE, NULL);
    deviance_style_color_shade_class_style_color_copy(self, DEVIANCE_STYLE_COLOR(clone));

    return clone;
}
