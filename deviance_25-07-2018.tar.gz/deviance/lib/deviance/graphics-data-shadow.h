/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * graphics-data-shadow.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_GRAPHICS_DATA_SHADOW_H__
#define __DEVIANCE_GRAPHICS_DATA_SHADOW_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define DEVIANCE_TYPE_GRAPHICS_DATA_SHADOW            (deviance_graphics_data_shadow_get_type())
#define DEVIANCE_GRAPHICS_DATA_SHADOW(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_GRAPHICS_DATA_SHADOW, DevianceGraphicsDataShadow))
#define DEVIANCE_GRAPHICS_DATA_SHADOW_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_GRAPHICS_DATA_SHADOW, DevianceGraphicsDataShadowClass))
#define DEVIANCE_IS_GRAPHICS_DATA_SHADOW(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_GRAPHICS_DATA_SHADOW))
#define DEVIANCE_IS_GRAPHICS_DATA_SHADOW_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_GRAPHICS_DATA_SHADOW))
#define DEVIANCE_GRAPHICS_DATA_SHADOW_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_GRAPHICS_DATA_SHADOW, DevianceGraphicsDataShadowClass))

typedef struct _DevianceGraphicsDataShadow DevianceGraphicsDataShadow;
typedef struct _DevianceGraphicsDataShadowClass DevianceGraphicsDataShadowClass;

struct _DevianceGraphicsDataShadow {
	DevianceGraphicsData parent_instance;

    /*< public >*/
    DevianceStyleBorder *border;
    gint    x_offset;
    gint    y_offset;
    gint    spread;
    gdouble blur;
    cairo_pattern_t *image;
    cairo_pattern_t *color;

    cairo_pattern_t *pattern;
};

struct _DevianceGraphicsDataShadowClass {
	DevianceGraphicsDataClass parent_class;
};

GType deviance_graphics_data_shadow_get_type();
DevianceGraphicsDataShadow *deviance_graphics_data_shadow_new();

G_END_DECLS

#endif /* __DEVIANCE_GRAPHICS_DATA_SHADOW_H__ */

