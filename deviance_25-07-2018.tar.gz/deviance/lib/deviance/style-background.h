/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-background.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_STYLE_BACKGROUND_H__
#define __DEVIANCE_STYLE_BACKGROUND_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define DEVIANCE_TYPE_STYLE_BACKGROUND            (deviance_style_background_get_type())
#define DEVIANCE_STYLE_BACKGROUND(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_STYLE_BACKGROUND, DevianceStyleBackground))
#define DEVIANCE_STYLE_BACKGROUND_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_STYLE_BACKGROUND, DevianceStyleBackgroundClass))
#define DEVIANCE_IS_STYLE_BACKGROUND(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_STYLE_BACKGROUND))
#define DEVIANCE_IS_STYLE_BACKGROUND_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_STYLE_BACKGROUND))
#define DEVIANCE_STYLE_BACKGROUND_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_STYLE_BACKGROUND, DevianceStyleBackgroundClass))

typedef struct _DevianceStyleBackground DevianceStyleBackground;
typedef struct _DevianceStyleBackgroundClass DevianceStyleBackgroundClass;

struct _DevianceStyleBackground {
	GObject parent_instance;
    DevianceStyleSelector *selectors;

    /*< public >*/
    DevianceStyleColor *color;
    DevianceStyleImage *image;
    /*
    DevianceStyleRepeat *repeat;
    DevianceStylePosition *position;
    DevianceStylePosition *attachement;
    DevianceStylePosition *size;
    DevianceStylePosition *clip;
    */
};

struct _DevianceStyleBackgroundClass {
	GObjectClass parent_class;
};

GType deviance_style_background_get_type();
DevianceStyleBackground *deviance_style_background_new();
//guint deviance_style_parse_background (GtkRcStyle *rc_style,
//                                       GtkSettings  *settings,
//                                       GScanner   *scanner);

guint deviance_style_background_hash(gconstpointer  key);
gboolean deviance_style_background_equal(gconstpointer  key, gconstpointer b);
DevianceStyleState deviance_style_background_get_first_state(DevianceStyleBackground *self);
gboolean deviance_style_background_has_state(DevianceStyleBackground *self, DevianceStyleState state);

DevianceStyleBackground*deviance_style_background_clone(DevianceStyleBackground *self);
void                    deviance_style_background_copy(DevianceStyleBackground *self, DevianceStyleBackground *background);
void                    deviance_style_background_merge(DevianceStyleBackground *self, DevianceStyleBackground *background);

G_END_DECLS

#endif /* __DEVIANCE_STYLE_BACKGROUND_H__ */

