/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-box-shadow.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "styles.h"
#include "graphics.h"
#include "display.h"

#include "graphics-data.h"
//#include "graphics-data-stroke.h"
#include "graphics-data-fill.h"
#include "graphics-data-shadow.h"
#include "graphics-data-shadow-stack.h"
#include "cairo-support.h"
#include "raico-blur.h"
#include "style-image.h"

#include "style-box-shadow.h"



static void deviance_style_shadow_class_init(DevianceStyleShadowClass *klass);
static void deviance_style_shadow_init(DevianceStyleShadow *gobject);

G_DEFINE_TYPE (DevianceStyleShadow, deviance_style_shadow, G_TYPE_OBJECT)

static void
deviance_style_shadow_class_init(DevianceStyleShadowClass *klass)
{
}

static void
deviance_style_shadow_init (DevianceStyleShadow *object)
{
    object->h = 0.0;
    object->v = 0.0;
    object->blur = 0.0;
    object->spread = 0.0;
    object->color = NULL;
    object->image = NULL;
    object->inset = FALSE;
}

DevianceStyleShadow *
deviance_style_shadow_new (void)
{
    return g_object_new (deviance_style_shadow_get_type (),
                         NULL);
}
DevianceGraphicsData*
deviance_style_shadow_to_graphics_data_fill(DevianceStyleShadow *self, GtkRcStyle *style)
{
    //DevianceStyle *deviance_style = DEVIANCE_STYLE(gtk_style);
    DevianceStyleShadow *shadow = DEVIANCE_STYLE_SHADOW(self);
    DevianceGraphicsDataShadow *data = deviance_graphics_data_shadow_new();

#if 0


    /* draw glow */
    DevianceRGB fill = {0.294117647, 0.294117647, 0.274509804};
    DevianceRGB colors_bg = {0.0, 1.0, 0.0};

    gdouble width=50, bheight=20, bradius=0;
    cairo_surface_t *surface = cairo_image_surface_create (CAIRO_FORMAT_ARGB32, width, bheight);
    cairo_t *cr_surface = cairo_create (surface);

    cairo_set_source_rgb (cr_surface, fill.r, fill.g, fill.b);
    cairo_paint (cr_surface);

    cairo_rectangle (cr_surface, 1.5, 1.5, width-3, 16);// path of shape

    cairo_set_operator(cr_surface, CAIRO_OPERATOR_CLEAR);
    //cairo_set_line_width (cr_surface, 1.0);
    cairo_fill (cr_surface);
    cairo_set_operator(cr_surface, CAIRO_OPERATOR_SOURCE);

    raico_blur_t *blur = raico_blur_create (RAICO_BLUR_QUALITY_LOW);
    raico_blur_set_radius (blur, 0.0);
    raico_blur_apply (blur, surface);

//    cairo_rectangle (cr_surface, 0, -15, width, bheight+15);


    cairo_pattern_t *pattern = cairo_pattern_create_linear (0, -15, 0.0, bheight+15);
    deviance_pattern_add_color_stop_rgba (pattern, 0.25, &colors_bg, 0.0);
    deviance_pattern_add_color_stop_rgba (pattern, 1.0, &colors_bg, 1.0);


    data->image = cairo_pattern_create_for_surface(surface);

    return data;
#endif

    if (self->image) {
        g_print("%s\n", g_type_name_from_instance(self->image));
        DevianceGraphicsDataFill *fill = deviance_style_image_to_graphics_data_fill(self->image, style);
        data->x_offset = self->h;
        data->y_offset = self->v;
        data->blur = self->blur;
        data->spread = self->spread;
        data->blur = self->blur;
        data->pattern = fill->pattern;
    }

}
// ----------------------------------------------------------------------------

static void deviance_style_box_shadow_class_init(DevianceStyleBoxShadowClass *klass);
static void deviance_style_box_shadow_init(DevianceStyleBoxShadow *gobject);

G_DEFINE_TYPE (DevianceStyleBoxShadow, deviance_style_box_shadow, G_TYPE_OBJECT)

static void
deviance_style_box_shadow_class_init(DevianceStyleBoxShadowClass *klass)
{
}

static void
deviance_style_box_shadow_init (DevianceStyleBoxShadow *object)
{
    object->shadows = NULL;

    object->selectors = NULL;
}

DevianceStyleBoxShadow *
deviance_style_box_shadow_new (void)
{
	return g_object_new (deviance_style_box_shadow_get_type (),
	                     NULL);
}



DevianceGraphicsData*
deviance_style_box_shadow_to_graphics_data_fill(DevianceStyleBoxShadow *self, GtkRcStyle *style, DevianceStyleBorder *border)
{
    DevianceGraphicsDataShadowStack *data = deviance_graphics_data_shadow_stack_new();

    GList *it=NULL;
    for (it=g_list_first(self->shadows); it; it=it->next) {
        DevianceStyleShadow *style_shadow = it->data;
        DevianceGraphicsData *data_shadow = deviance_style_shadow_to_graphics_data_fill(style_shadow, style);
        DEVIANCE_GRAPHICS_DATA_SHADOW(data_shadow)->border = border;
        data->shadows = g_list_append(data->shadows, data_shadow);
    }

    return data;
}

guint
deviance_style_box_shadow_hash(gconstpointer  key)
{
    DevianceStyleBoxShadow *self = DEVIANCE_STYLE_BOX_SHADOW(key);
    guint hash = deviance_style_selector_to_int(self->selectors);
    return hash;
}

gboolean
deviance_box_shadow_equal(gconstpointer  a, gconstpointer  b)
{
    DevianceStyleBoxShadow *self = DEVIANCE_STYLE_BOX_SHADOW(a);
    DevianceStyleBoxShadow *border = DEVIANCE_STYLE_BOX_SHADOW(b);
    if (a==b) {
        return TRUE;
    }
    guint hash = deviance_style_box_shadow_hash(border);
    guint self_hash = deviance_style_box_shadow_hash(self);
    if (hash==self_hash) {
        return TRUE;
    }

    return FALSE;
}

