/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * display-object.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DEVIANCE_DISPLAY_OBJECT_H__
#define __DEVIANCE_DISPLAY_OBJECT_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define DEVIANCE_TYPE_DISPLAY_OBJECT            (deviance_display_object_get_type())
#define DEVIANCE_DISPLAY_OBJECT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DEVIANCE_TYPE_DISPLAY_OBJECT, DevianceDisplayObject))
#define DEVIANCE_DISPLAY_OBJECT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DEVIANCE_TYPE_DISPLAY_OBJECT, DevianceDisplayObjectClass))
#define DEVIANCE_IS_DISPLAY_OBJECT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DEVIANCE_TYPE_DISPLAY_OBJECT))
#define DEVIANCE_IS_DISPLAY_OBJECT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DEVIANCE_TYPE_DISPLAY_OBJECT))
#define DEVIANCE_DISPLAY_OBJECT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DEVIANCE_TYPE_DISPLAY_OBJECT, DevianceDisplayObjectClass))

typedef struct _DevianceDisplayObjectClass DevianceDisplayObjectClass;

struct _DevianceDisplayObject {
	GObject parent_instance;

    /*< public >*/
    DevianceDisplayContainer *parent;
    DevianceDisplayViewport *viewport;
    GtkStyle *style;// DevianceStyle
};

struct _DevianceDisplayObjectClass {
	GObjectClass parent_class;

    /*< public >*/
    void (*apply_style)(DevianceDisplayObject *self, GtkStyle *style);

    void (*update)(DevianceDisplayObject*self, gpointer data);
    void (*render)(DevianceDisplayObject*self, gpointer data);
};

GType deviance_display_object_get_type();
DevianceDisplayObject *deviance_display_object_new();
void deviance_display_object_update(DevianceDisplayObject *self);
void deviance_display_object_render(DevianceDisplayObject *self, gpointer data);

void deviance_display_object_queue_draw(DevianceDisplayObject *self);
void deviance_display_object_queue_resize(DevianceDisplayObject *self);

void deviance_display_object_attach_style(DevianceDisplayObject *self, GtkStyle *style);
void deviance_display_object_apply_style(DevianceDisplayObject *self, GtkRcStyle *rc_style);

/// used for GHashTable : getDisplayBySelector()
//guint deviance_display_object_hash(gconstpointer a);
//gboolean deviance_display_object_equal(gconstpointer a, gconstpointer b);

G_END_DECLS

#endif /* __DEVIANCE_DISPLAY_OBJECT_H__ */

