/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * style-color-palette.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "styles.h"
#include "graphics.h"
#include "display.h"

#include "style-color.h"
#include "style-color-palette.h"

static DevianceStyleColor *deviance_style_color_palette_class_style_color_clone(DevianceStyleColor *self);
static void                deviance_style_color_palette_class_style_color_copy(DevianceStyleColor *self, DevianceStyleColor *color);

static void deviance_style_color_palette_class_init(DevianceStyleColorPaletteClass *klass);
static void deviance_style_color_palette_init(DevianceStyleColorPalette *gobject);

G_DEFINE_TYPE (DevianceStyleColorPalette, deviance_style_color_palette, DEVIANCE_TYPE_STYLE_COLOR)

static void
deviance_style_color_palette_class_init(DevianceStyleColorPaletteClass *klass)
{
    DEVIANCE_STYLE_COLOR_CLASS(klass)->clone = deviance_style_color_palette_class_style_color_clone;
    DEVIANCE_STYLE_COLOR_CLASS(klass)->copy = deviance_style_color_palette_class_style_color_copy;
}

static void
deviance_style_color_palette_init (DevianceStyleColorPalette *object)
{
    object->name  = NULL;//bg fg
    object->state = NULL;//DEVIANCE_STYLE_STATE_NORMAL;
}

DevianceStyleColorPalette *
deviance_style_color_palette_new (void)
{
	return g_object_new (deviance_style_color_palette_get_type (),
	                     NULL);
}

static void
deviance_style_color_palette_class_style_color_copy(DevianceStyleColor *self, DevianceStyleColor *color)
{
    DevianceStyleColorPalette *self_palette = DEVIANCE_STYLE_COLOR_PALETTE(self);
    DevianceStyleColorPalette *color_palette = DEVIANCE_STYLE_COLOR_PALETTE(color);

    color_palette->name = g_strdup(self_palette->name);
    color_palette->state = g_strdup(self_palette->state);

    DEVIANCE_STYLE_COLOR_CLASS(deviance_style_color_palette_parent_class)->copy(self, color);

}

static DevianceStyleColor*
deviance_style_color_palette_class_style_color_clone(DevianceStyleColor *self)
{
    DevianceStyleColorPalette *clone = g_object_new (DEVIANCE_TYPE_STYLE_COLOR_PALETTE, NULL);
    deviance_style_color_palette_class_style_color_copy(self, DEVIANCE_STYLE_COLOR(clone));

    return clone;
}
