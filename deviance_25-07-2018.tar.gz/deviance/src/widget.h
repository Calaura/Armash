/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * widget.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __DV_WIDGET_H__
#define __DV_WIDGET_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define DV_TYPE_WIDGET            (dv_widget_get_type())
#define DV_WIDGET(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), DV_TYPE_WIDGET, DvWidget))
#define DV_WIDGET_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), DV_TYPE_WIDGET, DvWidgetClass))
#define DV_IS_WIDGET(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), DV_TYPE_WIDGET))
#define DV_IS_WIDGET_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), DV_TYPE_WIDGET))
#define DV_WIDGET_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), DV_TYPE_WIDGET, DvWidgetClass))

typedef struct _DvWidget DvWidget;
typedef struct _DvWidgetClass DvWidgetClass;

struct _DvWidget {
	GtkDrawingArea parent_instance;
};

struct _DvWidgetClass {
	GtkDrawingAreaClass parent_class;
};

GType dv_widget_get_type();
DvWidget *dv_widget_new();

G_END_DECLS

#endif /* __DV_WIDGET_H__ */

