/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * group-button.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __GTX_GROUP_BUTTON_H__
#define __GTX_GROUP_BUTTON_H__

#include <gtk/gtk.h>


G_BEGIN_DECLS

#define GTX_TYPE_GROUP_BUTTON            (gtx_group_button_get_type())
#define GTX_GROUP_BUTTON(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GTX_TYPE_GROUP_BUTTON, GtxGroupButton))
#define GTX_GROUP_BUTTON_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GTX_TYPE_GROUP_BUTTON, GtxGroupButtonClass))
#define GTX_IS_GROUP_BUTTON(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GTX_TYPE_GROUP_BUTTON))
#define GTX_IS_GROUP_BUTTON_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GTX_TYPE_GROUP_BUTTON))
#define GTX_GROUP_BUTTON_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GTX_TYPE_GROUP_BUTTON, GtxGroupButtonClass))

typedef struct _GtxGroupButton GtxGroupButton;
typedef struct _GtxGroupButtonClass GtxGroupButtonClass;

struct _GtxGroupButton {
	GtkBox parent_instance;
};

struct _GtxGroupButtonClass {
	GtkBoxClass parent_class;
};

GType gtx_group_button_get_type();
GtkWidget *gtx_group_button_new(gboolean homogeneous, gint spacing);

G_END_DECLS

#endif /* __GTX_GROUP_BUTTON_H__ */

