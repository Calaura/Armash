/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * widget.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "widget.h"


static void dv_widget_class_init(DvWidgetClass *klass);
static void dv_widget_init(DvWidget *gobject);

#if GTK_CHECK_VERSION(3,0,0)
static void
dv_widget_get_preferred_width (GtkWidget *widget, gint *minimal_width, gint *natural_width)
{
    *minimal_width = *natural_width = 10;
}

static void
dv_widget_get_preferred_height (GtkWidget *widget, gint *minimal_height, gint *natural_height)
{
    *minimal_height = *natural_height = 10;
}
#else
static void
dv_widget_size_request (GtkWidget *widget, GtkRequisition *requisition)
{
    requisition->width = 10;
    requisition->height = 10;
}
#endif


G_DEFINE_TYPE (DvWidget, dv_widget, GTK_TYPE_DRAWING_AREA)

#if GTK_CHECK_VERSION(3,0,0)
static void dv_widget_get_preferred_width (GtkWidget *widget, gint *minimal_width, gint *natural_width);
static void dv_widget_get_preferred_height (GtkWidget *widget, gint *minimal_height, gint *natural_height);
#else
static void dv_widget_size_request (GtkWidget *widget, GtkRequisition *requisition);
#endif

static void
dv_widget_class_init(DvWidgetClass *klass)
{
#if GTK_CHECK_VERSION(3,0,0)
    GTK_WIDGET_CLASS(klass)->get_preferred_width = dv_widget_get_preferred_width;
    GTK_WIDGET_CLASS(klass)->get_preferred_height = dv_widget_get_preferred_height;
#else
    GTK_WIDGET_CLASS(klass)->size_request = dv_widget_size_request;
#endif
}

static void
dv_widget_init (DvWidget *object)
{
}

DvWidget *
dv_widget_new (void)
{
	return g_object_new (dv_widget_get_type (),
	                     NULL);
}

