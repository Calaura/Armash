
#include "widget.h"
#include "group-button.h"
#include <gtk/gtk.h>

/* This is a callback function. The data arguments are ignored
 * in this example. More on callbacks below. */
void hello( GtkWidget *widget,
            gpointer   data )
{
    g_print ("Good bye\n");
}

gint delete_event( GtkWidget *widget,
                   GdkEvent  *event,
                   gpointer   data )
{
    /* If you return FALSE in the "delete_event" signal handler,
     * GTK will emit the "destroy" signal. Returning TRUE means
     * you don't want the window to be destroyed.
     * This is useful for popping up 'are you sure you want to quit?'
     * type dialogs. */

    g_print ("delete event occurred\n");
    gtk_main_quit();

    /* Change TRUE to FALSE and the main window will be destroyed with
     * a "delete_event". */

    return(TRUE);
}


/* Another callback */
void destroy( GtkWidget *widget,
              gpointer   data )
{
    gtk_main_quit();
}

typedef cairo_rectangle_t DevianceRectangle;
typedef struct _DevianceRadius DevianceRadius;
typedef struct _DevianceCorners DevianceCorners;
typedef struct _DevianceBorder DevianceBorder;
#define DEVIANCE_RADIUS_INIT {10.0, 10.0}
#define DEVIANCE_CORNERS_INIT {DEVIANCE_RADIUS_INIT, DEVIANCE_RADIUS_INIT, DEVIANCE_RADIUS_INIT, DEVIANCE_RADIUS_INIT}

struct _DevianceRadius {
    gdouble rx;
    gdouble ry;
};

struct _DevianceCorners {
    DevianceRadius top_left;
    DevianceRadius top_right;
    DevianceRadius bottom_right;
    DevianceRadius bottom_left;
};

enum _DevianceCornerShape {
    DEVIANCE_CORNER_SHAPE_SQUARED,
    DEVIANCE_CORNER_SHAPE_ROUNDED,
    DEVIANCE_CORNER_SHAPE_BEVEL,
    DEVIANCE_CORNER_SHAPE_PATH
};

struct _DevianceBorder {
    gdouble top;
    gdouble right;
    gdouble bottom;
    gdouble left;
};


#define IS_POSITIVE(value) (value>0.01 ? TRUE : FALSE)
#define IS_NEGATIVE(value) (value<-0.01 ? TRUE : FALSE)

gboolean
deviance_display_is_epsilon(gdouble value)
{
    if (-0.01<value && value<0.01) {
        return TRUE;
    }
    return FALSE;
}
gboolean
deviance_display_is_positive(gdouble value)
{
    if (value>=0.0) {
        return TRUE;
    }
    return FALSE;
}
gboolean
deviance_display_is_negative(gdouble value)
{
    if (value<0.00) {
        return TRUE;
    }
    return FALSE;
}

#define DEVIANCE_DISPLAY_CIRCLE 0.552284749831

void
deviance_display_destroy_rounded_rectangle(cairo_path_t *path)
{
    cairo_path_destroy(path);
}

cairo_path_t*
deviance_display_create_rounded_rectangle(DevianceRectangle *rect,
                                          DevianceCorners *corners)
{
    cairo_path_t *path = NULL;
    cairo_surface_t *surface = cairo_image_surface_create(CAIRO_FORMAT_A8, 100, 100);
    cairo_t *cr = cairo_create(surface);
    double x         = rect->x,
           y         = rect->y,
           width     = rect->width,
           height    = rect->height;

    cairo_new_path (cr);

    if (deviance_display_is_epsilon(corners->top_left.rx) || deviance_display_is_epsilon(corners->top_left.ry) ) {
        cairo_move_to(cr, x, y);
    } else {
        cairo_move_to(cr, x+corners->top_left.rx, y);
    }


    if (deviance_display_is_epsilon(corners->top_right.rx) || deviance_display_is_epsilon(corners->top_right.ry) ) {
        cairo_line_to(cr, x+width, y);
    } else if ( deviance_display_is_positive(corners->top_right.rx) || deviance_display_is_positive(corners->top_right.ry) ) {
        cairo_line_to(cr, x+width-corners->top_right.rx, y);
        cairo_curve_to(cr,
                       x+width-corners->top_right.rx*0.44771525016, y,
                       x+width, y+corners->top_right.ry*0.44771525016,
                       x+width, y+corners->top_right.ry);
    }


    if (deviance_display_is_epsilon(corners->bottom_right.rx) || deviance_display_is_epsilon(corners->bottom_right.ry) ) {
        cairo_line_to(cr, x+width, y+height);
        // TODO add virtual cairo_curve_to
    } else if ( deviance_display_is_positive(corners->bottom_right.rx) || deviance_display_is_positive(corners->bottom_right.ry) ) {
        cairo_line_to(cr, x+width, y+height-corners->bottom_right.ry);
        cairo_curve_to(cr,
                       x+width, y+height-corners->bottom_right.ry*0.44771525016,
                       x+width-corners->bottom_right.rx*0.44771525016, y+height,
                       x+width-corners->bottom_right.rx, y+height);
    }

    if (deviance_display_is_epsilon(corners->bottom_left.rx) || deviance_display_is_epsilon(corners->bottom_left.ry) ) {
        cairo_line_to(cr, x+corners->bottom_left.rx, y+height);
        // TODO add virtual cairo_curve_to
    } else if ( deviance_display_is_positive(corners->bottom_left.rx) || deviance_display_is_positive(corners->bottom_left.ry) ) {
        cairo_line_to(cr, x+corners->bottom_left.rx, y+height);
        cairo_curve_to(cr,
                       x+corners->bottom_left.rx*0.44771525016, y+height,
                       x, y+height-corners->bottom_left.ry*0.44771525016,
                       x, y+height-corners->bottom_left.ry);
    }


    if (deviance_display_is_epsilon(corners->top_left.rx) || deviance_display_is_epsilon(corners->top_left.ry) ) {
        cairo_line_to(cr, x, y);
        // TODO add virtual cairo_curve_to
    } else if ( deviance_display_is_positive(corners->top_left.rx) || deviance_display_is_positive(corners->top_left.ry) ) {
        cairo_line_to(cr, x, y+corners->top_left.ry);
        cairo_curve_to(cr,
                       x, y+corners->top_left.ry*0.44771525016,
                       x+corners->top_left.rx*0.44771525016, y,
                       x+corners->top_left.rx, y);
    }

    path = cairo_copy_path(cr);

    cairo_destroy(cr);
    cairo_surface_destroy(surface);

    return path;
}

void
deviance_display_update_rounded_rectangle(cairo_path_t *path,
                                          DevianceRectangle *rect,
                                          DevianceCorners *corners)
{
    double x         = rect->x,
           y         = rect->y,
           width     = rect->width,
           height    = rect->height;

    cairo_path_data_t * path_data = path->data;
    gint index = 0;

    index += 1;
    if (deviance_display_is_epsilon(corners->top_left.rx) || deviance_display_is_epsilon(corners->top_left.ry) ) {
        path_data[index].point.x = x;
        path_data[index].point.y = y;
    } else {
        path_data[index].point.x = x+corners->top_left.rx;
        path_data[index].point.y = y;
    }
    index += 1;

    if (deviance_display_is_epsilon(corners->top_right.rx) || deviance_display_is_epsilon(corners->top_right.ry) ) {
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y;
        index += 1;
    } else {
        index += 1;
        path_data[index].point.x = x+width-corners->top_right.rx;
        path_data[index].point.y = y;
        index += 2;
        path_data[index].point.x = x+width-corners->top_right.rx*0.44771525016;
        path_data[index].point.y = y;
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+corners->top_right.ry*0.44771525016;
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+corners->top_right.ry;
        index += 1;
    }

    if (deviance_display_is_epsilon(corners->bottom_right.rx) || deviance_display_is_epsilon(corners->bottom_right.ry) ) {
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+height;
        index += 1;
    } else {
        index += 1;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+height-corners->bottom_right.ry;
        index += 2;
        path_data[index].point.x = x+width;
        path_data[index].point.y = y+height-corners->bottom_right.ry*0.44771525016;
        index += 1;
        path_data[index].point.x = x+width-corners->bottom_right.rx*0.44771525016;
        path_data[index].point.y = y+height;
        index += 1;
        path_data[index].point.x = x+width-corners->bottom_right.rx;
        path_data[index].point.y = y+height;
        index += 1;
    }

    if (deviance_display_is_epsilon(corners->bottom_left.rx) || deviance_display_is_epsilon(corners->bottom_left.ry) ) {
        index += 1;
        path_data[index].point.x = x+corners->bottom_left.rx;
        path_data[index].point.y = y+height;
        index += 1;
    } else {
        index += 1;
        path_data[index].point.x = x+corners->bottom_left.rx;
        path_data[index].point.y = y+height;
        index += 2;
        path_data[index].point.x = x+corners->bottom_left.rx*0.44771525016;
        path_data[index].point.y = y+height;
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y+height-corners->bottom_left.ry*0.44771525016;
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y+height-corners->bottom_left.ry;
        index += 1;
    }

    if (deviance_display_is_epsilon(corners->top_left.rx) || deviance_display_is_epsilon(corners->top_left.ry) ) {
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y;
        index += 1;
    } else {
        index += 1;
        path_data[index].point.x = x;
        path_data[index].point.y = y+corners->top_left.ry;
        index += 2;
        path_data[index].point.x = x;
        path_data[index].point.y = y+corners->top_left.ry*0.44771525016;
        index += 1;
        path_data[index].point.x = x+corners->top_left.rx*0.44771525016;
        path_data[index].point.y = y;
        index += 1;
        path_data[index].point.x = x+corners->top_left.rx;
        path_data[index].point.y = y;
        index += 1;
    }

}













#if 1


void
deviance_graphics_data_path_rectangle(cairo_t *cr,
                                      DevianceRectangle *rect,
                                      DevianceCorners *corners)
{
    double x         = rect->x,
           y         = rect->y,
           width     = rect->width,
           height    = rect->height;

    cairo_new_sub_path (cr);

    if (0.0==corners->top_left.rx || 0.0==corners->top_left.ry) {
        cairo_move_to(cr, x, y);
    } else {
        cairo_move_to(cr, x+corners->top_left.rx, y);
    }


    if (0.0==corners->top_right.rx && 0.0==corners->top_right.ry) {
        cairo_line_to(cr, x+width, y);
        // TODO add virtual cairo_curve_to
    } else if (0.0<corners->top_right.rx && 0.0<corners->top_right.ry) {
        cairo_line_to(cr, x+width-corners->top_right.rx, y);
        cairo_curve_to(cr,
                       x+width-corners->top_right.rx*0.44771525016, y,
                       x+width, y+corners->top_right.ry*0.44771525016,
                       x+width, y+corners->top_right.ry);
    } else {// negative
        cairo_line_to(cr, x+width+corners->top_right.rx, y);
        cairo_curve_to(cr,
                       x+width+corners->top_right.rx, y-corners->top_right.ry*0.552284749831,
                       x+width+corners->top_right.rx*0.552284749831, y-corners->top_right.ry,
                       x+width, y-corners->top_right.ry);
    }


    if (0.0==corners->bottom_right.rx && 0.0==corners->bottom_right.ry) {
        cairo_line_to(cr, x+width, y+height);
        // TODO add virtual cairo_curve_to
    } else if (0.0<corners->bottom_right.rx && 0.0<corners->bottom_right.ry) {
        cairo_line_to(cr, x+width, y+height-corners->bottom_right.ry);
        cairo_curve_to(cr,
                       x+width, y+height-corners->bottom_right.ry*0.44771525016,
                       x+width-corners->bottom_right.rx*0.44771525016, y+height,
                       x+width-corners->bottom_right.rx, y+height);
    } else {// negative
        cairo_line_to(cr, x+width, y+height+corners->bottom_right.ry);
        cairo_curve_to(cr,
                       x+width+corners->bottom_right.rx*0.552284749831, y+height+corners->bottom_right.ry,
                       x+width+corners->bottom_right.rx, y+height+corners->bottom_right.ry*0.552284749831,
                       x+width+corners->bottom_right.rx, y+height);
    }

    if (0.0==corners->bottom_left.rx || 0.0==corners->bottom_left.ry) {
        cairo_line_to(cr, x+corners->bottom_left.rx, y+height);
        // TODO add virtual cairo_curve_to
    } else if (0.0<corners->bottom_left.rx && 0.0<corners->bottom_left.ry) {
        cairo_line_to(cr, x+corners->bottom_left.rx, y+height);
        cairo_curve_to(cr,
                       x+corners->bottom_left.rx*0.44771525016, y+height,
                       x, y+height-corners->bottom_left.ry*0.44771525016,
                       x, y+height-corners->bottom_left.ry);
    } else {// negative
        cairo_line_to(cr, x-corners->bottom_left.rx, y+height);
        cairo_curve_to(cr,
                       x-corners->bottom_left.rx, y+height+corners->bottom_left.ry*0.552284749831,
                       x-corners->bottom_left.rx*0.552284749831, y+height+corners->bottom_left.ry,
                       x, y+height+corners->bottom_left.ry);
    }


    if (0.0==corners->top_left.rx || 0.0==corners->top_left.ry) {
        cairo_line_to(cr, x, y);
        // TODO add virtual cairo_curve_to
    } else if (0.0<corners->top_left.rx && 0.0<corners->top_left.ry) {
        cairo_line_to(cr, x, y+corners->top_left.ry);
        cairo_curve_to(cr,
                       x, y+corners->top_left.ry*0.44771525016,
                       x+corners->top_left.rx*0.44771525016, y,
                       x+corners->top_left.rx, y);
    } else {// negative
        cairo_line_to(cr, x, y-corners->top_left.ry);
        cairo_curve_to(cr,
                       x-corners->top_left.rx*0.552284749831, y-corners->top_left.ry,
                       x-corners->top_left.rx, y-corners->top_left.ry*0.552284749831,
                       x-corners->top_left.rx, y);
    }
}

void
deviance_style_corner_clamp(DevianceBorder *border, DevianceCorners *corners)
{
    corners->top_left.rx-border->top, corners->top_left.ry-border->left;


}

#define ALPHA 1.0
void
deviance_display_rectangle_draw(cairo_t *cr,
                                DevianceRectangle *rect,
                                DevianceBorder *border,
                                DevianceCorners *corners)
{
    cairo_set_source_rgba(cr, 1.0, 1.0, 1.0, ALPHA);
    cairo_set_line_width(cr, 1.0);
    cairo_set_fill_rule (cr, CAIRO_FILL_RULE_EVEN_ODD);


    DevianceRectangle rect_out = *rect;
    DevianceCorners corners_out = *corners;

    deviance_graphics_data_path_rectangle(cr, &rect_out, &corners_out);


    DevianceRectangle rect_in = {rect_out.x+border->left, rect_out.y+border->top,
                                 rect_out.width-border->left-border->right, rect_out.height-border->top-border->bottom};

    // faire en sorte que si rx / ry negatif mettre a zero
/*
    DevianceCorners corners_in = {
        {corners_out.top_left.rx-border->top, corners_out.top_left.ry-border->left},
        {corners_out.top_right.rx-border->top, corners_out.top_right.ry-border->right},
        {corners_out.bottom_left.rx-border->bottom, corners_out.bottom_left.ry-border->right},
        {corners_out.bottom_right.rx-border->bottom, corners_out.bottom_right.ry-border->right},
    };

    if ( deviance_display_is_epsilon(corners_in.top_left.rx) || deviance_display_is_epsilon(corners_in.top_left.ry) ) {
        corners_in.top_left.rx = 0.0;
        corners_in.top_left.ry = 0.0;
    }
    if ( deviance_display_is_epsilon(corners_in.top_right.rx) || deviance_display_is_epsilon(corners_in.top_right.ry) ) {
        corners_in.top_right.rx = 0.0;
        corners_in.top_right.ry = 0.0;
    }
    if ( deviance_display_is_epsilon(corners_in.bottom_right.rx) || deviance_display_is_epsilon(corners_in.bottom_right.ry) ) {
        corners_in.bottom_right.rx = 0.0;
        corners_in.bottom_right.ry = 0.0;
    }
    if ( deviance_display_is_epsilon(corners_in.bottom_left.rx) || deviance_display_is_epsilon(corners_in.bottom_left.ry) ) {
        corners_in.bottom_left.rx = 0.0;
        corners_in.bottom_left.ry = 0.0;
    }

    // --------------------------

    if ( deviance_display_is_negative(corners_in.top_left.rx) || deviance_display_is_negative(corners_in.top_left.ry) ) {
        corners_in.top_left.rx += border->left;
        corners_in.top_left.ry += border->top;
    } else {
        corners_in.top_left.rx -= border->left;
        corners_in.top_left.ry -= border->top;
    }
    if ( deviance_display_is_negative(corners_in.top_right.rx) || deviance_display_is_negative(corners_in.top_right.ry) ) {
        corners_in.top_right.rx += border->right;
        corners_in.top_right.ry += border->top;
    } else {
        corners_in.top_right.rx -= border->right;
        corners_in.top_right.ry -= border->top;
    }
    if ( deviance_display_is_negative(corners_in.bottom_right.rx) || deviance_display_is_negative(corners_in.bottom_right.ry) ) {
        corners_in.bottom_right.rx += border->right;
        corners_in.bottom_right.ry += border->bottom;
    } else {
        corners_in.bottom_right.rx -= border->right;
        corners_in.bottom_right.ry -= border->bottom;
    }
    if ( deviance_display_is_negative(corners_in.bottom_left.rx) || deviance_display_is_negative(corners_in.bottom_left.ry) ) {
        corners_in.bottom_left.rx += border->left;
        corners_in.bottom_left.ry += border->bottom;
    } else {
        corners_in.bottom_left.rx -= border->left;
        corners_in.bottom_left.ry -= border->bottom;
    }
*/
    DevianceCorners corners_in = corners_out;


    deviance_graphics_data_path_rectangle(cr, &rect_in, &corners_in);

    cairo_close_path (cr);
    cairo_fill (cr);


}
#endif


static cairo_path_t* path = NULL;

void
my_draw(cairo_t *cr,
        DevianceRectangle *rectangle,
        DevianceBorder *border,
        DevianceCorners *corners)
{
    DevianceRectangle *rect=g_new(DevianceRectangle, 1);
    rect->x = rectangle->x;
    rect->y = rectangle->y;
    rect->width = rectangle->width;
    rect->height = rectangle->height;

    rect->x += border->left/2.0;
    rect->y += border->top/2.0;
    rect->width -= border->left/2.0 + border->right/2.0;
    rect->height -= border->top/2.0 + border->bottom/2.0;

//    if (path==NULL) {
        path = deviance_display_create_rounded_rectangle(rect, corners);
//    } else {
//        deviance_display_update_rounded_rectangle(path, rect, corners);
//    }

        cairo_append_path(cr, path);
        //cairo_set_line_width(cr, 10.0);
        cairo_set_source_rgba(cr, 0.0, 1.0, 0.0, ALPHA);
        cairo_fill(cr);

    cairo_path_destroy(path);
}

#include "../lib/deviance/graphics.h"
#include "../lib/deviance/styles.h"
#include "../lib/deviance/style-border.h"
#include "../lib/deviance/style-length.h"


gboolean
expose_event_callback (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
    DevianceRectangle rect = {10.0, 10.0, 101, 101};
    /*
    rect.x = event->area.x;
    rect.y = event->area.y;
    rect.width = event->area.width;
    rect.height = event->area.height;
    */
    cairo_t *cr = gdk_cairo_create(GDK_DRAWABLE(widget->window));
    cairo_rectangle(cr, event->area.x, event->area.y, event->area.width, event->area.height);
    cairo_set_source_rgb(cr, 0.0, 0.0, 0.0);
    cairo_fill(cr);

    DevianceStyleBorder *borders = deviance_style_border_new();
    borders->top.width->value = 14.0;
    borders->right.width->value = 2.0;
    borders->bottom.width->value = 14.0;
    borders->left.width->value = 1.0;

    DevianceBorder border = {0.0, 0.0, 10.0, 0.0};
    DevianceCorners corners = {
        {20.0, 20.0}, {20.0, 20.0},
        {20.0, 20.0}, {20.0, 20.0},
    };

    DevianceRectangle rect_a = rect;
    rect_a.height+=border.bottom/2;
    my_draw(cr, &rect_a, &border, &corners);
    deviance_display_rectangle_draw(cr, &rect, &border, &corners);// border


    return TRUE;
}



int main (int argc, char **argv)
{
    /* GtkWidget is the storage type for widgets */
    GtkWidget *window;
    GtkWidget *btn1;
    GtkWidget *btn2;
    GtkWidget *btn3;
    GtkWidget *button;
    GtkWidget *button_1;
    GtkWidget *button_2;
    GtkWidget *button_3;
    GtkWidget *button_4;
    GtkWidget *box;
    GtkWidget *hbox;
    GtkWidget *scrolled_window;
    GtkWidget *drawing_area;

    /* This is called in all GTK applications. Arguments are parsed
     * from the command line and are returned to the application. */
    gtk_init(&argc, &argv);

    gchar *default_theme = "Variance";// Deviance
    gtk_settings_set_string_property (gtk_settings_get_default (), "gtk-theme-name", default_theme, NULL);

    /* create a new window */
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window), 500, 350);
    gtk_window_set_position(GTK_WINDOW(window), GTK_WIN_POS_CENTER);

    /* When the window is given the "delete_event" signal (this is given
     * by the window manager, usually by the "close" option, or on the
     * titlebar), we ask it to call the delete_event () function
     * as defined above. The data passed to the callback
     * function is NULL and is ignored in the callback function. */
    gtk_signal_connect (GTK_OBJECT (window), "delete_event",
                        GTK_SIGNAL_FUNC (delete_event), NULL);

    /* Here we connect the "destroy" event to a signal handler.
     * This event occurs when we call gtk_widget_destroy() on the window,
     * or if we return FALSE in the "delete_event" callback. */
    gtk_signal_connect (GTK_OBJECT (window), "destroy",
                        GTK_SIGNAL_FUNC (destroy), NULL);

    /* Sets the border width of the window. */
    gtk_container_set_border_width (GTK_CONTAINER (window), 3);

    /* Creates a new button with the label "Hello World". */
    box = gtk_vbox_new (FALSE, 0);
    hbox = gtx_group_button_new (TRUE, 0);// GtkGroupButton (Gtk[Toggle|Radio]Button)
//    hbox = gtk_hbutton_box_new ();
//    GtkButtonBoxStyle layout_style = GTK_BUTTONBOX_SPREAD;
//    gtk_button_box_set_layout (GTK_BUTTON_BOX(hbox), layout_style);

    button = gtk_button_new_with_label ("Hello World ... ");
    //gtk_widget_set_name(button, "my_button");
    //gtk_button_set_alignment (GTK_BUTTON(button), 1.0, 1.0);
    btn1 = gtk_button_new_with_label ("button");
    btn2 = gtk_button_new_with_label ("button");
    btn3 = gtk_button_new_with_label ("button");

    button_1 = gtk_button_new_with_label ("1");
    button_2 = gtk_button_new_with_label ("2");
    button_3 = gtk_button_new_with_label ("3");
    button_4 = gtk_button_new_with_label ("4");

//    gtk_widget_set_name(button_1, "first");
//    gtk_widget_set_name(button_2, "middel");
//    gtk_widget_set_name(button_3, "last");

    //widget = dv_widget_new ();
    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    drawing_area = gtk_drawing_area_new();
    gtk_widget_set_size_request (drawing_area, 200, 200);
    g_signal_connect (G_OBJECT (drawing_area), "expose_event",
                      G_CALLBACK (expose_event_callback), NULL);
    gtk_scrolled_window_add_with_viewport(GTK_SCROLLED_WINDOW(scrolled_window), drawing_area);


    /* When the button receives the "clicked" signal, it will call the
     * function hello() passing it NULL as its argument.  The hello()
     * function is defined above. */
    gtk_signal_connect (GTK_OBJECT (button), "clicked",
                        GTK_SIGNAL_FUNC (hello), NULL);

    /* This will cause the window to be destroyed by calling
     * gtk_widget_destroy(window) when "clicked".  Again, the destroy
     * signal could come from here, or the window manager. */
    gtk_signal_connect_object (GTK_OBJECT (button), "clicked",
                               GTK_SIGNAL_FUNC (gtk_widget_destroy),
                               GTK_OBJECT (window));

    /* This packs the button into the window (a gtk container). */
    gint padding = 0;
//    gtk_box_pack_start(GTK_BOX (box), btn1, TRUE, TRUE, 0);
//    gtk_box_pack_start(GTK_BOX (box), btn2, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX (hbox), button_1, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX (hbox), button_2, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX (hbox), button_3, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX (hbox), button_4, TRUE, TRUE, 0);
    gtk_box_pack_start(GTK_BOX (box), hbox, TRUE, TRUE, padding);
    gtk_box_pack_start(GTK_BOX (box), button, TRUE, TRUE, padding);
    gtk_box_pack_start(GTK_BOX (box), scrolled_window, TRUE, TRUE, padding);
    gtk_container_add (GTK_CONTAINER (window), box);

//    GtkWidget *button_box = gtk_hbutton_box_new ();
//    gtk_box_pack_start(GTK_BOX (button_box), btn1, TRUE, TRUE, 0);
//    gtk_box_pack_start(GTK_BOX (button_box), btn2, TRUE, TRUE, 0);
//    gtk_box_pack_start(GTK_BOX (button_box), btn3, TRUE, TRUE, 0);
    //gtk_button_box_set_layout (GTK_BUTTON_BOX(button_box), GTK_BUTTONBOX_CENTER);
    //gtk_box_pack_start(GTK_BOX (box), button_box, TRUE, TRUE, 0);
    /* The final step is to display this newly created widget. */
//    gtk_widget_show (button);
//    gtk_widget_show (widget);
//    gtk_widget_show (box);


    /* and the window */
    gtk_widget_show_all (window);

    /* All GTK applications must have a gtk_main(). Control ends here
     * and waits for an event to occur (like a key press or
     * mouse event). */
    gtk_main ();
    g_print("BUGGGGGGGGGGGGG gtk_box_pack_start(GTK_BOX (box), button, TRUE, TRUE, 3);\n");

    return(0);
}

