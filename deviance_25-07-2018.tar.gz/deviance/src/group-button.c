/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * group-button.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "group-button.h"



static void gtx_group_button_class_init(GtxGroupButtonClass *klass);
static void gtx_group_button_init(GtxGroupButton *gobject);

G_DEFINE_TYPE (GtxGroupButton, gtx_group_button, GTK_TYPE_BOX)

static void
gtx_group_button_class_widget_size_request(GtkWidget *widget, GtkRequisition *requisition)
{
    GTK_WIDGET_CLASS(gtx_group_button_parent_class)->size_request(widget, requisition);
    GtkStyle *style = gtk_widget_get_style(widget);
    requisition->width -= 2.0*style->xthickness;
    requisition->height -= 2.0*style->xthickness;
}
static void
gtx_group_button_class_widget_size_allocate(GtkWidget *widget, GtkAllocation *allocation)
{
    //GTK_WIDGET_GET_CLASS(widget)->size_allocate(widget, allocation);
    GTK_WIDGET_CLASS(gtx_group_button_parent_class)->size_allocate(widget, allocation);

    GtkStyle *style = gtk_widget_get_style(widget);
    style->xthickness = 0;
    style->ythickness = 0;
    allocation->x += style->xthickness;
    allocation->y += style->xthickness;
    allocation->width -= 2.0*style->xthickness;
    allocation->height -= 2.0*style->xthickness;
}

static void
gtx_group_button_class_init(GtxGroupButtonClass *klass)
{
    //GTK_WIDGET_CLASS(klass)->size_request = gtx_group_button_class_widget_size_request;
    //GTK_WIDGET_CLASS(klass)->size_allocate = gtx_group_button_class_widget_size_allocate;
    //klass->parent_class.
}

static void
gtx_group_button_init (GtxGroupButton *object)
{
    gtk_orientable_set_orientation (GTK_ORIENTABLE (object),
                                    GTK_ORIENTATION_HORIZONTAL);
}

GtkWidget*
gtx_group_button_new (gboolean homogeneous, gint spacing)
{
    GtkWidget *widget = g_object_new (GTX_TYPE_GROUP_BUTTON,
                                           "spacing",     spacing,
                                           "homogeneous", homogeneous ? TRUE : FALSE,
                                           NULL);
    return widget;
}

