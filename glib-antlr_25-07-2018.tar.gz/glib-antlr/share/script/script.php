
$mistakes = `echo "norzbibbit flagnbaggel koolalalooper" | {$this->aspell_path} list`;
echo "Escaped \" \\.";
