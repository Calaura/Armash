/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-token.h
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __ANTLR_TOKEN_FACTORY_H__
#define __ANTLR_TOKEN_FACTORY_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_TOKEN_FACTORY                (antlr_token_factory_get_type ())
#define ANTLR_TOKEN_FACTORY(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_TOKEN_FACTORY, AntlrTokenFactory))
#define ANTLR_IS_TOKEN_FACTORY(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_TOKEN_FACTORY))
#define ANTLR_TOKEN_FACTORY_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst), ANTLR_TYPE_TOKEN_FACTORY, AntlrTokenFactoryInterface))

typedef struct _AntlrTokenFactoryInterface AntlrTokenFactoryInterface;

/**
 * AntlrTokenFactoryInterface:
 * @create: Create
 * @create_from: Create
 *
 * The default mechanism for creating tokens. It's used by default in Lexer and
 *  the error handling strategy (to create missing tokens).  Notifying the parser
 *  of a new factory means that it notifies it's token source and error strategy.
 */
struct _AntlrTokenFactoryInterface
{
    /*< private >*/
    AntlrIntStreamInterface parent_iface;

    /*< public >*/
    AntlrSymbole *(*create)           (AntlrTokenFactory *self, AntlrSource source, gint type, gchar *text, gint channel, gint start, gint stop, gint line, gint char_position_in_line);
    AntlrSymbole *(*create_from)      (AntlrTokenFactory *self, gint type, gchar *text);

};

GType antlr_token_factory_get_type (void) G_GNUC_CONST;

AntlrSymbole *antlr_token_factory_create(AntlrTokenFactory *self, AntlrSource source, gint type, gchar *text, gint channel, gint start, gint stop, gint line, gint char_position_in_line);
AntlrSymbole *antlr_token_factory_create_from(AntlrTokenFactory *self, gint type, gchar *text);

G_END_DECLS

#endif // __ANTLR_TOKEN_FACTORY_H__
