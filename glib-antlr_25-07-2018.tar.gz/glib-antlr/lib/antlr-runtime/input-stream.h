/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-token.h
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _ANTLR_INPUT_STREAM_H_
#define _ANTLR_INPUT_STREAM_H_

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_INPUT_STREAM_READ_BUFFER_SIZE 1024
#define ANTLR_INPUT_STREAM_INITIAL_BUFFER_SIZE 1024


#define ANTLR_TYPE_INPUT_STREAM             (antlr_input_stream_get_type ())
#define ANTLR_INPUT_STREAM(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_INPUT_STREAM, AntlrInputStream))
#define ANTLR_INPUT_STREAM_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_INPUT_STREAM, AntlrInputStreamClass))
#define ANTLR_IS_INPUT_STREAM(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_INPUT_STREAM))
#define ANTLR_IS_INPUT_STREAM_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_INPUT_STREAM))
#define ANTLR_INPUT_STREAM_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_INPUT_STREAM, AntlrInputStreamClass))


typedef struct _AntlrInputStream        AntlrInputStream;
typedef struct _AntlrInputStreamClass   AntlrInputStreamClass;
typedef struct _AntlrInputStreamPrivate AntlrInputStreamPrivate;

/**
 * AntlrInputStream:
 * @data: The data being scanned
 * @n: How many characters are actually in the buffer
 * @p: 0..n-1 index into string of next char
 * @name: What is name or source of this char stream?
 *
 * Vacuum all input from a Reader/InputStream and then treat it
 * like a char[] buffer. Can also pass in a String or
 * char[] to use.
 *
 * If you need encoding, pass in stream/reader with correct encoding.
 */
struct _AntlrInputStream
{
    AntlrObject parent_instance;

    /*< public >*/
    gchar *name;
    gchar* data;
    gsize n;
    gint p;

};


struct _AntlrInputStreamClass
{
    AntlrObjectClass parent_class;
};

GType antlr_input_stream_get_type (void) G_GNUC_CONST;

AntlrInputStream *antlr_input_stream_new(void);

/**
 * antlr_input_stream_new_from_string:
 * @input: The string
 *
 * Copy data in string to a local char array
 */
AntlrInputStream *antlr_input_stream_new_from_string (const gchar *input);

AntlrInputStream *antlr_input_stream_new_from_data (gchar *data, int number_of_actual_chars_in_array);

/**
 * antlr_input_stream_reset:
 * @input_stream: Some #AntlrInputStream
 *
 * Reset the stream so that it's in the same state it was
 *  when the object was created *except* the data array is not
 *  touched.
 *
 */
void antlr_input_stream_reset (AntlrInputStream *input_stream);
gint antlr_input_stream_LT(AntlrInputStream *input_stream, gint i);


G_END_DECLS

#endif /* _ANTLR_INPUT_STREAM_H_ */
