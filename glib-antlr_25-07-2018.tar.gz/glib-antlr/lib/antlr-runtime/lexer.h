/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-lexer.h
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _ANTLR_LEXER_H_
#define _ANTLR_LEXER_H_

#include <glib-object.h>

G_BEGIN_DECLS

/**
 * ANTLR_LEXER_DEFAULT_MODE:
 *
 * Default mode : 0
 */
#define ANTLR_LEXER_DEFAULT_MODE 0
#define ANTLR_LEXER_MORE -2
#define ANTLR_LEXER_SKIP -3
#define DEFAULT_TOKEN_CHANNEL ANTLR_TOKEN_DEFAULT_CHANNEL
#define DEFAULT_HIDDEN ANTLR_TOKEN_HIDDEN_CHANNEL
#define DEFAULT_MIN_CHAR_VALUE '\u0000'
#define DEFAULT_MAX_CHAR_VALUE '\uFFFE'


#define ANTLR_TYPE_LEXER             (antlr_lexer_get_type ())
#define ANTLR_LEXER(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_LEXER, AntlrLexer))
#define ANTLR_LEXER_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_LEXER, AntlrLexerClass))
#define ANTLR_IS_LEXER(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_LEXER))
#define ANTLR_IS_LEXER_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_LEXER))
#define ANTLR_LEXER_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_LEXER, AntlrLexerClass))

typedef struct _AntlrLexerClass AntlrLexerClass;

struct _AntlrLexerClass
{
    AntlrRecognizerClass parent_class;

    AntlrToken*  (*lexer_emit)(AntlrLexer *self);
};


/**
 * AntlrLexer:
 * @input: The input
 * @token_factory_source: The token factory source
 * @factory: How to create token objects
 * @token: The goal of all lexer rules/methods is to create a token object.
 *  This is an instance variable as multiple rules may collaborate to
 *  create a single token.  nextToken will return this object after
 *  matching lexer rule(s).  If you subclass to allow multiple token
 *  emissions, then set this to the last token to be matched or
 *  something nonnull so that the auto token emit mechanism will not
 *  emit another token.
 * @token_start_char_index: What character index in the stream did the current token start at?
 *  Needed, for example, to get the text for current token.  Set at
 *  the start of nextToken.
 * @token_start_line: The line on which the first character of the token resides
 * @token_start_char_position_in_line: The character position of first character within the line
 * @hit_EOF: Once we see EOF on char stream, next token will be EOF.
 *  If you have DONE : EOF ; then you see DONE EOF.
 * @channel: The channel number for the current token
 * @type: The token type for the current token
 * @mode_stack: The mode Stack
 * @mode: The mode
 * @text: You can set the text for the current token to override what is in
 *  the input char buffer.  Use setText() or can set this instance var.
 *
 */
struct _AntlrLexer
{
    /* <private> */
    AntlrRecognizer parent_instance;

    /* <public> */
    AntlrCharStream *input;

    AntlrSource token_factory_source;// Pair<TokenSource, CharStream>
    AntlrTokenFactory *factory;// = CommonTokenFactory.DEFAULT;
    AntlrToken *token;
    gint token_start_char_index;// = -1;
    gint token_start_line;
    gint token_start_char_position_in_line;
    gboolean hit_EOF;
    gint channel;
    gint type;
    AntlrIntegerStack *mode_stack;// = new IntegerStack();
    gint mode;// = Lexer.DEFAULT_MODE;
    GString *text;
};


GType antlr_lexer_get_type (void) G_GNUC_CONST;

AntlrLexer *antlr_lexer_new (void);
AntlrLexer *antlr_lexer_super_with_char_stream (GType type, AntlrCharStream *char_stream);
AntlrLexer *antlr_lexer_new_from_char_stream (AntlrCharStream *char_stream);

void   antlr_lexer_set_line(AntlrLexer *self, gint line);
void   antlr_lexer_set_char_position_in_line(AntlrLexer *self, gint char_position_in_line);
gint   antlr_lexer_get_char_index(AntlrLexer *self);

gchar *antlr_lexer_get_text(AntlrLexer *self);
void   antlr_lexer_set_text(AntlrLexer *self, gchar *text);

AntlrToken *antlr_lexer_get_token(AntlrLexer *self);
void        antlr_lexer_set_token(AntlrLexer *self, AntlrToken *token);
void        antlr_lexer_set_lexer_type(AntlrLexer *self, gint ttype);
gint        antlr_lexer_get_lexer_type(AntlrLexer *self);

void        antlr_lexer_set_channel(AntlrLexer *self, gint channel);
gint        antlr_lexer_get_channel(AntlrLexer *self);
GString   **antlr_lexer_get_mode_names(AntlrLexer *self);

void        antlr_lexer_mode(AntlrLexer *self, gint mode);
void        antlr_lexer_skip(AntlrLexer *self);
void        antlr_lexer_more(AntlrLexer *self);

void        antlr_lexer_recover(AntlrLexer *self, GError**error);
void        antlr_lexer_notify_listeners(AntlrLexer *self, GError**error);

void        antlr_lexer_push_mode(AntlrLexer *self, gint m);
gint        antlr_lexer_pop_mode(AntlrLexer *self);

gint        antlr_lexer_get_lexer_type(AntlrLexer *self);
void        antlr_lexer_set_lexer_type(AntlrLexer *self, gint ttype);

AntlrToken *antlr_lexer_emit(AntlrLexer *self);
AntlrToken *antlr_lexer_emit_eof(AntlrLexer *lexer);
void        antlr_lexer_emit_with_token(AntlrLexer *self, AntlrToken *token);

G_END_DECLS

#endif /* _ANTLR_LEXER_H_ */

