/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-token.c
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>
#include <string.h>

#include "types.h"


#include "misc/object.h"
#include "misc/interval.h"
#include "int-stream.h"
#include "char-stream.h"
#include "input-stream.h"

/**
 * SECTION:input-stream
 * @title: AntlrInputStream
 * @short_description: Input stream
 * @stability: Unstable
 * @see_also: #AntlrFileStream
 *
 *
 * This implementation of #AntlrTokenStream loads tokens from a
 * #AntlrTokenSource on-demand, and places the tokens in a buffer to provide
 * access to any previous token by index.
 *
 * This token stream ignores the value of #antlr_token_get_channel. If your
 * parser requires the token stream filter tokens to only those on a particular
 * channel, such as %ANTLR_TOKEN_DEFAULT_CHANNEL or
 * %ANTLR_TOKEN_HIDDEN_CHANNEL, use a filtering token stream such a
 * #AntlrCommonTokenStream.
 */

/* interface IntStream */
static void antlr_input_stream_interface_int_stream_consume(AntlrIntStream *int_stream);
static gint antlr_input_stream_interface_int_stream_LA(AntlrIntStream *int_stream, gint i);
static gint antlr_input_stream_interface_int_stream_mark(AntlrIntStream *stream);
static void antlr_input_stream_interface_int_stream_release(AntlrIntStream *input_stream, gint marker);
static gint antlr_input_stream_interface_int_stream_index(AntlrIntStream *int_stream);
static void antlr_input_stream_interface_int_stream_seek(AntlrIntStream *int_stream, gint index);
static gint antlr_input_stream_interface_int_stream_size(AntlrIntStream *int_stream);
static gchar *antlr_input_stream_interface_int_stream_get_source_name(AntlrIntStream *int_stream);
/* interface CharStream */
static char* antlr_input_stream_interface_char_stream_get_text(AntlrCharStream *char_stream, AntlrInterval *interval);


static void antlr_input_stream_int_stream_interface_init (AntlrIntStreamInterface *iface);
static void antlr_input_stream_char_stream_interface_init (AntlrCharStreamInterface *iface);

G_DEFINE_TYPE_WITH_CODE (AntlrInputStream, antlr_input_stream, ANTLR_TYPE_OBJECT,
                         G_IMPLEMENT_INTERFACE (ANTLR_TYPE_INT_STREAM,
                                                antlr_input_stream_int_stream_interface_init)
                         G_IMPLEMENT_INTERFACE (ANTLR_TYPE_CHAR_STREAM,
                                                antlr_input_stream_char_stream_interface_init))

static void
antlr_input_stream_int_stream_interface_init (AntlrIntStreamInterface *iface)
{
    /* add properties and signals to the interface here */
    iface->consume = antlr_input_stream_interface_int_stream_consume;
    iface->LA = antlr_input_stream_interface_int_stream_LA;
    iface->mark = antlr_input_stream_interface_int_stream_mark;
    iface->release = antlr_input_stream_interface_int_stream_release;
    iface->index = antlr_input_stream_interface_int_stream_index;
    iface->seek = antlr_input_stream_interface_int_stream_seek;
    iface->size = antlr_input_stream_interface_int_stream_size;
    iface->get_source_name = antlr_input_stream_interface_int_stream_get_source_name;
}


static void
antlr_input_stream_char_stream_interface_init (AntlrCharStreamInterface *iface)
{
    /* add properties and signals to the interface here */
    iface->get_text = antlr_input_stream_interface_char_stream_get_text;
}

static gint
antlr_input_stream_interface_int_stream_LA(AntlrIntStream *int_stream, gint i)
{
    AntlrInputStream *input_stream = ANTLR_INPUT_STREAM(int_stream);
    if ( i==0 ) {
        return 0; // undefined
    }
    if ( i<0 ) {
        i++; // e.g., translate LA(-1) to use offset i=0; then data[p+0-1]
        if ( (input_stream->p+i-1) < 0 ) {
            return ANTLR_INT_STREAM_EOF; // invalid; no char before first char
        }
    }

    if ( (input_stream->p+i-1) >= input_stream->n ) {
        //g_print("char LA(%d)=EOF; p=%d\n", i, input_stream->p);
        return ANTLR_INT_STREAM_EOF;
    }

    //System.out.println("char LA("+i+")="+(char)data[p+i-1]+"; p="+p);
    //System.out.println("LA("+i+"); p="+p+" n="+n+" data.length="+data.length);
    return input_stream->data[input_stream->p+i-1];
}
static void
antlr_input_stream_interface_int_stream_consume(AntlrIntStream *int_stream) {
    AntlrInputStream *input_stream = ANTLR_INPUT_STREAM(int_stream);
    if (input_stream->p >= input_stream->n) {
        gint la = antlr_int_stream_LA(int_stream, 1);
        g_assert(la == ANTLR_INT_STREAM_EOF);
        g_error_new(g_quark_from_string("ANTLR"), 700, "Error::IllegalState: %s", "cannot consume EOF");
    }

    //g_print("prev p=%d, c=%s\n", input_stream->p, input_stream->data[input_stream->p]);
    if ( input_stream->p < input_stream->n ) {
        input_stream->p++;
        //g_print("p moves to %d (c='%c')\n", input_stream->p, input_stream->data[input_stream->p]);
    }

}

/**
 * antlr_input_stream_interface_int_stream_index:
 * @int_stream: Some #AntlrIntStream
 *
 * Return the current input symbol index 0..n where n indicates the
 *  last symbol has been read.  The index is the index of char to
 *  be returned from LA(1).
 */
static gint
antlr_input_stream_interface_int_stream_index(AntlrIntStream *int_stream) {
    AntlrInputStream *input_stream = ANTLR_INPUT_STREAM(int_stream);
    return input_stream->p;
}

/**
 * antlr_input_stream_interface_int_stream_mark:
 * @int_stream: Some #AntlrIntStream
 *
 * mark/release do nothing; we have entire buffer
 */
static gint
antlr_input_stream_interface_int_stream_mark(AntlrIntStream *stream) {
    return -1;
}

static void
antlr_input_stream_interface_int_stream_release(AntlrIntStream *input_stream, gint marker) {

}
/**
 * antlr_input_stream_interface_int_stream_seek:
 * @int_stream: Some #AntlrIntStream
 * @index: The index
 *
 * consume() ahead until p==index; can't just set p=index as we must
 *  update line and charPositionInLine. If we seek backwards, just set p
 */
static void
antlr_input_stream_interface_int_stream_seek(AntlrIntStream *int_stream, gint index) {
    AntlrInputStream *input_stream = ANTLR_INPUT_STREAM(int_stream);
    if ( index<=input_stream->p ) {
        input_stream->p = index; // just jump; don't update stream state (line, ...)
        return;
    }
    // seek forward, consume until p hits index or n (whichever comes first)
    index = MIN(index, input_stream->n);
    while ( input_stream->p<index ) {
        antlr_int_stream_consume(int_stream);
    }
}

static gint
antlr_input_stream_interface_int_stream_size(AntlrIntStream *int_stream) {
    AntlrInputStream *input_stream = ANTLR_INPUT_STREAM(int_stream);
    return input_stream->n;
}



static char*
antlr_input_stream_interface_char_stream_get_text(AntlrCharStream *char_stream, AntlrInterval *interval) {
    AntlrInputStream *input_stream = ANTLR_INPUT_STREAM(char_stream);

    gint start = interval->a;
    gint stop = interval->b;
    gint n = input_stream->n;
    if ( stop >= n )
        stop = n-1;
    int count = stop - start + 1;
    if ( start >= n )
        return g_strdup("");

    return g_strndup(input_stream->data+start, count);
}


static gchar*
antlr_input_stream_interface_int_stream_get_source_name(AntlrIntStream *int_stream) {
    AntlrInputStream *input_stream = ANTLR_INPUT_STREAM(int_stream);

    if (input_stream->name == NULL || !strlen(input_stream->name)) {
        return g_strdup(ANTLR_INT_STREAM_UNKNOWN_SOURCE_NAME);
    }

    return g_strdup(input_stream->name);
}

static void
antlr_input_stream_init (AntlrInputStream *input_stream)
{
    //antlr_token->priv = G_TYPE_INSTANCE_GET_PRIVATE (antlr_token, ANTLR_TYPE_TOKEN, AntlrTokenPrivate);

    /* TODO: Add initialization code here */
    input_stream->data = NULL;
    input_stream->n = 0;
    input_stream->name = NULL;
    input_stream->p = 0;
}

static void
antlr_input_stream_finalize (GObject *object)
{
    /* TODO: Add deinitalization code here */
    AntlrInputStream *input_stream = ANTLR_INPUT_STREAM(object);
    if (input_stream->data) {
        g_free(input_stream->data);
        input_stream->data = NULL;
    }
    if (input_stream->name) {
        g_free(input_stream->name);
        input_stream->name = NULL;
    }

    G_OBJECT_CLASS (antlr_input_stream_parent_class)->finalize (object);
}

static void
antlr_input_stream_class_init (AntlrInputStreamClass *klass)
{
    GObjectClass* object_class = G_OBJECT_CLASS (klass);

    //g_type_class_add_private (klass, sizeof (AntlrInputStreamPrivate));

    object_class->finalize = antlr_input_stream_finalize;
}


AntlrInputStream*
antlr_input_stream_new ()
{
    AntlrInputStream *input_stream;
    input_stream = g_object_new(ANTLR_TYPE_INPUT_STREAM, NULL);
    return input_stream;
}

/**
 * antlr_input_stream_new_from_string:
 * @input: The string
 *
 * Copy data in string to a local char array
 *
 */
AntlrInputStream*
antlr_input_stream_new_from_string (const gchar *input)
{
    AntlrInputStream *input_stream;

    input_stream = g_object_new(ANTLR_TYPE_INPUT_STREAM, NULL);
    input_stream->data = g_strdup(input);
    input_stream->n = strlen(input);
//    this.data = input.toCharArray();
//    this.n = input.length();

    return input_stream;
}

//AntlrInputStream*
//antlr_input_stream_new_from_reader (AntlrReader *reader)
//{
//    AntlrInputStream *input_stream;
//    input_stream = g_object_new(ANTLR_TYPE_INPUT_STREAM, NULL);
//    return input_stream;
//}

//public ANTLRInputStream(Reader r) throws IOException {
//    this(r, INITIAL_BUFFER_SIZE, READ_BUFFER_SIZE);
//}

//public ANTLRInputStream(Reader r, int initialSize) throws IOException {
//    this(r, initialSize, READ_BUFFER_SIZE);
//}

//public ANTLRInputStream(Reader r, int initialSize, int readChunkSize) throws IOException {
//    load(r, initialSize, readChunkSize);
//}

//public ANTLRInputStream(InputStream input) throws IOException {
//    this(new InputStreamReader(input), INITIAL_BUFFER_SIZE);
//}

//public ANTLRInputStream(InputStream input, int initialSize) throws IOException {
//    this(new InputStreamReader(input), initialSize);
//}

//public ANTLRInputStream(InputStream input, int initialSize, int readChunkSize) throws IOException {
//    this(new InputStreamReader(input), initialSize, readChunkSize);
//}


/**
 * antlr_input_stream_new_from_data:
 * @data: The string data
 * @number_of_actual_chars_in_array: The length of string data
 *
 * This is the preferred constructor for strings as no data is copied
 */
AntlrInputStream*
antlr_input_stream_new_from_data (gchar *data, int number_of_actual_chars_in_array)
{
    AntlrInputStream *input_stream;

    input_stream = g_object_new(ANTLR_TYPE_INPUT_STREAM, NULL);
    input_stream->data = data;
    input_stream->n = number_of_actual_chars_in_array;

    return input_stream;
}

void antlr_input_stream_reset (AntlrInputStream *input_stream)
{
    input_stream->p = 0;
}

gint antlr_input_stream_LT(AntlrInputStream *input_stream, gint i) {
    return antlr_int_stream_LA(ANTLR_INT_STREAM(input_stream), i);
}
