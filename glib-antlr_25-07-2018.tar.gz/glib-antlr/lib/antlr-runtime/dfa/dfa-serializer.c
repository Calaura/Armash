/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dfa-serializer.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/bit-set.h"
#include "../vocabulary.h"
#include "../vocabulary-impl.h"
#include "../atn/semantic-context.h"
#include "../atn/config.h"
#include "../atn/config-set.h"
#include "dfa-state.h"
#include "dfa.h"

#include "dfa-serializer.h"

static gchar *antlr_dfa_serializer_default_get_edge_label(AntlrDFASerializer *self, gint i);

static void antlr_dfa_serializer_class_init(AntlrDFASerializerClass *klass);
static void antlr_dfa_serializer_init(AntlrDFASerializer *gobject);

G_DEFINE_TYPE (AntlrDFASerializer, antlr_dfa_serializer, ANTLR_TYPE_OBJECT)

static void
antlr_dfa_serializer_class_init(AntlrDFASerializerClass *klass)
{
//	GObjectClass *gobject_class;

//	gobject_class = (GObjectClass *) klass;


    klass->get_edge_label = antlr_dfa_serializer_default_get_edge_label;

//	antlr_dfa_serializer_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_dfa_serializer_init (AntlrDFASerializer *object)
{
}

AntlrDFASerializer *
antlr_dfa_serializer_new (void)
{
	return g_object_new (antlr_dfa_serializer_get_type (),
	                     NULL);
}

// @deprecated Use {@link #DFASerializer(DFA, Vocabulary)} instead.
//@Deprecated
//public DFASerializer(DFA dfa, String[] tokenNames) {
//    this(dfa, VocabularyImpl.fromTokenNames(tokenNames));
//}

AntlrDFASerializer *
antlr_dfa_serializer_super_with_vocabulary (GType type, AntlrDFA *dfa, AntlrVocabulary *vocabulary)
{
    AntlrDFASerializer *self;
    self = g_object_new (type, NULL);
    self->dfa = dfa;
    self->vocabulary = vocabulary;

    return self;
}

AntlrDFASerializer *
antlr_dfa_serializer_new_with_vocabulary (AntlrDFA *dfa, AntlrVocabulary *vocabulary)
{
    return antlr_dfa_serializer_super_with_vocabulary(ANTLR_TYPE_DFA_SERIALIZER, dfa, vocabulary);
}

static gchar*
antlr_dfa_serializer_default_get_edge_label(AntlrDFASerializer *self, gint i) {
    return antlr_ivocabulary_get_display_name(ANTLR_IVOCABULARY(self->vocabulary), i-1);
}

gchar*
antlr_dfa_serializer_get_edge_label(AntlrDFASerializer *self, gint i) {
    g_return_val_if_fail(ANTLR_IS_DFA_SERIALIZER(self), NULL);
    return ANTLR_DFA_SERIALIZER_GET_CLASS(self)->get_edge_label(self, i);
}

static gchar*
g1_array_to_string(GArray *array, GFunc func)
{
    gchar *buffer = g_strdup("[");
    gchar *comma = ", ";
    gchar *glue = "";
    gchar *tmp;
    gint i;
    for (i = 0; i < array->len; i++) {
        AntlrPredPrediction *prediction = g_array_index(array, AntlrPredPrediction*, i);
        gchar *str = antlr_pred_prediction_to_string(prediction);
        tmp = buffer;
        buffer = g_strdup_printf("%s%s%s", buffer, glue, str);
        g_free(tmp);
        glue=comma;
    }
    tmp = buffer;
    buffer = g_strdup_printf("%s]", buffer);
    g_free(tmp);

    return buffer;
}

static
gchar*
antlr_dfa_serializer_get_state_string(AntlrDFASerializer *self, AntlrDFAState *s) {
    gint n = s->state_number;
    gchar *glue = s->is_accept_state ? ":" : "";
    gchar *suffix = s->requires_full_context ? "^" : "";

    gchar *tmp = NULL;
    gchar *baseStateStr = g_strdup_printf("%ss%d%s", glue, n, suffix);
    if ( s->is_accept_state ) {
        if ( s->predicates!=NULL ) {
            tmp = baseStateStr;
            gchar *pred = g1_array_to_string(s->predicates, NULL);
            baseStateStr = g_strdup_printf("%s=>%s", tmp, pred);
            g_free(tmp);
            /*
            return baseStateStr + "=>" + Arrays.toString(s->predicates);
    */
        }
        else {
            tmp = baseStateStr;
            baseStateStr = g_strdup_printf("%s=>%d", baseStateStr, s->prediction);
            g_free(tmp);
            return baseStateStr;
        }
    }
    else {
        return baseStateStr;
    }

    /*
    final String baseStateStr = (s.isAcceptState ? ":" : "") + "s" + n + (s.requiresFullContext ? "^" : "");
    if ( s.isAcceptState ) {
        if ( s.predicates!=null ) {
            return baseStateStr + "=>" + Arrays.toString(s.predicates);
        }
        else {
            return baseStateStr + "=>" + s.prediction;
        }
    }
    else {
        return baseStateStr;
    }
    */
    return baseStateStr;
}


gchar*
antlr_dfa_serializer_to_string(AntlrDFASerializer *self) {

    if ( self->dfa->s0==NULL ) return NULL;
    gchar *buf = g_strdup("");
    GList *states = antlr_dfa_get_states(self->dfa);
    GList *it;
    for (it=g_list_first(states); it; it=it->next) {
        AntlrDFAState *s = ANTLR_DFA_STATE(it->data);
        gint i, n = 0;
        if ( s->edges!=NULL )
            n = s->edges->len;
        for (i=0; i<n; i++) {
            AntlrDFAState *t = g_ptr_array_index(s->edges, i);
            if ( t!=NULL && t->state_number != G_MAXINT/*Integer.MAX_VALUE*/ ) {
                gchar *str_label = antlr_dfa_serializer_get_edge_label(self, i);
                gchar *str_state_s = antlr_dfa_serializer_get_state_string(self, s);
                gchar *str_state_t = antlr_dfa_serializer_get_state_string(self, t);
                gchar *tmp = buf;
                buf = g_strdup_printf("%s%s-%s->%s\n", buf, str_state_s, str_label, str_state_t);
                g_free(tmp);
                g_free(str_label);
                g_free(str_state_t);
                g_free(str_state_s);
            }
        }

    }

    g_list_free(states);

    /*
    StringBuilder buf = new StringBuilder();
    List<DFAState> states = dfa.getStates();
    for (DFAState s : states) { // AntlrDFAState *s
        int n = 0;
        if ( s.edges!=null ) n = s.edges.length;
        for (int i=0; i<n; i++) {
            DFAState t = s.edges[i];
            if ( t!=null && t.stateNumber != Integer.MAX_VALUE ) {
                buf.append(getStateString(s));
                String label = getEdgeLabel(i);
                buf.append("-").append(label).append("->").append(getStateString(t)).append('\n');
            }
        }
    }

    String output = buf.toString();
    if ( output.length()==0 ) return null;
    //return Utils.sortLinesInString(output);
    return output;
    */
    return buf;
}
