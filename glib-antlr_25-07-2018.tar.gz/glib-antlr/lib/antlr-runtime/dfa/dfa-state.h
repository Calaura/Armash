/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dfa-state.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_DFA_STATE_H__
#define __ANTLR_DFA_STATE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_DFA_STATE            (antlr_dfa_state_get_type())
#define ANTLR_DFA_STATE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_DFA_STATE, AntlrDFAState))
#define ANTLR_DFA_STATE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_DFA_STATE, AntlrDFAStateClass))
#define ANTLR_IS_DFA_STATE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_DFA_STATE))
#define ANTLR_IS_DFA_STATE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_DFA_STATE))
#define ANTLR_DFA_STATE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_DFA_STATE, AntlrDFAStateClass))

typedef struct _AntlrPredPrediction AntlrPredPrediction;

typedef struct _AntlrDFAStateClass AntlrDFAStateClass;

/**
 * AntlrDFAState:
 * @state_number: The state number
 * @configs: The configs
 * @edges: {@code edges[symbol]} points to target of symbol. Shift up by 1 so (-1)
 *  %ANTLR_TOKEN_EOF maps to {@code edges[0]}.
 * @is_accept_state: Acceptable state
 * @prediction: if accept state, what ttype do we match or alt do we predict?
 *  This is set to #ANTLR_ATN_INVALID_ALT_NUMBER when {@link #predicates}{@code !=null} or
 *  {@link #requiresFullContext}.
 * @lexer_action_executor: The lexer action executor
 * @requires_full_context: Indicates that this state was created during SLL prediction that
 * discovered a conflict between the configurations in the state. Future
 * #antlr_parser_atn_simulator_exec_atn invocations immediately jumped doing
 * full context prediction if this field is true.
 * @predicates: During SLL parsing, this is a list of predicates associated with the
 *  ATN configurations of the DFA state. When we have predicates,
 *  {@link #requiresFullContext} is {@code false} since full context prediction evaluates predicates
 *  on-the-fly. If this is not null, then {@link #prediction} is
 *  #ANTLR_ATN_INVALID_ALT_NUMBER.
 *  We only use these for non-{@link #requiresFullContext} but conflicting states. That
 *  means we know from the context (it's $ or we don't dip into outer
 *  context) that it's an ambiguity not a conflict.
 *  This list is computed by {@link ParserATNSimulator#predicateDFAState}.
 *
 */
struct _AntlrDFAState {
    /*< private >*/
    AntlrObject parent_instance;

    /*< public >*/
    gint state_number;
    AntlrATNConfigSet *configs;
    GPtrArray_AntlrDFAState *edges;
    gboolean is_accept_state;
    gint prediction;
    AntlrLexerActionExecutor *lexer_action_executor;
    gboolean requires_full_context;
    GArray *predicates;// GArray of AntlrPredPrediction
};


struct _AntlrDFAStateClass {
    AntlrObjectClass parent_class;
};

GType          antlr_dfa_state_get_type(void)G_GNUC_CONST;
AntlrDFAState *antlr_dfa_state_new();
AntlrDFAState *antlr_dfa_state_new_with_state (gint state_number);
AntlrDFAState *antlr_dfa_state_new_with_config_set (AntlrATNConfigSet *configs);
GList         *antlr_dfa_state_get_alt_set(AntlrDFAState *self);
//gchar         *antlr_dfa_state_to_string(AntlrDFAState *self);
gboolean       antlr_dfa_state_equals(AntlrDFAState *self, AntlrDFAState *o);
guint          antlr_dfa_state_hash_code(AntlrDFAState *self);

// ----------------------------------------------------------------------------

#define ANTLR_TYPE_PRED_PREDICTION            (antlr_pred_prediction_get_type())
#define ANTLR_PRED_PREDICTION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_PRED_PREDICTION, AntlrPredPrediction))
#define ANTLR_PRED_PREDICTION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_PRED_PREDICTION, AntlrPredPredictionClass))
#define ANTLR_IS_PRED_PREDICTION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_PRED_PREDICTION))
#define ANTLR_IS_PRED_PREDICTION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_PRED_PREDICTION))
#define ANTLR_PRED_PREDICTION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_PRED_PREDICTION, AntlrPredPredictionClass))


typedef struct _AntlrPredPrediction AntlrPredPrediction;
typedef struct _AntlrPredPredictionClass AntlrPredPredictionClass;

struct _AntlrPredPrediction {
    /*< private >*/
    AntlrObject parent_instance;

    /*< public >*/
    AntlrSemanticContext *pred; // never null; at least SemanticContext.NONE
    gint alt;
};
struct _AntlrPredPredictionClass {
    AntlrObjectClass parent_class;
};

GType antlr_pred_prediction_get_type(void)G_GNUC_CONST;
AntlrPredPrediction *antlr_pred_prediction_new(AntlrSemanticContext *pred, gint alt);
gchar               *antlr_pred_prediction_to_string(AntlrPredPrediction *self);

G_END_DECLS

#endif /* __ANTLR_DFA_STATE_H__ */

