/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dfa-state.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/bit-set.h"
#include "../misc/murmur-hash.h"

#include "../atn/semantic-context.h"
#include "../atn/config.h"
#include "../atn/config-set.h"

#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"

#include "../atn/transition.h"
#include "../atn/lexer-action.h"
#include "../atn/atn-state.h"
#include "../atn/decision-state.h"
#include "../atn/lexer-action-executor.h"
#include "../atn/config-set.h"



#include "dfa-state.h"

static gchar* antlr_dfa_state_class_object_to_string(AntlrObject *object);
static void   antlr_dfa_state_class_init(AntlrDFAStateClass *klass);
static void   antlr_dfa_state_init(AntlrDFAState *gobject);

G_DEFINE_TYPE (AntlrDFAState, antlr_dfa_state, ANTLR_TYPE_OBJECT)

static void
antlr_dfa_state_finalize(GObject *object)
{
    /* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (antlr_dfa_state_parent_class)->finalize (object);
}

static void
antlr_dfa_state_dispose(GObject *object)
{
    AntlrDFAState *self = ANTLR_DFA_STATE(object);
    /* TODO: Add deinitalization code here */

    //g_clear_object(&self->configs);

    if (self->edges) {
        //g_ptr_array_set_free_func(self->edges, (GDestroyNotify)g_object_unref);
        g_ptr_array_free(self->edges, TRUE);// clear_func is NULL so no unref of element are call
        self->edges = NULL;
    }
///    if (self->configs) {
///        g_clear_object(&self->configs);
///    }


    G_OBJECT_CLASS (antlr_dfa_state_parent_class)->dispose (object);
}

static void
antlr_dfa_state_class_init(AntlrDFAStateClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->dispose = antlr_dfa_state_dispose;
    gobject_class->finalize = antlr_dfa_state_finalize;

    ANTLR_OBJECT_CLASS(klass)->to_string = antlr_dfa_state_class_object_to_string;
//	antlr_dfa_state_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_dfa_state_init (AntlrDFAState *object)
{
    object->state_number = -1;
    object->configs = NULL;//antlr_atn_config_set_new();
    object->edges = NULL;//g_array_sized_new(FALSE, TRUE, sizeof(AntlrDFAState*), 100);
    object->is_accept_state = FALSE;
    //object->prediction;
    //object->lexer_action_executor;
    //object->requires_full_context;
    object->predicates = NULL;//g_array_new(FALSE, FALSE, sizeof(AntlrPredPrediction*));
}

AntlrDFAState *
antlr_dfa_state_new (void)
{
	return g_object_new (antlr_dfa_state_get_type (),
	                     NULL);
}

AntlrDFAState *
antlr_dfa_state_new_with_state (gint state_number)
{
    AntlrDFAState *state = g_object_new (ANTLR_TYPE_DFA_STATE, NULL);
    state->state_number = state_number;
    return state;
}
AntlrDFAState *
antlr_dfa_state_new_with_config_set (AntlrATNConfigSet *configs)
{
    AntlrDFAState *state = g_object_new (antlr_dfa_state_get_type (), NULL);
    state->configs = configs;
    g_object_ref(state->configs);
    return state;
}

/**
 * antlr_dfa_state_get_alt_set:
 * @self: Some #AntlrDFAState
 *
 * Get the set of all alts mentioned by all ATN configurations in this
 *  DFA state.
 */
GList* //Set<Integer>
antlr_dfa_state_get_alt_set(AntlrDFAState *self) {
    //Set<Integer> alts = new HashSet<Integer>();
    GList *alts = NULL;
    if ( self->configs!=NULL ) {
        GList *it;
        for (it=g_list_first(self->configs->configs); it; it=it->next) {
            AntlrATNConfig *c = it->data;
            alts = g_list_append(alts, GINT_TO_POINTER(c->alt));
        }
    }
    if ( !g_list_length(alts) )
        return NULL;
    return alts;
}

void my_func(gpointer data, gchar **user_data)
{
    gchar *str = antlr_pred_prediction_to_string(data);
    gchar *tmp = *user_data;

    *user_data = g_strdup_printf("%s, %s", *user_data, str);
    g_free(tmp);
    g_free(str);
}


static gchar*
g1_array_to_string(GArray *array, GFunc func)
{
    gchar *buffer = g_strdup("[");
    gchar *comma = ", ";
    gchar *glue = "";
    gchar *tmp;
    gint i;
    for (i = 0; i < array->len; i++) {
        AntlrPredPrediction *prediction = g_array_index(array, AntlrPredPrediction*, i);
        gchar *str = antlr_pred_prediction_to_string(prediction);
        tmp = buffer;
        buffer = g_strdup_printf("%s%s%s", buffer, glue, str);
        g_free(tmp);
        glue=comma;
    }
    tmp = buffer;
    buffer = g_strdup_printf("%s]", buffer);
    g_free(tmp);

    return buffer;
}

static gchar*
antlr_dfa_state_class_object_to_string(AntlrObject *object)
{
    AntlrDFAState *self=ANTLR_DFA_STATE(object);

    gchar *comma=", ";
    gchar *glue="";
    gchar *tmp = antlr_atn_config_set_to_string(self->configs);
    gchar *str = g_strdup_printf("%d:%s", self->state_number, tmp);
    g_free(tmp);

    if ( self->is_accept_state ) {
        tmp = str;
        str = g_strdup_printf("%s=>", str);
        g_free(tmp);

        if ( self->predicates!=NULL ) {
            gchar *pred = g1_array_to_string(self->predicates, (GFunc)my_func);
            //buf.append(Arrays.toString(predicates));
            tmp = str;
            str = g_strdup_printf("%s%s", str, pred);
            g_free(tmp);
            g_free(pred);
        }
        else {
            tmp = str;
            str = g_strdup_printf("%s%d", str, self->prediction);
            g_free(tmp);
        }
    }
    return str;
}

gboolean
antlr_dfa_state_equals(AntlrDFAState *self, AntlrDFAState *o) {
    // compare set of ATN configurations in this set with other
    if ( self==o ) return TRUE;

    if (!ANTLR_IS_DFA_STATE(o)) {
        return FALSE;
    }

    AntlrDFAState *other = ANTLR_DFA_STATE(o);
    // TODO (sam): what to do when configs==null?
    gboolean sameSet = antlr_atn_config_set_equals(self->configs, other->configs);
//		System.out.println("DFAState.equals: "+configs+(sameSet?"==":"!=")+other.configs);
    return sameSet;
}

guint
antlr_dfa_state_hash_code(AntlrDFAState *self) {
    gint hash = antlr_murmur_hash_initialize(7);
    gint hash_configs = antlr_atn_config_set_hash_code(self->configs);
    hash = antlr_murmur_hash_update(hash, hash_configs);
    hash = antlr_murmur_hash_finish(hash, 1);
    return hash;
}

// ----------------------------------------------------------------------------

static void antlr_pred_prediction_class_init(AntlrPredPredictionClass *klass);
static void antlr_pred_prediction_init(AntlrPredPrediction *gobject);

G_DEFINE_TYPE (AntlrPredPrediction, antlr_pred_prediction, ANTLR_TYPE_OBJECT)

static void
antlr_pred_prediction_class_init(AntlrPredPredictionClass *klass)
{
//    GObjectClass *gobject_class;

//    gobject_class = (GObjectClass *) klass;

//    antlr_pred_prediction_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_pred_prediction_init (AntlrPredPrediction *object)
{
    object->pred = ANTLR_SEMANTIC_CONTEXT_NONE; // never null; at least SemanticContext.NONE
    object->alt = -1;
}

AntlrPredPrediction*
antlr_pred_prediction_new(AntlrSemanticContext *pred, gint alt) {
    AntlrPredPrediction* self= g_object_new(ANTLR_TYPE_PRED_PREDICTION, NULL);
    self->alt = alt;
    self->pred = pred;
    return self;
}

gchar*
antlr_pred_prediction_to_string(AntlrPredPrediction *self) {
    return g_strdup_printf("(%s, %d)", antlr_object_to_string(ANTLR_OBJECT(self->pred)), self->alt);
}
