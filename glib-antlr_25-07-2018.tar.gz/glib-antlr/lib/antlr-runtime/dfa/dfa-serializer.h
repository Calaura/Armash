/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * dfa-serializer.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_DFA_SERIALIZER_H__
#define __ANTLR_DFA_SERIALIZER_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_DFA_SERIALIZER            (antlr_dfa_serializer_get_type())
#define ANTLR_DFA_SERIALIZER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_DFA_SERIALIZER, AntlrDFASerializer))
#define ANTLR_DFA_SERIALIZER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_DFA_SERIALIZER, AntlrDFASerializerClass))
#define ANTLR_IS_DFA_SERIALIZER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_DFA_SERIALIZER))
#define ANTLR_IS_DFA_SERIALIZER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_DFA_SERIALIZER))
#define ANTLR_DFA_SERIALIZER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_DFA_SERIALIZER, AntlrDFASerializerClass))

typedef struct _AntlrDFASerializer AntlrDFASerializer;
typedef struct _AntlrDFASerializerClass AntlrDFASerializerClass;

/**
 * AntlrDFASerializer:
 *
 * A DFA walker that knows how to dump them to serialized strings.
 */
struct _AntlrDFASerializer {
	AntlrObject parent_instance;

    /*< private >*/
    AntlrDFA *dfa;
    AntlrVocabulary *vocabulary;
};

struct _AntlrDFASerializerClass {
    GObjectClass  parent_class;
    gchar*      (*get_edge_label)(AntlrDFASerializer *self, gint i);
};

GType antlr_dfa_serializer_get_type(void)G_GNUC_CONST;
AntlrDFASerializer *antlr_dfa_serializer_new();
AntlrDFASerializer *antlr_dfa_serializer_new_with_vocabulary (AntlrDFA *dfa, AntlrVocabulary *vocabulary);
AntlrDFASerializer *antlr_dfa_serializer_super_with_vocabulary (GType type, AntlrDFA *dfa, AntlrVocabulary *vocabulary);
gchar              *antlr_dfa_serializer_to_string(AntlrDFASerializer *self);

G_END_DECLS

#endif /* __ANTLR_DFA_SERIALIZER_H__ */

