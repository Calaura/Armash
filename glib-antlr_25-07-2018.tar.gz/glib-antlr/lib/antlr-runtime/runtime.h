/*
 * rule-node.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_RUNTIME_H__
#define __ANTLR_RUNTIME_H__


#include <glib-object.h>


#include "antlr-runtime/types.h"

#include "antlr-runtime/misc/object.h"

#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/input-stream.h"
#include "antlr-runtime/file-stream.h"
#include "antlr-runtime/char-stream.h"
#include "antlr-runtime/token-stream.h"
#include "antlr-runtime/buffered-token-stream.h"
#include "antlr-runtime/common-token-stream.h"

#include "antlr-runtime/misc/bit-set.h"
#include "antlr-runtime/misc/int-iset.h"
#include "antlr-runtime/misc/interval.h"
#include "antlr-runtime/vocabulary.h"
#include "antlr-runtime/vocabulary-impl.h"
#include "antlr-runtime/misc/interval-set.h"
#include "antlr-runtime/misc/integer-list.h"
#include "antlr-runtime/misc/integer-stack.h"
#include "antlr-runtime/atn/transition.h"
#include "antlr-runtime/atn/lexer-action.h"
#include "antlr-runtime/atn/atn-state.h"
#include "antlr-runtime/atn/rule-stop-state.h"
#include "antlr-runtime/atn/rule-start-state.h"
#include "antlr-runtime/atn/atn.h"
#                                               include "antlr-runtime/atn/semantic-context.h"
#                                               include "antlr-runtime/atn/config.h"
#                                               include "antlr-runtime/atn/config-set.h"
#include "antlr-runtime/atn/prediction-context.h"
#include "antlr-runtime/atn/prediction-context-cache.h"
#include "antlr-runtime/atn/singleton-prediction-context.h"
#include "antlr-runtime/atn/empty-prediction-context.h"
#include "antlr-runtime/atn/array-prediction-context.h"
#include "antlr-runtime/atn/atn-simulator.h"

#include "antlr-runtime/dfa/dfa.h"
#include "antlr-runtime/dfa/dfa-state.h"

#include "antlr-runtime/tree/tree.h"
#include "antlr-runtime/tree/syntax-tree.h"
#include "antlr-runtime/tree/parse-tree.h"
#include "antlr-runtime/tree/terminal-node.h"
#include "antlr-runtime/tree/error-node.h"
#include "antlr-runtime/tree/parse-tree-listener.h"
#include "antlr-runtime/tree/parse-tree-walker.h"
#include "antlr-runtime/rule-context.h"
#include "antlr-runtime/parser-rule-context.h"
#include "antlr-runtime/token.h"
#include "antlr-runtime/token-source.h"

#include "antlr-runtime/recognizer.h"
#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/token-factory.h"
#include "antlr-runtime/lexer.h"
#include "antlr-runtime/parser.h"


#endif /* __ANTLR_RUNTIME_H__ */

