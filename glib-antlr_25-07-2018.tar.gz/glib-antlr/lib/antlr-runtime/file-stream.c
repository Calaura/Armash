/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-file_stream.c
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "types.h"

#include "misc/object.h"

#include "int-stream.h"
#include "input-stream.h"
#include "file-stream.h"

#include <string.h>

/**
 * SECTION:file-stream
 * @title: AntlrFileStream
 * @short_description: File stream
 * @see_also: #AntlrInputStream
 *
 * This is an #AntlrInputStream that is loaded from a file all at once when you construct the object.
 *
 */

static void antlr_file_stream_interface_int_stream_init(AntlrIntStreamInterface *iface);

G_DEFINE_TYPE_WITH_CODE (AntlrFileStream, antlr_file_stream, ANTLR_TYPE_INPUT_STREAM,
                         G_IMPLEMENT_INTERFACE(ANTLR_TYPE_INT_STREAM, antlr_file_stream_interface_int_stream_init)
                         )


static void
antlr_file_stream_init (AntlrFileStream *antlr_file_stream)
{
    /* TODO: Add initialization code here */
    antlr_file_stream->filename = NULL;
}

static void
antlr_file_stream_finalize (GObject *object)
{
    AntlrFileStream *file_stream = ANTLR_FILE_STREAM(object);

    if (file_stream->filename) {
        g_free(file_stream->filename);
    }

    G_OBJECT_CLASS (antlr_file_stream_parent_class)->finalize (object);
}

static gchar*
antlr_file_stream_interface_int_stream_get_source_name(AntlrIntStream *int_stream)
{
    AntlrFileStream *file_stream = ANTLR_FILE_STREAM(int_stream);
    if (! file_stream->filename) {
        return NULL;
    }
    return g_strdup(file_stream->filename);
}

static void
antlr_file_stream_interface_int_stream_init(AntlrIntStreamInterface *iface)
{
    iface->get_source_name = antlr_file_stream_interface_int_stream_get_source_name;
}

static void
antlr_file_stream_class_init (AntlrFileStreamClass *klass)
{
    GObjectClass* object_class = G_OBJECT_CLASS (klass);

    object_class->finalize = antlr_file_stream_finalize;
}

/**
 * antlr_file_stream_new_from_filename_encoding:
 * @filename: (type filename) :The name of file to read, in the GLib file name encoding.
 * @encoding: Not used
 * @error: return location for a #GError, or %NULL
 *
 * Reads an entire file with good error checking.
 * If the call was successful, it returns a #AntlrFileStream instance and
 * sets AntlrInputStream.data to the file contents and
 * AntlrInputStream.n to the length of the file contents in bytes.
 * If the call was not successful, it returns NULL and sets error.
 * The error domain is G_FILE_ERROR.
 * Possible error codes are those in the GFileError enumeration.
 * In the error case, AntlrInputStream.data is set to NULL and AntlrInputStream.n is set to zero.
 *
 * |[<!-- language="C" -->
 * GError *error = NULL;
 * AntlrFileStream *file_stream = antlr_file_stream_new_from_filename_encoding("script.sql", NULL, &error);
 * if (!file_stream) {
 *   g_print("%s\n", error->message);
 *   g_clear_error(error);
 * }
 *
 * ]|
 *
 * Returns: Some #AntlrFileStream instance, %NULL if an error occurred
 */
AntlrFileStream*
antlr_file_stream_new_from_filename_encoding (const gchar *filename, const gchar *encoding, GError **error)
{
    g_return_val_if_fail (error == NULL || *error == NULL, NULL);

    AntlrFileStream *file_stream;
    file_stream = g_object_new(ANTLR_TYPE_FILE_STREAM, NULL);

    if (! antlr_file_stream_load (file_stream, filename, encoding, error)) {
        g_object_unref(file_stream);
        file_stream = NULL;// g_clear_object(&file_stream);
    }

    return file_stream;
}

gboolean
antlr_file_stream_load (AntlrFileStream *file_stream, const gchar *filename, const gchar *encoding, GError **error)
{
    g_return_val_if_fail (error == NULL || *error == NULL, NULL);

    AntlrInputStream *input_stream = ANTLR_INPUT_STREAM(file_stream);

    // Reset
    input_stream->n = 0;
    if (input_stream->data) {
        g_free(input_stream->data);
        input_stream->data = NULL;// g_clear_pointer(&input_stream->data, g_free);
    }
    if (file_stream->filename) {
        g_free(file_stream->filename);
        file_stream->filename = NULL;// g_clear_pointer(&file_stream->filename, g_free);
    }

    gchar *content = NULL;
    gsize  length;

    // todo encoding ...
    gboolean ret = g_file_get_contents (filename,
                                        &content,
                                        &length,
                                        error);

    if (ret) {
        /// TODO: convert #content to encoding "UTF-8"
        // set file contents
        input_stream->data = content;
        input_stream->n = length;

        // set filename
        file_stream->filename = g_strdup(filename);
    }

    return ret;
}
