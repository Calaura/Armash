/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * buffered-token-stream.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_BUFFERED_TOKEN_STREAM_H__
#define __ANTLR_BUFFERED_TOKEN_STREAM_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_BUFFERED_TOKEN_STREAM            (antlr_buffered_token_stream_get_type())
#define ANTLR_BUFFERED_TOKEN_STREAM(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_BUFFERED_TOKEN_STREAM, AntlrBufferedTokenStream))
#define ANTLR_BUFFERED_TOKEN_STREAM_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_BUFFERED_TOKEN_STREAM, AntlrBufferedTokenStreamClass))
#define ANTLR_IS_BUFFERED_TOKEN_STREAM(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_BUFFERED_TOKEN_STREAM))
#define ANTLR_IS_BUFFERED_TOKEN_STREAM_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_BUFFERED_TOKEN_STREAM))
#define ANTLR_BUFFERED_TOKEN_STREAM_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_BUFFERED_TOKEN_STREAM, AntlrBufferedTokenStreamClass))

typedef struct _AntlrBufferedTokenStreamClass AntlrBufferedTokenStreamClass;

struct _AntlrBufferedTokenStream {
    /*< protected >*/
    /*< private >*/
    AntlrObject parent_instance;

    /*< public >*/

    AntlrTokenSource *token_source;

    GPtrArray_AntlrToken *tokens;

    gint p;// = -1;

    gboolean fetched_eof;
};

struct _AntlrBufferedTokenStreamClass {
    AntlrObjectClass parent_class;

    AntlrToken* (*LB)(AntlrBufferedTokenStream *self, gint k);
    gint (*adjust_seek_index)(AntlrBufferedTokenStream *self, gint i);
};

GType antlr_buffered_token_stream_get_type(void)G_GNUC_CONST;
AntlrBufferedTokenStream *antlr_buffered_token_stream_new();
AntlrBufferedTokenStream *antlr_buffered_token_stream_super_with_token_source(GType type, AntlrTokenSource *token_source);
AntlrBufferedTokenStream *antlr_buffered_token_stream_new_with_token_source(AntlrTokenSource *token_source);

gint                      antlr_buffered_token_stream_adjust_seek_index(AntlrBufferedTokenStream *self, gint i);

//GList                    *antlr_buffered_token_stream_get(AntlrBufferedTokenStream *self, gint start, gint stop);
AntlrToken               *antlr_buffered_token_stream_LB(AntlrBufferedTokenStream *self, gint k);


void     antlr_buffered_token_stream_reset(AntlrTokenStream *token_stream);
/*< protected >*/

void antlr_buffered_token_stream_set_token_source(AntlrBufferedTokenStream *self, AntlrTokenSource *token_source);

gint antlr_buffered_token_stream_next_token_on_channel(AntlrBufferedTokenStream *self, gint i, gint channel);

gint antlr_buffered_token_source_previous_token_on_channel(AntlrBufferedTokenStream *self, gint i, gint channel);


void     antlr_buffered_token_stream_lazy_init(AntlrTokenStream *token_stream);
gboolean antlr_buffered_token_stream_sync(AntlrTokenStream *token_stream, gint i);
void     antlr_buffered_token_stream_fill(AntlrBufferedTokenStream *self);

G_END_DECLS

#endif /* __ANTLR_BUFFERED_TOKEN_STREAM_H__ */

