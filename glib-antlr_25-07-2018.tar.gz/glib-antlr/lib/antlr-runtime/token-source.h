/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-token.h
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _ANTLR_TOKEN_SOURCE_H_
#define _ANTLR_TOKEN_SOURCE_H_

#include <glib-object.h>

G_BEGIN_DECLS


#define ANTLR_TYPE_TOKEN_SOURCE                (antlr_token_source_get_type ())
#define ANTLR_TOKEN_SOURCE(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_TOKEN_SOURCE, AntlrTokenSource))
#define ANTLR_IS_TOKEN_SOURCE(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_TOKEN_SOURCE))
#define ANTLR_TOKEN_SOURCE_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst), ANTLR_TYPE_TOKEN_SOURCE, AntlrTokenSourceInterface))

typedef struct _AntlrTokenSourceInterface AntlrTokenSourceInterface;

/**
 * AntlrTokenSourceInterface:
 * @next_token: The description of next_token
 * @get_line: The description of get_line
 * @get_char_position_in_line: The description of get_char_position_in_line
 * @get_input_stream: The description of get_input_stream
 * @get_source_name: The description of get_source_name
 */

struct _AntlrTokenSourceInterface
{
    /*< private >*/
    GTypeInterface parent_iface;

    /*< public >*/
    AntlrToken*        (*next_token)                 (AntlrTokenSource *token_source);
    int                (*get_line)                   (AntlrTokenSource *token_source);
    int                (*get_char_position_in_line)  (AntlrTokenSource *token_source);
    AntlrCharStream*   (*get_input_stream)           (AntlrTokenSource *token_source);
    char*              (*get_source_name)            (AntlrTokenSource *token_source);
    void               (*set_token_factory)          (AntlrTokenSource *token_source, AntlrTokenFactory* factory);
    AntlrTokenFactory* (*get_token_factory)          (AntlrTokenSource *token_source);
};

GType antlr_token_source_get_type (void) G_GNUC_CONST;

/**
 * antlr_token_source_next_token:
 * @token_source: Some #AntlrTokenSource
 *
 * Return a {@link Token} object from your input stream (usually a
 * {@link CharStream}). Do not fail/return upon lexing error; keep chewing
 * on the characters until you get a good one; errors are not passed through
 * to the parser.
 */
AntlrToken* antlr_token_source_next_token (AntlrTokenSource *token_source);

/**
 * antlr_token_source_get_line:
 * @token_source: Some #AntlrTokenSource
 *
 * Get the line number for the current position in the input stream. The
 * first line in the input is line 1.
 *
 * @return The line number for the current position in the input stream, or
 * 0 if the current token source does not track line numbers.
 */
int antlr_token_source_get_line(AntlrTokenSource *token_source);

/**
 * antlr_token_source_get_char_position_in_line:
 * @token_source: Some #AntlrTokenSource
 *
 * Get the index into the current line for the current position in the input
 * stream. The first character on a line has position 0.
 *
 * Returns: The line number for the current position in the input stream, or
 * -1 if the current token source does not track character positions.
 */
int antlr_token_source_get_char_position_in_line(AntlrTokenSource *token_source);

/**
 * antlr_token_source_get_input_stream:
 * @token_source: Some #AntlrTokenSource
 *
 * Get the {@link CharStream} from which this token source is currently
 * providing tokens.
 *
 * Returns: The {@link CharStream} associated with the current position in
 * the input, or %NULL if no input stream is available for the token
 * source.
 */
AntlrCharStream* antlr_token_source_get_input_stream(AntlrTokenSource *token_source);

/**
 * antlr_token_source_get_source_name:
 * @token_source: Some #AntlrTokenSource
 *
 * Gets the name of the underlying input source. This method returns a
 * non-null, non-empty string. If such a name is not known, this method
 * returns %ANTLR_INT_STREAM_UNKNOWN_SOURCE_NAME.
 */
char* antlr_token_source_get_source_name(AntlrTokenSource *token_source);

/**
 * antlr_token_source_set_token_factory:
 * @token_source: Some #AntlrTokenSource
 * @factory: The #AntlrTokenFactory to use for creating tokens.
 *
 * Set the {@link TokenFactory} this token source should use for creating
 * {@link Token} objects from the input.
 *
 */
void antlr_token_source_set_token_factory(AntlrTokenSource *token_source, AntlrTokenFactory* factory);

/**
 * antlr_token_source_get_token_factory:
 * @token_source: Some #AntlrTokenSource
 *
 * Gets the #AntlrTokenFactory this token source is currently using for
 * creating #AntlrToken objects from the input.
 *
 * Returns: The #AntlrTokenFactory currently used by this token source.
 */
AntlrTokenFactory* antlr_token_source_get_token_factory(AntlrTokenSource *token_source);

G_END_DECLS

#endif /* _ANTLR_TOKEN_SOURCE_H_ */
