/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * buffered-token-stream.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "types.h"

#include "misc/object.h"
#include "misc/interval.h"

#include "token.h"
#include "int-stream.h"
#include "token-stream.h"
#include "buffered-token-stream.h"
#include "token-source.h"
#include "common-token.h"
#include "input-stream.h"
#include "file-stream.h"

//#include "atn/config.h"
//#include "atn/config-set.h"
//#include "misc/int-iset.h"

#include "tree/tree.h"
#include "tree/syntax-tree.h"
#include "tree/parse-tree.h"
#include "rule-node.h"
#include "rule-context.h"

//#include "misc/interval-set.h"
//#include "atn/atn-state.h"
//#include "atn/atn.h"
//#include "atn/decision-state.h"
//#include "atn/lexer-action-executor.h"
//#include "dfa/dfa-state.h"
//#include "dfa/dfa.h"
//#include "atn/prediction-context.h"
//#include "atn/prediction-context-cache.h"
//#include "atn/atn-simulator.h"
//#include "atn/lexer-atn-simulator.h"
//#include "recognizer.h"
//#include "lexer.h"
//#include "../php/php-lexer.h"
#include "writable-token.h"



/* interface IntStream */
static gint  antlr_buffered_token_stream_interface_int_stream_LA(AntlrIntStream *int_stream, gint i);
static void antlr_buffered_token_stream_int_stream_interface_consume(AntlrIntStream *int_stream);
static gint antlr_buffered_token_stream_interface_int_stream_index(AntlrIntStream *int_stream);
static gint antlr_buffered_token_stream_interface_int_stream_mark(AntlrIntStream *int_stream);
static void antlr_buffered_token_stream_interface_int_stream_release(AntlrIntStream *int_stream, gint marker);
static void antlr_buffered_token_stream_interface_int_stream_seek(AntlrIntStream *int_stream, gint index);
static gint antlr_buffered_token_stream_interface_int_stream_size(AntlrIntStream *int_stream);

/* interface TokenStream */
static AntlrToken       *antlr_buffered_token_stream_interface_token_stream_get(AntlrTokenStream *token_stream, gint index);
static AntlrTokenSource *antlr_buffered_token_stream_interface_token_stream_get_token_source(AntlrTokenStream *token_stream);
static gchar            *antlr_buffered_token_stream_interface_token_stream_get_text(AntlrTokenStream *token_stream);
static gchar            *antlr_buffered_token_stream_interface_token_stream_get_text_from_interval(AntlrTokenStream *token_stream, AntlrInterval *interval);
static gchar            *antlr_buffered_token_stream_interface_token_stream_get_text_from_context(AntlrTokenStream *token_stream, AntlrRuleContext *ctx);
static gchar            *antlr_buffered_token_stream_interface_token_stream_get_text_from_token(AntlrTokenStream *token_stream, AntlrToken *start, AntlrToken *stop);
static AntlrToken       *antlr_buffered_token_stream_interface_token_stream_LT(AntlrTokenStream *token_stream, gint k);

/* interface BufferedTokenStream */
static AntlrToken       *antlr_buffered_token_stream_class_LB(AntlrBufferedTokenStream *self, gint k);
static gint              antlr_buffered_token_stream_default_adjust_seek_index(AntlrBufferedTokenStream *self, gint i);

/* protected/private BufferedTokenStream */
static gint              antlr_buffered_token_stream_fetch(AntlrBufferedTokenStream *token_stream, gint n);


static void antlr_buffered_token_stream_interface_int_stream_init(AntlrIntStreamInterface *iface);
static void antlr_buffered_token_stream_interface_token_stream_init(AntlrTokenStreamInterface *iface);

static void antlr_buffered_token_stream_class_init(AntlrBufferedTokenStreamClass *klass);
static void antlr_buffered_token_stream_init(AntlrBufferedTokenStream *gobject);


/**
 * SECTION:buffered-token-stream
 * @title: AntlrBufferedTokenStream
 * @short_description: Buffered token stream
 * @stability: Unstable
 * @see_also: #AntlrCommonTokenStream
 *
 *
 * This implementation of #AntlrTokenStream loads tokens from a
 * #AntlrTokenSource on-demand, and places the tokens in a buffer to provide
 * access to any previous token by index.
 *
 * This token stream ignores the value of #antlr_token_get_channel. If your
 * parser requires the token stream filter tokens to only those on a particular
 * channel, such as %ANTLR_TOKEN_DEFAULT_CHANNEL or
 * %ANTLR_TOKEN_HIDDEN_CHANNEL, use a filtering token stream such a
 * #AntlrCommonTokenStream.
 */

/**
 * AntlrBufferedTokenStream:
 * @token_source: The #AntlrTokenSource from which tokens for this stream are fetched.
 * @tokens: collection of all tokens fetched from the token source. The list is
 * considered a complete view of the input once {@link #fetchedEOF} is set
 * to %TRUE.
 * @p: The index into AntlrBufferedTokenStream.tokens of the current token (next token to
 * #antlr_int_stream_consume). AntlrBufferedTokenStream.tokens {@code [}{@link #p}{@code ]} should be
 * #antlr_token_stream_LT(1).
 * This field is set to -1 when the stream is first constructed or when
 * {@link #setTokenSource} is called, indicating that the first token has
 * not yet been fetched from the token source. For additional information,
 * see the documentation of #AntlrIntStream for a description of
 * Initializing Methods.
 * @fetched_eof: Indicates whether the %ANTLR_TOKEN_EOF token has been fetched from
 * {@link #tokenSource} and added to {@link #tokens}. This field improves
 * performance for the following cases:
 * - {@link #consume}: The lookahead check in {@link #consume} to prevent
 * consuming the EOF symbol is optimized by checking the values of
 * {@link #fetchedEOF} and {@link #p} instead of calling #antlr_int_stream_LA.
 * - {@link #fetch}: The check to prevent adding multiple EOF symbols into
 * {@link #tokens} is trivial with this field.
 *
 */

G_DEFINE_TYPE_WITH_CODE (AntlrBufferedTokenStream, antlr_buffered_token_stream, ANTLR_TYPE_OBJECT,
                            G_IMPLEMENT_INTERFACE(ANTLR_TYPE_INT_STREAM, antlr_buffered_token_stream_interface_int_stream_init)
                            G_IMPLEMENT_INTERFACE(ANTLR_TYPE_TOKEN_STREAM, antlr_buffered_token_stream_interface_token_stream_init))

static void
antlr_buffered_token_stream_interface_int_stream_init(AntlrIntStreamInterface *iface)
{
    iface->LA = antlr_buffered_token_stream_interface_int_stream_LA;
    iface->consume = antlr_buffered_token_stream_int_stream_interface_consume;
//    iface->get_source_name = NULL;
    iface->index = antlr_buffered_token_stream_interface_int_stream_index;
    iface->mark = antlr_buffered_token_stream_interface_int_stream_mark;
    iface->release = antlr_buffered_token_stream_interface_int_stream_release;
    iface->seek = antlr_buffered_token_stream_interface_int_stream_seek;
    iface->size = antlr_buffered_token_stream_interface_int_stream_size;
}

static void
antlr_buffered_token_stream_interface_token_stream_init(AntlrTokenStreamInterface *iface)
{
    iface->get = antlr_buffered_token_stream_interface_token_stream_get;

    iface->get_text = antlr_buffered_token_stream_interface_token_stream_get_text;
    iface->get_text_from_context = antlr_buffered_token_stream_interface_token_stream_get_text_from_context;
    iface->get_text_from_interval = antlr_buffered_token_stream_interface_token_stream_get_text_from_interval;
    iface->get_text_from_token = antlr_buffered_token_stream_interface_token_stream_get_text_from_token;

    iface->get_token_source       = antlr_buffered_token_stream_interface_token_stream_get_token_source;
    iface->LT                     = antlr_buffered_token_stream_interface_token_stream_LT;
}


static void
antlr_buffered_token_stream_class_object_dispose(GObject *object)
{
    AntlrBufferedTokenStream *self = ANTLR_BUFFERED_TOKEN_STREAM(object);
    /* TODO: Add deinitalization code here */

    if (self->tokens!=NULL) {
        g_ptr_array_set_free_func(self->tokens, (GDestroyNotify)g_object_unref);
        g_ptr_array_free(self->tokens, TRUE);
        self->tokens = NULL;
    }

    if (G_IS_OBJECT(self->token_source)) {
        g_object_unref(self->token_source);
        self->token_source = NULL;
    }

    G_OBJECT_CLASS (antlr_buffered_token_stream_parent_class)->dispose (object);
}

static void
antlr_buffered_token_stream_finalize(GObject *object)
{
    /* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (antlr_buffered_token_stream_parent_class)->finalize (object);
}

static void
antlr_buffered_token_stream_class_init(AntlrBufferedTokenStreamClass *klass)
{
    G_OBJECT_CLASS(klass)->dispose = antlr_buffered_token_stream_class_object_dispose;
    G_OBJECT_CLASS(klass)->finalize = antlr_buffered_token_stream_finalize;

    klass->LB = antlr_buffered_token_stream_class_LB;
    klass->adjust_seek_index = antlr_buffered_token_stream_default_adjust_seek_index;

//    antlr_buffered_token_stream_parent_class = g_type_class_peek_parent (klass);
}

void
antlr_buffered_token_stream_reset(AntlrTokenStream *token_stream)
{
    antlr_int_stream_seek(ANTLR_INT_STREAM(token_stream), 0);
}

/**
 * antlr_buffered_token_stream_sync:
 * @token_stream: Some #AntlrTokenStream
 * @i: The index
 *
 * Make sure index @i in tokens has a token.
 * see get(int i)
 *
 * Returns: Returns %TRUE if a token is located at index @i, otherwise %FALSE.
 */
gboolean
antlr_buffered_token_stream_sync(AntlrTokenStream *token_stream, gint i) {
    g_assert(i >= 0);
    AntlrBufferedTokenStream *stream = ANTLR_BUFFERED_TOKEN_STREAM(token_stream);

    gint n = i - stream->tokens->len + 1; // how many more elements we need?
    //g_print("sync(%d) needs %d \n", i, n);
    if ( n > 0 ) {
        gint fetched = antlr_buffered_token_stream_fetch(stream, n);
        return fetched >= n;
    }

    return TRUE;
}



static void
antlr_buffered_token_stream_setup(AntlrTokenStream *token_stream) {
    AntlrBufferedTokenStream *stream = ANTLR_BUFFERED_TOKEN_STREAM(token_stream);

    antlr_buffered_token_stream_sync(token_stream, 0);
    stream->p = antlr_buffered_token_stream_adjust_seek_index(stream, 0);
}

void
antlr_buffered_token_stream_lazy_init(AntlrTokenStream *token_stream) {
    AntlrBufferedTokenStream *stream = ANTLR_BUFFERED_TOKEN_STREAM(token_stream);

    if (stream->p == -1) {
        antlr_buffered_token_stream_setup(token_stream);
    }
}


static AntlrToken*
antlr_buffered_token_stream_interface_token_stream_LT(AntlrTokenStream *token_stream, gint k) {
    antlr_buffered_token_stream_lazy_init(token_stream);
    if ( k==0 ) return NULL;
    if ( k < 0 ) return antlr_buffered_token_stream_LB(ANTLR_BUFFERED_TOKEN_STREAM(token_stream), -k);

    int i = ANTLR_BUFFERED_TOKEN_STREAM(token_stream)->p + k - 1;
    antlr_buffered_token_stream_sync(token_stream, i);

    int size = ANTLR_BUFFERED_TOKEN_STREAM(token_stream)->tokens->len;
    if (i >= size) {
        AntlrTokenStream *t = g_ptr_array_index(ANTLR_BUFFERED_TOKEN_STREAM(token_stream)->tokens, size-1);
        return ANTLR_TOKEN(t);
    }

    AntlrToken *token = g_ptr_array_index(ANTLR_BUFFERED_TOKEN_STREAM(token_stream)->tokens, i);
    return token;
}

static AntlrToken*
antlr_buffered_token_stream_interface_token_stream_get(AntlrTokenStream *token_stream, gint index) {
    AntlrBufferedTokenStream *self = ANTLR_BUFFERED_TOKEN_STREAM(token_stream);
    gint size = self->tokens->len;
    if (index<0 || index>= size) {
        //if (error) *error = g_error_new()
        return NULL;
    }
    return g_ptr_array_index(self->tokens, index);
}

static AntlrTokenSource*
antlr_buffered_token_stream_interface_token_stream_get_token_source(AntlrTokenStream *token_stream) {
    AntlrBufferedTokenStream *token = ANTLR_BUFFERED_TOKEN_STREAM(token_stream);
    return token->token_source;
}
static gchar*
antlr_buffered_token_stream_interface_token_stream_get_text(AntlrTokenStream *token_stream) {
    antlr_buffered_token_stream_lazy_init(token_stream);
    antlr_buffered_token_stream_fill(ANTLR_BUFFERED_TOKEN_STREAM(token_stream));

    gint size = antlr_int_stream_size(ANTLR_INT_STREAM(token_stream));
    AntlrInterval *interval = antlr_interval_of(0, size-1);
    return antlr_buffered_token_stream_interface_token_stream_get_text_from_interval(token_stream, interval);
}

static gchar*
antlr_buffered_token_stream_interface_token_stream_get_text_from_interval(AntlrTokenStream *token_stream, AntlrInterval *interval) {
    gint start = interval->a;
    gint stop = interval->b;
    if ( start<0 || stop<0 ) return g_strdup("");
    antlr_buffered_token_stream_lazy_init(token_stream);
    GPtrArray_AntlrToken *tokens = ANTLR_BUFFERED_TOKEN_STREAM(token_stream)->tokens;
    gint size = tokens->len;
    if ( stop>=size ) stop = size-1;

    gchar *tmp = NULL;
    gchar *buf = g_strdup("");
    gint i;
    for (i = start; i <= stop; i++) {
        AntlrToken *t = g_ptr_array_index(tokens, i);//tokens.get(i);
        if ( antlr_token_get_token_type(t)==ANTLR_TOKEN_EOF ) break;
        gchar *s = antlr_token_get_text(t);
        tmp = buf;
        buf = g_strconcat(buf, s, NULL);
        g_free(tmp);
        g_free(s);
    }
    return buf;
}

static gchar*
antlr_buffered_token_stream_interface_token_stream_get_text_from_context(AntlrTokenStream *token_stream, AntlrRuleContext *ctx) {
    AntlrInterval *interval = antlr_syntax_tree_get_source_interval(ANTLR_SYNTAX_TREE(ctx));
    return antlr_buffered_token_stream_interface_token_stream_get_text_from_interval(token_stream, interval);
}

static gchar*
antlr_buffered_token_stream_interface_token_stream_get_text_from_token(AntlrTokenStream *token_stream, AntlrToken *start, AntlrToken *stop) {

    if ( start!=NULL && stop!=NULL ) {
        gint a = antlr_token_get_token_index(start);
        gint b = antlr_token_get_token_index(stop);
        AntlrInterval *interval = antlr_interval_of(a, b);
        return antlr_token_stream_get_text_from_interval(token_stream, interval);
    }

    return g_strdup("");
}



static void
antlr_buffered_token_stream_int_stream_interface_consume(AntlrIntStream *int_stream) {
    gboolean skip_eof_check;
    AntlrBufferedTokenStream *stream = ANTLR_BUFFERED_TOKEN_STREAM(int_stream);
    if (stream->p >= 0) {
        if (stream->fetched_eof) {
            // the last token in tokens is EOF. skip check if p indexes any
            // fetched token except the last.
            skip_eof_check = stream->p < stream->tokens->len - 1;
        }
        else {
            // no EOF token in tokens. skip check if p indexes a fetched token.
            skip_eof_check = stream->p < stream->tokens->len;
        }
    }
    else {
        // not yet initialized
        skip_eof_check = FALSE;
    }


    if (!skip_eof_check && antlr_int_stream_LA(int_stream, 1) == ANTLR_INT_STREAM_EOF) {
        g_return_if_reached(); //throw new IllegalStateException("cannot consume EOF");
    }

    if (antlr_buffered_token_stream_sync(ANTLR_TOKEN_STREAM(stream), stream->p + 1)) {
        stream->p = antlr_buffered_token_stream_adjust_seek_index(stream, stream->p+1);
    }
}

static gint
antlr_buffered_token_stream_interface_int_stream_LA(AntlrIntStream *int_stream, gint i) {
    AntlrToken *token = antlr_token_stream_LT(ANTLR_TOKEN_STREAM(int_stream), i);

//    g_print(">IntStream: %s\n", g_type_name_from_instance(int_stream));// CommonTokenStream
//    g_print(">Token: %p\n", token);
//    g_print(">Token: %s\n", g_type_name_from_instance(token));
    gint type = antlr_token_get_token_type(token);
//    g_print(">Type: %d\n", type);
    return type;
 ///return LT(i).getType();
}

static int
    antlr_buffered_token_stream_interface_int_stream_mark(AntlrIntStream *int_stream) {
    return 0;
}

static void
antlr_buffered_token_stream_interface_int_stream_release(AntlrIntStream *int_stream, gint marker) {
    // no resources to release
}

static int
    antlr_buffered_token_stream_interface_int_stream_index(AntlrIntStream *int_stream) {
    return ANTLR_BUFFERED_TOKEN_STREAM(int_stream)->p;
}

static void
antlr_buffered_token_stream_interface_int_stream_seek(AntlrIntStream *int_stream, gint index) {
    AntlrBufferedTokenStream *stream = ANTLR_BUFFERED_TOKEN_STREAM(int_stream);

    antlr_buffered_token_stream_lazy_init(ANTLR_TOKEN_STREAM(stream));
    stream->p = antlr_buffered_token_stream_adjust_seek_index(stream, index);
}

static gint
antlr_buffered_token_stream_interface_int_stream_size(AntlrIntStream *int_stream)
{
    return ANTLR_BUFFERED_TOKEN_STREAM(int_stream)->tokens->len;
}

//char* (*get_source_name)  (AntlrIntStream *int_stream);





static AntlrToken*
antlr_buffered_token_stream_class_LB(AntlrBufferedTokenStream *self, gint k) {
    if ( (self->p - k)<0 )
        return NULL;
//    return tokens.get(p-k);
    return antlr_token_stream_get(ANTLR_TOKEN_STREAM(self), self->p - k);
}
static gint
antlr_buffered_token_stream_default_adjust_seek_index(AntlrBufferedTokenStream *self, gint i)
{
    return i;
}

static void
antlr_buffered_token_stream_init (AntlrBufferedTokenStream *object)
{
    object->p = -1;
    object->tokens = g_ptr_array_sized_new(100);
    g_ptr_array_set_free_func(object->tokens, (GDestroyNotify)g_object_unref);
    object->fetched_eof = FALSE;
}

AntlrBufferedTokenStream *
antlr_buffered_token_stream_new (void)
{
	return g_object_new (antlr_buffered_token_stream_get_type (),
	                     NULL);
}

AntlrBufferedTokenStream*
antlr_buffered_token_stream_super_with_token_source(GType type, AntlrTokenSource *token_source)
{
    g_return_val_if_fail(token_source, NULL);// throw new NullPointerException("tokenSource cannot be null");

    AntlrBufferedTokenStream *stream = g_object_new (type, NULL);
    stream->token_source = token_source;
    g_object_ref(stream->token_source);

    return stream;
}

AntlrBufferedTokenStream*
antlr_buffered_token_stream_new_with_token_source(AntlrTokenSource *token_source)
{
    return antlr_buffered_token_stream_super_with_token_source(ANTLR_TYPE_BUFFERED_TOKEN_STREAM, token_source);
}

/**
 * antlr_buffered_token_stream_adjust_seek_index:
 * @self: Some #AntlrBufferedTokenStream
 * @i: The target token index.
 *
 * Allowed derived classes to modify the behavior of operations which change
 * the current stream position by adjusting the target token index of a seek
 * operation. The default implementation simply returns {@code i}. If an
 * exception is thrown in this method, the current stream index should not be
 * changed.
 *
 * For example, #AntlrCommonTokenStream overrides this method to ensure that
 * the seek target is always an on-channel token.
 *
 * Returns: The adjusted target token index.
 */
gint
antlr_buffered_token_stream_adjust_seek_index(AntlrBufferedTokenStream *self, gint i)
{
    g_return_val_if_fail(ANTLR_IS_BUFFERED_TOKEN_STREAM(self), -1);

    return ANTLR_BUFFERED_TOKEN_STREAM_GET_CLASS(self)->adjust_seek_index(self, i);
}


AntlrToken*
antlr_buffered_token_stream_LB(AntlrBufferedTokenStream *self, gint k)
{
    g_return_val_if_fail(ANTLR_IS_BUFFERED_TOKEN_STREAM(self), NULL);

    return ANTLR_BUFFERED_TOKEN_STREAM_GET_CLASS(self)->LB(self, k);
}

/**
 * antlr_buffered_token_stream_fetch:
 * @token_stream: Some #AntlrBufferedTokenStream
 *
 * Add @n elements to buffer.
 *
 * Returns: The actual number of elements added to the buffer.
 */
static gint
antlr_buffered_token_stream_fetch(AntlrBufferedTokenStream *token_stream, gint n)
{
    if (token_stream->fetched_eof==TRUE) {
        return 0;
    }

    gint i;
    for (i = 0; i < n; i++) {
        AntlrToken *t = antlr_token_source_next_token(token_stream->token_source);// token_source of PhpLexer
        if ( ANTLR_IS_WRITABLE_TOKEN(t) ) {
            antlr_writable_token_set_token_index(ANTLR_WRITABLE_TOKEN(t), token_stream->tokens->len);
        }
        g_ptr_array_add(token_stream->tokens, t);

        if ( antlr_token_get_token_type(t)==ANTLR_TOKEN_EOF) {
            token_stream->fetched_eof = TRUE;
            return i + 1;
        }
    }


    return n;
}

/**
 * antlr_buffered_token_stream_set_token_source:
 * @self: Some #AntlrBufferedTokenStream
 * @token_source: Some #AntlrTokenSource
 *
 * Reset this token stream by setting its token source.
 */
void antlr_buffered_token_stream_set_token_source(AntlrBufferedTokenStream *self, AntlrTokenSource *token_source) {
    self->token_source = token_source;
    if (self->tokens) {
        g_ptr_array_free(self->tokens, TRUE);
    }
    self->tokens = g_ptr_array_new();//tokens.clear();
    g_ptr_array_set_free_func(self->tokens, (GDestroyNotify)g_object_unref);//tokens.clear();
    self->p = -1;
}


/**
 * antlr_buffered_token_stream_next_token_on_channel:
 * @self: Some #AntlrBufferedTokenStream
 * @i: The index
 * @channel: The channel
 *
 * Given a starting index, return the index of the next token on channel.
 * Return @i if AntlrBufferedTokenStream.tokens[i] is on @channel. Return the index of
 * the #ANTLR_TOKEN_EOF token if there are no tokens on channel between @i} and
 * #ANTLR_TOKEN_EOF.
 */
gint
antlr_buffered_token_stream_next_token_on_channel(AntlrBufferedTokenStream *self, gint i, gint channel) {
    antlr_buffered_token_stream_sync(ANTLR_TOKEN_STREAM(self), i);

    gint size = antlr_int_stream_size(ANTLR_INT_STREAM(self));
    if (i >= size) {
        return size - 1;
    }

    AntlrToken *token = g_ptr_array_index(self->tokens, i);

    while (antlr_token_get_channel(token)!=channel) {
        if (antlr_token_get_token_type(token)==ANTLR_TOKEN_EOF) {
            return i;
        }
        i++;
        antlr_buffered_token_stream_sync(ANTLR_TOKEN_STREAM(self), i);
        token = g_ptr_array_index(self->tokens, i);
    }

    return i;
}

/**
 * antlr_buffered_token_source_previous_token_on_channel:
 * @self: Some #AntlrBufferedTokenStream
 * @i: The token index
 * @channel: The channel index
 *
 * Given a starting index, return the index of the previous token on
 * channel. Return @i if AntlrBufferedTokenStream.tokens[i] is on channel. Return -1
 * if there are no tokens on channel between @i and 0.
 *
 * If @i specifies an index at or after the EOF token, the EOF token
 * index is returned. This is due to the fact that the EOF token is treated
 * as though it were on every channel.
 */
gint antlr_buffered_token_source_previous_token_on_channel(AntlrBufferedTokenStream *self, gint i, gint channel)
{
    antlr_buffered_token_stream_sync(ANTLR_TOKEN_STREAM(self), i);

    gint size = antlr_int_stream_size(ANTLR_INT_STREAM(self));
    if (i >= size) {
        return size - 1;
    }

    while (i>=0) {
        AntlrToken *token = g_ptr_array_index(self->tokens, i);

        if ( antlr_token_get_token_type(token)==ANTLR_TOKEN_EOF
          || antlr_token_get_channel(token)==channel
         ) {
            return i;
        }
        i--;
    }

    return i;
}

/**
 * antlr_buffered_token_stream_fill:
 * @self: Some #AntlrBufferedTokenStream
 *
 * Get all tokens from lexer until EOF
 */
void
antlr_buffered_token_stream_fill(AntlrBufferedTokenStream *self)
{
    antlr_buffered_token_stream_lazy_init(ANTLR_TOKEN_STREAM(self));
    gint block_size = 1000;
    while (TRUE) {
        gint fetched = antlr_buffered_token_stream_fetch(self, block_size);
        if (fetched < block_size) {
            return;
        }
    }
}
