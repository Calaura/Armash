/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * parser-rule-context.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "types.h"
#include "misc/object.h"
#include "misc/interval.h"
#include "tree/tree.h"
#include "tree/syntax-tree.h"
#include "tree/parse-tree.h"
#include "tree/terminal-node.h"
#include "tree/terminal-node-impl.h"
#include "tree/error-node.h"
#include "tree/error-node-impl.h"
#include "tree/parse-tree-listener.h"
#include "tree/tree.h"
#include "rule-context.h"
#include "token.h"

#include "parser-rule-context.h"


static void
antlr_parser_rule_context_default_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener)
{

}

static void
antlr_parser_rule_context_default_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener)
{

}

static int
antlr_parser_rule_context_interface_tree_get_child_count(AntlrTree *self) {
    int length = g_list_length(ANTLR_PARSER_RULE_CONTEXT(self)->children);
    return length;
}

static AntlrTree*
antlr_parser_rule_context_interface_tree_get_child(AntlrTree *self, gint i) {
    return g_list_nth_data(ANTLR_PARSER_RULE_CONTEXT(self)->children, i);
}

static AntlrInterval*
antlr_parser_rule_context_interface_syntax_tree_get_source_interval(AntlrSyntaxTree *self);

static void antlr_parser_rule_context_interface_syntax_tree_init(AntlrSyntaxTreeInterface *iface);
static void antlr_parser_rule_context_interface_tree_init(AntlrTreeInterface *iface);
static void antlr_parser_rule_context_class_init(AntlrParserRuleContextClass *klass);
static void antlr_parser_rule_context_init(AntlrParserRuleContext *gobject);

G_DEFINE_TYPE_WITH_CODE (AntlrParserRuleContext, antlr_parser_rule_context, ANTLR_TYPE_RULE_CONTEXT,
                         G_IMPLEMENT_INTERFACE(ANTLR_TYPE_TREE, antlr_parser_rule_context_interface_tree_init)
                         G_IMPLEMENT_INTERFACE(ANTLR_TYPE_SYNTAX_TREE, antlr_parser_rule_context_interface_syntax_tree_init)
                         )

static void
antlr_parser_rule_context_interface_syntax_tree_init(AntlrSyntaxTreeInterface *iface)
{
    iface->get_source_interval = antlr_parser_rule_context_interface_syntax_tree_get_source_interval;
}

static void
antlr_parser_rule_context_interface_tree_init(AntlrTreeInterface *iface)
{
    iface->get_child       = antlr_parser_rule_context_interface_tree_get_child;
    iface->get_child_count = antlr_parser_rule_context_interface_tree_get_child_count;
}

static void
antlr_parser_rule_context_class_object_dispose(GObject *object) {
    AntlrParserRuleContext *slef = ANTLR_PARSER_RULE_CONTEXT(object);
    if (slef->children)
        g_list_free_full(slef->children, (GDestroyNotify)g_object_unref);

    G_OBJECT_CLASS(antlr_parser_rule_context_parent_class)->dispose(object);
}

static void
antlr_parser_rule_context_class_init(AntlrParserRuleContextClass *klass)
{
//    GObjectClass *gobject_class;

//	gobject_class = (GObjectClass *) klass;

    G_OBJECT_CLASS(klass)->dispose = antlr_parser_rule_context_class_object_dispose;

    klass->enter_rule = antlr_parser_rule_context_default_enter_rule;
    klass->exit_rule = antlr_parser_rule_context_default_exit_rule;
}

static void
antlr_parser_rule_context_init (AntlrParserRuleContext *object)
{
    object->children = NULL;
}

AntlrParserRuleContext *
antlr_parser_rule_context_new (void)
{
	return g_object_new (antlr_parser_rule_context_get_type (),
	                     NULL);
}

AntlrParserRuleContext *
antlr_parser_rule_context_copy_from(AntlrParserRuleContext *self, AntlrParserRuleContext *ctx) {
    ANTLR_RULE_CONTEXT(self)->parent = ANTLR_RULE_CONTEXT(ctx)->parent;
    ANTLR_RULE_CONTEXT(self)->invoking_state = ANTLR_RULE_CONTEXT(ctx)->invoking_state;

    self->start = ctx->start;
    self->stop  = ctx->stop;

    // copy any error nodes to alt label node
    if ( ctx->children!=NULL ) {
        GList *it;
        // reset parent pointer for any error nodes
        for (it=g_list_first(ctx->children); it; it=it->next) {
            AntlrParseTree *child = it->data;
            if ( ANTLR_IS_ERROR_NODE_IMPL(child) ) {
                self->children = g_list_append(self->children, (gpointer)child);
                ANTLR_RULE_CONTEXT(child)->parent = self;
            }
        }
    }

    return self;
}

AntlrParserRuleContext *
antlr_parser_rule_context_super_with_parent(GType type, AntlrParserRuleContext *parent, gint state) {
    AntlrParserRuleContext *context = g_object_new (type, NULL);
    ANTLR_RULE_CONTEXT(context)->parent = ANTLR_RULE_CONTEXT(parent);
    if (parent) {
        ANTLR_RULE_CONTEXT(context)->root = ANTLR_RULE_CONTEXT(parent)->root;
    } else {
        ANTLR_RULE_CONTEXT(context)->root = ANTLR_RULE_CONTEXT(context);
    }
//    if (parent)
//        g_object_ref(parent);
    ANTLR_RULE_CONTEXT(context)->invoking_state = state;

    return context;
}

AntlrParserRuleContext *
antlr_parser_rule_context_new_with_parent(AntlrParserRuleContext *parent, gint invoking_state_number) {
    return antlr_parser_rule_context_super_with_parent(ANTLR_TYPE_PARSER_RULE_CONTEXT, parent, invoking_state_number);
}


// TODO
// Double dispatch methods for listeners

void
antlr_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener)
{
    g_return_if_fail(ANTLR_IS_PARSER_RULE_CONTEXT(self));

    ANTLR_PARSER_RULE_CONTEXT_GET_CLASS(self)->enter_rule(self, listener);
}

void
antlr_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener)
{
    g_return_if_fail(ANTLR_IS_PARSER_RULE_CONTEXT(self));

    ANTLR_PARSER_RULE_CONTEXT_GET_CLASS(self)->exit_rule(self, listener);
}

AntlrRuleContext*
antlr_parser_rule_context_add_child(AntlrParserRuleContext *self, AntlrRuleContext *rule_invocation)
{
    self->children = g_list_append(self->children, rule_invocation);

    rule_invocation->parent = ANTLR_RULE_CONTEXT(self);
    rule_invocation->root = ANTLR_RULE_CONTEXT(rule_invocation->root);
//    g_object_add_weak_pointer(G_OBJECT(rule_invocation->root), (void **)&rule_invocation);
//    g_print("add_weak_pointer(%s, %s)\n",
//            g_type_name_from_instance(rule_invocation->root),
//            g_type_name_from_instance(rule_invocation));

    return rule_invocation;
}


/**
 * antlr_parser_rule_context_add_child_from_node:
 * @self: Some #AntlrParserRuleContext
 * @t: The terminal node
 *
 * Does not set parent link; other add methods do that
 */
AntlrTerminalNode*
antlr_parser_rule_context_add_child_from_node(AntlrParserRuleContext *self, AntlrTerminalNode*t) {
    self->children = g_list_append(self->children, t);

    ANTLR_TERMINAL_NODE_IMPL(t)->parent = ANTLR_PARSE_TREE(self);
    ANTLR_TERMINAL_NODE_IMPL(t)->root = ANTLR_PARSE_TREE(ANTLR_RULE_CONTEXT(self)->root);
//    g_object_add_weak_pointer(G_OBJECT(ANTLR_TERMINAL_NODE_IMPL(t)->root), (void **)&t);
//    g_print("*add_weak_pointer(%s, %s)\n",
//            g_type_name_from_instance(ANTLR_TERMINAL_NODE_IMPL(t)->root),
//            g_type_name_from_instance(t));

    return t;
}

/**
 * antlr_parser_rule_context_remove_last_child:
 * @self: Some #AntlrParserRuleContext
 *
 * antlr_parser_rule_context_remove_last_child:
 * Used by enterOuterAlt to toss out a RuleContext previously added as
 * we entered a rule. If we have # label, we will need to remove
 * generic ruleContext object.
 */
void
antlr_parser_rule_context_remove_last_child (AntlrParserRuleContext *self)
{
    if ( self->children!=NULL ) {
        GList *link = g_list_last(self->children);
        AntlrParseTree *data = link->data;
        self->children = g_list_remove_link(self->children, link);
//        if(ANTLR_IS_TERMINAL_NODE_IMPL(data)) {
//            g_object_remove_weak_pointer(G_OBJECT(ANTLR_TERMINAL_NODE_IMPL(data)->root), (void **)&data);
//        } else if (ANTLR_IS_RULE_CONTEXT(data)) {
//            g_object_remove_weak_pointer(G_OBJECT(ANTLR_RULE_CONTEXT(data)->root), (void **)&data);
//        }
        g_object_unref(data);
    }
}

AntlrTerminalNode*
antlr_parser_rule_context_add_child_from_token(AntlrParserRuleContext *self, AntlrToken *matchedToken) {
    AntlrTerminalNodeImpl *t = antlr_terminal_node_impl_new_with_token(matchedToken);
    antlr_parser_rule_context_add_child_from_node(self, ANTLR_TERMINAL_NODE(t));
    //g_object_ref(t);
    return ANTLR_TERMINAL_NODE(t);
}

AntlrErrorNode*
antlr_parser_rule_context_add_error_node(AntlrParserRuleContext *self, AntlrToken *bad_token) {
    AntlrErrorNodeImpl *t = antlr_error_node_impl_new_with_token(bad_token);
    antlr_parser_rule_context_add_child_from_node(self, ANTLR_TERMINAL_NODE(t));
    ANTLR_TERMINAL_NODE_IMPL(t)->parent = ANTLR_PARSE_TREE(self);
    return ANTLR_ERROR_NODE(t);
}

AntlrTerminalNode *antlr_parser_rule_context_get_token(AntlrParserRuleContext *self, gint ttype, gint i) {
    g_print("antlr_parser_get_token not implemented");
    if ( self->children==NULL || i < 0 || i >= g_list_length(self->children) ) {
        return NULL;
    }
#if 0
    int j = -1; // what token with ttype have we found?
    for (ParseTree o : children) {
        if ( o instanceof TerminalNode ) {
            TerminalNode tnode = (TerminalNode)o;
            Token symbol = tnode.getSymbol();
            if ( symbol.getType()==ttype ) {
                j++;
                if ( j == i ) {
                    return tnode;
                }
            }
        }
    }
#endif
    return NULL;
}

// returns GList of <TerminalNode>
GList* antlr_parser_rule_context_get_tokens(AntlrParserRuleContext *self, gint ttype) {
    g_print("antlr_parser_get_tokens not implemented");

    if ( self->children==NULL ) {
        return NULL;//Collections.emptyList();
    }

    GList * tokens = NULL;// <TerminalNode>
#if 0
    for (ParseTree o : children) {
        if ( o instanceof TerminalNode ) {
            TerminalNode tnode = (TerminalNode)o;
            Token symbol = tnode.getSymbol();
            if ( symbol.getType()==ttype ) {
                if ( tokens==null ) {
                    tokens = new ArrayList<TerminalNode>();
                }
                tokens.add(tnode);
            }
        }
    }

    if ( tokens==null ) {
        return Collections.emptyList();
    }
#endif
    return tokens;
}



AntlrParserRuleContext*
antlr_parser_rule_context_get_rule_context(AntlrParserRuleContext *self, GType ctxType, gint i) {
    g_print("%s not implemented for instance: %s\n", __FUNCTION__, g_type_name(ctxType));
    return NULL;
    //antlr_tree_get_child(ANTLR_TREE(ctx), i);
}
//public <T extends ParserRuleContext> T getRuleContext(Class<? extends T> ctxType, int i) {
//    return getChild(ctxType, i);
//}

GList* /* of AntlrParserRuleContext* */
antlr_parser_rule_context_get_rule_contexts(AntlrParserRuleContext *self, GType ctxType) {
    return NULL;
}
//public <T extends ParserRuleContext> List<T> getRuleContexts(Class<? extends T> ctxType) {
//    if ( children==null ) {
//        return Collections.emptyList();
//    }

//    List<T> contexts = null;
//    for (ParseTree o : children) {
//        if ( ctxType.isInstance(o) ) {
//            if ( contexts==null ) {
//                contexts = new ArrayList<T>();
//            }

//            contexts.add(ctxType.cast(o));
//        }
//    }

//    if ( contexts==null ) {
//        return Collections.emptyList();
//    }

//    return contexts;
//}

static AntlrInterval*
antlr_parser_rule_context_interface_syntax_tree_get_source_interval(AntlrSyntaxTree *obj)
{
    AntlrParserRuleContext *self = ANTLR_PARSER_RULE_CONTEXT(obj);
    if ( self->start == NULL ) {
        return ANTLR_INTERVAL_INVALID;
    }

    if ( self->stop==NULL || antlr_token_get_token_index(self->stop)<antlr_token_get_token_index(self->start) ) {

        return antlr_interval_of(antlr_token_get_token_index(self->start), antlr_token_get_token_index(self->start)-1); // empty
    }
    return antlr_interval_of(antlr_token_get_token_index(self->start), antlr_token_get_token_index(self->stop));
}
