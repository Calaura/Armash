/*
 * [The "BSD license"]
 *  Copyright (c) 2016 Gaulouis <gaulouis.com@gmail.com>
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 *  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 *  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * SECTION:vocabulary
 * @Title: AntlrIVocabulary
 * @Short_Description: This interface provides information about the vocabulary.
 *
 * This interface provides information about the vocabulary used by a
 * #AntlrRecognizer.
 *
 */

#include "vocabulary.h"



G_DEFINE_INTERFACE (AntlrIVocabulary, antlr_ivocabulary, 0)

static void
antlr_ivocabulary_default_init (AntlrIVocabularyInterface *iface)
{
    /* add properties and signals to the interface here */
}

/**
 * antlr_ivocabulary_get_literal_name:
 * @self: a #AntlrIVocabulary.
 * @token_type: The token type.
 *
 * Gets the string literal associated with a token type. The string returned
 * by this method, when not %NULL, can be used unaltered in a parser
 * grammar to represent this token type.
 *
 * The following table shows examples of lexer rules and the literal
 * names assigned to the corresponding token types.
 * <table width="100%">
 *  <tr>
 *   <th>Rule</th>
 *   <th>Literal Name</th>
 *   <th>GString Literal</th>
 *  </tr>
 *  <tr>
 *   <td>THIS : 'this';</td>
 *   <td>'this'</td>
 *   <td>"'this'"</td>
 *  </tr>
 *  <tr>
 *   <td>SQUOTE : '\'';</td>
 *   <td>'\''</td>
 *   <td>"'\\''"</td>
 *  </tr>
 *  <tr>
 *   <td>ID : [A-Z]+;</td>
 *   <td>N/A</td>
 *   <td>%NULL</td>
 *  </tr>
 * </table>
 *
 * Returns: (transfer full): The string literal associated with the specified token type, or
 * %NULL if no string literal is associated with the type.
 **/
gchar*
antlr_ivocabulary_get_literal_name (AntlrIVocabulary *self, gint token_type)
{
    g_assert(ANTLR_IS_IVOCABULARY (self));

    return ANTLR_IVOCABULARY_GET_INTERFACE (self)->get_literal_name (self, token_type);
}

/**
 * antlr_ivocabulary_get_symbolic_name:
 * @self: a #AntlrIVocabulary.
 * @token_type: The token type.
 *
 * Gets the symbolic name associated with a token type. The string returned
 * by this method, when not %NULL, can be used unaltered in a parser
 * grammar to represent this token type.
 *
 * This method supports token types defined by any of the following
 * methods:
 *
 * - Tokens created by lexer rules.
 * - Tokens defined in a tokens{} block in a lexer or parser grammar.
 * - The implicitly defined #ANTLR_TOKEN_EOF token, which has the token type
 * #ANTLR_TOKEN_EOF.
 *
 * The following table shows examples of lexer rules and the literal
 * names assigned to the corresponding token types.
 *
 * <table width="100%">
 *  <tr>
 *   <th>Rule</th>
 *   <th>Symbolic Name</th>
 *  </tr>
 *  <tr>
 *   <td>THIS : 'this';</td>
 *   <td>THIS</td>
 *  </tr>
 *  <tr>
 *   <td>SQUOTE : '\'';</td>
 *   <td>SQUOTE</td>
 *  </tr>
 *  <tr>
 *   <td>ID : [A-Z]+;</td>
 *   <td>ID</td>
 *  </tr>
 * </table>
 *
 * Returns: (transfer full): The symbolic name associated with the specified token type, or
 * %NULL if no symbolic name is associated with the type.
 */
gchar*
antlr_ivocabulary_get_symbolic_name(AntlrIVocabulary *self, gint token_type)
{
    g_assert(ANTLR_IS_IVOCABULARY (self));

    return ANTLR_IVOCABULARY_GET_INTERFACE (self)->get_symbolic_name (self, token_type);
}

/**
 * antlr_ivocabulary_get_display_name:
 * @self: a #AntlrIVocabulary.
 * @token_type: The token type.
 *
 * Gets the display name of a token type.
 *
 * ANTLR provides a default implementation of this method, but
 * applications are free to override the behavior in any manner which makes
 * sense for the application. The default implementation returns the first
 * result from the following list which produces a non-%NULL
 * result.
 *
 * 1. The result of #antlr_ivocabulary_get_literal_name()
 * 2. The result of #antlr_ivocabulary_get_symbolic_name()
 * 3. The result of integer formatted to string
 *
 *
 * Returns: (transfer full): The display name of the token type, for use in error reporting or
 * other user-visible messages which reference specific token types.
 */
gchar*
antlr_ivocabulary_get_display_name (AntlrIVocabulary *self, gint token_type)
{
    g_assert(ANTLR_IS_IVOCABULARY (self));

    return ANTLR_IVOCABULARY_GET_INTERFACE (self)->get_display_name (self, token_type);
}
