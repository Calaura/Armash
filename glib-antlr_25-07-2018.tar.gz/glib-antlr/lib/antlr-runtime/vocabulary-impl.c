/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * vocabulary-impl.c
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr-runtime is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr-runtime is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "types.h"
#include "misc/object.h"
#include "vocabulary-impl.h"
#include "vocabulary.h"
#include "types.h"
#include "int-stream.h"
#include "token.h"


struct _AntlrVocabularyPrivate {
    GArrayGString *literal_names;
    GArrayGString *symbolic_names;
    GArrayGString *display_names;
};

/**
 * AntlrVocabulary:
 * This class provides a default implementation of the {@link Vocabulary}
 * interface.
 *
 */

/**
 * antlr_vocabulary_EMPTY_NAMES:
 *
 */
static gchar **antlr_vocabulary_EMPTY_NAMES = {NULL};
/**
 * antlr_vocabulary_EMPTY_VOCABULARY:
 * Gets an empty #AntlrVocabulary instance.
 *
 * No literal or symbol names are assigned to token types, so
 * antlr_ivocabulary_get_display_name(int) returns the numeric value for all tokens
 * except %ANTLR_TOKEN_EOF.
 */
static AntlrVocabulary *antlr_vocabulary_EMPTY_VOCABULARY = NULL;
//public static final VocabularyImpl EMPTY_VOCABULARY = new VocabularyImpl(EMPTY_NAMES, EMPTY_NAMES, EMPTY_NAMES);
AntlrVocabulary *
antlr_vocabulary_get_empty_vocabulary() {
    if (!antlr_vocabulary_EMPTY_VOCABULARY) {
        antlr_vocabulary_EMPTY_VOCABULARY = antlr_vocabulary_new (
                    NULL,
                    NULL,
                    NULL);
    }
    return antlr_vocabulary_EMPTY_VOCABULARY;
}

static void antlr_ivocabulary_interface_init (AntlrIVocabularyInterface *iface);

G_DEFINE_TYPE_WITH_CODE (AntlrVocabulary, antlr_vocabulary, ANTLR_TYPE_OBJECT,
                         G_IMPLEMENT_INTERFACE (ANTLR_TYPE_IVOCABULARY,
                                                antlr_ivocabulary_interface_init))

static gchar *
antlr_vocabulary_get_literal_name(AntlrIVocabulary *self, int token_type) {
    AntlrVocabulary *instance = ANTLR_VOCABULARY(self);
    if (token_type >= 0 && token_type < instance->priv->literal_names->len) {
        GString *literal_names = g_array_index(instance->priv->literal_names, GString *, token_type);
        return g_strdup(literal_names->str);
    }

    return NULL;
}

static gchar *
antlr_vocabulary_get_symbolic_name(AntlrIVocabulary *self, int token_type) {
    AntlrVocabulary *instance = ANTLR_VOCABULARY(self);
    if (token_type >= 0 && token_type < instance->priv->symbolic_names->len) {
        GString *symbolic_names = g_array_index(instance->priv->symbolic_names, GString *, token_type);
        return g_strdup(symbolic_names->str);
        //return instance->priv->symbolic_names->data[token_type];
    }

    if (token_type == ANTLR_TOKEN_EOF) {
        return g_strdup("EOF");
    }

    return NULL;
}

static gchar *
antlr_vocabulary_get_display_name(AntlrIVocabulary *self, int token_type) {
    AntlrVocabulary *instance = ANTLR_VOCABULARY(self);
    if (token_type >= 0 && token_type < instance->priv->display_names->len) {
        GString *display_name = g_array_index(instance->priv->display_names, GString *, token_type);
        //gchar *display_name = instance->priv->display_names->data[token_type];
        if (display_name != NULL) {
            return g_strdup(display_name->str);
        }
    }

    gchar* literal_name = antlr_vocabulary_get_literal_name(self, token_type);
    if (literal_name != NULL) {
        return literal_name;
    }

    gchar *symbolic_name = antlr_vocabulary_get_symbolic_name(self, token_type);
    if (symbolic_name != NULL) {
        return symbolic_name;
    }

    return g_strdup_printf("'%c'", token_type+1);//Integer.toString(token_type);
}

static void
antlr_ivocabulary_interface_init (AntlrIVocabularyInterface *iface)
{
    iface->get_display_name  = antlr_vocabulary_get_display_name;
    iface->get_literal_name  = antlr_vocabulary_get_literal_name;
    iface->get_symbolic_name = antlr_vocabulary_get_symbolic_name;
}

static void
antlr_vocabulary_class_init (AntlrVocabularyClass *klass)
{
    g_type_class_add_private (klass, sizeof (AntlrVocabularyPrivate));
}

static void
antlr_vocabulary_init (AntlrVocabulary *self)
{
    self->priv = G_TYPE_INSTANCE_GET_PRIVATE (self, ANTLR_TYPE_VOCABULARY, AntlrVocabularyPrivate);
    self->priv->literal_names = NULL;//g_array_new( FALSE, FALSE, sizeof(GString *));
    self->priv->display_names = NULL;//g_array_new( FALSE, FALSE, sizeof(GString *));
    self->priv->symbolic_names = NULL;//g_array_new( FALSE, FALSE, sizeof(GString *));
}

/**
 * antlr_vocabulary_new:
 * @literal_names: The literal names assigned to tokens, or %NULL
 * if no literal names are assigned.
 * @symbolic_names: The symbolic names assigned to tokens, or
 * %NULL if no symbolic names are assigned.
 * @display_names: The display names assigned to tokens, or %NULL
 * to use the values in @literal_names and @symbolic_names as
 * the source of display names, as described in
 *
 * Constructs a new instance of #AntlrVocabulary from the specified
 * literal, symbolic, and display token names.
 *
 * #antlr_ivocabulary_get_display_name(int).
 *
 * @see #antlr_ivocabulary_get_literal_name(int)
 * @see #antlr_ivocabulary_get_symbolic_name(int)
 * @see #antlr_ivocabulary_get_display_name(int)
 */
AntlrVocabulary*
antlr_vocabulary_new (GArray *literal_names, GArray *symbolic_names, GArray *display_names)
{
    AntlrVocabulary* vocabulary = g_object_new(ANTLR_TYPE_VOCABULARY, NULL);

#define EMPTY_NAMES g_array_new(FALSE, FALSE, sizeof(GString*))
    vocabulary->priv->literal_names  = literal_names  != NULL ? literal_names  : EMPTY_NAMES;
    vocabulary->priv->symbolic_names = symbolic_names != NULL ? symbolic_names : EMPTY_NAMES;
    vocabulary->priv->display_names  = display_names  != NULL ? display_names  : EMPTY_NAMES;

    return vocabulary;
}



/**
 * antlr_vocabulary_from_token_names:
 * @token_names: The token names, or %NULL if no token names are
 * available.
 *
 * Returns a #AntlrVocabulary instance from the specified set of token
 * names. This method acts as a compatibility layer for the single
 * @token_names array generated by previous releases of ANTLR.
 *
 * The resulting vocabulary instance returns %NULL for
 * #antlr_ivocabulary_get_literal_name(int) and #antlr_ivocabulary_get_symbolic_name(int), and the
 * value from @token_names for the display names.
 *
 * Returns: A #AntlrVocabulary instance which uses @token_names for
 * the display names of tokens.
 */
AntlrVocabulary*
antlr_vocabulary_from_token_names(GArrayGString *token_names/* of string */) {
    if (token_names == NULL || token_names->len == 0) {
        return ANTLR_VOCABULARY_EMPTY_VOCABULARY;
    }

    GArray *literal_names = g_array_sized_new(FALSE, TRUE, sizeof(GString*), token_names->len);
    g_array_set_size(literal_names, token_names->len);
    GArray *symbolic_names = g_array_sized_new(FALSE, TRUE, sizeof(GString*), token_names->len);
    g_array_set_size(symbolic_names, token_names->len);
    int i;
    for (i = 0; i < token_names->len; i++) {
        GString *token_name = g_array_index(token_names, GString*, i);
        if (token_name == NULL) {
            continue;
        }

        if (token_name->len) {
            gchar firstChar = token_name->str[0];
            if (firstChar == '\'') {
                g_array_index(literal_names, GString*, i) = g_string_new_len(token_name->str, token_name->len);
                continue;
            } else if (g_ascii_isupper(firstChar)) {// g_unichar_isupper
                g_array_index(symbolic_names, GString*, i) = g_string_new_len(token_name->str, token_name->len);
                continue;
            }
        }
    }

    return antlr_vocabulary_new(literal_names, symbolic_names, token_names);
}
