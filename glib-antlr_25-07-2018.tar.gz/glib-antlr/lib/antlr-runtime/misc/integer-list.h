/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * integer-list.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_INTEGER_LIST_H__
#define __ANTLR_INTEGER_LIST_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_INTEGER_LIST            (antlr_integer_list_get_type())
#define ANTLR_INTEGER_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_INTEGER_LIST, AntlrIntegerList))
#define ANTLR_INTEGER_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_INTEGER_LIST, AntlrIntegerListClass))
#define ANTLR_IS_INTEGER_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_INTEGER_LIST))
#define ANTLR_IS_INTEGER_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_INTEGER_LIST))
#define ANTLR_INTEGER_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_INTEGER_LIST, AntlrIntegerListClass))

typedef struct _AntlrIntegerList AntlrIntegerList;
typedef struct _AntlrIntegerListClass AntlrIntegerListClass;

struct _AntlrIntegerList {
	AntlrObject parent_instance;

    /*< private >*/
    GArray *data;// of gint
    gint size;
};

struct _AntlrIntegerListClass {
	AntlrObjectClass parent_class;
};

GType antlr_integer_list_get_type(void)G_GNUC_CONST;
AntlrIntegerList *antlr_integer_list_new();
void antlr_integer_list_add(AntlrIntegerList *self, gint value);

void     antlr_integer_list_add(AntlrIntegerList *self, gint value);
void     antlr_integer_list_add_all(AntlrIntegerList *self, GArray *array);
gint     antlr_integer_list_get(AntlrIntegerList *self, gint index);
gboolean antlr_integer_list_contains(AntlrIntegerList *self, gint value);
gint     antlr_integer_list_set(AntlrIntegerList *self, gint index, gint value);
gint     antlr_integer_list_remove_at(AntlrIntegerList *self, gint index);

G_END_DECLS

#endif /* __ANTLR_INTEGER_LIST_H__ */

