/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * double-key-map.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "object.h"
#include "double-key-map.h"

#include "linked-hash-map.h"

static void antlr_double_key_map_class_init(AntlrDoubleKeyMapClass *klass);
static void antlr_double_key_map_init(AntlrDoubleKeyMap *gobject);

G_DEFINE_TYPE (AntlrDoubleKeyMap, antlr_double_key_map, ANTLR_TYPE_OBJECT)

static void
antlr_double_key_map_class_object_dispose(GObject *object)
{

    if (ANTLR_DOUBLE_KEY_MAP(object)->data) {
        g_hash_table_unref(ANTLR_DOUBLE_KEY_MAP(object)->data);
    }

    G_OBJECT_CLASS(antlr_double_key_map_parent_class)->dispose(object);
}

static void
antlr_double_key_map_class_init(AntlrDoubleKeyMapClass *klass)
{
    GObjectClass *gobject_class;

    gobject_class = (GObjectClass *) klass;
    //gobject_class->dispose = antlr_double_key_map_class_object_dispose;


//	antlr_double_key_map_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_double_key_map_init (AntlrDoubleKeyMap *object)
{
    object->data = NULL;
}

void
antlr_double_key_map_super (AntlrDoubleKeyMap *object,
                            GHashFunc       hash_func,
                            GEqualFunc      key_equal_func,
                            GDestroyNotify  key_destroy_func,
                            GDestroyNotify  value_destroy_func)
{
    object->data = g_hash_table_new_full(hash_func, key_equal_func, key_destroy_func, value_destroy_func);
}

void
antlr_double_key_map_free (AntlrDoubleKeyMap *self)
{
    GHashTableIter iter;
    gpointer key, value;

    g_hash_table_iter_init (&iter, self->data);
    while (g_hash_table_iter_next (&iter, &key, &value))
    {
        antlr_linked_hash_map_free((AntlrLinkedHashMap*)value);
    }
    g_hash_table_destroy(self->data);
}

AntlrDoubleKeyMap *
antlr_double_key_map_new (void)
{
    AntlrDoubleKeyMap *object = g_object_new (ANTLR_TYPE_DOUBLE_KEY_MAP, NULL);
    antlr_double_key_map_super (object, g_direct_hash, g_direct_equal, NULL, NULL);
    return object;
}

AntlrDoubleKeyMap *
antlr_double_key_map_new_full (GHashFunc       hash_func,
                               GEqualFunc      key_equal_func,
                               GDestroyNotify  key_destroy_func,
                               GDestroyNotify  value_destroy_func)
{
    AntlrDoubleKeyMap *object = g_object_new (ANTLR_TYPE_DOUBLE_KEY_MAP, NULL);
    antlr_double_key_map_super (object, hash_func, key_equal_func, key_destroy_func, value_destroy_func);
    return object;
}

gpointer
antlr_double_key_map_put(AntlrDoubleKeyMap *self, gpointer key1, gpointer key2, gpointer value)
{
    gpointer prev = NULL;
    gpointer data2 = g_hash_table_lookup(self->data, (gconstpointer)key1);
    if (data2==NULL) {
        data2 = antlr_linked_hash_map_new_full((GHashFunc)g_direct_hash, (GEqualFunc)g_direct_equal, NULL, NULL/*use self->value_destroy_func*/);
        g_hash_table_insert(self->data, (gpointer)key1, (gpointer)data2);
    } else {
        prev = antlr_linked_hash_map_get(data2, key2);
    }
    antlr_linked_hash_map_put(data2, key2, value);

    return prev;
}

gpointer
antlr_double_key_map_get(AntlrDoubleKeyMap *self, gpointer key1, gpointer key2)
{
    gpointer data2 = g_hash_table_lookup(self->data, (gconstpointer)key1);
    if ( data2==NULL )
        return NULL;
    return antlr_linked_hash_map_get(data2, key2);
}
