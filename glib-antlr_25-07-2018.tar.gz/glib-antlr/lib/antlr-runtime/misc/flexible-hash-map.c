/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * flexible-hash-map.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>
#include "../types.h"

#include "flexible-hash-map.h"

//#include "bit-set.h"
//#include "../atn/semantic-context.h"
//#include "../atn/config.h"



static AntlrFlexibleHashEntry*
antlr_flexible_hash_entry_new (gpointer key, gpointer value)
{
    AntlrFlexibleHashEntry *entry = g_new(AntlrFlexibleHashEntry, 1);
    entry->key = key;
    entry->value = value;// GList of BitSet
    return entry;
}

#include "object.h"
#include "bit-set.h"
static void
antlr_flexible_hash_entry_free (AntlrFlexibleHashEntry *entry)
{
    if (entry) {
        // FIXME: g_object_unref(key),  g_object_unref(value) ?
        g_clear_object(&entry->value);// TODO use a special user clear function
        g_free(entry);
    }
}

static void
my_antlr_flexible_hash_entry_free(gpointer *object)
{
    AntlrFlexibleHashEntry *entry = *object;
    antlr_flexible_hash_entry_free(entry);
}
static void
antlr_flexible_hash_map_super (AntlrFlexibleHashMap *map, GHashFunc hash_func, GEqualFunc key_equal_func)
{
    map->buckets = g_hash_table_new_full(hash_func, key_equal_func, NULL, (GDestroyNotify)my_antlr_flexible_hash_entry_free);
    //map->buckets = g_hash_table_new(hash_func, key_equal_func);
    map->key_equal_func = key_equal_func ? key_equal_func : g_direct_equal;
}

//AntlrFlexibleHashMap *
//antlr_flexible_hash_map_new (void)
//{
//    AntlrFlexibleHashMap *map = g_new(AntlrFlexibleHashMap, 1);
//    antlr_flexible_hash_map_super (map, g_direct_hash, g_direct_equal);
//    return map;
//}

AntlrFlexibleHashMap *
antlr_flexible_hash_map_new (GHashFunc hash_func, GEqualFunc key_equal_func)
{
    AntlrFlexibleHashMap *map = g_new0(AntlrFlexibleHashMap, 1);
    antlr_flexible_hash_map_super (map, hash_func, key_equal_func);
    return map;
}

void
antlr_flexible_hash_map_free (AntlrFlexibleHashMap *object)
{
    if (object->buckets) {
        g_hash_table_destroy(object->buckets);
    }
    g_free(object);
}

gpointer
antlr_flexible_hash_map_get (AntlrFlexibleHashMap *object, gpointer key)
{
    if ( key==NULL ) return NULL;
    gpointer bucket_ptr = g_hash_table_lookup(object->buckets, (gconstpointer)key);// bucket_ptr = LinkedList<Entry<K, V>>
    if ( bucket_ptr==NULL ) return NULL; // no bucket
    GList *it;
    for (it = g_list_first((GList*)bucket_ptr); it; it=it->next) {
        AntlrFlexibleHashEntry *e = it->data;
        if ( object->key_equal_func(e->key, key) ) {
            return e->value;
        }
    }

#if 0
    K typedKey = (K)key;
    if ( key==null ) return null;
    int b = getBucket(typedKey);
    LinkedList<Entry<K, V>> bucket = buckets[b];
    if ( bucket==null ) return null; // no bucket
    for (Entry<K, V> e : bucket) {
        if ( comparator.equals(e.key, typedKey) ) {
            return e.value;
        }
    }
#endif
    return NULL;
}


gpointer
antlr_flexible_hash_map_put (AntlrFlexibleHashMap *object, gpointer key, gpointer value)
{
    if ( key==NULL ) return NULL;
    gpointer bucket_ptr = g_hash_table_lookup(object->buckets, (gconstpointer)key);// bucket_ptr = LinkedList<Entry<K, V>>
    GList_AntlrFlexibleHashEntry *bucket = (GList*)bucket_ptr;
    GList *it;
    for (it = g_list_first(bucket); it; it=it->next) {
        AntlrFlexibleHashEntry *e = it->data;
        if ( object->key_equal_func(e->key, key) ) {
            gpointer prev = e->value;
            e->value = value;
//            n++;
            return prev;
        }
    }
    // not there
    AntlrFlexibleHashEntry *entry = antlr_flexible_hash_entry_new(key, value);
    bucket = g_list_append(bucket, (gpointer)entry);
    if ( bucket_ptr==NULL ) {
        g_hash_table_insert(object->buckets, (gpointer)key, (gpointer)bucket);
    }
//    n++;

    return NULL;
}


GList* // of BitSet
antlr_flexible_hash_map_values (AntlrFlexibleHashMap *object)
{
#if 0

#else
    GList *a = NULL;

    GHashTableIter iter;
    gpointer k;
    gpointer v;
    g_hash_table_iter_init (&iter, object->buckets);
    while (g_hash_table_iter_next (&iter, &k, (gpointer) &v))
      {
        //g_print ("ATNConfig==%s\n", g_type_name_from_instance((GTypeInstance*)k));
        GList *it;// of Entry<k, v>
        for (it = g_list_first((GList*)v); it; it=it->next) {
            AntlrFlexibleHashEntry *entry = it->data;
            a = g_list_append(a, entry->value);
            g_object_ref(entry->value);
        }
      }
    return a;
#endif
}
