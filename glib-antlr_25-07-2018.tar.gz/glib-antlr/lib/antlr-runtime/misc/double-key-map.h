/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * double-key-map.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_DOUBLE_KEY_MAP_H__
#define __ANTLR_DOUBLE_KEY_MAP_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_DOUBLE_KEY_MAP            (antlr_double_key_map_get_type())
#define ANTLR_DOUBLE_KEY_MAP(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_DOUBLE_KEY_MAP, AntlrDoubleKeyMap))
#define ANTLR_DOUBLE_KEY_MAP_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_DOUBLE_KEY_MAP, AntlrDoubleKeyMapClass))
#define ANTLR_IS_DOUBLE_KEY_MAP(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_DOUBLE_KEY_MAP))
#define ANTLR_IS_DOUBLE_KEY_MAP_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_DOUBLE_KEY_MAP))
#define ANTLR_DOUBLE_KEY_MAP_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_DOUBLE_KEY_MAP, AntlrDoubleKeyMapClass))

typedef struct _AntlrDoubleKeyMap AntlrDoubleKeyMap;
typedef struct _AntlrDoubleKeyMapClass AntlrDoubleKeyMapClass;

struct _AntlrDoubleKeyMap {
	AntlrObject parent_instance;
    GHashTable *data;// Map<Key1, Map<Key2, Value>>
};

struct _AntlrDoubleKeyMapClass {
	AntlrObjectClass parent_class;
};

GType antlr_double_key_map_get_type(void)G_GNUC_CONST;
void               antlr_double_key_map_free (AntlrDoubleKeyMap *self);
AntlrDoubleKeyMap *antlr_double_key_map_new();
AntlrDoubleKeyMap *antlr_double_key_map_new_full (GHashFunc hash_func, GEqualFunc key_equal_func, GDestroyNotify key_destroy_func, GDestroyNotify value_destroy_func);
gpointer           antlr_double_key_map_put(AntlrDoubleKeyMap *self, gpointer key1, gpointer key2, gpointer value);
gpointer           antlr_double_key_map_get(AntlrDoubleKeyMap *self, gpointer key1, gpointer key2);

G_END_DECLS

#endif /* __ANTLR_DOUBLE_KEY_MAP_H__ */

