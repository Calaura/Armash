/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * integer-list.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "object.h"
#include "integer-list.h"


#define ANTLR_INTEGER_LIST_INITIAL_SIZE 4
#define ANTLR_INTEGER_LIST_MAX_ARRAY_SIZE (G_MAXINT - 8)

static void
antlr_integer_list_ensure_capacity(AntlrIntegerList *self, gint capacity) {
    if (capacity < 0 || capacity > ANTLR_INTEGER_LIST_MAX_ARRAY_SIZE) {
        GError *error = g_error_new(g_quark_from_string("ANTLR"), 100, "%s", "Error: Out of memory");
    }

    gint new_length;
    if (self->data->len == 0) {
        new_length = ANTLR_INTEGER_LIST_INITIAL_SIZE;
    } else {
        new_length = self->data->len;
    }

    while (new_length < capacity) {
        new_length = new_length * 2;
        if (new_length < 0 || new_length > ANTLR_INTEGER_LIST_MAX_ARRAY_SIZE) {
            new_length = ANTLR_INTEGER_LIST_MAX_ARRAY_SIZE;
        }
    }

    g_array_set_size(self->data, new_length);
}


static void antlr_integer_list_class_init(AntlrIntegerListClass *klass);
static void antlr_integer_list_init(AntlrIntegerList *gobject);

G_DEFINE_TYPE (AntlrIntegerList, antlr_integer_list, ANTLR_TYPE_OBJECT)

static void
antlr_integer_list_class_object_dispose(GObject *object)
{
    AntlrIntegerList *self = ANTLR_INTEGER_LIST(object);
    g_array_free(self->data, TRUE);

    G_OBJECT_CLASS(antlr_integer_list_parent_class)->dispose(object);
}

static void
antlr_integer_list_class_init(AntlrIntegerListClass *klass)
{
    GObjectClass *gobject_class;

    gobject_class = (GObjectClass *) klass;
    gobject_class->dispose = antlr_integer_list_class_object_dispose;

//	antlr_integer_list_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_integer_list_init (AntlrIntegerList *object)
{
    object->data = g_array_new(FALSE, FALSE, sizeof(gint));
}

AntlrIntegerList *
antlr_integer_list_new (void)
{
	return g_object_new (antlr_integer_list_get_type (),
	                     NULL);
}

void
antlr_integer_list_add(AntlrIntegerList *self, gint value) {
    g_array_append_val(self->data, value);
}

void
antlr_integer_list_add_all(AntlrIntegerList *self, GArray *array) {
    antlr_integer_list_ensure_capacity(self, self->data->len + array->len);

    g_array_append_vals(self->data, array->data, array->len);
}

// maybe : antlr_integer_list_concat
//void
//antlr_integer_list_add_all(AntlrIntegerList *self, AntlrIntegerList *list) {
//    antlr_integer_list_ensure_capacity(self, self->data->len + list->data->len);
//    g_array_append_vals(self->data, list->data->data, list->data->len);
//}

// add_all


gint
antlr_integer_list_get(AntlrIntegerList *self, gint index) {
    if (index < 0 || index >= self->data->len) {
        //throw new IndexOutOfBoundsException();
        GError *error = g_error_new(g_quark_from_string("ANTLR"), 100, "%s", "Index out of bounds");
    }

    return g_array_index(self->data, gint, index);
}

gboolean
antlr_integer_list_contains(AntlrIntegerList *self, gint value) {
    gint i;
    for (i = 0; i < self->data->len; i++) {
        gint item = g_array_index(self->data, gint, i);
        if (item == value) {
            return TRUE;
        }
    }

    return FALSE;
}


gint
antlr_integer_list_set(AntlrIntegerList *self, gint index, gint value) {
//    if (index < 0 || index >= _size) {
//        throw new IndexOutOfBoundsException();
//    }

    gint previous = g_array_index(self->data, gint, index);
    g_array_insert_val(self->data, index, value);

    return previous;
}

gint
antlr_integer_list_remove_at(AntlrIntegerList *self, gint index) {
    gint value = antlr_integer_list_get(self, index);

    self->data = g_array_remove_index(self->data, index);
//    gint size = self->data->len-1;
//    GArray *array = g_array_new(FALSE, FALSE, size);
//    g_array_append_vals(array, self->data, index+1);
//    g_array_append_vals(array, self->data+index+1, size-index);

//    System.arraycopy(_data, index + 1, _data, index, _size - index - 1);
//    _data[_size - 1] = 0;
//    _size--;
    return value;
}
#if 0
public final int removeAt(int index) {
    int value = get(index);
    System.arraycopy(_data, index + 1, _data, index, _size - index - 1);
    _data[_size - 1] = 0;
    _size--;
    return value;
}

#endif
