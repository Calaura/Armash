/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * linked-hash-map.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "object.h"
#include "linked-hash-map.h"


static void antlr_linked_hash_map_class_init(AntlrLinkedHashMapClass *klass);
static void antlr_linked_hash_map_init(AntlrLinkedHashMap *gobject);

G_DEFINE_TYPE (AntlrLinkedHashMap, antlr_linked_hash_map, ANTLR_TYPE_OBJECT)

static void
antlr_linked_hash_map_class_init(AntlrLinkedHashMapClass *klass)
{
//	GObjectClass *gobject_class;

//	gobject_class = (GObjectClass *) klass;


//	antlr_linked_hash_map_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_linked_hash_map_init (AntlrLinkedHashMap *object)
{
    object->table = NULL;
    object->header = NULL;
}

void
antlr_linked_hash_map_super (AntlrLinkedHashMap *object,
                             GHashFunc       hash_func,
                             GEqualFunc      key_equal_func,
                             GDestroyNotify  key_destroy_func,
                             GDestroyNotify  value_destroy_func)
{
    object->table = g_hash_table_new_full(hash_func, key_equal_func, key_destroy_func, value_destroy_func);
    object->header = NULL;
}

void
antlr_linked_hash_map_free (AntlrLinkedHashMap *self)
{
    g_hash_table_destroy((GHashTable*)self->table);
    if (self->header) {
        g_list_free(self->header);
    }
}

AntlrLinkedHashMap *
antlr_linked_hash_map_new (void)
{
    AntlrLinkedHashMap *object = g_object_new (ANTLR_TYPE_LINKED_HASH_MAP, NULL);
    antlr_linked_hash_map_super (object, g_direct_hash, g_direct_equal, NULL, NULL);
    return object;
}

AntlrLinkedHashMap *
antlr_linked_hash_map_new_full (GHashFunc       hash_func,
                                GEqualFunc      key_equal_func,
                                GDestroyNotify  key_destroy_func,
                                GDestroyNotify  value_destroy_func)
{
    AntlrLinkedHashMap *object = g_object_new (ANTLR_TYPE_LINKED_HASH_MAP, NULL);
    antlr_linked_hash_map_super (object, hash_func, key_equal_func, key_destroy_func, value_destroy_func);
    return object;
}

/**
 * antlr_linked_hash_map_put:
 * @self: Some #AntlrLinkedHashMap
 * @key: The key
 * @value: The value
 *
 * Returns value or %NULL if not set
 * Associates the specified value with the specified key in this map. If the map previously contained a mapping for the key, the old value is replaced.
 */
gpointer
antlr_linked_hash_map_put (AntlrLinkedHashMap *self, gpointer key, gpointer value)
{
    gpointer prev = NULL;
    //gboolean inserted;

    prev = g_hash_table_lookup(self->table, (gconstpointer)key);
    g_hash_table_insert(self->table, (gpointer)key, (gpointer)value);

//#if GLIB_CHECK_VERSION (2, 40, 2)
//    inserted = g_hash_table_insert(self->table, key, value);
//#else
//    inserted = ! g_hash_table_contains(self->table, key);
//    g_hash_table_insert(self->table, key, value);
//#endif

    if (prev) {
        GList *node = g_list_find(self->header, prev);
        node->data = value;
    } else {
        self->header = g_list_append(self->header, value);
    }

    return prev;
}

gpointer
antlr_linked_hash_map_get (AntlrLinkedHashMap *self, gpointer key)
{
    gpointer value = g_hash_table_lookup(self->table, (gconstpointer)key);

    return value;
}
