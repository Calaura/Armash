/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-token.c
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "types.h"

#include "misc/object.h"

#include "int-stream.h"
#include "char-stream.h"
#include "token.h"

#include "token-source.h"


G_DEFINE_INTERFACE (AntlrTokenSource, antlr_token_source, ANTLR_TYPE_OBJECT)

static void
antlr_token_source_default_init (AntlrTokenSourceInterface *iface)
{
    /* add properties and signals to the interface here */
}

AntlrToken*
antlr_token_source_next_token (AntlrTokenSource *token_source)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_SOURCE (token_source), NULL);

    return ANTLR_TOKEN_SOURCE_GET_INTERFACE (token_source)->next_token (token_source);
}

int
antlr_token_source_get_line(AntlrTokenSource *token_source)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_SOURCE (token_source), -1);

    return ANTLR_TOKEN_SOURCE_GET_INTERFACE (token_source)->get_line (token_source);
}

int
antlr_token_source_get_char_position_in_line(AntlrTokenSource *token_source)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_SOURCE (token_source), -1);

    return ANTLR_TOKEN_SOURCE_GET_INTERFACE (token_source)->get_char_position_in_line (token_source);
}

AntlrCharStream*
antlr_token_source_get_input_stream(AntlrTokenSource *token_source)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_SOURCE (token_source), NULL);

    return ANTLR_TOKEN_SOURCE_GET_INTERFACE (token_source)->get_input_stream (token_source);
}

char*
antlr_token_source_get_source_name(AntlrTokenSource *token_source)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_SOURCE (token_source), NULL);

    return ANTLR_TOKEN_SOURCE_GET_INTERFACE (token_source)->get_source_name (token_source);
}

void
antlr_token_source_set_token_factory(AntlrTokenSource *token_source, AntlrTokenFactory* factory)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_SOURCE (token_source), NULL);

    ANTLR_TOKEN_SOURCE_GET_INTERFACE (token_source)->set_token_factory (token_source, factory);
}

AntlrTokenFactory*
antlr_token_source_get_token_factory(AntlrTokenSource *token_source)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_SOURCE (token_source), NULL);

    return ANTLR_TOKEN_SOURCE_GET_INTERFACE (token_source)->get_token_factory (token_source);
}

