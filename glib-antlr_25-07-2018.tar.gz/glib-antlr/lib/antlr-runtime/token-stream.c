/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * [The "BSD license"]
 *  Copyright (C) 2016 Gaulouis <gaulouis.com@gmail.com>
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 *  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 *  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <glib-object.h>

#include "types.h"
#include "misc/object.h"
#include "misc/interval.h"

#include "int-stream.h"
#include "token-stream.h"

/**
 * SECTION:token-stream
 * @title: AntlrTokenStream
 * @short_description: An AntlrIntStream whose symbols are AntlrToken instances.
 * @stability: Unstable
 * @see_also: #AntlrToken
 *
 */

G_DEFINE_INTERFACE (AntlrTokenStream, antlr_token_stream, ANTLR_TYPE_INT_STREAM)

static void
antlr_token_stream_default_init (AntlrTokenStreamInterface *iface)
{
    /* add properties and signals to the interface here */
}

/**
 * antlr_token_stream_LT:
 * @token_stream: Some #AntlrTokenStream
 * @k: parameter k
 *
 * Get the #AntlrToken instance associated with the value returned by
 * #antlr_int_stream_LA(k). This method has the same pre- and post-conditions as
 * #antlr_int_stream_LA. In addition, when the preconditions of this method
 * are met, the return value is non-null and the value of
 * #antlr_token_stream_LT(k).#antlr_token_get_token_type()==#antlr_int_stream_LA(k).
 *
 * @see #antlr_int_stream_LA
 */
AntlrToken*
antlr_token_stream_LT(AntlrTokenStream *token_stream, gint k)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_STREAM (token_stream), NULL);

    return ANTLR_TOKEN_STREAM_GET_INTERFACE (token_stream)->LT (token_stream, k);
}

/**
 * antlr_token_stream_get:
 * @token_stream: Some #AntlrTokenStream
 * @index: The index
 *
 * Gets the #AntlrToken at the specified #antlr_int_stream_index in the stream. When
 * the preconditions of this method are met, the return value is non-%NULL.
 *
 * The preconditions for this method are the same as the preconditions of
 * #antlr_int_stream_seek. If the behavior of #antlr_int_stream_seek(@index) is
 * unspecified for the current state and given #antlr_token_stream_get_index, then the
 * behavior of this method is also unspecified.
 *
 * The symbol referred to by #antlr_token_stream_get_index differs from #antlr_int_stream_seek() only
 * in the case of filtering streams where #antlr_token_stream_get_index lies before the end
 * of the stream. Unlike #antlr_int_stream_seek(), this method does not adjust
 * #antlr_token_stream_get_index to point to a non-ignored symbol.
 *
 */
AntlrToken*
antlr_token_stream_get (AntlrTokenStream* token_stream, gint index) // @throws IllegalArgumentException if {code index} is less than 0
                                                                    // @throws UnsupportedOperationException if the stream does not support retrieving the token at the specified index
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_STREAM (token_stream), NULL);

    return ANTLR_TOKEN_STREAM_GET_INTERFACE (token_stream)->get (token_stream, index);
}

/**
 * antlr_token_stream_get_token_source:
 * @token_stream: Some #AntlrTokenStream
 *
 * Gets the underlying #AntlrTokenSource which provides tokens for this stream.
 *
 * Retuns: The tokens of this tream
 */
AntlrTokenSource*
antlr_token_stream_get_token_source (AntlrTokenStream* token_stream)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_STREAM (token_stream), NULL);

    return ANTLR_TOKEN_STREAM_GET_INTERFACE (token_stream)->get_token_source (token_stream);
}


/**
 * antlr_token_stream_get_text:
 * @token_stream: Some #AntlrTokenStream
 *
 * Return the text of all tokens in the stream. This method behaves like the
 * following code, including potential exceptions from the calls to
 * #antlr_int_stream_size and #antlr_token_stream_get_text(Interval), but may be
 * optimized by the specific implementation.
 *
 * |[<!-- language="C" -->
 * AntlrTokenStream stream = ...;
 * String text = antlr_token_stream_get_text(stream, new Interval(0, stream.size()));
 * ]|
 *
 * Returns: The text of all tokens in the stream.
 */
gchar *antlr_token_stream_get_text(AntlrTokenStream *token_stream)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_STREAM (token_stream), NULL);
    AntlrTokenStreamInterface *iface = ANTLR_TOKEN_STREAM_GET_INTERFACE (token_stream);

    return iface->get_text (token_stream);
}

/**
 * antlr_token_stream_get_text_from_interval:
 * @token_stream: Some #AntlrTokenStream
 * @interval: The interval of tokens within this stream to get text
 * for.
 *
 * Return the text of all tokens within the specified #antlr_token_stream_get_text_from_interval:interval. This
 * method behaves like the following code (including potential exceptions
 * for violating preconditions of #antl_token_stream_get, but may be optimized by the
 * specific implementation.
 *
 * A C-language example:
 * |[<!-- language="C" -->
 * AntlrTokenStream *stream = ...;
 * GString *text = "";
 * for (int i = interval.a; i &lt;= interval.b; i++) {
 *   text += stream.get(i).getText();
 * }
 * ]|
 *
 * Returns: The text of all tokens within the specified interval in this
 * stream.
 */
gchar*
antlr_token_stream_get_text_from_interval (AntlrTokenStream* token_stream, AntlrInterval *interval)// @throws NullPointerException if {@code interval} is %NULL
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_STREAM (token_stream), NULL);

    return ANTLR_TOKEN_STREAM_GET_INTERFACE (token_stream)->get_text_from_interval (token_stream, interval);
}

/**
 * antlr_token_stream_get_text_from_context:
 * @token_stream: Some #AntlrTokenStream
 * @ctx: The context providing the source interval of tokens to get
 * text for.
 *
 * Return the text of all tokens in the source interval of the specified
 * context. This method behaves like the following code, including potential
 * exceptions from the call to #antlr_token_stream_get_text_from_interval(), but may be
 * optimized by the specific implementation.
 *
 * If #antlr_syntax_tree_get_source_interval() does not return a valid interval of
 * tokens provided by this stream, the behavior is unspecified.
 *
 * |[<!-- language="C" -->
 * AntlrTokenStream *stream = ...;
 * AntlrInterval *interval = antlr_syntax_tree_get_source_interval(ANTLR_SYNTAX_TREE(ctx));
 * gchar *text = antlr_token_stream_get_text_from_interval(stream, interval);
 * g_free(text);
 * g_object_unref(interval);
 * ]|
 *
 *
 * Returns: The text of all tokens within the source interval of @ctx.
 */
gchar*
antlr_token_stream_get_text_from_context (AntlrTokenStream* token_stream, AntlrRuleContext *ctx)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_STREAM (token_stream), NULL);

    return ANTLR_TOKEN_STREAM_GET_INTERFACE (token_stream)->get_text_from_context (token_stream, ctx);
}

/**
 * antlr_token_stream_get_text_from_token:
 * @token_stream: Some #AntlrTokenStream
 * @start: The first token in the interval to get text for.
 * @stop: The last token in the interval to get text for (inclusive).
 *
 * Return the text of all tokens in this stream between #antlr_token_stream_get_text_from_token:@start and
 * #antlr_token_stream_get_text_from_token:@stop (inclusive).
 *
 * If the specified #antlr_token_stream_get_text_from_token:@start or #antlr_token_stream_get_text_from_token:@stop token was not provided by
 * this stream, or if the #antlr_token_stream_get_text_from_token:stop occurred before the #antlr_token_stream_get_text_from_token:start
 * token, the behavior is unspecified.
 *
 * For streams which ensure that the {@link Token#getTokenIndex} method is
 * accurate for all of its provided tokens, this method behaves like the
 * following code. Other streams may implement this method in other ways
 * provided the behavior is consistent with this at a high level.
 *
 * |[<!-- language="C" -->
 * TokenStream stream = ...;
 * GString text = "";
 * for (int i = start.getTokenIndex(); i &lt;= stop.getTokenIndex(); i++) {
 *   text += stream.get(i).getText();
 * }
 * ]|
 *
 * Returns: The text of all tokens lying between the specified @start
 * and @stop tokens.
 */
gchar *antlr_token_stream_get_text_from_token(AntlrTokenStream* token_stream, AntlrToken *start, AntlrToken *stop)// @throws UnsupportedOperationException if this stream does not support this method for the specified tokens
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_STREAM (token_stream), NULL);

    return ANTLR_TOKEN_STREAM_GET_INTERFACE (token_stream)->get_text_from_token (token_stream, start, stop);
}
