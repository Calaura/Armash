/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-lexer.c
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * SECTION:lexer
 * @title: AntlrLexer
 * @short_description: Lexer
 * @stability: Unstable
 *
 * A lexer is recognizer that draws input symbols from a character stream.
 * lexer grammars result in a subclass of this object.
 * A Lexer object uses simplified match() and error recovery mechanisms
 * in the interest of speed.
 */


#include <glib-object.h>

#include "types.h"


#include "misc/object.h"
#include "misc/bit-set.h"
#include "misc/int-iset.h"
#include "misc/interval.h"
#include "vocabulary.h"
#include "vocabulary-impl.h"
#include "misc/interval-set.h"
#include "misc/integer-list.h"
#include "misc/integer-stack.h"
#include "atn/transition.h"
#include "atn/lexer-action.h"
#include "atn/atn-state.h"
#include "atn/rule-stop-state.h"
#include "atn/rule-start-state.h"
#include "atn/atn.h"
#include "atn/prediction-context.h"
#include "atn/prediction-context-cache.h"
#include "atn/atn-simulator.h"

#include "atn/semantic-context.h"
#include "atn/config.h"
#include "atn/config-set.h"

#include "atn/lexer-action-executor.h"
#include "atn/decision-state.h"
#include "dfa/dfa-state.h"
#include "dfa/dfa.h"
#include "atn/lexer-atn-simulator.h"
#include "recognizer.h"

#include "int-stream.h"
#include "token-source.h"
#include "token-stream.h"
#include "token.h"
#include "token-factory.h"
#include "common-token-factory.h"
#include "char-stream.h"
#include "error-listener.h"

#include "lexer.h"

static AntlrToken *antlr_lexer_default_emit(AntlrLexer *self);
static void antlr_lexer_reset(AntlrLexer *lexer);
static void antlr_lexer_class_object_finalize (GObject *object);
static void antlr_lexer_class_object_dispose (GObject *object);

/**
 * antlr_lexer_interface_token_source_next_token:
 * @token_source: Some #AntlrTokenSource
 *
 * Returns: a token from this source; i.e., match a token on the char
 *  stream.
 */
AntlrToken *
antlr_lexer_interface_token_source_next_token(AntlrTokenSource *token_source) {
    AntlrToken *ret = NULL;
    AntlrLexer *lexer = ANTLR_LEXER(token_source);


    if (lexer->input == NULL) {
        /*GError *error = */g_error_new(g_quark_from_string("ANTLR"), 600, "Error::IllegalState: \"%s\"", "nextToken requires a non-null input stream.");
    }

    // Mark start location in char stream so unbuffered streams are
    // guaranteed at least have text of current token
    gint token_start_marker = antlr_int_stream_mark(ANTLR_INT_STREAM(lexer->input));

outer:
    while (TRUE)
    {
        if (lexer->hit_EOF) {
            antlr_lexer_emit_eof(lexer);
            antlr_int_stream_release(ANTLR_INT_STREAM(lexer->input), token_start_marker);// finaly
            return lexer->token;
        }
        lexer->token = NULL;
        lexer->channel = ANTLR_TOKEN_DEFAULT_CHANNEL;
        lexer->token_start_char_index = antlr_int_stream_index(ANTLR_INT_STREAM(lexer->input));
        AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(lexer));
        lexer->token_start_char_position_in_line = antlr_lexer_atn_simulator_get_char_position_in_line(ANTLR_LEXER_ATN_SIMULATOR(interpreter));
        lexer->token_start_line = antlr_lexer_atn_simulator_get_line(ANTLR_LEXER_ATN_SIMULATOR(interpreter));
        lexer->text = NULL;

        do {
            lexer->type = ANTLR_TOKEN_INVALID_TYPE;
/*
            g_print("nextToken line %d at '%c' in mode %d at index %d\n",
                    lexer->token_start_line,
                    antlr_int_stream_LA(lexer->input, 1),
                    lexer->mode,
                    lexer->token_start_char_index
                    );
*/

            GError *error = NULL;
            gint ttype = antlr_lexer_atn_simulator_match(ANTLR_LEXER_ATN_SIMULATOR(interpreter), lexer->input, lexer->mode, &error);
            if (error!=NULL) {// && error->code==ANTLR_ERROR_CODE_LEXER_NO_VIABLE_ALT
                antlr_lexer_notify_listeners(ANTLR_LEXER(token_source), &error);// report error
                antlr_lexer_recover(ANTLR_LEXER(token_source), &error); g_clear_error(&error);
                ttype = ANTLR_LEXER_SKIP;
            }
            if ( antlr_int_stream_LA(ANTLR_INT_STREAM(lexer->input), 1)==ANTLR_INT_STREAM_EOF ) {
                lexer->hit_EOF = TRUE;
            }
            if ( lexer->type == ANTLR_TOKEN_INVALID_TYPE ) {
                lexer->type = ttype;
            }
            if ( lexer->type ==ANTLR_LEXER_SKIP ) {
                goto outer;
            }

        } while ( lexer->type ==ANTLR_LEXER_MORE );

        if ( lexer->token == NULL ) antlr_lexer_emit(lexer);

        antlr_int_stream_release(ANTLR_INT_STREAM(lexer->input), token_start_marker);// finaly
        return lexer->token;

    }

    //finally {
        // make sure we release marker after match or
        // unbuffered char stream will keep buffering
        //TODO :
        ///_input.release(tokenStartMarker);
        antlr_int_stream_release(ANTLR_INT_STREAM(lexer->input), token_start_marker);
    //}

    return ret;
}

static void               antlr_lexer_class_recognizer_set_token_factory(AntlrRecognizer *self, AntlrTokenFactory *factory);
static AntlrTokenFactory *antlr_lexer_class_recognizer_get_token_factory(AntlrRecognizer *self);
static void               antlr_lexer_class_recognizer_set_input_stream(AntlrRecognizer *self, AntlrIntStream *input);

static gint               antlr_lexer_interface_token_source_get_line(AntlrTokenSource*self);
static gint               antlr_lexer_interface_token_source_get_char_position_in_line(AntlrTokenSource*self);
static char *antlr_lexer_interface_token_source_get_source_name(AntlrTokenSource *self);
static AntlrCharStream   *antlr_lexer_interface_token_source_get_input_stream(AntlrTokenSource *self);


static void antlr_lexer_interface_token_source_init(AntlrTokenSourceInterface *iface);
static void antlr_lexer_interface_int_stream_init (AntlrIntStreamInterface *iface);
static void antlr_lexer_interface_token_stream_init (AntlrTokenStreamInterface *iface);

G_DEFINE_TYPE_WITH_CODE (AntlrLexer, antlr_lexer, ANTLR_TYPE_RECOGNIZER,
                         G_IMPLEMENT_INTERFACE (ANTLR_TYPE_INT_STREAM,
                                                antlr_lexer_interface_int_stream_init)
                         G_IMPLEMENT_INTERFACE (ANTLR_TYPE_TOKEN_STREAM,
                                                antlr_lexer_interface_token_stream_init)
                         G_IMPLEMENT_INTERFACE (ANTLR_TYPE_TOKEN_SOURCE,
                                                antlr_lexer_interface_token_source_init)
                         )

static void
antlr_lexer_interface_int_stream_init (AntlrIntStreamInterface *iface)
{
//    iface->consume = NULL;
//    iface->get_source_name = NULL;
//    iface->index = NULL;
//    iface->LA = NULL;
//    iface->mark = NULL;
//    iface->release = NULL;
//    iface->seek = NULL;
//    iface->size = NULL;
}

static void
antlr_lexer_interface_token_stream_init (AntlrTokenStreamInterface *iface)
{
//    iface->get = NULL;
//    iface->get_text = NULL;
//    iface->get_text_from_interval = NULL;
//    iface->get_text_from_token = NULL;
//    iface->get_token_source = NULL;
//    iface->LT = NULL;
}


static void
antlr_lexer_interface_token_source_set_token_factory(AntlrTokenSource *token_source, AntlrTokenFactory *factory) {
    ANTLR_LEXER(token_source)->factory = factory;
}

static AntlrTokenFactory*
antlr_lexer_interface_token_source_get_token_factory(AntlrTokenSource *token_source) {
    return ANTLR_LEXER(token_source)->factory;
}

static void
antlr_lexer_interface_token_source_init (AntlrTokenSourceInterface *iface)
{
    iface->get_char_position_in_line = antlr_lexer_interface_token_source_get_char_position_in_line;
    iface->get_input_stream = antlr_lexer_interface_token_source_get_input_stream;
    iface->get_line = antlr_lexer_interface_token_source_get_line;
    iface->get_source_name = antlr_lexer_interface_token_source_get_source_name;
    iface->next_token = antlr_lexer_interface_token_source_next_token;

    iface->get_token_factory = antlr_lexer_interface_token_source_get_token_factory;
    iface->set_token_factory = antlr_lexer_interface_token_source_set_token_factory;
}

AntlrIntStream*
antlr_lexer_class_recognizer_get_input_stream(AntlrRecognizer *recognizer)
{
    return ANTLR_INT_STREAM(antlr_lexer_interface_token_source_get_input_stream(ANTLR_TOKEN_SOURCE(recognizer)));
}

static void
antlr_lexer_class_init (AntlrLexerClass *klass)
{
    GObjectClass* object_class = G_OBJECT_CLASS (klass);
    AntlrRecognizerClass* recognizer_class = ANTLR_RECOGNIZER_CLASS (klass);

    object_class->finalize = antlr_lexer_class_object_finalize;
    object_class->dispose = antlr_lexer_class_object_dispose;

    //recognizer_class->set_token_factory = antlr_lexer_class_recognizer_set_token_factory;
    //recognizer_class->get_token_factory = antlr_lexer_class_recognizer_get_token_factory;
    recognizer_class->get_input_stream = antlr_lexer_class_recognizer_get_input_stream;
    recognizer_class->set_input_stream = antlr_lexer_class_recognizer_set_input_stream;

    klass->lexer_emit = antlr_lexer_default_emit;
}

/* interface TokenSource */
static char*
antlr_lexer_interface_token_source_get_source_name(AntlrTokenSource *obj) {
    AntlrLexer *self = ANTLR_LEXER(obj);
    return antlr_int_stream_get_source_name(ANTLR_INT_STREAM(self->input));
}

static AntlrCharStream*
antlr_lexer_interface_token_source_get_input_stream(AntlrTokenSource *self) {
    return ANTLR_LEXER(self)->input;
}


/**
 * antlr_lexer_class_recognizer_set_input_stream:
 * @self: Some #AntlrRecognizer
 * @input: The #AntlrIntStream instance
 *
 * Set the char stream and reset the lexer
 */
static void
antlr_lexer_class_recognizer_set_input_stream(AntlrRecognizer *self, AntlrIntStream *input) {
    ANTLR_LEXER(self)->input = NULL;
    // self->token_factory_source = new Pair<TokenSource, CharStream>(this, _input);
    ANTLR_LEXER(self)->token_factory_source.a = ANTLR_TOKEN_SOURCE(self);
    ANTLR_LEXER(self)->token_factory_source.b = ANTLR_CHAR_STREAM(ANTLR_LEXER(self)->input);

    antlr_lexer_reset(ANTLR_LEXER(self));
    ANTLR_LEXER(self)->input = (AntlrCharStream*)input;
    //self->token_factory_source = new Pair<TokenSource, CharStream>(this, _input);
    ANTLR_LEXER(self)->token_factory_source.a = ANTLR_TOKEN_SOURCE(self);
    ANTLR_LEXER(self)->token_factory_source.b = ANTLR_CHAR_STREAM(ANTLR_LEXER(self)->input);
}

static void
antlr_lexer_class_object_dispose (GObject *object)
{
    AntlrLexer *self = ANTLR_LEXER(object);

    if (self->factory) {
        g_clear_object(&self->factory);
    }
    if (self->mode_stack) {
        g_clear_object(&self->mode_stack);
    }

    G_OBJECT_CLASS (antlr_lexer_parent_class)->dispose (object);
}

static void
antlr_lexer_class_object_finalize (GObject *object)
{
    /* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (antlr_lexer_parent_class)->finalize (object);
}

static void
antlr_lexer_init (AntlrLexer *antlr_lexer)
{
    //antlr_common_token_factory_get_default();
    antlr_lexer->factory = ANTLR_TOKEN_FACTORY(antlr_common_token_factory_new());

    antlr_lexer->mode_stack = antlr_integer_stack_new();
}

AntlrLexer*
antlr_lexer_new (void)
{
    AntlrLexer *lexer;
    lexer = g_object_new(ANTLR_TYPE_LEXER, NULL);
    return lexer;
}

/**
 * antlr_lexer_super_with_char_stream:
 * @type: Some #GType
 * @char_stream: Some #AntlrCharStream
 *
 * A lexer is recognizer that draws input symbols from a character stream.
 * lexer grammars result in a subclass of this object. A Lexer object
 * uses simplified match() and error recovery mechanisms in the interest
 * of speed.
 *
 * Returns: #AntlrLexer recognizer
 */
AntlrLexer*
antlr_lexer_super_with_char_stream (GType type, AntlrCharStream *char_stream)
{
    AntlrLexer *lexer;

    lexer = g_object_new(type, NULL);
    lexer->input = char_stream;
    lexer->token_factory_source.a = ANTLR_TOKEN_SOURCE(lexer);
    lexer->token_factory_source.b = char_stream;

    return lexer;
}
AntlrLexer*
antlr_lexer_new_from_char_stream (AntlrCharStream *char_stream)
{
    AntlrLexer *lexer = antlr_lexer_super_with_char_stream(ANTLR_TYPE_LEXER, char_stream);
    return lexer;
}

static void
antlr_lexer_reset(AntlrLexer *lexer) {
    // wack Lexer state variables
    if ( lexer->input !=NULL ) {
        antlr_int_stream_seek(ANTLR_INT_STREAM(lexer->input), 0); // rewind the input
    }
    lexer->token = NULL;
    lexer->type = ANTLR_TOKEN_INVALID_TYPE;
    lexer->channel = ANTLR_TOKEN_DEFAULT_CHANNEL;
    lexer->token_start_char_index = -1;
    lexer->token_start_char_position_in_line = -1;
    lexer->token_start_line = -1;
    lexer->text = NULL;

    lexer->hit_EOF = FALSE;
    lexer->mode = ANTLR_LEXER_DEFAULT_MODE;
    lexer->mode_stack = antlr_integer_stack_new();//.clear();

    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(lexer));
    antlr_atn_simulator_reset(interpreter);
}

static gint
antlr_lexer_interface_token_source_get_line(AntlrTokenSource*self) {
    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    return antlr_lexer_atn_simulator_get_line(ANTLR_LEXER_ATN_SIMULATOR(interpreter));
}

static gint
antlr_lexer_interface_token_source_get_char_position_in_line(AntlrTokenSource*self) {
    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    return antlr_lexer_atn_simulator_get_char_position_in_line(ANTLR_LEXER_ATN_SIMULATOR(interpreter));
}

void
antlr_lexer_set_line(AntlrLexer *self, gint line) {
    AntlrATNInterpreter* interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    antlr_lexer_atn_simulator_set_line(ANTLR_LEXER_ATN_SIMULATOR(interpreter), line);
}

void
antlr_lexer_set_char_position_in_line(AntlrLexer *self, gint char_position_in_line) {
    AntlrATNInterpreter* interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    antlr_lexer_atn_simulator_set_char_position_in_line(ANTLR_LEXER_ATN_SIMULATOR(interpreter), char_position_in_line);
}

/**
 * antlr_lexer_get_char_index:
 * @self: Some #AntlrLexer
 *
 * What is the index of the current character of lookahead?
 */
gint
antlr_lexer_get_char_index(AntlrLexer *self) {
    return antlr_int_stream_index(ANTLR_INT_STREAM(ANTLR_LEXER(self)->input));
}

/**
 * antlr_lexer_get_text:
 * @self: Some #AntlrLexer
 *
 * Return the text matched so far for the current token or any
 *  text override.
 */
gchar*
antlr_lexer_get_text(AntlrLexer *self) {
    if ( self->text != NULL ) {
        return self->text->str;
    }
    AntlrATNInterpreter* interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    return antlr_lexer_atn_simulator_get_text(ANTLR_LEXER_ATN_SIMULATOR(interpreter), self->input);
}
/**
 * antlr_lexer_set_text:
 * @self: Some #AntlrLexer
 * @text: The text
 *
 * Set the complete text of this token; it wipes any previous
 *  changes to the text.
 */
void
antlr_lexer_set_text(AntlrLexer *self, gchar *text) {
    self->text = g_string_new(text);
}

/**
 * antlr_lexer_get_token:
 * @self: Some #AntlrLexer
 *
 * Override if emitting multiple tokens.
 *
 */
AntlrToken*
antlr_lexer_get_token(AntlrLexer *self) {
    return self->token;
}

void
antlr_lexer_set_token(AntlrLexer *self, AntlrToken *token) {
    self->token = token;
}

void
antlr_lexer_set_lexer_type(AntlrLexer *self, gint ttype) {
    self->type = ttype;
}

gint
antlr_lexer_get_lexer_type(AntlrLexer *self) {
    return self->type;
}

void
antlr_lexer_set_channel(AntlrLexer *self, gint channel) {
    self->channel = channel;
}

gint
antlr_lexer_get_channel(AntlrLexer *self) {
    return self->channel;
}

GString**
antlr_lexer_get_mode_names(AntlrLexer *self) {
    return NULL;
}

void
antlr_lexer_mode(AntlrLexer *self, gint mode) {
    self->mode = mode;
}
/**
 * antlr_lexer_skip:
 * @self: Some #AntlrLexer
 *
 * Instruct the lexer to skip creating a token for current lexer rule
 *  and look for another token.  nextToken() knows to keep looking when
 *  a lexer rule finishes with token set to SKIP_TOKEN.  Recall that
 *  if token==null at end of any token rule, it creates one for you
 *  and emits it.
 */
void
antlr_lexer_skip(AntlrLexer *self)
{
    self->type = ANTLR_LEXER_SKIP;
}

void
antlr_lexer_more(AntlrLexer *self)
{
    self->type = ANTLR_LEXER_MORE;
}

void
antlr_lexer_push_mode(AntlrLexer *self, gint m) {
    if (ANTLR_LEXER_ATN_SIMULATOR(ANTLR_RECOGNIZER(self)->interp)->debug)
        g_print("pushMode %d\n", m);

    antlr_integer_stack_push(self->mode_stack, self->mode);
    antlr_lexer_mode(self, m);
}

#include "misc/integer-stack.h"
gint
antlr_lexer_pop_mode(AntlrLexer *self) {
//    if ( _modeStack.isEmpty() )
//            throw new EmptyStackException();
//    if ( LexerATNSimulator.debug )
//        System.out.println("popMode back to "+ _modeStack.peek());
    if (ANTLR_LEXER_ATN_SIMULATOR(ANTLR_RECOGNIZER(self)->interp)->debug) {
        g_print("popMode back to %d\n", antlr_integer_stack_peek(self->mode_stack));
    }
    antlr_lexer_mode(self, antlr_integer_stack_pop(self->mode_stack));
    return self->mode;
}


void
antlr_lexer_recover(AntlrLexer *self, GError**error/*LexerNoViableAltException e*/) {
    gint la = antlr_int_stream_LA(ANTLR_INT_STREAM(self->input), 1);
    if (la!=ANTLR_INT_STREAM_EOF) {
        // skip a char and try again
        AntlrATNInterpreter *interpreter= antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
        antlr_lexer_atn_simulator_consume(ANTLR_LEXER_ATN_SIMULATOR(interpreter), self->input);
    }
}

/*
public String getErrorDisplay(int c) {
    String s = String.valueOf((char)c);
    switch ( c ) {
        case Token.EOF :
            s = "<EOF>";
            break;
        case '\n' :
            s = "\\n";
            break;
        case '\t' :
            s = "\\t";
            break;
        case '\r' :
            s = "\\r";
            break;
    }
    return s;
}
*/
gchar*
antlr_lexer_get_error_display(AntlrLexer *self, gchar *s) {
    // TODO refactor name by escape_string
    return g_strdup(s);
    /*
    StringBuilder buf = new StringBuilder();
    for (char c : s.toCharArray()) {
        buf.append(getErrorDisplay(c));
    }
    return buf.toString();
    */
}

void
antlr_lexer_notify_listeners(AntlrLexer *self, GError**error/*LexerNoViableAltException e*/) {
    gint a = self->token_start_char_index;
    gint b = antlr_int_stream_index(ANTLR_INT_STREAM(self->input));
    AntlrInterval *interval = antlr_interval_of(a, b);
    gchar *text = antlr_char_stream_get_text(ANTLR_CHAR_STREAM(self->input), interval);
    gchar *str = antlr_lexer_get_error_display(self, text);
    gchar *msg = g_strdup_printf("token recognition error at: '%s'", str);

    AntlrErrorListener *listener = antlr_recognizer_get_error_listener_dispatch(ANTLR_RECOGNIZER(self));
    antlr_error_listener_syntax_error(ANTLR_ERROR_LISTENER(listener),
                                      ANTLR_RECOGNIZER(self),
                                      NULL,
                                      self->token_start_line,
                                      self->token_start_char_position_in_line,
                                      msg,
                                      error);
    g_free(text);
    g_free(str);
    g_free(msg);
}

/**
 * antlr_lexer_emit_with_token:
 * @self: Some #AntlrLexer
 * @token: Some #AntlrToken instance
 *
 * By default does not support multiple emits per nextToken invocation
 *  for efficiency reasons.  Subclass and override this method, nextToken,
 *  and getToken (to push tokens into a list and pull from that list
 *  rather than a single variable as this implementation does).
 */
void
antlr_lexer_emit_with_token(AntlrLexer *self, AntlrToken *token) {
    //System.err.println("emit "+token);
    self->token = token;
}

static AntlrToken*
antlr_lexer_default_emit(AntlrLexer *self) {
    gchar *text = self->text ? self->text->str : NULL;
    AntlrSymbole *s;
    AntlrToken *t;
    s = antlr_token_factory_create(self->factory,
                                   self->token_factory_source,
                                   self->type,
                                   text /*lexer->text->str*/,
                                   self->channel,
                                   self->token_start_char_index,
                                   antlr_lexer_get_char_index(self)-1,
                                   self->token_start_line,
                                   self->token_start_char_position_in_line);
//    t = _factory.create(_tokenFactorySourcePair, _type, _text, _channel, _tokenStartCharIndex, getCharIndex()-1,
//                              _tokenStartLine, _tokenStartCharPositionInLine);
    t = ANTLR_TOKEN(s);
    antlr_lexer_emit_with_token(self, t);
    return t;
}

/**
 * antlr_lexer_emit:
 * @self: Some #AntlrLexer
 *
 * The standard method called to automatically emit a token at the
 *  outermost lexical rule.  The token object should point into the
 *  char buffer start..stop.  If there is a text override in 'text',
 *  use that to set the token's text.  Override this method to emit
 *  custom Token objects or provide a new factory.
 */
AntlrToken*
antlr_lexer_emit(AntlrLexer *self) {
    return ANTLR_LEXER_GET_CLASS(self)->lexer_emit(self);
}

AntlrToken*
antlr_lexer_emit_eof(AntlrLexer *lexer) {
    //int cpos = getCharPositionInLine();
    gint cpos = antlr_token_source_get_char_position_in_line(ANTLR_TOKEN_SOURCE(lexer));
    //int line = getLine();
    gint line = antlr_token_source_get_line(ANTLR_TOKEN_SOURCE(lexer));
    AntlrSymbole *s;
    AntlrToken *eof;
    s = antlr_token_factory_create(lexer->factory,
                                     lexer->token_factory_source,
                                     ANTLR_TOKEN_EOF,
                                     NULL,
                                     ANTLR_TOKEN_DEFAULT_CHANNEL,
                                     antlr_int_stream_index(ANTLR_INT_STREAM(lexer->input)),
                                     antlr_int_stream_index(ANTLR_INT_STREAM(lexer->input))-1,
                                     line,
                                     cpos);
//    eof = _factory.create(_tokenFactorySourcePair, Token.EOF, null, Token.DEFAULT_CHANNEL, _input.index(), _input.index()-1,
//                                line, cpos);
    eof = ANTLR_TOKEN(s);
    antlr_lexer_emit_with_token(lexer, eof);
    return eof;
}
