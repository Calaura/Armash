#include <glib-object.h>

#include "types.h"
#include "int-stream.h"
#include "misc/object.h"
#include "misc/interval.h"

#include "token-factory.h"

G_DEFINE_INTERFACE(AntlrTokenFactory, antlr_token_factory, 0)

static void
antlr_token_factory_default_init (AntlrTokenFactoryInterface *iface)
{
    /* add properties and signals to the interface here */
}

/**
 * antlr_token_factory_create:
 * @self: Some #AntlrTokenFactory
 * @source: Some #AntlrSource
 * @type: The type
 * @text: The text
 * @channel: The channel
 * @start: The start
 * @stop: The stop
 * @line: The line
 * @char_position_in_line: The char position in line
 *
 * This is the method used to create tokens in the lexer and in the
 *  error handling strategy. If text!=null, than the start and stop positions
 *  are wiped to -1 in the text override is set in the CommonToken.
 */
AntlrSymbole *
antlr_token_factory_create(AntlrTokenFactory *self, AntlrSource source, gint type, gchar *text,
                           gint channel, gint start, gint stop, gint line, gint char_position_in_line)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_FACTORY (self), NULL);

    return ANTLR_TOKEN_FACTORY_GET_INTERFACE (self)->create (self, source, type, text, channel, start, stop, line, char_position_in_line);
}

/**
 * antlr_token_factory_create_from:
 * @self: Some #AntlrTokenFactory
 * @type: The type
 * @text: The text
 *
 * Generically useful
 */
AntlrSymbole *
antlr_token_factory_create_from(AntlrTokenFactory *self, gint type, gchar *text)
{
    g_return_val_if_fail (ANTLR_IS_TOKEN_FACTORY (self), NULL);

    return ANTLR_TOKEN_FACTORY_GET_INTERFACE (self)->create_from (self, type, text);
}
