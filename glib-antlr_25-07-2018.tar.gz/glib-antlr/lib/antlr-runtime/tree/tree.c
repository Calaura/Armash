/*
 * tree.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "tree.h"

G_DEFINE_INTERFACE(AntlrTree, antlr_tree, 0)

static void
antlr_tree_default_init(AntlrTreeInterface *iface) {
    /* Add properties and signals to the interface here */
}

AntlrTree*
antlr_tree_get_parent (AntlrTree *self)
{
    g_return_val_if_fail(ANTLR_IS_TREE(self), NULL);

    return ANTLR_TREE_GET_INTERFACE(self)->get_parent(self);
}

GObject*
antlr_tree_get_payload (AntlrTree *self)
{
    g_return_val_if_fail(ANTLR_IS_TREE(self), NULL);

    return ANTLR_TREE_GET_INTERFACE(self)->get_payload(self);
}

AntlrTree*
antlr_tree_get_child (AntlrTree *self, gint i)
{
    g_return_val_if_fail(ANTLR_IS_TREE(self), NULL);

    return ANTLR_TREE_GET_INTERFACE(self)->get_child(self, i);
}

gint
antlr_tree_get_child_count (AntlrTree *self)
{
    g_return_val_if_fail(ANTLR_IS_TREE(self), -1);

    return ANTLR_TREE_GET_INTERFACE(self)->get_child_count(self);
}

gchar*
antlr_tree_to_string_tree (AntlrTree *self, GArray *rule_names)
{
    g_return_val_if_fail(ANTLR_IS_TREE(self), NULL);

    AntlrTreeInterface *iface = ANTLR_TREE_GET_INTERFACE(self);
    if (NULL==iface->to_string_tree) {
        g_error("Interface AntlrTree::to_string_tree() not implemented in '%s'\n", g_type_name_from_instance((GTypeInstance*)self));
    }
    return iface->to_string_tree(self, rule_names);
}
