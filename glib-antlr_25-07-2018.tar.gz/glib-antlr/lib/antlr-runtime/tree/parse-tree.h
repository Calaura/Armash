/*
 * parse-tree.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_PARSE_TREE_H__
#define __ANTLR_PARSE_TREE_H__


#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_PARSE_TREE                (antlr_parse_tree_get_type ())
#define ANTLR_PARSE_TREE(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  ANTLR_TYPE_PARSE_TREE,  AntlrParseTree))
#define ANTLR_IS_PARSE_TREE(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  ANTLR_TYPE_PARSE_TREE))
#define ANTLR_PARSE_TREE_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  ANTLR_TYPE_PARSE_TREE,  AntlrParseTreeInterface))


typedef struct _AntlrParseTree  AntlrParseTree; /* dummy object */
typedef struct _AntlrParseTreeInterface  AntlrParseTreeInterface;

/**
 * AntlrParseTreeInterface:
 * @get_text:Return the combined text of all leaf nodes. Does not get any
 *  off-channel tokens (if any) so won't return whitespace and
 *  comments if they are sent to parser on hidden channel.
 *
 */
struct _AntlrParseTreeInterface
{
    /*< private >*/
    AntlrSyntaxTreeInterface parent_iface;

    /* The {@link ParseTreeVisitor} needs a double dispatch method. */
    //<T> T accept(ParseTreeVisitor<? extends T> visitor);
    //gpointer* (*accept) ( AntlrParseTree *self);

    /*< public >*/
    gchar* (*get_text) ( AntlrParseTree *self);
};

GType  antlr_parse_tree_get_type (void) G_GNUC_CONST;

gchar* antlr_parse_tree_get_text (AntlrParseTree *self);

G_END_DECLS

#endif /* __ANTLR_PARSE_TREE_H__ */

