/*
 * syntax-tree.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_SYNTAX_TREE_H__
#define __ANTLR_SYNTAX_TREE_H__


#include <glib-object.h>

G_BEGIN_DECLS

#define ANTLR_TYPE_SYNTAX_TREE                (antlr_syntax_tree_get_type ())
#define ANTLR_SYNTAX_TREE(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  ANTLR_TYPE_SYNTAX_TREE,  AntlrSyntaxTree))
#define ANTLR_IS_SYNTAX_TREE(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  ANTLR_TYPE_SYNTAX_TREE))
#define ANTLR_SYNTAX_TREE_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  ANTLR_TYPE_SYNTAX_TREE,  AntlrSyntaxTreeInterface))


typedef struct _AntlrSyntaxTree  AntlrSyntaxTree; /* dummy object */
typedef struct _AntlrSyntaxTreeInterface  AntlrSyntaxTreeInterface;

/**
 * AntlrSyntaxTreeInterface:
 * @get_source_interval: Return an #AntlrInterval indicating the index in the
 * #AntlrTokenStream of the first and last token associated with this
 * subtree. If this node is a leaf, then the interval represents a single
 * token and has interval i..i for token index i.
 *
 * An interval of i..i-1 indicates an empty interval at position
 * i in the input stream, where 0 &lt;= i &lt;= the size of the input
 * token stream.  Currently, the code base can only have i=0..n-1 but
 * in concept one could have an empty interval after EOF.
 *
 * If source interval is unknown, this returns %ANTLR_INTERVAL_INVALID.
 *
 * As a weird special case, the source interval for rules matched after
 * EOF is unspecified.
 *
 * A tree that knows about an interval in a token stream
 *  is some kind of syntax tree. Subinterfaces distinguish
 *  between parse trees and other kinds of syntax trees we might want to create.
 */
struct _AntlrSyntaxTreeInterface
{
    /*< private >*/
    AntlrTreeInterface parent_iface;

    /*< public >*/
    AntlrInterval* (*get_source_interval) ( AntlrSyntaxTree *self);
};

GType  antlr_syntax_tree_get_type (void) G_GNUC_CONST;

AntlrInterval* antlr_syntax_tree_get_source_interval (AntlrSyntaxTree *self);

G_END_DECLS

#endif /* __ANTLR_SYNTAX_TREE_H__ */

