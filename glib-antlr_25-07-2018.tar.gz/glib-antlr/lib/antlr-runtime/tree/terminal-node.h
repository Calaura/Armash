/*
 * terminal-node.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_TERMINAL_NODE_H__
#define __ANTLR_TERMINAL_NODE_H__


#include <glib-object.h>

G_BEGIN_DECLS

#define ANTLR_TYPE_TERMINAL_NODE                (antlr_terminal_node_get_type ())
#define ANTLR_TERMINAL_NODE(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  ANTLR_TYPE_TERMINAL_NODE,  AntlrTerminalNode))
#define ANTLR_IS_TERMINAL_NODE(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  ANTLR_TYPE_TERMINAL_NODE))
#define ANTLR_TERMINAL_NODE_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  ANTLR_TYPE_TERMINAL_NODE,  AntlrTerminalNodeInterface))


typedef struct _AntlrTerminalNode  AntlrTerminalNode; /* dummy object */
typedef struct _AntlrTerminalNodeInterface  AntlrTerminalNodeInterface;

/**
 * AntlrTerminalNodeInterface:
 * @get_symbol: The description of get_symbol
 */
struct _AntlrTerminalNodeInterface
{
    /*< private >*/
    AntlrParseTreeInterface parent_iface;

    /*< public >*/
    AntlrToken* (*get_symbol) (AntlrTerminalNode *self);
};

GType  antlr_terminal_node_get_type (void) G_GNUC_CONST;
AntlrToken *antlr_terminal_node_get_symbol(AntlrTerminalNode *self);

G_END_DECLS

#endif /* __ANTLR_TERMINAL_NODE_H__ */

