/*
 * syntax-tree.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "tree.h"
#include "syntax-tree.h"

G_DEFINE_INTERFACE(AntlrSyntaxTree, antlr_syntax_tree, ANTLR_TYPE_TREE)

static void
antlr_syntax_tree_default_init(AntlrSyntaxTreeInterface *iface) {
	  /* Add properties and signals to the interface here */
}

AntlrInterval*
antlr_syntax_tree_get_source_interval (AntlrSyntaxTree *self)
{
    g_return_val_if_fail(ANTLR_IS_SYNTAX_TREE(self), NULL);

    return ANTLR_SYNTAX_TREE_GET_INTERFACE(self)->get_source_interval(self);
}
