/*
 * tree.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_TREE_H__
#define __ANTLR_TREE_H__


#include <glib-object.h>

G_BEGIN_DECLS

#define ANTLR_TYPE_TREE                (antlr_tree_get_type ())
#define ANTLR_TREE(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  ANTLR_TYPE_TREE,  AntlrTree))
#define ANTLR_IS_TREE(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  ANTLR_TYPE_TREE))
#define ANTLR_TREE_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  ANTLR_TYPE_TREE,  AntlrTreeInterface))


typedef struct _AntlrTree  AntlrTree; /* dummy object */
typedef struct _AntlrTreeInterface  AntlrTreeInterface;

/**
 * AntlrTreeInterface:
 * @get_parent: The parent of this node. If the return value is null, then this
 *  node is the root of the tree.
 * @get_payload: This method returns whatever object represents the data at this note. For
 * example, for parse trees, the payload can be a {@link Token} representing
 * a leaf node or a {@link RuleContext} object representing a rule
 * invocation. For abstract syntax trees (ASTs), this is a {@link Token}
 * object.
 * @get_child: If there are children, get the @i th value indexed from 0.
 * @get_child_count: How many children are there? If there is none, then this
 *  node represents a leaf node.
 * @to_string_tree: Print out a whole tree, not just a node, in LISP format
 *  (root child1 .. childN). Print just a node if this is a leaf.
 *
 */
struct _AntlrTreeInterface
{
    /*< private >*/
	GTypeInterface parent_iface;

    /*< public >*/
    AntlrTree* (*get_parent)      (AntlrTree *self);
    GObject*   (*get_payload)     (AntlrTree *self);
    AntlrTree* (*get_child)       (AntlrTree *self, gint i);
    gint       (*get_child_count) (AntlrTree *self);
    gchar*     (*to_string_tree)  (AntlrTree *self, GArray *rule_names);
};

GType  antlr_tree_get_type (void) G_GNUC_CONST;

AntlrTree* antlr_tree_get_parent (AntlrTree *self);
GObject* antlr_tree_get_payload (AntlrTree *self);
AntlrTree* antlr_tree_get_child (AntlrTree *self, gint i);
gint antlr_tree_get_child_count(AntlrTree *self);
gchar* antlr_tree_to_string_tree (AntlrTree *self, GArray *rule_names);



G_END_DECLS

#endif /* __ANTLR_TREE_H__ */

