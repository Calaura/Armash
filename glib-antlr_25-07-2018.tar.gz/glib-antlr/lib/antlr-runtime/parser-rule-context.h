/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * parser-rule-context.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_PARSER_RULE_CONTEXT_H__
#define __ANTLR_PARSER_RULE_CONTEXT_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_PARSER_RULE_CONTEXT            (antlr_parser_rule_context_get_type())
#define ANTLR_PARSER_RULE_CONTEXT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_PARSER_RULE_CONTEXT, AntlrParserRuleContext))
#define ANTLR_PARSER_RULE_CONTEXT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_PARSER_RULE_CONTEXT, AntlrParserRuleContextClass))
#define ANTLR_IS_PARSER_RULE_CONTEXT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_PARSER_RULE_CONTEXT))
#define ANTLR_IS_PARSER_RULE_CONTEXT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_PARSER_RULE_CONTEXT))
#define ANTLR_PARSER_RULE_CONTEXT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_PARSER_RULE_CONTEXT, AntlrParserRuleContextClass))

typedef struct _AntlrParserRuleContextPrivate AntlrParserRuleContextPrivate;
typedef struct _AntlrParserRuleContextClass AntlrParserRuleContextClass;
/**
 * AntlrParserRuleContext:
 * @children:  If we are debugging or building a parse tree for a visitor,
 *  we need to track all of the tokens and rule invocations associated
 *  with this rule's context. This is empty for parsing w/o tree constr.
 *  operation because we don't the need to track the details about
 *  how we parse this rule.
 * @start: Start
 * @stop: Stop
 *
 * exception: The exception that forced this rule to return. If the rule successfully
 * completed, this is %NULL.
 */
struct _AntlrParserRuleContext {
    /*< private >*/
    AntlrRuleContext parent_instance;

    /*< public >*/
    GList *children;// of AntlrRuleContext AntlrParseTree
    AntlrToken *start;
    AntlrToken *stop;
    //public RecognitionException exception;

};

struct _AntlrParserRuleContextClass {
    AntlrRuleContextClass parent_class;

    void (*enter_rule)(AntlrParserRuleContext *self, AntlrParseTreeListener *listener);
    void (*exit_rule) (AntlrParserRuleContext *self, AntlrParseTreeListener *listener);
};

GType antlr_parser_rule_context_get_type(void)G_GNUC_CONST;
AntlrParserRuleContext *antlr_parser_rule_context_new();
AntlrParserRuleContext *antlr_parser_rule_context_super_with_parent(GType type, AntlrParserRuleContext *parent, gint state);
AntlrParserRuleContext *antlr_parser_rule_context_new_with_parent(AntlrParserRuleContext *parent, gint invoking_state_number);


/* COPY a ctx (I'm deliberately not using copy constructor) to avoid
 *  confusion with creating node with parent. Does not copy children.
 */
AntlrParserRuleContext *antlr_parser_rule_context_copy_from(AntlrParserRuleContext *self, AntlrParserRuleContext *ctx);
void antlr_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener);
void antlr_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener);

AntlrRuleContext  *antlr_parser_rule_context_add_child(AntlrParserRuleContext *self, AntlrRuleContext *rule_invocation);
AntlrTerminalNode *antlr_parser_rule_context_add_child_from_node(AntlrParserRuleContext *self, AntlrTerminalNode *t);
AntlrTerminalNode *antlr_parser_rule_context_add_child_from_token(AntlrParserRuleContext *self, AntlrToken *matchedToken);

AntlrErrorNode    *antlr_parser_rule_context_add_error_node(AntlrParserRuleContext *self, AntlrToken *bad_token);

AntlrTerminalNode *antlr_parser_rule_context_get_token(AntlrParserRuleContext *self, gint ttype, gint i);
GList             *antlr_parser_rule_context_get_tokens(AntlrParserRuleContext *self, gint ttype);// of <TerminalNode>

AntlrParserRuleContext *antlr_parser_rule_context_get_rule_context(AntlrParserRuleContext *self, GType ctxType, gint i);
GList*                  antlr_parser_rule_context_get_rule_contexts(AntlrParserRuleContext *self, GType ctxType);
void                    antlr_parser_rule_context_remove_last_child (AntlrParserRuleContext *self);


G_END_DECLS

#endif /* __ANTLR_PARSER_RULE_CONTEXT_H__ */

