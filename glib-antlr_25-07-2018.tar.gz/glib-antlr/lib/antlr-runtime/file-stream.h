/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-file_stream.h
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _ANTLR_FILE_STREAM_H_
#define _ANTLR_FILE_STREAM_H_

#include <glib-object.h>

G_BEGIN_DECLS

#define ANTLR_TYPE_FILE_STREAM             (antlr_file_stream_get_type ())
#define ANTLR_FILE_STREAM(obj)             (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_FILE_STREAM, AntlrFileStream))
#define ANTLR_FILE_STREAM_CLASS(klass)     (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_FILE_STREAM, AntlrFileStreamClass))
#define ANTLR_IS_FILE_STREAM(obj)          (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_FILE_STREAM))
#define ANTLR_IS_FILE_STREAM_CLASS(klass)  (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_FILE_STREAM))
#define ANTLR_FILE_STREAM_GET_CLASS(obj)   (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_FILE_STREAM, AntlrFileStreamClass))

typedef struct _AntlrFileStreamClass AntlrFileStreamClass;

struct _AntlrFileStream
{
    /*< private >*/
    AntlrInputStream parent_instance;

    gchar *filename;
};

struct _AntlrFileStreamClass
{
    /*< private >*/
    AntlrInputStreamClass parent_class;
};

GType antlr_file_stream_get_type (void) G_GNUC_CONST;

AntlrFileStream *antlr_file_stream_new_from_filename_encoding (const gchar *filename, const gchar *encoding, GError **error);
gboolean         antlr_file_stream_load(AntlrFileStream *file_stream, const gchar *filename, const gchar *encoding, GError **error);
gchar           *antlr_file_stream_get_source_name (AntlrFileStream *file_stream);

G_END_DECLS

#endif /* _ANTLR_FILE_STREAM_H_ */

