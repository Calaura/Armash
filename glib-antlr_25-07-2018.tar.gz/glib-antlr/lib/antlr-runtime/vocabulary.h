#ifndef __ANTLR_IVOCABULARY_H__
#define __ANTLR_IVOCABULARY_H__

#include <glib-object.h>

G_BEGIN_DECLS

#define ANTLR_TYPE_IVOCABULARY                 (antlr_ivocabulary_get_type ())
#define ANTLR_IVOCABULARY(obj)                 (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_IVOCABULARY, AntlrIVocabulary))
#define ANTLR_IS_IVOCABULARY(obj)              (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_IVOCABULARY))
#define ANTLR_IVOCABULARY_GET_INTERFACE(inst)  (G_TYPE_INSTANCE_GET_INTERFACE ((inst), ANTLR_TYPE_IVOCABULARY, AntlrIVocabularyInterface))


typedef struct _AntlrIVocabulary               AntlrIVocabulary; /* dummy object */

/**
 * AntlrIVocabularyInterface:
 * @get_literal_name: Gets the string literal associated with a token type.
 * @get_symbolic_name: Gets the symbolic name associated with a token type.
 * @get_display_name: Gets the display name of a token type.
 *
 *
 */
typedef struct _AntlrIVocabularyInterface      AntlrIVocabularyInterface;

struct _AntlrIVocabularyInterface
{
    /*< private >*/
    GTypeInterface parent_iface;

    /*< public >*/
    gchar* (*get_literal_name)  (AntlrIVocabulary *self, gint token_type);
    gchar* (*get_symbolic_name) (AntlrIVocabulary *self, gint token_type);
    gchar* (*get_display_name)  (AntlrIVocabulary *self, gint token_type);
};

GType antlr_ivocabulary_get_type (void) G_GNUC_CONST;

gchar* antlr_ivocabulary_get_literal_name (AntlrIVocabulary *self, gint token_type);
gchar* antlr_ivocabulary_get_symbolic_name(AntlrIVocabulary *self, gint token_type);
gchar* antlr_ivocabulary_get_display_name (AntlrIVocabulary *self, gint token_type);

G_END_DECLS

#endif // __ANTLR_IVOCABULARY_H__
