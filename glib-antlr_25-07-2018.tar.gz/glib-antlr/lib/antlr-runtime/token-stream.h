/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*-  */
/*
 * antlr-token.h
 * Copyright (C) 2016 Gaulouis <gaulouis.fr@gmail.com>
 *
 * org-antlr is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * org-antlr is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _ANTLR_TOKEN_STREAM_H_
#define _ANTLR_TOKEN_STREAM_H_

#include <glib-object.h>

G_BEGIN_DECLS


#define ANTLR_TYPE_TOKEN_STREAM                (antlr_token_stream_get_type ())
//#define ANTLR_TOKEN_STREAM(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_TOKEN_STREAM, AntlrTokenStream))
#define ANTLR_TOKEN_STREAM(obj)                ((AntlrTokenStream*)obj)
#define ANTLR_IS_TOKEN_STREAM(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_TOKEN_STREAM))
#define ANTLR_TOKEN_STREAM_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst), ANTLR_TYPE_TOKEN_STREAM, AntlrTokenStreamInterface))

typedef struct _AntlrTokenStreamInterface AntlrTokenStreamInterface;

/**
 * AntlrTokenStreamInterface:
 * @LT: The description of LT
 * @get: The description of get
 * @get_token_source: The description of get_token_source
 * @get_text: The description of get_text
 * @get_text_from_interval: The description of get_text_from_interval
 * @get_text_from_context: The description of get_text_from_context
 * @get_text_from_token: The description of get_text_from_token
 */
struct _AntlrTokenStreamInterface
{
    /*< private >*/
    AntlrIntStreamInterface parent_iface;

    /*< public >*/
    AntlrToken*        (*LT)                     (AntlrTokenStream *token_stream, gint k);
    AntlrToken*        (*get)                    (AntlrTokenStream *token_stream, gint index);
    AntlrTokenSource*  (*get_token_source)       (AntlrTokenStream *token_stream);
    gchar*             (*get_text)               (AntlrTokenStream *token_stream);
    gchar*             (*get_text_from_interval) (AntlrTokenStream *token_stream, AntlrInterval *interval);
    gchar*             (*get_text_from_context)  (AntlrTokenStream *token_stream, AntlrRuleContext *ctx);
    gchar*             (*get_text_from_token)    (AntlrTokenStream *token_stream, AntlrToken *start, AntlrToken *stop);

};

GType antlr_token_stream_get_type (void) G_GNUC_CONST;

AntlrToken* antlr_token_stream_LT (AntlrTokenStream* token_stream, gint k);

AntlrToken* antlr_token_stream_get (AntlrTokenStream* token_stream, gint index);

AntlrTokenSource* antlr_token_stream_get_token_source (AntlrTokenStream* token_stream);

gchar* antlr_token_stream_get_text (AntlrTokenStream* token_stream);
gchar* antlr_token_stream_get_text_from_interval (AntlrTokenStream* token_stream, AntlrInterval *interval);

gchar* antlr_token_stream_get_text_from_context (AntlrTokenStream* token_stream, AntlrRuleContext *ctx);
gchar* antlr_token_stream_get_text_from_token (AntlrTokenStream* token_stream, AntlrToken *start, AntlrToken *stop);

G_END_DECLS

#endif /* _ANTLR_TOKEN_STREAM_H_ */
