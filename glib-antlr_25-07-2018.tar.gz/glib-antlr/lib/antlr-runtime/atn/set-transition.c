/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * set-transition.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"
#include "transition.h"
#include "set-transition.h"
#include "../token.h"

static gint
antlr_set_transition_class_transition_get_serialization_type(AntlrTransition *self) {
    return ANTLR_TRANSITION_SET;
}

static gboolean
antlr_set_transition_class_transition_matches(AntlrTransition *self, gint symbol, gint min_vocab_symbol, gint max_vocab_symbol) {
    AntlrIntervalSet *set = ANTLR_SET_TRANSITION(self)->set;
    return antlr_int_iset_contains(ANTLR_INT_ISET(set), symbol);
}

static AntlrIntervalSet*
antlr_set_transition_class_transition_label(AntlrTransition *self) {
    return ANTLR_SET_TRANSITION(self)->set;
}

static void antlr_set_transition_class_init(AntlrSetTransitionClass *klass);
static void antlr_set_transition_init(AntlrSetTransition *gobject);

G_DEFINE_TYPE (AntlrSetTransition, antlr_set_transition, ANTLR_TYPE_TRANSITION)

static void
antlr_set_transition_class_object_dispose(GObject *object) {
    //g_clear_object(&ANTLR_SET_TRANSITION(object)->set);

    G_OBJECT_CLASS(antlr_set_transition_parent_class)->dispose(object);
}
static void
antlr_set_transition_class_object_finalize(GObject *object) {

    G_OBJECT_CLASS(antlr_set_transition_parent_class)->finalize(object);
}


static void
antlr_set_transition_class_init(AntlrSetTransitionClass *klass)
{
    AntlrTransitionClass *transition_class;

    transition_class = (AntlrTransitionClass *) klass;

    G_OBJECT_CLASS(klass)->dispose = antlr_set_transition_class_object_dispose;
    G_OBJECT_CLASS(klass)->finalize = antlr_set_transition_class_object_finalize;

    transition_class->get_serialization_type = antlr_set_transition_class_transition_get_serialization_type;
    transition_class->matches = antlr_set_transition_class_transition_matches;
    transition_class->label = antlr_set_transition_class_transition_label;

//	antlr_set_transition_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_set_transition_init (AntlrSetTransition *object)
{
    object->set = NULL;
}

AntlrSetTransition*
antlr_set_transition_super (GType type, AntlrATNState *target, AntlrIntervalSet *set)
{
    AntlrSetTransition *self = (AntlrSetTransition *)antlr_transition_super (type, target);

    if ( set == NULL )
        set = antlr_interval_set_of(ANTLR_TOKEN_INVALID_TYPE);
    else
        g_object_ref(set);
    self->set = set;

    return self;
}

AntlrSetTransition*
antlr_set_transition_new (AntlrATNState *target, AntlrIntervalSet *set)
{
    AntlrSetTransition *self = antlr_set_transition_super (ANTLR_TYPE_SET_TRANSITION, target, set);

    return self;
}

#if 0

/*
 * [The "BSD license"]
 *  Copyright (c) 2012 Terence Parr
 *  Copyright (c) 2012 Sam Harwell
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 *  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 *  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.antlr.v4.runtime.atn;

import org.antlr.v4.runtime.Token;
import org.antlr.v4.runtime.misc.IntervalSet;

/** A transition containing a set of values. */
public class SetTransition extends Transition {
    public final IntervalSet set;

    // TODO (sam): should we really allow null here?
    public SetTransition(ATNState target, IntervalSet set) {
        super(target);
        if ( set == null ) set = IntervalSet.of(Token.INVALID_TYPE);
        this.set = set;
    }

    @Override
    public int getSerializationType() {
        return SET;
    }

    @Override

    public IntervalSet label() { return set; }

    @Override
    public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
        return set.contains(symbol);
    }

    @Override

    public String toString() {
        return set.toString();
    }
}

#endif
