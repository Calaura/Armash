/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * lexer-indexed-custom-action.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_LEXER_INDEXED_CUSTOM_ACTION_H__
#define __ANTLR_LEXER_INDEXED_CUSTOM_ACTION_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_LEXER_INDEXED_CUSTOM_ACTION            (antlr_lexer_indexed_custom_action_get_type())
#define ANTLR_LEXER_INDEXED_CUSTOM_ACTION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_LEXER_INDEXED_CUSTOM_ACTION, AntlrLexerIndexedCustomAction))
#define ANTLR_LEXER_INDEXED_CUSTOM_ACTION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_LEXER_INDEXED_CUSTOM_ACTION, AntlrLexerIndexedCustomActionClass))
#define ANTLR_IS_LEXER_INDEXED_CUSTOM_ACTION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_LEXER_INDEXED_CUSTOM_ACTION))
#define ANTLR_IS_LEXER_INDEXED_CUSTOM_ACTION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_LEXER_INDEXED_CUSTOM_ACTION))
#define ANTLR_LEXER_INDEXED_CUSTOM_ACTION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_LEXER_INDEXED_CUSTOM_ACTION, AntlrLexerIndexedCustomActionClass))

typedef struct _AntlrLexerIndexedCustomAction AntlrLexerIndexedCustomAction;
typedef struct _AntlrLexerIndexedCustomActionClass AntlrLexerIndexedCustomActionClass;

struct _AntlrLexerIndexedCustomAction {
	AntlrObject parent_instance;

    /*< public >*/
    gint offset;
    AntlrLexerAction *action;
};

struct _AntlrLexerIndexedCustomActionClass {
	AntlrObjectClass parent_class;
};

GType antlr_lexer_indexed_custom_action_get_type(void)G_GNUC_CONST;
AntlrLexerIndexedCustomAction *antlr_lexer_indexed_custom_action_new();
AntlrLexerIndexedCustomAction *antlr_lexer_indexed_custom_action_new_full(gint offset, AntlrLexerAction *action);
gint                           antlr_lexer_indexed_custom_action_get_offset(AntlrLexerIndexedCustomAction *self);
AntlrLexerAction              *antlr_lexer_indexed_custom_action_get_action(AntlrLexerIndexedCustomAction *self);

G_END_DECLS

#endif /* __ANTLR_LEXER_INDEXED_CUSTOM_ACTION_H__ */

