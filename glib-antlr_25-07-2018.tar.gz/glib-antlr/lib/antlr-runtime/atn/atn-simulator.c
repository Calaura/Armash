/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * atn-simulator.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"

#include "../misc/object.h"
#include "../misc/bit-set.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"

#include "prediction-context.h"
#include "prediction-context-cache.h"
#include "transition.h"
#include "lexer-action.h"
#include "atn-state.h"
#include "semantic-context.h"
#include "config.h"
#include "config-set.h"
#include "rule-stop-state.h"
#include "rule-start-state.h"
#include "atn.h"
#include "../dfa/dfa-state.h"

#include "atn-simulator.h"


static AntlrDFAState* antlr_atn_simulator_error = NULL;

static void antlr_atn_simulator_class_init(AntlrATNSimulatorClass *klass);
static void antlr_atn_simulator_init(AntlrATNSimulator *gobject);

G_DEFINE_TYPE (AntlrATNSimulator, antlr_atn_simulator, ANTLR_TYPE_OBJECT)

AntlrDFAState*
antlr_atn_simulator_get_error()
{
    if (!antlr_atn_simulator_error) {
        AntlrATNConfigSet *configs = antlr_atn_config_set_new();
        antlr_atn_simulator_error = antlr_dfa_state_new_with_config_set(configs);
        antlr_atn_simulator_error->state_number = G_MAXINT;
        g_object_unref(configs);
    }

    return antlr_atn_simulator_error;
}

void
antlr_atn_simulator_error_free()
{
    if (antlr_atn_simulator_error!=NULL) {
        g_object_unref(antlr_atn_simulator_error);
    }
    antlr_atn_simulator_error = NULL;
}

static void
antlr_atn_simulator_class_object_dispose(GObject *object)
{
    AntlrATNSimulator *self = ANTLR_ATN_SIMULATOR(object);

    if (self->shared_context_cache) {
        g_clear_object(&self->shared_context_cache);
    }

    G_OBJECT_CLASS (antlr_atn_simulator_parent_class)->dispose (object);
}

static void
antlr_atn_simulator_class_object_finalize(GObject *object)
{
    /* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (antlr_atn_simulator_parent_class)->finalize (object);
}

static void
antlr_atn_simulator_class_init(AntlrATNSimulatorClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = antlr_atn_simulator_class_object_finalize;
    gobject_class->dispose = antlr_atn_simulator_class_object_dispose;

//	antlr_atn_simulator_parent_class = g_type_class_peek_parent (klass);
    klass->error = NULL;
}

static void
antlr_atn_simulator_init (AntlrATNSimulator *object)
{
    object->shared_context_cache = NULL;
}

void
antlr_atn_simulator_super (AntlrATNSimulator *simulator,
                           AntlrATN *atn,
                           AntlrPredictionContextCache *shared_context_cache)
{
    simulator->atn = atn;
    simulator->shared_context_cache = shared_context_cache;
}

AntlrATNSimulator *
antlr_atn_simulator_new (void)
{
    return g_object_new (antlr_atn_simulator_get_type (),
                         NULL);
}

void
antlr_atn_simulator_reset (AntlrATNSimulator *simulator)
{
    g_return_if_fail(ANTLR_IS_ATN_SIMULATOR(simulator));

    ANTLR_ATN_SIMULATOR_GET_CLASS(simulator)->reset(simulator);
}

AntlrPredictionContext*
antlr_atn_simulator_get_cached_context(AntlrATNSimulator *simulator, AntlrPredictionContext *context)
{
    if ( simulator->shared_context_cache==NULL )
        return context;

    GHashTable *visited = g_hash_table_new(g_direct_hash, g_direct_equal);

    return antlr_prediction_context_get_cached_context(context, simulator->shared_context_cache, visited);
}
