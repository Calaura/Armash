/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * lexer-atn-config.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"
#include "semantic-context.h"
#include "config.h"
#include "lexer-action-executor.h"
#include "lexer-action-executor.h"
#include "transition.h"
#include "atn-state.h"
#include "decision-state.h"

#include "lexer-atn-config.h"


static void antlr_lexer_atn_config_class_init(AntlrLexerATNConfigClass *klass);
static void antlr_lexer_atn_config_init(AntlrLexerATNConfig *gobject);

G_DEFINE_TYPE (AntlrLexerATNConfig, antlr_lexer_atn_config, ANTLR_ATN_TYPE_CONFIG)


static void
antlr_lexer_atn_config_class_gobject_dispose(GObject *object)
{
    AntlrLexerATNConfig *self = ANTLR_LEXER_ATN_CONFIG(object);

    G_OBJECT_CLASS(antlr_lexer_atn_config_parent_class)->dispose(object);
}

static void
antlr_lexer_atn_config_class_init(AntlrLexerATNConfigClass *klass)
{
//    AntlrATNConfigClass *atnconfig_class;
    GObjectClass *gobject_class = NULL;

    gobject_class = G_OBJECT_CLASS(klass);

    gobject_class->dispose = antlr_lexer_atn_config_class_gobject_dispose;
}

static void
antlr_lexer_atn_config_init (AntlrLexerATNConfig *object)
{
}

AntlrLexerATNConfig *
antlr_lexer_atn_config_new (void)
{
	return g_object_new (antlr_lexer_atn_config_get_type (),
	                     NULL);
}

AntlrLexerATNConfig*
antlr_lexer_atn_config_new_with_prediction(AntlrATNState *state,
                                           gint alt,
                                           AntlrPredictionContext *context)
{
    AntlrLexerATNConfig *config = g_object_new (ANTLR_TYPE_LEXER_ATN_CONFIG, NULL);
    antlr_atn_config_super_with_prediction(ANTLR_ATN_CONFIG(config), state, alt, context, antlr_semantic_context_get_none());
//    super(state, alt, context, SemanticContext.NONE);
    config->passed_through_non_greedy_decision = FALSE;
    config->lexer_action_executor = NULL;
    return config;
}

static gboolean
antlr_lexer_atn_config_check_non_greedy_decision(AntlrLexerATNConfig*self, AntlrLexerATNConfig *source, AntlrATNState *target) {
    return source->passed_through_non_greedy_decision
        || (ANTLR_IS_DECISION_STATE(target) && ANTLR_DECISION_STATE(target)->non_greedy);
}

AntlrLexerATNConfig*
antlr_lexer_atn_config_new_with_config(AntlrLexerATNConfig *c, AntlrATNState *state) {
    AntlrLexerATNConfig *self = g_object_new (ANTLR_TYPE_LEXER_ATN_CONFIG, NULL);
    antlr_atn_config_super_from_config(ANTLR_ATN_CONFIG(self), ANTLR_ATN_CONFIG(c), state, ANTLR_ATN_CONFIG(c)->context, ANTLR_ATN_CONFIG(c)->semantic_context);
    self->lexer_action_executor = c->lexer_action_executor;
    self->passed_through_non_greedy_decision = antlr_lexer_atn_config_check_non_greedy_decision(self, c, state);
    return self;
}

AntlrLexerATNConfig*
antlr_lexer_atn_config_new_with_config_and_action(AntlrLexerATNConfig *c, AntlrATNState *state,
                      AntlrLexerActionExecutor *lexer_action_executor)
{
    AntlrLexerATNConfig *self = g_object_new (ANTLR_TYPE_LEXER_ATN_CONFIG, NULL);
    antlr_atn_config_super_from_config(ANTLR_ATN_CONFIG(self), ANTLR_ATN_CONFIG(c), state, ANTLR_ATN_CONFIG(c)->context, ANTLR_ATN_CONFIG(c)->semantic_context);

    self->lexer_action_executor = lexer_action_executor;
    self->passed_through_non_greedy_decision = antlr_lexer_atn_config_check_non_greedy_decision(self, c, state);
    return self;
}

AntlrLexerATNConfig*
antlr_lexer_atn_config_new_with_config_and_prediction(AntlrLexerATNConfig *c,
                                                      AntlrATNState *state,
                                                      AntlrPredictionContext *context)
{
    AntlrLexerATNConfig *self = g_object_new (ANTLR_TYPE_LEXER_ATN_CONFIG, NULL);
    antlr_atn_config_super_from_config(ANTLR_ATN_CONFIG(self), ANTLR_ATN_CONFIG(c), state, context, ANTLR_ATN_CONFIG(c)->semantic_context);

    self->lexer_action_executor = c->lexer_action_executor;
    self->passed_through_non_greedy_decision = antlr_lexer_atn_config_check_non_greedy_decision(self, c, state);
    return self;
}

gboolean
antlr_lexer_atn_config_has_passed_through_non_greedy_decision(AntlrLexerATNConfig *self) {
    return self->passed_through_non_greedy_decision;
}

/**
 * antlr_lexer_atn_config_get_lexer_action_executor:
 * @config: Some #AntlrLexerATNConfig
 *
 * Gets the {@link LexerActionExecutor} capable of executing the embedded
 * action(s) for the current configuration.
 */
AntlrLexerActionExecutor*
antlr_lexer_atn_config_get_lexer_action_executor(AntlrLexerATNConfig *config)
{
    return config->lexer_action_executor;
}

