/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * lexer-indexed-custom-action.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/integer-list.h"
#include "../misc/integer-stack.h"
#include "../misc/murmur-hash.h"
#include "../vocabulary.h"
#include "../recognizer.h"
#include "../int-stream.h"
#include "../token-factory.h"
#include "../lexer.h"
#include "atn-simulator.h"
#include "lexer-action.h"

#include "lexer-indexed-custom-action.h"


static void antlr_lexer_indexed_custom_action_interface_lexer_action_init(AntlrLexerActionInterface *iface);

static void antlr_lexer_indexed_custom_action_class_init(AntlrLexerIndexedCustomActionClass *klass);
static void antlr_lexer_indexed_custom_action_init(AntlrLexerIndexedCustomAction *gobject);

G_DEFINE_TYPE_WITH_CODE (AntlrLexerIndexedCustomAction, antlr_lexer_indexed_custom_action, ANTLR_TYPE_OBJECT,
               G_IMPLEMENT_INTERFACE(ANTLR_TYPE_LEXER_ACTION, antlr_lexer_indexed_custom_action_interface_lexer_action_init)
               )



/**
 * antlr_lexer_indexed_custom_action_interface_lexer_action_get_action_type:
 *
 * Returns: This method returns the result of calling {@link #getActionType}
 * on the #AntlrLexerAction returned by {@link #getAction}.
 */
static AntlrLexerActionType
antlr_lexer_indexed_custom_action_interface_lexer_action_get_action_type(AntlrLexerAction *self) {
    return antlr_lexer_action_get_action_type(ANTLR_LEXER_INDEXED_CUSTOM_ACTION(self)->action);
}

/**
 * antlr_lexer_indexed_custom_action_interface_lexer_action_is_position_dependent:
 * @self: Some #AntlrLexerAction
 *
 * Returns: This method returns %FALSE.
 */
static gboolean
antlr_lexer_indexed_custom_action_interface_lexer_action_is_position_dependent(AntlrLexerAction *self) {
    return TRUE;
}

/**
 * antlr_lexer_indexed_custom_action_interface_lexer_action_execute:
 * @self: Some #AntlrLexerAction
 * @lexer: Some #AntlrLexer
 *
 * This method calls {@link #execute} on the result of {@link #getAction}
 * using the provided {@code lexer}.
 */
static void
antlr_lexer_indexed_custom_action_interface_lexer_action_execute(AntlrLexerAction *self, AntlrLexer *lexer) {
    AntlrLexerAction *action = ANTLR_LEXER_INDEXED_CUSTOM_ACTION(self)->action;

    // assume the input stream position was properly set by the calling code
    antlr_lexer_action_execute(action, lexer);
}


static gint
antlr_lexer_indexed_custom_action_interface_lexer_action_hash_code(AntlrLexerAction *lexer_action) {
    AntlrLexerIndexedCustomAction *self = ANTLR_LEXER_INDEXED_CUSTOM_ACTION(lexer_action);

    //gint type_code = antlr_lexer_action_get_action_type(lexer_action);// ANTLR_LEXER_ACTION_TYPE_INDEXED_CUSTOM
    gint action_code = antlr_lexer_action_hash_code(self->action);
    gint hash_code;
    hash_code = antlr_murmur_hash_initialize(ANTLR_MURMUR_HASH_DEFAULT_SEED);
    //hash_code = antlr_murmur_hash_update(hash_code, type_code);
    hash_code = antlr_murmur_hash_update(hash_code, self->offset);
    hash_code = antlr_murmur_hash_update(hash_code, action_code);
    return antlr_murmur_hash_finish(hash_code, 2);
}


static void
antlr_lexer_indexed_custom_action_interface_lexer_action_init(AntlrLexerActionInterface *iface)
{
    iface->get_action_type = antlr_lexer_indexed_custom_action_interface_lexer_action_get_action_type;
    iface->is_position_dependent = antlr_lexer_indexed_custom_action_interface_lexer_action_is_position_dependent;
    iface->execute = antlr_lexer_indexed_custom_action_interface_lexer_action_execute;
    iface->hash_code = antlr_lexer_indexed_custom_action_interface_lexer_action_hash_code;
}

static void
antlr_lexer_indexed_custom_action_class_init(AntlrLexerIndexedCustomActionClass *klass)
{
//	GObjectClass *gobject_class;

//	gobject_class = (GObjectClass *) klass;


//	antlr_lexer_indexed_custom_action_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_lexer_indexed_custom_action_init (AntlrLexerIndexedCustomAction *object)
{
}

AntlrLexerIndexedCustomAction *
antlr_lexer_indexed_custom_action_new (void)
{
	return g_object_new (antlr_lexer_indexed_custom_action_get_type (),
	                     NULL);
}
/**
 * antlr_lexer_indexed_custom_action_new_full:
 * @offset: The offset into the input {@link CharStream}, relative to
 * the token start index, at which the specified lexer action should be
 * executed.
 * @action: The lexer action to execute at a particular offset in the
 * input {@link CharStream}.
 *
 * Constructs a new indexed custom action by associating a character offset
 * with a #AntlrLexerAction.
 *
 * Note: This class is only required for lexer actions for which
 * {@link LexerAction#isPositionDependent} returns %TRUE.
 *
 */
AntlrLexerIndexedCustomAction*
antlr_lexer_indexed_custom_action_new_full(gint offset, AntlrLexerAction *action) {
    AntlrLexerIndexedCustomAction *self = g_object_new (ANTLR_TYPE_LEXER_INDEXED_CUSTOM_ACTION, NULL);
    self->offset = offset;
    self->action = action;

    return self;
}

/**
 * antlr_lexer_indexed_custom_action_get_offset:
 * @self: Some #AntlrLexerIndexedCustomAction
 *
 * Gets the location in the input {@link CharStream} at which the lexer
 * action should be executed. The value is interpreted as an offset relative
 * to the token start index.
 *
 * Returns: The location in the input {@link CharStream} at which the lexer
 * action should be executed.
 */
gint
antlr_lexer_indexed_custom_action_get_offset(AntlrLexerIndexedCustomAction *self) {
    return self->offset;
}

/**
 * antlr_lexer_indexed_custom_action_get_action:
 * @self: Some #AntlrLexerIndexedCustomAction
 *
 * Gets the lexer action to execute.
 *
 * Returns: A #AntlrLexerAction object which executes the lexer action.
 */
AntlrLexerAction*
antlr_lexer_indexed_custom_action_get_action(AntlrLexerIndexedCustomAction *self) {
    return self->action;
}
