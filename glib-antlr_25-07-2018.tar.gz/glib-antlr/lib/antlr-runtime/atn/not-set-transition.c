/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * not-set-transition.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"
#include "transition.h"
#include "set-transition.h"
#include "not-set-transition.h"


static void antlr_not_set_transition_class_init(AntlrNotSetTransitionClass *klass);
static void antlr_not_set_transition_init(AntlrNotSetTransition *gobject);

G_DEFINE_TYPE (AntlrNotSetTransition, antlr_not_set_transition, ANTLR_TYPE_SET_TRANSITION)

static gint
antlr_not_set_transition_class_transition_get_serialization_type(AntlrTransition *self) {
    return ANTLR_TRANSITION_NOT_SET;
}

static gboolean
antlr_not_set_transition_class_transition_matches(AntlrTransition *self, gint symbol, gint min_vocab_symbol, gint max_vocab_symbol) {
    AntlrTransitionClass *klass = ANTLR_TRANSITION_CLASS(antlr_not_set_transition_parent_class);

    return symbol >= min_vocab_symbol
        && symbol <= max_vocab_symbol
        && !klass->matches(self, symbol, min_vocab_symbol, max_vocab_symbol);
}

static void
antlr_not_set_transition_class_init(AntlrNotSetTransitionClass *klass)
{
    AntlrTransitionClass *transition_class;

    transition_class = (AntlrTransitionClass *) klass;

    transition_class->get_serialization_type = antlr_not_set_transition_class_transition_get_serialization_type;
    transition_class->matches = antlr_not_set_transition_class_transition_matches;


//	antlr_not_set_transition_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_not_set_transition_init (AntlrNotSetTransition *object)
{
}

AntlrNotSetTransition *
antlr_not_set_transition_new (AntlrATNState *target, AntlrIntervalSet *set)
{
    AntlrNotSetTransition *self = (AntlrNotSetTransition *)antlr_set_transition_super(ANTLR_TYPE_NOT_SET_TRANSITION, target, set);

    return self;
}

#if 0

/*
 * [The "BSD license"]
 *  Copyright (c) 2012 Terence Parr
 *  Copyright (c) 2012 Sam Harwell
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 *  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 *  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.antlr.v4.runtime.atn;

import org.antlr.v4.runtime.misc.IntervalSet;

public final class NotSetTransition extends SetTransition {
    public NotSetTransition(ATNState target, IntervalSet set) {
        super(target, set);
    }

    @Override
    public int getSerializationType() {
        return NOT_SET;
    }

    @Override
    public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
        return symbol >= minVocabSymbol
            && symbol <= maxVocabSymbol
            && !super.matches(symbol, minVocabSymbol, maxVocabSymbol);
    }

    @Override
    public String toString() {
        return '~'+super.toString();
    }
}


#endif

