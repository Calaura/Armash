/*
 * lexer-action.c
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * SECTION:lexer-action
 * @title: AntlrLexerAction
 * @short_description: Lexer action interface
 * @stability: Stable
 *
 *
 * Represents a single action which can be executed following the successful
 * match of a lexer rule. Lexer actions are used for both embedded action syntax
 * and ANTLR 4's new lexer command syntax.
 *
 */


#include <glib-object.h>

#include "../types.h"

#include "../misc/object.h"
#include "../misc/integer-list.h"
#include "../misc/integer-stack.h"
#include "../vocabulary.h"
#include "../recognizer.h"
#include "../int-stream.h"
#include "../token-factory.h"
#include "../lexer.h"

#include "prediction-context.h"
#include "prediction-context-cache.h"
#include "atn-simulator.h"
#include "lexer-action.h"

G_DEFINE_INTERFACE(AntlrLexerAction, antlr_lexer_action, 0)

static void
antlr_lexer_action_default_init(AntlrLexerActionInterface *iface) {
	  /* Add properties and signals to the interface here */
    iface->execute = NULL;
    iface->get_action_type = NULL;
    iface->is_position_dependent = NULL;
    iface->hash_code = NULL;
}

/**
 * antlr_lexer_action_get_action_type:
 * @self: Some #AntlrLexerAction
 *
 * Gets the serialization type of the lexer action.
 *
 * Returns: The serialization type of the lexer action.
 */
AntlrLexerActionType
antlr_lexer_action_get_action_type(AntlrLexerAction *self) {
    g_return_val_if_fail(ANTLR_IS_LEXER_ACTION(self), ANTLR_LEXER_ACTION_TYPE_SKIP);

    return ANTLR_LEXER_ACTION_GET_INTERFACE(self)->get_action_type(self);
}

/**
 * antlr_lexer_action_is_position_dependent:
 * @self: Some #AntlrLexerAction
 *
 * Gets whether the lexer action is position-dependent. Position-dependent
 * actions may have different semantics depending on the {@link CharStream}
 * index at the time the action is executed.
 *
 * <p>Many lexer commands, including {@code type}, {@code skip}, and
 * {@code more}, do not check the input index during their execution.
 * Actions like this are position-independent, and may be stored more
 * efficiently as part of the {@link LexerATNConfig#lexerActionExecutor}.</p>
 *
 * Returns: %TRUE if the lexer action semantics can be affected by the
 * position of the input #AntlrCharStream at the time it is executed;
 * otherwise, %FALSE.
 */
gboolean
antlr_lexer_action_is_position_dependent(AntlrLexerAction *self) {
    g_return_val_if_fail(ANTLR_IS_LEXER_ACTION(self), FALSE);

    return ANTLR_LEXER_ACTION_GET_INTERFACE(self)->is_position_dependent(self);
}

/**
 * antlr_lexer_action_execute:
 * @self: Some #AntlrLexerAction
 * @lexer: The lexer instance.
 *
 * Execute the lexer action in the context of the specified {@link Lexer}.
 *
 * <p>For position-dependent actions, the input stream must already be
 * positioned correctly prior to calling this method.</p>
 *
 */
void
antlr_lexer_action_execute(AntlrLexerAction *self, AntlrLexer *lexer) {
    g_return_if_fail(ANTLR_IS_LEXER_ACTION(self));

    return ANTLR_LEXER_ACTION_GET_INTERFACE(self)->execute(self, lexer);
}

gint
antlr_lexer_action_hash_code(AntlrLexerAction *self)
{
    g_return_if_fail(ANTLR_IS_LEXER_ACTION(self));

    return ANTLR_LEXER_ACTION_GET_INTERFACE(self)->hash_code(self);
}
