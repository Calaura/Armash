/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * star-loop-entry-state.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_STAR_LOOP_ENTRY_STATE_H__
#define __ANTLR_STAR_LOOP_ENTRY_STATE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_STAR_LOOP_ENTRY_STATE            (antlr_star_loop_entry_state_get_type())
#define ANTLR_STAR_LOOP_ENTRY_STATE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_STAR_LOOP_ENTRY_STATE, AntlrStarLoopEntryState))
#define ANTLR_STAR_LOOP_ENTRY_STATE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_STAR_LOOP_ENTRY_STATE, AntlrStarLoopEntryStateClass))
#define ANTLR_IS_STAR_LOOP_ENTRY_STATE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_STAR_LOOP_ENTRY_STATE))
#define ANTLR_IS_STAR_LOOP_ENTRY_STATE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_STAR_LOOP_ENTRY_STATE))
#define ANTLR_STAR_LOOP_ENTRY_STATE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_STAR_LOOP_ENTRY_STATE, AntlrStarLoopEntryStateClass))

typedef struct _AntlrStarLoopEntryStateClass AntlrStarLoopEntryStateClass;

/**
 * AntlrStarLoopEntryState:
 * @loop_back_state: The loop back state
 * @is_precedence_decision: Indicates whether this state can benefit from a precedence DFA during SLL
 * decision making.
 * This is a computed property that is calculated during ATN deserialization
 * and stored for use in {@link ParserATNSimulator} and
 * {@link ParserInterpreter}.
 * @see DFA#isPrecedenceDfa()
 *
 */
struct _AntlrStarLoopEntryState {
    /*< private >*/
	AntlrDecisionState parent_instance;

    /*< public >*/
    AntlrStarLoopbackState *loop_back_state;
    gboolean is_precedence_decision;
};

struct _AntlrStarLoopEntryStateClass {
	AntlrDecisionStateClass parent_class;
};

GType antlr_star_loop_entry_state_get_type(void)G_GNUC_CONST;
AntlrStarLoopEntryState *antlr_star_loop_entry_state_new();

G_END_DECLS

#endif /* __ANTLR_STAR_LOOP_ENTRY_STATE_H__ */

