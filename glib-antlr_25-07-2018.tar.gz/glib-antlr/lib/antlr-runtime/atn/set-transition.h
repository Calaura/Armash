/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * set-transition.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_SET_TRANSITION_H__
#define __ANTLR_SET_TRANSITION_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_SET_TRANSITION            (antlr_set_transition_get_type())
#define ANTLR_SET_TRANSITION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_SET_TRANSITION, AntlrSetTransition))
#define ANTLR_SET_TRANSITION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_SET_TRANSITION, AntlrSetTransitionClass))
#define ANTLR_IS_SET_TRANSITION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_SET_TRANSITION))
#define ANTLR_IS_SET_TRANSITION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_SET_TRANSITION))
#define ANTLR_SET_TRANSITION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_SET_TRANSITION, AntlrSetTransitionClass))

typedef struct _AntlrSetTransition AntlrSetTransition;
typedef struct _AntlrSetTransitionClass AntlrSetTransitionClass;

struct _AntlrSetTransition {
	AntlrTransition parent_instance;

    AntlrIntervalSet *set;
};

struct _AntlrSetTransitionClass {
	AntlrTransitionClass parent_class;
};

GType antlr_set_transition_get_type(void)G_GNUC_CONST;
AntlrSetTransition *antlr_set_transition_super (GType type, AntlrATNState *target, AntlrIntervalSet *set);
AntlrSetTransition *antlr_set_transition_new (AntlrATNState *target, AntlrIntervalSet *set);


G_END_DECLS

#endif /* __ANTLR_SET_TRANSITION_H__ */

