/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * atn.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_ATN_H__
#define __ANTLR_ATN_H__

#include <glib-object.h>

/**
 * AntlrATNType:
 * @LEXER: A lexer grammar.
 * @PARSER: A parser grammar.
 *
 * Represents the type of recognizer an ATN applies to.
 *
 */
typedef enum _AntlrATNType {
    LEXER,
    PARSER
} AntlrATNType;

/**
 * ANTLR_ATN_INVALID_ALT_NUMBER:
 *
 * Set to 0
 */
#define ANTLR_ATN_INVALID_ALT_NUMBER 0

#define ANTLR_TYPE_ATN            (antlr_atn_get_type())
#define ANTLR_ATN(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_ATN, AntlrATN))
#define ANTLR_ATN_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_ATN, AntlrATNClass))
#define ANTLR_IS_ATN(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_ATN))
#define ANTLR_IS_ATN_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_ATN))
#define ANTLR_ATN_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_ATN, AntlrATNClass))

typedef struct _AntlrATNClass AntlrATNClass;

/**
 * AntlrATN:
 * @states: some #GList of #AntlrATNState
 * @decision_to_state: Each subrule/rule is a decision point and we must track them so we
 * can go back later and build DFA predictors for them.  This includes
 * all the rules, subrules, optional blocks, ()+, ()* etc...
 * @rule_to_start_state: Maps from rule index to starting state number
 * @rule_to_stop_state: Maps from rule index to stop state number
 * @mode_name_to_start_state: A GHashTable associate GString with AntlrTokenStartState
 * @grammar_type: The grammar type
 * @max_token_type: The max token type
 * @rule_to_token_type: GArray of gint
 * @lexer_actions: For lexer ATNs, this is an array of #AntlrLexerAction objects which may
 * be referenced by action transitions in the ATN.
 * @mode_to_start_state: GList of AntlrTokensStartState
 */
struct _AntlrATN {
    AntlrObject parent_instance;

    /*< public >*/
    GList_AntlrATNState *states;// of #AntlrATNState By default = new ArrayList<ATNState>();
    GList *decision_to_state;// = <DecisionState> new ArrayList<DecisionState>();
    GPtrArray_AntlrATNState *rule_to_start_state;
    GPtrArray_AntlrATNState *rule_to_stop_state;
    GHashTable *mode_name_to_start_state;//Map<String, TokensStartState>
    AntlrATNType grammar_type;
    gint max_token_type;
    GArrayGInt *rule_to_token_type;// of gint
    GPtrArray_AntlrLexerAction *lexer_actions;
    GList* mode_to_start_state;// List<TokensStartState> = new ArrayList<TokensStartState>();
};

struct _AntlrATNClass {
    AntlrObjectClass parent_class;
};

GType antlr_atn_get_type(void)G_GNUC_CONST;
AntlrATN           *antlr_atn_new();
AntlrATN           *antlr_atn_new_from_type (AntlrATNType grammar_type, gint max_token_type);
AntlrIntervalSet   *antlr_atn_next_tokens(AntlrATN *self, AntlrATNState *s, AntlrRuleContext *ctx);
AntlrIntervalSet   *antlr_atn_next_tokens_from_state(AntlrATN *self, AntlrATNState *s);
int                 antlr_atn_define_decision_state(AntlrATN *atn, AntlrDecisionState *s);
gint                antlr_atn_get_number_of_decisions(AntlrATN *atn);
AntlrDecisionState *antlr_atn_get_decision_state(AntlrATN *atn, gint decision);
void                antlr_atn_add_state(AntlrATN *atn, AntlrATNState *state);
AntlrIntervalSet   *antlr_atn_get_expected_tokens(AntlrATN *atn, gint state_number, AntlrRuleContext* context);

G_END_DECLS

#endif /* __ANTLR_ATN_H__ */

