/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * precedence-predicate-transition.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"
#include "semantic-context.h"
#include "transition.h"
#include "abstract-predicate-transition.h"
#include "precedence-predicate-transition.h"

static gint
antlr_precedence_predicate_transition_class_transition_get_serialization_type(AntlrTransition *self) {
    return ANTLR_TRANSITION_PRECEDENCE;
}

static gboolean
antlr_precedence_predicate_transition_class_transition_is_epsilon(AntlrTransition *self) {
    return TRUE;
}

static gboolean
antlr_precedence_predicate_transition_class_transition_matches(AntlrTransition *self, gint symbol, gint min_vocab_symbol, gint max_vocab_symbol) {
    return FALSE;
}

static void antlr_precedence_predicate_transition_class_init(AntlrPrecedencePredicateTransitionClass *klass);
static void antlr_precedence_predicate_transition_init(AntlrPrecedencePredicateTransition *gobject);

G_DEFINE_TYPE (AntlrPrecedencePredicateTransition, antlr_precedence_predicate_transition, ANTLR_TYPE_ABSTRACT_PREDICATE_TRANSITION)

static void
antlr_precedence_predicate_transition_class_init(AntlrPrecedencePredicateTransitionClass *klass)
{
    AntlrTransitionClass *transition_class;
//    AntlrAbstractPredicateTransitionClass *abstract_transition_class;

    transition_class = (AntlrTransitionClass *) klass;
//    abstract_transition_class = (AntlrAbstractPredicateTransitionClass *) klass;

    transition_class->get_serialization_type = antlr_precedence_predicate_transition_class_transition_get_serialization_type;
    transition_class->is_epsilon = antlr_precedence_predicate_transition_class_transition_is_epsilon;
    transition_class->matches = antlr_precedence_predicate_transition_class_transition_matches;

//	antlr_precedence_predicate_transition_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_precedence_predicate_transition_init (AntlrPrecedencePredicateTransition *object)
{
    object->precedence = -1;
}


AntlrPrecedencePredicateTransition *
antlr_precedence_predicate_transition_new (AntlrATNState *target, gint precedence)
{
    AntlrPrecedencePredicateTransition *self = (AntlrPrecedencePredicateTransition *)antlr_transition_super (ANTLR_TYPE_PRECEDENCE_PREDICATE_TRANSITION, target);
    self->precedence = precedence;
    return self;
}

AntlrPrecedencePredicate*
antlr_precedence_predicate_transition_get_predicate(AntlrPrecedencePredicateTransition *self) {
    return (AntlrPrecedencePredicate*)antlr_precedence_predicate_new(self->precedence);
}


#if 0

public final class PrecedencePredicateTransition extends AbstractPredicateTransition {
    public final int precedence;

    public PrecedencePredicateTransition(ATNState target, int precedence) {
        super(target);
        this.precedence = precedence;
    }

    @Override
    public int getSerializationType() {
        return PRECEDENCE;
    }

    @Override
    public boolean isEpsilon() {
        return true;
    }

    @Override
    public boolean matches(int symbol, int minVocabSymbol, int maxVocabSymbol) {
        return false;
    }

    public SemanticContext.PrecedencePredicate getPredicate() {
        return new SemanticContext.PrecedencePredicate(precedence);
    }

    @Override
    public String toString() {
        return precedence + " >= _p";
    }

}

#endif
