/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * parser-atn-simulator.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"

#include "../misc/object.h"

#include "../vocabulary.h"
#include "../vocabulary-impl.h"

#include "../misc/double-key-map.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../misc/interval-set.h"
#include "../misc/bit-set.h"
#include "../int-stream.h"


#include "../token.h"
#include "../token-stream.h"
#include "../rule-context.h"
#include "../tree/tree.h"
#include "../tree/syntax-tree.h"
#include "../tree/parse-tree.h"
#include "../tree/terminal-node.h"
#include "../tree/terminal-node-impl.h"
#include "../tree/error-node.h"
#include "../tree/error-node-impl.h"
#include "../tree/parse-tree-listener.h"
#include "../parser-rule-context.h"
#include "atn-simulator.h"
#include "../recognizer.h"
#include "../parser.h"
#include "../error-listener.h"


#include "semantic-context.h"
#include "config.h"
#include "config-set.h"
#include "../dfa/dfa-state.h"
#include "../dfa/dfa.h"
#include "transition.h"
#include "lexer-action.h"
#include "atn-state.h"
#include "rule-stop-state.h"
#include "rule-start-state.h"
#include "atn.h"

#include "semantic-context.h"
#include "rule-transition.h"
#include "prediction-context.h"
#include "prediction-context-cache.h"
#include "prediction-mode.h"
#include "singleton-prediction-context.h"
#include "abstract-predicate-transition.h"
#include "predicate-transition.h"
#include "precedence-predicate-transition.h"

#include "transition.h"
#include "rule-transition.h"
#include "action-transition.h"
#include "epsilon-transition.h"
#include "atn-state.h"
#include "decision-state.h"


#include "parser-atn-simulator.h"

static gboolean antlr_parser_atn_simulator_debug = TRUE;
static gboolean antlr_parser_atn_simulator_debug_list_atn_decisions = TRUE;
static gboolean antlr_parser_atn_simulator_dfa_debug = TRUE;
static gboolean antlr_parser_atn_simulator_retry_debug = TRUE;


static gint               antlr_parser_atn_simulator_exec_atn(AntlrParserATNSimulator *self, AntlrDFA *dfa, AntlrDFAState *s0, AntlrTokenStream *input, gint start_index, AntlrParserRuleContext *outer_context);
static AntlrDFAState     *antlr_parser_atn_simulator_get_existing_target_state(AntlrParserATNSimulator *self, AntlrDFAState *previousD, gint t);
static AntlrDFAState     *antlr_parser_atn_simulator_compute_target_state(AntlrParserATNSimulator *self, AntlrDFA *dfa, AntlrDFAState *previous_dfa, gint t);
static void               antlr_parser_atn_simulator_predicate_dfa_state(AntlrParserATNSimulator *self, AntlrDFAState *dfaState, AntlrDecisionState *decisionState);
static gint               antlr_parser_atn_simulator_exec_atn_with_full_context(AntlrParserATNSimulator *self,
                                                                                AntlrDFA *dfa,
                                                                                AntlrDFAState *D, // how far we got in SLL DFA before failing over
                                                                                AntlrATNConfigSet *s0,
                                                                                AntlrTokenStream *input, gint startIndex,
                                                                                AntlrParserRuleContext *outerContext);
static AntlrATNConfigSet *antlr_parser_atn_simulator_compute_reach_set(AntlrParserATNSimulator *self, AntlrATNConfigSet *closure, gint t, gboolean fullCtx);
static AntlrATNState     *antlr_parser_atn_simulator_get_reachable_target(AntlrParserATNSimulator *self, AntlrTransition *trans, gint ttype);
static GArray            *antlr_parser_atn_simulator_get_preds_for_ambig_alts(AntlrParserATNSimulator *self, AntlrBitSet *ambigAlts, AntlrATNConfigSet *configs, gint nalts);
static GArray            *antlr_parser_atn_simulator_get_predicate_predictions(AntlrParserATNSimulator *self, AntlrBitSet *ambigAlts, GArray *altToPred/*of AntlrSemanticContext */);/* of AntlrPredPrediction */
static gint               antlr_parser_atn_simulator_get_syn_valid_or_sem_invalid_alt_that_finished_decision_entry_rule(AntlrParserATNSimulator *self,
                                                                                                                        AntlrATNConfigSet *configs,
                                                                                                                        AntlrParserRuleContext *outerContext);
static gint               antlr_parser_atn_simulator_get_alt_that_finished_decision_entry_rule(AntlrParserATNSimulator *self, AntlrATNConfigSet *configs);
static gint               antlr_parser_atn_simulator_get_unique_alt(AntlrParserATNSimulator *self, AntlrATNConfigSet *configs);
static AntlrATNConfigSet *antlr_parser_atn_simulator_remove_all_configs_not_in_rule_stop_state(AntlrParserATNSimulator *self, AntlrATNConfigSet *configs, gboolean lookToEndOfRule);
static AntlrDFAState     *antlr_parser_atn_simulator_add_dfa_edge(AntlrParserATNSimulator *self, AntlrDFA *dfa, AntlrDFAState *from, gint t, AntlrDFAState *to);
static AntlrDFAState     *antlr_parser_atn_simulator_add_dfa_state(AntlrParserATNSimulator *self, AntlrDFA *dfa, AntlrDFAState *D);
static void               antlr_parser_atn_simulator_report_attempting_full_context(AntlrParserATNSimulator *self,
                                                                                    AntlrDFA *dfa,
                                                                                    AntlrBitSet *conflictingAlts,
                                                                                    AntlrATNConfigSet *configs,
                                                                                    gint startIndex,
                                                                                    gint stopIndex);
static gboolean           antlr_parser_atn_simulator_eval_semantic_context(AntlrParserATNSimulator *self,
                                                                           AntlrSemanticContext *pred,
                                                                           AntlrParserRuleContext *parserCallStack,
                                                                           gint alt,
                                                                           gboolean fullCtx);
static void               antlr_parser_atn_simulator_report_context_sensitivity(AntlrParserATNSimulator *self,
                                                                                AntlrDFA *dfa,
                                                                                gint prediction,
                                                                                AntlrATNConfigSet *configs,
                                                                                gint startIndex,
                                                                                gint stopIndex);
static void               antlr_parser_atn_simulator_report_ambiguity(AntlrParserATNSimulator *self,
                                                                      AntlrDFA *dfa,
                                                                      AntlrDFAState *D, // the DFA state from execATN() that had SLL conflicts
                                                                      gint startIndex, gint stopIndex,
                                                                      gboolean exact,
                                                                      AntlrBitSet *ambigAlts,
                                                                      AntlrATNConfigSet *configs);

static void antlr_parser_atn_simulator_class_init(AntlrParserATNSimulatorClass *klass);
static void antlr_parser_atn_simulator_init(AntlrParserATNSimulator *gobject);

G_DEFINE_TYPE (AntlrParserATNSimulator, antlr_parser_atn_simulator, ANTLR_TYPE_ATN_SIMULATOR)

static void
antlr_parser_atn_simulator_class_init(AntlrParserATNSimulatorClass *klass)
{
//	AntlrATNSimulatorClass *antlratnsimulator_class;

//	antlratnsimulator_class = (AntlrATNSimulatorClass *) klass;

//	antlr_parser_atn_simulator_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_parser_atn_simulator_init (AntlrParserATNSimulator *object)
{
    //object->mode = AntlrPredictionMode.LL
    object->mode = ANTLR_PREDICTION_MODE_LL;

}

AntlrParserATNSimulator *
antlr_parser_atn_simulator_new (void)
{
    return g_object_new (antlr_parser_atn_simulator_get_type (),
                         NULL);
}

AntlrParserATNSimulator *
antlr_parser_atn_simulator_new_full (AntlrParser *parser,
                                     AntlrATN *atn,
                                     GArray *decision_to_dfa,
                                     AntlrPredictionContextCache *shared_context_cache)//decision_to_dfa: AntlrDFA[]
{
    AntlrParserATNSimulator *self = g_object_new (antlr_parser_atn_simulator_get_type (), NULL);
    antlr_atn_simulator_super(ANTLR_ATN_SIMULATOR(self), atn, shared_context_cache);
    self->parser = parser;
    self->decision_to_dfa = decision_to_dfa;
    return self;
}

/*
    public ParserATNSimulator(Parser parser, ATN atn,
                              DFA[] decisionToDFA,
                              PredictionContextCache sharedContextCache)
    {
        super(atn, sharedContextCache);
        this.parser = parser;
        this.decisionToDFA = decisionToDFA;
        //		DOTGenerator dot = new DOTGenerator(null);
        //		System.out.println(dot.getDOT(atn.rules.get(0), parser.getRuleNames()));
        //		System.out.println(dot.getDOT(atn.rules.get(1), parser.getRuleNames()));
    }
*/


#if 1 // ----------------------------------------------------------------------------

static void
antlr_parser_atn_simulator_closure_checking_stop_state(AntlrParserATNSimulator *self,
                                                       AntlrATNConfig *config,
                                                       AntlrATNConfigSet *configs,
                                                       GHashTable_AntlrATNConfig *closureBusy, /*    Set<ATNConfig>  */
                                                       gboolean collectPredicates,
                                                       gboolean fullCtx,
                                                       gint depth,
                                                       gboolean treatEofAsEpsilon);

static void
antlr_parser_atn_simulator_closure_(AntlrParserATNSimulator *self,
                                    AntlrATNConfig *config,
                                    AntlrATNConfigSet *configs,
                                    GHashTable_AntlrATNConfig *closureBusy, /* Set<ATNConfig> */
                                    gboolean collectPredicates,
                                    gboolean fullCtx,
                                    gint depth,
                                    gboolean treatEofAsEpsilon);
static AntlrATNConfig* antlr_parser_atn_simulator_get_epsilon_target(AntlrParserATNSimulator *self,
                                                                     AntlrATNConfig *config,
                                                                     AntlrTransition *t,
                                                                     gboolean collectPredicates,
                                                                     gboolean inContext,
                                                                     gboolean fullCtx,
                                                                     gboolean treatEofAsEpsilon);

static AntlrBitSet* antlr_parser_atn_simulator_get_conflicting_alts(AntlrParserATNSimulator *self, AntlrATNConfigSet *configs);
static AntlrBitSet* antlr_parser_atn_simulator_get_conflicting_alts_or_unique_alt(AntlrParserATNSimulator *self, AntlrATNConfigSet *configs);

static void
antlr_parser_atn_simulator_closure_checking_stop_state(AntlrParserATNSimulator *self,
                                                       AntlrATNConfig *config,
                                                       AntlrATNConfigSet *configs,
                                                       GHashTable_AntlrATNConfig *closureBusy, /*Set<ATNConfig> */
                                                       gboolean collectPredicates,
                                                       gboolean fullCtx,
                                                       gint depth,
                                                       gboolean treatEofAsEpsilon)
{
    if ( antlr_parser_atn_simulator_debug ) {
        gchar *str_config = antlr_atn_config_to_string_with_options(config, ANTLR_RECOGNIZER(self->parser), TRUE);
        g_print("closure(%s)\n", str_config);
        g_free(str_config);
    }

    if ( ANTLR_IS_RULE_STOP_STATE(config->state) ) {
        // We hit rule end. If we have context info, use it
        // run thru all possible stack tops in ctx
        if ( !antlr_prediction_context_is_empty(config->context) ) {
            gint i;
            gint size = antlr_prediction_context_size(config->context);
            for (i = 0; i < size; i++) {
                if ( antlr_prediction_context_get_return_state(config->context, i)==ANTLR_PREDICTION_CONTEXT_EMPTY_RETURN_STATE ) {
                    if (fullCtx) {
                        AntlrATNConfig *new_config = antlr_atn_config_new_with_config (config, config->state, ANTLR_PREDICTION_CONTEXT_EMPTY);
                        g_print("BAD implementation : self->merge_cache, from antlr_parser_atn_simulator_closure_checking_stop_state");
                        antlr_atn_config_set_add_with_cache(configs, new_config, self->merge_cache);
                        continue;
                    }
                    else {
                        // we have no context info, just chase follow links (if greedy)
                        if ( antlr_parser_atn_simulator_debug ) {
                            gchar *rule_name = antlr_parser_atn_simulator_get_rule_name(self, config->state->rule_index);
                            g_print("FALLING off rule %s\n", rule_name);
                            g_free(rule_name);
                        }
                        antlr_parser_atn_simulator_closure_(self,
                                                            config,
                                                            configs,
                                                            closureBusy,
                                                            collectPredicates,
                                                            fullCtx,
                                                            depth,
                                                            treatEofAsEpsilon);
                    }
                    continue;

                }

                gint n = antlr_prediction_context_get_return_state(config->context, i);
                AntlrATNState *returnState = g_list_nth_data(ANTLR_ATN_SIMULATOR(self)->atn->states, n);
                AntlrPredictionContext *newContext = antlr_prediction_context_get_parent(config->context, i);// "pop" return state
                AntlrATNConfig *c = antlr_atn_config_new_full(returnState, config->alt, newContext, config->semantic_context);
                // While we have context to pop back from, we may have
                // gotten that context AFTER having falling off a rule.
                // Make sure we track that we are now out of context.
                //
                // This assignment also propagates the
                // isPrecedenceFilterSuppressed() value to the new
                // configuration.
                c->reaches_into_outer_context = config->reaches_into_outer_context;
                g_assert(depth > G_MININT);
                antlr_parser_atn_simulator_closure_checking_stop_state(self, c, configs, closureBusy, collectPredicates,
                                         fullCtx, depth - 1, treatEofAsEpsilon);
            }
            return;
        } else if (fullCtx) {
            // reached end of start rule
            antlr_atn_config_set_add_with_cache(configs, config, self->merge_cache);
            return;
        } else {
            // else if we have no context info, just chase follow links (if greedy)
            if ( antlr_parser_atn_simulator_debug ) {
                gchar *str_rule_name = antlr_parser_atn_simulator_get_rule_name(self, config->state->rule_index);
                g_print("FALLING off rule %s\n", str_rule_name);
                g_free(str_rule_name);
            }
        }
    }

    antlr_parser_atn_simulator_closure_(self, config, configs, closureBusy, collectPredicates,
             fullCtx, depth, treatEofAsEpsilon);

}

#define TURN_OFF_LR_LOOP_ENTRY_BRANCH_OPT FALSE
#include "star-loop-entry-state.h"
#include "block-start-state.h"
static gboolean
antlr_parser_atn_simulator_can_drop_loop_entry_edge_in_left_recursive_rule(AntlrParserATNSimulator *self, AntlrATNConfig *config) {

    if ( TURN_OFF_LR_LOOP_ENTRY_BRANCH_OPT )
        return FALSE;

    AntlrATNState *p = config->state;
    // First check to see if we are in StarLoopEntryState generated during
    // left-recursion elimination. For efficiency, also check if
    // the context has an empty stack case. If so, it would mean
    // global FOLLOW so we can't perform optimization

    if ( antlr_atn_state_get_state_type(p) != ANTLR_ATN_STATE_STAR_LOOP_ENTRY ||
         !ANTLR_STAR_LOOP_ENTRY_STATE(p)->is_precedence_decision || // Are we the special loop entry/exit state?
         antlr_prediction_context_is_empty(config->context) ||                      // If SLL wildcard
         antlr_prediction_context_has_empty_path(config->context))
    {
        return FALSE;
    }

    GList *states = ANTLR_ATN_SIMULATOR(self)->atn->states;
    // Require all return states to return back to the same rule
    // that p is in.
    int numCtxs = antlr_prediction_context_size(config->context);
    int i;
    for (i = 0; i < numCtxs; i++) { // for each stack context
        guint n = antlr_prediction_context_get_return_state(config->context, i);
        AntlrATNState *returnState = g_list_nth_data(states, n);
        if ( returnState->rule_index != p->rule_index )
            return FALSE;
    }

    AntlrTransition *transition = g_list_nth_data(ANTLR_ATN_STATE(p)->transitions, 0);
    AntlrBlockStartState *decisionStartState = ANTLR_BLOCK_START_STATE(transition->target);
    int blockEndStateNum = ANTLR_ATN_STATE(decisionStartState->end_state)->state_number;
    AntlrBlockEndState *blockEndState = g_list_nth_data(states, blockEndStateNum);

    // Verify that the top of each stack context leads to loop entry/exit
    // state through epsilon edges and w/o leaving rule.
    for (i = 0; i < numCtxs; i++) {                           // for each stack context
        int returnStateNumber = antlr_prediction_context_get_return_state(config->context, i);
        AntlrATNState *returnState = g_list_nth_data(states, returnStateNumber);
        // all states must have single outgoing epsilon edge
        AntlrTransition * transition_0 = g_list_nth_data(returnState->transitions, 0);
        if ( antlr_atn_state_get_number_of_transitions(returnState)!=1 ||
             !antlr_transition_is_epsilon(transition_0) )
        {
            return FALSE;
        }
        // Look for prefix op case like 'not expr', (' type ')' expr
        AntlrATNState *returnStateTarget = transition_0->target;
        if ( antlr_atn_state_get_state_type(returnState)==ANTLR_ATN_STATE_BLOCK_END
          && returnStateTarget==p ) {
            continue;
        }
        // Look for 'expr op expr' or case where expr's return state is block end
        // of (...)* internal block; the block end points to loop back
        // which points to p but we don't need to check that
        if ( returnState==blockEndState ) {
            continue;
        }
        // Look for ternary expr ? expr : expr. The return state points at block end,
        // which points at loop entry state
        if ( returnStateTarget==blockEndState ) {
            continue;
        }
        // Look for complex prefix 'between expr and expr' case where 2nd expr's
        // return state points at block end state of (...)* internal block

        transition_0 = g_list_nth_data(returnStateTarget->transitions, 0);
        if ( antlr_atn_state_get_state_type(returnStateTarget)==ANTLR_ATN_STATE_BLOCK_END
             && antlr_atn_state_get_number_of_transitions(returnStateTarget)==1
             && antlr_transition_is_epsilon(transition_0)
             && transition_0->target == p)
        {
            continue;
        }

        // anything else ain't conforming
        return FALSE;

    }

    return TRUE;
}

/** Do the actual work of walking epsilon edges */
static void
antlr_parser_atn_simulator_closure_(AntlrParserATNSimulator *self,
                                    AntlrATNConfig *config,
                                    AntlrATNConfigSet *configs,
                                    GHashTable_AntlrATNConfig *closureBusy, /* Set<ATNConfig> */
                                    gboolean collectPredicates,
                                    gboolean fullCtx,
                                    gint depth,
                                    gboolean treatEofAsEpsilon)
{
    AntlrATNState *p = config->state;
    // TODO make a break point on second pass on config.toString=="(134,1,[$],up=1)"
    // optimization
    if ( !antlr_atn_state_only_has_epsilon_transitions(p) ) {
        antlr_atn_config_set_add_with_cache(configs, config, self->merge_cache);
        // make sure to not return here, because EOF transitions can act as
        // both epsilon transitions and non-epsilon transitions.
//            if ( debug ) System.out.println("added config "+configs);
    }

    gint i;
    GList *transitions = antlr_atn_state_get_transitions(p);
    gint num = g_list_length(transitions);
    for (i=0; i<num; i++) {
        if ( i==0 && antlr_parser_atn_simulator_can_drop_loop_entry_edge_in_left_recursive_rule(self, config) )
            continue;

        AntlrTransition *t = antlr_atn_state_transition(p, i);
        gboolean continueCollecting = !ANTLR_IS_ACTION_TRANSITION(t) && collectPredicates;
        AntlrATNConfig *c = antlr_parser_atn_simulator_get_epsilon_target(self, config, t, continueCollecting,
                                       depth == 0, fullCtx, treatEofAsEpsilon);
        if ( c!=NULL ) {
            if (!antlr_transition_is_epsilon(t)) {
                gboolean added = g_hash_table_add(closureBusy, (gpointer)c);
                if (! added) {
                    // avoid infinite recursion for EOF* and EOF+
                    continue;
                }
                // if replaced what append for the old value ?
                //g_object_ref(c);
            }

            gint newDepth = depth;
            if ( ANTLR_IS_RULE_STOP_STATE(config->state) ) {
                g_assert (!fullCtx);
                // target fell off end of rule; mark resulting c as having dipped into outer context
                // We can't get here if incoming config was rule stop and we had context
                // track how far we dip into outer context.  Might
                // come in handy and we avoid evaluating context dependent
                // preds if this is > 0.

                gboolean added = g_hash_table_add(closureBusy, (gpointer)c);
                if ( !added ) {
                    // avoid infinite recursion for right-recursive rules
                    continue;
                }
                //g_object_ref(c);// replace ??

                if (self->dfa != NULL && antlr_dfa_is_precedence_dfa(self->dfa)) {
                    gint outermostPrecedenceReturn = antlr_epsilon_transition_outermost_precedence_return(ANTLR_EPSILON_TRANSITION(t));
                    if (outermostPrecedenceReturn ==
                            ANTLR_ATN_STATE(self->dfa->atn_start_state)->rule_index) {
                        antlr_atn_config_set_precedence_filter_suppressed(c, TRUE);
                    }
                }

                c->reaches_into_outer_context++;
                configs->dips_into_outer_context = TRUE; // TODO: can remove? only care when we add to set per middle of this method
                g_assert( newDepth > G_MININT );
                newDepth--;
                if ( antlr_parser_atn_simulator_debug ) {
                    gchar *str_config = antlr_object_to_string(ANTLR_OBJECT(c));
                    g_print("dips into outer ctx: %s\n", str_config );
                    g_free(str_config);
                }

            } else if (ANTLR_IS_RULE_TRANSITION(t)) {
                // latch when newDepth goes negative - once we step out of the entry context we can't return
                if (newDepth >= 0) {
                    newDepth++;
                }
            }

            antlr_parser_atn_simulator_closure_checking_stop_state(self, c, configs, closureBusy, continueCollecting,
                                     fullCtx, newDepth, treatEofAsEpsilon);
        }
    }
}


/**
 * antlr_parser_atn_simulator_eval_semantic_context_from_predictions:
 * @self: Some #AntlrParserATNSimulator
 * @predPredictions: GArray Of #AntlrPredPrediction
 * @outerContext: The context instance
 * @complete: If complete
 *
 * Look through a list of predicate/alt pairs, returning alts for the
 *  pairs that win. A {@code NONE} predicate indicates an alt containing an
 *  unpredicated config which behaves as "always true." If !complete
 *  then we stop at the first predicate that evaluates to true. This
 *  includes pairs with null predicates.
 */
static AntlrBitSet*
antlr_parser_atn_simulator_eval_semantic_context_from_predictions(AntlrParserATNSimulator *self,
                                                                  GArray *predPredictions, /* of AntlrPredPrediction */
                                                                  AntlrParserRuleContext *outerContext,
                                                                  gboolean complete)
{
    AntlrBitSet *predictions = antlr_bit_set_new();
    gint i;
    for (i=0; i<predPredictions->len; i++) {
        // DFAState.PredPrediction pair : predPredictions
        AntlrPredPrediction *pair = g_array_index(predPredictions, AntlrPredPrediction *, i);
        if ( pair->pred==ANTLR_SEMANTIC_CONTEXT_NONE ) {
            antlr_bit_set_set(predictions, pair->alt, TRUE);
            if (!complete) {
                break;
            }
            continue;
        }

        gboolean fullCtx = FALSE; // in dfa
        gboolean predicateEvaluationResult = antlr_parser_atn_simulator_eval_semantic_context(self, pair->pred, outerContext, pair->alt, fullCtx);
        if ( antlr_parser_atn_simulator_debug || antlr_parser_atn_simulator_dfa_debug ) {
            gchar *str_pair = antlr_pred_prediction_to_string(pair);
            g_print("eval pred %s=%s\n", str_pair, predicateEvaluationResult?"true":"false");
            g_free(str_pair);
        }

        if ( predicateEvaluationResult ) {
            if ( antlr_parser_atn_simulator_debug || antlr_parser_atn_simulator_dfa_debug )
                g_print("PREDICT %d\n", pair->alt);
            antlr_bit_set_set(predictions, pair->alt, TRUE);
            if (!complete) {
                break;
            }
        }

    }

    return predictions;
}

/**
 * antlr_parser_atn_simulator_eval_semantic_context:
 * @self: Some #AntlrParserATNSimulator
 * @pred: The semantic context to evaluate
 * @parserCallStack: The parser context in which to evaluate the
 * semantic context
 * @alt: The alternative which is guarded by @pred
 * @fullCtx: %TRUE if the evaluation is occurring during LL
 * prediction; otherwise, %FALSE if the evaluation is occurring
 * during SLL prediction
 *
 * Evaluate a semantic context within a specific parser context.
 *
 * <p>
 * This method might not be called for every semantic context evaluated
 * during the prediction process. In particular, we currently do not
 * evaluate the following but it may change in the future:</p>
 *
 * - Precedence predicates (represented by
 * {@link SemanticContext.PrecedencePredicate}) are not currently evaluated
 * through this method.
 * - Operator predicates (represented by {@link SemanticContext.AND} and
 * {@link SemanticContext.OR}) are evaluated as a single semantic
 * context, rather than evaluating the operands individually.
 * Implementations which require evaluation results from individual
 * predicates should override this method to explicitly handle evaluation of
 * the operands within operator predicates.
 *
 */
static gboolean
antlr_parser_atn_simulator_eval_semantic_context(AntlrParserATNSimulator *self,
                                                 AntlrSemanticContext *pred,
                                                 AntlrParserRuleContext *parserCallStack,
                                                 gint alt,
                                                 gboolean fullCtx) {
    return antlr_semantic_context_eval(pred, ANTLR_RECOGNIZER(self->parser), ANTLR_RULE_CONTEXT(parserCallStack));
}

/* TODO: If we are doing predicates, there is no point in pursuing
     closure operations if we reach a DFA state that uniquely predicts
     alternative. We will not be caching that DFA state and it is a
     waste to pursue the closure. Might have to advance when we do
     ambig detection thought :(
      */
static void
antlr_parser_atn_simulator_closure(AntlrParserATNSimulator *self,
                                   AntlrATNConfig *config,
                                   AntlrATNConfigSet *configs,
                                   GHashTable *closureBusy, /* Set<ATNConfig> */
                                   gboolean collectPredicates,
                                   gboolean fullCtx,
                                   gboolean treatEofAsEpsilon)
{
    gint initialDepth = 0;
    antlr_parser_atn_simulator_closure_checking_stop_state(self, config, configs, closureBusy, collectPredicates,
                             fullCtx,
                             initialDepth, treatEofAsEpsilon);
    g_assert( !fullCtx || !configs->dips_into_outer_context);

}

/**
 * antlr_parser_atn_simulator_split_according_to_semantic_validity:
 * @self: Some #AntlrParserATNSimulator
 * @configs: The config
 * @outerContext: The context
 * @semValidConfigs: the valid config
 * @semInvalidConfigs: the invalid config
 *
 * Walk the list of configurations and split them according to
 *  those that have preds evaluating to true/false.  If no pred, assume
 *  true pred and include in succeeded set.  Returns Pair of sets.
 *
 *  Create a new set so as not to alter the incoming parameter.
 *
 *  Assumption: the input stream has been restored to the starting point
 *  prediction, which is where predicates need to evaluate.
 */
static void //Pair<ATNConfigSet,ATNConfigSet>
antlr_parser_atn_simulator_split_according_to_semantic_validity(AntlrParserATNSimulator *self,
                                                                AntlrATNConfigSet *configs,
                                                                AntlrParserRuleContext *outerContext,
                                                                AntlrATNConfigSet **semValidConfigs,
                                                                AntlrATNConfigSet **semInvalidConfigs)
{
    AntlrATNConfigSet *succeeded = antlr_atn_config_set_new_with_context(configs->full_ctx);
    AntlrATNConfigSet *failed = antlr_atn_config_set_new_with_context(configs->full_ctx);
    GList *it;
    for (it = g_list_first(configs->configs); it; it=it->next) {
        AntlrATNConfig *c = it->data;
        if ( c->semantic_context!=ANTLR_SEMANTIC_CONTEXT_NONE ) {
            gboolean predicateEvaluationResult = antlr_parser_atn_simulator_eval_semantic_context(self, c->semantic_context, outerContext, c->alt, configs->full_ctx);
            if ( predicateEvaluationResult ) {
                antlr_atn_config_set_add(succeeded, c);
            } else {
                antlr_atn_config_set_add(failed, c);
            }
        } else {
            antlr_atn_config_set_add(succeeded, c);
        }
    }
    *semValidConfigs = succeeded;
    *semInvalidConfigs = failed;
}

#endif // ----------------------------------------------------------------------------


/**
 * antlr_parser_atn_simulator_remove_all_configs_not_in_rule_stop_state:
 * @self: The some #AntlrParserATNSimulator
 * @configs: The configuration set to update
 * @lookToEndOfRule: When true, this method checks for rule stop states
 * reachable by epsilon-only transitions from each configuration in @configs.
 *
 * Return a configuration set containing only the configurations from
 * {@code configs} which are in a #AntlrRuleStopState. If all
 * configurations in {@code configs} are already in a rule stop state, this
 * method simply returns {@code configs}.
 *
 * <p>When {@code lookToEndOfRule} is true, this method uses
 * {@link ATN#nextTokens} for each configuration in {@code configs} which is
 * not already in a rule stop state to see if a rule stop state is reachable
 * from the configuration via epsilon-only transitions.</p>
 *
 * Returns: @configs if all configurations in @configs are in a
 * rule stop state, otherwise return a new configuration set containing only
 * the configurations from @configs which are in a rule stop state
 */
static AntlrATNConfigSet*
antlr_parser_atn_simulator_remove_all_configs_not_in_rule_stop_state(AntlrParserATNSimulator *self,
                                                                     AntlrATNConfigSet *configs,
                                                                     gboolean lookToEndOfRule)
{
    if (antlr_prediction_mode_all_configs_in_rule_stop_states(configs)) {
        return configs;
    }

    AntlrATNConfigSet *result = antlr_atn_config_set_new_with_context(configs->full_ctx);
    GList *it;
    for (it = g_list_first(configs->configs); it; it=it->next) {
        AntlrATNConfig *config = it->data;
        if (ANTLR_IS_RULE_STOP_STATE(config->state)) {
            antlr_atn_config_set_add_with_cache(result, config, self->merge_cache);
            continue;
        }

        if (lookToEndOfRule && antlr_atn_state_only_has_epsilon_transitions(config->state)) {
            AntlrATN *atn = ANTLR_ATN_SIMULATOR(self)->atn;
            AntlrIntervalSet *nextTokens = antlr_atn_next_tokens_from_state(atn, config->state);
            if (antlr_int_iset_contains(ANTLR_INT_ISET(nextTokens), ANTLR_TOKEN_EPSILON)) {
                AntlrATNState *endOfRuleState = g_ptr_array_index(atn->rule_to_stop_state, config->state->rule_index);
                antlr_atn_config_set_add_with_cache(result, antlr_atn_config_new_with_config_state(config, endOfRuleState), self->merge_cache);
            }
        }
    }
    return result;
}

static AntlrATNConfigSet*
antlr_parser_atn_simulator_compute_start_state(AntlrParserATNSimulator *self,
                                               AntlrATNState *p,
                                               AntlrRuleContext *ctx,
                                               gboolean fullCtx)
{
    // always at least the implicit call to start rule
    AntlrPredictionContext *initialContext = antlr_prediction_context_new_from_rule_context(ANTLR_ATN_SIMULATOR(self)->atn, ctx);
    AntlrATNConfigSet *configs = antlr_atn_config_set_new_with_context(fullCtx);

    gint num_transition = antlr_atn_state_get_number_of_transitions(p);
    gint i;
    for (i=0; i<num_transition; i++) {// TODO: use GList *it = g_list_first(p->transitions); it; it=it->next
        AntlrTransition *transition = antlr_atn_state_transition(p, i);
        AntlrATNState *target = transition->target;
        AntlrATNConfig *c = antlr_atn_config_new_with_state(target, i+1, initialContext);
        //g_print("CHECK implementation of g_hash_table from: antlr_parser_atn_simulator_compute_start_state\n");
        //g_hash_table_new(antlr_atn_config_hash_code, antlr_atn_config_equals);
        GHashTable *closureBusy = g_hash_table_new((GHashFunc)antlr_atn_config_hash_code, (GEqualFunc)antlr_atn_config_equals); // Set<AntlrATNConfig> closureBusy = new HashSet<ATNConfig>();
        antlr_parser_atn_simulator_closure(self, c, configs, closureBusy, TRUE, fullCtx, FALSE);
        g_hash_table_unref(closureBusy);
    }

    return configs;
}

/**
 * antlr_parser_atn_simulator_apply_precedence_filter:
 * @self: Some #AntlrParserATNSimulator
 * @configs: The configuration set computed by
 * #antlr_parser_atn_simulator_compute_start_state as the start state for the DFA.
 *
 * This method transforms the start state computed by
 * #antlr_parser_atn_simulator_compute_start_state to the special start state used by a
 * precedence DFA for a particular precedence value. The transformation
 * process applies the following changes to the start state's configuration
 * set.
 *
 * <ol>
 * <li>Evaluate the precedence predicates for each configuration using
 * {@link SemanticContext#evalPrecedence}.</li>
 * <li>When {@link ATNConfig#isPrecedenceFilterSuppressed} is {@code false},
 * remove all configurations which predict an alternative greater than 1,
 * for which another configuration that predicts alternative 1 is in the
 * same ATN state with the same prediction context. This transformation is
 * valid for the following reasons:
 * <ul>
 * <li>The closure block cannot contain any epsilon transitions which bypass
 * the body of the closure, so all states reachable via alternative 1 are
 * part of the precedence alternatives of the transformed left-recursive
 * rule.</li>
 * <li>The "primary" portion of a left recursive rule cannot contain an
 * epsilon transition, so the only way an alternative other than 1 can exist
 * in a state that is also reachable via alternative 1 is by nesting calls
 * to the left-recursive rule, with the outer calls not being at the
 * preferred precedence level. The
 * {@link ATNConfig#isPrecedenceFilterSuppressed} property marks ATN
 * configurations which do not meet this condition, and therefore are not
 * eligible for elimination during the filtering process.</li>
 * </ul>
 * </li>
 * </ol>
 *
 * <p>
 * The prediction context must be considered by this filter to address
 * situations like the following.
 * </p>
 * <code>
 * <pre>
 * grammar TA;
 * prog: statement* EOF;
 * statement: letterA | statement letterA 'b' ;
 * letterA: 'a';
 * </pre>
 * </code>
 * <p>
 * If the above grammar, the ATN state immediately before the token
 * reference {@code 'a'} in {@code letterA} is reachable from the left edge
 * of both the primary and closure blocks of the left-recursive rule
 * {@code statement}. The prediction context associated with each of these
 * configurations distinguishes between them, and prevents the alternative
 * which stepped out to {@code prog} (and then back in to {@code statement}
 * from being eliminated by the filter.
 * </p>
 *
 * Returns: The transformed configuration set representing the start state
 * for a precedence DFA at a particular precedence level (determined by
 * calling {@link Parser#getPrecedence}).
 */
static AntlrATNConfigSet*
antlr_parser_atn_simulator_apply_precedence_filter(AntlrParserATNSimulator *self, AntlrATNConfigSet *configs) {
    GHashTable_Gint_AntlrPredictionContext *statesFromAlt1 = g_hash_table_new(g_direct_hash, antlr_prediction_context_hash_code);/* of Integer, PredictionContext */
    AntlrATNConfigSet *configSet = antlr_atn_config_set_new_with_context(configs->full_ctx);

    GList *list = NULL;
    for (list = g_list_first(configs->configs); list; list=list->next) {
        AntlrATNConfig *config = list->data;
        // handle alt 1 first
        if (config->alt != 1) {
            continue;
        }
        AntlrSemanticContext *updatedContext = antlr_semantic_context_eval_precedence(config->semantic_context, ANTLR_RECOGNIZER(self->parser), ANTLR_RULE_CONTEXT(self->outer_context));
        if (updatedContext == NULL) {
            // the configuration was eliminated
            continue;
        }

        g_hash_table_insert(statesFromAlt1,GINT_TO_POINTER(config->state->state_number), (gpointer)config->context);
        if (updatedContext != config->semantic_context) {
            AntlrATNConfig *conf = antlr_atn_config_new_with_config_semantic(config, updatedContext);
            antlr_atn_config_set_add_with_cache(configSet, conf, self->merge_cache);
        } else {
            antlr_atn_config_set_add_with_cache(configSet, config, self->merge_cache);
        }
    }

    for (list = g_list_first(configs->configs); list; list=list->next) {
        AntlrATNConfig *config = list->data;
        if (config->alt == 1) {
            // already handled
            continue;
        }

        if (!antlr_atn_config_is_precedence_filter_suppressed(config)) {
            /* In the future, this elimination step could be updated to also
             * filter the prediction context for alternatives predicting alt>1
             * (basically a graph subtraction algorithm).
             */
            GHashTableIter iter;
            gpointer key, value;
            gpointer search_key = GINT_TO_POINTER(config->state->state_number);
            AntlrPredictionContext *context = NULL;
            g_hash_table_iter_init (&iter, statesFromAlt1);
            while (g_hash_table_iter_next (&iter, &key, &value))
              {
                if (search_key == key) {
                    context = (AntlrPredictionContext*)value;
                }
              }
            if (context != NULL && antlr_prediction_context_equals(context, G_OBJECT(config->context)) ) {
                // eliminated
                continue;
            }
        }
        antlr_atn_config_set_add_with_cache(configSet, config, self->merge_cache);

    }

    return configSet;
}

static AntlrATNState*
antlr_parser_atn_simulator_get_reachable_target(AntlrParserATNSimulator *self,
                                                AntlrTransition *trans,
                                                gint ttype)
{
    AntlrATN *atn = ANTLR_ATN_SIMULATOR(self)->atn;
    if (antlr_transition_matches(trans, ttype, 0, atn->max_token_type)) {
        return trans->target;
    }

    return NULL;
}
static GArray*
antlr_parser_atn_simulator_get_preds_for_ambig_alts(AntlrParserATNSimulator *self, AntlrBitSet *ambigAlts, AntlrATNConfigSet *configs, gint nalts)
{
    // REACH=[1|1|[]|0:0, 1|2|[]|0:1]
    /* altToPred starts as an array of all null contexts. The entry at index i
     * corresponds to alternative i. altToPred[i] may have one of three values:
     *   1. null: no ATNConfig c is found such that c.alt==i
     *   2. SemanticContext.NONE: At least one ATNConfig c exists such that
     *      c.alt==i and c.semanticContext==SemanticContext.NONE. In other words,
     *      alt i has at least one unpredicated config.
     *   3. Non-NONE Semantic Context: There exists at least one, and for all
     *      ATNConfig c such that c.alt==i, c.semanticContext!=SemanticContext.NONE.
     *
     * From this, it is clear that NONE||anything==NONE.
     */
    GArray *altToPred = g_array_sized_new(FALSE, TRUE, sizeof(AntlrSemanticContext*), nalts+1);
    g_array_set_size(altToPred, nalts+1);
    GList *it;
    for (it = g_list_first(configs->configs); it; it=it->next) {
        AntlrATNConfig *c = it->data;
        if ( antlr_bit_set_get(ambigAlts, c->alt) ) {
            AntlrSemanticContext *a = g_array_index(altToPred, AntlrSemanticContext*, c->alt);
            g_array_index(altToPred, AntlrSemanticContext*, c->alt) = antlr_semantic_context_or(a, c->semantic_context);
        }
    }

    int nPredAlts = 0;
    int i;
    for (i = 1; i <= nalts; i++) {
        AntlrSemanticContext *a = g_array_index(altToPred, AntlrSemanticContext*, i);
        if (a == NULL) {
            g_array_index(altToPred, AntlrSemanticContext*, i) = ANTLR_SEMANTIC_CONTEXT_NONE;
        } else if (a != ANTLR_SEMANTIC_CONTEXT_NONE) {
            nPredAlts++;
        }
    }

//		// Optimize away p||p and p&&p TODO: optimize() was a no-op
//		for (int i = 0; i < altToPred.length; i++) {
//			altToPred[i] = altToPred[i].optimize();
//		}

    // nonambig alts are null in altToPred
    if ( nPredAlts==0 ) {
        g_array_free(altToPred, FALSE);
        altToPred = NULL;
    }
    if ( antlr_parser_atn_simulator_debug ) {
        gchar *tmp=NULL;
        gchar *comma = ", ";
        gchar *glue = "";
        GString *out = g_string_new("[");
        for(i=0; i<altToPred->len; i++) {
            AntlrSemanticContext *ctx = g_array_index(altToPred, AntlrSemanticContext *, i);
            gchar *str = "null";
            if (ctx) {
                str = antlr_object_to_string(ANTLR_OBJECT(ctx));
            }
            g_string_append(out, glue);
            g_string_append(out, str);
            glue = comma;
        }
        g_string_append(out, "]");
        g_print("getPredsForAmbigAlts result %s\n", g_string_free(out, FALSE));// [null, {-1:-1}?, {2:0}?]
    }
    return altToPred;
}


static GArray* /*of AntlrPredPrediction*/
antlr_parser_atn_simulator_get_predicate_predictions(AntlrParserATNSimulator *self,
                                                     AntlrBitSet *ambigAlts,
                                                     GArray *altToPred/*of AntlrSemanticContext */)
{
    GArray *pairs = g_array_new(FALSE, TRUE, sizeof(AntlrPredPrediction*));
    gboolean containsPredicate = FALSE;
    int i;
    for (i = 1; i < altToPred->len; i++) {
        AntlrSemanticContext *pred = g_array_index(altToPred, AntlrSemanticContext *, i);

        // unpredicated is indicated by SemanticContext.NONE
        g_assert(pred != NULL);

        if (ambigAlts!=NULL && antlr_bit_set_get(ambigAlts, i)) {
            AntlrPredPrediction *prediction = antlr_pred_prediction_new(pred, i);
            g_array_append_val(pairs, prediction);
        }
        if ( pred!=ANTLR_SEMANTIC_CONTEXT_NONE )
            containsPredicate = TRUE;
    }

    if ( !containsPredicate ) {
        g_array_free(pairs, FALSE);
        return NULL;
    }

    return pairs;
}


/**
 * antlr_parser_atn_simulator_get_syn_valid_or_sem_invalid_alt_that_finished_decision_entry_rule:
 * @self: Some #AntlrParserATNSimulator
 * @configs: The ATN configurations which were valid immediately before
 * the {@link #ERROR} state was reached
 * @outerContext: The is the \gamma_0 initial parser context from the paper
 * or the parser stack at the instant before prediction commences.
 *
 * This method is used to improve the localization of error messages by
 * choosing an alternative rather than throwing a
 * {@link NoViableAltException} in particular prediction scenarios where the
 * {@link #ERROR} state was reached during ATN simulation.
 *
 * <p>
 * The default implementation of this method uses the following
 * algorithm to identify an ATN configuration which successfully parsed the
 * decision entry rule. Choosing such an alternative ensures that the
 * {@link ParserRuleContext} returned by the calling rule will be complete
 * and valid, and the syntax error will be reported later at a more
 * localized location.</p>
 *
 * <ul>
 * <li>If a syntactically valid path or paths reach the end of the decision rule and
 * they are semantically valid if predicated, return the min associated alt.</li>
 * <li>Else, if a semantically invalid but syntactically valid path exist
 * or paths exist, return the minimum associated alt.
 * </li>
 * <li>Otherwise, return #ANTLR_ATN_INVALID_ALT_NUMBER.</li>
 * </ul>
 *
 * <p>
 * In some scenarios, the algorithm described above could predict an
 * alternative which will result in a {@link FailedPredicateException} in
 * the parser. Specifically, this could occur if the <em>only</em> configuration
 * capable of successfully parsing to the end of the decision rule is
 * blocked by a semantic predicate. By choosing this alternative within
 * {@link #adaptivePredict} instead of throwing a
 * {@link NoViableAltException}, the resulting
 * {@link FailedPredicateException} in the parser will identify the specific
 * predicate which is preventing the parser from successfully parsing the
 * decision rule, which helps developers identify and correct logic errors
 * in semantic predicates.
 * </p>
 *
 * Returns: The value to return from {@link #adaptivePredict}, or
 * #ANTLR_ATN_INVALID_ALT_NUMBER if a suitable alternative was not
 * identified and {@link #adaptivePredict} should report an error instead.
 */
static gint
antlr_parser_atn_simulator_get_syn_valid_or_sem_invalid_alt_that_finished_decision_entry_rule(AntlrParserATNSimulator *self,
                                                                                              AntlrATNConfigSet *configs,
                                                                                              AntlrParserRuleContext *outerContext)
{
    AntlrATNConfigSet *semValidConfigs;
    AntlrATNConfigSet *semInvalidConfigs;
    antlr_parser_atn_simulator_split_according_to_semantic_validity(self, configs, outerContext, &semValidConfigs, &semInvalidConfigs);
    gint alt = antlr_parser_atn_simulator_get_alt_that_finished_decision_entry_rule(self, semValidConfigs);
    if ( alt!=ANTLR_ATN_INVALID_ALT_NUMBER ) { // semantically/syntactically viable path exists
        return alt;
    }
    // Is there a syntactically valid path with a failed pred?
    if ( antlr_atn_config_set_size(semInvalidConfigs)>0 ) {
        alt = antlr_parser_atn_simulator_get_alt_that_finished_decision_entry_rule(self, semInvalidConfigs);
        if ( alt!=ANTLR_ATN_INVALID_ALT_NUMBER ) { // syntactically viable path exists
            return alt;
        }
    }
    return ANTLR_ATN_INVALID_ALT_NUMBER;
}

static gint
antlr_parser_atn_simulator_get_alt_that_finished_decision_entry_rule(AntlrParserATNSimulator *self,
                                                                     AntlrATNConfigSet *configs)
{
    AntlrIntervalSet *alts = antlr_interval_set_new();
    GList *it;
    for (it = g_list_first(configs->configs); it; it=it->next) {
        AntlrATNConfig *c = it->data;

        if ( antlr_atn_config_get_outer_context_depth(c)>0
          || (ANTLR_IS_RULE_STOP_STATE(c->state) && antlr_prediction_context_has_empty_path(c->context)) ) {
            antlr_int_iset_add(ANTLR_INT_ISET(alts), c->alt);
        }
    }

    if ( antlr_int_iset_size(ANTLR_INT_ISET(alts))==0 )
        return ANTLR_ATN_INVALID_ALT_NUMBER;
    return antlr_interval_set_get_min_element(alts);
}

/**
 * antlr_parser_atn_simulator_add_dfa_edge:
 * @self: Some #AntlrParserATNSimulator
 * @dfa: The DFA
 * @from: The source state for the edge
 * @t: The input symbol
 * @to: The target state for the edge
 *
 * Add an edge to the DFA, if possible. This method calls
 * {@link #addDFAState} to ensure the {@code to} state is present in the
 * DFA. If {@code from} is %NULL, or if {@code t} is outside the
 * range of edges that can be represented in the DFA tables, this method
 * returns without adding the edge to the DFA.
 *
 * <p>If {@code to} is %NULL, this method returns %NULL.
 * Otherwise, this method returns the {@link DFAState} returned by calling
 * {@link #addDFAState} for the {@code to} state.</p>
 *
 *
 * Returns: If @to is %NULL, this method returns %NULL;
 * otherwise this method returns the result of calling {@link #addDFAState}
 * on @to
 */
static AntlrDFAState*
antlr_parser_atn_simulator_add_dfa_edge(AntlrParserATNSimulator *self,
                                        AntlrDFA *dfa,
                                        AntlrDFAState *from,
                                        gint t,
                                        AntlrDFAState *to)
{
    if ( antlr_parser_atn_simulator_debug ) {
        gchar *str_from  = antlr_object_to_string(ANTLR_OBJECT(from));
        gchar *str_to    = antlr_object_to_string(ANTLR_OBJECT(to));
        gchar *str_token = antlr_parser_atn_simulator_get_token_name(self, t);
        g_print("EDGE %s -> %s upon %s\n", str_from, str_to, str_token);
        g_free(str_from);
        g_free(str_to);
        g_free(str_token);
    }

    if (to == NULL) {
        return NULL;
    }

    to = antlr_parser_atn_simulator_add_dfa_state(self, dfa, to);
    if (from == NULL || t < -1 || t > ANTLR_ATN_SIMULATOR(self)->atn->max_token_type) {
        return to;
    }

    if ( from->edges==NULL ) {
        from->edges = g_ptr_array_sized_new(ANTLR_ATN_SIMULATOR(self)->atn->max_token_type+1+1);// AntlrDFAState
        int i;
        for (i=0; i<(ANTLR_ATN_SIMULATOR(self)->atn->max_token_type+1+1); i++) {
            AntlrDFAState *ptr = NULL;
            g_ptr_array_insert(from->edges, i, ptr);
        }
    }

    //g_ptr_array_insert(from->edges, t+1, to); // connect
    g_ptr_array_index(from->edges, t+1) = to; // connect

    if ( antlr_parser_atn_simulator_debug ) {
        AntlrVocabulary *vocabulary = self->parser!=NULL ? (AntlrVocabulary *)antlr_recognizer_get_vocabulary(ANTLR_RECOGNIZER(self->parser)) : ANTLR_VOCABULARY_EMPTY_VOCABULARY;
        gchar *str_dfa = antlr_dfa_to_string_from_vocabulary(dfa, vocabulary);
        g_print("DFA=\n%s\n", str_dfa);
        g_free(str_dfa);
    }
    return to;
}


/**
 * antlr_parser_atn_simulator_add_dfa_state:
 * @self: Some #AntlrParserATNSimulator
 * @dfa: The dfa
 * @D: The DFA state to add
 *
 * Add state {@code D} to the DFA if it is not already present, and return
 * the actual instance stored in the DFA. If a state equivalent to {@code D}
 * is already in the DFA, the existing state is returned. Otherwise this
 * method returns {@code D} after adding it to the DFA.
 *
 * <p>If {@code D} is {@link #ERROR}, this method returns {@link #ERROR} and
 * does not change the DFA.</p>
 *
 * Returns: The state stored in the DFA. This will be either the existing
 * state if {@code D} is already in the DFA, or {@code D} itself if the
 * state was not already present.
 */
static AntlrDFAState*
antlr_parser_atn_simulator_add_dfa_state(AntlrParserATNSimulator *self,
                                         AntlrDFA *dfa,
                                         AntlrDFAState *D)
{
    GError *error = NULL;

    if (D == ANTLR_ATN_SIMULATOR_ERROR) {
        return D;
    }

    AntlrDFAState *existing = g_hash_table_lookup(dfa->states, (gconstpointer)D);
    if( existing!=NULL ) {
        return existing;
    }
    D->state_number = g_hash_table_size(dfa->states);
    if (!antlr_atn_config_set_is_readonly(D->configs)) {
        antlr_atn_config_set_optimize_configs(D->configs, ANTLR_ATN_SIMULATOR(self), &error);
        antlr_atn_config_set_set_readonly(D->configs, TRUE);
    }

    g_object_ref(D);
    g_hash_table_insert(dfa->states, (gpointer)D, (gpointer)D);
    if ( antlr_parser_atn_simulator_debug ) {
        gchar *str_dfa = antlr_object_to_string(ANTLR_OBJECT(D));
        g_print("adding new DFA state: %s\n", str_dfa);
        g_free(str_dfa);
    }
    return D;
}

static void
antlr_parser_atn_simulator_report_attempting_full_context(AntlrParserATNSimulator *self,
                                                          AntlrDFA *dfa,
                                                          AntlrBitSet *conflictingAlts,
                                                          AntlrATNConfigSet *configs,
                                                          gint startIndex,
                                                          gint stopIndex)
{
    if ( antlr_parser_atn_simulator_debug || antlr_parser_atn_simulator_retry_debug ) {
        AntlrInterval *interval = antlr_interval_of(startIndex, stopIndex);
        gchar *str_config = antlr_atn_config_set_to_string(configs);
        AntlrTokenStream *stream = antlr_parser_get_token_stream(self->parser);
        gchar *str_text = antlr_token_stream_get_text_from_interval(stream, interval);
        g_print("reportAttemptingFullContext decision=%d:%s, input=%s\n", dfa->decision, str_config, str_text);
        g_free(str_config);
        g_free(str_text);
        g_object_unref(interval);
    }

    if ( self->parser!=NULL ) {
        AntlrErrorListener *listener = antlr_recognizer_get_error_listener_dispatch(ANTLR_RECOGNIZER(self->parser));
        antlr_error_listener_report_attempting_full_context(listener, self->parser, dfa, startIndex, stopIndex, conflictingAlts, configs);
    }
}

static void
antlr_parser_atn_simulator_report_context_sensitivity(AntlrParserATNSimulator *self,
                                                      AntlrDFA *dfa,
                                                      gint prediction,
                                                      AntlrATNConfigSet *configs,
                                                      gint startIndex,
                                                      gint stopIndex)
{
    if ( antlr_parser_atn_simulator_debug || antlr_parser_atn_simulator_retry_debug ) {
        AntlrInterval *interval = antlr_interval_of(startIndex, stopIndex);
        g_print("reportContextSensitivity decision=%s:%s, input=%s\n", "dfa.decision", "configs", "parser.getTokenStream().getText(interval)");
        g_object_unref(interval);
    }
    if ( self->parser!=NULL ) {
        AntlrErrorListener *listener = antlr_recognizer_get_error_listener_dispatch(ANTLR_RECOGNIZER(self->parser));
        antlr_error_listener_report_context_sensitivity(listener, self->parser, dfa, startIndex, stopIndex, prediction, configs);
    }
}


AntlrATNConfig*
antlr_parser_atn_simulator_precedence_transition(AntlrParserATNSimulator *self,
                                                 AntlrATNConfig *config,
                                                 AntlrPrecedencePredicateTransition *pt,
                                                 gboolean collectPredicates,
                                                 gboolean inContext,
                                                 gboolean fullCtx)
{
    if ( antlr_parser_atn_simulator_debug ) {
        g_print("PRED (collectPredicates=%s) %d>=_p, ctx dependent=true\n", collectPredicates?"true":"false", pt->precedence);

        if ( self->parser != NULL ) {
            GList *stack = antlr_parser_get_rule_invocation_stack(self->parser);
            gchar *str_stack = g_list_to_string(stack, (GStringFunc)g_string_to_cstr, NULL);
            g_print("context surrounding pred is %s\n", str_stack);
            g_free(str_stack);
            //g_list_free(stack); // TODO GString unref
        }
    }

    AntlrATNConfig *c = NULL;
    if (collectPredicates && inContext) {
        if ( fullCtx ) {
            // In full context mode, we can evaluate predicates on-the-fly
            // during closure, which dramatically reduces the size of
            // the config sets. It also obviates the need to test predicates
            // later during conflict resolution.
            gint currentPosition = antlr_int_stream_index(ANTLR_INT_STREAM(self->input));
            antlr_int_stream_seek(ANTLR_INT_STREAM(self->input), self->start_index);

            AntlrPredicate *predicate = antlr_predicate_transition_get_predicate(ANTLR_PREDICATE_TRANSITION(pt));
            gboolean predSucceeds = antlr_parser_atn_simulator_eval_semantic_context(self, ANTLR_SEMANTIC_CONTEXT(predicate), self->outer_context, config->alt, fullCtx);
            antlr_int_stream_seek(ANTLR_INT_STREAM(self->input), currentPosition);
            if (predSucceeds) {
                c = antlr_atn_config_new_with_config_state(config, ANTLR_TRANSITION(pt)->target);
            }
            ///g_object_unref(predicate);
        }
        else {
            AntlrPrecedencePredicate *predicate = antlr_precedence_predicate_transition_get_predicate(ANTLR_PRECEDENCE_PREDICATE_TRANSITION(pt));
            AntlrSemanticContext *newSemCtx = antlr_semantic_context_and(config->semantic_context, ANTLR_SEMANTIC_CONTEXT(predicate));
            c = antlr_atn_config_new_with_config_state_semantic(config, ANTLR_TRANSITION(pt)->target, newSemCtx);
            ///g_object_unref(predicate);
        }
    }
    else {
        c = antlr_atn_config_new_with_config_state(config, ANTLR_TRANSITION(pt)->target);
    }

    if ( antlr_parser_atn_simulator_debug ) {
        gchar *str_config = antlr_object_to_string(ANTLR_OBJECT(c));
        g_print("config from pred transition=%s\n", str_config);
        g_free(str_config);
    }
    return c;
}

static AntlrATNConfig*
antlr_parser_atn_simulator_action_transition(AntlrParserATNSimulator *self,
                                             AntlrATNConfig *config,
                                             AntlrActionTransition *t) {
    if ( antlr_parser_atn_simulator_debug )
        g_print("ACTION edge %d:%d\n", t->rule_index, t->action_index);
    return antlr_atn_config_new_with_config_state(config, ANTLR_TRANSITION(t)->target);
}

static AntlrATNConfig*
antlr_parser_atn_simulator_pred_transition(AntlrParserATNSimulator *self,
                                           AntlrATNConfig *config,
                                           AntlrPredicateTransition *pt,
                                           gboolean collectPredicates,
                                           gboolean inContext,
                                           gboolean fullCtx)
{

    if ( antlr_parser_atn_simulator_debug ) {
        g_print("PRED (collectPredicates=%s) %d:%d, ctx dependent=%s\n", collectPredicates?"true":"false", pt->rule_index, pt->pred_index, pt->is_ctx_dependent?"true":"false");

        if ( self->parser != NULL ) {
            GList *stack = antlr_parser_get_rule_invocation_stack(self->parser);
            gchar *str_stack = g_list_to_string(stack, (GStringFunc)g_string_to_cstr, NULL);
            g_print("context surrounding pred is %s\n", str_stack);
            g_free(str_stack);
            //g_list_free(stack);
        }
    }
    AntlrATNConfig *c = NULL;

    if (collectPredicates && ( !pt->is_ctx_dependent || (pt->is_ctx_dependent && inContext) ) ) {
        if ( fullCtx ) {
            // In full context mode, we can evaluate predicates on-the-fly
            // during closure, which dramatically reduces the size of
            // the config sets. It also obviates the need to test predicates
            // later during conflict resolution.
            gint currentPosition = antlr_int_stream_index(ANTLR_INT_STREAM(self->input));
            antlr_int_stream_seek(ANTLR_INT_STREAM(self->input), self->start_index);
            AntlrPredicate *predicate = antlr_predicate_transition_get_predicate(pt);
            gboolean predSucceeds = antlr_parser_atn_simulator_eval_semantic_context(self, ANTLR_SEMANTIC_CONTEXT(predicate), self->outer_context, config->alt, fullCtx);
            antlr_int_stream_seek(ANTLR_INT_STREAM(self->input), currentPosition);
            if ( predSucceeds ) {
                c = antlr_atn_config_new_with_config_state(config, ANTLR_TRANSITION(pt)->target); // no pred context
            }
            ///g_object_unref(predicate);
        } else {
            AntlrPredicate *predicate = antlr_predicate_transition_get_predicate(pt);
            AntlrSemanticContext *newSemCtx = antlr_semantic_context_and(config->semantic_context, ANTLR_SEMANTIC_CONTEXT(predicate));
            c = antlr_atn_config_new_with_config_state_semantic(config, ANTLR_TRANSITION(pt)->target, newSemCtx);
            ///g_object_unref(predicate);
        }
    } else {
        c = antlr_atn_config_new_with_config_state(config, ANTLR_TRANSITION(pt)->target);
    }


    if ( antlr_parser_atn_simulator_debug ) {
        gchar *str_config = antlr_object_to_string(ANTLR_OBJECT(c));
        g_print("config from pred transition=%s\n", str_config);
        g_free(str_config);
    }

    return c;
}



static AntlrATNConfig*
antlr_parser_atn_simulator_rule_transition(AntlrParserATNSimulator *self, AntlrATNConfig *config, AntlrRuleTransition *t) {
    if ( antlr_parser_atn_simulator_debug ) {
        gchar *rule_name = antlr_parser_atn_simulator_get_rule_name(self, ANTLR_TRANSITION(t)->target->rule_index);
        gchar *str_prediction = antlr_object_to_string(ANTLR_OBJECT(config->context));
        g_print("CALL rule %s, ctx=%s\n", rule_name, str_prediction);
        g_free(rule_name);
        g_free(str_prediction);
    }

    AntlrATNState *returnState = t->follow_state;
    AntlrPredictionContext *newContext = ANTLR_PREDICTION_CONTEXT(
        antlr_singleton_prediction_context_create(config->context, returnState->state_number));
    return antlr_atn_config_new_with_config(config, ANTLR_TRANSITION(t)->target, newContext);
}

static AntlrATNConfig* antlr_parser_atn_simulator_get_epsilon_target(AntlrParserATNSimulator *self,
                                                                     AntlrATNConfig *config,
                                                                     AntlrTransition *t,
                                                                     gboolean collectPredicates,
                                                                     gboolean inContext,
                                                                     gboolean fullCtx,
                                                                     gboolean treatEofAsEpsilon)
{
    gint st = antlr_transition_get_serialization_type(t);
    switch (st) {
        case ANTLR_TRANSITION_RULE:
            return antlr_parser_atn_simulator_rule_transition(self, config, ANTLR_RULE_TRANSITION(t));
        case ANTLR_TRANSITION_PRECEDENCE:
            return antlr_parser_atn_simulator_precedence_transition(self, config, ANTLR_PRECEDENCE_PREDICATE_TRANSITION(t), collectPredicates, inContext, fullCtx);
        case ANTLR_TRANSITION_PREDICATE:
            return antlr_parser_atn_simulator_pred_transition(self, config, ANTLR_PREDICATE_TRANSITION(t),
                                  collectPredicates,
                                  inContext,
                                  fullCtx);
        case ANTLR_TRANSITION_ACTION:
            return antlr_parser_atn_simulator_action_transition(self, config, ANTLR_ACTION_TRANSITION(t));
        case ANTLR_TRANSITION_EPSILON:
            return antlr_atn_config_new_with_config_state(config, ANTLR_TRANSITION(t)->target);
        case ANTLR_TRANSITION_ATOM:
        case ANTLR_TRANSITION_RANGE:
        case ANTLR_TRANSITION_SET:
            // EOF transitions act like epsilon transitions after the first EOF
            // transition is traversed
            if (treatEofAsEpsilon) {
                if ( antlr_transition_matches(ANTLR_TRANSITION(t), ANTLR_TOKEN_EOF, 0, 1) ) {
                    return antlr_atn_config_new_with_config_state(config, ANTLR_TRANSITION(t)->target);
                }
            }
            return NULL;
        default:
            return NULL;
    }
}

/**
 * antlr_parser_atn_simulator_get_conflicting_alts:
 * @self: Some #AntlrParserATNSimulator
 * @configs: The #AntlrATNConfigSet to analyze.
 *
 * antlr_parser_atn_simulator_get_conflicting_alts:
 * Gets a {@link BitSet} containing the alternatives in {@code configs}
 * which are part of one or more conflicting alternative subsets.
 *
 * Returns: The alternatives in @configs which are part of one or more
 * conflicting alternative subsets. If @configs does not contain any
 * conflicting subsets, this method returns an empty #AntlrBitSet.
 */
static AntlrBitSet*
antlr_parser_atn_simulator_get_conflicting_alts(AntlrParserATNSimulator *self, AntlrATNConfigSet *configs)
{
    GList *altsets = antlr_prediction_mode_get_conflicting_alt_subsets(configs);// GList of AntlrBitSet
    AntlrBitSet *bit_set = antlr_prediction_mode_get_alts_from_bit_set(altsets);
    g_list_free_full(altsets, (GDestroyNotify)g_object_unref);
    return bit_set;
}

/**
 * antlr_parser_atn_simulator_get_conflicting_alts_or_unique_alt:
 * @self: Some #AntlrParserATNSimulator
 * @configs: The configs
 *
 * Sam pointed out a problem with the previous definition, v3, of
 * ambiguous states. If we have another state associated with conflicting
 * alternatives, we should keep going. For example, the following grammar
 *
 * s : (ID | ID ID?) ';' ;
 *
 * When the ATN simulation reaches the state before ';', it has a DFA
 * state that looks like: [12|1|[], 6|2|[], 12|2|[]]. Naturally
 * 12|1|[] and 12|2|[] conflict, but we cannot stop processing this node
 * because alternative to has another way to continue, via [6|2|[]].
 * The key is that we have a single state that has config's only associated
 * with a single alternative, 2, and crucially the state transitions
 * among the configurations are all non-epsilon transitions. That means
 * we don't consider any conflicts that include alternative 2. So, we
 * ignore the conflict between alts 1 and 2. We ignore a set of
 * conflicting alts when there is an intersection with an alternative
 * associated with a single alt state in the state&rarr;config-list map.
 *
 * It's also the case that we might have two conflicting configurations but
 * also a 3rd nonconflicting configuration for a different alternative:
 * [1|1|[], 1|2|[], 8|3|[]]. This can come about from grammar:
 *
 * a : A | A | A B ;
 *
 * After matching input A, we reach the stop state for rule A, state 1.
 * State 8 is the state right before B. Clearly alternatives 1 and 2
 * conflict and no amount of further lookahead will separate the two.
 * However, alternative 3 will be able to continue and so we do not
 * stop working on this state. In the previous example, we're concerned
 * with states associated with the conflicting alternatives. Here alt
 * 3 is not associated with the conflicting configs, but since we can continue
 * looking for input reasonably, I don't declare the state done. We
 * ignore a set of conflicting alts when we have an alternative
 * that we still need to pursue.
 *
 */
static AntlrBitSet*
antlr_parser_atn_simulator_get_conflicting_alts_or_unique_alt(AntlrParserATNSimulator *self, AntlrATNConfigSet *configs) {
    AntlrBitSet *conflictingAlts;
    if ( configs->unique_alt!= ANTLR_ATN_INVALID_ALT_NUMBER ) {
        conflictingAlts = antlr_bit_set_new();
        antlr_bit_set_set(conflictingAlts, configs->unique_alt, TRUE);
    }
    else {
        conflictingAlts = configs->conflicting_alts;
    }
    return conflictingAlts;
}

gchar*
antlr_parser_atn_simulator_get_rule_name(AntlrParserATNSimulator *self, gint index)
{
    if ( self->parser!=NULL && index>=0 ) {
        GArray *rule_names = antlr_recognizer_get_rule_names(ANTLR_RECOGNIZER(self->parser));
        GString *rule_name = g_array_index(rule_names, GString*, index);
        return g_strdup(rule_name->str);
    }

    return g_strdup_printf("<rule %d>", index);
}

gchar* antlr_parser_atn_simulator_get_token_name(AntlrParserATNSimulator *self, gint t) {
    if (t == ANTLR_TOKEN_EOF) {
        return g_strdup("EOF");
    }

    AntlrIVocabulary *vocabulary = self->parser != NULL ? antlr_recognizer_get_vocabulary(ANTLR_RECOGNIZER(self->parser)) : ANTLR_IVOCABULARY(ANTLR_VOCABULARY_EMPTY_VOCABULARY);

    gchar* display_name = antlr_ivocabulary_get_display_name(vocabulary, t);// TODO check memory leaks
    gchar* str_integer = g_strdup_printf("%d", t);

    if (g_strcmp0(display_name, str_integer)==0) {
        g_free(str_integer);
        return display_name;
    }

    gchar* str_name = g_strdup_printf("%s<%d>", display_name, t);

    g_free(str_integer);
    g_free(display_name);

    return str_name;
}

gchar* antlr_parser_atn_simulator_get_lookahead_name(AntlrParserATNSimulator *self, AntlrTokenStream *input) {
    gint t = antlr_int_stream_LA(ANTLR_INT_STREAM(input), 1);
    return antlr_parser_atn_simulator_get_token_name(self, t);
}

static gint
antlr_parser_atn_simulator_get_unique_alt(AntlrParserATNSimulator *self, AntlrATNConfigSet *configs) {
    gint alt = ANTLR_ATN_INVALID_ALT_NUMBER;
    GList *it;
    for (it = g_list_first(configs->configs); it; it=it->next) {
        AntlrATNConfig *c = it->data;
        if ( alt == ANTLR_ATN_INVALID_ALT_NUMBER ) {
            alt = c->alt; // found first alt
        } else if ( c->alt!=alt ) {
            return ANTLR_ATN_INVALID_ALT_NUMBER;
        }
    }
    return alt;
}

gint antlr_parser_atn_simulator_adaptive_predict(AntlrParserATNSimulator *self, AntlrTokenStream *input, gint decision, AntlrParserRuleContext *outer_context)
{
    GError *error = NULL;
    if ( antlr_parser_atn_simulator_debug || antlr_parser_atn_simulator_debug_list_atn_decisions )  {
        gchar *lookahead_name = antlr_parser_atn_simulator_get_lookahead_name(self, input);
        AntlrToken *token = antlr_token_stream_LT(ANTLR_TOKEN_STREAM(input), 1);
        gint line = antlr_token_get_line(ANTLR_TOKEN(token));
        gint position = antlr_token_get_char_position_in_line(ANTLR_TOKEN(token));
        g_print("adaptivePredict decision %d exec LA(1)==%s line %d:%d\n", decision, lookahead_name, line, position);
        g_free(lookahead_name);
    }

    self->input = input;
    self->start_index = antlr_int_stream_index(ANTLR_INT_STREAM(input));
    self->outer_context = outer_context;
    AntlrDFA *dfa = g_array_index(self->decision_to_dfa, AntlrDFA*, decision);
    self->dfa = dfa;

    gint m = antlr_int_stream_mark(ANTLR_INT_STREAM(input));
    gint index = self->start_index;

    // Now we are certain to have a specific decision's DFA
    // But, do we still need an initial state?
    //try {
        AntlrDFAState *s0;

        if (antlr_dfa_is_precedence_dfa(dfa)) {
            // the start state for a precedence DFA depends on the current
            // parser precedence, and is provided by a DFA method.
            s0 = antlr_dfa_get_precedence_start_state(dfa,
                                                      antlr_parser_get_precedence(self->parser), NULL);
        }
        else {
            // the start state for a "regular" DFA is just s0
            s0 = dfa->s0;
        }
        if (s0 == NULL) {
            if ( self->outer_context ==NULL ) self->outer_context = antlr_rule_context_get_empty();
            if ( antlr_parser_atn_simulator_debug || antlr_parser_atn_simulator_debug_list_atn_decisions )  {
                gchar *lookahead_name = antlr_parser_atn_simulator_get_lookahead_name(self, input);
                gchar *str_outer = antlr_rule_context_to_string_from_recognizer(ANTLR_RULE_CONTEXT(outer_context), ANTLR_RECOGNIZER(self->parser));
                g_print("predictATN decision %d exec LA(1)==%s, outerContext=%s\n", dfa->decision, lookahead_name, str_outer);
                g_free(str_outer);
                g_free(lookahead_name);
            }

            gboolean fullCtx = FALSE;
            AntlrATNConfigSet *s0_closure = antlr_parser_atn_simulator_compute_start_state(self,
                                                                                           ANTLR_ATN_STATE(dfa->atn_start_state),
                                                                                           ANTLR_RULE_CONTEXT_EMPTY,
                                                                                           fullCtx);

            if (antlr_dfa_is_precedence_dfa(dfa)) {
                /* If this is a precedence DFA, we use applyPrecedenceFilter
                 * to convert the computed start state to a precedence start
                 * state. We then use DFA.setPrecedenceStartState to set the
                 * appropriate start state for the precedence level rather
                 * than simply setting DFA.s0.
                 */
                dfa->s0->configs = s0_closure; // not used for prediction but useful to know start configs anyway
                s0_closure = antlr_parser_atn_simulator_apply_precedence_filter(self, s0_closure);
                AntlrDFAState *dfa_state = antlr_dfa_state_new_with_config_set(s0_closure);
                s0 = antlr_parser_atn_simulator_add_dfa_state(self, dfa, dfa_state);
                antlr_dfa_set_precedence_start_state(dfa, antlr_parser_get_precedence(self->parser), s0, &error);
            }
            else {
                AntlrDFAState *dfa_state = antlr_dfa_state_new_with_config_set(s0_closure);
                s0 = antlr_parser_atn_simulator_add_dfa_state(self, dfa, dfa_state);
                dfa->s0 = s0;
            }
        }

        gint alt = antlr_parser_atn_simulator_exec_atn(self, dfa, s0, input, index, outer_context);
        if ( antlr_parser_atn_simulator_debug ) {
            AntlrVocabulary *vocabulary = self->parser!=NULL ? (AntlrVocabulary *)antlr_recognizer_get_vocabulary(ANTLR_RECOGNIZER(self->parser)) : ANTLR_VOCABULARY_EMPTY_VOCABULARY;
            gchar *str_dfa = antlr_dfa_to_string_from_vocabulary(dfa, vocabulary);
            g_print("DFA after predictATN: %s\n", str_dfa);
            g_free(str_dfa);
        }

    //}

    // finally {
    ///antlr_double_key_map_free(self->merge_cache);
    self->merge_cache = NULL; // wack cache after each prediction
    //g_clear_object(&self->dfa); TODO: clear so ????
    self->dfa = NULL;
    antlr_int_stream_seek(ANTLR_INT_STREAM(input), index);
    antlr_int_stream_release(ANTLR_INT_STREAM(input), m);
    //}


    //antlr_object_dump_atn_config();
    ///antlr_object_garbage_collector_atn_config();

    return alt;
}


/**
 * antlr_parser_atn_simulator_exec_atn:
 * @self: Some #AntlrParserATNSimulator
 * @dfa: The dfa
 * @s0: The state
 * @input: The input
 * @startIndex: The index
 * @outerContext: The context
 *
 *
 * Performs ATN simulation to compute a predicted alternative based
 *  upon the remaining input, but also updates the DFA cache to avoid
 *  having to traverse the ATN again for the same input sequence.
 *
 * There are some key conditions we're looking for after computing a new
 * set of ATN configs (proposed DFA state):
 *       - if the set is empty, there is no viable alternative for current symbol
 *       - does the state uniquely predict an alternative?
 *       - does the state have a conflict that would prevent us from
 *         putting it on the work list?
 *
 * We also have some key operations to do:
 *       - add an edge from previous DFA state to potentially new DFA state, D,
 *         upon current symbol but only if adding to work list, which means in all
 *         cases except no viable alternative (and possibly non-greedy decisions?)
 *       - collecting predicates and adding semantic context to DFA accept states
 *       - adding rule context to context-sensitive DFA accept states
 *       - consuming an input symbol
 *       - reporting a conflict
 *       - reporting an ambiguity
 *       - reporting a context sensitivity
 *       - reporting insufficient predicates
 *
 * cover these cases:
 *    dead end
 *    single alt
 *    single alt + preds
 *    conflict
 *    conflict + preds
 *
 */
static gint
antlr_parser_atn_simulator_exec_atn(AntlrParserATNSimulator *self, AntlrDFA *dfa, AntlrDFAState *s0, AntlrTokenStream *input, gint start_index, AntlrParserRuleContext *outer_context)
{

    if ( antlr_parser_atn_simulator_debug || antlr_parser_atn_simulator_debug_list_atn_decisions) {
        gchar *lookahead_name = antlr_parser_atn_simulator_get_lookahead_name(self, input);
        AntlrToken *token_lt = antlr_token_stream_LT(input, 1);
        gint line = antlr_token_get_line(token_lt);
        gint char_position_in_line = antlr_token_get_char_position_in_line(token_lt);
        g_print("execATN decision %d exec LA(1)==%s line %d:%d\n", dfa->decision, lookahead_name, line, char_position_in_line);
        g_free(lookahead_name);
    }

    AntlrDFAState *previousD = s0;
    ///g_object_ref(previousD);

    if ( antlr_parser_atn_simulator_debug ) {
        gchar *str_dfa = antlr_object_to_string(ANTLR_OBJECT(s0));
        g_print("s0 = %s\n", str_dfa);
        g_free(str_dfa);
    }


    int t = antlr_int_stream_LA(ANTLR_INT_STREAM(input), 1);

    while (TRUE) { // while more work
        AntlrDFAState *D = antlr_parser_atn_simulator_get_existing_target_state(self, previousD, t);
        if (D == NULL) {
            D = antlr_parser_atn_simulator_compute_target_state(self, dfa, previousD, t);
        }

        if (D == ANTLR_ATN_SIMULATOR_ERROR) {
            // if any configs in previous dipped into outer context, that
            // means that input up to t actually finished entry rule
            // at least for SLL decision. Full LL doesn't dip into outer
            // so don't need special case.
            // We will get an error no matter what so delay until after
            // decision; better error message. Also, no reachable target
            // ATN states in SLL implies LL will also get nowhere.
            // If conflict in states that dip out, choose min since we
            // will get error no matter what.

            //NoViableAltException e = noViableAlt(input, outerContext, previousD.configs, startIndex);
            //g_error_new(g_quark_from_string("ANTLR"), 120, "%s", "NoViableAltException");
            antlr_int_stream_seek(ANTLR_INT_STREAM(input), start_index);
            gint alt = antlr_parser_atn_simulator_get_syn_valid_or_sem_invalid_alt_that_finished_decision_entry_rule(self, previousD->configs, outer_context);
            if ( alt!=ANTLR_ATN_INVALID_ALT_NUMBER ) {
                ///g_object_unref(previousD);///---------
                ///g_object_unref(D);///---------
                return alt;
            }
            //throw e;
            ///g_object_unref(previousD);///---------
            ///g_object_unref(D);///---------
            return -1;
        }

        if ( D->requires_full_context && self->mode != ANTLR_PREDICTION_MODE_SLL ) {
            // IF PREDS, MIGHT RESOLVE TO SINGLE ALT => SLL (or syntax error)
            AntlrBitSet *conflictingAlts = D->configs->conflicting_alts;
            if ( D->predicates!=NULL ) {
                if ( antlr_parser_atn_simulator_debug )
                    g_print("DFA state has preds in DFA sim LL failover\n");
                gint conflictIndex = antlr_int_stream_index(ANTLR_INT_STREAM(input));
                if (conflictIndex != start_index) {
                    antlr_int_stream_seek(ANTLR_INT_STREAM(input), start_index);
                }
                conflictingAlts = antlr_parser_atn_simulator_eval_semantic_context_from_predictions(self, D->predicates, outer_context, TRUE);
                if ( antlr_bit_set_cardinality(conflictingAlts)==1 ) {
                    if ( antlr_parser_atn_simulator_debug )
                        g_print("Full LL avoided\n");
                    ///g_object_unref(D);///---------
                    ///g_object_unref(previousD);///---------
                    return antlr_bit_set_next_set_bit(conflictingAlts, 0);
                }

                if (conflictIndex != start_index) {
                    // restore the index so reporting the fallback to full
                    // context occurs with the index at the correct spot
                    antlr_int_stream_seek(ANTLR_INT_STREAM(input), conflictIndex);
                }
            }

            if ( antlr_parser_atn_simulator_dfa_debug ) {
                gchar *str_outerContext = antlr_rule_context_to_string(outer_context);
                gchar *str_D = antlr_object_to_string(ANTLR_OBJECT(D));
                g_print("ctx sensitive state %s in %s\n", str_outerContext, str_D);
                g_free(str_outerContext);
                g_free(str_D);
            }
            gboolean fullCtx = TRUE;
            AntlrATNConfigSet *s0_closure = antlr_parser_atn_simulator_compute_start_state(self, ANTLR_ATN_STATE(dfa->atn_start_state), ANTLR_RULE_CONTEXT(outer_context), fullCtx);
            antlr_parser_atn_simulator_report_attempting_full_context(self, dfa, conflictingAlts, D->configs, start_index, antlr_int_stream_index(ANTLR_INT_STREAM(input)));

            int alt = antlr_parser_atn_simulator_exec_atn_with_full_context(self, dfa, D, s0_closure, input, start_index, outer_context);
            ///g_object_unref(previousD);///---------
            ///g_object_unref(D);///---------
            return alt;
        }

        if ( D->is_accept_state ) {
            if (D->predicates == NULL) {
                gint prediction = D->prediction;
                ///g_object_unref(previousD);///---------
                ///g_object_unref(D);///---------
                return prediction;
            }

            gint stop_index = antlr_int_stream_index(ANTLR_INT_STREAM(input));
            antlr_int_stream_seek(ANTLR_INT_STREAM(input), start_index);
            AntlrBitSet *alts = antlr_parser_atn_simulator_eval_semantic_context_from_predictions(self, D->predicates, outer_context, TRUE);
            switch (antlr_bit_set_cardinality(alts)) {
            case 0:
                //throw noViableAlt(input, outerContext, D.configs, startIndex);
                g_warning("%s", "not implmeented");

            case 1:
                ///g_object_unref(previousD);///---------
                ///g_object_unref(D);///---------
                return antlr_bit_set_next_set_bit(alts, 0);

            default:
                // report ambiguity after predicate evaluation to make sure the correct
                // set of ambig alts is reported.
                antlr_parser_atn_simulator_report_ambiguity(self, dfa, D, start_index, stop_index, FALSE, alts, D->configs);
                ///g_object_unref(previousD);///---------
                ///g_object_unref(D);///---------
                return antlr_bit_set_next_set_bit(alts, 0);
            }
        }

        ///g_object_unref(previousD);///---------
        previousD = D;

        if (t != ANTLR_INT_STREAM_EOF) {
            antlr_int_stream_consume(ANTLR_INT_STREAM(input));
            t = antlr_int_stream_LA(ANTLR_INT_STREAM(input), 1);
        }

    }
}

/**
 * antlr_parser_atn_simulator_get_existing_target_state:
 * @self: Some #AntlrParserATNSimulator
 * @previousD: The current DFA state
 * @t: The next input symbol
 *
 * Get an existing target state for an edge in the DFA. If the target state
 * for the edge has not yet been computed or is otherwise not available,
 * this method returns %NULL.
 *
 * Returns: The existing target DFA state for the given input symbol
 * @t, or %NULL if the target state for this edge is not
 * already cached
 */
static AntlrDFAState*
antlr_parser_atn_simulator_get_existing_target_state(AntlrParserATNSimulator *self, AntlrDFAState *previousD, gint t)
{
    GPtrArray_AntlrDFAState *edges = previousD->edges;// of AntlrDFAState*
    if (edges == NULL || t + 1 < 0 || t + 1 >= edges->len) {
        return NULL;
    }

    return g_ptr_array_index(edges, t+1);
}

/**
 * antlr_parser_atn_simulator_compute_target_state:
 * @self: Some #AntlrParserATNSimulator
 * @dfa: The DFA
 * @previousD: The current DFA state
 * @t: The next input symbol
 *
 * Compute a target state for an edge in the DFA, and attempt to add the
 * computed state and corresponding edge to the DFA.
 *
 *
 * Returns: The computed target DFA state for the given input symbol
 * {@code t}. If {@code t} does not lead to a valid DFA state, this method
 * returns {@link #ERROR}.
 */
static AntlrDFAState*
antlr_parser_atn_simulator_compute_target_state(AntlrParserATNSimulator *self, AntlrDFA *dfa, AntlrDFAState *previous_dfa, gint t)
{
    AntlrATNConfigSet *reach = antlr_parser_atn_simulator_compute_reach_set(self, previous_dfa->configs, t, FALSE);
    if ( reach==NULL ) {
        antlr_parser_atn_simulator_add_dfa_edge(self, dfa, previous_dfa, t, ANTLR_ATN_SIMULATOR_ERROR);
        return ANTLR_ATN_SIMULATOR_ERROR;
    }

    // create new target state; we'll add to DFA after it's complete
    AntlrDFAState *D = antlr_dfa_state_new_with_config_set(reach);

    gint predictedAlt = antlr_parser_atn_simulator_get_unique_alt(self, reach);

    if ( FALSE && antlr_parser_atn_simulator_debug ) {
        GList *altSubSets = antlr_prediction_mode_get_conflicting_alt_subsets(reach);
        gboolean conflict = antlr_prediction_mode_all_subsets_conflict(altSubSets);
        gchar *str_altSubSets = g_list_to_string(altSubSets, (GStringFunc)antlr_bit_set_to_string, NULL);
        gchar *str_reach = antlr_atn_config_set_to_string(reach);
        AntlrBitSet *bit_set = antlr_parser_atn_simulator_get_conflicting_alts(self, reach);
        gchar *str_bit_set = antlr_bit_set_to_string(bit_set);
        g_print("SLL altSubSets=%s, configs=%s, predict=%d, allSubsetsConflict=%s, conflictingAlts=%s\n", str_altSubSets, str_reach, predictedAlt, conflict?"true":"false", str_bit_set);
        g_free(str_altSubSets);
        g_free(str_reach);
        g_free(str_bit_set);
    }


    if ( predictedAlt!=ANTLR_ATN_INVALID_ALT_NUMBER ) {
        // NO CONFLICT, UNIQUELY PREDICTED ALT
        D->is_accept_state = TRUE;
        D->configs->unique_alt = predictedAlt;
        D->prediction = predictedAlt;
    } else if ( antlr_prediction_mode_has_sll_conflict_terminating_prediction(self->mode, reach) ) {
        // MORE THAN ONE VIABLE ALTERNATIVE
        D->configs->conflicting_alts = antlr_parser_atn_simulator_get_conflicting_alts(self, reach);
        D->requires_full_context = TRUE;
        // in SLL-only mode, we will stop at this state and return the minimum alt
        D->is_accept_state = TRUE;
        D->prediction = antlr_bit_set_next_set_bit(D->configs->conflicting_alts, 0);
    }

    if ( D->is_accept_state && D->configs->has_semantic_context ) {

        antlr_parser_atn_simulator_predicate_dfa_state(self, D, antlr_atn_get_decision_state(ANTLR_ATN_SIMULATOR(self)->atn, self->dfa->decision));
        if (D->predicates != NULL) {
            D->prediction = ANTLR_ATN_INVALID_ALT_NUMBER;
        }
    }

    // all adds to dfa are done after we've created full D state
    D = antlr_parser_atn_simulator_add_dfa_edge(self, dfa, previous_dfa, t, D);

    //g_object_unref(G_OBJECT(reach));

    return D;
}

static void
antlr_parser_atn_simulator_predicate_dfa_state(AntlrParserATNSimulator *self, AntlrDFAState *dfaState, AntlrDecisionState *decisionState) {
    // We need to test all predicates, even in DFA states that
    // uniquely predict alternative.
    gint nalts = antlr_atn_state_get_number_of_transitions(ANTLR_ATN_STATE(decisionState));
    // Update DFA so reach becomes accept state with (predicate,alt)
    // pairs if preds found for conflicting alts
    AntlrBitSet* altsToCollectPredsFrom = antlr_parser_atn_simulator_get_conflicting_alts_or_unique_alt(self, dfaState->configs);
    GArray */*of AntlrSemanticContext*/ altToPred = antlr_parser_atn_simulator_get_preds_for_ambig_alts(self, altsToCollectPredsFrom, dfaState->configs, nalts);
    if ( altToPred!=NULL ) {

        dfaState->predicates = antlr_parser_atn_simulator_get_predicate_predictions(self, altsToCollectPredsFrom, altToPred);
        dfaState->prediction = ANTLR_ATN_INVALID_ALT_NUMBER; // make sure we use preds
    } else {
        // There are preds in configs but they might go away
        // when OR'd together like {p}? || NONE == NONE. If neither
        // alt has preds, resolve to min alt
        dfaState->prediction = antlr_bit_set_next_set_bit(altsToCollectPredsFrom, 0);
    }
}

// comes back with reach.uniqueAlt set to a valid alt
static gint
antlr_parser_atn_simulator_exec_atn_with_full_context(AntlrParserATNSimulator *self,
                                                      AntlrDFA *dfa,
                                                      AntlrDFAState *D, // how far we got in SLL DFA before failing over
                                                      AntlrATNConfigSet *s0,
                                                      AntlrTokenStream *input, gint startIndex,
                                                      AntlrParserRuleContext *outerContext)
{
    if ( antlr_parser_atn_simulator_debug || antlr_parser_atn_simulator_debug_list_atn_decisions ) {
        gchar *s0_str = antlr_atn_config_set_to_string(s0);
        g_print("execATNWithFullContext %s\n", s0_str);
        g_free(s0_str);
    }
    gboolean fullCtx = TRUE;
    gboolean foundExactAmbig = FALSE;
    AntlrATNConfigSet *reach = NULL;
    AntlrATNConfigSet *previous = s0;
    antlr_int_stream_seek(ANTLR_INT_STREAM(input), startIndex);
    gint t = antlr_int_stream_LA(ANTLR_INT_STREAM(input), 1);
    gint predictedAlt;
    while (TRUE) { // while more work
        //			System.out.println("LL REACH "+getLookaheadName(input)+
        //							   " from configs.size="+previous.size()+
        //							   " line "+input.LT(1).getLine()+":"+input.LT(1).getCharPositionInLine());
        reach = antlr_parser_atn_simulator_compute_reach_set(self, previous, t, fullCtx);
        if ( reach==NULL ) {
            // if any configs in previous dipped into outer context, that
            // means that input up to t actually finished entry rule
            // at least for LL decision. Full LL doesn't dip into outer
            // so don't need special case.
            // We will get an error no matter what so delay until after
            // decision; better error message. Also, no reachable target
            // ATN states in SLL implies LL will also get nowhere.
            // If conflict in states that dip out, choose min since we
            // will get error no matter what.
            ///NoViableAltException e = noViableAlt(input, outerContext, previous, startIndex);
            antlr_int_stream_seek(ANTLR_INT_STREAM(input), startIndex);
            gint alt = antlr_parser_atn_simulator_get_syn_valid_or_sem_invalid_alt_that_finished_decision_entry_rule(self, previous, outerContext);
            if ( alt!=ANTLR_ATN_INVALID_ALT_NUMBER ) {
                return alt;
            }
            ///throw e;
            return -1;
        }

        GList* /*AntlrBitSet*/ altSubSets = antlr_prediction_mode_get_conflicting_alt_subsets(reach);
        if ( antlr_parser_atn_simulator_debug ) {
            gchar *str_altSubSets = g_list_to_string(altSubSets, (GStringFunc)antlr_bit_set_to_string, NULL);
            gint unique_alt = antlr_prediction_mode_get_unique_alt(altSubSets);
            gint one_viable_alt = antlr_prediction_mode_resolves_to_just_one_viable_alt(altSubSets);
            g_print("LL altSubSets=%s, predict=%d, resolvesToJustOneViableAlt=%d\n", str_altSubSets, unique_alt, one_viable_alt);
            g_free(str_altSubSets);
        }
//			System.out.println("altSubSets: "+altSubSets);
//			System.err.println("reach="+reach+", "+reach.conflictingAlts);

        reach->unique_alt = antlr_parser_atn_simulator_get_unique_alt(self, reach);
        // unique prediction?
        if ( reach->unique_alt!=ANTLR_ATN_INVALID_ALT_NUMBER ) {
            predictedAlt = reach->unique_alt;
            break;
        }
        if ( self->mode != ANTLR_PREDICTION_MODE_LL_EXACT_AMBIG_DETECTION ) {
            predictedAlt = antlr_prediction_mode_resolves_to_just_one_viable_alt(altSubSets);
            if ( predictedAlt != ANTLR_ATN_INVALID_ALT_NUMBER ) {
                break;
            }
        } else {
            // In exact ambiguity mode, we never try to terminate early.
            // Just keeps scarfing until we know what the conflict is
            if ( antlr_prediction_mode_all_subsets_conflict(altSubSets)
              && antlr_prediction_mode_all_subsets_equal(altSubSets) )
            {
                foundExactAmbig = TRUE;
                predictedAlt = antlr_prediction_mode_get_single_viable_alt(altSubSets);
                break;
            }
            // else there are multiple non-conflicting subsets or
            // we're not sure what the ambiguity is yet.
            // So, keep going.
        }

        previous = reach;
        if (t != ANTLR_INT_STREAM_EOF) {
            antlr_int_stream_consume(ANTLR_INT_STREAM(input));
            t = antlr_int_stream_LA(ANTLR_INT_STREAM(input), 1);
        }

        // g_list_free(altSubSets);// TODO
    }

    // If the configuration set uniquely predicts an alternative,
    // without conflict, then we know that it's a full LL decision
    // not SLL.

    if ( reach->unique_alt != ANTLR_ATN_INVALID_ALT_NUMBER ) {
        antlr_parser_atn_simulator_report_context_sensitivity(self, dfa, predictedAlt, reach, startIndex, antlr_int_stream_index(ANTLR_INT_STREAM(input)));
        return predictedAlt;
    }

    // We do not check predicates here because we have checked them
    // on-the-fly when doing full context prediction.

    /*
    In non-exact ambiguity detection mode, we might	actually be able to
    detect an exact ambiguity, but I'm not going to spend the cycles
    needed to check. We only emit ambiguity warnings in exact ambiguity
    mode.

    For example, we might know that we have conflicting configurations.
    But, that does not mean that there is no way forward without a
    conflict. It's possible to have nonconflicting alt subsets as in:

       LL altSubSets=[{1, 2}, {1, 2}, {1}, {1, 2}]

    from

       [(17,1,[5 $]), (13,1,[5 10 $]), (21,1,[5 10 $]), (11,1,[$]),
        (13,2,[5 10 $]), (21,2,[5 10 $]), (11,2,[$])]

    In this case, (17,1,[5 $]) indicates there is some next sequence that
    would resolve this without conflict to alternative 1. Any other viable
    next sequence, however, is associated with a conflict.  We stop
    looking for input because no amount of further lookahead will alter
    the fact that we should predict alternative 1.  We just can't say for
    sure that there is an ambiguity without looking further.
    */

    AntlrBitSet *ambigAlts = antlr_atn_config_set_get_alts(reach);
    antlr_parser_atn_simulator_report_ambiguity(self,
                                                dfa,
                                                D,
                                                startIndex,
                                                antlr_int_stream_index(ANTLR_INT_STREAM(input)),
                                                foundExactAmbig,
                                                ambigAlts,
                                                reach);
    g_object_unref(ambigAlts);

    return predictedAlt;
}

static AntlrATNConfigSet*
antlr_parser_atn_simulator_compute_reach_set(AntlrParserATNSimulator *self, AntlrATNConfigSet *closure, gint t, gboolean fullCtx)
{
    if ( antlr_parser_atn_simulator_debug ) {
        gchar *str_config = antlr_atn_config_set_to_string(closure);
        g_print("in computeReachSet, starting closure: %s\n", str_config);
        g_free(str_config);
    }

    if (self->merge_cache == NULL) {
        //self->merge_cache = antlr_double_key_map_new(antlr_prediction_context_hash_code, antlr_prediction_context_equal, g_object_unref, g_object_unref);
        self->merge_cache = antlr_double_key_map_new_full((GHashFunc)antlr_prediction_context_hash_code, (GEqualFunc)antlr_prediction_context_equals, NULL, (GDestroyNotify)g_object_unref);//new DoubleKeyMap<PredictionContext, PredictionContext, PredictionContext>();
    }

    AntlrATNConfigSet *intermediate = antlr_atn_config_set_new_with_context(fullCtx);

    /* Configurations already in a rule stop state indicate reaching the end
     * of the decision rule (local context) or end of the start rule (full
     * context). Once reached, these configurations are never updated by a
     * closure operation, so they are handled separately for the performance
     * advantage of having a smaller intermediate set when calling closure.
     *
     * For full-context reach operations, separate handling is required to
     * ensure that the alternative matching the longest overall sequence is
     * chosen when multiple such configurations can match the input.
     */
    GList *skippedStopStates = NULL;// of AntlrATNConfig*

    // First figure out where we can reach on input t""
    GList *it;
    for(it = g_list_first(closure->configs); it; it=it->next) {
        AntlrATNConfig *c = it->data;
        if ( antlr_parser_atn_simulator_debug ) {
            gchar *str_token = antlr_parser_atn_simulator_get_token_name(self, t);
            gchar *str_config = antlr_object_to_string(ANTLR_OBJECT(c));
            g_print("testing %s at %s\n", str_token, str_config);
            g_free(str_token);
            g_free(str_config);
        }

        if (ANTLR_IS_RULE_STOP_STATE(c->state)) {
            g_assert(antlr_prediction_context_is_empty(c->context));

            if (fullCtx || t == ANTLR_INT_STREAM_EOF) {
                skippedStopStates = g_list_append(skippedStopStates, c);
            }

            continue;
        }

        // for each transition
        GList *transition_it=NULL;
        for (transition_it=g_list_first(c->state->transitions); transition_it; transition_it=transition_it->next) {
            AntlrTransition *trans = transition_it->data;
            AntlrATNState *target = antlr_parser_atn_simulator_get_reachable_target(self, trans, t);
            if ( target!=NULL ) {
                antlr_atn_config_set_add_with_cache(intermediate, antlr_atn_config_new_with_config_state(c, target), self->merge_cache);
            }
        }
    }

    // Now figure out where the reach operation can take us...
    AntlrATNConfigSet *reach = NULL;

    /* This block optimizes the reach operation for intermediate sets which
     * trivially indicate a termination state for the overall
     * adaptivePredict operation.
     *
     * The conditions assume that intermediate
     * contains all configurations relevant to the reach set, but this
     * condition is not true when one or more configurations have been
     * withheld in skippedStopStates, or when the current symbol is EOF.
     */

    if (skippedStopStates == NULL && t != ANTLR_TOKEN_EOF) {
        if ( antlr_atn_config_set_size(intermediate)==1 ) {

            // Don't pursue the closure if there is just one state.
            // It can only have one alternative; just add to result
            // Also don't pursue the closure if there is unique alternative
            // among the configurations.
            reach = intermediate;
            //g_object_ref(intermediate);
        }
        else if ( antlr_parser_atn_simulator_get_unique_alt(self, intermediate)!=ANTLR_ATN_INVALID_ALT_NUMBER ) {
            // Also don't pursue the closure if there is unique alternative
            // among the configurations.
            reach = intermediate;
            //g_object_ref(intermediate);
        }
    }

    /* If the reach set could not be trivially determined, perform a closure
     * operation on the intermediate set to compute its initial value.
     */
    if (reach == NULL) {
        reach = antlr_atn_config_set_new_with_context(fullCtx);
        //GHashTable *closureBusy = g_hash_table_new_full((GHashFunc)antlr_atn_config_hash_code, (GEqualFunc)antlr_atn_config_equals, NULL, (GDestroyNotify)g_object_unref); // Set<AntlrATNConfig> closureBusy = new HashSet<ATNConfig>();
        GHashTable *closureBusy = g_hash_table_new((GHashFunc)antlr_atn_config_hash_code, (GEqualFunc)antlr_atn_config_equals);
        gboolean treatEofAsEpsilon = (t == ANTLR_TOKEN_EOF);
        GList *it;
        for (it = g_list_first(intermediate->configs); it; it=it->next) {
            AntlrATNConfig *c = it->data;
            antlr_parser_atn_simulator_closure(self, c, reach, closureBusy, FALSE, fullCtx, treatEofAsEpsilon);
        }
        g_hash_table_destroy(closureBusy);
        //g_object_unref(reach);
    }
    //g_object_unref(intermediate);


    if (t == ANTLR_INT_STREAM_EOF) {
        /* After consuming EOF no additional input is possible, so we are
         * only interested in configurations which reached the end of the
         * decision rule (local context) or end of the start rule (full
         * context). Update reach to contain only these configurations. This
         * handles both explicit EOF transitions in the grammar and implicit
         * EOF transitions following the end of the decision or start rule.
         *
         * When reach==intermediate, no closure operation was performed. In
         * this case, removeAllConfigsNotInRuleStopState needs to check for
         * reachable rule stop states as well as configurations already in
         * a rule stop state.
         *
         * This is handled before the configurations in skippedStopStates,
         * because any configurations potentially added from that list are
         * already guaranteed to meet this condition whether or not it's
         * required.
         */
        reach = antlr_parser_atn_simulator_remove_all_configs_not_in_rule_stop_state(self, reach, reach == intermediate);
    }

    /* If skippedStopStates is not null, then it contains at least one
     * configuration. For full-context reach operations, these
     * configurations reached the end of the start rule, in which case we
     * only add them back to reach if no configuration during the current
     * closure operation reached such a state. This ensures adaptivePredict
     * chooses an alternative matching the longest overall sequence when
     * multiple alternatives are viable.
     */
    if (skippedStopStates != NULL && (!fullCtx || !antlr_prediction_mode_has_config_in_rule_stop_state(reach))) {
        g_assert(g_list_length(skippedStopStates));
        GList *it;
        for (it = g_list_first(skippedStopStates); it; it=it->next) {
            AntlrATNConfig *c = it->data;
            antlr_atn_config_set_add_with_cache(reach, c, self->merge_cache);
        }
    }
    g_list_free(skippedStopStates);

    if ( antlr_atn_config_set_is_empty(reach) )
        return NULL;

    return reach;
}

/**
 * antlr_parser_atn_simulator_report_ambiguity:
 * @self: Some #AntlrParserATNSimulator
 * @dfa: The DFA
 * @D: The current DFA state
 * @startIndex: The start index
 * @stopIndex: The stop index
 * @exact: The exact
 * @ambigAlts: The ambigute alts
 * @configs: The configs
 *
 * If context sensitive parsing, we know it's ambiguity not conflict
 *
 */
static void
antlr_parser_atn_simulator_report_ambiguity(AntlrParserATNSimulator *self,
                                            AntlrDFA *dfa,
                                            AntlrDFAState *D, // the DFA state from execATN() that had SLL conflicts
                                            gint startIndex, gint stopIndex,
                                            gboolean exact,
                                            AntlrBitSet *ambigAlts,
                                            AntlrATNConfigSet *configs) // configs that LL not SLL considered conflicting
{
    if ( antlr_parser_atn_simulator_debug || antlr_parser_atn_simulator_retry_debug ) {
        AntlrInterval *interval = antlr_interval_of(startIndex, stopIndex);
        gchar *str_bit_set = antlr_bit_set_to_string(ambigAlts);
        gchar *str_configs = antlr_atn_config_set_to_string(configs);
        AntlrTokenStream *stream = antlr_parser_get_token_stream(self->parser);
        gchar *str_text = antlr_token_stream_get_text_from_interval(stream, interval);
        g_print("reportAmbiguity %s:%s, input=%s\n", str_bit_set, str_configs, str_text);
        g_free(str_bit_set);
        g_free(str_configs);
        g_free(str_text);
        g_object_unref(interval);
    }
    if ( self->parser!=NULL ) {
        AntlrErrorListener *listener = antlr_recognizer_get_error_listener_dispatch(ANTLR_RECOGNIZER(self->parser));
        antlr_error_listener_report_ambiguity(listener, self->parser, dfa, startIndex, stopIndex, exact, ambigAlts, configs);
    }
}
