/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * atn-state.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_ATN_STATE_H__
#define __ANTLR_ATN_STATE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_ATN_STATE_INITIAL_NUM_TRANSITIONS 4

// constants for serialization
#define ANTLR_ATN_STATE_INVALID_TYPE      0
#define ANTLR_ATN_STATE_BASIC             1
#define ANTLR_ATN_STATE_RULE_START        2
#define ANTLR_ATN_STATE_BLOCK_START       3
#define ANTLR_ATN_STATE_PLUS_BLOCK_START  4
#define ANTLR_ATN_STATE_STAR_BLOCK_START  5
#define ANTLR_ATN_STATE_TOKEN_START       6
#define ANTLR_ATN_STATE_RULE_STOP         7
#define ANTLR_ATN_STATE_BLOCK_END         8
#define ANTLR_ATN_STATE_STAR_LOOP_BACK    9
#define ANTLR_ATN_STATE_STAR_LOOP_ENTRY  10
#define ANTLR_ATN_STATE_PLUS_LOOP_BACK   11
#define ANTLR_ATN_STATE_LOOP_END         12

/*
typedef struct _StringStatic {
    gchar *string;
    gint len;
} StringStatic;
#define STATIC_STRING_INIT(str) {str, sizeof(str)}

static StringStatic antlr_atn_state_serialization_names[] = {
    STATIC_STRING_INIT("INVALID"),
    STATIC_STRING_INIT("BASIC"),
    STATIC_STRING_INIT("RULE_START"),
    STATIC_STRING_INIT("BLOCK_START"),
    STATIC_STRING_INIT("PLUS_BLOCK_START"),
    STATIC_STRING_INIT("STAR_BLOCK_START"),
    STATIC_STRING_INIT("TOKEN_START"),
    STATIC_STRING_INIT("RULE_STOP"),
    STATIC_STRING_INIT("BLOCK_END"),
    STATIC_STRING_INIT("STAR_LOOP_BACK"),
    STATIC_STRING_INIT("STAR_LOOP_ENTRY"),
    STATIC_STRING_INIT("PLUS_LOOP_BACK"),
    STATIC_STRING_INIT("LOOP_END")

};
//G_N_ELEMENTS(antlr_atn_state_serialization_names);
*/

#define ANTLR_ATN_STATE_INVALID_STATE_NUMBER -1


#define ANTLR_TYPE_ATN_STATE            (antlr_atn_state_get_type())
#define ANTLR_ATN_STATE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_ATN_STATE, AntlrATNState))
#define ANTLR_ATN_STATE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_ATN_STATE, AntlrATNStateClass))
#define ANTLR_IS_ATN_STATE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_ATN_STATE))
#define ANTLR_IS_ATN_STATE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_ATN_STATE))
#define ANTLR_ATN_STATE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_ATN_STATE, AntlrATNStateClass))

typedef struct _AntlrATNStateClass AntlrATNStateClass;

/**
 * AntlrATNState:
 * @atn: Which ATN are we in?
 * @state_number: The number state
 * @rule_index:  at runtime, we don't have Rule objects
 * @epsilon_only_transitions: The epsilon
 * @transitions: GList of #AntlrTransition Track the transitions emanating from this ATN state
 * @next_token_within_rule: Used to cache lookahead during parsing, not used during construction
 *
 */
struct _AntlrATNState {
    /*< private >*/
    AntlrObject parent_instance;

    /*< public >*/
    AntlrATN *atn;// AntlrPtrShared
    gint state_number;
    gint rule_index;
    gboolean epsilon_only_transitions;

    GList_AntlrTransition *transitions;
    AntlrIntervalSet *next_token_within_rule;
};

struct _AntlrATNStateClass {
    AntlrObjectClass parent_class;

    gint          (*hash_code) (AntlrATNState *self);
    gboolean         (*equals) (AntlrATNState *self, GObject *o);

    gint     (*get_state_type) (AntlrATNState *self);
};

GType antlr_atn_state_get_type(void)G_GNUC_CONST;
AntlrATNState *antlr_atn_state_new();

gint     antlr_atn_state_get_state_type(AntlrATNState *self);
gint     antlr_atn_state_hash_code(AntlrATNState *self);
gboolean antlr_atn_state_equals(AntlrATNState *self, GObject *o);
gboolean antlr_atn_state_is_non_greedy_exit_state(AntlrATNState *self);

GList   *antlr_atn_state_get_transitions(AntlrATNState *self);
gint     antlr_atn_state_get_number_of_transitions(AntlrATNState *self);

void antlr_atn_state_add_transition(AntlrATNState *self, AntlrTransition *e);
void antlr_atn_state_add_transition_at(AntlrATNState *self, gint index, AntlrTransition *e);

AntlrTransition* antlr_atn_state_transition(AntlrATNState *self, gint i);
void antlr_atn_state_set_transition(AntlrATNState *self, gint i, AntlrTransition *e);
AntlrTransition* antlr_atn_state_remove_transition(AntlrATNState *self, gint i);
gboolean antlr_atn_state_only_has_epsilon_transitions(AntlrATNState *self);
void antlr_atn_state_set_rule_index(AntlrATNState *self, gint rule_index);


G_END_DECLS

#endif /* __ANTLR_ATN_STATE_H__ */

