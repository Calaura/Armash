/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * star-block-start-state.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"
#include "transition.h"
#include "atn-state.h"
#include "decision-state.h"
#include "block-end-state.h"
#include "block-start-state.h"

#include "star-block-start-state.h"


static void antlr_star_block_start_state_class_init(AntlrStarBlockStartStateClass *klass);
static void antlr_star_block_start_state_init(AntlrStarBlockStartState *gobject);

G_DEFINE_TYPE (AntlrStarBlockStartState, antlr_star_block_start_state, ANTLR_TYPE_BLOCK_START_STATE)

static gint
antlr_star_block_start_state_class_atn_state_get_state_type(AntlrATNState *self)
{
    return ANTLR_ATN_STATE_STAR_BLOCK_START;
}

static void
antlr_star_block_start_state_class_init(AntlrStarBlockStartStateClass *klass)
{
//    AntlrBlockStartStateClass *blockstartstate_class;
    AntlrATNStateClass *atn_class;

    atn_class = (AntlrATNStateClass *) klass;

    atn_class->get_state_type = antlr_star_block_start_state_class_atn_state_get_state_type;

//	antlr_star_block_start_state_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_star_block_start_state_init (AntlrStarBlockStartState *object)
{
}

AntlrStarBlockStartState *
antlr_star_block_start_state_new (void)
{
	return g_object_new (antlr_star_block_start_state_get_type (),
	                     NULL);
}
