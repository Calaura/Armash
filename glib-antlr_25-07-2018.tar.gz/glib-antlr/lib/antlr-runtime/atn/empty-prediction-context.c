/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * empty-prediction-context.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"

//#include "rule-context.h"
//#include "parser-rule-context.h"
#include "prediction-context.h"
#include "singleton-prediction-context.h"
#include "empty-prediction-context.h"


static void antlr_empty_prediction_context_class_init(AntlrEmptyPredictionContextClass *klass);
static void antlr_empty_prediction_context_init(AntlrEmptyPredictionContext *gobject);

G_DEFINE_TYPE (AntlrEmptyPredictionContext, antlr_empty_prediction_context, ANTLR_TYPE_SINGLETON_PREDICTION_CONTEXT)

static void
antlr_empty_prediction_context_finalize(GObject *object)
{
	/* TODO: Add deinitalization code here */

	G_OBJECT_CLASS (antlr_empty_prediction_context_parent_class)->finalize (object);
}

static gchar*
antlr_empty_prediction_context_class_object_to_string(AntlrPredictionContext *self)
{
    return g_strdup("$");
}

static gboolean
antlr_empty_prediction_context_class_prediction_context_equals(AntlrPredictionContext *self, /*AntlrPredictionContext*/GObject *o) {
    return self == ANTLR_PREDICTION_CONTEXT(o);
}

static gboolean
antlr_empty_prediction_context_class_prediction_context_is_empty(AntlrPredictionContext *self) {
    return TRUE;
}

static gint
antlr_empty_prediction_context_class_prediction_context_size(AntlrPredictionContext *self) {
    return 1;
}

static AntlrPredictionContext*
antlr_empty_prediction_context_class_prediction_context_get_parent(AntlrPredictionContext *self, gint index) {
    return NULL;
}

static gint
antlr_empty_prediction_context_class_prediction_context_get_return_state(AntlrPredictionContext *self, gint index) {
    return ANTLR_SINGLETON_PREDICTION_CONTEXT(self)->return_state;
}

static void
antlr_empty_prediction_context_class_init(AntlrEmptyPredictionContextClass *klass)
{
    AntlrPredictionContextClass *predictioncontext_class;
//    AntlrSingletonPredictionContextClass *antlrsingletonpredictioncontext_class;

//	antlrsingletonpredictioncontext_class = (AntlrSingletonPredictionContextClass *) klass;
    predictioncontext_class = (AntlrPredictionContextClass *) klass;

    //antlrsingletonpredictioncontext_class->finalize = antlr_empty_prediction_context_finalize;
    predictioncontext_class->equals = antlr_empty_prediction_context_class_prediction_context_equals;
    predictioncontext_class->is_empty = antlr_empty_prediction_context_class_prediction_context_is_empty;
    predictioncontext_class->get_return_state = antlr_empty_prediction_context_class_prediction_context_get_return_state;
    predictioncontext_class->get_parent = antlr_empty_prediction_context_class_prediction_context_get_parent;
    predictioncontext_class->size = antlr_empty_prediction_context_class_prediction_context_size;


    ANTLR_OBJECT_CLASS(klass)->to_string = antlr_empty_prediction_context_class_object_to_string;
//	antlr_empty_prediction_context_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_empty_prediction_context_init (AntlrEmptyPredictionContext *object)
{
}

AntlrEmptyPredictionContext *
antlr_empty_prediction_context_new (void)
{
    AntlrSingletonPredictionContext*
    context = antlr_singleton_prediction_context_super_with_parent(
        ANTLR_TYPE_EMPTY_PREDICTION_CONTEXT,
        NULL,
        ANTLR_PREDICTION_CONTEXT_EMPTY_RETURN_STATE
    );

    return ANTLR_EMPTY_PREDICTION_CONTEXT(context);
}

#if 0

/*
 * [The "BSD license"]
 *  Copyright (c) 2012 Terence Parr
 *  Copyright (c) 2012 Sam Harwell
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. The name of the author may not be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS OR
 *  IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 *  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
 *  NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
 *  THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

package org.antlr.v4.runtime.atn;

public class EmptyPredictionContext extends SingletonPredictionContext {
    public EmptyPredictionContext() {
        super(null, EMPTY_RETURN_STATE);
    }

    @Override
    public boolean isEmpty() { return true; }

    @Override
    public int size() {
        return 1;
    }

    @Override
    public PredictionContext getParent(int index) {
        return null;
    }

    @Override
    public int getReturnState(int index) {
        return returnState;
    }

    @Override
    public boolean equals(Object o) {
        return this == o;
    }

    @Override
    public String toString() {
        return "$";
    }
}

#endif
