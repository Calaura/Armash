/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * semantic-context.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"

#include "../misc/object.h"
#include "../misc/murmur-hash.h"

#include "prediction-context.h"
#include "prediction-context-cache.h"
#include "atn-simulator.h"
#include "../vocabulary.h"
#include "../recognizer.h"
#include "semantic-context.h"

static AntlrSemanticContext* antlr_semantic_context_none = NULL;

static AntlrSemanticContext*
antlr_semantic_context_default_eval_precedence(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack) {
    return self;
}

static void antlr_semantic_context_class_init(AntlrSemanticContextClass *klass);
static void antlr_semantic_context_init(AntlrSemanticContext *gobject);

G_DEFINE_TYPE (AntlrSemanticContext, antlr_semantic_context, ANTLR_TYPE_OBJECT)


static void
antlr_semantic_context_class_object_dispose(GObject *object)
{
    AntlrSemanticContext *self = ANTLR_SEMANTIC_CONTEXT(object);

    G_OBJECT_CLASS(antlr_semantic_context_parent_class)->dispose(object);
}

static void
antlr_semantic_context_class_init(AntlrSemanticContextClass *klass)
{
    GObjectClass *gobject_class;
    gobject_class = (GObjectClass *) klass;

    gobject_class->dispose = antlr_semantic_context_class_object_dispose;

    klass->eval = NULL;//antlr_semantic_context_default_eval
    klass->eval_precedence = antlr_semantic_context_default_eval_precedence;
    klass->equals = NULL;

//	antlr_semantic_context_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_semantic_context_init (AntlrSemanticContext *object)
{
}

//AntlrSemanticContext *
//antlr_semantic_context_new (void)
//{
//	return g_object_new (antlr_semantic_context_get_type (),
//	                     NULL);
//}

/**
 * antlr_semantic_context_get_none:
 *
 * The default #AntlrSemanticContext, which is semantically equivalent to
 * a predicate of the form %TRUE.
 */
AntlrSemanticContext*
antlr_semantic_context_get_none()
{
    if (!antlr_semantic_context_none) {
        antlr_semantic_context_none = antlr_predicate_new();
    }
    return antlr_semantic_context_none;
}

void
antlr_semantic_context_none_free()
{
    if (antlr_semantic_context_none) {
        g_object_unref(antlr_semantic_context_none);
    }
    antlr_semantic_context_none = NULL;
}

gboolean
antlr_semantic_context_equals(AntlrSemanticContext *self, AntlrSemanticContext *o)
{
    g_return_val_if_fail(ANTLR_IS_SEMANTIC_CONTEXT(self), FALSE);

    return ANTLR_SEMANTIC_CONTEXT_GET_CLASS(self)->equals(self, o);
}

guint
antlr_semantic_context_hash_code(AntlrSemanticContext *self)
{
    AntlrSemanticContextClass *klass = NULL;
    const gchar *name = NULL;
    g_return_val_if_fail(ANTLR_IS_SEMANTIC_CONTEXT(self), 0);

    klass = ANTLR_SEMANTIC_CONTEXT_GET_CLASS(self);
    name = g_type_name_from_instance((GTypeInstance*)self);
    if (g_strcmp0("AntlrPredicate", name)==0) {
        ///g_print("bug\n");
        ///g_printerr("bug\n");
    }
    return klass->hash_code(self);
}


/**
 * antlr_semantic_context_eval:
 * @self: Some #AntlrSemanticContext
 * @parser: The parser instance
 * @parser_call_stack: The parser call stack
 *
 * For context independent predicates, we evaluate them without a local
 * context (i.e., null context). That way, we can evaluate them without
 * having to create proper rule-specific context during prediction (as
 * opposed to the parser, which creates them naturally). In a practical
 * sense, this avoids a cast exception from RuleContext to myruleContext.
 *
 * <p>For context dependent predicates, we must pass in a local context so that
 * references such as $arg evaluate properly as _localctx.arg. We only
 * capture context dependent predicates in the context in which we begin
 * prediction, so we passed in the outer context here in case of context
 * dependent predicate evaluation.</p>
 */
gboolean
antlr_semantic_context_eval(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack)
{
    g_return_val_if_fail(ANTLR_IS_SEMANTIC_CONTEXT(self), FALSE);

    return ANTLR_SEMANTIC_CONTEXT_GET_CLASS(self)->eval(self, parser, parser_call_stack);
}

/**
 * antlr_semantic_context_eval_precedence:
 * @self: Some #AntlrSemanticContext
 * @parser: The parser instance.
 * @parser_call_stack: The parser call stack
 *
 * Evaluate the precedence predicates for the context and reduce the result.
 *
 * Returns: The simplified semantic context after precedence predicates are
 * evaluated, which will be one of the following values.
  * - %ANTLR_SEMANTIC_CONTEXT_NONE: if the predicate simplifies to %TRUE after
 * precedence predicates are evaluated.
 * - %NULL: if the predicate simplifies to %FALSE after
 * precedence predicates are evaluated.
 * - @self: if the semantic context is not changed as a result of
 * precedence predicate evaluation.
 * - A non-%NULL #AntlrSemanticContext: the new simplified
 * semantic context after precedence predicates are evaluated.
 */
AntlrSemanticContext*
antlr_semantic_context_eval_precedence(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack) {
    g_return_val_if_fail(ANTLR_IS_SEMANTIC_CONTEXT(self), NULL);

    return ANTLR_SEMANTIC_CONTEXT_GET_CLASS(self)->eval_precedence(self, parser, parser_call_stack);
}

GList* // of <PrecedencePredicate>
antlr_semantic_context_filter_precedence_predicates(AntlrSemanticContext *self, GHashTable *collection) {// collection of SemanticContext
    GList *result = NULL;// of ArrayList<PrecedencePredicate>

    GHashTableIter iter;
    gpointer key, value;
    g_hash_table_iter_init (&iter, collection);
    while (g_hash_table_iter_next (&iter, &key, &value))
      {
        AntlrSemanticContext *context = ANTLR_SEMANTIC_CONTEXT(value);
        if (ANTLR_IS_PRECEDENCE_PREDICATE(context)) {
            result = g_list_append(result, context);
        }
      }

    /*
    GList *it;
    for (it=g_list_first(collection); it; it=it->next) {
        AntlrSemanticContext *context = it->data;
        if (ANTLR_IS_PRECEDENCE_PREDICATE(context)) {
            result = g_list_append(result, context);
        }
    }
    */

    return result;
}

AntlrSemanticContext*
antlr_semantic_context_and(AntlrSemanticContext *a, AntlrSemanticContext *b) {
    if ( a == NULL || a == antlr_semantic_context_get_none() ) return b;
    if ( b == NULL || b == antlr_semantic_context_get_none() ) return a;
    AntlrSemanticContext *result = antlr_and_new_with_context(a, b);

    if (g_list_length(ANTLR_AND(result)->opnds) == 1) {
        return g_list_first(ANTLR_AND(result)->opnds)->data;
    }

    return result;
}

/**
 * antlr_semantic_context_or:
 * @a: The first #AntlrSemanticContext
 * @b: The second #AntlrSemanticContext
 *
 * @see ParserATNSimulator#getPredsForAmbigAlts
 */
AntlrSemanticContext*
antlr_semantic_context_or(AntlrSemanticContext *a, AntlrSemanticContext *b) {
    if ( a == NULL ) return b;
    if ( b == NULL ) return a;
    if ( a == antlr_semantic_context_get_none() || b == antlr_semantic_context_get_none() ) return antlr_semantic_context_get_none();

    AntlrSemanticContext *result = antlr_or_new_with_context(a, b);
    if (g_list_length(ANTLR_OR(result)->opnds) == 1) {
        return g_list_first(ANTLR_OR(result)->opnds)->data;
    }

    return result;
}

// ----------------------------------------------------------------------------
static gboolean
antlr_predicate_class_semantic_context_eval(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack)
{
    AntlrPredicate *predicate = ANTLR_PREDICATE(self);
    AntlrRuleContext *localctx = predicate->is_ctx_dependent ? parser_call_stack : NULL;

    return antlr_recognizer_sempred(parser, localctx, predicate->rule_index, predicate->pred_index);
}

static guint
antlr_predicate_class_semantic_context_hash_code(AntlrSemanticContext *obj) {
    AntlrPredicate *self = ANTLR_PREDICATE(obj);
    gint hash_code = antlr_murmur_hash_initialize(ANTLR_MURMUR_HASH_DEFAULT_SEED);
    hash_code = antlr_murmur_hash_update(hash_code, self->rule_index);
    hash_code = antlr_murmur_hash_update(hash_code, self->pred_index);
    hash_code = antlr_murmur_hash_update(hash_code, self->is_ctx_dependent ? 1 : 0);
    hash_code = antlr_murmur_hash_finish(hash_code, 3);
    return hash_code;
}
static gboolean
antlr_predicate_class_semantic_context_equals(AntlrSemanticContext *self, AntlrSemanticContext *o)
{
    if ( !ANTLR_IS_PREDICATE(o) )
        return FALSE;

    if ( self == o )
        return TRUE;

    AntlrPredicate *s = ANTLR_PREDICATE(self);
    AntlrPredicate *p = ANTLR_PREDICATE(o);
    return s->rule_index == p->rule_index &&
           s->pred_index == p->pred_index &&
           s->is_ctx_dependent == p->is_ctx_dependent;
}

static gchar*
antlr_predicate_class_object_to_string(AntlrSemanticContext *obj)
{
    AntlrPredicate *self = ANTLR_PREDICATE(obj);
    return g_strdup_printf("{%d:%d}?", self->rule_index, self->pred_index);
}

static void antlr_predicate_class_init(AntlrPredicateClass *klass);
static void antlr_predicate_init(AntlrPredicate *gobject);

G_DEFINE_TYPE (AntlrPredicate, antlr_predicate, ANTLR_TYPE_SEMANTIC_CONTEXT)

static void
antlr_predicate_class_init(AntlrPredicateClass *klass)
{
//    GObjectClass *gobject_class;
    AntlrSemanticContextClass *semantic_class;

//    gobject_class = (GObjectClass *) klass;
    semantic_class = (AntlrSemanticContextClass *) klass;

    semantic_class->eval = antlr_predicate_class_semantic_context_eval;


    semantic_class->equals    = antlr_predicate_class_semantic_context_equals;
    semantic_class->hash_code = antlr_predicate_class_semantic_context_hash_code;

    ANTLR_OBJECT_CLASS(klass)->to_string = antlr_predicate_class_object_to_string;
}

static void
antlr_predicate_init (AntlrPredicate *object)
{
}

void
antlr_predicate_super (AntlrPredicate *self,
                       gint rule_index,
                       gint pred_index,
                       gboolean is_ctx_dependent)
{
    self->rule_index = rule_index;
    self->pred_index = pred_index;
    self->is_ctx_dependent = is_ctx_dependent;
}

AntlrSemanticContext *
antlr_predicate_new (void)
{
    AntlrPredicate *predicate = g_object_new (ANTLR_TYPE_PREDICATE, NULL);
    antlr_predicate_super (predicate, -1, -1, FALSE);

    return ANTLR_SEMANTIC_CONTEXT(predicate);
}

AntlrSemanticContext *
antlr_predicate_new_full (gint rule_index,
                          gint pred_index,
                          gboolean is_ctx_dependent)
{
    AntlrPredicate *predicate = g_object_new (ANTLR_TYPE_PREDICATE, NULL);
    antlr_predicate_super (predicate, rule_index, pred_index, is_ctx_dependent);

    return ANTLR_SEMANTIC_CONTEXT(predicate);
}


// ----------------------------------------------------------------------------


static guint
antlr_precedence_predicate_class_semantic_context_hash_code(AntlrSemanticContext *obj) {
    AntlrPrecedencePredicate *self = ANTLR_PRECEDENCE_PREDICATE(obj);
    guint hash_code = 1;
    hash_code = 31 * hash_code + self->precedence;
    return hash_code;
}

static gboolean
antlr_precedence_predicate_default_equals(AntlrSemanticContext *self, AntlrSemanticContext *o) {
    if ( !ANTLR_IS_PRECEDENCE_PREDICATE(o) )
        return FALSE;

    if (self == o) {
        return TRUE;
    }

    AntlrPrecedencePredicate *s = ANTLR_PRECEDENCE_PREDICATE(self);
    AntlrPrecedencePredicate *other = ANTLR_PRECEDENCE_PREDICATE(o);
    return s->precedence == other->precedence;
}
static gchar*
antlr_precedence_predicate_class_object_to_string(AntlrSemanticContext *obj) {
    AntlrPrecedencePredicate *self = ANTLR_PRECEDENCE_PREDICATE(obj);
    return g_strdup_printf("{%d>=prec}?", self->precedence);
}

static gboolean
antlr_precedence_predicate_class_semantic_context_eval(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack) {
    AntlrPrecedencePredicate *predicate = ANTLR_PRECEDENCE_PREDICATE(self);
    return antlr_recognizer_precpred(parser, parser_call_stack, predicate->precedence);
}

static AntlrSemanticContext*
antlr_precedence_predicate_class_semantic_context_eval_precedence(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack) {
    AntlrPrecedencePredicate *predicate = ANTLR_PRECEDENCE_PREDICATE(self);
    if (antlr_recognizer_precpred(parser, parser_call_stack, predicate->precedence)) {
        return antlr_semantic_context_get_none();
    } else {
        return NULL;
    }
}

static void antlr_precedence_predicate_class_init(AntlrPrecedencePredicateClass *klass);
static void antlr_precedence_predicate_init(AntlrPrecedencePredicate *gobject);

G_DEFINE_TYPE (AntlrPrecedencePredicate, antlr_precedence_predicate, ANTLR_TYPE_SEMANTIC_CONTEXT)

static void
antlr_precedence_predicate_class_init(AntlrPrecedencePredicateClass *klass)
{
//    GObjectClass *gobject_class;
    AntlrSemanticContextClass *semantic_class;

//    gobject_class = (GObjectClass *) klass;
    semantic_class = (AntlrSemanticContextClass *) klass;

    semantic_class->eval = antlr_precedence_predicate_class_semantic_context_eval;
    semantic_class->eval_precedence = antlr_precedence_predicate_class_semantic_context_eval_precedence;
    semantic_class->equals    = antlr_precedence_predicate_default_equals;

    semantic_class->hash_code = antlr_precedence_predicate_class_semantic_context_hash_code;

    ANTLR_OBJECT_CLASS(klass)->to_string = antlr_precedence_predicate_class_object_to_string;
}

static void
antlr_precedence_predicate_init (AntlrPrecedencePredicate *object)
{
    object->precedence = 0;
}


AntlrSemanticContext *
antlr_precedence_predicate_new (gint precedence)
{
    AntlrPrecedencePredicate *self = g_object_new (ANTLR_TYPE_PRECEDENCE_PREDICATE, NULL);
    self->precedence = precedence;

    return ANTLR_SEMANTIC_CONTEXT(self);
}


#if 0
public static class PrecedencePredicate extends SemanticContext implements Comparable<PrecedencePredicate> {
    @Override
    public int compareTo(PrecedencePredicate o) {
        return precedence - o.precedence;
    }
#endif

// ----------------------------------------------------------------------------

static void antlr_operator_class_init(AntlrOperatorClass *klass);
static void antlr_operator_init(AntlrOperator *gobject);

G_DEFINE_TYPE (AntlrOperator, antlr_operator, ANTLR_TYPE_SEMANTIC_CONTEXT)

static void
antlr_operator_class_init(AntlrOperatorClass *klass)
{
//    GObjectClass *gobject_class;

//    gobject_class = (GObjectClass *) klass;

    klass->get_operands = NULL;

//    antlr_operator_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_operator_init (AntlrOperator *object)
{
}

//AntlrSemanticContext *
//antlr_operator_new (void)
//{
//    return g_object_new (antlr_operator_get_type (),
//                         NULL);
//}

/**
 * antlr_operator_get_operands:
 * @self: Some #AntlrOperator
 *
 * Gets the operands for the semantic context operator.
 *
 * Returns: a collection of #AntlrSemanticContext operands for the
 * operator.
 *
 */
GList*
antlr_operator_get_operands(AntlrOperator *self)
{
    g_return_val_if_fail(ANTLR_IS_OPERATOR(self), NULL);

    return ANTLR_OPERATOR_GET_CLASS(self)->get_operands(self);
}


// ----------------------------------------------------------------------------
static gboolean
g1_list_equals(GList *list, GList *o, GEqualFunc func) {
    GList *it_list;
    GList *it_o;
    gboolean ret = TRUE;
    if (g_list_length(list) != g_list_length(o)) {
        return FALSE;
    }
    for(it_list = g_list_first(list),
        it_o = g_list_first(o);
        it_list && it_o;
        it_list = it_list->next,
        it_o = it_o->next
    ) {
        if (it_list->data==it_o->data
         || func(it_list->data, it_o->data)
        ) {
            ret = TRUE;
            continue;
        } else {
            ret = FALSE;
            break;
        }
    }

    return ret;
}

static gboolean
antlr_and_class_semantic_context_equals(AntlrSemanticContext *self, AntlrSemanticContext *o) {
    if (self==o) {
        return TRUE;
    }
    if (!ANTLR_IS_AND(o)) {
        return FALSE;
    }

    return g1_list_equals(ANTLR_AND(self)->opnds, ANTLR_AND(o)->opnds, (GEqualFunc)antlr_semantic_context_equals);
}
static gchar*
antlr_and_class_object_to_string(AntlrSemanticContext *self) {
    gchar *symbol = "&&";
    gchar *glue = "";
    GString *str = g_string_new("");
    GList *it;
    for (it = g_list_first(ANTLR_AND(self)->opnds); it; it=it->next) {
        AntlrSemanticContext *context = it->data;
        gchar *tmp = antlr_object_to_string(ANTLR_OBJECT(context));
        g_string_append_printf(str, "%s%s", glue, tmp);
        glue = symbol;
        g_free(tmp);
    }
    return g_string_free(str, FALSE);
}

static GList*
antlr_and_get_operands(AntlrOperator *obj) {
    AntlrAnd *self = ANTLR_AND(obj);
    return self->opnds;
}

static guint antlr_and_class_semantic_context_hash_code(AntlrSemanticContext *self);
static void antlr_and_class_init(AntlrAndClass *klass);
static void antlr_and_init(AntlrAnd *gobject);

G_DEFINE_TYPE (AntlrAnd, antlr_and, ANTLR_TYPE_OPERATOR)

static void
antlr_and_class_init(AntlrAndClass *klass)
{
//    GObjectClass *gobject_class;
    AntlrOperatorClass *operator_class;
    AntlrSemanticContextClass *semantic_class;

//    gobject_class = (GObjectClass *) klass;
    operator_class = (AntlrOperatorClass *) klass;
    semantic_class = (AntlrSemanticContextClass *) klass;

    operator_class->get_operands = antlr_and_get_operands;

//    semantic_class->eval = antlr_and_class_semantic_context_eval;
//    semantic_class->eval_precedence = antlr_and_class_semantic_context_eval_precedence;
    semantic_class->equals = antlr_and_class_semantic_context_equals;
    semantic_class->hash_code = antlr_and_class_semantic_context_hash_code;

    ANTLR_OBJECT_CLASS(klass)->to_string = antlr_and_class_object_to_string;
}


/**
 * antlr_and_class_semantic_context_eval:
 * @self: Some #AntlrSemanticContext
 * @parser: The parser instance
 * @parser_call_stack: The parser call stack
 *
 * The evaluation of predicates by this context is short-circuiting, but
 * unordered.
 */
static gboolean
antlr_and_class_semantic_context_eval(AntlrSemanticContext*self,
                                      AntlrRecognizer *parser,
                                      AntlrRuleContext *parser_call_stack) {
    GList *it;
    for (it = g_list_first(ANTLR_AND(self)->opnds); it; it=it->next) {
        AntlrSemanticContext *opnd = it->data;
        if ( !antlr_semantic_context_eval(opnd, parser, parser_call_stack) )
            return FALSE;
    }
    return TRUE;
}

static AntlrSemanticContext*
antlr_and_class_semantic_context_eval_precedence(AntlrSemanticContext*self,
                                                 AntlrRecognizer *parser,
                                                 AntlrRuleContext *parser_call_stack) {
    GList *it;
    gboolean differs = FALSE;
    GList *operands = NULL; // new ArrayList<SemanticContext>();
    for (it=g_list_first(ANTLR_AND(self)->opnds); it; it=it->next) {
        AntlrSemanticContext *context = it->data;
        AntlrSemanticContext *evaluated = antlr_semantic_context_eval_precedence(context, parser, parser_call_stack);
        differs |= (evaluated != context);
        if (evaluated == NULL) {
            // The AND context is false if any element is false
            return NULL;
        } else if (evaluated != antlr_semantic_context_get_none()) {
            // Reduce the result by skipping true elements
            operands = g_list_append(operands, evaluated);
        }
    }

    if (!differs) {
        return self;
    }


    if (!g_list_length(operands)) {
        // all elements were true, so the AND context is true
        return antlr_semantic_context_get_none();
    }


    it = g_list_first(operands);
    AntlrSemanticContext *result = it->data;
    for (it=it->next; it; it=it->next) {
        result = antlr_semantic_context_or(result, it->data);
    }

    return result;
}

static void
antlr_and_init (AntlrAnd *object)
{
    object->opnds = NULL;
}

AntlrSemanticContext *
antlr_and_new (void)
{
    return g_object_new (antlr_and_get_type (),
                         NULL);
}

static AntlrPrecedencePredicate *
antlr_semantic_context_list_min (GList *list) {
    AntlrPrecedencePredicate *ret = NULL;
    GList *it;
    for (it=g_list_first(list); it; it=it->next) {
        if (ret == NULL) {
            ret = it->data;
        } else if (ANTLR_PRECEDENCE_PREDICATE(it->data)->precedence < ret->precedence ) {
            ret = it->data;
        }
    }
    return ret;
}

static AntlrPrecedencePredicate *
antlr_semantic_context_list_max(GList *precedence_predicates) {
    AntlrPrecedencePredicate *ret = NULL;
    GList *it;
    for (it=g_list_first(precedence_predicates); it; it=it->next) {
        if (ret == NULL) {
            ret = it->data;
        } else if (ANTLR_PRECEDENCE_PREDICATE(it->data)->precedence > ret->precedence ) {
            ret = it->data;
        }
    }
    return ret;
}

#if 0
public AND(SemanticContext a, SemanticContext b) {
    Set<SemanticContext> operands = new HashSet<SemanticContext>();
    if ( a instanceof AND ) operands.addAll(Arrays.asList(((AND)a).opnds));
    else operands.add(a);
    if ( b instanceof AND ) operands.addAll(Arrays.asList(((AND)b).opnds));
    else operands.add(b);

    List<PrecedencePredicate> precedencePredicates = filterPrecedencePredicates(operands);
    if (!precedencePredicates.isEmpty()) {
        // interested in the transition with the lowest precedence
        PrecedencePredicate reduced = Collections.min(precedencePredicates);
        operands.add(reduced);
    }

    opnds = operands.toArray(new SemanticContext[operands.size()]);
}
#endif

AntlrSemanticContext *
antlr_and_new_with_context(AntlrSemanticContext *a, AntlrSemanticContext *b)
{
    AntlrAnd *self = g_object_new (ANTLR_TYPE_AND, NULL);

    GHashTable *operands = g_hash_table_new(antlr_semantic_context_hash_code, antlr_semantic_context_equals);
    //GList *operands = NULL;

    if ( ANTLR_IS_AND(a) ) {
        GList *it;
        for (it=g_list_first(ANTLR_AND(a)->opnds); it; it=it->next) {
            //antlr_semantic_context_hash_code(it->data)
            g_hash_table_insert(operands, it->data, it->data);
            //operands = g_list_append(operands, it->data);
        }
        //operands.addAll(Arrays.asList(((AND)a).opnds));
    } else {
        //operands = g_list_append(operands, a);
        g_hash_table_insert(operands, a, a);
        //operands.add(a);
    }

    if ( ANTLR_IS_AND(b) ) {
        GList *it;
        for (it=g_list_first(ANTLR_AND(b)->opnds); it; it=it->next) {
            //antlr_semantic_context_hash_code(it->data)
            g_hash_table_insert(operands, it->data, it->data);
            //operands = g_list_append(operands, it->data);
        }
        //operands.addAll(Arrays.asList(((AND)b).opnds));
    } else {
        //operands = g_list_append(operands, b);
        g_hash_table_insert(operands, b, b);
    }

    GList* precedence_predicates = antlr_semantic_context_filter_precedence_predicates(ANTLR_SEMANTIC_CONTEXT(self), operands);
    if (g_list_length(precedence_predicates)>0) {
        AntlrPrecedencePredicate *reduced = antlr_semantic_context_list_min(precedence_predicates);
        //operands = g_list_append(operands, reduced);
        g_hash_table_insert(operands, reduced, reduced);
    }

    // TODO g_list_free
    self->opnds = NULL;//operands;

    GHashTableIter iter;
    gpointer key, value;
    g_hash_table_iter_init (&iter, operands);
    while (g_hash_table_iter_next (&iter, &key, &value))
      {
        AntlrSemanticContext *context = ANTLR_SEMANTIC_CONTEXT(value);
        self->opnds = g_list_append(self->opnds, (gpointer)context);
      }
//    List<PrecedencePredicate> precedencePredicates = filterPrecedencePredicates(operands);
//    if (!precedencePredicates.isEmpty()) {
//        // interested in the transition with the lowest precedence
//        PrecedencePredicate reduced = Collections.min(precedencePredicates);
//        operands.add(reduced);
//    }

//    opnds = operands.toArray(new SemanticContext[operands.size()]);
    return ANTLR_SEMANTIC_CONTEXT(self);
}


static guint
antlr_and_class_semantic_context_hash_code(AntlrSemanticContext *self) {
    gint class_hash_code = ANTLR_SEMANTIC_CONTEXT_HASH_CODE_OR;
    return antlr_murmur_hash_hash_code(ANTLR_AND(self)->opnds, class_hash_code, antlr_semantic_context_hash_code);
}

//The evaluation of predicates by this context is short-circuiting, but
//unordered.
//gboolean
//antlr_and_eval(AntlrAnd *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack) {
//    for (SemanticContext opnd : opnds) {
//        if ( !opnd.eval(parser, parser_call_stack) ) return false;
//    }
//    return true;
//}


//----------
//----------
//----------

// ----------------------------------------------------------------------------
static gboolean antlr_or_class_semantic_context_equals(AntlrSemanticContext *self, AntlrSemanticContext *o);
static gchar   *antlr_or_class_object_to_string(AntlrSemanticContext *self);

static GList*
antlr_or_get_operands(AntlrOperator *self) {
    return ANTLR_OR(self)->opnds;
}

/**
 * antlr_or_class_semantic_context_eval:
 * @self: Some #AntlrSemanticContext
 * @parser: The parser instance
 * @parser_call_stack: The parser call stack
 *
 * The evaluation of predicates by this context is short-circuiting, but
 * unordered.
 */
static gboolean
antlr_or_class_semantic_context_eval(AntlrSemanticContext*self,
                                      AntlrRecognizer *parser,
                                      AntlrRuleContext *parser_call_stack) {
    AntlrOr *semantic = ANTLR_OR(self);
    GList *it;
    for (it=g_list_first(semantic->opnds); it; it=it->next) {
        AntlrSemanticContext *opnd = it->data;
        if ( antlr_semantic_context_eval(opnd, parser, parser_call_stack) )
            return TRUE;
    }
    return FALSE;
}

static AntlrSemanticContext*
antlr_or_class_semantic_context_eval_precedence(AntlrSemanticContext*self,
                                                 AntlrRecognizer *parser,
                                                 AntlrRuleContext *parser_call_stack) {
    AntlrOr *semantic = ANTLR_OR(self);
    gboolean differs = FALSE;
    GList*/*<SemanticContext>*/ operands = NULL;//new ArrayList<SemanticContext>();
    GList *it;
    for (it=g_list_first(semantic->opnds); it; it=it->next) {
        AntlrSemanticContext *context = it->data;

        AntlrSemanticContext *evaluated = antlr_semantic_context_eval_precedence(context, parser, parser_call_stack);
        differs |= (evaluated != context);
        if (evaluated == antlr_semantic_context_get_none()) {
            // The OR context is true if any element is true
            return antlr_semantic_context_get_none();
        }
        else if (evaluated != NULL) {
            // Reduce the result by skipping false elements
            operands = g_list_append(operands, evaluated);
        }
    }

    if (!differs) {
        return self;
    }


    if (!operands || !g_list_length(operands)) {
        // all elements were false, so the OR context is false
        return NULL;
    }

    it = g_list_first(operands);
    AntlrSemanticContext *result = it->data;
    for (it=it->next; it; it=it->next) {
        result = antlr_semantic_context_or(result, it->data);
    }

    return result;
}
static guint antlr_or_class_semantic_context_hash_code(AntlrSemanticContext *self);
static void antlr_or_class_init(AntlrOrClass *klass);
static void antlr_or_init(AntlrOr *gobject);

G_DEFINE_TYPE (AntlrOr, antlr_or, ANTLR_TYPE_OPERATOR)

static void
antlr_or_class_init(AntlrOrClass *klass)
{
//    GObjectClass *gobject_class;
    AntlrOperatorClass *operator_class;
    AntlrSemanticContextClass *semantic_class;

//    gobject_class = (GObjectClass *) klass;
    operator_class = (AntlrOperatorClass *) klass;
    semantic_class = (AntlrSemanticContextClass *) klass;

    operator_class->get_operands = antlr_or_get_operands;

    semantic_class->eval = antlr_or_class_semantic_context_eval;
    semantic_class->eval_precedence = antlr_or_class_semantic_context_eval_precedence;
    semantic_class->equals = antlr_or_class_semantic_context_equals;
    semantic_class->hash_code = antlr_or_class_semantic_context_hash_code;

    ANTLR_OBJECT_CLASS(klass)->to_string = antlr_or_class_object_to_string;
}

static void
antlr_or_init (AntlrOr *object)
{
}

AntlrSemanticContext *
antlr_or_new (void)
{
    return g_object_new (antlr_or_get_type (),
                         NULL);
}


AntlrSemanticContext*
antlr_or_new_with_context(AntlrSemanticContext *a, AntlrSemanticContext *b)
{
    AntlrAnd *self = g_object_new (ANTLR_TYPE_OR, NULL);

    GHashTable *operands = g_hash_table_new(antlr_semantic_context_hash_code, antlr_semantic_context_equals);
    if ( ANTLR_IS_OR(a) ) {
        GList *it;
        for (it=g_list_first(ANTLR_OR(a)->opnds); it; it=it->next) {
            g_hash_table_insert(operands, it->data, it->data);
        }
    } else {
        g_hash_table_insert(operands, a, a);
    }
    if ( ANTLR_IS_OR(b) ) {
        GList *it;
        for (it=g_list_first(ANTLR_OR(b)->opnds); it; it=it->next) {
            g_hash_table_insert(operands, it->data, it->data);
        }
    } else {
        g_hash_table_insert(operands, b, b);
    }

    GList * precedence_predicates = antlr_semantic_context_filter_precedence_predicates(ANTLR_SEMANTIC_CONTEXT(self), operands);
    if (g_list_length(precedence_predicates)>0) {
        AntlrPrecedencePredicate *reduced = antlr_semantic_context_list_max(precedence_predicates);
        g_hash_table_insert(operands, reduced, reduced);
    }

    self->opnds = NULL;//operands;

    GHashTableIter iter;
    gpointer key, value;
    g_hash_table_iter_init (&iter, operands);
    while (g_hash_table_iter_next (&iter, &key, &value))
      {
        AntlrSemanticContext *context = ANTLR_SEMANTIC_CONTEXT(value);
        self->opnds = g_list_append(self->opnds, (gpointer)context);
      }

    return ANTLR_SEMANTIC_CONTEXT(self);
}

static gboolean
antlr_or_class_semantic_context_equals(AntlrSemanticContext *self, AntlrSemanticContext *o) {
    if ( self==o )
        return TRUE;
    if ( !ANTLR_IS_OR(o) )
        return FALSE;

    return g1_list_equals(ANTLR_OR(self)->opnds, ANTLR_OR(o)->opnds, (GEqualFunc)antlr_semantic_context_equals);
}
static gchar*
antlr_or_class_object_to_string(AntlrSemanticContext *self) {
    gchar *symbol = "||";
    gchar *glue = "";
    GString *str = g_string_new("");
    GList *it;
    for (it = g_list_first(ANTLR_OR(self)->opnds); it; it=it->next) {
        AntlrSemanticContext *context = it->data;
        gchar *tmp = antlr_object_to_string(ANTLR_OBJECT(context));
        g_string_append_printf(str, "%s%s", glue, tmp);
        glue = symbol;
        g_free(tmp);
    }
    g_string_free(str, FALSE);
    return str->str;
}

static guint
antlr_or_class_semantic_context_hash_code(AntlrSemanticContext *self) {
    gint class_hash_code = ANTLR_SEMANTIC_CONTEXT_HASH_CODE_OR;
    return antlr_murmur_hash_hash_code(ANTLR_OR(self)->opnds, class_hash_code, antlr_semantic_context_hash_code);
}
