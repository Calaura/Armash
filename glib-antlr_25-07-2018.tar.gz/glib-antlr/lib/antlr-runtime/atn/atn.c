/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * atn.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"
#include "transition.h"
#include "atn-state.h"
#include "decision-state.h"
#include "rule-stop-state.h"
#include "rule-start-state.h"
#include "lexer-action.h"
#include "ll1-analyzer.h"

#include "../token.h"
#include "../tree/tree.h"
#include "../tree/syntax-tree.h"
#include "../tree/parse-tree.h"
#include "../rule-node.h"
#include "../rule-context.h"
#include "../int-stream.h"
#include "transition.h"
#include "rule-transition.h"

#include "atn.h"


static void antlr_atn_class_init(AntlrATNClass *klass);
static void antlr_atn_init(AntlrATN *gobject);

G_DEFINE_TYPE (AntlrATN, antlr_atn, ANTLR_TYPE_OBJECT)


static void
antlr_atn_class_object_dispose(GObject *object)
{
    //g_print("AntlrATN::dispose\n");

    AntlrATN *self = ANTLR_ATN(object);

    /* TODO: Add deinitalization code here */
    if (self->rule_to_token_type!=NULL) {
        g_array_free(self->rule_to_token_type, TRUE);
        self->rule_to_token_type = NULL;
    }
    if (self->rule_to_start_state!=NULL) {
        //g_ptr_array_set_free_func(self->rule_to_start_state, (GDestroyNotify)g_object_unref);
        g_ptr_array_free(self->rule_to_start_state, TRUE);// free/unref is not call because free_func is NULL. But valgrind shut up fake memory-leaks
        self->rule_to_start_state = NULL;
    }
    if (self->rule_to_stop_state!=NULL) {
        //g_ptr_array_set_free_func(self->rule_to_stop_state, (GDestroyNotify)g_object_unref);
        g_ptr_array_free(self->rule_to_stop_state, TRUE);// free/unref on element is not call because free_func is NULL. But valgrind shut up fake memory-leaks
        self->rule_to_stop_state = NULL;
    }
    if (self->decision_to_state!=NULL) {
        g_list_free(self->decision_to_state);
        self->decision_to_state = NULL;
    }
    if (self->lexer_actions!=NULL) {
        g_ptr_array_set_free_func(self->lexer_actions, (GDestroyNotify)g_object_unref);
        g_ptr_array_free(self->lexer_actions, TRUE);
        //g_array_free(self->rule_to_stop_state, FALSE);
        self->lexer_actions = NULL;
    }
    if (self->mode_to_start_state!=NULL) {
        //g_list_free_full(self->mode_to_start_state, (GDestroyNotify)my_object_unref);
        g_list_free(self->mode_to_start_state);
        self->mode_to_start_state = NULL;
    }
    if (self->states!=NULL) {
        g_list_free_full(self->states, (GDestroyNotify)g_object_unref);
        self->states = NULL;
    }



    G_OBJECT_CLASS (antlr_atn_parent_class)->dispose (object);
}

static void
antlr_atn_class_object_finalize(GObject *object)
{
    /* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (antlr_atn_parent_class)->finalize (object);
}

static void
antlr_atn_class_init(AntlrATNClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = antlr_atn_class_object_finalize;
    gobject_class->dispose = antlr_atn_class_object_dispose;

//	antlr_atn_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_atn_init (AntlrATN *object)
{
    object->rule_to_token_type = NULL;//g_array_new(FALSE, FALSE, sizeof(gint));
    object->decision_to_state = NULL;
}

AntlrATN *
antlr_atn_new (void)
{
    return g_object_new (antlr_atn_get_type (),
                         NULL);
}



/**
 * antlr_atn_new_from_type:
 * @grammar_type: The #AntlrATNType
 * @max_token_type: The token type
 *
 * Used for runtime deserialization of ATNs from strings
 *
 */
AntlrATN *
antlr_atn_new_from_type (AntlrATNType grammar_type, gint max_token_type)
{
    AntlrATN *atn = g_object_new (antlr_atn_get_type (), NULL);
    atn->grammar_type = grammar_type;
    atn->max_token_type = max_token_type;
    return atn;
}

/**
 * antlr_atn_next_tokens:
 * @self: Some #AntlrATN
 * @s: The #AntlrATNState instance
 * @ctx: The #AntlrRuleContext instance
 *
 * Compute the set of valid tokens that can occur starting in state {@code s}.
 *  If {@code ctx} is null, the set of tokens will not include what can follow
 *  the rule surrounding {@code s}. In other words, the set will be
 *  restricted to tokens reachable staying within {@code s}'s rule.
 */
AntlrIntervalSet*
antlr_atn_next_tokens(AntlrATN *self, AntlrATNState *s, AntlrRuleContext *ctx) {
    AntlrLL1Analyzer *anal = antlr_ll1_analyzer_new_with_atn(self);
    AntlrIntervalSet *next = antlr_ll1_analyzer_look(anal, s, ctx);
    g_object_unref(anal);
    return next;
}

/**
 * antlr_atn_next_tokens_from_state:
 * @self: Some #AntlrATN
 * @s: The state
 *
 * Compute the set of valid tokens that can occur starting in @s and
 * staying in same rule. #ANTLR_TOKEN_EPSILON is in set if we reach end of
 * rule.
 *
 */
AntlrIntervalSet* antlr_atn_next_tokens_from_state(AntlrATN *self, AntlrATNState *s) {
    if (s->next_token_within_rule != NULL)
        return s->next_token_within_rule;
    s->next_token_within_rule = antlr_atn_next_tokens(self, s, NULL);
    antlr_interval_set_set_readonly(s->next_token_within_rule, TRUE);
    return s->next_token_within_rule;
}

int
antlr_atn_define_decision_state(AntlrATN *atn, AntlrDecisionState *s) {
    atn->decision_to_state = g_list_append(atn->decision_to_state, s);

    s->decision = g_list_length(atn->decision_to_state)-1;
    return s->decision;
}

AntlrDecisionState*
antlr_atn_get_decision_state(AntlrATN *atn, gint decision) {
    if ( g_list_length(atn->decision_to_state) ) {
        return g_list_nth_data(atn->decision_to_state, decision);
    }
    return NULL;
}
gint
antlr_atn_get_number_of_decisions(AntlrATN *atn) {
    return g_list_length(atn->decision_to_state);
}


void
antlr_atn_add_state(AntlrATN *atn, AntlrATNState *state) {
    if (state != NULL) {
        state->atn = atn;
        state->state_number = g_list_length(atn->states);
    }

    atn->states = g_list_append(atn->states, state);
}




/**
 * antlr_atn_get_expected_tokens:
 * @atn: Some #AntlrATN
 * @state_number: The ATN state number
 * @context: The full parse context
 *
 * Computes the set of input symbols which could follow ATN state number
 * @state_number in the specified full @context. This method
 * considers the complete parser context, but does not evaluate semantic
 * predicates (i.e. all predicates encountered during the calculation are
 * assumed true). If a path in the ATN exists from the starting state to the
 * #AntlrRuleStopState of the outermost context without matching any
 * symbols, #ANTLR_TOKEN_EOF is added to the returned set.
 *
 * If @context is %NULL, it is treated as
 * %ANTLR_RULE_CONTEXT_EMPTY.
 *
 * Returns: The set of potentially valid input symbols which could follow the
 * specified state in the specified context.
 */
AntlrIntervalSet*
antlr_atn_get_expected_tokens(AntlrATN *atn, gint state_number, AntlrRuleContext* context) {// @throws IllegalArgumentException if the ATN does not contain a state with number {@code stateNumber}
    gint size = g_list_length(atn->states);
    if (state_number < 0 || state_number >= size) {
        //throw new IllegalArgumentException("Invalid state number.");
        GError *error = g_error_new(g_quark_from_string("ANTLR"), 500, "IllegalArgument:%s", "Invalid state number.");
        return NULL;
    }

    AntlrRuleContext* ctx = context;
    AntlrATNState* s = g_list_nth_data(atn->states, state_number);
    AntlrIntervalSet* following = antlr_atn_next_tokens_from_state(atn, s);
    if (!antlr_int_iset_contains(ANTLR_INT_ISET(following), ANTLR_TOKEN_EPSILON)) {
        return following;
    }

    AntlrIntervalSet* expected = antlr_interval_set_new();
    antlr_int_iset_add_all(ANTLR_INT_ISET(expected), ANTLR_INT_ISET(following));
    antlr_int_iset_remove(ANTLR_INT_ISET(expected), ANTLR_TOKEN_EPSILON);

    while (ctx!=NULL && ctx->invoking_state >= 0 && antlr_int_iset_contains(ANTLR_INT_ISET(following), ANTLR_TOKEN_EPSILON)) {
        AntlrATNState* invoking_state = g_list_nth_data(atn->states, ctx->invoking_state);
        AntlrTransition *t = antlr_atn_state_transition(invoking_state, 0);
        AntlrRuleTransition *rt = ANTLR_RULE_TRANSITION(t);
        following = antlr_atn_next_tokens_from_state(atn, rt->follow_state);
        antlr_int_iset_add_all(ANTLR_INT_ISET(expected), ANTLR_INT_ISET(following));
        antlr_int_iset_remove(ANTLR_INT_ISET(expected), ANTLR_TOKEN_EPSILON);
        ctx = ctx->parent;
    }

    if (antlr_int_iset_contains(ANTLR_INT_ISET(following), ANTLR_TOKEN_EPSILON)) {
        antlr_int_iset_add(ANTLR_INT_ISET(expected), ANTLR_TOKEN_EOF);
    }

    return expected;
}
