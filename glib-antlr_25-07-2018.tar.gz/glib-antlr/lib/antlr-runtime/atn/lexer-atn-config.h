/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * lexer-atn-config.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_LEXER_ATN_CONFIG_H__
#define __ANTLR_LEXER_ATN_CONFIG_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_LEXER_ATN_CONFIG            (antlr_lexer_atn_config_get_type())
#define ANTLR_LEXER_ATN_CONFIG(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_LEXER_ATN_CONFIG, AntlrLexerATNConfig))
#define ANTLR_LEXER_ATN_CONFIG_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_LEXER_ATN_CONFIG, AntlrLexerATNConfigClass))
#define ANTLR_IS_LEXER_ATN_CONFIG(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_LEXER_ATN_CONFIG))
#define ANTLR_IS_LEXER_ATN_CONFIG_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_LEXER_ATN_CONFIG))
#define ANTLR_LEXER_ATN_CONFIG_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_LEXER_ATN_CONFIG, AntlrLexerATNConfigClass))

typedef struct _AntlrLexerATNConfig AntlrLexerATNConfig;
typedef struct _AntlrLexerATNConfigClass AntlrLexerATNConfigClass;

/**
 * AntlrLexerATNConfig:
 * @lexer_action_executor: This is the backing field for {@link #getLexerActionExecutor}.
 * @passed_through_non_greedy_decision: The passed through non greedy decision
 */
struct _AntlrLexerATNConfig {
    /*< private >*/
    AntlrATNConfig parent_instance;

    /*< public >*/
    AntlrLexerActionExecutor *lexer_action_executor;
    gboolean passed_through_non_greedy_decision;
};

struct _AntlrLexerATNConfigClass {
	AntlrATNConfigClass parent_class;
};

GType antlr_lexer_atn_config_get_type(void)G_GNUC_CONST;
AntlrLexerATNConfig *antlr_lexer_atn_config_new();
AntlrLexerATNConfig *antlr_lexer_atn_config_new_with_prediction(AntlrATNState *state, gint alt, AntlrPredictionContext *context);


AntlrLexerATNConfig *antlr_lexer_atn_config_new_with_config(AntlrLexerATNConfig *c, AntlrATNState *state);
AntlrLexerATNConfig *antlr_lexer_atn_config_new_with_config_and_action(AntlrLexerATNConfig *c, AntlrATNState *state, AntlrLexerActionExecutor *lexer_action_executor);
AntlrLexerATNConfig *antlr_lexer_atn_config_new_with_config_and_prediction(AntlrLexerATNConfig *c, AntlrATNState *state, AntlrPredictionContext *context);

gboolean             antlr_lexer_atn_config_has_passed_through_non_greedy_decision(AntlrLexerATNConfig *self);
AntlrLexerActionExecutor* antlr_lexer_atn_config_get_lexer_action_executor(AntlrLexerATNConfig *config);

G_END_DECLS

#endif /* __ANTLR_LEXER_ATN_CONFIG_H__ */

