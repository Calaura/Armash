/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * semantic-context.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_SEMANTIC_CONTEXT_H__
#define __ANTLR_SEMANTIC_CONTEXT_H__

#include <glib-object.h>


G_BEGIN_DECLS

enum _SemanticContextHashCode{
    ANTLR_SEMANTIC_CONTEXT_HASH_CODE_AND = 17,
    ANTLR_SEMANTIC_CONTEXT_HASH_CODE_OR = 19
};

#define ANTLR_SEMANTIC_CONTEXT_NONE            (antlr_semantic_context_get_none())

#define ANTLR_TYPE_SEMANTIC_CONTEXT            (antlr_semantic_context_get_type())
#define ANTLR_SEMANTIC_CONTEXT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_SEMANTIC_CONTEXT, AntlrSemanticContext))
#define ANTLR_SEMANTIC_CONTEXT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_SEMANTIC_CONTEXT, AntlrSemanticContextClass))
#define ANTLR_IS_SEMANTIC_CONTEXT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_SEMANTIC_CONTEXT))
#define ANTLR_IS_SEMANTIC_CONTEXT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_SEMANTIC_CONTEXT))
#define ANTLR_SEMANTIC_CONTEXT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_SEMANTIC_CONTEXT, AntlrSemanticContextClass))

typedef struct _AntlrSemanticContextClass AntlrSemanticContextClass;

struct _AntlrSemanticContext {
	AntlrObject parent_instance;
};

struct _AntlrSemanticContextClass {
	AntlrObjectClass parent_class;

    guint                       (*hash_code)(AntlrSemanticContext *self);
    gboolean                       (*equals)(AntlrSemanticContext *self, AntlrSemanticContext *o);
    gboolean                         (*eval)(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack);
    AntlrSemanticContext* (*eval_precedence)(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack);
};

GType antlr_semantic_context_get_type(void)G_GNUC_CONST;
//AntlrSemanticContext *antlr_semantic_context_new();
AntlrSemanticContext *antlr_semantic_context_get_none();

gboolean
antlr_semantic_context_eval(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack);
AntlrSemanticContext*
antlr_semantic_context_eval_precedence(AntlrSemanticContext *self, AntlrRecognizer *parser, AntlrRuleContext *parser_call_stack);
GList*
antlr_semantic_context_filter_precedence_predicates(AntlrSemanticContext *self, GHashTable *collection);
AntlrSemanticContext*
antlr_semantic_context_and(AntlrSemanticContext *a, AntlrSemanticContext *b);
AntlrSemanticContext*
antlr_semantic_context_or(AntlrSemanticContext *a, AntlrSemanticContext *b);

gboolean
antlr_semantic_context_equals(AntlrSemanticContext *self, AntlrSemanticContext *o);
guint
antlr_semantic_context_hash_code(AntlrSemanticContext *self);


// ----------------------------------------------------------------------------

#define ANTLR_TYPE_PREDICATE            (antlr_predicate_get_type())
#define ANTLR_PREDICATE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_PREDICATE, AntlrPredicate))
#define ANTLR_PREDICATE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_PREDICATE, AntlrPredicateClass))
#define ANTLR_IS_PREDICATE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_PREDICATE))
#define ANTLR_IS_PREDICATE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_PREDICATE))
#define ANTLR_PREDICATE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_PREDICATE, AntlrPredicateClass))

typedef struct _AntlrPredicateClass AntlrPredicateClass;

struct _AntlrPredicate {
    AntlrSemanticContext parent_instance;

    gint rule_index;
    gint pred_index;
    gboolean is_ctx_dependent;  // e.g., $i ref in pred
};

struct _AntlrPredicateClass {
    AntlrSemanticContextClass parent_class;
};

GType antlr_predicate_get_type(void)G_GNUC_CONST;
AntlrSemanticContext *antlr_predicate_new();
AntlrSemanticContext *antlr_predicate_new_full (gint rule_index,
                                                gint pred_index,
                                                gboolean is_ctx_dependent);
void antlr_semantic_context_none_free();

// ----------------------------------------------------------------------------

#define ANTLR_TYPE_PRECEDENCE_PREDICATE            (antlr_precedence_predicate_get_type())
#define ANTLR_PRECEDENCE_PREDICATE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_PRECEDENCE_PREDICATE, AntlrPrecedencePredicate))
#define ANTLR_PRECEDENCE_PREDICATE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_PRECEDENCE_PREDICATE, AntlrPrecedencePredicateClass))
#define ANTLR_IS_PRECEDENCE_PREDICATE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_PRECEDENCE_PREDICATE))
#define ANTLR_IS_PRECEDENCE_PREDICATE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_PRECEDENCE_PREDICATE))
#define ANTLR_PRECEDENCE_PREDICATE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_PRECEDENCE_PREDICATE, AntlrPrecedencePredicateClass))

typedef struct _AntlrPrecedencePredicateClass AntlrPrecedencePredicateClass;

struct _AntlrPrecedencePredicate {
    AntlrSemanticContext parent_instance;

    gint precedence;
};

struct _AntlrPrecedencePredicateClass {
    AntlrSemanticContextClass parent_class;
};

GType antlr_precedence_predicate_get_type(void)G_GNUC_CONST;
AntlrSemanticContext *antlr_precedence_predicate_new(gint precedence);

// ----------------------------------------------------------------------------

#define ANTLR_TYPE_OPERATOR            (antlr_operator_get_type())
#define ANTLR_OPERATOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_OPERATOR, AntlrOperator))
#define ANTLR_OPERATOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_OPERATOR, AntlrOperatorClass))
#define ANTLR_IS_OPERATOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_OPERATOR))
#define ANTLR_IS_OPERATOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_OPERATOR))
#define ANTLR_OPERATOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_OPERATOR, AntlrOperatorClass))

typedef struct _AntlrOperatorClass AntlrOperatorClass;

/**
 * AntlrOperator:
 *
 * This is the base class for semantic context "operators", which operate on
 * a collection of semantic context "operands".
 *
 */
struct _AntlrOperator {
    AntlrSemanticContext parent_instance;
};

struct _AntlrOperatorClass {
    AntlrSemanticContextClass parent_class;

    GList*   (*get_operands)(AntlrOperator *self);
};

GType antlr_operator_get_type(void)G_GNUC_CONST;
//AntlrSemanticContext *antlr_operator_new();

/**
 * antlr_operator_get_operands:
 * self: Some #AntlrOperator
 *
 * Gets the operands for the semantic context operator.
 *
 * Returns: a collection of #AntlrSemanticContext operands for the
 * operator.
 *
 */
GList* antlr_operator_get_operands(AntlrOperator *self);

// ----------------------------------------------------------------------------
#define ANTLR_TYPE_AND            (antlr_and_get_type())
#define ANTLR_AND(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_AND, AntlrAnd))
#define ANTLR_AND_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_AND, AntlrAndClass))
#define ANTLR_IS_AND(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_AND))
#define ANTLR_IS_AND_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_AND))
#define ANTLR_AND_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_AND, AntlrAndClass))

typedef struct _AntlrAndClass AntlrAndClass;

/**
 * AntlrAnd:
 * @opnds: GList of AntlrSemanticContext
 *
 * This is the base class for semantic context "operators", which operate on
 * a collection of semantic context "operands".
 *
 */
struct _AntlrAnd {
    /*< private >*/
    AntlrOperator parent_instance;

    /*< public >*/
    GList *opnds;// of AntlrSemanticContext*
};

struct _AntlrAndClass {
    AntlrOperatorClass parent_class;

};

GType antlr_and_get_type(void)G_GNUC_CONST;
AntlrSemanticContext *antlr_and_new();
AntlrSemanticContext *antlr_and_new_with_context(AntlrSemanticContext *a, AntlrSemanticContext *b);


// ----------------------------------------------------------------------------
#define ANTLR_TYPE_OR            (antlr_or_get_type())
#define ANTLR_OR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_OR, AntlrOr))
#define ANTLR_OR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_OR, AntlrOrClass))
#define ANTLR_IS_OR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_OR))
#define ANTLR_IS_OR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_OR))
#define ANTLR_OR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_OR, AntlrOrClass))

typedef struct _AntlrOrClass AntlrOrClass;

/**
 * AntlrOr:
 * @opnds: GList of AntlrSemanticContext
 *
 * This is the base class for semantic context "operators", which operate on
 * a collection of semantic context "operands".
 *
 */
struct _AntlrOr {
    /*< private >*/
    AntlrOperator parent_instance;

    /*< public >*/
    GList *opnds;// of AntlrSemanticContext*
};

struct _AntlrOrClass {
    AntlrOperatorClass parent_class;

};

GType antlr_or_get_type(void)G_GNUC_CONST;
AntlrSemanticContext *antlr_or_new();
AntlrSemanticContext *antlr_or_new_with_context(AntlrSemanticContext *a, AntlrSemanticContext *b);


G_END_DECLS

#endif /* __ANTLR_SEMANTIC_CONTEXT_H__ */

