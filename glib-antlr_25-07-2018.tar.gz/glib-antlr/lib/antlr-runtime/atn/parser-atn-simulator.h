/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * parser-atn-simulator.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_PARSER_ATN_SIMULATOR_H__
#define __ANTLR_PARSER_ATN_SIMULATOR_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_PARSER_ATN_SIMULATOR            (antlr_parser_atn_simulator_get_type())
#define ANTLR_PARSER_ATN_SIMULATOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_PARSER_ATN_SIMULATOR, AntlrParserATNSimulator))
#define ANTLR_PARSER_ATN_SIMULATOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_PARSER_ATN_SIMULATOR, AntlrParserATNSimulatorClass))
#define ANTLR_IS_PARSER_ATN_SIMULATOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_PARSER_ATN_SIMULATOR))
#define ANTLR_IS_PARSER_ATN_SIMULATOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_PARSER_ATN_SIMULATOR))
#define ANTLR_PARSER_ATN_SIMULATOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_PARSER_ATN_SIMULATOR, AntlrParserATNSimulatorClass))

typedef struct _AntlrParserATNSimulator AntlrParserATNSimulator;
typedef struct _AntlrParserATNSimulatorClass AntlrParserATNSimulatorClass;


struct _AntlrParserATNSimulator {
	AntlrATNSimulator parent_instance;

    AntlrParser *parser;
    GArray *decision_to_dfa;// of GPtrArray_AntlrDFA

    /*< private >*/
    /** SLL, LL, or LL + exact ambig detection? */
    //AntlrPredictionMode mode;
    // LAME globals to avoid parameters!!!!! I need these down deep in predTransition

    /*< private >*/
     AntlrPredictionMode mode;

    /*< protected >*/
    AntlrDoubleKeyMap *merge_cache;//DoubleKeyMap<PredictionContext,PredictionContext,PredictionContext> mergeCache;
    AntlrTokenStream *input;
    gint start_index;
    AntlrParserRuleContext *outer_context;
    AntlrDFA *dfa;
};

struct _AntlrParserATNSimulatorClass {
	AntlrATNSimulatorClass parent_class;
};

GType antlr_parser_atn_simulator_get_type(void)G_GNUC_CONST;
AntlrParserATNSimulator *antlr_parser_atn_simulator_new();
AntlrParserATNSimulator *antlr_parser_atn_simulator_new_full (AntlrParser *parser,
                                                              AntlrATN *atn,
                                                              GArray *decision_to_dfa,
                                                              AntlrPredictionContextCache *shared_context_cache);//decision_to_dfa: AntlrDFA[]
gint antlr_parser_atn_simulator_adaptive_predict(AntlrParserATNSimulator *self, AntlrTokenStream *input, gint decision, AntlrParserRuleContext *outer_context);

gchar* antlr_parser_atn_simulator_get_rule_name(AntlrParserATNSimulator *self, gint index);
gchar* antlr_parser_atn_simulator_get_token_name(AntlrParserATNSimulator *self, gint t);
gchar* antlr_parser_atn_simulator_get_lookahead_name(AntlrParserATNSimulator *self, AntlrTokenStream *input);

G_END_DECLS

#endif /* __ANTLR_PARSER_ATN_SIMULATOR_H__ */

