/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * atn-state.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"
#include "lexer-action.h"
#include "transition.h"
#include "atn.h"

#include "atn-state.h"

static gint antlr_atn_state_default_hash_code(AntlrATNState *self);
static gboolean antlr_atn_state_default_equals(AntlrATNState *self, GObject *o);
static gchar* antlr_atn_state_class_object_to_string(AntlrObject *object);

static void antlr_atn_state_class_init(AntlrATNStateClass *klass);
static void antlr_atn_state_init(AntlrATNState *gobject);

G_DEFINE_TYPE (AntlrATNState, antlr_atn_state, ANTLR_TYPE_OBJECT)


static void
antlr_atn_state_class_object_dispose(GObject *object)
{
    //g_print("AntlrATNState::dispose\n");

    /* TODO: Add deinitalization code here */
    AntlrATNState *self = ANTLR_ATN_STATE(object);
    if (self->transitions) {
        g_list_free_full(self->transitions, (GDestroyNotify)g_object_unref);
        self->transitions = NULL;
    }
    if (self->next_token_within_rule) {
        g_clear_object(&self->next_token_within_rule);
    }


    G_OBJECT_CLASS (antlr_atn_state_parent_class)->dispose (object);
}

static void
antlr_atn_state_class_object_finalize(GObject *object)
{
    /* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (antlr_atn_state_parent_class)->finalize (object);
}

static void
antlr_atn_state_class_init(AntlrATNStateClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = antlr_atn_state_class_object_finalize;
    gobject_class->dispose = antlr_atn_state_class_object_dispose;


    klass->hash_code = antlr_atn_state_default_hash_code;
    klass->equals    = antlr_atn_state_default_equals;
    ANTLR_OBJECT_CLASS(klass)->to_string = antlr_atn_state_class_object_to_string;

//	antlr_atn_state_parent_class = g_type_class_peek_parent (klass);
}

static gint
antlr_atn_state_default_hash_code(AntlrATNState *self)
{
    return self->state_number;
}
static gboolean
antlr_atn_state_default_equals(AntlrATNState *self, GObject *o) {
    // are these states same object?
    if ( ANTLR_IS_ATN_STATE(o) )
        return self->state_number==ANTLR_ATN_STATE(o)->state_number;
    return FALSE;
}

static gchar*
antlr_atn_state_class_object_to_string(AntlrObject *object) {
    AntlrATNState *self = ANTLR_ATN_STATE(object);
    return g_strdup_printf("%d", self->state_number);
}

static void
antlr_atn_state_init (AntlrATNState *object)
{
    object->atn = NULL;
    object->state_number = ANTLR_ATN_STATE_INVALID_STATE_NUMBER;
    //object->rule_index;
    object->epsilon_only_transitions = FALSE;

    object->transitions = NULL;
}

AntlrATNState *
antlr_atn_state_new (void)
{
	return g_object_new (antlr_atn_state_get_type (),
	                     NULL);
}


gint antlr_atn_state_hash_code(AntlrATNState *self)
{
    g_return_val_if_fail (ANTLR_IS_ATN_STATE (self), 0);

    return ANTLR_ATN_STATE_GET_CLASS(self)->hash_code(self);
}

gboolean
antlr_atn_state_equals(AntlrATNState *self, GObject *o) {
    g_return_val_if_fail (ANTLR_IS_ATN_STATE (self), FALSE);

    return ANTLR_ATN_STATE_GET_CLASS(self)->equals(self, o);
}

gboolean
antlr_atn_state_is_non_greedy_exit_state(AntlrATNState *self) {
    return FALSE;
}


GList* // TODO: toArray
antlr_atn_state_get_transitions(AntlrATNState *self)
{
    return self->transitions;
    //return transitions.toArray(new Transition[transitions.size()]);
}

gint
antlr_atn_state_get_number_of_transitions(AntlrATNState *self)
{
    return g_list_length(self->transitions);
}

void
antlr_atn_state_add_transition(AntlrATNState *self, AntlrTransition *e) {
    gint size = antlr_atn_state_get_number_of_transitions(self);
    antlr_atn_state_add_transition_at(self, size, e);
}

void
antlr_atn_state_add_transition_at(AntlrATNState *self, gint index, AntlrTransition *e) {
    gint size = g_list_length(self->transitions);
    gboolean is_epsilon = antlr_transition_is_epsilon(e);
    if (size==0) {
        self->epsilon_only_transitions = is_epsilon;
    } else if (self->epsilon_only_transitions != is_epsilon) {
        g_print("ATN state %d has both epsilon and non-epsilon transitions.\n", self->state_number);
        self->epsilon_only_transitions = FALSE;
    }

    gboolean already_present = FALSE;
    gboolean t_is_epsilon = FALSE;
    GList *it=NULL;
    for (it=g_list_first(self->transitions); it; it=it->next) {
        AntlrTransition *t = it->data;
        if ( t->target->state_number == e->target->state_number ) {
            AntlrInterval *t_label= antlr_transition_label(t);
            AntlrInterval *e_label= antlr_transition_label(e);
            t_is_epsilon = antlr_transition_is_epsilon(t);
            if ( t_label!=NULL && e_label!=NULL
                 && (t_label->a==e_label->a && t_label->b==e_label->b) ) {
                //					System.err.println("Repeated transition upon "+e.label()+" from "+stateNumber+"->"+t.target.stateNumber);
                already_present = TRUE;
                break;
            } else if ( t_is_epsilon && is_epsilon ) {
                //					System.err.println("Repeated epsilon transition from "+stateNumber+"->"+t.target.stateNumber);
                already_present = TRUE;
                break;
            }
        }
    }
    if ( !already_present ) {
        self->transitions = g_list_insert(self->transitions, e, index);
    }
}


AntlrTransition* antlr_atn_state_transition(AntlrATNState *self, gint i)
{
    return g_list_nth_data(self->transitions, i);
}

void
antlr_atn_state_set_transition(AntlrATNState *self, gint i, AntlrTransition *e)
{
    GList *g_transition = g_list_nth(self->transitions, i);
    g_transition->data = e;
}

AntlrTransition*
antlr_atn_state_remove_transition(AntlrATNState *self, gint i)
{
    GList *link = g_list_nth(self->transitions, i);
    self->transitions = g_list_remove_link(self->transitions, link);
    AntlrTransition *transition = link->data;
    g_list_free(link);
    return transition;
}

gint
antlr_atn_state_get_state_type(AntlrATNState *self)
{
    g_return_val_if_fail (ANTLR_IS_ATN_STATE (self), -1);

    return ANTLR_ATN_STATE_GET_CLASS(self)->get_state_type(self);
}

gboolean
antlr_atn_state_only_has_epsilon_transitions(AntlrATNState *self)
{
    return self->epsilon_only_transitions;
}

void
antlr_atn_state_set_rule_index(AntlrATNState *self, gint rule_index) {
    self->rule_index = rule_index;
}
