/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * atn-simulator.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_ATN_SIMULATOR_H__
#define __ANTLR_ATN_SIMULATOR_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_ATN_SIMULATOR_ERROR           antlr_atn_simulator_get_error()

#define ANTLR_TYPE_ATN_SIMULATOR            (antlr_atn_simulator_get_type())
#define ANTLR_ATN_SIMULATOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_ATN_SIMULATOR, AntlrATNSimulator))
#define ANTLR_ATN_SIMULATOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_ATN_SIMULATOR, AntlrATNSimulatorClass))
#define ANTLR_IS_ATN_SIMULATOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_ATN_SIMULATOR))
#define ANTLR_IS_ATN_SIMULATOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_ATN_SIMULATOR))
#define ANTLR_ATN_SIMULATOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_ATN_SIMULATOR, AntlrATNSimulatorClass))

typedef struct _AntlrATNSimulatorClass AntlrATNSimulatorClass;

/**
 * AntlrATNSimulator:
 * @atn: Must distinguish between missing edge and edge we know leads nowhere
 * @shared_context_cache: The context cache maps all PredictionContext objects that are equals()
 *  to a single cached copy. This cache is shared across all contexts
 *  in all ATNConfigs in all DFA states.  We rebuild each ATNConfigSet
 *  to use only cached nodes/graphs in addDFAState(). We don't want to
 *  fill this during closure() since there are lots of contexts that
 *  pop up but are not used ever again. It also greatly slows down closure().
 *  <p>This cache makes a huge difference in memory and a little bit in speed.
 *  For the Java grammar on java.*, it dropped the memory requirements
 *  at the end from 25M to 16M. We don't store any of the full context
 *  graphs in the DFA because they are limited to local context only,
 *  but apparently there's a lot of repetition there as well. We optimize
 *  the config contexts before storing the config set in the DFA states
 *  by literally rebuilding them with cached subgraphs only.</p>
 *  <p>I tried a cache for use during closure operations, that was
 *  whacked after each adaptivePredict(). It cost a little bit
 *  more time I think and doesn't save on the overall footprint
 *  so it's not worth the complexity.</p>
 */
struct _AntlrATNSimulator {
    /*< private >*/
    AntlrObject parent_instance;

    /*< public >*/
    AntlrATN *atn;
    AntlrPredictionContextCache *shared_context_cache;
};

struct _AntlrATNSimulatorClass {
    AntlrObjectClass parent_class;
    void (*reset)(AntlrATNSimulator *simulator);

    AntlrDFAState *error;
};

GType antlr_atn_simulator_get_type(void)G_GNUC_CONST;
AntlrATNSimulator *antlr_atn_simulator_new();
void               antlr_atn_simulator_super (AntlrATNSimulator *simulator, AntlrATN *atn, AntlrPredictionContextCache *shared_context_cache);
void               antlr_atn_simulator_reset (AntlrATNSimulator *simulator);
AntlrDFAState     *antlr_atn_simulator_get_error();
void               antlr_atn_simulator_error_free();

AntlrPredictionContext     *antlr_atn_simulator_get_cached_context(AntlrATNSimulator *simulator, AntlrPredictionContext *context);


//#define ANTLR_ATN_SIMULATOR_SERIALIZED_VERSION ATNDeserializer.SERIALIZED_VERSION;


G_END_DECLS

#endif /* __ANTLR_ATN_SIMULATOR_H__ */

