/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * empty-prediction-context.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_EMPTY_PREDICTION_CONTEXT_H__
#define __ANTLR_EMPTY_PREDICTION_CONTEXT_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_EMPTY_PREDICTION_CONTEXT            (antlr_empty_prediction_context_get_type())
#define ANTLR_EMPTY_PREDICTION_CONTEXT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_EMPTY_PREDICTION_CONTEXT, AntlrEmptyPredictionContext))
#define ANTLR_EMPTY_PREDICTION_CONTEXT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_EMPTY_PREDICTION_CONTEXT, AntlrEmptyPredictionContextClass))
#define ANTLR_IS_EMPTY_PREDICTION_CONTEXT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_EMPTY_PREDICTION_CONTEXT))
#define ANTLR_IS_EMPTY_PREDICTION_CONTEXT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_EMPTY_PREDICTION_CONTEXT))
#define ANTLR_EMPTY_PREDICTION_CONTEXT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_EMPTY_PREDICTION_CONTEXT, AntlrEmptyPredictionContextClass))

typedef struct _AntlrEmptyPredictionContextClass AntlrEmptyPredictionContextClass;

struct _AntlrEmptyPredictionContext {
	AntlrSingletonPredictionContext parent_instance;
};

struct _AntlrEmptyPredictionContextClass {
	AntlrSingletonPredictionContextClass parent_class;
};

GType antlr_empty_prediction_context_get_type(void)G_GNUC_CONST;
AntlrEmptyPredictionContext *antlr_empty_prediction_context_new();

G_END_DECLS

#endif /* __ANTLR_EMPTY_PREDICTION_CONTEXT_H__ */

