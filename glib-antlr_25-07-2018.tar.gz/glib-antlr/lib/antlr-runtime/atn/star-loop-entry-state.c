/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * star-loop-entry-state.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/int-iset.h"
#include "../misc/interval.h"
#include "../vocabulary.h"
#include "../misc/interval-set.h"
#include "transition.h"
#include "lexer-action.h"
#include "atn-state.h"
#include "rule-stop-state.h"
#include "rule-start-state.h"
#include "atn.h"
#include "decision-state.h"
#include "star-loop-entry-state.h"
#include "star-loopback-state.h"


static void antlr_star_loop_entry_state_class_init(AntlrStarLoopEntryStateClass *klass);
static void antlr_star_loop_entry_state_init(AntlrStarLoopEntryState *gobject);

G_DEFINE_TYPE (AntlrStarLoopEntryState, antlr_star_loop_entry_state, ANTLR_TYPE_DECISION_STATE)

static gint
antlr_star_loop_entry_state_get_state_type(AntlrATNState *state)
{
    return ANTLR_ATN_STATE_STAR_LOOP_ENTRY;
}

static void
antlr_star_loop_entry_state_class_init(AntlrStarLoopEntryStateClass *klass)
{
//    AntlrDecisionStateClass *antlrdecisionstate_class;
    AntlrATNStateClass *antlratnstate_class;

//    antlrdecisionstate_class = (AntlrDecisionStateClass *) klass;
    antlratnstate_class = (AntlrATNStateClass *) klass;

    antlratnstate_class->get_state_type = antlr_star_loop_entry_state_get_state_type;

//	antlr_star_loop_entry_state_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_star_loop_entry_state_init (AntlrStarLoopEntryState *object)
{
}

AntlrStarLoopEntryState *
antlr_star_loop_entry_state_new (void)
{
	return g_object_new (antlr_star_loop_entry_state_get_type (),
	                     NULL);
}
