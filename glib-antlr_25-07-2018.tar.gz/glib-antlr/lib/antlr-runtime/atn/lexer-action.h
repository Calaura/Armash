/*
 * lexer-action.h
 * Copyright (C) 2013 MY_NAME MY.NAME@CONTACT
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_LEXER_ACTION_H__
#define __ANTLR_LEXER_ACTION_H__


#include <glib-object.h>

G_BEGIN_DECLS

/**
 * AntlrLexerActionType:
 * @CHANNEL: The type of a #AntlrLexerChannelAction action.
 * @CUSTOM: The type of a #AntlrLexerCustomAction action.
 * @MODE: The type of a #AntlrLexerModeAction action.
 * @MORE: The type of a #AntlrLexerMoreAction action.
 * @POP_MODE: The type of a #AntlrLexerPopModeAction action.
 * @PUSH_MODE: The type of a #AntlrLexerPushModeAction action.
 * @SKIP: The type of a #AntlrLexerSkipAction action.
 * @TYPE: The type of a #AntlrLexerTypeAction action.
 *
 */
typedef enum _AntlrLexerActionType {
    ANTLR_LEXER_ACTION_TYPE_CHANNEL = 0,
    ANTLR_LEXER_ACTION_TYPE_CUSTOM,
    ANTLR_LEXER_ACTION_TYPE_MODE,
    ANTLR_LEXER_ACTION_TYPE_MORE,
    ANTLR_LEXER_ACTION_TYPE_POP_MODE,
    ANTLR_LEXER_ACTION_TYPE_PUSH_MODE,
    ANTLR_LEXER_ACTION_TYPE_SKIP,
    ANTLR_LEXER_ACTION_TYPE_TYPE
} AntlrLexerActionType;

#define ANTLR_TYPE_LEXER_ACTION                (antlr_lexer_action_get_type ())
#define ANTLR_LEXER_ACTION(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  ANTLR_TYPE_LEXER_ACTION,  AntlrLexerAction))
#define ANTLR_IS_LEXER_ACTION(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  ANTLR_TYPE_LEXER_ACTION))
#define ANTLR_LEXER_ACTION_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  ANTLR_TYPE_LEXER_ACTION,  AntlrLexerActionInterface))


typedef struct _AntlrLexerActionInterface  AntlrLexerActionInterface;

/**
 * AntlrLexerActionInterface:
 * @get_action_type: Gets the serialization type of the lexer action.
 * @is_position_dependent: Gets whether the lexer action is position-dependent.
 * @execute: Execute the lexer action in the context of the specified #AntlrLexer.
 *
 */
struct _AntlrLexerActionInterface
{
    /*< private >*/
	GTypeInterface parent_iface;

    /*< public >*/
    AntlrLexerActionType (*get_action_type)(AntlrLexerAction *self);
    gboolean             (*is_position_dependent)(AntlrLexerAction *self);
    void                 (*execute)(AntlrLexerAction *self, AntlrLexer *lexer);
    gint                 (*hash_code)(AntlrLexerAction *self);
};

GType  antlr_lexer_action_get_type(void)G_GNUC_CONST;

AntlrLexerActionType antlr_lexer_action_get_action_type(AntlrLexerAction *self);
gboolean             antlr_lexer_action_is_position_dependent(AntlrLexerAction *self);
void                 antlr_lexer_action_execute(AntlrLexerAction *self, AntlrLexer *lexer);
gint                 antlr_lexer_action_hash_code(AntlrLexerAction *self);

G_END_DECLS

#endif /* __ANTLR_LEXER_ACTION_H__ */

