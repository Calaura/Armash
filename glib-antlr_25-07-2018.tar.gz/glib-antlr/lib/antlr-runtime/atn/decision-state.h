/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * decision-state.h
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __ANTLR_DECISION_STATE_H__
#define __ANTLR_DECISION_STATE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define ANTLR_TYPE_DECISION_STATE            (antlr_decision_state_get_type())
#define ANTLR_DECISION_STATE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_DECISION_STATE, AntlrDecisionState))
#define ANTLR_DECISION_STATE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), ANTLR_TYPE_DECISION_STATE, AntlrDecisionStateClass))
#define ANTLR_IS_DECISION_STATE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_DECISION_STATE))
#define ANTLR_IS_DECISION_STATE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), ANTLR_TYPE_DECISION_STATE))
#define ANTLR_DECISION_STATE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), ANTLR_TYPE_DECISION_STATE, AntlrDecisionStateClass))

typedef struct _AntlrDecisionStateClass AntlrDecisionStateClass;

/**
 * AntlrDecisionState:
 * @decision: The description of decision
 * @non_greedy: The description of non_greedy
 */
struct _AntlrDecisionState {
    /*< private >*/
    AntlrATNState parent_instance;

    /*< public >*/
    gint decision;
    gboolean non_greedy;
};

struct _AntlrDecisionStateClass {
    AntlrATNStateClass parent_class;
};

GType antlr_decision_state_get_type(void)G_GNUC_CONST;
AntlrDecisionState *antlr_decision_state_new();

G_END_DECLS

#endif /* __ANTLR_DECISION_STATE_H__ */

