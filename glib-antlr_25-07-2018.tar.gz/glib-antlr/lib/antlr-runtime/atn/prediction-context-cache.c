/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * prediction-context-cache.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"

#include "prediction-context.h"
#include "singleton-prediction-context.h"
#include "empty-prediction-context.h"
#include "prediction-context-cache.h"


static void antlr_prediction_context_cache_class_init(AntlrPredictionContextCacheClass *klass);
static void antlr_prediction_context_cache_init(AntlrPredictionContextCache *gobject);

G_DEFINE_TYPE (AntlrPredictionContextCache, antlr_prediction_context_cache, ANTLR_TYPE_OBJECT)


static void
antlr_prediction_context_cache_dispose(GObject *object)
{
    AntlrPredictionContextCache *self = ANTLR_PREDICTION_CONTEXT_CACHE(object);
    g_hash_table_destroy(self->cache);

    G_OBJECT_CLASS (antlr_prediction_context_cache_parent_class)->dispose (object);
}

static void
antlr_prediction_context_cache_finalize(GObject *object)
{
    /* TODO: Add deinitalization code here */

    G_OBJECT_CLASS (antlr_prediction_context_cache_parent_class)->finalize (object);
}

static void
antlr_prediction_context_cache_class_init(AntlrPredictionContextCacheClass *klass)
{
	GObjectClass *gobject_class;

	gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = antlr_prediction_context_cache_finalize;
    gobject_class->dispose = antlr_prediction_context_cache_dispose;

//	antlr_prediction_context_cache_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_prediction_context_cache_init (AntlrPredictionContextCache *object)
{
    object->cache = g_hash_table_new(NULL, NULL);
}

AntlrPredictionContextCache *
antlr_prediction_context_cache_new (void)
{
	return g_object_new (antlr_prediction_context_cache_get_type (),
	                     NULL);
}

/**
 * antlr_prediction_context_cache_add:
 * @self: Some #AntlrPredictionContextCache
 * @ctx: The #AntlrPredictionContext instance
 *
 * Add a context to the cache and return it. If the context already exists,
 *  return that one instead and do not add a new context to the cache.
 *  Protect shared cache from unsafe thread access.
 */
AntlrPredictionContext*
antlr_prediction_context_cache_add(AntlrPredictionContextCache *self, AntlrPredictionContext *ctx) {
    AntlrEmptyPredictionContext *empty = antlr_prediction_context_get_empty();
    if ( ctx==ANTLR_PREDICTION_CONTEXT(empty)) return ANTLR_PREDICTION_CONTEXT(empty);

    AntlrPredictionContext *existing = g_hash_table_lookup(self->cache, (gconstpointer)ctx);
    if ( existing!=NULL ) {
        //gchar *str_existing = antlr_prediction_context_to_string(existing);
        //g_print("%s reuses %s\n", name, str_existing);
        return existing;
    }
    g_hash_table_add(self->cache, ctx);

    return ctx;
}

AntlrPredictionContext *
antlr_prediction_context_cache_get(AntlrPredictionContextCache *self, AntlrPredictionContext *ctx) {
    return g_hash_table_lookup(self->cache, (gconstpointer)ctx);
}

gint
antlr_prediction_context_cache_size(AntlrPredictionContextCache *self) {
    return g_hash_table_size(self->cache);
}
