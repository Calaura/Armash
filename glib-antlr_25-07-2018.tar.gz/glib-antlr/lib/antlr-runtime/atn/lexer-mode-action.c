/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * lexer-mode-action.c
 * Copyright (C) 2014 
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "../types.h"
#include "../misc/object.h"
#include "../misc/integer-list.h"
#include "../misc/integer-stack.h"
#include "../misc/murmur-hash.h"
#include "../vocabulary.h"
#include "../recognizer.h"
#include "../int-stream.h"
#include "../token-factory.h"
#include "../lexer.h"
#include "atn-simulator.h"
#include "lexer-action.h"


#include "lexer-mode-action.h"

static void antlr_lexer_mode_action_interface_lexer_action_init(AntlrLexerActionInterface *iface);

static void antlr_lexer_mode_action_class_init(AntlrLexerModeActionClass *klass);
static void antlr_lexer_mode_action_init(AntlrLexerModeAction *gobject);

G_DEFINE_TYPE_WITH_CODE (AntlrLexerModeAction, antlr_lexer_mode_action, ANTLR_TYPE_OBJECT,
                         G_IMPLEMENT_INTERFACE(ANTLR_TYPE_LEXER_ACTION, antlr_lexer_mode_action_interface_lexer_action_init)
                         )



/**
 * antlr_lexer_indexed_custom_action_interface_lexer_action_get_action_type:
 * @self: Some #AntlrLexerAction
 *
 * Returns: This method returns the result of calling #antlr_lexer_action_get_action_type
 * on the #AntlrLexerAction returned by #antlr_lexer_action_get_action_type.
 */
static AntlrLexerActionType
antlr_lexer_mode_action_interface_lexer_action_get_action_type(AntlrLexerAction *self) {
    return ANTLR_LEXER_ACTION_TYPE_MODE;
}

/**
 * antlr_lexer_mode_action_interface_lexer_action_is_position_dependent:
 * @self: Some #AntlrLexerAction
 *
 * Returns: This method returns %FALSE.
 */
static gboolean
antlr_lexer_mode_action_interface_lexer_action_is_position_dependent(AntlrLexerAction *self) {
    return FALSE;
}

/**
 * antlr_lexer_mode_action_interface_lexer_action_execute:
 * @self: Some #AntlrLexerAction
 * @lexer: The #AntlrLexer instance
 *
 * This action is implemented by calling {@link Lexer#mode} with the
 * value provided by {@link #getMode}.
 */
static void
antlr_lexer_mode_action_interface_lexer_action_execute(AntlrLexerAction *self, AntlrLexer *lexer) {
    gint mode = ANTLR_LEXER_MODE_ACTION(self)->mode;

    // assume the input stream position was properly set by the calling code
    antlr_lexer_mode(lexer, mode);
}


static gint
antlr_lexer_mode_action_interface_lexer_action_hash_code(AntlrLexerAction *lexer_action) {
    AntlrLexerModeAction *self = ANTLR_LEXER_MODE_ACTION(lexer_action);

    gint type_code = antlr_lexer_action_get_action_type(lexer_action);// ANTLR_LEXER_ACTION_TYPE_CUSTOM
    gint hash_code;
    hash_code = antlr_murmur_hash_initialize(ANTLR_MURMUR_HASH_DEFAULT_SEED);
    hash_code = antlr_murmur_hash_update(hash_code, type_code);
    hash_code = antlr_murmur_hash_update(hash_code, self->mode);
    return antlr_murmur_hash_finish(hash_code, 2);
}

static void
antlr_lexer_mode_action_interface_lexer_action_init(AntlrLexerActionInterface *iface)
{
    iface->get_action_type = antlr_lexer_mode_action_interface_lexer_action_get_action_type;
    iface->is_position_dependent = antlr_lexer_mode_action_interface_lexer_action_is_position_dependent;
    iface->execute = antlr_lexer_mode_action_interface_lexer_action_execute;
    iface->hash_code = antlr_lexer_mode_action_interface_lexer_action_hash_code;
}

static void
antlr_lexer_mode_action_class_init(AntlrLexerModeActionClass *klass)
{
//	GObjectClass *gobject_class;

//	gobject_class = (GObjectClass *) klass;

//	antlr_lexer_mode_action_parent_class = g_type_class_peek_parent (klass);
}

static void
antlr_lexer_mode_action_init (AntlrLexerModeAction *object)
{
}

AntlrLexerModeAction *
antlr_lexer_mode_action_new (void)
{
	return g_object_new (antlr_lexer_mode_action_get_type (),
	                     NULL);
}



/**
 * antlr_lexer_mode_action_new_full:
 * @mode: The mode value to pass to {@link Lexer#mode}.
 *
 * Constructs a new {@code mode} action with the specified mode value.
 */
AntlrLexerModeAction *
antlr_lexer_mode_action_new_full (gint mode)
{
    AntlrLexerModeAction *self = g_object_new (ANTLR_TYPE_LEXER_MODE_ACTION, NULL);
    self->mode = mode;

    return self;
}

/**
 * antlr_lexer_mode_action_get_mode:
 * @self: Some #AntlrLexerModeAction
 *
 * Get the lexer mode this action should transition the lexer to.
 *
 * Returns: The lexer mode for this {@code mode} command.
 */
gint
antlr_lexer_mode_action_get_mode(AntlrLexerModeAction *self)
{
    return self->mode;
}
