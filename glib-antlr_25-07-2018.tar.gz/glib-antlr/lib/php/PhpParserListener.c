
// Generated from PhpParser.g4 by ANTLR 4.6



#include <glib-object.h>

#include "antlr-runtime/types.h"

#include "antlr-runtime/misc/object.h"
#include "antlr-runtime/misc/int-iset.h"
#include "antlr-runtime/misc/interval.h"

#include "antlr-runtime/tree/tree.h"
#include "antlr-runtime/tree/syntax-tree.h"
#include "antlr-runtime/tree/parse-tree.h"
#include "antlr-runtime/tree/terminal-node.h"
#include "antlr-runtime/tree/terminal-node-impl.h"
#include "antlr-runtime/tree/error-node.h"
#include "antlr-runtime/tree/error-node-impl.h"
#include "antlr-runtime/tree/parse-tree-listener.h"

#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/tree/tree.h"
#include "antlr-runtime/tree/syntax-tree.h"
#include "antlr-runtime/tree/parse-tree.h"
#include "antlr-runtime/tree/terminal-node.h"
#include "antlr-runtime/tree/error-node.h"
#include "antlr-runtime/tree/parse-tree-listener.h"
#include "antlr-runtime/rule-node.h"
#include "antlr-runtime/rule-context.h"
#include "antlr-runtime/parser-rule-context.h"
#include "antlr-runtime/vocabulary.h"
#include "antlr-runtime/vocabulary-impl.h"
#include "antlr-runtime/recognizer.h"
#include "antlr-runtime/parser.h"


#include "PhpParser.h"
#include "PhpParserListener.h"



G_DEFINE_INTERFACE(MyPhpParserListener, my_php_parser_listener, ANTLR_TYPE_PARSE_TREE_LISTENER)


static void
my_php_parser_listener_default_init(MyPhpParserListenerInterface *iface) {
    /* Add properties and signals to the interface here */
}

/**
 * my_php_parser_listener_enter_html_document:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextHtmlDocument.
 */
void my_php_parser_listener_enter_html_document  (MyPhpParserListener *self, MyContextHtmlDocument *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_html_document(self, ctx);
}
/**
 * my_php_parser_listener_exit_html_document:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextHtmlDocument.
 */
void my_php_parser_listener_exit_html_document   (MyPhpParserListener *self, MyContextHtmlDocument *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_html_document(self, ctx);
}

/**
 * my_php_parser_listener_enter_html_element_or_php_block:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextHtmlElementOrPhpBlock.
 */
void my_php_parser_listener_enter_html_element_or_php_block  (MyPhpParserListener *self, MyContextHtmlElementOrPhpBlock *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_html_element_or_php_block(self, ctx);
}
/**
 * my_php_parser_listener_exit_html_element_or_php_block:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextHtmlElementOrPhpBlock.
 */
void my_php_parser_listener_exit_html_element_or_php_block   (MyPhpParserListener *self, MyContextHtmlElementOrPhpBlock *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_html_element_or_php_block(self, ctx);
}

/**
 * my_php_parser_listener_enter_html_elements:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextHtmlElements.
 */
void my_php_parser_listener_enter_html_elements  (MyPhpParserListener *self, MyContextHtmlElements *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_html_elements(self, ctx);
}
/**
 * my_php_parser_listener_exit_html_elements:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextHtmlElements.
 */
void my_php_parser_listener_exit_html_elements   (MyPhpParserListener *self, MyContextHtmlElements *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_html_elements(self, ctx);
}

/**
 * my_php_parser_listener_enter_html_element:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextHtmlElement.
 */
void my_php_parser_listener_enter_html_element  (MyPhpParserListener *self, MyContextHtmlElement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_html_element(self, ctx);
}
/**
 * my_php_parser_listener_exit_html_element:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextHtmlElement.
 */
void my_php_parser_listener_exit_html_element   (MyPhpParserListener *self, MyContextHtmlElement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_html_element(self, ctx);
}

/**
 * my_php_parser_listener_enter_script_text_part:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextScriptTextPart.
 */
void my_php_parser_listener_enter_script_text_part  (MyPhpParserListener *self, MyContextScriptTextPart *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_script_text_part(self, ctx);
}
/**
 * my_php_parser_listener_exit_script_text_part:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextScriptTextPart.
 */
void my_php_parser_listener_exit_script_text_part   (MyPhpParserListener *self, MyContextScriptTextPart *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_script_text_part(self, ctx);
}

/**
 * my_php_parser_listener_enter_php_block:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextPhpBlock.
 */
void my_php_parser_listener_enter_php_block  (MyPhpParserListener *self, MyContextPhpBlock *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_php_block(self, ctx);
}
/**
 * my_php_parser_listener_exit_php_block:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextPhpBlock.
 */
void my_php_parser_listener_exit_php_block   (MyPhpParserListener *self, MyContextPhpBlock *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_php_block(self, ctx);
}

/**
 * my_php_parser_listener_enter_import_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextImportStatement.
 */
void my_php_parser_listener_enter_import_statement  (MyPhpParserListener *self, MyContextImportStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_import_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_import_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextImportStatement.
 */
void my_php_parser_listener_exit_import_statement   (MyPhpParserListener *self, MyContextImportStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_import_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_top_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTopStatement.
 */
void my_php_parser_listener_enter_top_statement  (MyPhpParserListener *self, MyContextTopStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_top_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_top_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTopStatement.
 */
void my_php_parser_listener_exit_top_statement   (MyPhpParserListener *self, MyContextTopStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_top_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_use_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextUseDeclaration.
 */
void my_php_parser_listener_enter_use_declaration  (MyPhpParserListener *self, MyContextUseDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_use_declaration(self, ctx);
}
/**
 * my_php_parser_listener_exit_use_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextUseDeclaration.
 */
void my_php_parser_listener_exit_use_declaration   (MyPhpParserListener *self, MyContextUseDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_use_declaration(self, ctx);
}

/**
 * my_php_parser_listener_enter_use_declaration_content_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextUseDeclarationContentList.
 */
void my_php_parser_listener_enter_use_declaration_content_list  (MyPhpParserListener *self, MyContextUseDeclarationContentList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_use_declaration_content_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_use_declaration_content_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextUseDeclarationContentList.
 */
void my_php_parser_listener_exit_use_declaration_content_list   (MyPhpParserListener *self, MyContextUseDeclarationContentList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_use_declaration_content_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_use_declaration_content:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextUseDeclarationContent.
 */
void my_php_parser_listener_enter_use_declaration_content  (MyPhpParserListener *self, MyContextUseDeclarationContent *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_use_declaration_content(self, ctx);
}
/**
 * my_php_parser_listener_exit_use_declaration_content:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextUseDeclarationContent.
 */
void my_php_parser_listener_exit_use_declaration_content   (MyPhpParserListener *self, MyContextUseDeclarationContent *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_use_declaration_content(self, ctx);
}

/**
 * my_php_parser_listener_enter_namespace_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextNamespaceDeclaration.
 */
void my_php_parser_listener_enter_namespace_declaration  (MyPhpParserListener *self, MyContextNamespaceDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_namespace_declaration(self, ctx);
}
/**
 * my_php_parser_listener_exit_namespace_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextNamespaceDeclaration.
 */
void my_php_parser_listener_exit_namespace_declaration   (MyPhpParserListener *self, MyContextNamespaceDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_namespace_declaration(self, ctx);
}

/**
 * my_php_parser_listener_enter_namespace_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextNamespaceStatement.
 */
void my_php_parser_listener_enter_namespace_statement  (MyPhpParserListener *self, MyContextNamespaceStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_namespace_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_namespace_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextNamespaceStatement.
 */
void my_php_parser_listener_exit_namespace_statement   (MyPhpParserListener *self, MyContextNamespaceStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_namespace_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_function_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextFunctionDeclaration.
 */
void my_php_parser_listener_enter_function_declaration  (MyPhpParserListener *self, MyContextFunctionDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_function_declaration(self, ctx);
}
/**
 * my_php_parser_listener_exit_function_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextFunctionDeclaration.
 */
void my_php_parser_listener_exit_function_declaration   (MyPhpParserListener *self, MyContextFunctionDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_function_declaration(self, ctx);
}

/**
 * my_php_parser_listener_enter_class_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextClassDeclaration.
 */
void my_php_parser_listener_enter_class_declaration  (MyPhpParserListener *self, MyContextClassDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_class_declaration(self, ctx);
}
/**
 * my_php_parser_listener_exit_class_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextClassDeclaration.
 */
void my_php_parser_listener_exit_class_declaration   (MyPhpParserListener *self, MyContextClassDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_class_declaration(self, ctx);
}

/**
 * my_php_parser_listener_enter_class_entry_type:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextClassEntryType.
 */
void my_php_parser_listener_enter_class_entry_type  (MyPhpParserListener *self, MyContextClassEntryType *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_class_entry_type(self, ctx);
}
/**
 * my_php_parser_listener_exit_class_entry_type:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextClassEntryType.
 */
void my_php_parser_listener_exit_class_entry_type   (MyPhpParserListener *self, MyContextClassEntryType *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_class_entry_type(self, ctx);
}

/**
 * my_php_parser_listener_enter_interface_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextInterfaceList.
 */
void my_php_parser_listener_enter_interface_list  (MyPhpParserListener *self, MyContextInterfaceList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_interface_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_interface_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextInterfaceList.
 */
void my_php_parser_listener_exit_interface_list   (MyPhpParserListener *self, MyContextInterfaceList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_interface_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_type_parameter_list_in_brackets:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTypeParameterListInBrackets.
 */
void my_php_parser_listener_enter_type_parameter_list_in_brackets  (MyPhpParserListener *self, MyContextTypeParameterListInBrackets *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_type_parameter_list_in_brackets(self, ctx);
}
/**
 * my_php_parser_listener_exit_type_parameter_list_in_brackets:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTypeParameterListInBrackets.
 */
void my_php_parser_listener_exit_type_parameter_list_in_brackets   (MyPhpParserListener *self, MyContextTypeParameterListInBrackets *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_type_parameter_list_in_brackets(self, ctx);
}

/**
 * my_php_parser_listener_enter_type_parameter_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTypeParameterList.
 */
void my_php_parser_listener_enter_type_parameter_list  (MyPhpParserListener *self, MyContextTypeParameterList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_type_parameter_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_type_parameter_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTypeParameterList.
 */
void my_php_parser_listener_exit_type_parameter_list   (MyPhpParserListener *self, MyContextTypeParameterList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_type_parameter_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_type_parameter_with_defaults_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTypeParameterWithDefaultsList.
 */
void my_php_parser_listener_enter_type_parameter_with_defaults_list  (MyPhpParserListener *self, MyContextTypeParameterWithDefaultsList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_type_parameter_with_defaults_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_type_parameter_with_defaults_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTypeParameterWithDefaultsList.
 */
void my_php_parser_listener_exit_type_parameter_with_defaults_list   (MyPhpParserListener *self, MyContextTypeParameterWithDefaultsList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_type_parameter_with_defaults_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_type_parameter_decl:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTypeParameterDecl.
 */
void my_php_parser_listener_enter_type_parameter_decl  (MyPhpParserListener *self, MyContextTypeParameterDecl *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_type_parameter_decl(self, ctx);
}
/**
 * my_php_parser_listener_exit_type_parameter_decl:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTypeParameterDecl.
 */
void my_php_parser_listener_exit_type_parameter_decl   (MyPhpParserListener *self, MyContextTypeParameterDecl *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_type_parameter_decl(self, ctx);
}

/**
 * my_php_parser_listener_enter_type_parameter_with_default_decl:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTypeParameterWithDefaultDecl.
 */
void my_php_parser_listener_enter_type_parameter_with_default_decl  (MyPhpParserListener *self, MyContextTypeParameterWithDefaultDecl *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_type_parameter_with_default_decl(self, ctx);
}
/**
 * my_php_parser_listener_exit_type_parameter_with_default_decl:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTypeParameterWithDefaultDecl.
 */
void my_php_parser_listener_exit_type_parameter_with_default_decl   (MyPhpParserListener *self, MyContextTypeParameterWithDefaultDecl *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_type_parameter_with_default_decl(self, ctx);
}

/**
 * my_php_parser_listener_enter_generic_dynamic_args:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextGenericDynamicArgs.
 */
void my_php_parser_listener_enter_generic_dynamic_args  (MyPhpParserListener *self, MyContextGenericDynamicArgs *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_generic_dynamic_args(self, ctx);
}
/**
 * my_php_parser_listener_exit_generic_dynamic_args:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextGenericDynamicArgs.
 */
void my_php_parser_listener_exit_generic_dynamic_args   (MyPhpParserListener *self, MyContextGenericDynamicArgs *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_generic_dynamic_args(self, ctx);
}

/**
 * my_php_parser_listener_enter_attributes:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAttributes.
 */
void my_php_parser_listener_enter_attributes  (MyPhpParserListener *self, MyContextAttributes *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_attributes(self, ctx);
}
/**
 * my_php_parser_listener_exit_attributes:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAttributes.
 */
void my_php_parser_listener_exit_attributes   (MyPhpParserListener *self, MyContextAttributes *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_attributes(self, ctx);
}

/**
 * my_php_parser_listener_enter_attributes_group:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAttributesGroup.
 */
void my_php_parser_listener_enter_attributes_group  (MyPhpParserListener *self, MyContextAttributesGroup *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_attributes_group(self, ctx);
}
/**
 * my_php_parser_listener_exit_attributes_group:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAttributesGroup.
 */
void my_php_parser_listener_exit_attributes_group   (MyPhpParserListener *self, MyContextAttributesGroup *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_attributes_group(self, ctx);
}

/**
 * my_php_parser_listener_enter_attribute:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAttribute.
 */
void my_php_parser_listener_enter_attribute  (MyPhpParserListener *self, MyContextAttribute *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_attribute(self, ctx);
}
/**
 * my_php_parser_listener_exit_attribute:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAttribute.
 */
void my_php_parser_listener_exit_attribute   (MyPhpParserListener *self, MyContextAttribute *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_attribute(self, ctx);
}

/**
 * my_php_parser_listener_enter_attribute_arg_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAttributeArgList.
 */
void my_php_parser_listener_enter_attribute_arg_list  (MyPhpParserListener *self, MyContextAttributeArgList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_attribute_arg_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_attribute_arg_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAttributeArgList.
 */
void my_php_parser_listener_exit_attribute_arg_list   (MyPhpParserListener *self, MyContextAttributeArgList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_attribute_arg_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_attribute_named_arg_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAttributeNamedArgList.
 */
void my_php_parser_listener_enter_attribute_named_arg_list  (MyPhpParserListener *self, MyContextAttributeNamedArgList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_attribute_named_arg_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_attribute_named_arg_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAttributeNamedArgList.
 */
void my_php_parser_listener_exit_attribute_named_arg_list   (MyPhpParserListener *self, MyContextAttributeNamedArgList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_attribute_named_arg_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_attribute_named_arg:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAttributeNamedArg.
 */
void my_php_parser_listener_enter_attribute_named_arg  (MyPhpParserListener *self, MyContextAttributeNamedArg *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_attribute_named_arg(self, ctx);
}
/**
 * my_php_parser_listener_exit_attribute_named_arg:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAttributeNamedArg.
 */
void my_php_parser_listener_exit_attribute_named_arg   (MyPhpParserListener *self, MyContextAttributeNamedArg *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_attribute_named_arg(self, ctx);
}

/**
 * my_php_parser_listener_enter_inner_statement_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextInnerStatementList.
 */
void my_php_parser_listener_enter_inner_statement_list  (MyPhpParserListener *self, MyContextInnerStatementList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_inner_statement_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_inner_statement_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextInnerStatementList.
 */
void my_php_parser_listener_exit_inner_statement_list   (MyPhpParserListener *self, MyContextInnerStatementList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_inner_statement_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_inner_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextInnerStatement.
 */
void my_php_parser_listener_enter_inner_statement  (MyPhpParserListener *self, MyContextInnerStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_inner_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_inner_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextInnerStatement.
 */
void my_php_parser_listener_exit_inner_statement   (MyPhpParserListener *self, MyContextInnerStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_inner_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextStatement.
 */
void my_php_parser_listener_enter_statement  (MyPhpParserListener *self, MyContextStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextStatement.
 */
void my_php_parser_listener_exit_statement   (MyPhpParserListener *self, MyContextStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_empty_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextEmptyStatement.
 */
void my_php_parser_listener_enter_empty_statement  (MyPhpParserListener *self, MyContextEmptyStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_empty_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_empty_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextEmptyStatement.
 */
void my_php_parser_listener_exit_empty_statement   (MyPhpParserListener *self, MyContextEmptyStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_empty_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_block_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextBlockStatement.
 */
void my_php_parser_listener_enter_block_statement  (MyPhpParserListener *self, MyContextBlockStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_block_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_block_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextBlockStatement.
 */
void my_php_parser_listener_exit_block_statement   (MyPhpParserListener *self, MyContextBlockStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_block_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_if_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextIfStatement.
 */
void my_php_parser_listener_enter_if_statement  (MyPhpParserListener *self, MyContextIfStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_if_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_if_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextIfStatement.
 */
void my_php_parser_listener_exit_if_statement   (MyPhpParserListener *self, MyContextIfStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_if_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_else_if_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextElseIfStatement.
 */
void my_php_parser_listener_enter_else_if_statement  (MyPhpParserListener *self, MyContextElseIfStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_else_if_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_else_if_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextElseIfStatement.
 */
void my_php_parser_listener_exit_else_if_statement   (MyPhpParserListener *self, MyContextElseIfStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_else_if_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_else_if_colon_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextElseIfColonStatement.
 */
void my_php_parser_listener_enter_else_if_colon_statement  (MyPhpParserListener *self, MyContextElseIfColonStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_else_if_colon_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_else_if_colon_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextElseIfColonStatement.
 */
void my_php_parser_listener_exit_else_if_colon_statement   (MyPhpParserListener *self, MyContextElseIfColonStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_else_if_colon_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_else_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextElseStatement.
 */
void my_php_parser_listener_enter_else_statement  (MyPhpParserListener *self, MyContextElseStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_else_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_else_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextElseStatement.
 */
void my_php_parser_listener_exit_else_statement   (MyPhpParserListener *self, MyContextElseStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_else_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_else_colon_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextElseColonStatement.
 */
void my_php_parser_listener_enter_else_colon_statement  (MyPhpParserListener *self, MyContextElseColonStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_else_colon_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_else_colon_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextElseColonStatement.
 */
void my_php_parser_listener_exit_else_colon_statement   (MyPhpParserListener *self, MyContextElseColonStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_else_colon_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_while_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextWhileStatement.
 */
void my_php_parser_listener_enter_while_statement  (MyPhpParserListener *self, MyContextWhileStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_while_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_while_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextWhileStatement.
 */
void my_php_parser_listener_exit_while_statement   (MyPhpParserListener *self, MyContextWhileStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_while_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_do_while_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextDoWhileStatement.
 */
void my_php_parser_listener_enter_do_while_statement  (MyPhpParserListener *self, MyContextDoWhileStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_do_while_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_do_while_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextDoWhileStatement.
 */
void my_php_parser_listener_exit_do_while_statement   (MyPhpParserListener *self, MyContextDoWhileStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_do_while_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_for_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextForStatement.
 */
void my_php_parser_listener_enter_for_statement  (MyPhpParserListener *self, MyContextForStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_for_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_for_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextForStatement.
 */
void my_php_parser_listener_exit_for_statement   (MyPhpParserListener *self, MyContextForStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_for_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_for_init:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextForInit.
 */
void my_php_parser_listener_enter_for_init  (MyPhpParserListener *self, MyContextForInit *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_for_init(self, ctx);
}
/**
 * my_php_parser_listener_exit_for_init:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextForInit.
 */
void my_php_parser_listener_exit_for_init   (MyPhpParserListener *self, MyContextForInit *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_for_init(self, ctx);
}

/**
 * my_php_parser_listener_enter_for_update:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextForUpdate.
 */
void my_php_parser_listener_enter_for_update  (MyPhpParserListener *self, MyContextForUpdate *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_for_update(self, ctx);
}
/**
 * my_php_parser_listener_exit_for_update:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextForUpdate.
 */
void my_php_parser_listener_exit_for_update   (MyPhpParserListener *self, MyContextForUpdate *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_for_update(self, ctx);
}

/**
 * my_php_parser_listener_enter_switch_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextSwitchStatement.
 */
void my_php_parser_listener_enter_switch_statement  (MyPhpParserListener *self, MyContextSwitchStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_switch_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_switch_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextSwitchStatement.
 */
void my_php_parser_listener_exit_switch_statement   (MyPhpParserListener *self, MyContextSwitchStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_switch_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_switch_block:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextSwitchBlock.
 */
void my_php_parser_listener_enter_switch_block  (MyPhpParserListener *self, MyContextSwitchBlock *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_switch_block(self, ctx);
}
/**
 * my_php_parser_listener_exit_switch_block:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextSwitchBlock.
 */
void my_php_parser_listener_exit_switch_block   (MyPhpParserListener *self, MyContextSwitchBlock *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_switch_block(self, ctx);
}

/**
 * my_php_parser_listener_enter_break_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextBreakStatement.
 */
void my_php_parser_listener_enter_break_statement  (MyPhpParserListener *self, MyContextBreakStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_break_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_break_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextBreakStatement.
 */
void my_php_parser_listener_exit_break_statement   (MyPhpParserListener *self, MyContextBreakStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_break_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_continue_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextContinueStatement.
 */
void my_php_parser_listener_enter_continue_statement  (MyPhpParserListener *self, MyContextContinueStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_continue_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_continue_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextContinueStatement.
 */
void my_php_parser_listener_exit_continue_statement   (MyPhpParserListener *self, MyContextContinueStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_continue_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_return_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextReturnStatement.
 */
void my_php_parser_listener_enter_return_statement  (MyPhpParserListener *self, MyContextReturnStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_return_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_return_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextReturnStatement.
 */
void my_php_parser_listener_exit_return_statement   (MyPhpParserListener *self, MyContextReturnStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_return_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_expression_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextExpressionStatement.
 */
void my_php_parser_listener_enter_expression_statement  (MyPhpParserListener *self, MyContextExpressionStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_expression_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_expression_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextExpressionStatement.
 */
void my_php_parser_listener_exit_expression_statement   (MyPhpParserListener *self, MyContextExpressionStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_expression_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_unset_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextUnsetStatement.
 */
void my_php_parser_listener_enter_unset_statement  (MyPhpParserListener *self, MyContextUnsetStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_unset_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_unset_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextUnsetStatement.
 */
void my_php_parser_listener_exit_unset_statement   (MyPhpParserListener *self, MyContextUnsetStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_unset_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_foreach_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextForeachStatement.
 */
void my_php_parser_listener_enter_foreach_statement  (MyPhpParserListener *self, MyContextForeachStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_foreach_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_foreach_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextForeachStatement.
 */
void my_php_parser_listener_exit_foreach_statement   (MyPhpParserListener *self, MyContextForeachStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_foreach_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_try_catch_finally:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTryCatchFinally.
 */
void my_php_parser_listener_enter_try_catch_finally  (MyPhpParserListener *self, MyContextTryCatchFinally *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_try_catch_finally(self, ctx);
}
/**
 * my_php_parser_listener_exit_try_catch_finally:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTryCatchFinally.
 */
void my_php_parser_listener_exit_try_catch_finally   (MyPhpParserListener *self, MyContextTryCatchFinally *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_try_catch_finally(self, ctx);
}

/**
 * my_php_parser_listener_enter_catch_clause:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextCatchClause.
 */
void my_php_parser_listener_enter_catch_clause  (MyPhpParserListener *self, MyContextCatchClause *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_catch_clause(self, ctx);
}
/**
 * my_php_parser_listener_exit_catch_clause:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextCatchClause.
 */
void my_php_parser_listener_exit_catch_clause   (MyPhpParserListener *self, MyContextCatchClause *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_catch_clause(self, ctx);
}

/**
 * my_php_parser_listener_enter_finally_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextFinallyStatement.
 */
void my_php_parser_listener_enter_finally_statement  (MyPhpParserListener *self, MyContextFinallyStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_finally_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_finally_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextFinallyStatement.
 */
void my_php_parser_listener_exit_finally_statement   (MyPhpParserListener *self, MyContextFinallyStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_finally_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_throw_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextThrowStatement.
 */
void my_php_parser_listener_enter_throw_statement  (MyPhpParserListener *self, MyContextThrowStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_throw_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_throw_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextThrowStatement.
 */
void my_php_parser_listener_exit_throw_statement   (MyPhpParserListener *self, MyContextThrowStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_throw_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_goto_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextGotoStatement.
 */
void my_php_parser_listener_enter_goto_statement  (MyPhpParserListener *self, MyContextGotoStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_goto_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_goto_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextGotoStatement.
 */
void my_php_parser_listener_exit_goto_statement   (MyPhpParserListener *self, MyContextGotoStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_goto_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_declare_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextDeclareStatement.
 */
void my_php_parser_listener_enter_declare_statement  (MyPhpParserListener *self, MyContextDeclareStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_declare_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_declare_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextDeclareStatement.
 */
void my_php_parser_listener_exit_declare_statement   (MyPhpParserListener *self, MyContextDeclareStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_declare_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_inline_html_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextInlineHtmlStatement.
 */
void my_php_parser_listener_enter_inline_html_statement  (MyPhpParserListener *self, MyContextInlineHtmlStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_inline_html_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_inline_html_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextInlineHtmlStatement.
 */
void my_php_parser_listener_exit_inline_html_statement   (MyPhpParserListener *self, MyContextInlineHtmlStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_inline_html_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_inline_html:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextInlineHtml.
 */
void my_php_parser_listener_enter_inline_html  (MyPhpParserListener *self, MyContextInlineHtml *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_inline_html(self, ctx);
}
/**
 * my_php_parser_listener_exit_inline_html:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextInlineHtml.
 */
void my_php_parser_listener_exit_inline_html   (MyPhpParserListener *self, MyContextInlineHtml *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_inline_html(self, ctx);
}

/**
 * my_php_parser_listener_enter_declare_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextDeclareList.
 */
void my_php_parser_listener_enter_declare_list  (MyPhpParserListener *self, MyContextDeclareList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_declare_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_declare_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextDeclareList.
 */
void my_php_parser_listener_exit_declare_list   (MyPhpParserListener *self, MyContextDeclareList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_declare_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_formal_parameter_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextFormalParameterList.
 */
void my_php_parser_listener_enter_formal_parameter_list  (MyPhpParserListener *self, MyContextFormalParameterList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_formal_parameter_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_formal_parameter_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextFormalParameterList.
 */
void my_php_parser_listener_exit_formal_parameter_list   (MyPhpParserListener *self, MyContextFormalParameterList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_formal_parameter_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_formal_parameter:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextFormalParameter.
 */
void my_php_parser_listener_enter_formal_parameter  (MyPhpParserListener *self, MyContextFormalParameter *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_formal_parameter(self, ctx);
}
/**
 * my_php_parser_listener_exit_formal_parameter:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextFormalParameter.
 */
void my_php_parser_listener_exit_formal_parameter   (MyPhpParserListener *self, MyContextFormalParameter *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_formal_parameter(self, ctx);
}

/**
 * my_php_parser_listener_enter_type_hint:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTypeHint.
 */
void my_php_parser_listener_enter_type_hint  (MyPhpParserListener *self, MyContextTypeHint *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_type_hint(self, ctx);
}
/**
 * my_php_parser_listener_exit_type_hint:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTypeHint.
 */
void my_php_parser_listener_exit_type_hint   (MyPhpParserListener *self, MyContextTypeHint *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_type_hint(self, ctx);
}

/**
 * my_php_parser_listener_enter_global_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextGlobalStatement.
 */
void my_php_parser_listener_enter_global_statement  (MyPhpParserListener *self, MyContextGlobalStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_global_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_global_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextGlobalStatement.
 */
void my_php_parser_listener_exit_global_statement   (MyPhpParserListener *self, MyContextGlobalStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_global_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_global_var:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextGlobalVar.
 */
void my_php_parser_listener_enter_global_var  (MyPhpParserListener *self, MyContextGlobalVar *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_global_var(self, ctx);
}
/**
 * my_php_parser_listener_exit_global_var:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextGlobalVar.
 */
void my_php_parser_listener_exit_global_var   (MyPhpParserListener *self, MyContextGlobalVar *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_global_var(self, ctx);
}

/**
 * my_php_parser_listener_enter_echo_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextEchoStatement.
 */
void my_php_parser_listener_enter_echo_statement  (MyPhpParserListener *self, MyContextEchoStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_echo_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_echo_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextEchoStatement.
 */
void my_php_parser_listener_exit_echo_statement   (MyPhpParserListener *self, MyContextEchoStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_echo_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_static_variable_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextStaticVariableStatement.
 */
void my_php_parser_listener_enter_static_variable_statement  (MyPhpParserListener *self, MyContextStaticVariableStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_static_variable_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_static_variable_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextStaticVariableStatement.
 */
void my_php_parser_listener_exit_static_variable_statement   (MyPhpParserListener *self, MyContextStaticVariableStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_static_variable_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_class_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextClassStatement.
 */
void my_php_parser_listener_enter_class_statement  (MyPhpParserListener *self, MyContextClassStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_class_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_class_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextClassStatement.
 */
void my_php_parser_listener_exit_class_statement   (MyPhpParserListener *self, MyContextClassStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_class_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_trait_adaptations:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTraitAdaptations.
 */
void my_php_parser_listener_enter_trait_adaptations  (MyPhpParserListener *self, MyContextTraitAdaptations *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_trait_adaptations(self, ctx);
}
/**
 * my_php_parser_listener_exit_trait_adaptations:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTraitAdaptations.
 */
void my_php_parser_listener_exit_trait_adaptations   (MyPhpParserListener *self, MyContextTraitAdaptations *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_trait_adaptations(self, ctx);
}

/**
 * my_php_parser_listener_enter_trait_adaptation_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTraitAdaptationStatement.
 */
void my_php_parser_listener_enter_trait_adaptation_statement  (MyPhpParserListener *self, MyContextTraitAdaptationStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_trait_adaptation_statement(self, ctx);
}
/**
 * my_php_parser_listener_exit_trait_adaptation_statement:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTraitAdaptationStatement.
 */
void my_php_parser_listener_exit_trait_adaptation_statement   (MyPhpParserListener *self, MyContextTraitAdaptationStatement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_trait_adaptation_statement(self, ctx);
}

/**
 * my_php_parser_listener_enter_trait_precedence:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTraitPrecedence.
 */
void my_php_parser_listener_enter_trait_precedence  (MyPhpParserListener *self, MyContextTraitPrecedence *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_trait_precedence(self, ctx);
}
/**
 * my_php_parser_listener_exit_trait_precedence:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTraitPrecedence.
 */
void my_php_parser_listener_exit_trait_precedence   (MyPhpParserListener *self, MyContextTraitPrecedence *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_trait_precedence(self, ctx);
}

/**
 * my_php_parser_listener_enter_trait_alias:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTraitAlias.
 */
void my_php_parser_listener_enter_trait_alias  (MyPhpParserListener *self, MyContextTraitAlias *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_trait_alias(self, ctx);
}
/**
 * my_php_parser_listener_exit_trait_alias:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTraitAlias.
 */
void my_php_parser_listener_exit_trait_alias   (MyPhpParserListener *self, MyContextTraitAlias *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_trait_alias(self, ctx);
}

/**
 * my_php_parser_listener_enter_trait_method_reference:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTraitMethodReference.
 */
void my_php_parser_listener_enter_trait_method_reference  (MyPhpParserListener *self, MyContextTraitMethodReference *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_trait_method_reference(self, ctx);
}
/**
 * my_php_parser_listener_exit_trait_method_reference:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTraitMethodReference.
 */
void my_php_parser_listener_exit_trait_method_reference   (MyPhpParserListener *self, MyContextTraitMethodReference *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_trait_method_reference(self, ctx);
}

/**
 * my_php_parser_listener_enter_base_ctor_call:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextBaseCtorCall.
 */
void my_php_parser_listener_enter_base_ctor_call  (MyPhpParserListener *self, MyContextBaseCtorCall *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_base_ctor_call(self, ctx);
}
/**
 * my_php_parser_listener_exit_base_ctor_call:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextBaseCtorCall.
 */
void my_php_parser_listener_exit_base_ctor_call   (MyPhpParserListener *self, MyContextBaseCtorCall *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_base_ctor_call(self, ctx);
}

/**
 * my_php_parser_listener_enter_method_body:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextMethodBody.
 */
void my_php_parser_listener_enter_method_body  (MyPhpParserListener *self, MyContextMethodBody *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_method_body(self, ctx);
}
/**
 * my_php_parser_listener_exit_method_body:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextMethodBody.
 */
void my_php_parser_listener_exit_method_body   (MyPhpParserListener *self, MyContextMethodBody *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_method_body(self, ctx);
}

/**
 * my_php_parser_listener_enter_property_modifiers:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextPropertyModifiers.
 */
void my_php_parser_listener_enter_property_modifiers  (MyPhpParserListener *self, MyContextPropertyModifiers *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_property_modifiers(self, ctx);
}
/**
 * my_php_parser_listener_exit_property_modifiers:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextPropertyModifiers.
 */
void my_php_parser_listener_exit_property_modifiers   (MyPhpParserListener *self, MyContextPropertyModifiers *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_property_modifiers(self, ctx);
}

/**
 * my_php_parser_listener_enter_member_modifiers:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextMemberModifiers.
 */
void my_php_parser_listener_enter_member_modifiers  (MyPhpParserListener *self, MyContextMemberModifiers *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_member_modifiers(self, ctx);
}
/**
 * my_php_parser_listener_exit_member_modifiers:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextMemberModifiers.
 */
void my_php_parser_listener_exit_member_modifiers   (MyPhpParserListener *self, MyContextMemberModifiers *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_member_modifiers(self, ctx);
}

/**
 * my_php_parser_listener_enter_variable_initializer:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextVariableInitializer.
 */
void my_php_parser_listener_enter_variable_initializer  (MyPhpParserListener *self, MyContextVariableInitializer *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_variable_initializer(self, ctx);
}
/**
 * my_php_parser_listener_exit_variable_initializer:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextVariableInitializer.
 */
void my_php_parser_listener_exit_variable_initializer   (MyPhpParserListener *self, MyContextVariableInitializer *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_variable_initializer(self, ctx);
}

/**
 * my_php_parser_listener_enter_identifier_inititalizer:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextIdentifierInititalizer.
 */
void my_php_parser_listener_enter_identifier_inititalizer  (MyPhpParserListener *self, MyContextIdentifierInititalizer *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_identifier_inititalizer(self, ctx);
}
/**
 * my_php_parser_listener_exit_identifier_inititalizer:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextIdentifierInititalizer.
 */
void my_php_parser_listener_exit_identifier_inititalizer   (MyPhpParserListener *self, MyContextIdentifierInititalizer *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_identifier_inititalizer(self, ctx);
}

/**
 * my_php_parser_listener_enter_global_constant_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextGlobalConstantDeclaration.
 */
void my_php_parser_listener_enter_global_constant_declaration  (MyPhpParserListener *self, MyContextGlobalConstantDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_global_constant_declaration(self, ctx);
}
/**
 * my_php_parser_listener_exit_global_constant_declaration:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextGlobalConstantDeclaration.
 */
void my_php_parser_listener_exit_global_constant_declaration   (MyPhpParserListener *self, MyContextGlobalConstantDeclaration *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_global_constant_declaration(self, ctx);
}

/**
 * my_php_parser_listener_enter_expression_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextExpressionList.
 */
void my_php_parser_listener_enter_expression_list  (MyPhpParserListener *self, MyContextExpressionList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_expression_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_expression_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextExpressionList.
 */
void my_php_parser_listener_exit_expression_list   (MyPhpParserListener *self, MyContextExpressionList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_expression_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_parenthesis:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextParenthesis.
 */
void my_php_parser_listener_enter_parenthesis  (MyPhpParserListener *self, MyContextParenthesis *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_parenthesis(self, ctx);
}
/**
 * my_php_parser_listener_exit_parenthesis:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextParenthesis.
 */
void my_php_parser_listener_exit_parenthesis   (MyPhpParserListener *self, MyContextParenthesis *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_parenthesis(self, ctx);
}

/**
 * my_php_parser_listener_enter_chain_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextChainExpression.
 */
void my_php_parser_listener_enter_chain_expression  (MyPhpParserListener *self, MyContextChainExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_chain_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_chain_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextChainExpression.
 */
void my_php_parser_listener_exit_chain_expression   (MyPhpParserListener *self, MyContextChainExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_chain_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_unary_operator_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextUnaryOperatorExpression.
 */
void my_php_parser_listener_enter_unary_operator_expression  (MyPhpParserListener *self, MyContextUnaryOperatorExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_unary_operator_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_unary_operator_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextUnaryOperatorExpression.
 */
void my_php_parser_listener_exit_unary_operator_expression   (MyPhpParserListener *self, MyContextUnaryOperatorExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_unary_operator_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_special_word_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextSpecialWordExpression.
 */
void my_php_parser_listener_enter_special_word_expression  (MyPhpParserListener *self, MyContextSpecialWordExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_special_word_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_special_word_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextSpecialWordExpression.
 */
void my_php_parser_listener_exit_special_word_expression   (MyPhpParserListener *self, MyContextSpecialWordExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_special_word_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_array_creation_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextArrayCreationExpression.
 */
void my_php_parser_listener_enter_array_creation_expression  (MyPhpParserListener *self, MyContextArrayCreationExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_array_creation_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_array_creation_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextArrayCreationExpression.
 */
void my_php_parser_listener_exit_array_creation_expression   (MyPhpParserListener *self, MyContextArrayCreationExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_array_creation_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_new_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextNewExpression.
 */
void my_php_parser_listener_enter_new_expression  (MyPhpParserListener *self, MyContextNewExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_new_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_new_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextNewExpression.
 */
void my_php_parser_listener_exit_new_expression   (MyPhpParserListener *self, MyContextNewExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_new_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_parenthesis_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextParenthesisExpression.
 */
void my_php_parser_listener_enter_parenthesis_expression  (MyPhpParserListener *self, MyContextParenthesisExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_parenthesis_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_parenthesis_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextParenthesisExpression.
 */
void my_php_parser_listener_exit_parenthesis_expression   (MyPhpParserListener *self, MyContextParenthesisExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_parenthesis_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_back_quote_string_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextBackQuoteStringExpression.
 */
void my_php_parser_listener_enter_back_quote_string_expression  (MyPhpParserListener *self, MyContextBackQuoteStringExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_back_quote_string_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_back_quote_string_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextBackQuoteStringExpression.
 */
void my_php_parser_listener_exit_back_quote_string_expression   (MyPhpParserListener *self, MyContextBackQuoteStringExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_back_quote_string_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_conditional_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextConditionalExpression.
 */
void my_php_parser_listener_enter_conditional_expression  (MyPhpParserListener *self, MyContextConditionalExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_conditional_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_conditional_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextConditionalExpression.
 */
void my_php_parser_listener_exit_conditional_expression   (MyPhpParserListener *self, MyContextConditionalExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_conditional_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_arithmetic_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextArithmeticExpression.
 */
void my_php_parser_listener_enter_arithmetic_expression  (MyPhpParserListener *self, MyContextArithmeticExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_arithmetic_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_arithmetic_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextArithmeticExpression.
 */
void my_php_parser_listener_exit_arithmetic_expression   (MyPhpParserListener *self, MyContextArithmeticExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_arithmetic_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_indexer_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextIndexerExpression.
 */
void my_php_parser_listener_enter_indexer_expression  (MyPhpParserListener *self, MyContextIndexerExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_indexer_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_indexer_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextIndexerExpression.
 */
void my_php_parser_listener_exit_indexer_expression   (MyPhpParserListener *self, MyContextIndexerExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_indexer_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_scalar_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextScalarExpression.
 */
void my_php_parser_listener_enter_scalar_expression  (MyPhpParserListener *self, MyContextScalarExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_scalar_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_scalar_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextScalarExpression.
 */
void my_php_parser_listener_exit_scalar_expression   (MyPhpParserListener *self, MyContextScalarExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_scalar_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_prefix_inc_dec_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextPrefixIncDecExpression.
 */
void my_php_parser_listener_enter_prefix_inc_dec_expression  (MyPhpParserListener *self, MyContextPrefixIncDecExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_prefix_inc_dec_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_prefix_inc_dec_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextPrefixIncDecExpression.
 */
void my_php_parser_listener_exit_prefix_inc_dec_expression   (MyPhpParserListener *self, MyContextPrefixIncDecExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_prefix_inc_dec_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_comparison_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextComparisonExpression.
 */
void my_php_parser_listener_enter_comparison_expression  (MyPhpParserListener *self, MyContextComparisonExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_comparison_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_comparison_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextComparisonExpression.
 */
void my_php_parser_listener_exit_comparison_expression   (MyPhpParserListener *self, MyContextComparisonExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_comparison_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_logical_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextLogicalExpression.
 */
void my_php_parser_listener_enter_logical_expression  (MyPhpParserListener *self, MyContextLogicalExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_logical_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_logical_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextLogicalExpression.
 */
void my_php_parser_listener_exit_logical_expression   (MyPhpParserListener *self, MyContextLogicalExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_logical_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_print_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextPrintExpression.
 */
void my_php_parser_listener_enter_print_expression  (MyPhpParserListener *self, MyContextPrintExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_print_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_print_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextPrintExpression.
 */
void my_php_parser_listener_exit_print_expression   (MyPhpParserListener *self, MyContextPrintExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_print_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_assignment_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAssignmentExpression.
 */
void my_php_parser_listener_enter_assignment_expression  (MyPhpParserListener *self, MyContextAssignmentExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_assignment_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_assignment_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAssignmentExpression.
 */
void my_php_parser_listener_exit_assignment_expression   (MyPhpParserListener *self, MyContextAssignmentExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_assignment_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_postfix_inc_dec_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextPostfixIncDecExpression.
 */
void my_php_parser_listener_enter_postfix_inc_dec_expression  (MyPhpParserListener *self, MyContextPostfixIncDecExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_postfix_inc_dec_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_postfix_inc_dec_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextPostfixIncDecExpression.
 */
void my_php_parser_listener_exit_postfix_inc_dec_expression   (MyPhpParserListener *self, MyContextPostfixIncDecExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_postfix_inc_dec_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_cast_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextCastExpression.
 */
void my_php_parser_listener_enter_cast_expression  (MyPhpParserListener *self, MyContextCastExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_cast_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_cast_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextCastExpression.
 */
void my_php_parser_listener_exit_cast_expression   (MyPhpParserListener *self, MyContextCastExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_cast_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_instance_of_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextInstanceOfExpression.
 */
void my_php_parser_listener_enter_instance_of_expression  (MyPhpParserListener *self, MyContextInstanceOfExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_instance_of_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_instance_of_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextInstanceOfExpression.
 */
void my_php_parser_listener_exit_instance_of_expression   (MyPhpParserListener *self, MyContextInstanceOfExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_instance_of_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_lambda_function_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextLambdaFunctionExpression.
 */
void my_php_parser_listener_enter_lambda_function_expression  (MyPhpParserListener *self, MyContextLambdaFunctionExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_lambda_function_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_lambda_function_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextLambdaFunctionExpression.
 */
void my_php_parser_listener_exit_lambda_function_expression   (MyPhpParserListener *self, MyContextLambdaFunctionExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_lambda_function_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_bitwise_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextBitwiseExpression.
 */
void my_php_parser_listener_enter_bitwise_expression  (MyPhpParserListener *self, MyContextBitwiseExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_bitwise_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_bitwise_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextBitwiseExpression.
 */
void my_php_parser_listener_exit_bitwise_expression   (MyPhpParserListener *self, MyContextBitwiseExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_bitwise_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_clone_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextCloneExpression.
 */
void my_php_parser_listener_enter_clone_expression  (MyPhpParserListener *self, MyContextCloneExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_clone_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_clone_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextCloneExpression.
 */
void my_php_parser_listener_exit_clone_expression   (MyPhpParserListener *self, MyContextCloneExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_clone_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_new_expr:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextNewExpr.
 */
void my_php_parser_listener_enter_new_expr  (MyPhpParserListener *self, MyContextNewExpr *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_new_expr(self, ctx);
}
/**
 * my_php_parser_listener_exit_new_expr:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextNewExpr.
 */
void my_php_parser_listener_exit_new_expr   (MyPhpParserListener *self, MyContextNewExpr *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_new_expr(self, ctx);
}

/**
 * my_php_parser_listener_enter_assignment_operator:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAssignmentOperator.
 */
void my_php_parser_listener_enter_assignment_operator  (MyPhpParserListener *self, MyContextAssignmentOperator *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_assignment_operator(self, ctx);
}
/**
 * my_php_parser_listener_exit_assignment_operator:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAssignmentOperator.
 */
void my_php_parser_listener_exit_assignment_operator   (MyPhpParserListener *self, MyContextAssignmentOperator *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_assignment_operator(self, ctx);
}

/**
 * my_php_parser_listener_enter_yield_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextYieldExpression.
 */
void my_php_parser_listener_enter_yield_expression  (MyPhpParserListener *self, MyContextYieldExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_yield_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_yield_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextYieldExpression.
 */
void my_php_parser_listener_exit_yield_expression   (MyPhpParserListener *self, MyContextYieldExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_yield_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_array_item_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextArrayItemList.
 */
void my_php_parser_listener_enter_array_item_list  (MyPhpParserListener *self, MyContextArrayItemList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_array_item_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_array_item_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextArrayItemList.
 */
void my_php_parser_listener_exit_array_item_list   (MyPhpParserListener *self, MyContextArrayItemList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_array_item_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_array_item:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextArrayItem.
 */
void my_php_parser_listener_enter_array_item  (MyPhpParserListener *self, MyContextArrayItem *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_array_item(self, ctx);
}
/**
 * my_php_parser_listener_exit_array_item:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextArrayItem.
 */
void my_php_parser_listener_exit_array_item   (MyPhpParserListener *self, MyContextArrayItem *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_array_item(self, ctx);
}

/**
 * my_php_parser_listener_enter_lambda_function_use_vars:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextLambdaFunctionUseVars.
 */
void my_php_parser_listener_enter_lambda_function_use_vars  (MyPhpParserListener *self, MyContextLambdaFunctionUseVars *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_lambda_function_use_vars(self, ctx);
}
/**
 * my_php_parser_listener_exit_lambda_function_use_vars:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextLambdaFunctionUseVars.
 */
void my_php_parser_listener_exit_lambda_function_use_vars   (MyPhpParserListener *self, MyContextLambdaFunctionUseVars *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_lambda_function_use_vars(self, ctx);
}

/**
 * my_php_parser_listener_enter_lambda_function_use_var:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextLambdaFunctionUseVar.
 */
void my_php_parser_listener_enter_lambda_function_use_var  (MyPhpParserListener *self, MyContextLambdaFunctionUseVar *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_lambda_function_use_var(self, ctx);
}
/**
 * my_php_parser_listener_exit_lambda_function_use_var:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextLambdaFunctionUseVar.
 */
void my_php_parser_listener_exit_lambda_function_use_var   (MyPhpParserListener *self, MyContextLambdaFunctionUseVar *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_lambda_function_use_var(self, ctx);
}

/**
 * my_php_parser_listener_enter_qualified_static_type_ref:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextQualifiedStaticTypeRef.
 */
void my_php_parser_listener_enter_qualified_static_type_ref  (MyPhpParserListener *self, MyContextQualifiedStaticTypeRef *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_qualified_static_type_ref(self, ctx);
}
/**
 * my_php_parser_listener_exit_qualified_static_type_ref:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextQualifiedStaticTypeRef.
 */
void my_php_parser_listener_exit_qualified_static_type_ref   (MyPhpParserListener *self, MyContextQualifiedStaticTypeRef *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_qualified_static_type_ref(self, ctx);
}

/**
 * my_php_parser_listener_enter_type_ref:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextTypeRef.
 */
void my_php_parser_listener_enter_type_ref  (MyPhpParserListener *self, MyContextTypeRef *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_type_ref(self, ctx);
}
/**
 * my_php_parser_listener_exit_type_ref:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextTypeRef.
 */
void my_php_parser_listener_exit_type_ref   (MyPhpParserListener *self, MyContextTypeRef *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_type_ref(self, ctx);
}

/**
 * my_php_parser_listener_enter_indirect_type_ref:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextIndirectTypeRef.
 */
void my_php_parser_listener_enter_indirect_type_ref  (MyPhpParserListener *self, MyContextIndirectTypeRef *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_indirect_type_ref(self, ctx);
}
/**
 * my_php_parser_listener_exit_indirect_type_ref:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextIndirectTypeRef.
 */
void my_php_parser_listener_exit_indirect_type_ref   (MyPhpParserListener *self, MyContextIndirectTypeRef *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_indirect_type_ref(self, ctx);
}

/**
 * my_php_parser_listener_enter_qualified_namespace_name:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextQualifiedNamespaceName.
 */
void my_php_parser_listener_enter_qualified_namespace_name  (MyPhpParserListener *self, MyContextQualifiedNamespaceName *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_qualified_namespace_name(self, ctx);
}
/**
 * my_php_parser_listener_exit_qualified_namespace_name:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextQualifiedNamespaceName.
 */
void my_php_parser_listener_exit_qualified_namespace_name   (MyPhpParserListener *self, MyContextQualifiedNamespaceName *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_qualified_namespace_name(self, ctx);
}

/**
 * my_php_parser_listener_enter_namespace_name_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextNamespaceNameList.
 */
void my_php_parser_listener_enter_namespace_name_list  (MyPhpParserListener *self, MyContextNamespaceNameList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_namespace_name_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_namespace_name_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextNamespaceNameList.
 */
void my_php_parser_listener_exit_namespace_name_list   (MyPhpParserListener *self, MyContextNamespaceNameList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_namespace_name_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_qualified_namespace_name_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextQualifiedNamespaceNameList.
 */
void my_php_parser_listener_enter_qualified_namespace_name_list  (MyPhpParserListener *self, MyContextQualifiedNamespaceNameList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_qualified_namespace_name_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_qualified_namespace_name_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextQualifiedNamespaceNameList.
 */
void my_php_parser_listener_exit_qualified_namespace_name_list   (MyPhpParserListener *self, MyContextQualifiedNamespaceNameList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_qualified_namespace_name_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_arguments:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextArguments.
 */
void my_php_parser_listener_enter_arguments  (MyPhpParserListener *self, MyContextArguments *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_arguments(self, ctx);
}
/**
 * my_php_parser_listener_exit_arguments:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextArguments.
 */
void my_php_parser_listener_exit_arguments   (MyPhpParserListener *self, MyContextArguments *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_arguments(self, ctx);
}

/**
 * my_php_parser_listener_enter_actual_argument:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextActualArgument.
 */
void my_php_parser_listener_enter_actual_argument  (MyPhpParserListener *self, MyContextActualArgument *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_actual_argument(self, ctx);
}
/**
 * my_php_parser_listener_exit_actual_argument:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextActualArgument.
 */
void my_php_parser_listener_exit_actual_argument   (MyPhpParserListener *self, MyContextActualArgument *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_actual_argument(self, ctx);
}

/**
 * my_php_parser_listener_enter_constant_inititalizer:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextConstantInititalizer.
 */
void my_php_parser_listener_enter_constant_inititalizer  (MyPhpParserListener *self, MyContextConstantInititalizer *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_constant_inititalizer(self, ctx);
}
/**
 * my_php_parser_listener_exit_constant_inititalizer:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextConstantInititalizer.
 */
void my_php_parser_listener_exit_constant_inititalizer   (MyPhpParserListener *self, MyContextConstantInititalizer *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_constant_inititalizer(self, ctx);
}

/**
 * my_php_parser_listener_enter_constant_array_item_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextConstantArrayItemList.
 */
void my_php_parser_listener_enter_constant_array_item_list  (MyPhpParserListener *self, MyContextConstantArrayItemList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_constant_array_item_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_constant_array_item_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextConstantArrayItemList.
 */
void my_php_parser_listener_exit_constant_array_item_list   (MyPhpParserListener *self, MyContextConstantArrayItemList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_constant_array_item_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_constant_array_item:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextConstantArrayItem.
 */
void my_php_parser_listener_enter_constant_array_item  (MyPhpParserListener *self, MyContextConstantArrayItem *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_constant_array_item(self, ctx);
}
/**
 * my_php_parser_listener_exit_constant_array_item:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextConstantArrayItem.
 */
void my_php_parser_listener_exit_constant_array_item   (MyPhpParserListener *self, MyContextConstantArrayItem *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_constant_array_item(self, ctx);
}

/**
 * my_php_parser_listener_enter_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextConstant.
 */
void my_php_parser_listener_enter_constant  (MyPhpParserListener *self, MyContextConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_constant(self, ctx);
}
/**
 * my_php_parser_listener_exit_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextConstant.
 */
void my_php_parser_listener_exit_constant   (MyPhpParserListener *self, MyContextConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_constant(self, ctx);
}

/**
 * my_php_parser_listener_enter_literal_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextLiteralConstant.
 */
void my_php_parser_listener_enter_literal_constant  (MyPhpParserListener *self, MyContextLiteralConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_literal_constant(self, ctx);
}
/**
 * my_php_parser_listener_exit_literal_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextLiteralConstant.
 */
void my_php_parser_listener_exit_literal_constant   (MyPhpParserListener *self, MyContextLiteralConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_literal_constant(self, ctx);
}

/**
 * my_php_parser_listener_enter_numeric_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextNumericConstant.
 */
void my_php_parser_listener_enter_numeric_constant  (MyPhpParserListener *self, MyContextNumericConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_numeric_constant(self, ctx);
}
/**
 * my_php_parser_listener_exit_numeric_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextNumericConstant.
 */
void my_php_parser_listener_exit_numeric_constant   (MyPhpParserListener *self, MyContextNumericConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_numeric_constant(self, ctx);
}

/**
 * my_php_parser_listener_enter_class_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextClassConstant.
 */
void my_php_parser_listener_enter_class_constant  (MyPhpParserListener *self, MyContextClassConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_class_constant(self, ctx);
}
/**
 * my_php_parser_listener_exit_class_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextClassConstant.
 */
void my_php_parser_listener_exit_class_constant   (MyPhpParserListener *self, MyContextClassConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_class_constant(self, ctx);
}

/**
 * my_php_parser_listener_enter_string_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextStringConstant.
 */
void my_php_parser_listener_enter_string_constant  (MyPhpParserListener *self, MyContextStringConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_string_constant(self, ctx);
}
/**
 * my_php_parser_listener_exit_string_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextStringConstant.
 */
void my_php_parser_listener_exit_string_constant   (MyPhpParserListener *self, MyContextStringConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_string_constant(self, ctx);
}

/**
 * my_php_parser_listener_enter_string:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextString.
 */
void my_php_parser_listener_enter_string  (MyPhpParserListener *self, MyContextString *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_string(self, ctx);
}
/**
 * my_php_parser_listener_exit_string:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextString.
 */
void my_php_parser_listener_exit_string   (MyPhpParserListener *self, MyContextString *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_string(self, ctx);
}

/**
 * my_php_parser_listener_enter_interpolated_string_part:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextInterpolatedStringPart.
 */
void my_php_parser_listener_enter_interpolated_string_part  (MyPhpParserListener *self, MyContextInterpolatedStringPart *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_interpolated_string_part(self, ctx);
}
/**
 * my_php_parser_listener_exit_interpolated_string_part:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextInterpolatedStringPart.
 */
void my_php_parser_listener_exit_interpolated_string_part   (MyPhpParserListener *self, MyContextInterpolatedStringPart *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_interpolated_string_part(self, ctx);
}

/**
 * my_php_parser_listener_enter_chain_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextChainList.
 */
void my_php_parser_listener_enter_chain_list  (MyPhpParserListener *self, MyContextChainList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_chain_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_chain_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextChainList.
 */
void my_php_parser_listener_exit_chain_list   (MyPhpParserListener *self, MyContextChainList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_chain_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_chain:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextChain.
 */
void my_php_parser_listener_enter_chain  (MyPhpParserListener *self, MyContextChain *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_chain(self, ctx);
}
/**
 * my_php_parser_listener_exit_chain:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextChain.
 */
void my_php_parser_listener_exit_chain   (MyPhpParserListener *self, MyContextChain *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_chain(self, ctx);
}

/**
 * my_php_parser_listener_enter_member_access:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextMemberAccess.
 */
void my_php_parser_listener_enter_member_access  (MyPhpParserListener *self, MyContextMemberAccess *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_member_access(self, ctx);
}
/**
 * my_php_parser_listener_exit_member_access:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextMemberAccess.
 */
void my_php_parser_listener_exit_member_access   (MyPhpParserListener *self, MyContextMemberAccess *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_member_access(self, ctx);
}

/**
 * my_php_parser_listener_enter_function_call:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextFunctionCall.
 */
void my_php_parser_listener_enter_function_call  (MyPhpParserListener *self, MyContextFunctionCall *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_function_call(self, ctx);
}
/**
 * my_php_parser_listener_exit_function_call:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextFunctionCall.
 */
void my_php_parser_listener_exit_function_call   (MyPhpParserListener *self, MyContextFunctionCall *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_function_call(self, ctx);
}

/**
 * my_php_parser_listener_enter_function_call_name:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextFunctionCallName.
 */
void my_php_parser_listener_enter_function_call_name  (MyPhpParserListener *self, MyContextFunctionCallName *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_function_call_name(self, ctx);
}
/**
 * my_php_parser_listener_exit_function_call_name:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextFunctionCallName.
 */
void my_php_parser_listener_exit_function_call_name   (MyPhpParserListener *self, MyContextFunctionCallName *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_function_call_name(self, ctx);
}

/**
 * my_php_parser_listener_enter_actual_arguments:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextActualArguments.
 */
void my_php_parser_listener_enter_actual_arguments  (MyPhpParserListener *self, MyContextActualArguments *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_actual_arguments(self, ctx);
}
/**
 * my_php_parser_listener_exit_actual_arguments:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextActualArguments.
 */
void my_php_parser_listener_exit_actual_arguments   (MyPhpParserListener *self, MyContextActualArguments *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_actual_arguments(self, ctx);
}

/**
 * my_php_parser_listener_enter_chain_base:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextChainBase.
 */
void my_php_parser_listener_enter_chain_base  (MyPhpParserListener *self, MyContextChainBase *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_chain_base(self, ctx);
}
/**
 * my_php_parser_listener_exit_chain_base:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextChainBase.
 */
void my_php_parser_listener_exit_chain_base   (MyPhpParserListener *self, MyContextChainBase *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_chain_base(self, ctx);
}

/**
 * my_php_parser_listener_enter_keyed_field_name:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextKeyedFieldName.
 */
void my_php_parser_listener_enter_keyed_field_name  (MyPhpParserListener *self, MyContextKeyedFieldName *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_keyed_field_name(self, ctx);
}
/**
 * my_php_parser_listener_exit_keyed_field_name:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextKeyedFieldName.
 */
void my_php_parser_listener_exit_keyed_field_name   (MyPhpParserListener *self, MyContextKeyedFieldName *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_keyed_field_name(self, ctx);
}

/**
 * my_php_parser_listener_enter_keyed_simple_field_name:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextKeyedSimpleFieldName.
 */
void my_php_parser_listener_enter_keyed_simple_field_name  (MyPhpParserListener *self, MyContextKeyedSimpleFieldName *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_keyed_simple_field_name(self, ctx);
}
/**
 * my_php_parser_listener_exit_keyed_simple_field_name:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextKeyedSimpleFieldName.
 */
void my_php_parser_listener_exit_keyed_simple_field_name   (MyPhpParserListener *self, MyContextKeyedSimpleFieldName *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_keyed_simple_field_name(self, ctx);
}

/**
 * my_php_parser_listener_enter_keyed_variable:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextKeyedVariable.
 */
void my_php_parser_listener_enter_keyed_variable  (MyPhpParserListener *self, MyContextKeyedVariable *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_keyed_variable(self, ctx);
}
/**
 * my_php_parser_listener_exit_keyed_variable:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextKeyedVariable.
 */
void my_php_parser_listener_exit_keyed_variable   (MyPhpParserListener *self, MyContextKeyedVariable *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_keyed_variable(self, ctx);
}

/**
 * my_php_parser_listener_enter_square_curly_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextSquareCurlyExpression.
 */
void my_php_parser_listener_enter_square_curly_expression  (MyPhpParserListener *self, MyContextSquareCurlyExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_square_curly_expression(self, ctx);
}
/**
 * my_php_parser_listener_exit_square_curly_expression:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextSquareCurlyExpression.
 */
void my_php_parser_listener_exit_square_curly_expression   (MyPhpParserListener *self, MyContextSquareCurlyExpression *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_square_curly_expression(self, ctx);
}

/**
 * my_php_parser_listener_enter_assignment_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAssignmentList.
 */
void my_php_parser_listener_enter_assignment_list  (MyPhpParserListener *self, MyContextAssignmentList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_assignment_list(self, ctx);
}
/**
 * my_php_parser_listener_exit_assignment_list:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAssignmentList.
 */
void my_php_parser_listener_exit_assignment_list   (MyPhpParserListener *self, MyContextAssignmentList *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_assignment_list(self, ctx);
}

/**
 * my_php_parser_listener_enter_assignment_list_element:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextAssignmentListElement.
 */
void my_php_parser_listener_enter_assignment_list_element  (MyPhpParserListener *self, MyContextAssignmentListElement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_assignment_list_element(self, ctx);
}
/**
 * my_php_parser_listener_exit_assignment_list_element:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextAssignmentListElement.
 */
void my_php_parser_listener_exit_assignment_list_element   (MyPhpParserListener *self, MyContextAssignmentListElement *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_assignment_list_element(self, ctx);
}

/**
 * my_php_parser_listener_enter_modifier:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextModifier.
 */
void my_php_parser_listener_enter_modifier  (MyPhpParserListener *self, MyContextModifier *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_modifier(self, ctx);
}
/**
 * my_php_parser_listener_exit_modifier:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextModifier.
 */
void my_php_parser_listener_exit_modifier   (MyPhpParserListener *self, MyContextModifier *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_modifier(self, ctx);
}

/**
 * my_php_parser_listener_enter_identifier:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextIdentifier.
 */
void my_php_parser_listener_enter_identifier  (MyPhpParserListener *self, MyContextIdentifier *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_identifier(self, ctx);
}
/**
 * my_php_parser_listener_exit_identifier:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextIdentifier.
 */
void my_php_parser_listener_exit_identifier   (MyPhpParserListener *self, MyContextIdentifier *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_identifier(self, ctx);
}

/**
 * my_php_parser_listener_enter_member_modifier:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextMemberModifier.
 */
void my_php_parser_listener_enter_member_modifier  (MyPhpParserListener *self, MyContextMemberModifier *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_member_modifier(self, ctx);
}
/**
 * my_php_parser_listener_exit_member_modifier:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextMemberModifier.
 */
void my_php_parser_listener_exit_member_modifier   (MyPhpParserListener *self, MyContextMemberModifier *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_member_modifier(self, ctx);
}

/**
 * my_php_parser_listener_enter_magic_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextMagicConstant.
 */
void my_php_parser_listener_enter_magic_constant  (MyPhpParserListener *self, MyContextMagicConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_magic_constant(self, ctx);
}
/**
 * my_php_parser_listener_exit_magic_constant:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextMagicConstant.
 */
void my_php_parser_listener_exit_magic_constant   (MyPhpParserListener *self, MyContextMagicConstant *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_magic_constant(self, ctx);
}

/**
 * my_php_parser_listener_enter_magic_method:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextMagicMethod.
 */
void my_php_parser_listener_enter_magic_method  (MyPhpParserListener *self, MyContextMagicMethod *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_magic_method(self, ctx);
}
/**
 * my_php_parser_listener_exit_magic_method:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextMagicMethod.
 */
void my_php_parser_listener_exit_magic_method   (MyPhpParserListener *self, MyContextMagicMethod *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_magic_method(self, ctx);
}

/**
 * my_php_parser_listener_enter_primitive_type:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextPrimitiveType.
 */
void my_php_parser_listener_enter_primitive_type  (MyPhpParserListener *self, MyContextPrimitiveType *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_primitive_type(self, ctx);
}
/**
 * my_php_parser_listener_exit_primitive_type:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextPrimitiveType.
 */
void my_php_parser_listener_exit_primitive_type   (MyPhpParserListener *self, MyContextPrimitiveType *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_primitive_type(self, ctx);
}

/**
 * my_php_parser_listener_enter_cast_operation:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Enter a parse tree produced by #MyContextCastOperation.
 */
void my_php_parser_listener_enter_cast_operation  (MyPhpParserListener *self, MyContextCastOperation *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->enter_cast_operation(self, ctx);
}
/**
 * my_php_parser_listener_exit_cast_operation:
 * @self: Some #MyPhpParserListener
 * @ctx: the parse tree instance
 *
 * Exit a parse tree produced by #MyContextCastOperation.
 */
void my_php_parser_listener_exit_cast_operation   (MyPhpParserListener *self, MyContextCastOperation *ctx) {
    g_assert(MY_IS_PHP_PARSER_LISTENER(self));
    MY_PHP_PARSER_LISTENER_GET_INTERFACE(self)->exit_cast_operation(self, ctx);
}






