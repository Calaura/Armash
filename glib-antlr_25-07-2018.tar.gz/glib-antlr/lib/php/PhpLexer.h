
// Generated from PhpLexer.g4 by ANTLR 4.6



#ifndef __MY_PHP_LEXER_H__
#define __MY_PHP_LEXER_H__

#include <glib-object.h>

G_BEGIN_DECLS

typedef enum _MyPhpLexerSymbols  MyPhpLexerSymbols;
typedef enum _MyPhpLexerChannels MyPhpLexerChannels;
typedef enum _MyPhpLexerRules    MyPhpLexerRules;


enum _MyPhpLexerSymbols {
  MY_PHP_LEXER_SYMBOL_SEAWHITESPACE = 1, MY_PHP_LEXER_SYMBOL_HTMLTEXT = 2, 
  MY_PHP_LEXER_SYMBOL_XMLSTART = 3, MY_PHP_LEXER_SYMBOL_PHPSTART = 4, MY_PHP_LEXER_SYMBOL_HTMLSCRIPTOPEN = 5, 
  MY_PHP_LEXER_SYMBOL_HTMLSTYLEOPEN = 6, MY_PHP_LEXER_SYMBOL_HTMLCOMMENT = 7, 
  MY_PHP_LEXER_SYMBOL_HTMLDTD = 8, MY_PHP_LEXER_SYMBOL_HTMLOPEN = 9, MY_PHP_LEXER_SYMBOL_SHEBANG = 10, 
  MY_PHP_LEXER_SYMBOL_ERROR = 11, MY_PHP_LEXER_SYMBOL_XMLTEXT = 12, MY_PHP_LEXER_SYMBOL_XMLCLOSE = 13, 
  MY_PHP_LEXER_SYMBOL_PHPSTARTINSIDE = 14, MY_PHP_LEXER_SYMBOL_HTMLCLOSE = 15, 
  MY_PHP_LEXER_SYMBOL_HTMLSLASHCLOSE = 16, MY_PHP_LEXER_SYMBOL_HTMLSLASH = 17, 
  MY_PHP_LEXER_SYMBOL_HTMLEQUALS = 18, MY_PHP_LEXER_SYMBOL_HTMLSTARTQUOTESTRING = 19, 
  MY_PHP_LEXER_SYMBOL_HTMLSTARTDOUBLEQUOTESTRING = 20, MY_PHP_LEXER_SYMBOL_HTMLHEX = 21, 
  MY_PHP_LEXER_SYMBOL_HTMLDECIMAL = 22, MY_PHP_LEXER_SYMBOL_HTMLSPACE = 23, 
  MY_PHP_LEXER_SYMBOL_HTMLNAME = 24, MY_PHP_LEXER_SYMBOL_ERRORINSIDE = 25, 
  MY_PHP_LEXER_SYMBOL_PHPSTARTINSIDEQUOTESTRING = 26, MY_PHP_LEXER_SYMBOL_HTMLENDQUOTESTRING = 27, 
  MY_PHP_LEXER_SYMBOL_HTMLQUOTESTRING = 28, MY_PHP_LEXER_SYMBOL_ERRORHTMLQUOTE = 29, 
  MY_PHP_LEXER_SYMBOL_PHPSTARTDOUBLEQUOTESTRING = 30, MY_PHP_LEXER_SYMBOL_HTMLENDDOUBLEQUOTESTRING = 31, 
  MY_PHP_LEXER_SYMBOL_HTMLDOUBLEQUOTESTRING = 32, MY_PHP_LEXER_SYMBOL_ERRORHTMLDOUBLEQUOTE = 33, 
  MY_PHP_LEXER_SYMBOL_SCRIPTTEXT = 34, MY_PHP_LEXER_SYMBOL_SCRIPTCLOSE = 35, 
  MY_PHP_LEXER_SYMBOL_PHPSTARTINSIDESCRIPT = 36, MY_PHP_LEXER_SYMBOL_STYLEBODY = 37, 
  MY_PHP_LEXER_SYMBOL_PHPEND = 38, MY_PHP_LEXER_SYMBOL_WHITESPACE = 39, 
  MY_PHP_LEXER_SYMBOL_MULTILINECOMMENT = 40, MY_PHP_LEXER_SYMBOL_SINGLELINECOMMENT = 41, 
  MY_PHP_LEXER_SYMBOL_SHELLSTYLECOMMENT = 42, MY_PHP_LEXER_SYMBOL_ABSTRACT = 43, 
  MY_PHP_LEXER_SYMBOL_ARRAY = 44, MY_PHP_LEXER_SYMBOL_AS = 45, MY_PHP_LEXER_SYMBOL_BINARYCAST = 46, 
  MY_PHP_LEXER_SYMBOL_BOOLTYPE = 47, MY_PHP_LEXER_SYMBOL_BOOLEANCONSTANT = 48, 
  MY_PHP_LEXER_SYMBOL_BREAK = 49, MY_PHP_LEXER_SYMBOL_CALLABLE = 50, MY_PHP_LEXER_SYMBOL_CASE = 51, 
  MY_PHP_LEXER_SYMBOL_CATCH = 52, MY_PHP_LEXER_SYMBOL_CLASS = 53, MY_PHP_LEXER_SYMBOL_CLONE = 54, 
  MY_PHP_LEXER_SYMBOL_CONST = 55, MY_PHP_LEXER_SYMBOL_CONTINUE = 56, MY_PHP_LEXER_SYMBOL_DECLARE = 57, 
  MY_PHP_LEXER_SYMBOL_DEFAULT = 58, MY_PHP_LEXER_SYMBOL_DO = 59, MY_PHP_LEXER_SYMBOL_DOUBLECAST = 60, 
  MY_PHP_LEXER_SYMBOL_DOUBLETYPE = 61, MY_PHP_LEXER_SYMBOL_ECHO = 62, MY_PHP_LEXER_SYMBOL_ELSE = 63, 
  MY_PHP_LEXER_SYMBOL_ELSEIF = 64, MY_PHP_LEXER_SYMBOL_EMPTY = 65, MY_PHP_LEXER_SYMBOL_ENDDECLARE = 66, 
  MY_PHP_LEXER_SYMBOL_ENDFOR = 67, MY_PHP_LEXER_SYMBOL_ENDFOREACH = 68, 
  MY_PHP_LEXER_SYMBOL_ENDIF = 69, MY_PHP_LEXER_SYMBOL_ENDSWITCH = 70, MY_PHP_LEXER_SYMBOL_ENDWHILE = 71, 
  MY_PHP_LEXER_SYMBOL_EVAL = 72, MY_PHP_LEXER_SYMBOL_EXIT = 73, MY_PHP_LEXER_SYMBOL_EXTENDS = 74, 
  MY_PHP_LEXER_SYMBOL_FINAL = 75, MY_PHP_LEXER_SYMBOL_FINALLY = 76, MY_PHP_LEXER_SYMBOL_FLOATCAST = 77, 
  MY_PHP_LEXER_SYMBOL_FOR = 78, MY_PHP_LEXER_SYMBOL_FOREACH = 79, MY_PHP_LEXER_SYMBOL_FUNCTION = 80, 
  MY_PHP_LEXER_SYMBOL_GLOBAL = 81, MY_PHP_LEXER_SYMBOL_GOTO = 82, MY_PHP_LEXER_SYMBOL_IF = 83, 
  MY_PHP_LEXER_SYMBOL_IMPLEMENTS = 84, MY_PHP_LEXER_SYMBOL_IMPORT = 85, 
  MY_PHP_LEXER_SYMBOL_INCLUDE = 86, MY_PHP_LEXER_SYMBOL_INCLUDEONCE = 87, 
  MY_PHP_LEXER_SYMBOL_INSTANCEOF = 88, MY_PHP_LEXER_SYMBOL_INSTEADOF = 89, 
  MY_PHP_LEXER_SYMBOL_INT8CAST = 90, MY_PHP_LEXER_SYMBOL_INT16CAST = 91, 
  MY_PHP_LEXER_SYMBOL_INT64TYPE = 92, MY_PHP_LEXER_SYMBOL_INTTYPE = 93, 
  MY_PHP_LEXER_SYMBOL_INTERFACE = 94, MY_PHP_LEXER_SYMBOL_ISSET = 95, MY_PHP_LEXER_SYMBOL_LIST = 96, 
  MY_PHP_LEXER_SYMBOL_LOGICALAND = 97, MY_PHP_LEXER_SYMBOL_LOGICALOR = 98, 
  MY_PHP_LEXER_SYMBOL_LOGICALXOR = 99, MY_PHP_LEXER_SYMBOL_NAMESPACE = 100, 
  MY_PHP_LEXER_SYMBOL_NEW = 101, MY_PHP_LEXER_SYMBOL_NULL = 102, MY_PHP_LEXER_SYMBOL_OBJECTTYPE = 103, 
  MY_PHP_LEXER_SYMBOL_PARENT_ = 104, MY_PHP_LEXER_SYMBOL_PARTIAL = 105, 
  MY_PHP_LEXER_SYMBOL_PRINT = 106, MY_PHP_LEXER_SYMBOL_PRIVATE = 107, MY_PHP_LEXER_SYMBOL_PROTECTED = 108, 
  MY_PHP_LEXER_SYMBOL_PUBLIC = 109, MY_PHP_LEXER_SYMBOL_REQUIRE = 110, MY_PHP_LEXER_SYMBOL_REQUIREONCE = 111, 
  MY_PHP_LEXER_SYMBOL_RESOURCE = 112, MY_PHP_LEXER_SYMBOL_RETURN = 113, 
  MY_PHP_LEXER_SYMBOL_STATIC = 114, MY_PHP_LEXER_SYMBOL_STRINGTYPE = 115, 
  MY_PHP_LEXER_SYMBOL_SWITCH = 116, MY_PHP_LEXER_SYMBOL_THROW = 117, MY_PHP_LEXER_SYMBOL_TRAIT = 118, 
  MY_PHP_LEXER_SYMBOL_TRY = 119, MY_PHP_LEXER_SYMBOL_TYPEOF = 120, MY_PHP_LEXER_SYMBOL_UINTCAST = 121, 
  MY_PHP_LEXER_SYMBOL_UNICODECAST = 122, MY_PHP_LEXER_SYMBOL_UNSET = 123, 
  MY_PHP_LEXER_SYMBOL_USE = 124, MY_PHP_LEXER_SYMBOL_VAR = 125, MY_PHP_LEXER_SYMBOL_WHILE = 126, 
  MY_PHP_LEXER_SYMBOL_YIELD = 127, MY_PHP_LEXER_SYMBOL_GET = 128, MY_PHP_LEXER_SYMBOL_SET = 129, 
  MY_PHP_LEXER_SYMBOL_CALL = 130, MY_PHP_LEXER_SYMBOL_CALLSTATIC = 131, 
  MY_PHP_LEXER_SYMBOL_CONSTRUCTOR = 132, MY_PHP_LEXER_SYMBOL_DESTRUCT = 133, 
  MY_PHP_LEXER_SYMBOL_WAKEUP = 134, MY_PHP_LEXER_SYMBOL_SLEEP = 135, MY_PHP_LEXER_SYMBOL_AUTOLOAD = 136, 
  MY_PHP_LEXER_SYMBOL_ISSET__ = 137, MY_PHP_LEXER_SYMBOL_UNSET__ = 138, 
  MY_PHP_LEXER_SYMBOL_TOSTRING__ = 139, MY_PHP_LEXER_SYMBOL_INVOKE = 140, 
  MY_PHP_LEXER_SYMBOL_SETSTATE = 141, MY_PHP_LEXER_SYMBOL_CLONE__ = 142, 
  MY_PHP_LEXER_SYMBOL_DEBUGINFO = 143, MY_PHP_LEXER_SYMBOL_NAMESPACE__ = 144, 
  MY_PHP_LEXER_SYMBOL_CLASS__ = 145, MY_PHP_LEXER_SYMBOL_TRAIC__ = 146, 
  MY_PHP_LEXER_SYMBOL_FUNCTION__ = 147, MY_PHP_LEXER_SYMBOL_METHOD__ = 148, 
  MY_PHP_LEXER_SYMBOL_LINE__ = 149, MY_PHP_LEXER_SYMBOL_FILE__ = 150, MY_PHP_LEXER_SYMBOL_DIR__ = 151, 
  MY_PHP_LEXER_SYMBOL_LGENERIC = 152, MY_PHP_LEXER_SYMBOL_RGENERIC = 153, 
  MY_PHP_LEXER_SYMBOL_DOUBLEARROW = 154, MY_PHP_LEXER_SYMBOL_INC = 155, 
  MY_PHP_LEXER_SYMBOL_DEC = 156, MY_PHP_LEXER_SYMBOL_ISIDENTICAL = 157, 
  MY_PHP_LEXER_SYMBOL_ISNOIDENTICAL = 158, MY_PHP_LEXER_SYMBOL_ISEQUAL = 159, 
  MY_PHP_LEXER_SYMBOL_ISNOTEQ = 160, MY_PHP_LEXER_SYMBOL_ISSMALLEROREQUAL = 161, 
  MY_PHP_LEXER_SYMBOL_ISGREATEROREQUAL = 162, MY_PHP_LEXER_SYMBOL_PLUSEQUAL = 163, 
  MY_PHP_LEXER_SYMBOL_MINUSEQUAL = 164, MY_PHP_LEXER_SYMBOL_MULEQUAL = 165, 
  MY_PHP_LEXER_SYMBOL_POW = 166, MY_PHP_LEXER_SYMBOL_POWEQUAL = 167, MY_PHP_LEXER_SYMBOL_DIVEQUAL = 168, 
  MY_PHP_LEXER_SYMBOL_CONCAEQUAL = 169, MY_PHP_LEXER_SYMBOL_MODEQUAL = 170, 
  MY_PHP_LEXER_SYMBOL_SHIFTLEFTEQUAL = 171, MY_PHP_LEXER_SYMBOL_SHIFTRIGHTEQUAL = 172, 
  MY_PHP_LEXER_SYMBOL_ANDEQUAL = 173, MY_PHP_LEXER_SYMBOL_OREQUAL = 174, 
  MY_PHP_LEXER_SYMBOL_XOREQUAL = 175, MY_PHP_LEXER_SYMBOL_BOOLEANOR = 176, 
  MY_PHP_LEXER_SYMBOL_BOOLEANAND = 177, MY_PHP_LEXER_SYMBOL_SHIFTLEFT = 178, 
  MY_PHP_LEXER_SYMBOL_SHIFTRIGHT = 179, MY_PHP_LEXER_SYMBOL_DOUBLECOLON = 180, 
  MY_PHP_LEXER_SYMBOL_OBJECTOPERATOR = 181, MY_PHP_LEXER_SYMBOL_NAMESPACESEPARATOR = 182, 
  MY_PHP_LEXER_SYMBOL_ELLIPSIS = 183, MY_PHP_LEXER_SYMBOL_LESS = 184, MY_PHP_LEXER_SYMBOL_GREATER = 185, 
  MY_PHP_LEXER_SYMBOL_AMPERSAND = 186, MY_PHP_LEXER_SYMBOL_PIPE = 187, MY_PHP_LEXER_SYMBOL_BANG = 188, 
  MY_PHP_LEXER_SYMBOL_CARET = 189, MY_PHP_LEXER_SYMBOL_PLUS = 190, MY_PHP_LEXER_SYMBOL_MINUS = 191, 
  MY_PHP_LEXER_SYMBOL_ASTERISK = 192, MY_PHP_LEXER_SYMBOL_PERCENT = 193, 
  MY_PHP_LEXER_SYMBOL_DIVIDE = 194, MY_PHP_LEXER_SYMBOL_TILDE = 195, MY_PHP_LEXER_SYMBOL_SUPPRESSWARNINGS = 196, 
  MY_PHP_LEXER_SYMBOL_DOLLAR = 197, MY_PHP_LEXER_SYMBOL_DOT = 198, MY_PHP_LEXER_SYMBOL_QUESTIONMARK = 199, 
  MY_PHP_LEXER_SYMBOL_OPENROUNDBRACKET = 200, MY_PHP_LEXER_SYMBOL_CLOSEROUNDBRACKET = 201, 
  MY_PHP_LEXER_SYMBOL_OPENSQUAREBRACKET = 202, MY_PHP_LEXER_SYMBOL_CLOSESQUAREBRACKET = 203, 
  MY_PHP_LEXER_SYMBOL_OPENCURLYBRACKET = 204, MY_PHP_LEXER_SYMBOL_CLOSECURLYBRACKET = 205, 
  MY_PHP_LEXER_SYMBOL_COMMA = 206, MY_PHP_LEXER_SYMBOL_COLON = 207, MY_PHP_LEXER_SYMBOL_SEMICOLON = 208, 
  MY_PHP_LEXER_SYMBOL_EQ = 209, MY_PHP_LEXER_SYMBOL_QUOTE = 210, MY_PHP_LEXER_SYMBOL_BACKQUOTE = 211, 
  MY_PHP_LEXER_SYMBOL_VARNAME = 212, MY_PHP_LEXER_SYMBOL_LABEL = 213, MY_PHP_LEXER_SYMBOL_OCTAL = 214, 
  MY_PHP_LEXER_SYMBOL_DECIMAL = 215, MY_PHP_LEXER_SYMBOL_REAL = 216, MY_PHP_LEXER_SYMBOL_HEX = 217, 
  MY_PHP_LEXER_SYMBOL_BINARY = 218, MY_PHP_LEXER_SYMBOL_BACKQUOTESTRING = 219, 
  MY_PHP_LEXER_SYMBOL_SINGLEQUOTESTRING = 220, MY_PHP_LEXER_SYMBOL_DOUBLEQUOTE = 221, 
  MY_PHP_LEXER_SYMBOL_STARTNOWDOC = 222, MY_PHP_LEXER_SYMBOL_STARTHEREDOC = 223, 
  MY_PHP_LEXER_SYMBOL_ERRORPHP = 224, MY_PHP_LEXER_SYMBOL_CURLYDOLLAR = 225, 
  MY_PHP_LEXER_SYMBOL_STRINGPART = 226, MY_PHP_LEXER_SYMBOL_COMMENT = 227, 
  MY_PHP_LEXER_SYMBOL_PHPENDSINGLELINECOMMENT = 228, MY_PHP_LEXER_SYMBOL_COMMENTEND = 229, 
  MY_PHP_LEXER_SYMBOL_HEREDOCTEXT = 230, MY_PHP_LEXER_SYMBOL_XMLTEXT2 = 231
};

enum _MyPhpLexerChannels {
  MY_PHP_LEXER_CHANNEL_PHPCOMMENTS = 2, MY_PHP_LEXER_CHANNEL_ERRORLEXEM = 3, 
  MY_PHP_LEXER_CHANNEL_SKIP = 4
};

enum _MyPhpLexerRules {
  MY_PHP_LEXER_RULE_XML = 1,
  MY_PHP_LEXER_RULE_INSIDE = 2,
  MY_PHP_LEXER_RULE_HTMLQUOTESTRINGMODE = 3,
  MY_PHP_LEXER_RULE_HTMLDOUBLEQUOTESTRINGMODE = 4,
  MY_PHP_LEXER_RULE_SCRIPT = 5,
  MY_PHP_LEXER_RULE_STYLE = 6,
  MY_PHP_LEXER_RULE_PHP = 7,
  MY_PHP_LEXER_RULE_INTERPOLATIONSTRING = 8,
  MY_PHP_LEXER_RULE_SINGLELINECOMMENTMODE = 9,
  MY_PHP_LEXER_RULE_HEREDOC = 10,
};



#define MY_TYPE_PHP_LEXER            (my_php_lexer_get_type())
#define MY_PHP_LEXER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_PHP_LEXER, MyPhpLexer))
#define MY_PHP_LEXER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_PHP_LEXER, MyPhpLexerClass))
#define MY_IS_PHP_LEXER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_PHP_LEXER))
#define MY_IS_PHP_LEXER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_PHP_LEXER))
#define MY_PHP_LEXER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_PHP_LEXER, MyPhpLexerClass))

typedef struct _MyPhpLexer      MyPhpLexer;
typedef struct _MyPhpLexerClass MyPhpLexerClass;

struct _MyPhpLexer {
    /*< private >*/
    PhpLexerBase parent_instance;

    /*< public >*/

    #if 0
    public boolean AspTags = true;
    boolean _scriptTag;
    boolean _styleTag;
    String _heredocIdentifier;
    int _prevTokenType;
    String _htmlNameText;
    boolean _phpScript;
    boolean _insideString;
    @Override
    public Token nextToken()
    {
        CommonToken token = (CommonToken)super.nextToken();
        if (token.getType() == PHPEnd || token.getType() == PHPEndSingleLineComment)
        {
            if (_mode == SingleLineCommentMode)
            {
                // SingleLineCommentMode for such allowed syntax:
                // <?php echo "Hello world"; // comment ?>
                popMode(); // exit from SingleLineComment mode.
            }
            popMode(); // exit from PHP mode.

            if (token.getText().equals("</script>"))
            {
                _phpScript = false;
                token.setType(ScriptClose);
            }
            else
            {
                // Add semicolon to the end of statement if it is absente.
                // For example: <?php echo "Hello world" ?>
                if (_prevTokenType == SemiColon || _prevTokenType == Colon
                    || _prevTokenType == OpenCurlyBracket || _prevTokenType == CloseCurlyBracket)
                {
                    token.setChannel(SkipChannel);
                }
                else
                {
                    token = new CommonToken(SemiColon);
                }
            }
        }
        else if (token.getType() == HtmlName)
        {
            _htmlNameText = token.getText();
        }
        else if (token.getType() == HtmlDoubleQuoteString)
        {
            if (token.getText().equals("php") && _htmlNameText.equals("language"))
            {
                _phpScript = true;
            }
        }
        else if (_mode == HereDoc)
        {
            // Heredoc and Nowdoc syntax support: http://php.net/manual/en/language.types.string.php#language.types.string.syntax.heredoc
            switch (token.getType())
            {
                case StartHereDoc:
                case StartNowDoc:
                    _heredocIdentifier = token.getText().substring(3).trim().replace("\'","");
                    break;
                case HereDocText:
                    if (CheckHeredocEnd(token.getText()))
                    {
                        popMode();
                        if (token.getText().trim().endsWith(";"))
                        {
                            token = new CommonToken(SemiColon);
                        }
                        else
                        {
                            token.setChannel(SkipChannel);
                        }
                    }
                    break;
            }
        }
        else if (_mode == PHP)
        {
            if (_channel != HIDDEN)
            {
                _prevTokenType = token.getType();
            }
        }

        return token;
    }

    boolean CheckHeredocEnd(String text)
    {
        text = text.trim();
        boolean semi = (text.length() > 0) ? (text.charAt(text.length() - 1) == ';') : false;
        String identifier = semi ? text.substring(0, text.length() - 1) : text;
        boolean result = identifier.equals(_heredocIdentifier);
        return result;
    }
    #endif

};

struct _MyPhpLexerClass {
    /*< private >*/
    PhpLexerBaseClass parent_class;
};

GType my_php_lexer_get_type(void) G_GNUC_CONST;
MyPhpLexer *my_php_lexer_new();

MyPhpLexer *my_php_lexer_new_with_char_stream (AntlrCharStream *char_stream);

void my_php_lexer_atn_free ();
void my_php_lexer_decision_to_dfa_free ();
void my_php_lexer_token_names_free();


//virtual void my_php_lexer_action(MyPhpLexer* self, AntlrRuleContext *context, size_t ruleIndex, size_t actionIndex);
//virtual gboolean my_php_lexer_sempred(MyPhpLexer* self, AntlrRuleContext *local_context, size_t ruleIndex, size_t predicateIndex);


// Individual action functions triggered by action() above.
void my_php_lexer_action_htmlscriptopen(MyPhpLexer* self, AntlrRuleContext *context, gint actionIndex);
void my_php_lexer_action_htmlstyleopen(MyPhpLexer* self, AntlrRuleContext *context, gint actionIndex);
void my_php_lexer_action_htmlclose(MyPhpLexer* self, AntlrRuleContext *context, gint actionIndex);
void my_php_lexer_action_closecurlybracket(MyPhpLexer* self, AntlrRuleContext *context, gint actionIndex);
void my_php_lexer_action_curlydollar(MyPhpLexer* self, AntlrRuleContext *context, gint actionIndex);

// Individual semantic predicate functions triggered by sempred() above.
gboolean my_php_lexer_sempred_shebang(MyPhpLexer* self, AntlrRuleContext *local_context, size_t predicateIndex);
gboolean my_php_lexer_sempred_phpend(MyPhpLexer* self, AntlrRuleContext *local_context, size_t predicateIndex);
gboolean my_php_lexer_sempred_startnowdoc(MyPhpLexer* self, AntlrRuleContext *local_context, size_t predicateIndex);
gboolean my_php_lexer_sempred_startheredoc(MyPhpLexer* self, AntlrRuleContext *local_context, size_t predicateIndex);
gboolean my_php_lexer_sempred_curlydollar(MyPhpLexer* self, AntlrRuleContext *local_context, size_t predicateIndex);
gboolean my_php_lexer_sempred_phpstartechofragment(MyPhpLexer* self, AntlrRuleContext *local_context, size_t predicateIndex);
gboolean my_php_lexer_sempred_phpstartfragment(MyPhpLexer* self, AntlrRuleContext *local_context, size_t predicateIndex);


G_END_DECLS

#endif /* __MY_PHP_LEXER_H__ */

