
// Generated from PhpParser.g4 by ANTLR 4.6


//#include "antlr4-runtime.h"




#ifndef __MY_PHP_PARSER_H__
#define __MY_PHP_PARSER_H__

#include <glib-object.h>

G_BEGIN_DECLS

#define MY_PHP_PARSER_EOF ANTLR_TOKEN_EOF

typedef enum _MyPhpParserTokens  MyPhpParserTokens;
typedef enum _MyPhpParserRules   MyPhpParserRules;

enum _MyPhpParserTokens {
  MY_PHP_PARSER_SEA_WHITESPACE = 1, MY_PHP_PARSER_HTML_TEXT = 2, MY_PHP_PARSER_XML_START = 3, 
  MY_PHP_PARSER_PHPSTART = 4, MY_PHP_PARSER_HTML_SCRIPT_OPEN = 5, MY_PHP_PARSER_HTML_STYLE_OPEN = 6, 
  MY_PHP_PARSER_HTML_COMMENT = 7, MY_PHP_PARSER_HTML_DTD = 8, MY_PHP_PARSER_HTML_OPEN = 9, 
  MY_PHP_PARSER_SHEBANG = 10, MY_PHP_PARSER_ERROR = 11, MY_PHP_PARSER_XML_TEXT = 12, 
  MY_PHP_PARSER_XML_CLOSE = 13, MY_PHP_PARSER_PHPSTART_INSIDE = 14, MY_PHP_PARSER_HTML_CLOSE = 15, 
  MY_PHP_PARSER_HTML_SLASH_CLOSE = 16, MY_PHP_PARSER_HTML_SLASH = 17, MY_PHP_PARSER_HTML_EQUALS = 18, 
  MY_PHP_PARSER_HTML_START_QUOTE_STRING = 19, MY_PHP_PARSER_HTML_START_DOUBLE_QUOTE_STRING = 20, 
  MY_PHP_PARSER_HTML_HEX = 21, MY_PHP_PARSER_HTML_DECIMAL = 22, MY_PHP_PARSER_HTML_SPACE = 23, 
  MY_PHP_PARSER_HTML_NAME = 24, MY_PHP_PARSER_ERROR_INSIDE = 25, MY_PHP_PARSER_PHPSTART_INSIDE_QUOTE_STRING = 26, 
  MY_PHP_PARSER_HTML_END_QUOTE_STRING = 27, MY_PHP_PARSER_HTML_QUOTE_STRING = 28, 
  MY_PHP_PARSER_ERROR_HTML_QUOTE = 29, MY_PHP_PARSER_PHPSTART_DOUBLE_QUOTE_STRING = 30, 
  MY_PHP_PARSER_HTML_END_DOUBLE_QUOTE_STRING = 31, MY_PHP_PARSER_HTML_DOUBLE_QUOTE_STRING = 32, 
  MY_PHP_PARSER_ERROR_HTML_DOUBLE_QUOTE = 33, MY_PHP_PARSER_SCRIPT_TEXT = 34, 
  MY_PHP_PARSER_SCRIPT_CLOSE = 35, MY_PHP_PARSER_PHPSTART_INSIDE_SCRIPT = 36, 
  MY_PHP_PARSER_STYLE_BODY = 37, MY_PHP_PARSER_PHPEND = 38, MY_PHP_PARSER_WHITESPACE = 39, 
  MY_PHP_PARSER_MULTI_LINE_COMMENT = 40, MY_PHP_PARSER_SINGLE_LINE_COMMENT = 41, 
  MY_PHP_PARSER_SHELL_STYLE_COMMENT = 42, MY_PHP_PARSER_ABSTRACT = 43, MY_PHP_PARSER_ARRAY = 44, 
  MY_PHP_PARSER_AS = 45, MY_PHP_PARSER_BINARY_CAST = 46, MY_PHP_PARSER_BOOL_TYPE = 47, 
  MY_PHP_PARSER_BOOLEAN_CONSTANT = 48, MY_PHP_PARSER_BREAK = 49, MY_PHP_PARSER_CALLABLE = 50, 
  MY_PHP_PARSER_CASE = 51, MY_PHP_PARSER_CATCH = 52, MY_PHP_PARSER_CLASS = 53, 
  MY_PHP_PARSER_CLONE = 54, MY_PHP_PARSER_CONST = 55, MY_PHP_PARSER_CONTINUE = 56, 
  MY_PHP_PARSER_DECLARE = 57, MY_PHP_PARSER_DEFAULT = 58, MY_PHP_PARSER_DO = 59, 
  MY_PHP_PARSER_DOUBLE_CAST = 60, MY_PHP_PARSER_DOUBLE_TYPE = 61, MY_PHP_PARSER_ECHO = 62, 
  MY_PHP_PARSER_ELSE = 63, MY_PHP_PARSER_ELSE_IF = 64, MY_PHP_PARSER_EMPTY = 65, 
  MY_PHP_PARSER_END_DECLARE = 66, MY_PHP_PARSER_END_FOR = 67, MY_PHP_PARSER_END_FOREACH = 68, 
  MY_PHP_PARSER_END_IF = 69, MY_PHP_PARSER_END_SWITCH = 70, MY_PHP_PARSER_END_WHILE = 71, 
  MY_PHP_PARSER_EVAL = 72, MY_PHP_PARSER_EXIT = 73, MY_PHP_PARSER_EXTENDS = 74, 
  MY_PHP_PARSER_FINAL = 75, MY_PHP_PARSER_FINALLY = 76, MY_PHP_PARSER_FLOAT_CAST = 77, 
  MY_PHP_PARSER_FOR = 78, MY_PHP_PARSER_FOREACH = 79, MY_PHP_PARSER_FUNCTION = 80, 
  MY_PHP_PARSER_GLOBAL = 81, MY_PHP_PARSER_GOTO = 82, MY_PHP_PARSER_IF = 83, 
  MY_PHP_PARSER_IMPLEMENTS = 84, MY_PHP_PARSER_IMPORT = 85, MY_PHP_PARSER_INCLUDE = 86, 
  MY_PHP_PARSER_INCLUDE_ONCE = 87, MY_PHP_PARSER_INSTANCE_OF = 88, MY_PHP_PARSER_INSTEAD_OF = 89, 
  MY_PHP_PARSER_INT8CAST = 90, MY_PHP_PARSER_INT16CAST = 91, MY_PHP_PARSER_INT64TYPE = 92, 
  MY_PHP_PARSER_INT_TYPE = 93, MY_PHP_PARSER_INTERFACE = 94, MY_PHP_PARSER_IS_SET = 95, 
  MY_PHP_PARSER_LIST = 96, MY_PHP_PARSER_LOGICAL_AND = 97, MY_PHP_PARSER_LOGICAL_OR = 98, 
  MY_PHP_PARSER_LOGICAL_XOR = 99, MY_PHP_PARSER_NAMESPACE = 100, MY_PHP_PARSER_NEW = 101, 
  MY_PHP_PARSER_NULL = 102, MY_PHP_PARSER_OBJECT_TYPE = 103, MY_PHP_PARSER_PARENT_ = 104, 
  MY_PHP_PARSER_PARTIAL = 105, MY_PHP_PARSER_PRINT = 106, MY_PHP_PARSER_PRIVATE = 107, 
  MY_PHP_PARSER_PROTECTED = 108, MY_PHP_PARSER_PUBLIC = 109, MY_PHP_PARSER_REQUIRE = 110, 
  MY_PHP_PARSER_REQUIRE_ONCE = 111, MY_PHP_PARSER_RESOURCE = 112, MY_PHP_PARSER_RETURN = 113, 
  MY_PHP_PARSER_STATIC = 114, MY_PHP_PARSER_STRING_TYPE = 115, MY_PHP_PARSER_SWITCH = 116, 
  MY_PHP_PARSER_THROW = 117, MY_PHP_PARSER_TRAIT = 118, MY_PHP_PARSER_TRY = 119, 
  MY_PHP_PARSER_TYPEOF = 120, MY_PHP_PARSER_UINT_CAST = 121, MY_PHP_PARSER_UNICODE_CAST = 122, 
  MY_PHP_PARSER_UNSET = 123, MY_PHP_PARSER_USE = 124, MY_PHP_PARSER_VAR = 125, 
  MY_PHP_PARSER_WHILE = 126, MY_PHP_PARSER_YIELD = 127, MY_PHP_PARSER_GET = 128, 
  MY_PHP_PARSER_SET = 129, MY_PHP_PARSER_CALL = 130, MY_PHP_PARSER_CALL_STATIC = 131, 
  MY_PHP_PARSER_CONSTRUCTOR = 132, MY_PHP_PARSER_DESTRUCT = 133, MY_PHP_PARSER_WAKEUP = 134, 
  MY_PHP_PARSER_SLEEP = 135, MY_PHP_PARSER_AUTOLOAD = 136, MY_PHP_PARSER_IS_SET__ = 137, 
  MY_PHP_PARSER_UNSET__ = 138, MY_PHP_PARSER_TO_STRING__ = 139, MY_PHP_PARSER_INVOKE = 140, 
  MY_PHP_PARSER_SET_STATE = 141, MY_PHP_PARSER_CLONE__ = 142, MY_PHP_PARSER_DEBUG_INFO = 143, 
  MY_PHP_PARSER_NAMESPACE__ = 144, MY_PHP_PARSER_CLASS__ = 145, MY_PHP_PARSER_TRAIC__ = 146, 
  MY_PHP_PARSER_FUNCTION__ = 147, MY_PHP_PARSER_METHOD__ = 148, MY_PHP_PARSER_LINE__ = 149, 
  MY_PHP_PARSER_FILE__ = 150, MY_PHP_PARSER_DIR__ = 151, MY_PHP_PARSER_LGENERIC = 152, 
  MY_PHP_PARSER_RGENERIC = 153, MY_PHP_PARSER_DOUBLE_ARROW = 154, MY_PHP_PARSER_INC = 155, 
  MY_PHP_PARSER_DEC = 156, MY_PHP_PARSER_IS_IDENTICAL = 157, MY_PHP_PARSER_IS_NOIDENTICAL = 158, 
  MY_PHP_PARSER_IS_EQUAL = 159, MY_PHP_PARSER_IS_NOT_EQ = 160, MY_PHP_PARSER_IS_SMALLER_OR_EQUAL = 161, 
  MY_PHP_PARSER_IS_GREATER_OR_EQUAL = 162, MY_PHP_PARSER_PLUS_EQUAL = 163, 
  MY_PHP_PARSER_MINUS_EQUAL = 164, MY_PHP_PARSER_MUL_EQUAL = 165, MY_PHP_PARSER_POW = 166, 
  MY_PHP_PARSER_POW_EQUAL = 167, MY_PHP_PARSER_DIV_EQUAL = 168, MY_PHP_PARSER_CONCAEQUAL = 169, 
  MY_PHP_PARSER_MOD_EQUAL = 170, MY_PHP_PARSER_SHIFT_LEFT_EQUAL = 171, MY_PHP_PARSER_SHIFT_RIGHT_EQUAL = 172, 
  MY_PHP_PARSER_AND_EQUAL = 173, MY_PHP_PARSER_OR_EQUAL = 174, MY_PHP_PARSER_XOR_EQUAL = 175, 
  MY_PHP_PARSER_BOOLEAN_OR = 176, MY_PHP_PARSER_BOOLEAN_AND = 177, MY_PHP_PARSER_SHIFT_LEFT = 178, 
  MY_PHP_PARSER_SHIFT_RIGHT = 179, MY_PHP_PARSER_DOUBLE_COLON = 180, MY_PHP_PARSER_OBJECT_OPERATOR = 181, 
  MY_PHP_PARSER_NAMESPACE_SEPARATOR = 182, MY_PHP_PARSER_ELLIPSIS = 183, 
  MY_PHP_PARSER_LESS = 184, MY_PHP_PARSER_GREATER = 185, MY_PHP_PARSER_AMPERSAND = 186, 
  MY_PHP_PARSER_PIPE = 187, MY_PHP_PARSER_BANG = 188, MY_PHP_PARSER_CARET = 189, 
  MY_PHP_PARSER_PLUS = 190, MY_PHP_PARSER_MINUS = 191, MY_PHP_PARSER_ASTERISK = 192, 
  MY_PHP_PARSER_PERCENT = 193, MY_PHP_PARSER_DIVIDE = 194, MY_PHP_PARSER_TILDE = 195, 
  MY_PHP_PARSER_SUPPRESS_WARNINGS = 196, MY_PHP_PARSER_DOLLAR = 197, MY_PHP_PARSER_DOT = 198, 
  MY_PHP_PARSER_QUESTION_MARK = 199, MY_PHP_PARSER_OPEN_ROUND_BRACKET = 200, 
  MY_PHP_PARSER_CLOSE_ROUND_BRACKET = 201, MY_PHP_PARSER_OPEN_SQUARE_BRACKET = 202, 
  MY_PHP_PARSER_CLOSE_SQUARE_BRACKET = 203, MY_PHP_PARSER_OPEN_CURLY_BRACKET = 204, 
  MY_PHP_PARSER_CLOSE_CURLY_BRACKET = 205, MY_PHP_PARSER_COMMA = 206, MY_PHP_PARSER_COLON = 207, 
  MY_PHP_PARSER_SEMI_COLON = 208, MY_PHP_PARSER_EQ = 209, MY_PHP_PARSER_QUOTE = 210, 
  MY_PHP_PARSER_BACK_QUOTE = 211, MY_PHP_PARSER_VAR_NAME = 212, MY_PHP_PARSER_LABEL = 213, 
  MY_PHP_PARSER_OCTAL = 214, MY_PHP_PARSER_DECIMAL = 215, MY_PHP_PARSER_REAL = 216, 
  MY_PHP_PARSER_HEX = 217, MY_PHP_PARSER_BINARY = 218, MY_PHP_PARSER_BACK_QUOTE_STRING = 219, 
  MY_PHP_PARSER_SINGLE_QUOTE_STRING = 220, MY_PHP_PARSER_DOUBLE_QUOTE = 221, 
  MY_PHP_PARSER_START_NOW_DOC = 222, MY_PHP_PARSER_START_HERE_DOC = 223, 
  MY_PHP_PARSER_ERROR_PHP = 224, MY_PHP_PARSER_CURLY_DOLLAR = 225, MY_PHP_PARSER_STRING_PART = 226, 
  MY_PHP_PARSER_COMMENT = 227, MY_PHP_PARSER_PHPEND_SINGLE_LINE_COMMENT = 228, 
  MY_PHP_PARSER_COMMENT_END = 229, MY_PHP_PARSER_HERE_DOC_TEXT = 230, MY_PHP_PARSER_XML_TEXT2 = 231
};

enum _MyPhpParserRules {
    MY_PHP_PARSER_HTML_DOCUMENT = 0, MY_PHP_PARSER_HTML_ELEMENT_OR_PHP_BLOCK = 1, 
    MY_PHP_PARSER_HTML_ELEMENTS = 2, MY_PHP_PARSER_HTML_ELEMENT = 3, MY_PHP_PARSER_SCRIPT_TEXT_PART = 4, 
    MY_PHP_PARSER_PHP_BLOCK = 5, MY_PHP_PARSER_IMPORT_STATEMENT = 6, MY_PHP_PARSER_TOP_STATEMENT = 7, 
    MY_PHP_PARSER_USE_DECLARATION = 8, MY_PHP_PARSER_USE_DECLARATION_CONTENT_LIST = 9, 
    MY_PHP_PARSER_USE_DECLARATION_CONTENT = 10, MY_PHP_PARSER_NAMESPACE_DECLARATION = 11, 
    MY_PHP_PARSER_NAMESPACE_STATEMENT = 12, MY_PHP_PARSER_FUNCTION_DECLARATION = 13, 
    MY_PHP_PARSER_CLASS_DECLARATION = 14, MY_PHP_PARSER_CLASS_ENTRY_TYPE = 15, 
    MY_PHP_PARSER_INTERFACE_LIST = 16, MY_PHP_PARSER_TYPE_PARAMETER_LIST_IN_BRACKETS = 17, 
    MY_PHP_PARSER_TYPE_PARAMETER_LIST = 18, MY_PHP_PARSER_TYPE_PARAMETER_WITH_DEFAULTS_LIST = 19, 
    MY_PHP_PARSER_TYPE_PARAMETER_DECL = 20, MY_PHP_PARSER_TYPE_PARAMETER_WITH_DEFAULT_DECL = 21, 
    MY_PHP_PARSER_GENERIC_DYNAMIC_ARGS = 22, MY_PHP_PARSER_ATTRIBUTES = 23, 
    MY_PHP_PARSER_ATTRIBUTES_GROUP = 24, MY_PHP_PARSER_ATTRIBUTE = 25, MY_PHP_PARSER_ATTRIBUTE_ARG_LIST = 26, 
    MY_PHP_PARSER_ATTRIBUTE_NAMED_ARG_LIST = 27, MY_PHP_PARSER_ATTRIBUTE_NAMED_ARG = 28, 
    MY_PHP_PARSER_INNER_STATEMENT_LIST = 29, MY_PHP_PARSER_INNER_STATEMENT = 30, 
    MY_PHP_PARSER_STATEMENT = 31, MY_PHP_PARSER_EMPTY_STATEMENT = 32, MY_PHP_PARSER_BLOCK_STATEMENT = 33, 
    MY_PHP_PARSER_IF_STATEMENT = 34, MY_PHP_PARSER_ELSE_IF_STATEMENT = 35, 
    MY_PHP_PARSER_ELSE_IF_COLON_STATEMENT = 36, MY_PHP_PARSER_ELSE_STATEMENT = 37, 
    MY_PHP_PARSER_ELSE_COLON_STATEMENT = 38, MY_PHP_PARSER_WHILE_STATEMENT = 39, 
    MY_PHP_PARSER_DO_WHILE_STATEMENT = 40, MY_PHP_PARSER_FOR_STATEMENT = 41, 
    MY_PHP_PARSER_FOR_INIT = 42, MY_PHP_PARSER_FOR_UPDATE = 43, MY_PHP_PARSER_SWITCH_STATEMENT = 44, 
    MY_PHP_PARSER_SWITCH_BLOCK = 45, MY_PHP_PARSER_BREAK_STATEMENT = 46, 
    MY_PHP_PARSER_CONTINUE_STATEMENT = 47, MY_PHP_PARSER_RETURN_STATEMENT = 48, 
    MY_PHP_PARSER_EXPRESSION_STATEMENT = 49, MY_PHP_PARSER_UNSET_STATEMENT = 50, 
    MY_PHP_PARSER_FOREACH_STATEMENT = 51, MY_PHP_PARSER_TRY_CATCH_FINALLY = 52, 
    MY_PHP_PARSER_CATCH_CLAUSE = 53, MY_PHP_PARSER_FINALLY_STATEMENT = 54, 
    MY_PHP_PARSER_THROW_STATEMENT = 55, MY_PHP_PARSER_GOTO_STATEMENT = 56, 
    MY_PHP_PARSER_DECLARE_STATEMENT = 57, MY_PHP_PARSER_INLINE_HTML_STATEMENT = 58, 
    MY_PHP_PARSER_INLINE_HTML = 59, MY_PHP_PARSER_DECLARE_LIST = 60, MY_PHP_PARSER_FORMAL_PARAMETER_LIST = 61, 
    MY_PHP_PARSER_FORMAL_PARAMETER = 62, MY_PHP_PARSER_TYPE_HINT = 63, MY_PHP_PARSER_GLOBAL_STATEMENT = 64, 
    MY_PHP_PARSER_GLOBAL_VAR = 65, MY_PHP_PARSER_ECHO_STATEMENT = 66, MY_PHP_PARSER_STATIC_VARIABLE_STATEMENT = 67, 
    MY_PHP_PARSER_CLASS_STATEMENT = 68, MY_PHP_PARSER_TRAIT_ADAPTATIONS = 69, 
    MY_PHP_PARSER_TRAIT_ADAPTATION_STATEMENT = 70, MY_PHP_PARSER_TRAIT_PRECEDENCE = 71, 
    MY_PHP_PARSER_TRAIT_ALIAS = 72, MY_PHP_PARSER_TRAIT_METHOD_REFERENCE = 73, 
    MY_PHP_PARSER_BASE_CTOR_CALL = 74, MY_PHP_PARSER_METHOD_BODY = 75, MY_PHP_PARSER_PROPERTY_MODIFIERS = 76, 
    MY_PHP_PARSER_MEMBER_MODIFIERS = 77, MY_PHP_PARSER_VARIABLE_INITIALIZER = 78, 
    MY_PHP_PARSER_IDENTIFIER_INITITALIZER = 79, MY_PHP_PARSER_GLOBAL_CONSTANT_DECLARATION = 80, 
    MY_PHP_PARSER_EXPRESSION_LIST = 81, MY_PHP_PARSER_PARENTHESIS = 82, 
    MY_PHP_PARSER_EXPRESSION = 83, MY_PHP_PARSER_NEW_EXPR = 84, MY_PHP_PARSER_ASSIGNMENT_OPERATOR = 85, 
    MY_PHP_PARSER_YIELD_EXPRESSION = 86, MY_PHP_PARSER_ARRAY_ITEM_LIST = 87, 
    MY_PHP_PARSER_ARRAY_ITEM = 88, MY_PHP_PARSER_LAMBDA_FUNCTION_USE_VARS = 89, 
    MY_PHP_PARSER_LAMBDA_FUNCTION_USE_VAR = 90, MY_PHP_PARSER_QUALIFIED_STATIC_TYPE_REF = 91, 
    MY_PHP_PARSER_TYPE_REF = 92, MY_PHP_PARSER_INDIRECT_TYPE_REF = 93, MY_PHP_PARSER_QUALIFIED_NAMESPACE_NAME = 94, 
    MY_PHP_PARSER_NAMESPACE_NAME_LIST = 95, MY_PHP_PARSER_QUALIFIED_NAMESPACE_NAME_LIST = 96, 
    MY_PHP_PARSER_ARGUMENTS = 97, MY_PHP_PARSER_ACTUAL_ARGUMENT = 98, MY_PHP_PARSER_CONSTANT_INITITALIZER = 99, 
    MY_PHP_PARSER_CONSTANT_ARRAY_ITEM_LIST = 100, MY_PHP_PARSER_CONSTANT_ARRAY_ITEM = 101, 
    MY_PHP_PARSER_CONSTANT = 102, MY_PHP_PARSER_LITERAL_CONSTANT = 103, 
    MY_PHP_PARSER_NUMERIC_CONSTANT = 104, MY_PHP_PARSER_CLASS_CONSTANT = 105, 
    MY_PHP_PARSER_STRING_CONSTANT = 106, MY_PHP_PARSER_STRING = 107, MY_PHP_PARSER_INTERPOLATED_STRING_PART = 108, 
    MY_PHP_PARSER_CHAIN_LIST = 109, MY_PHP_PARSER_CHAIN = 110, MY_PHP_PARSER_MEMBER_ACCESS = 111, 
    MY_PHP_PARSER_FUNCTION_CALL = 112, MY_PHP_PARSER_FUNCTION_CALL_NAME = 113, 
    MY_PHP_PARSER_ACTUAL_ARGUMENTS = 114, MY_PHP_PARSER_CHAIN_BASE = 115, 
    MY_PHP_PARSER_KEYED_FIELD_NAME = 116, MY_PHP_PARSER_KEYED_SIMPLE_FIELD_NAME = 117, 
    MY_PHP_PARSER_KEYED_VARIABLE = 118, MY_PHP_PARSER_SQUARE_CURLY_EXPRESSION = 119, 
    MY_PHP_PARSER_ASSIGNMENT_LIST = 120, MY_PHP_PARSER_ASSIGNMENT_LIST_ELEMENT = 121, 
    MY_PHP_PARSER_MODIFIER = 122, MY_PHP_PARSER_IDENTIFIER = 123, MY_PHP_PARSER_MEMBER_MODIFIER = 124, 
    MY_PHP_PARSER_MAGIC_CONSTANT = 125, MY_PHP_PARSER_MAGIC_METHOD = 126, 
    MY_PHP_PARSER_PRIMITIVE_TYPE = 127, MY_PHP_PARSER_CAST_OPERATION = 128
};


#define MY_TYPE_PHP_PARSER            (my_php_parser_get_type())
#define MY_PHP_PARSER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_PHP_PARSER, MyPhpParser))
#define MY_PHP_PARSER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_PHP_PARSER, MyPhpParserClass))
#define MY_IS_PHP_PARSER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_PHP_PARSER))
#define MY_IS_PHP_PARSER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_PHP_PARSER))
#define MY_PHP_PARSER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_PHP_PARSER, MyPhpParserClass))

typedef struct _MyPhpParser      MyPhpParser;
typedef struct _MyPhpParserClass MyPhpParserClass;

struct _MyPhpParser {
    /*< private >*/
    AntlrParser parent_instance;

    GArray *rule_names;

    /*< public >*/
};

struct _MyPhpParserClass {
    /*< private >*/
    AntlrParserClass parent_class;
};

GType my_php_parser_get_type(void) G_GNUC_CONST;
MyPhpParser *my_php_parser_new();
MyPhpParser *my_php_parser_new_with_token_stream (AntlrTokenStream *input);

void my_php_parser_atn_free ();
void my_php_parser_decision_to_dfa_free ();
void my_php_parser_token_names_free();


typedef struct _MyContextHtmlDocument MyContextHtmlDocument; 
typedef struct _MyContextHtmlElementOrPhpBlock MyContextHtmlElementOrPhpBlock; 
typedef struct _MyContextHtmlElements MyContextHtmlElements; 
typedef struct _MyContextHtmlElement MyContextHtmlElement; 
typedef struct _MyContextScriptTextPart MyContextScriptTextPart; 
typedef struct _MyContextPhpBlock MyContextPhpBlock; 
typedef struct _MyContextImportStatement MyContextImportStatement; 
typedef struct _MyContextTopStatement MyContextTopStatement; 
typedef struct _MyContextUseDeclaration MyContextUseDeclaration; 
typedef struct _MyContextUseDeclarationContentList MyContextUseDeclarationContentList; 
typedef struct _MyContextUseDeclarationContent MyContextUseDeclarationContent; 
typedef struct _MyContextNamespaceDeclaration MyContextNamespaceDeclaration; 
typedef struct _MyContextNamespaceStatement MyContextNamespaceStatement; 
typedef struct _MyContextFunctionDeclaration MyContextFunctionDeclaration; 
typedef struct _MyContextClassDeclaration MyContextClassDeclaration; 
typedef struct _MyContextClassEntryType MyContextClassEntryType; 
typedef struct _MyContextInterfaceList MyContextInterfaceList; 
typedef struct _MyContextTypeParameterListInBrackets MyContextTypeParameterListInBrackets; 
typedef struct _MyContextTypeParameterList MyContextTypeParameterList; 
typedef struct _MyContextTypeParameterWithDefaultsList MyContextTypeParameterWithDefaultsList; 
typedef struct _MyContextTypeParameterDecl MyContextTypeParameterDecl; 
typedef struct _MyContextTypeParameterWithDefaultDecl MyContextTypeParameterWithDefaultDecl; 
typedef struct _MyContextGenericDynamicArgs MyContextGenericDynamicArgs; 
typedef struct _MyContextAttributes MyContextAttributes; 
typedef struct _MyContextAttributesGroup MyContextAttributesGroup; 
typedef struct _MyContextAttribute MyContextAttribute; 
typedef struct _MyContextAttributeArgList MyContextAttributeArgList; 
typedef struct _MyContextAttributeNamedArgList MyContextAttributeNamedArgList; 
typedef struct _MyContextAttributeNamedArg MyContextAttributeNamedArg; 
typedef struct _MyContextInnerStatementList MyContextInnerStatementList; 
typedef struct _MyContextInnerStatement MyContextInnerStatement; 
typedef struct _MyContextStatement MyContextStatement; 
typedef struct _MyContextEmptyStatement MyContextEmptyStatement; 
typedef struct _MyContextBlockStatement MyContextBlockStatement; 
typedef struct _MyContextIfStatement MyContextIfStatement; 
typedef struct _MyContextElseIfStatement MyContextElseIfStatement; 
typedef struct _MyContextElseIfColonStatement MyContextElseIfColonStatement; 
typedef struct _MyContextElseStatement MyContextElseStatement; 
typedef struct _MyContextElseColonStatement MyContextElseColonStatement; 
typedef struct _MyContextWhileStatement MyContextWhileStatement; 
typedef struct _MyContextDoWhileStatement MyContextDoWhileStatement; 
typedef struct _MyContextForStatement MyContextForStatement; 
typedef struct _MyContextForInit MyContextForInit; 
typedef struct _MyContextForUpdate MyContextForUpdate; 
typedef struct _MyContextSwitchStatement MyContextSwitchStatement; 
typedef struct _MyContextSwitchBlock MyContextSwitchBlock; 
typedef struct _MyContextBreakStatement MyContextBreakStatement; 
typedef struct _MyContextContinueStatement MyContextContinueStatement; 
typedef struct _MyContextReturnStatement MyContextReturnStatement; 
typedef struct _MyContextExpressionStatement MyContextExpressionStatement; 
typedef struct _MyContextUnsetStatement MyContextUnsetStatement; 
typedef struct _MyContextForeachStatement MyContextForeachStatement; 
typedef struct _MyContextTryCatchFinally MyContextTryCatchFinally; 
typedef struct _MyContextCatchClause MyContextCatchClause; 
typedef struct _MyContextFinallyStatement MyContextFinallyStatement; 
typedef struct _MyContextThrowStatement MyContextThrowStatement; 
typedef struct _MyContextGotoStatement MyContextGotoStatement; 
typedef struct _MyContextDeclareStatement MyContextDeclareStatement; 
typedef struct _MyContextInlineHtmlStatement MyContextInlineHtmlStatement; 
typedef struct _MyContextInlineHtml MyContextInlineHtml; 
typedef struct _MyContextDeclareList MyContextDeclareList; 
typedef struct _MyContextFormalParameterList MyContextFormalParameterList; 
typedef struct _MyContextFormalParameter MyContextFormalParameter; 
typedef struct _MyContextTypeHint MyContextTypeHint; 
typedef struct _MyContextGlobalStatement MyContextGlobalStatement; 
typedef struct _MyContextGlobalVar MyContextGlobalVar; 
typedef struct _MyContextEchoStatement MyContextEchoStatement; 
typedef struct _MyContextStaticVariableStatement MyContextStaticVariableStatement; 
typedef struct _MyContextClassStatement MyContextClassStatement; 
typedef struct _MyContextTraitAdaptations MyContextTraitAdaptations; 
typedef struct _MyContextTraitAdaptationStatement MyContextTraitAdaptationStatement; 
typedef struct _MyContextTraitPrecedence MyContextTraitPrecedence; 
typedef struct _MyContextTraitAlias MyContextTraitAlias; 
typedef struct _MyContextTraitMethodReference MyContextTraitMethodReference; 
typedef struct _MyContextBaseCtorCall MyContextBaseCtorCall; 
typedef struct _MyContextMethodBody MyContextMethodBody; 
typedef struct _MyContextPropertyModifiers MyContextPropertyModifiers; 
typedef struct _MyContextMemberModifiers MyContextMemberModifiers; 
typedef struct _MyContextVariableInitializer MyContextVariableInitializer; 
typedef struct _MyContextIdentifierInititalizer MyContextIdentifierInititalizer; 
typedef struct _MyContextGlobalConstantDeclaration MyContextGlobalConstantDeclaration; 
typedef struct _MyContextExpressionList MyContextExpressionList; 
typedef struct _MyContextParenthesis MyContextParenthesis; 
typedef struct _MyContextExpression MyContextExpression; 
typedef struct _MyContextNewExpr MyContextNewExpr; 
typedef struct _MyContextAssignmentOperator MyContextAssignmentOperator; 
typedef struct _MyContextYieldExpression MyContextYieldExpression; 
typedef struct _MyContextArrayItemList MyContextArrayItemList; 
typedef struct _MyContextArrayItem MyContextArrayItem; 
typedef struct _MyContextLambdaFunctionUseVars MyContextLambdaFunctionUseVars; 
typedef struct _MyContextLambdaFunctionUseVar MyContextLambdaFunctionUseVar; 
typedef struct _MyContextQualifiedStaticTypeRef MyContextQualifiedStaticTypeRef; 
typedef struct _MyContextTypeRef MyContextTypeRef; 
typedef struct _MyContextIndirectTypeRef MyContextIndirectTypeRef; 
typedef struct _MyContextQualifiedNamespaceName MyContextQualifiedNamespaceName; 
typedef struct _MyContextNamespaceNameList MyContextNamespaceNameList; 
typedef struct _MyContextQualifiedNamespaceNameList MyContextQualifiedNamespaceNameList; 
typedef struct _MyContextArguments MyContextArguments; 
typedef struct _MyContextActualArgument MyContextActualArgument; 
typedef struct _MyContextConstantInititalizer MyContextConstantInititalizer; 
typedef struct _MyContextConstantArrayItemList MyContextConstantArrayItemList; 
typedef struct _MyContextConstantArrayItem MyContextConstantArrayItem; 
typedef struct _MyContextConstant MyContextConstant; 
typedef struct _MyContextLiteralConstant MyContextLiteralConstant; 
typedef struct _MyContextNumericConstant MyContextNumericConstant; 
typedef struct _MyContextClassConstant MyContextClassConstant; 
typedef struct _MyContextStringConstant MyContextStringConstant; 
typedef struct _MyContextString MyContextString; 
typedef struct _MyContextInterpolatedStringPart MyContextInterpolatedStringPart; 
typedef struct _MyContextChainList MyContextChainList; 
typedef struct _MyContextChain MyContextChain; 
typedef struct _MyContextMemberAccess MyContextMemberAccess; 
typedef struct _MyContextFunctionCall MyContextFunctionCall; 
typedef struct _MyContextFunctionCallName MyContextFunctionCallName; 
typedef struct _MyContextActualArguments MyContextActualArguments; 
typedef struct _MyContextChainBase MyContextChainBase; 
typedef struct _MyContextKeyedFieldName MyContextKeyedFieldName; 
typedef struct _MyContextKeyedSimpleFieldName MyContextKeyedSimpleFieldName; 
typedef struct _MyContextKeyedVariable MyContextKeyedVariable; 
typedef struct _MyContextSquareCurlyExpression MyContextSquareCurlyExpression; 
typedef struct _MyContextAssignmentList MyContextAssignmentList; 
typedef struct _MyContextAssignmentListElement MyContextAssignmentListElement; 
typedef struct _MyContextModifier MyContextModifier; 
typedef struct _MyContextIdentifier MyContextIdentifier; 
typedef struct _MyContextMemberModifier MyContextMemberModifier; 
typedef struct _MyContextMagicConstant MyContextMagicConstant; 
typedef struct _MyContextMagicMethod MyContextMagicMethod; 
typedef struct _MyContextPrimitiveType MyContextPrimitiveType; 
typedef struct _MyContextCastOperation MyContextCastOperation; 

//----------------- HtmlDocumentContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_HTML_DOCUMENT            (my_context_html_document_get_type())
#define MY_CONTEXT_HTML_DOCUMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_HTML_DOCUMENT, MyContextHtmlDocument))
#define MY_CONTEXT_HTML_DOCUMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_HTML_DOCUMENT, MyContextHtmlDocumentClass))
#define MY_IS_CONTEXT_HTML_DOCUMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_HTML_DOCUMENT))
#define MY_IS_CONTEXT_HTML_DOCUMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_HTML_DOCUMENT))
#define MY_CONTEXT_HTML_DOCUMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_HTML_DOCUMENT, MyContextHtmlDocumentClass))


//typedef struct _MyContextHtmlDocument      MyContextHtmlDocument;
typedef struct _MyContextHtmlDocumentClass MyContextHtmlDocumentClass;

struct _MyContextHtmlDocument {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextHtmlDocumentClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_html_document_get_type(void) G_GNUC_CONST;
MyContextHtmlDocument *my_context_html_document_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_html_document_token_get_eof(MyContextHtmlDocument* self);
AntlrTerminalNode *my_context_html_document_token_get_shebang(MyContextHtmlDocument* self);
GList* my_context_html_document_rule_get_html_element_or_php_block(MyContextHtmlDocument* self);// of MyContextHtmlElementOrPhpBlock
MyContextHtmlElementOrPhpBlock* my_context_html_document_at_rule_get_html_element_or_php_block(MyContextHtmlDocument* self, size_t i);


MyContextHtmlDocument* my_php_parser_parse_html_document(MyPhpParser* self, GError **error);
//----------------- HtmlElementOrPhpBlockContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK            (my_context_html_element_or_php_block_get_type())
#define MY_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK, MyContextHtmlElementOrPhpBlock))
#define MY_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK, MyContextHtmlElementOrPhpBlockClass))
#define MY_IS_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK))
#define MY_IS_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK))
#define MY_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_HTML_ELEMENT_OR_PHP_BLOCK, MyContextHtmlElementOrPhpBlockClass))


//typedef struct _MyContextHtmlElementOrPhpBlock      MyContextHtmlElementOrPhpBlock;
typedef struct _MyContextHtmlElementOrPhpBlockClass MyContextHtmlElementOrPhpBlockClass;

struct _MyContextHtmlElementOrPhpBlock {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextHtmlElementOrPhpBlockClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_html_element_or_php_block_get_type(void) G_GNUC_CONST;
MyContextHtmlElementOrPhpBlock *my_context_html_element_or_php_block_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextHtmlElements *my_context_html_element_or_php_block_rule_get_html_elements(MyContextHtmlElementOrPhpBlock* self);
MyContextPhpBlock *my_context_html_element_or_php_block_rule_get_php_block(MyContextHtmlElementOrPhpBlock* self);
MyContextScriptTextPart *my_context_html_element_or_php_block_rule_get_script_text_part(MyContextHtmlElementOrPhpBlock* self);


MyContextHtmlElementOrPhpBlock* my_php_parser_parse_html_element_or_php_block(MyPhpParser* self, GError **error);
//----------------- HtmlElementsContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_HTML_ELEMENTS            (my_context_html_elements_get_type())
#define MY_CONTEXT_HTML_ELEMENTS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_HTML_ELEMENTS, MyContextHtmlElements))
#define MY_CONTEXT_HTML_ELEMENTS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_HTML_ELEMENTS, MyContextHtmlElementsClass))
#define MY_IS_CONTEXT_HTML_ELEMENTS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_HTML_ELEMENTS))
#define MY_IS_CONTEXT_HTML_ELEMENTS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_HTML_ELEMENTS))
#define MY_CONTEXT_HTML_ELEMENTS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_HTML_ELEMENTS, MyContextHtmlElementsClass))


//typedef struct _MyContextHtmlElements      MyContextHtmlElements;
typedef struct _MyContextHtmlElementsClass MyContextHtmlElementsClass;

struct _MyContextHtmlElements {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextHtmlElementsClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_html_elements_get_type(void) G_GNUC_CONST;
MyContextHtmlElements *my_context_html_elements_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_html_elements_rule_get_html_element(MyContextHtmlElements* self);// of MyContextHtmlElement
MyContextHtmlElement* my_context_html_elements_at_rule_get_html_element(MyContextHtmlElements* self, size_t i);


MyContextHtmlElements* my_php_parser_parse_html_elements(MyPhpParser* self, GError **error);
//----------------- HtmlElementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_HTML_ELEMENT            (my_context_html_element_get_type())
#define MY_CONTEXT_HTML_ELEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_HTML_ELEMENT, MyContextHtmlElement))
#define MY_CONTEXT_HTML_ELEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_HTML_ELEMENT, MyContextHtmlElementClass))
#define MY_IS_CONTEXT_HTML_ELEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_HTML_ELEMENT))
#define MY_IS_CONTEXT_HTML_ELEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_HTML_ELEMENT))
#define MY_CONTEXT_HTML_ELEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_HTML_ELEMENT, MyContextHtmlElementClass))


//typedef struct _MyContextHtmlElement      MyContextHtmlElement;
typedef struct _MyContextHtmlElementClass MyContextHtmlElementClass;

struct _MyContextHtmlElement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextHtmlElementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_html_element_get_type(void) G_GNUC_CONST;
MyContextHtmlElement *my_context_html_element_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_html_element_token_get_html_dtd(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_script_open(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_close(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_style_open(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_open(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_name(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_slash_close(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_slash(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_text(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_equals(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_start_quote_string(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_end_quote_string(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_start_double_quote_string(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_end_double_quote_string(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_hex(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_decimal(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_quote_string(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_html_double_quote_string(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_style_body(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_script_close(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_xml_start(MyContextHtmlElement* self);
AntlrTerminalNode *my_context_html_element_token_get_xml_close(MyContextHtmlElement* self);
GList* my_context_html_element_token_get_xml_text(MyContextHtmlElement* self);// of AntlrTerminalNode*
AntlrTerminalNode *my_context_html_element_at_token_get_xml_text(MyContextHtmlElement* self, size_t i);


MyContextHtmlElement* my_php_parser_parse_html_element(MyPhpParser* self, GError **error);
//----------------- ScriptTextPartContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_SCRIPT_TEXT_PART            (my_context_script_text_part_get_type())
#define MY_CONTEXT_SCRIPT_TEXT_PART(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_SCRIPT_TEXT_PART, MyContextScriptTextPart))
#define MY_CONTEXT_SCRIPT_TEXT_PART_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_SCRIPT_TEXT_PART, MyContextScriptTextPartClass))
#define MY_IS_CONTEXT_SCRIPT_TEXT_PART(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_SCRIPT_TEXT_PART))
#define MY_IS_CONTEXT_SCRIPT_TEXT_PART_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_SCRIPT_TEXT_PART))
#define MY_CONTEXT_SCRIPT_TEXT_PART_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_SCRIPT_TEXT_PART, MyContextScriptTextPartClass))


//typedef struct _MyContextScriptTextPart      MyContextScriptTextPart;
typedef struct _MyContextScriptTextPartClass MyContextScriptTextPartClass;

struct _MyContextScriptTextPart {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextScriptTextPartClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_script_text_part_get_type(void) G_GNUC_CONST;
MyContextScriptTextPart *my_context_script_text_part_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_script_text_part_token_get_script_text(MyContextScriptTextPart* self);// of AntlrTerminalNode*
AntlrTerminalNode *my_context_script_text_part_at_token_get_script_text(MyContextScriptTextPart* self, size_t i);


MyContextScriptTextPart* my_php_parser_parse_script_text_part(MyPhpParser* self, GError **error);
//----------------- PhpBlockContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_PHP_BLOCK            (my_context_php_block_get_type())
#define MY_CONTEXT_PHP_BLOCK(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_PHP_BLOCK, MyContextPhpBlock))
#define MY_CONTEXT_PHP_BLOCK_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_PHP_BLOCK, MyContextPhpBlockClass))
#define MY_IS_CONTEXT_PHP_BLOCK(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_PHP_BLOCK))
#define MY_IS_CONTEXT_PHP_BLOCK_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_PHP_BLOCK))
#define MY_CONTEXT_PHP_BLOCK_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_PHP_BLOCK, MyContextPhpBlockClass))


//typedef struct _MyContextPhpBlock      MyContextPhpBlock;
typedef struct _MyContextPhpBlockClass MyContextPhpBlockClass;

struct _MyContextPhpBlock {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextPhpBlockClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_php_block_get_type(void) G_GNUC_CONST;
MyContextPhpBlock *my_context_php_block_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_php_block_rule_get_import_statement(MyContextPhpBlock* self);// of MyContextImportStatement
MyContextImportStatement* my_context_php_block_at_rule_get_import_statement(MyContextPhpBlock* self, size_t i);
GList* my_context_php_block_rule_get_top_statement(MyContextPhpBlock* self);// of MyContextTopStatement
MyContextTopStatement* my_context_php_block_at_rule_get_top_statement(MyContextPhpBlock* self, size_t i);


MyContextPhpBlock* my_php_parser_parse_php_block(MyPhpParser* self, GError **error);
//----------------- ImportStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_IMPORT_STATEMENT            (my_context_import_statement_get_type())
#define MY_CONTEXT_IMPORT_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_IMPORT_STATEMENT, MyContextImportStatement))
#define MY_CONTEXT_IMPORT_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_IMPORT_STATEMENT, MyContextImportStatementClass))
#define MY_IS_CONTEXT_IMPORT_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_IMPORT_STATEMENT))
#define MY_IS_CONTEXT_IMPORT_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_IMPORT_STATEMENT))
#define MY_CONTEXT_IMPORT_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_IMPORT_STATEMENT, MyContextImportStatementClass))


//typedef struct _MyContextImportStatement      MyContextImportStatement;
typedef struct _MyContextImportStatementClass MyContextImportStatementClass;

struct _MyContextImportStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextImportStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_import_statement_get_type(void) G_GNUC_CONST;
MyContextImportStatement *my_context_import_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_import_statement_token_get_import(MyContextImportStatement* self);
AntlrTerminalNode *my_context_import_statement_token_get_namespace(MyContextImportStatement* self);
MyContextNamespaceNameList *my_context_import_statement_rule_get_namespace_name_list(MyContextImportStatement* self);


MyContextImportStatement* my_php_parser_parse_import_statement(MyPhpParser* self, GError **error);
//----------------- TopStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TOP_STATEMENT            (my_context_top_statement_get_type())
#define MY_CONTEXT_TOP_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TOP_STATEMENT, MyContextTopStatement))
#define MY_CONTEXT_TOP_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TOP_STATEMENT, MyContextTopStatementClass))
#define MY_IS_CONTEXT_TOP_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TOP_STATEMENT))
#define MY_IS_CONTEXT_TOP_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TOP_STATEMENT))
#define MY_CONTEXT_TOP_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TOP_STATEMENT, MyContextTopStatementClass))


//typedef struct _MyContextTopStatement      MyContextTopStatement;
typedef struct _MyContextTopStatementClass MyContextTopStatementClass;

struct _MyContextTopStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTopStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_top_statement_get_type(void) G_GNUC_CONST;
MyContextTopStatement *my_context_top_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextStatement *my_context_top_statement_rule_get_statement(MyContextTopStatement* self);
MyContextUseDeclaration *my_context_top_statement_rule_get_use_declaration(MyContextTopStatement* self);
MyContextNamespaceDeclaration *my_context_top_statement_rule_get_namespace_declaration(MyContextTopStatement* self);
MyContextFunctionDeclaration *my_context_top_statement_rule_get_function_declaration(MyContextTopStatement* self);
MyContextClassDeclaration *my_context_top_statement_rule_get_class_declaration(MyContextTopStatement* self);
MyContextGlobalConstantDeclaration *my_context_top_statement_rule_get_global_constant_declaration(MyContextTopStatement* self);


MyContextTopStatement* my_php_parser_parse_top_statement(MyPhpParser* self, GError **error);
//----------------- UseDeclarationContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_USE_DECLARATION            (my_context_use_declaration_get_type())
#define MY_CONTEXT_USE_DECLARATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_USE_DECLARATION, MyContextUseDeclaration))
#define MY_CONTEXT_USE_DECLARATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_USE_DECLARATION, MyContextUseDeclarationClass))
#define MY_IS_CONTEXT_USE_DECLARATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_USE_DECLARATION))
#define MY_IS_CONTEXT_USE_DECLARATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_USE_DECLARATION))
#define MY_CONTEXT_USE_DECLARATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_USE_DECLARATION, MyContextUseDeclarationClass))


//typedef struct _MyContextUseDeclaration      MyContextUseDeclaration;
typedef struct _MyContextUseDeclarationClass MyContextUseDeclarationClass;

struct _MyContextUseDeclaration {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextUseDeclarationClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_use_declaration_get_type(void) G_GNUC_CONST;
MyContextUseDeclaration *my_context_use_declaration_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_use_declaration_token_get_use(MyContextUseDeclaration* self);
MyContextUseDeclarationContentList *my_context_use_declaration_rule_get_use_declaration_content_list(MyContextUseDeclaration* self);
AntlrTerminalNode *my_context_use_declaration_token_get_function(MyContextUseDeclaration* self);
AntlrTerminalNode *my_context_use_declaration_token_get_const(MyContextUseDeclaration* self);


MyContextUseDeclaration* my_php_parser_parse_use_declaration(MyPhpParser* self, GError **error);
//----------------- UseDeclarationContentListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT_LIST            (my_context_use_declaration_content_list_get_type())
#define MY_CONTEXT_USE_DECLARATION_CONTENT_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT_LIST, MyContextUseDeclarationContentList))
#define MY_CONTEXT_USE_DECLARATION_CONTENT_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT_LIST, MyContextUseDeclarationContentListClass))
#define MY_IS_CONTEXT_USE_DECLARATION_CONTENT_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT_LIST))
#define MY_IS_CONTEXT_USE_DECLARATION_CONTENT_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT_LIST))
#define MY_CONTEXT_USE_DECLARATION_CONTENT_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT_LIST, MyContextUseDeclarationContentListClass))


//typedef struct _MyContextUseDeclarationContentList      MyContextUseDeclarationContentList;
typedef struct _MyContextUseDeclarationContentListClass MyContextUseDeclarationContentListClass;

struct _MyContextUseDeclarationContentList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextUseDeclarationContentListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_use_declaration_content_list_get_type(void) G_GNUC_CONST;
MyContextUseDeclarationContentList *my_context_use_declaration_content_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_use_declaration_content_list_rule_get_use_declaration_content(MyContextUseDeclarationContentList* self);// of MyContextUseDeclarationContent
MyContextUseDeclarationContent* my_context_use_declaration_content_list_at_rule_get_use_declaration_content(MyContextUseDeclarationContentList* self, size_t i);


MyContextUseDeclarationContentList* my_php_parser_parse_use_declaration_content_list(MyPhpParser* self, GError **error);
//----------------- UseDeclarationContentContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT            (my_context_use_declaration_content_get_type())
#define MY_CONTEXT_USE_DECLARATION_CONTENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT, MyContextUseDeclarationContent))
#define MY_CONTEXT_USE_DECLARATION_CONTENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT, MyContextUseDeclarationContentClass))
#define MY_IS_CONTEXT_USE_DECLARATION_CONTENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT))
#define MY_IS_CONTEXT_USE_DECLARATION_CONTENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT))
#define MY_CONTEXT_USE_DECLARATION_CONTENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_USE_DECLARATION_CONTENT, MyContextUseDeclarationContentClass))


//typedef struct _MyContextUseDeclarationContent      MyContextUseDeclarationContent;
typedef struct _MyContextUseDeclarationContentClass MyContextUseDeclarationContentClass;

struct _MyContextUseDeclarationContent {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextUseDeclarationContentClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_use_declaration_content_get_type(void) G_GNUC_CONST;
MyContextUseDeclarationContent *my_context_use_declaration_content_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextNamespaceNameList *my_context_use_declaration_content_rule_get_namespace_name_list(MyContextUseDeclarationContent* self);
AntlrTerminalNode *my_context_use_declaration_content_token_get_as(MyContextUseDeclarationContent* self);
MyContextIdentifier *my_context_use_declaration_content_rule_get_identifier(MyContextUseDeclarationContent* self);


MyContextUseDeclarationContent* my_php_parser_parse_use_declaration_content(MyPhpParser* self, GError **error);
//----------------- NamespaceDeclarationContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_NAMESPACE_DECLARATION            (my_context_namespace_declaration_get_type())
#define MY_CONTEXT_NAMESPACE_DECLARATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_NAMESPACE_DECLARATION, MyContextNamespaceDeclaration))
#define MY_CONTEXT_NAMESPACE_DECLARATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_NAMESPACE_DECLARATION, MyContextNamespaceDeclarationClass))
#define MY_IS_CONTEXT_NAMESPACE_DECLARATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_NAMESPACE_DECLARATION))
#define MY_IS_CONTEXT_NAMESPACE_DECLARATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_NAMESPACE_DECLARATION))
#define MY_CONTEXT_NAMESPACE_DECLARATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_NAMESPACE_DECLARATION, MyContextNamespaceDeclarationClass))


//typedef struct _MyContextNamespaceDeclaration      MyContextNamespaceDeclaration;
typedef struct _MyContextNamespaceDeclarationClass MyContextNamespaceDeclarationClass;

struct _MyContextNamespaceDeclaration {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextNamespaceDeclarationClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_namespace_declaration_get_type(void) G_GNUC_CONST;
MyContextNamespaceDeclaration *my_context_namespace_declaration_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_namespace_declaration_token_get_namespace(MyContextNamespaceDeclaration* self);
AntlrTerminalNode *my_context_namespace_declaration_token_get_open_curly_bracket(MyContextNamespaceDeclaration* self);
MyContextNamespaceNameList *my_context_namespace_declaration_rule_get_namespace_name_list(MyContextNamespaceDeclaration* self);
GList* my_context_namespace_declaration_rule_get_namespace_statement(MyContextNamespaceDeclaration* self);// of MyContextNamespaceStatement
MyContextNamespaceStatement* my_context_namespace_declaration_at_rule_get_namespace_statement(MyContextNamespaceDeclaration* self, size_t i);


MyContextNamespaceDeclaration* my_php_parser_parse_namespace_declaration(MyPhpParser* self, GError **error);
//----------------- NamespaceStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_NAMESPACE_STATEMENT            (my_context_namespace_statement_get_type())
#define MY_CONTEXT_NAMESPACE_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_NAMESPACE_STATEMENT, MyContextNamespaceStatement))
#define MY_CONTEXT_NAMESPACE_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_NAMESPACE_STATEMENT, MyContextNamespaceStatementClass))
#define MY_IS_CONTEXT_NAMESPACE_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_NAMESPACE_STATEMENT))
#define MY_IS_CONTEXT_NAMESPACE_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_NAMESPACE_STATEMENT))
#define MY_CONTEXT_NAMESPACE_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_NAMESPACE_STATEMENT, MyContextNamespaceStatementClass))


//typedef struct _MyContextNamespaceStatement      MyContextNamespaceStatement;
typedef struct _MyContextNamespaceStatementClass MyContextNamespaceStatementClass;

struct _MyContextNamespaceStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextNamespaceStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_namespace_statement_get_type(void) G_GNUC_CONST;
MyContextNamespaceStatement *my_context_namespace_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextStatement *my_context_namespace_statement_rule_get_statement(MyContextNamespaceStatement* self);
MyContextUseDeclaration *my_context_namespace_statement_rule_get_use_declaration(MyContextNamespaceStatement* self);
MyContextFunctionDeclaration *my_context_namespace_statement_rule_get_function_declaration(MyContextNamespaceStatement* self);
MyContextClassDeclaration *my_context_namespace_statement_rule_get_class_declaration(MyContextNamespaceStatement* self);
MyContextGlobalConstantDeclaration *my_context_namespace_statement_rule_get_global_constant_declaration(MyContextNamespaceStatement* self);


MyContextNamespaceStatement* my_php_parser_parse_namespace_statement(MyPhpParser* self, GError **error);
//----------------- FunctionDeclarationContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FUNCTION_DECLARATION            (my_context_function_declaration_get_type())
#define MY_CONTEXT_FUNCTION_DECLARATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FUNCTION_DECLARATION, MyContextFunctionDeclaration))
#define MY_CONTEXT_FUNCTION_DECLARATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FUNCTION_DECLARATION, MyContextFunctionDeclarationClass))
#define MY_IS_CONTEXT_FUNCTION_DECLARATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FUNCTION_DECLARATION))
#define MY_IS_CONTEXT_FUNCTION_DECLARATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FUNCTION_DECLARATION))
#define MY_CONTEXT_FUNCTION_DECLARATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FUNCTION_DECLARATION, MyContextFunctionDeclarationClass))


//typedef struct _MyContextFunctionDeclaration      MyContextFunctionDeclaration;
typedef struct _MyContextFunctionDeclarationClass MyContextFunctionDeclarationClass;

struct _MyContextFunctionDeclaration {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextFunctionDeclarationClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_function_declaration_get_type(void) G_GNUC_CONST;
MyContextFunctionDeclaration *my_context_function_declaration_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextAttributes *my_context_function_declaration_rule_get_attributes(MyContextFunctionDeclaration* self);
AntlrTerminalNode *my_context_function_declaration_token_get_function(MyContextFunctionDeclaration* self);
MyContextIdentifier *my_context_function_declaration_rule_get_identifier(MyContextFunctionDeclaration* self);
MyContextFormalParameterList *my_context_function_declaration_rule_get_formal_parameter_list(MyContextFunctionDeclaration* self);
MyContextBlockStatement *my_context_function_declaration_rule_get_block_statement(MyContextFunctionDeclaration* self);
MyContextTypeParameterListInBrackets *my_context_function_declaration_rule_get_type_parameter_list_in_brackets(MyContextFunctionDeclaration* self);


MyContextFunctionDeclaration* my_php_parser_parse_function_declaration(MyPhpParser* self, GError **error);
//----------------- ClassDeclarationContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CLASS_DECLARATION            (my_context_class_declaration_get_type())
#define MY_CONTEXT_CLASS_DECLARATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CLASS_DECLARATION, MyContextClassDeclaration))
#define MY_CONTEXT_CLASS_DECLARATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CLASS_DECLARATION, MyContextClassDeclarationClass))
#define MY_IS_CONTEXT_CLASS_DECLARATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CLASS_DECLARATION))
#define MY_IS_CONTEXT_CLASS_DECLARATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CLASS_DECLARATION))
#define MY_CONTEXT_CLASS_DECLARATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CLASS_DECLARATION, MyContextClassDeclarationClass))


//typedef struct _MyContextClassDeclaration      MyContextClassDeclaration;
typedef struct _MyContextClassDeclarationClass MyContextClassDeclarationClass;

struct _MyContextClassDeclaration {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextClassDeclarationClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_class_declaration_get_type(void) G_GNUC_CONST;
MyContextClassDeclaration *my_context_class_declaration_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextAttributes *my_context_class_declaration_rule_get_attributes(MyContextClassDeclaration* self);
AntlrTerminalNode *my_context_class_declaration_token_get_open_curly_bracket(MyContextClassDeclaration* self);
MyContextClassEntryType *my_context_class_declaration_rule_get_class_entry_type(MyContextClassDeclaration* self);
MyContextIdentifier *my_context_class_declaration_rule_get_identifier(MyContextClassDeclaration* self);
AntlrTerminalNode *my_context_class_declaration_token_get_interface(MyContextClassDeclaration* self);
AntlrTerminalNode *my_context_class_declaration_token_get_private(MyContextClassDeclaration* self);
MyContextModifier *my_context_class_declaration_rule_get_modifier(MyContextClassDeclaration* self);
AntlrTerminalNode *my_context_class_declaration_token_get_partial(MyContextClassDeclaration* self);
GList* my_context_class_declaration_rule_get_class_statement(MyContextClassDeclaration* self);// of MyContextClassStatement
MyContextClassStatement* my_context_class_declaration_at_rule_get_class_statement(MyContextClassDeclaration* self, size_t i);
MyContextTypeParameterListInBrackets *my_context_class_declaration_rule_get_type_parameter_list_in_brackets(MyContextClassDeclaration* self);
AntlrTerminalNode *my_context_class_declaration_token_get_extends(MyContextClassDeclaration* self);
MyContextQualifiedStaticTypeRef *my_context_class_declaration_rule_get_qualified_static_type_ref(MyContextClassDeclaration* self);
AntlrTerminalNode *my_context_class_declaration_token_get_implements(MyContextClassDeclaration* self);
MyContextInterfaceList *my_context_class_declaration_rule_get_interface_list(MyContextClassDeclaration* self);


MyContextClassDeclaration* my_php_parser_parse_class_declaration(MyPhpParser* self, GError **error);
//----------------- ClassEntryTypeContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CLASS_ENTRY_TYPE            (my_context_class_entry_type_get_type())
#define MY_CONTEXT_CLASS_ENTRY_TYPE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CLASS_ENTRY_TYPE, MyContextClassEntryType))
#define MY_CONTEXT_CLASS_ENTRY_TYPE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CLASS_ENTRY_TYPE, MyContextClassEntryTypeClass))
#define MY_IS_CONTEXT_CLASS_ENTRY_TYPE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CLASS_ENTRY_TYPE))
#define MY_IS_CONTEXT_CLASS_ENTRY_TYPE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CLASS_ENTRY_TYPE))
#define MY_CONTEXT_CLASS_ENTRY_TYPE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CLASS_ENTRY_TYPE, MyContextClassEntryTypeClass))


//typedef struct _MyContextClassEntryType      MyContextClassEntryType;
typedef struct _MyContextClassEntryTypeClass MyContextClassEntryTypeClass;

struct _MyContextClassEntryType {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextClassEntryTypeClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_class_entry_type_get_type(void) G_GNUC_CONST;
MyContextClassEntryType *my_context_class_entry_type_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_class_entry_type_token_get_class(MyContextClassEntryType* self);
AntlrTerminalNode *my_context_class_entry_type_token_get_trait(MyContextClassEntryType* self);


MyContextClassEntryType* my_php_parser_parse_class_entry_type(MyPhpParser* self, GError **error);
//----------------- InterfaceListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_INTERFACE_LIST            (my_context_interface_list_get_type())
#define MY_CONTEXT_INTERFACE_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_INTERFACE_LIST, MyContextInterfaceList))
#define MY_CONTEXT_INTERFACE_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_INTERFACE_LIST, MyContextInterfaceListClass))
#define MY_IS_CONTEXT_INTERFACE_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_INTERFACE_LIST))
#define MY_IS_CONTEXT_INTERFACE_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_INTERFACE_LIST))
#define MY_CONTEXT_INTERFACE_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_INTERFACE_LIST, MyContextInterfaceListClass))


//typedef struct _MyContextInterfaceList      MyContextInterfaceList;
typedef struct _MyContextInterfaceListClass MyContextInterfaceListClass;

struct _MyContextInterfaceList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextInterfaceListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_interface_list_get_type(void) G_GNUC_CONST;
MyContextInterfaceList *my_context_interface_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_interface_list_rule_get_qualified_static_type_ref(MyContextInterfaceList* self);// of MyContextQualifiedStaticTypeRef
MyContextQualifiedStaticTypeRef* my_context_interface_list_at_rule_get_qualified_static_type_ref(MyContextInterfaceList* self, size_t i);


MyContextInterfaceList* my_php_parser_parse_interface_list(MyPhpParser* self, GError **error);
//----------------- TypeParameterListInBracketsContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS            (my_context_type_parameter_list_in_brackets_get_type())
#define MY_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS, MyContextTypeParameterListInBrackets))
#define MY_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS, MyContextTypeParameterListInBracketsClass))
#define MY_IS_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS))
#define MY_IS_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS))
#define MY_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST_IN_BRACKETS, MyContextTypeParameterListInBracketsClass))


//typedef struct _MyContextTypeParameterListInBrackets      MyContextTypeParameterListInBrackets;
typedef struct _MyContextTypeParameterListInBracketsClass MyContextTypeParameterListInBracketsClass;

struct _MyContextTypeParameterListInBrackets {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTypeParameterListInBracketsClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_type_parameter_list_in_brackets_get_type(void) G_GNUC_CONST;
MyContextTypeParameterListInBrackets *my_context_type_parameter_list_in_brackets_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextTypeParameterList *my_context_type_parameter_list_in_brackets_rule_get_type_parameter_list(MyContextTypeParameterListInBrackets* self);
MyContextTypeParameterWithDefaultsList *my_context_type_parameter_list_in_brackets_rule_get_type_parameter_with_defaults_list(MyContextTypeParameterListInBrackets* self);


MyContextTypeParameterListInBrackets* my_php_parser_parse_type_parameter_list_in_brackets(MyPhpParser* self, GError **error);
//----------------- TypeParameterListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST            (my_context_type_parameter_list_get_type())
#define MY_CONTEXT_TYPE_PARAMETER_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST, MyContextTypeParameterList))
#define MY_CONTEXT_TYPE_PARAMETER_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST, MyContextTypeParameterListClass))
#define MY_IS_CONTEXT_TYPE_PARAMETER_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST))
#define MY_IS_CONTEXT_TYPE_PARAMETER_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST))
#define MY_CONTEXT_TYPE_PARAMETER_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TYPE_PARAMETER_LIST, MyContextTypeParameterListClass))


//typedef struct _MyContextTypeParameterList      MyContextTypeParameterList;
typedef struct _MyContextTypeParameterListClass MyContextTypeParameterListClass;

struct _MyContextTypeParameterList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTypeParameterListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_type_parameter_list_get_type(void) G_GNUC_CONST;
MyContextTypeParameterList *my_context_type_parameter_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_type_parameter_list_rule_get_type_parameter_decl(MyContextTypeParameterList* self);// of MyContextTypeParameterDecl
MyContextTypeParameterDecl* my_context_type_parameter_list_at_rule_get_type_parameter_decl(MyContextTypeParameterList* self, size_t i);


MyContextTypeParameterList* my_php_parser_parse_type_parameter_list(MyPhpParser* self, GError **error);
//----------------- TypeParameterWithDefaultsListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST            (my_context_type_parameter_with_defaults_list_get_type())
#define MY_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST, MyContextTypeParameterWithDefaultsList))
#define MY_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST, MyContextTypeParameterWithDefaultsListClass))
#define MY_IS_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST))
#define MY_IS_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST))
#define MY_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULTS_LIST, MyContextTypeParameterWithDefaultsListClass))


//typedef struct _MyContextTypeParameterWithDefaultsList      MyContextTypeParameterWithDefaultsList;
typedef struct _MyContextTypeParameterWithDefaultsListClass MyContextTypeParameterWithDefaultsListClass;

struct _MyContextTypeParameterWithDefaultsList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTypeParameterWithDefaultsListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_type_parameter_with_defaults_list_get_type(void) G_GNUC_CONST;
MyContextTypeParameterWithDefaultsList *my_context_type_parameter_with_defaults_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_type_parameter_with_defaults_list_rule_get_type_parameter_with_default_decl(MyContextTypeParameterWithDefaultsList* self);// of MyContextTypeParameterWithDefaultDecl
MyContextTypeParameterWithDefaultDecl* my_context_type_parameter_with_defaults_list_at_rule_get_type_parameter_with_default_decl(MyContextTypeParameterWithDefaultsList* self, size_t i);


MyContextTypeParameterWithDefaultsList* my_php_parser_parse_type_parameter_with_defaults_list(MyPhpParser* self, GError **error);
//----------------- TypeParameterDeclContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TYPE_PARAMETER_DECL            (my_context_type_parameter_decl_get_type())
#define MY_CONTEXT_TYPE_PARAMETER_DECL(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_DECL, MyContextTypeParameterDecl))
#define MY_CONTEXT_TYPE_PARAMETER_DECL_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_DECL, MyContextTypeParameterDeclClass))
#define MY_IS_CONTEXT_TYPE_PARAMETER_DECL(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_DECL))
#define MY_IS_CONTEXT_TYPE_PARAMETER_DECL_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_DECL))
#define MY_CONTEXT_TYPE_PARAMETER_DECL_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TYPE_PARAMETER_DECL, MyContextTypeParameterDeclClass))


//typedef struct _MyContextTypeParameterDecl      MyContextTypeParameterDecl;
typedef struct _MyContextTypeParameterDeclClass MyContextTypeParameterDeclClass;

struct _MyContextTypeParameterDecl {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTypeParameterDeclClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_type_parameter_decl_get_type(void) G_GNUC_CONST;
MyContextTypeParameterDecl *my_context_type_parameter_decl_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextAttributes *my_context_type_parameter_decl_rule_get_attributes(MyContextTypeParameterDecl* self);
MyContextIdentifier *my_context_type_parameter_decl_rule_get_identifier(MyContextTypeParameterDecl* self);


MyContextTypeParameterDecl* my_php_parser_parse_type_parameter_decl(MyPhpParser* self, GError **error);
//----------------- TypeParameterWithDefaultDeclContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL            (my_context_type_parameter_with_default_decl_get_type())
#define MY_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL, MyContextTypeParameterWithDefaultDecl))
#define MY_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL, MyContextTypeParameterWithDefaultDeclClass))
#define MY_IS_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL))
#define MY_IS_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL))
#define MY_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TYPE_PARAMETER_WITH_DEFAULT_DECL, MyContextTypeParameterWithDefaultDeclClass))


//typedef struct _MyContextTypeParameterWithDefaultDecl      MyContextTypeParameterWithDefaultDecl;
typedef struct _MyContextTypeParameterWithDefaultDeclClass MyContextTypeParameterWithDefaultDeclClass;

struct _MyContextTypeParameterWithDefaultDecl {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTypeParameterWithDefaultDeclClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_type_parameter_with_default_decl_get_type(void) G_GNUC_CONST;
MyContextTypeParameterWithDefaultDecl *my_context_type_parameter_with_default_decl_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextAttributes *my_context_type_parameter_with_default_decl_rule_get_attributes(MyContextTypeParameterWithDefaultDecl* self);
MyContextIdentifier *my_context_type_parameter_with_default_decl_rule_get_identifier(MyContextTypeParameterWithDefaultDecl* self);
AntlrTerminalNode *my_context_type_parameter_with_default_decl_token_get_eq(MyContextTypeParameterWithDefaultDecl* self);
MyContextQualifiedStaticTypeRef *my_context_type_parameter_with_default_decl_rule_get_qualified_static_type_ref(MyContextTypeParameterWithDefaultDecl* self);
MyContextPrimitiveType *my_context_type_parameter_with_default_decl_rule_get_primitive_type(MyContextTypeParameterWithDefaultDecl* self);


MyContextTypeParameterWithDefaultDecl* my_php_parser_parse_type_parameter_with_default_decl(MyPhpParser* self, GError **error);
//----------------- GenericDynamicArgsContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_GENERIC_DYNAMIC_ARGS            (my_context_generic_dynamic_args_get_type())
#define MY_CONTEXT_GENERIC_DYNAMIC_ARGS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_GENERIC_DYNAMIC_ARGS, MyContextGenericDynamicArgs))
#define MY_CONTEXT_GENERIC_DYNAMIC_ARGS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_GENERIC_DYNAMIC_ARGS, MyContextGenericDynamicArgsClass))
#define MY_IS_CONTEXT_GENERIC_DYNAMIC_ARGS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_GENERIC_DYNAMIC_ARGS))
#define MY_IS_CONTEXT_GENERIC_DYNAMIC_ARGS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_GENERIC_DYNAMIC_ARGS))
#define MY_CONTEXT_GENERIC_DYNAMIC_ARGS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_GENERIC_DYNAMIC_ARGS, MyContextGenericDynamicArgsClass))


//typedef struct _MyContextGenericDynamicArgs      MyContextGenericDynamicArgs;
typedef struct _MyContextGenericDynamicArgsClass MyContextGenericDynamicArgsClass;

struct _MyContextGenericDynamicArgs {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextGenericDynamicArgsClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_generic_dynamic_args_get_type(void) G_GNUC_CONST;
MyContextGenericDynamicArgs *my_context_generic_dynamic_args_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_generic_dynamic_args_rule_get_type_ref(MyContextGenericDynamicArgs* self);// of MyContextTypeRef
MyContextTypeRef* my_context_generic_dynamic_args_at_rule_get_type_ref(MyContextGenericDynamicArgs* self, size_t i);


MyContextGenericDynamicArgs* my_php_parser_parse_generic_dynamic_args(MyPhpParser* self, GError **error);
//----------------- AttributesContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ATTRIBUTES            (my_context_attributes_get_type())
#define MY_CONTEXT_ATTRIBUTES(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ATTRIBUTES, MyContextAttributes))
#define MY_CONTEXT_ATTRIBUTES_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ATTRIBUTES, MyContextAttributesClass))
#define MY_IS_CONTEXT_ATTRIBUTES(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ATTRIBUTES))
#define MY_IS_CONTEXT_ATTRIBUTES_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ATTRIBUTES))
#define MY_CONTEXT_ATTRIBUTES_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ATTRIBUTES, MyContextAttributesClass))


//typedef struct _MyContextAttributes      MyContextAttributes;
typedef struct _MyContextAttributesClass MyContextAttributesClass;

struct _MyContextAttributes {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAttributesClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_attributes_get_type(void) G_GNUC_CONST;
MyContextAttributes *my_context_attributes_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_attributes_rule_get_attributes_group(MyContextAttributes* self);// of MyContextAttributesGroup
MyContextAttributesGroup* my_context_attributes_at_rule_get_attributes_group(MyContextAttributes* self, size_t i);


MyContextAttributes* my_php_parser_parse_attributes(MyPhpParser* self, GError **error);
//----------------- AttributesGroupContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ATTRIBUTES_GROUP            (my_context_attributes_group_get_type())
#define MY_CONTEXT_ATTRIBUTES_GROUP(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ATTRIBUTES_GROUP, MyContextAttributesGroup))
#define MY_CONTEXT_ATTRIBUTES_GROUP_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ATTRIBUTES_GROUP, MyContextAttributesGroupClass))
#define MY_IS_CONTEXT_ATTRIBUTES_GROUP(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ATTRIBUTES_GROUP))
#define MY_IS_CONTEXT_ATTRIBUTES_GROUP_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ATTRIBUTES_GROUP))
#define MY_CONTEXT_ATTRIBUTES_GROUP_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ATTRIBUTES_GROUP, MyContextAttributesGroupClass))


//typedef struct _MyContextAttributesGroup      MyContextAttributesGroup;
typedef struct _MyContextAttributesGroupClass MyContextAttributesGroupClass;

struct _MyContextAttributesGroup {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAttributesGroupClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_attributes_group_get_type(void) G_GNUC_CONST;
MyContextAttributesGroup *my_context_attributes_group_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_attributes_group_rule_get_attribute(MyContextAttributesGroup* self);// of MyContextAttribute
MyContextAttribute* my_context_attributes_group_at_rule_get_attribute(MyContextAttributesGroup* self, size_t i);
MyContextIdentifier *my_context_attributes_group_rule_get_identifier(MyContextAttributesGroup* self);


MyContextAttributesGroup* my_php_parser_parse_attributes_group(MyPhpParser* self, GError **error);
//----------------- AttributeContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ATTRIBUTE            (my_context_attribute_get_type())
#define MY_CONTEXT_ATTRIBUTE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ATTRIBUTE, MyContextAttribute))
#define MY_CONTEXT_ATTRIBUTE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ATTRIBUTE, MyContextAttributeClass))
#define MY_IS_CONTEXT_ATTRIBUTE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ATTRIBUTE))
#define MY_IS_CONTEXT_ATTRIBUTE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ATTRIBUTE))
#define MY_CONTEXT_ATTRIBUTE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ATTRIBUTE, MyContextAttributeClass))


//typedef struct _MyContextAttribute      MyContextAttribute;
typedef struct _MyContextAttributeClass MyContextAttributeClass;

struct _MyContextAttribute {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAttributeClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_attribute_get_type(void) G_GNUC_CONST;
MyContextAttribute *my_context_attribute_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextQualifiedNamespaceName *my_context_attribute_rule_get_qualified_namespace_name(MyContextAttribute* self);
MyContextAttributeArgList *my_context_attribute_rule_get_attribute_arg_list(MyContextAttribute* self);
MyContextAttributeNamedArgList *my_context_attribute_rule_get_attribute_named_arg_list(MyContextAttribute* self);


MyContextAttribute* my_php_parser_parse_attribute(MyPhpParser* self, GError **error);
//----------------- AttributeArgListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ATTRIBUTE_ARG_LIST            (my_context_attribute_arg_list_get_type())
#define MY_CONTEXT_ATTRIBUTE_ARG_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ATTRIBUTE_ARG_LIST, MyContextAttributeArgList))
#define MY_CONTEXT_ATTRIBUTE_ARG_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ATTRIBUTE_ARG_LIST, MyContextAttributeArgListClass))
#define MY_IS_CONTEXT_ATTRIBUTE_ARG_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ATTRIBUTE_ARG_LIST))
#define MY_IS_CONTEXT_ATTRIBUTE_ARG_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ATTRIBUTE_ARG_LIST))
#define MY_CONTEXT_ATTRIBUTE_ARG_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ATTRIBUTE_ARG_LIST, MyContextAttributeArgListClass))


//typedef struct _MyContextAttributeArgList      MyContextAttributeArgList;
typedef struct _MyContextAttributeArgListClass MyContextAttributeArgListClass;

struct _MyContextAttributeArgList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAttributeArgListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_attribute_arg_list_get_type(void) G_GNUC_CONST;
MyContextAttributeArgList *my_context_attribute_arg_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_attribute_arg_list_rule_get_expression(MyContextAttributeArgList* self);// of MyContextExpression
MyContextExpression* my_context_attribute_arg_list_at_rule_get_expression(MyContextAttributeArgList* self, size_t i);


MyContextAttributeArgList* my_php_parser_parse_attribute_arg_list(MyPhpParser* self, GError **error);
//----------------- AttributeNamedArgListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST            (my_context_attribute_named_arg_list_get_type())
#define MY_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST, MyContextAttributeNamedArgList))
#define MY_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST, MyContextAttributeNamedArgListClass))
#define MY_IS_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST))
#define MY_IS_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST))
#define MY_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG_LIST, MyContextAttributeNamedArgListClass))


//typedef struct _MyContextAttributeNamedArgList      MyContextAttributeNamedArgList;
typedef struct _MyContextAttributeNamedArgListClass MyContextAttributeNamedArgListClass;

struct _MyContextAttributeNamedArgList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAttributeNamedArgListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_attribute_named_arg_list_get_type(void) G_GNUC_CONST;
MyContextAttributeNamedArgList *my_context_attribute_named_arg_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_attribute_named_arg_list_rule_get_attribute_named_arg(MyContextAttributeNamedArgList* self);// of MyContextAttributeNamedArg
MyContextAttributeNamedArg* my_context_attribute_named_arg_list_at_rule_get_attribute_named_arg(MyContextAttributeNamedArgList* self, size_t i);


MyContextAttributeNamedArgList* my_php_parser_parse_attribute_named_arg_list(MyPhpParser* self, GError **error);
//----------------- AttributeNamedArgContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG            (my_context_attribute_named_arg_get_type())
#define MY_CONTEXT_ATTRIBUTE_NAMED_ARG(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG, MyContextAttributeNamedArg))
#define MY_CONTEXT_ATTRIBUTE_NAMED_ARG_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG, MyContextAttributeNamedArgClass))
#define MY_IS_CONTEXT_ATTRIBUTE_NAMED_ARG(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG))
#define MY_IS_CONTEXT_ATTRIBUTE_NAMED_ARG_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG))
#define MY_CONTEXT_ATTRIBUTE_NAMED_ARG_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ATTRIBUTE_NAMED_ARG, MyContextAttributeNamedArgClass))


//typedef struct _MyContextAttributeNamedArg      MyContextAttributeNamedArg;
typedef struct _MyContextAttributeNamedArgClass MyContextAttributeNamedArgClass;

struct _MyContextAttributeNamedArg {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAttributeNamedArgClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_attribute_named_arg_get_type(void) G_GNUC_CONST;
MyContextAttributeNamedArg *my_context_attribute_named_arg_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_attribute_named_arg_token_get_var_name(MyContextAttributeNamedArg* self);
MyContextExpression *my_context_attribute_named_arg_rule_get_expression(MyContextAttributeNamedArg* self);


MyContextAttributeNamedArg* my_php_parser_parse_attribute_named_arg(MyPhpParser* self, GError **error);
//----------------- InnerStatementListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_INNER_STATEMENT_LIST            (my_context_inner_statement_list_get_type())
#define MY_CONTEXT_INNER_STATEMENT_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_INNER_STATEMENT_LIST, MyContextInnerStatementList))
#define MY_CONTEXT_INNER_STATEMENT_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_INNER_STATEMENT_LIST, MyContextInnerStatementListClass))
#define MY_IS_CONTEXT_INNER_STATEMENT_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_INNER_STATEMENT_LIST))
#define MY_IS_CONTEXT_INNER_STATEMENT_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_INNER_STATEMENT_LIST))
#define MY_CONTEXT_INNER_STATEMENT_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_INNER_STATEMENT_LIST, MyContextInnerStatementListClass))


//typedef struct _MyContextInnerStatementList      MyContextInnerStatementList;
typedef struct _MyContextInnerStatementListClass MyContextInnerStatementListClass;

struct _MyContextInnerStatementList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextInnerStatementListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_inner_statement_list_get_type(void) G_GNUC_CONST;
MyContextInnerStatementList *my_context_inner_statement_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_inner_statement_list_rule_get_inner_statement(MyContextInnerStatementList* self);// of MyContextInnerStatement
MyContextInnerStatement* my_context_inner_statement_list_at_rule_get_inner_statement(MyContextInnerStatementList* self, size_t i);


MyContextInnerStatementList* my_php_parser_parse_inner_statement_list(MyPhpParser* self, GError **error);
//----------------- InnerStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_INNER_STATEMENT            (my_context_inner_statement_get_type())
#define MY_CONTEXT_INNER_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_INNER_STATEMENT, MyContextInnerStatement))
#define MY_CONTEXT_INNER_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_INNER_STATEMENT, MyContextInnerStatementClass))
#define MY_IS_CONTEXT_INNER_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_INNER_STATEMENT))
#define MY_IS_CONTEXT_INNER_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_INNER_STATEMENT))
#define MY_CONTEXT_INNER_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_INNER_STATEMENT, MyContextInnerStatementClass))


//typedef struct _MyContextInnerStatement      MyContextInnerStatement;
typedef struct _MyContextInnerStatementClass MyContextInnerStatementClass;

struct _MyContextInnerStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextInnerStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_inner_statement_get_type(void) G_GNUC_CONST;
MyContextInnerStatement *my_context_inner_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextStatement *my_context_inner_statement_rule_get_statement(MyContextInnerStatement* self);
MyContextFunctionDeclaration *my_context_inner_statement_rule_get_function_declaration(MyContextInnerStatement* self);
MyContextClassDeclaration *my_context_inner_statement_rule_get_class_declaration(MyContextInnerStatement* self);


MyContextInnerStatement* my_php_parser_parse_inner_statement(MyPhpParser* self, GError **error);
//----------------- StatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_STATEMENT            (my_context_statement_get_type())
#define MY_CONTEXT_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_STATEMENT, MyContextStatement))
#define MY_CONTEXT_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_STATEMENT, MyContextStatementClass))
#define MY_IS_CONTEXT_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_STATEMENT))
#define MY_IS_CONTEXT_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_STATEMENT))
#define MY_CONTEXT_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_STATEMENT, MyContextStatementClass))


//typedef struct _MyContextStatement      MyContextStatement;
typedef struct _MyContextStatementClass MyContextStatementClass;

struct _MyContextStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_statement_get_type(void) G_GNUC_CONST;
MyContextStatement *my_context_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextIdentifier *my_context_statement_rule_get_identifier(MyContextStatement* self);
MyContextBlockStatement *my_context_statement_rule_get_block_statement(MyContextStatement* self);
MyContextIfStatement *my_context_statement_rule_get_if_statement(MyContextStatement* self);
MyContextWhileStatement *my_context_statement_rule_get_while_statement(MyContextStatement* self);
MyContextDoWhileStatement *my_context_statement_rule_get_do_while_statement(MyContextStatement* self);
MyContextForStatement *my_context_statement_rule_get_for_statement(MyContextStatement* self);
MyContextSwitchStatement *my_context_statement_rule_get_switch_statement(MyContextStatement* self);
MyContextBreakStatement *my_context_statement_rule_get_break_statement(MyContextStatement* self);
MyContextContinueStatement *my_context_statement_rule_get_continue_statement(MyContextStatement* self);
MyContextReturnStatement *my_context_statement_rule_get_return_statement(MyContextStatement* self);
MyContextYieldExpression *my_context_statement_rule_get_yield_expression(MyContextStatement* self);
MyContextGlobalStatement *my_context_statement_rule_get_global_statement(MyContextStatement* self);
MyContextStaticVariableStatement *my_context_statement_rule_get_static_variable_statement(MyContextStatement* self);
MyContextEchoStatement *my_context_statement_rule_get_echo_statement(MyContextStatement* self);
MyContextExpressionStatement *my_context_statement_rule_get_expression_statement(MyContextStatement* self);
MyContextUnsetStatement *my_context_statement_rule_get_unset_statement(MyContextStatement* self);
MyContextForeachStatement *my_context_statement_rule_get_foreach_statement(MyContextStatement* self);
MyContextTryCatchFinally *my_context_statement_rule_get_try_catch_finally(MyContextStatement* self);
MyContextThrowStatement *my_context_statement_rule_get_throw_statement(MyContextStatement* self);
MyContextGotoStatement *my_context_statement_rule_get_goto_statement(MyContextStatement* self);
MyContextDeclareStatement *my_context_statement_rule_get_declare_statement(MyContextStatement* self);
MyContextEmptyStatement *my_context_statement_rule_get_empty_statement(MyContextStatement* self);
MyContextInlineHtmlStatement *my_context_statement_rule_get_inline_html_statement(MyContextStatement* self);


MyContextStatement* my_php_parser_parse_statement(MyPhpParser* self, GError **error);
//----------------- EmptyStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_EMPTY_STATEMENT            (my_context_empty_statement_get_type())
#define MY_CONTEXT_EMPTY_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_EMPTY_STATEMENT, MyContextEmptyStatement))
#define MY_CONTEXT_EMPTY_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_EMPTY_STATEMENT, MyContextEmptyStatementClass))
#define MY_IS_CONTEXT_EMPTY_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_EMPTY_STATEMENT))
#define MY_IS_CONTEXT_EMPTY_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_EMPTY_STATEMENT))
#define MY_CONTEXT_EMPTY_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_EMPTY_STATEMENT, MyContextEmptyStatementClass))


//typedef struct _MyContextEmptyStatement      MyContextEmptyStatement;
typedef struct _MyContextEmptyStatementClass MyContextEmptyStatementClass;

struct _MyContextEmptyStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextEmptyStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_empty_statement_get_type(void) G_GNUC_CONST;
MyContextEmptyStatement *my_context_empty_statement_new(AntlrParserRuleContext *parent, size_t invokingState);



MyContextEmptyStatement* my_php_parser_parse_empty_statement(MyPhpParser* self, GError **error);
//----------------- BlockStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_BLOCK_STATEMENT            (my_context_block_statement_get_type())
#define MY_CONTEXT_BLOCK_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_BLOCK_STATEMENT, MyContextBlockStatement))
#define MY_CONTEXT_BLOCK_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_BLOCK_STATEMENT, MyContextBlockStatementClass))
#define MY_IS_CONTEXT_BLOCK_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_BLOCK_STATEMENT))
#define MY_IS_CONTEXT_BLOCK_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_BLOCK_STATEMENT))
#define MY_CONTEXT_BLOCK_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_BLOCK_STATEMENT, MyContextBlockStatementClass))


//typedef struct _MyContextBlockStatement      MyContextBlockStatement;
typedef struct _MyContextBlockStatementClass MyContextBlockStatementClass;

struct _MyContextBlockStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextBlockStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_block_statement_get_type(void) G_GNUC_CONST;
MyContextBlockStatement *my_context_block_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_block_statement_token_get_open_curly_bracket(MyContextBlockStatement* self);
MyContextInnerStatementList *my_context_block_statement_rule_get_inner_statement_list(MyContextBlockStatement* self);


MyContextBlockStatement* my_php_parser_parse_block_statement(MyPhpParser* self, GError **error);
//----------------- IfStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_IF_STATEMENT            (my_context_if_statement_get_type())
#define MY_CONTEXT_IF_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_IF_STATEMENT, MyContextIfStatement))
#define MY_CONTEXT_IF_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_IF_STATEMENT, MyContextIfStatementClass))
#define MY_IS_CONTEXT_IF_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_IF_STATEMENT))
#define MY_IS_CONTEXT_IF_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_IF_STATEMENT))
#define MY_CONTEXT_IF_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_IF_STATEMENT, MyContextIfStatementClass))


//typedef struct _MyContextIfStatement      MyContextIfStatement;
typedef struct _MyContextIfStatementClass MyContextIfStatementClass;

struct _MyContextIfStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextIfStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_if_statement_get_type(void) G_GNUC_CONST;
MyContextIfStatement *my_context_if_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_if_statement_token_get_if(MyContextIfStatement* self);
MyContextParenthesis *my_context_if_statement_rule_get_parenthesis(MyContextIfStatement* self);
MyContextStatement *my_context_if_statement_rule_get_statement(MyContextIfStatement* self);
GList* my_context_if_statement_rule_get_else_if_statement(MyContextIfStatement* self);// of MyContextElseIfStatement
MyContextElseIfStatement* my_context_if_statement_at_rule_get_else_if_statement(MyContextIfStatement* self, size_t i);
MyContextElseStatement *my_context_if_statement_rule_get_else_statement(MyContextIfStatement* self);
MyContextInnerStatementList *my_context_if_statement_rule_get_inner_statement_list(MyContextIfStatement* self);
AntlrTerminalNode *my_context_if_statement_token_get_end_if(MyContextIfStatement* self);
GList* my_context_if_statement_rule_get_else_if_colon_statement(MyContextIfStatement* self);// of MyContextElseIfColonStatement
MyContextElseIfColonStatement* my_context_if_statement_at_rule_get_else_if_colon_statement(MyContextIfStatement* self, size_t i);
MyContextElseColonStatement *my_context_if_statement_rule_get_else_colon_statement(MyContextIfStatement* self);


MyContextIfStatement* my_php_parser_parse_if_statement(MyPhpParser* self, GError **error);
//----------------- ElseIfStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ELSE_IF_STATEMENT            (my_context_else_if_statement_get_type())
#define MY_CONTEXT_ELSE_IF_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ELSE_IF_STATEMENT, MyContextElseIfStatement))
#define MY_CONTEXT_ELSE_IF_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ELSE_IF_STATEMENT, MyContextElseIfStatementClass))
#define MY_IS_CONTEXT_ELSE_IF_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ELSE_IF_STATEMENT))
#define MY_IS_CONTEXT_ELSE_IF_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ELSE_IF_STATEMENT))
#define MY_CONTEXT_ELSE_IF_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ELSE_IF_STATEMENT, MyContextElseIfStatementClass))


//typedef struct _MyContextElseIfStatement      MyContextElseIfStatement;
typedef struct _MyContextElseIfStatementClass MyContextElseIfStatementClass;

struct _MyContextElseIfStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextElseIfStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_else_if_statement_get_type(void) G_GNUC_CONST;
MyContextElseIfStatement *my_context_else_if_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_else_if_statement_token_get_else_if(MyContextElseIfStatement* self);
MyContextParenthesis *my_context_else_if_statement_rule_get_parenthesis(MyContextElseIfStatement* self);
MyContextStatement *my_context_else_if_statement_rule_get_statement(MyContextElseIfStatement* self);


MyContextElseIfStatement* my_php_parser_parse_else_if_statement(MyPhpParser* self, GError **error);
//----------------- ElseIfColonStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ELSE_IF_COLON_STATEMENT            (my_context_else_if_colon_statement_get_type())
#define MY_CONTEXT_ELSE_IF_COLON_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ELSE_IF_COLON_STATEMENT, MyContextElseIfColonStatement))
#define MY_CONTEXT_ELSE_IF_COLON_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ELSE_IF_COLON_STATEMENT, MyContextElseIfColonStatementClass))
#define MY_IS_CONTEXT_ELSE_IF_COLON_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ELSE_IF_COLON_STATEMENT))
#define MY_IS_CONTEXT_ELSE_IF_COLON_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ELSE_IF_COLON_STATEMENT))
#define MY_CONTEXT_ELSE_IF_COLON_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ELSE_IF_COLON_STATEMENT, MyContextElseIfColonStatementClass))


//typedef struct _MyContextElseIfColonStatement      MyContextElseIfColonStatement;
typedef struct _MyContextElseIfColonStatementClass MyContextElseIfColonStatementClass;

struct _MyContextElseIfColonStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextElseIfColonStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_else_if_colon_statement_get_type(void) G_GNUC_CONST;
MyContextElseIfColonStatement *my_context_else_if_colon_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_else_if_colon_statement_token_get_else_if(MyContextElseIfColonStatement* self);
MyContextParenthesis *my_context_else_if_colon_statement_rule_get_parenthesis(MyContextElseIfColonStatement* self);
MyContextInnerStatementList *my_context_else_if_colon_statement_rule_get_inner_statement_list(MyContextElseIfColonStatement* self);


MyContextElseIfColonStatement* my_php_parser_parse_else_if_colon_statement(MyPhpParser* self, GError **error);
//----------------- ElseStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ELSE_STATEMENT            (my_context_else_statement_get_type())
#define MY_CONTEXT_ELSE_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ELSE_STATEMENT, MyContextElseStatement))
#define MY_CONTEXT_ELSE_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ELSE_STATEMENT, MyContextElseStatementClass))
#define MY_IS_CONTEXT_ELSE_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ELSE_STATEMENT))
#define MY_IS_CONTEXT_ELSE_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ELSE_STATEMENT))
#define MY_CONTEXT_ELSE_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ELSE_STATEMENT, MyContextElseStatementClass))


//typedef struct _MyContextElseStatement      MyContextElseStatement;
typedef struct _MyContextElseStatementClass MyContextElseStatementClass;

struct _MyContextElseStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextElseStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_else_statement_get_type(void) G_GNUC_CONST;
MyContextElseStatement *my_context_else_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_else_statement_token_get_else(MyContextElseStatement* self);
MyContextStatement *my_context_else_statement_rule_get_statement(MyContextElseStatement* self);


MyContextElseStatement* my_php_parser_parse_else_statement(MyPhpParser* self, GError **error);
//----------------- ElseColonStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ELSE_COLON_STATEMENT            (my_context_else_colon_statement_get_type())
#define MY_CONTEXT_ELSE_COLON_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ELSE_COLON_STATEMENT, MyContextElseColonStatement))
#define MY_CONTEXT_ELSE_COLON_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ELSE_COLON_STATEMENT, MyContextElseColonStatementClass))
#define MY_IS_CONTEXT_ELSE_COLON_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ELSE_COLON_STATEMENT))
#define MY_IS_CONTEXT_ELSE_COLON_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ELSE_COLON_STATEMENT))
#define MY_CONTEXT_ELSE_COLON_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ELSE_COLON_STATEMENT, MyContextElseColonStatementClass))


//typedef struct _MyContextElseColonStatement      MyContextElseColonStatement;
typedef struct _MyContextElseColonStatementClass MyContextElseColonStatementClass;

struct _MyContextElseColonStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextElseColonStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_else_colon_statement_get_type(void) G_GNUC_CONST;
MyContextElseColonStatement *my_context_else_colon_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_else_colon_statement_token_get_else(MyContextElseColonStatement* self);
MyContextInnerStatementList *my_context_else_colon_statement_rule_get_inner_statement_list(MyContextElseColonStatement* self);


MyContextElseColonStatement* my_php_parser_parse_else_colon_statement(MyPhpParser* self, GError **error);
//----------------- WhileStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_WHILE_STATEMENT            (my_context_while_statement_get_type())
#define MY_CONTEXT_WHILE_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_WHILE_STATEMENT, MyContextWhileStatement))
#define MY_CONTEXT_WHILE_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_WHILE_STATEMENT, MyContextWhileStatementClass))
#define MY_IS_CONTEXT_WHILE_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_WHILE_STATEMENT))
#define MY_IS_CONTEXT_WHILE_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_WHILE_STATEMENT))
#define MY_CONTEXT_WHILE_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_WHILE_STATEMENT, MyContextWhileStatementClass))


//typedef struct _MyContextWhileStatement      MyContextWhileStatement;
typedef struct _MyContextWhileStatementClass MyContextWhileStatementClass;

struct _MyContextWhileStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextWhileStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_while_statement_get_type(void) G_GNUC_CONST;
MyContextWhileStatement *my_context_while_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_while_statement_token_get_while(MyContextWhileStatement* self);
MyContextParenthesis *my_context_while_statement_rule_get_parenthesis(MyContextWhileStatement* self);
MyContextStatement *my_context_while_statement_rule_get_statement(MyContextWhileStatement* self);
MyContextInnerStatementList *my_context_while_statement_rule_get_inner_statement_list(MyContextWhileStatement* self);
AntlrTerminalNode *my_context_while_statement_token_get_end_while(MyContextWhileStatement* self);


MyContextWhileStatement* my_php_parser_parse_while_statement(MyPhpParser* self, GError **error);
//----------------- DoWhileStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_DO_WHILE_STATEMENT            (my_context_do_while_statement_get_type())
#define MY_CONTEXT_DO_WHILE_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_DO_WHILE_STATEMENT, MyContextDoWhileStatement))
#define MY_CONTEXT_DO_WHILE_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_DO_WHILE_STATEMENT, MyContextDoWhileStatementClass))
#define MY_IS_CONTEXT_DO_WHILE_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_DO_WHILE_STATEMENT))
#define MY_IS_CONTEXT_DO_WHILE_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_DO_WHILE_STATEMENT))
#define MY_CONTEXT_DO_WHILE_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_DO_WHILE_STATEMENT, MyContextDoWhileStatementClass))


//typedef struct _MyContextDoWhileStatement      MyContextDoWhileStatement;
typedef struct _MyContextDoWhileStatementClass MyContextDoWhileStatementClass;

struct _MyContextDoWhileStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextDoWhileStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_do_while_statement_get_type(void) G_GNUC_CONST;
MyContextDoWhileStatement *my_context_do_while_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_do_while_statement_token_get_do(MyContextDoWhileStatement* self);
MyContextStatement *my_context_do_while_statement_rule_get_statement(MyContextDoWhileStatement* self);
AntlrTerminalNode *my_context_do_while_statement_token_get_while(MyContextDoWhileStatement* self);
MyContextParenthesis *my_context_do_while_statement_rule_get_parenthesis(MyContextDoWhileStatement* self);


MyContextDoWhileStatement* my_php_parser_parse_do_while_statement(MyPhpParser* self, GError **error);
//----------------- ForStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FOR_STATEMENT            (my_context_for_statement_get_type())
#define MY_CONTEXT_FOR_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FOR_STATEMENT, MyContextForStatement))
#define MY_CONTEXT_FOR_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FOR_STATEMENT, MyContextForStatementClass))
#define MY_IS_CONTEXT_FOR_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FOR_STATEMENT))
#define MY_IS_CONTEXT_FOR_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FOR_STATEMENT))
#define MY_CONTEXT_FOR_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FOR_STATEMENT, MyContextForStatementClass))


//typedef struct _MyContextForStatement      MyContextForStatement;
typedef struct _MyContextForStatementClass MyContextForStatementClass;

struct _MyContextForStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextForStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_for_statement_get_type(void) G_GNUC_CONST;
MyContextForStatement *my_context_for_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_for_statement_token_get_for(MyContextForStatement* self);
MyContextStatement *my_context_for_statement_rule_get_statement(MyContextForStatement* self);
MyContextInnerStatementList *my_context_for_statement_rule_get_inner_statement_list(MyContextForStatement* self);
AntlrTerminalNode *my_context_for_statement_token_get_end_for(MyContextForStatement* self);
MyContextForInit *my_context_for_statement_rule_get_for_init(MyContextForStatement* self);
MyContextExpressionList *my_context_for_statement_rule_get_expression_list(MyContextForStatement* self);
MyContextForUpdate *my_context_for_statement_rule_get_for_update(MyContextForStatement* self);


MyContextForStatement* my_php_parser_parse_for_statement(MyPhpParser* self, GError **error);
//----------------- ForInitContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FOR_INIT            (my_context_for_init_get_type())
#define MY_CONTEXT_FOR_INIT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FOR_INIT, MyContextForInit))
#define MY_CONTEXT_FOR_INIT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FOR_INIT, MyContextForInitClass))
#define MY_IS_CONTEXT_FOR_INIT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FOR_INIT))
#define MY_IS_CONTEXT_FOR_INIT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FOR_INIT))
#define MY_CONTEXT_FOR_INIT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FOR_INIT, MyContextForInitClass))


//typedef struct _MyContextForInit      MyContextForInit;
typedef struct _MyContextForInitClass MyContextForInitClass;

struct _MyContextForInit {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextForInitClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_for_init_get_type(void) G_GNUC_CONST;
MyContextForInit *my_context_for_init_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextExpressionList *my_context_for_init_rule_get_expression_list(MyContextForInit* self);


MyContextForInit* my_php_parser_parse_for_init(MyPhpParser* self, GError **error);
//----------------- ForUpdateContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FOR_UPDATE            (my_context_for_update_get_type())
#define MY_CONTEXT_FOR_UPDATE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FOR_UPDATE, MyContextForUpdate))
#define MY_CONTEXT_FOR_UPDATE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FOR_UPDATE, MyContextForUpdateClass))
#define MY_IS_CONTEXT_FOR_UPDATE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FOR_UPDATE))
#define MY_IS_CONTEXT_FOR_UPDATE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FOR_UPDATE))
#define MY_CONTEXT_FOR_UPDATE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FOR_UPDATE, MyContextForUpdateClass))


//typedef struct _MyContextForUpdate      MyContextForUpdate;
typedef struct _MyContextForUpdateClass MyContextForUpdateClass;

struct _MyContextForUpdate {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextForUpdateClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_for_update_get_type(void) G_GNUC_CONST;
MyContextForUpdate *my_context_for_update_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextExpressionList *my_context_for_update_rule_get_expression_list(MyContextForUpdate* self);


MyContextForUpdate* my_php_parser_parse_for_update(MyPhpParser* self, GError **error);
//----------------- SwitchStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_SWITCH_STATEMENT            (my_context_switch_statement_get_type())
#define MY_CONTEXT_SWITCH_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_SWITCH_STATEMENT, MyContextSwitchStatement))
#define MY_CONTEXT_SWITCH_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_SWITCH_STATEMENT, MyContextSwitchStatementClass))
#define MY_IS_CONTEXT_SWITCH_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_SWITCH_STATEMENT))
#define MY_IS_CONTEXT_SWITCH_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_SWITCH_STATEMENT))
#define MY_CONTEXT_SWITCH_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_SWITCH_STATEMENT, MyContextSwitchStatementClass))


//typedef struct _MyContextSwitchStatement      MyContextSwitchStatement;
typedef struct _MyContextSwitchStatementClass MyContextSwitchStatementClass;

struct _MyContextSwitchStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextSwitchStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_switch_statement_get_type(void) G_GNUC_CONST;
MyContextSwitchStatement *my_context_switch_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_switch_statement_token_get_switch(MyContextSwitchStatement* self);
MyContextParenthesis *my_context_switch_statement_rule_get_parenthesis(MyContextSwitchStatement* self);
AntlrTerminalNode *my_context_switch_statement_token_get_open_curly_bracket(MyContextSwitchStatement* self);
AntlrTerminalNode *my_context_switch_statement_token_get_end_switch(MyContextSwitchStatement* self);
GList* my_context_switch_statement_rule_get_switch_block(MyContextSwitchStatement* self);// of MyContextSwitchBlock
MyContextSwitchBlock* my_context_switch_statement_at_rule_get_switch_block(MyContextSwitchStatement* self, size_t i);


MyContextSwitchStatement* my_php_parser_parse_switch_statement(MyPhpParser* self, GError **error);
//----------------- SwitchBlockContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_SWITCH_BLOCK            (my_context_switch_block_get_type())
#define MY_CONTEXT_SWITCH_BLOCK(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_SWITCH_BLOCK, MyContextSwitchBlock))
#define MY_CONTEXT_SWITCH_BLOCK_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_SWITCH_BLOCK, MyContextSwitchBlockClass))
#define MY_IS_CONTEXT_SWITCH_BLOCK(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_SWITCH_BLOCK))
#define MY_IS_CONTEXT_SWITCH_BLOCK_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_SWITCH_BLOCK))
#define MY_CONTEXT_SWITCH_BLOCK_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_SWITCH_BLOCK, MyContextSwitchBlockClass))


//typedef struct _MyContextSwitchBlock      MyContextSwitchBlock;
typedef struct _MyContextSwitchBlockClass MyContextSwitchBlockClass;

struct _MyContextSwitchBlock {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextSwitchBlockClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_switch_block_get_type(void) G_GNUC_CONST;
MyContextSwitchBlock *my_context_switch_block_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextInnerStatementList *my_context_switch_block_rule_get_inner_statement_list(MyContextSwitchBlock* self);
GList* my_context_switch_block_token_get_case(MyContextSwitchBlock* self);// of AntlrTerminalNode*
AntlrTerminalNode *my_context_switch_block_at_token_get_case(MyContextSwitchBlock* self, size_t i);
GList* my_context_switch_block_rule_get_expression(MyContextSwitchBlock* self);// of MyContextExpression
MyContextExpression* my_context_switch_block_at_rule_get_expression(MyContextSwitchBlock* self, size_t i);
GList* my_context_switch_block_token_get_default(MyContextSwitchBlock* self);// of AntlrTerminalNode*
AntlrTerminalNode *my_context_switch_block_at_token_get_default(MyContextSwitchBlock* self, size_t i);


MyContextSwitchBlock* my_php_parser_parse_switch_block(MyPhpParser* self, GError **error);
//----------------- BreakStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_BREAK_STATEMENT            (my_context_break_statement_get_type())
#define MY_CONTEXT_BREAK_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_BREAK_STATEMENT, MyContextBreakStatement))
#define MY_CONTEXT_BREAK_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_BREAK_STATEMENT, MyContextBreakStatementClass))
#define MY_IS_CONTEXT_BREAK_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_BREAK_STATEMENT))
#define MY_IS_CONTEXT_BREAK_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_BREAK_STATEMENT))
#define MY_CONTEXT_BREAK_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_BREAK_STATEMENT, MyContextBreakStatementClass))


//typedef struct _MyContextBreakStatement      MyContextBreakStatement;
typedef struct _MyContextBreakStatementClass MyContextBreakStatementClass;

struct _MyContextBreakStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextBreakStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_break_statement_get_type(void) G_GNUC_CONST;
MyContextBreakStatement *my_context_break_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_break_statement_token_get_break(MyContextBreakStatement* self);
MyContextExpression *my_context_break_statement_rule_get_expression(MyContextBreakStatement* self);


MyContextBreakStatement* my_php_parser_parse_break_statement(MyPhpParser* self, GError **error);
//----------------- ContinueStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CONTINUE_STATEMENT            (my_context_continue_statement_get_type())
#define MY_CONTEXT_CONTINUE_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CONTINUE_STATEMENT, MyContextContinueStatement))
#define MY_CONTEXT_CONTINUE_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CONTINUE_STATEMENT, MyContextContinueStatementClass))
#define MY_IS_CONTEXT_CONTINUE_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CONTINUE_STATEMENT))
#define MY_IS_CONTEXT_CONTINUE_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CONTINUE_STATEMENT))
#define MY_CONTEXT_CONTINUE_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CONTINUE_STATEMENT, MyContextContinueStatementClass))


//typedef struct _MyContextContinueStatement      MyContextContinueStatement;
typedef struct _MyContextContinueStatementClass MyContextContinueStatementClass;

struct _MyContextContinueStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextContinueStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_continue_statement_get_type(void) G_GNUC_CONST;
MyContextContinueStatement *my_context_continue_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_continue_statement_token_get_continue(MyContextContinueStatement* self);
MyContextExpression *my_context_continue_statement_rule_get_expression(MyContextContinueStatement* self);


MyContextContinueStatement* my_php_parser_parse_continue_statement(MyPhpParser* self, GError **error);
//----------------- ReturnStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_RETURN_STATEMENT            (my_context_return_statement_get_type())
#define MY_CONTEXT_RETURN_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_RETURN_STATEMENT, MyContextReturnStatement))
#define MY_CONTEXT_RETURN_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_RETURN_STATEMENT, MyContextReturnStatementClass))
#define MY_IS_CONTEXT_RETURN_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_RETURN_STATEMENT))
#define MY_IS_CONTEXT_RETURN_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_RETURN_STATEMENT))
#define MY_CONTEXT_RETURN_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_RETURN_STATEMENT, MyContextReturnStatementClass))


//typedef struct _MyContextReturnStatement      MyContextReturnStatement;
typedef struct _MyContextReturnStatementClass MyContextReturnStatementClass;

struct _MyContextReturnStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextReturnStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_return_statement_get_type(void) G_GNUC_CONST;
MyContextReturnStatement *my_context_return_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_return_statement_token_get_return(MyContextReturnStatement* self);
MyContextExpression *my_context_return_statement_rule_get_expression(MyContextReturnStatement* self);


MyContextReturnStatement* my_php_parser_parse_return_statement(MyPhpParser* self, GError **error);
//----------------- ExpressionStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_EXPRESSION_STATEMENT            (my_context_expression_statement_get_type())
#define MY_CONTEXT_EXPRESSION_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_EXPRESSION_STATEMENT, MyContextExpressionStatement))
#define MY_CONTEXT_EXPRESSION_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_EXPRESSION_STATEMENT, MyContextExpressionStatementClass))
#define MY_IS_CONTEXT_EXPRESSION_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_EXPRESSION_STATEMENT))
#define MY_IS_CONTEXT_EXPRESSION_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_EXPRESSION_STATEMENT))
#define MY_CONTEXT_EXPRESSION_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_EXPRESSION_STATEMENT, MyContextExpressionStatementClass))


//typedef struct _MyContextExpressionStatement      MyContextExpressionStatement;
typedef struct _MyContextExpressionStatementClass MyContextExpressionStatementClass;

struct _MyContextExpressionStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextExpressionStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_expression_statement_get_type(void) G_GNUC_CONST;
MyContextExpressionStatement *my_context_expression_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextExpression *my_context_expression_statement_rule_get_expression(MyContextExpressionStatement* self);


MyContextExpressionStatement* my_php_parser_parse_expression_statement(MyPhpParser* self, GError **error);
//----------------- UnsetStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_UNSET_STATEMENT            (my_context_unset_statement_get_type())
#define MY_CONTEXT_UNSET_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_UNSET_STATEMENT, MyContextUnsetStatement))
#define MY_CONTEXT_UNSET_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_UNSET_STATEMENT, MyContextUnsetStatementClass))
#define MY_IS_CONTEXT_UNSET_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_UNSET_STATEMENT))
#define MY_IS_CONTEXT_UNSET_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_UNSET_STATEMENT))
#define MY_CONTEXT_UNSET_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_UNSET_STATEMENT, MyContextUnsetStatementClass))


//typedef struct _MyContextUnsetStatement      MyContextUnsetStatement;
typedef struct _MyContextUnsetStatementClass MyContextUnsetStatementClass;

struct _MyContextUnsetStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextUnsetStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_unset_statement_get_type(void) G_GNUC_CONST;
MyContextUnsetStatement *my_context_unset_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_unset_statement_token_get_unset(MyContextUnsetStatement* self);
MyContextChainList *my_context_unset_statement_rule_get_chain_list(MyContextUnsetStatement* self);


MyContextUnsetStatement* my_php_parser_parse_unset_statement(MyPhpParser* self, GError **error);
//----------------- ForeachStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FOREACH_STATEMENT            (my_context_foreach_statement_get_type())
#define MY_CONTEXT_FOREACH_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FOREACH_STATEMENT, MyContextForeachStatement))
#define MY_CONTEXT_FOREACH_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FOREACH_STATEMENT, MyContextForeachStatementClass))
#define MY_IS_CONTEXT_FOREACH_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FOREACH_STATEMENT))
#define MY_IS_CONTEXT_FOREACH_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FOREACH_STATEMENT))
#define MY_CONTEXT_FOREACH_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FOREACH_STATEMENT, MyContextForeachStatementClass))


//typedef struct _MyContextForeachStatement      MyContextForeachStatement;
typedef struct _MyContextForeachStatementClass MyContextForeachStatementClass;

struct _MyContextForeachStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextForeachStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_foreach_statement_get_type(void) G_GNUC_CONST;
MyContextForeachStatement *my_context_foreach_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_foreach_statement_token_get_foreach(MyContextForeachStatement* self);
GList* my_context_foreach_statement_rule_get_chain(MyContextForeachStatement* self);// of MyContextChain
MyContextChain* my_context_foreach_statement_at_rule_get_chain(MyContextForeachStatement* self, size_t i);
AntlrTerminalNode *my_context_foreach_statement_token_get_as(MyContextForeachStatement* self);
MyContextExpression *my_context_foreach_statement_rule_get_expression(MyContextForeachStatement* self);
AntlrTerminalNode *my_context_foreach_statement_token_get_list(MyContextForeachStatement* self);
MyContextAssignmentList *my_context_foreach_statement_rule_get_assignment_list(MyContextForeachStatement* self);
MyContextStatement *my_context_foreach_statement_rule_get_statement(MyContextForeachStatement* self);
MyContextInnerStatementList *my_context_foreach_statement_rule_get_inner_statement_list(MyContextForeachStatement* self);
AntlrTerminalNode *my_context_foreach_statement_token_get_end_foreach(MyContextForeachStatement* self);


MyContextForeachStatement* my_php_parser_parse_foreach_statement(MyPhpParser* self, GError **error);
//----------------- TryCatchFinallyContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TRY_CATCH_FINALLY            (my_context_try_catch_finally_get_type())
#define MY_CONTEXT_TRY_CATCH_FINALLY(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TRY_CATCH_FINALLY, MyContextTryCatchFinally))
#define MY_CONTEXT_TRY_CATCH_FINALLY_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TRY_CATCH_FINALLY, MyContextTryCatchFinallyClass))
#define MY_IS_CONTEXT_TRY_CATCH_FINALLY(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TRY_CATCH_FINALLY))
#define MY_IS_CONTEXT_TRY_CATCH_FINALLY_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TRY_CATCH_FINALLY))
#define MY_CONTEXT_TRY_CATCH_FINALLY_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TRY_CATCH_FINALLY, MyContextTryCatchFinallyClass))


//typedef struct _MyContextTryCatchFinally      MyContextTryCatchFinally;
typedef struct _MyContextTryCatchFinallyClass MyContextTryCatchFinallyClass;

struct _MyContextTryCatchFinally {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTryCatchFinallyClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_try_catch_finally_get_type(void) G_GNUC_CONST;
MyContextTryCatchFinally *my_context_try_catch_finally_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_try_catch_finally_token_get_try(MyContextTryCatchFinally* self);
MyContextBlockStatement *my_context_try_catch_finally_rule_get_block_statement(MyContextTryCatchFinally* self);
MyContextFinallyStatement *my_context_try_catch_finally_rule_get_finally_statement(MyContextTryCatchFinally* self);
GList* my_context_try_catch_finally_rule_get_catch_clause(MyContextTryCatchFinally* self);// of MyContextCatchClause
MyContextCatchClause* my_context_try_catch_finally_at_rule_get_catch_clause(MyContextTryCatchFinally* self, size_t i);


MyContextTryCatchFinally* my_php_parser_parse_try_catch_finally(MyPhpParser* self, GError **error);
//----------------- CatchClauseContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CATCH_CLAUSE            (my_context_catch_clause_get_type())
#define MY_CONTEXT_CATCH_CLAUSE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CATCH_CLAUSE, MyContextCatchClause))
#define MY_CONTEXT_CATCH_CLAUSE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CATCH_CLAUSE, MyContextCatchClauseClass))
#define MY_IS_CONTEXT_CATCH_CLAUSE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CATCH_CLAUSE))
#define MY_IS_CONTEXT_CATCH_CLAUSE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CATCH_CLAUSE))
#define MY_CONTEXT_CATCH_CLAUSE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CATCH_CLAUSE, MyContextCatchClauseClass))


//typedef struct _MyContextCatchClause      MyContextCatchClause;
typedef struct _MyContextCatchClauseClass MyContextCatchClauseClass;

struct _MyContextCatchClause {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextCatchClauseClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_catch_clause_get_type(void) G_GNUC_CONST;
MyContextCatchClause *my_context_catch_clause_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_catch_clause_token_get_catch(MyContextCatchClause* self);
MyContextQualifiedStaticTypeRef *my_context_catch_clause_rule_get_qualified_static_type_ref(MyContextCatchClause* self);
AntlrTerminalNode *my_context_catch_clause_token_get_var_name(MyContextCatchClause* self);
MyContextBlockStatement *my_context_catch_clause_rule_get_block_statement(MyContextCatchClause* self);


MyContextCatchClause* my_php_parser_parse_catch_clause(MyPhpParser* self, GError **error);
//----------------- FinallyStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FINALLY_STATEMENT            (my_context_finally_statement_get_type())
#define MY_CONTEXT_FINALLY_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FINALLY_STATEMENT, MyContextFinallyStatement))
#define MY_CONTEXT_FINALLY_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FINALLY_STATEMENT, MyContextFinallyStatementClass))
#define MY_IS_CONTEXT_FINALLY_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FINALLY_STATEMENT))
#define MY_IS_CONTEXT_FINALLY_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FINALLY_STATEMENT))
#define MY_CONTEXT_FINALLY_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FINALLY_STATEMENT, MyContextFinallyStatementClass))


//typedef struct _MyContextFinallyStatement      MyContextFinallyStatement;
typedef struct _MyContextFinallyStatementClass MyContextFinallyStatementClass;

struct _MyContextFinallyStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextFinallyStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_finally_statement_get_type(void) G_GNUC_CONST;
MyContextFinallyStatement *my_context_finally_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_finally_statement_token_get_finally(MyContextFinallyStatement* self);
MyContextBlockStatement *my_context_finally_statement_rule_get_block_statement(MyContextFinallyStatement* self);


MyContextFinallyStatement* my_php_parser_parse_finally_statement(MyPhpParser* self, GError **error);
//----------------- ThrowStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_THROW_STATEMENT            (my_context_throw_statement_get_type())
#define MY_CONTEXT_THROW_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_THROW_STATEMENT, MyContextThrowStatement))
#define MY_CONTEXT_THROW_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_THROW_STATEMENT, MyContextThrowStatementClass))
#define MY_IS_CONTEXT_THROW_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_THROW_STATEMENT))
#define MY_IS_CONTEXT_THROW_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_THROW_STATEMENT))
#define MY_CONTEXT_THROW_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_THROW_STATEMENT, MyContextThrowStatementClass))


//typedef struct _MyContextThrowStatement      MyContextThrowStatement;
typedef struct _MyContextThrowStatementClass MyContextThrowStatementClass;

struct _MyContextThrowStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextThrowStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_throw_statement_get_type(void) G_GNUC_CONST;
MyContextThrowStatement *my_context_throw_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_throw_statement_token_get_throw(MyContextThrowStatement* self);
MyContextExpression *my_context_throw_statement_rule_get_expression(MyContextThrowStatement* self);


MyContextThrowStatement* my_php_parser_parse_throw_statement(MyPhpParser* self, GError **error);
//----------------- GotoStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_GOTO_STATEMENT            (my_context_goto_statement_get_type())
#define MY_CONTEXT_GOTO_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_GOTO_STATEMENT, MyContextGotoStatement))
#define MY_CONTEXT_GOTO_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_GOTO_STATEMENT, MyContextGotoStatementClass))
#define MY_IS_CONTEXT_GOTO_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_GOTO_STATEMENT))
#define MY_IS_CONTEXT_GOTO_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_GOTO_STATEMENT))
#define MY_CONTEXT_GOTO_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_GOTO_STATEMENT, MyContextGotoStatementClass))


//typedef struct _MyContextGotoStatement      MyContextGotoStatement;
typedef struct _MyContextGotoStatementClass MyContextGotoStatementClass;

struct _MyContextGotoStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextGotoStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_goto_statement_get_type(void) G_GNUC_CONST;
MyContextGotoStatement *my_context_goto_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_goto_statement_token_get_goto(MyContextGotoStatement* self);
MyContextIdentifier *my_context_goto_statement_rule_get_identifier(MyContextGotoStatement* self);


MyContextGotoStatement* my_php_parser_parse_goto_statement(MyPhpParser* self, GError **error);
//----------------- DeclareStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_DECLARE_STATEMENT            (my_context_declare_statement_get_type())
#define MY_CONTEXT_DECLARE_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_DECLARE_STATEMENT, MyContextDeclareStatement))
#define MY_CONTEXT_DECLARE_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_DECLARE_STATEMENT, MyContextDeclareStatementClass))
#define MY_IS_CONTEXT_DECLARE_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_DECLARE_STATEMENT))
#define MY_IS_CONTEXT_DECLARE_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_DECLARE_STATEMENT))
#define MY_CONTEXT_DECLARE_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_DECLARE_STATEMENT, MyContextDeclareStatementClass))


//typedef struct _MyContextDeclareStatement      MyContextDeclareStatement;
typedef struct _MyContextDeclareStatementClass MyContextDeclareStatementClass;

struct _MyContextDeclareStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextDeclareStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_declare_statement_get_type(void) G_GNUC_CONST;
MyContextDeclareStatement *my_context_declare_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_declare_statement_token_get_declare(MyContextDeclareStatement* self);
MyContextDeclareList *my_context_declare_statement_rule_get_declare_list(MyContextDeclareStatement* self);
MyContextStatement *my_context_declare_statement_rule_get_statement(MyContextDeclareStatement* self);
MyContextInnerStatementList *my_context_declare_statement_rule_get_inner_statement_list(MyContextDeclareStatement* self);
AntlrTerminalNode *my_context_declare_statement_token_get_end_declare(MyContextDeclareStatement* self);


MyContextDeclareStatement* my_php_parser_parse_declare_statement(MyPhpParser* self, GError **error);
//----------------- InlineHtmlStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_INLINE_HTML_STATEMENT            (my_context_inline_html_statement_get_type())
#define MY_CONTEXT_INLINE_HTML_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_INLINE_HTML_STATEMENT, MyContextInlineHtmlStatement))
#define MY_CONTEXT_INLINE_HTML_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_INLINE_HTML_STATEMENT, MyContextInlineHtmlStatementClass))
#define MY_IS_CONTEXT_INLINE_HTML_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_INLINE_HTML_STATEMENT))
#define MY_IS_CONTEXT_INLINE_HTML_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_INLINE_HTML_STATEMENT))
#define MY_CONTEXT_INLINE_HTML_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_INLINE_HTML_STATEMENT, MyContextInlineHtmlStatementClass))


//typedef struct _MyContextInlineHtmlStatement      MyContextInlineHtmlStatement;
typedef struct _MyContextInlineHtmlStatementClass MyContextInlineHtmlStatementClass;

struct _MyContextInlineHtmlStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextInlineHtmlStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_inline_html_statement_get_type(void) G_GNUC_CONST;
MyContextInlineHtmlStatement *my_context_inline_html_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_inline_html_statement_rule_get_inline_html(MyContextInlineHtmlStatement* self);// of MyContextInlineHtml
MyContextInlineHtml* my_context_inline_html_statement_at_rule_get_inline_html(MyContextInlineHtmlStatement* self, size_t i);


MyContextInlineHtmlStatement* my_php_parser_parse_inline_html_statement(MyPhpParser* self, GError **error);
//----------------- InlineHtmlContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_INLINE_HTML            (my_context_inline_html_get_type())
#define MY_CONTEXT_INLINE_HTML(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_INLINE_HTML, MyContextInlineHtml))
#define MY_CONTEXT_INLINE_HTML_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_INLINE_HTML, MyContextInlineHtmlClass))
#define MY_IS_CONTEXT_INLINE_HTML(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_INLINE_HTML))
#define MY_IS_CONTEXT_INLINE_HTML_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_INLINE_HTML))
#define MY_CONTEXT_INLINE_HTML_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_INLINE_HTML, MyContextInlineHtmlClass))


//typedef struct _MyContextInlineHtml      MyContextInlineHtml;
typedef struct _MyContextInlineHtmlClass MyContextInlineHtmlClass;

struct _MyContextInlineHtml {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextInlineHtmlClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_inline_html_get_type(void) G_GNUC_CONST;
MyContextInlineHtml *my_context_inline_html_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextHtmlElements *my_context_inline_html_rule_get_html_elements(MyContextInlineHtml* self);
MyContextScriptTextPart *my_context_inline_html_rule_get_script_text_part(MyContextInlineHtml* self);


MyContextInlineHtml* my_php_parser_parse_inline_html(MyPhpParser* self, GError **error);
//----------------- DeclareListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_DECLARE_LIST            (my_context_declare_list_get_type())
#define MY_CONTEXT_DECLARE_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_DECLARE_LIST, MyContextDeclareList))
#define MY_CONTEXT_DECLARE_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_DECLARE_LIST, MyContextDeclareListClass))
#define MY_IS_CONTEXT_DECLARE_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_DECLARE_LIST))
#define MY_IS_CONTEXT_DECLARE_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_DECLARE_LIST))
#define MY_CONTEXT_DECLARE_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_DECLARE_LIST, MyContextDeclareListClass))


//typedef struct _MyContextDeclareList      MyContextDeclareList;
typedef struct _MyContextDeclareListClass MyContextDeclareListClass;

struct _MyContextDeclareList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextDeclareListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_declare_list_get_type(void) G_GNUC_CONST;
MyContextDeclareList *my_context_declare_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_declare_list_rule_get_identifier_inititalizer(MyContextDeclareList* self);// of MyContextIdentifierInititalizer
MyContextIdentifierInititalizer* my_context_declare_list_at_rule_get_identifier_inititalizer(MyContextDeclareList* self, size_t i);


MyContextDeclareList* my_php_parser_parse_declare_list(MyPhpParser* self, GError **error);
//----------------- FormalParameterListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FORMAL_PARAMETER_LIST            (my_context_formal_parameter_list_get_type())
#define MY_CONTEXT_FORMAL_PARAMETER_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FORMAL_PARAMETER_LIST, MyContextFormalParameterList))
#define MY_CONTEXT_FORMAL_PARAMETER_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FORMAL_PARAMETER_LIST, MyContextFormalParameterListClass))
#define MY_IS_CONTEXT_FORMAL_PARAMETER_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FORMAL_PARAMETER_LIST))
#define MY_IS_CONTEXT_FORMAL_PARAMETER_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FORMAL_PARAMETER_LIST))
#define MY_CONTEXT_FORMAL_PARAMETER_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FORMAL_PARAMETER_LIST, MyContextFormalParameterListClass))


//typedef struct _MyContextFormalParameterList      MyContextFormalParameterList;
typedef struct _MyContextFormalParameterListClass MyContextFormalParameterListClass;

struct _MyContextFormalParameterList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextFormalParameterListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_formal_parameter_list_get_type(void) G_GNUC_CONST;
MyContextFormalParameterList *my_context_formal_parameter_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_formal_parameter_list_rule_get_formal_parameter(MyContextFormalParameterList* self);// of MyContextFormalParameter
MyContextFormalParameter* my_context_formal_parameter_list_at_rule_get_formal_parameter(MyContextFormalParameterList* self, size_t i);


MyContextFormalParameterList* my_php_parser_parse_formal_parameter_list(MyPhpParser* self, GError **error);
//----------------- FormalParameterContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FORMAL_PARAMETER            (my_context_formal_parameter_get_type())
#define MY_CONTEXT_FORMAL_PARAMETER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FORMAL_PARAMETER, MyContextFormalParameter))
#define MY_CONTEXT_FORMAL_PARAMETER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FORMAL_PARAMETER, MyContextFormalParameterClass))
#define MY_IS_CONTEXT_FORMAL_PARAMETER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FORMAL_PARAMETER))
#define MY_IS_CONTEXT_FORMAL_PARAMETER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FORMAL_PARAMETER))
#define MY_CONTEXT_FORMAL_PARAMETER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FORMAL_PARAMETER, MyContextFormalParameterClass))


//typedef struct _MyContextFormalParameter      MyContextFormalParameter;
typedef struct _MyContextFormalParameterClass MyContextFormalParameterClass;

struct _MyContextFormalParameter {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextFormalParameterClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_formal_parameter_get_type(void) G_GNUC_CONST;
MyContextFormalParameter *my_context_formal_parameter_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextAttributes *my_context_formal_parameter_rule_get_attributes(MyContextFormalParameter* self);
MyContextVariableInitializer *my_context_formal_parameter_rule_get_variable_initializer(MyContextFormalParameter* self);
MyContextTypeHint *my_context_formal_parameter_rule_get_type_hint(MyContextFormalParameter* self);


MyContextFormalParameter* my_php_parser_parse_formal_parameter(MyPhpParser* self, GError **error);
//----------------- TypeHintContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TYPE_HINT            (my_context_type_hint_get_type())
#define MY_CONTEXT_TYPE_HINT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TYPE_HINT, MyContextTypeHint))
#define MY_CONTEXT_TYPE_HINT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TYPE_HINT, MyContextTypeHintClass))
#define MY_IS_CONTEXT_TYPE_HINT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TYPE_HINT))
#define MY_IS_CONTEXT_TYPE_HINT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TYPE_HINT))
#define MY_CONTEXT_TYPE_HINT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TYPE_HINT, MyContextTypeHintClass))


//typedef struct _MyContextTypeHint      MyContextTypeHint;
typedef struct _MyContextTypeHintClass MyContextTypeHintClass;

struct _MyContextTypeHint {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTypeHintClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_type_hint_get_type(void) G_GNUC_CONST;
MyContextTypeHint *my_context_type_hint_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextQualifiedStaticTypeRef *my_context_type_hint_rule_get_qualified_static_type_ref(MyContextTypeHint* self);
AntlrTerminalNode *my_context_type_hint_token_get_callable(MyContextTypeHint* self);
MyContextPrimitiveType *my_context_type_hint_rule_get_primitive_type(MyContextTypeHint* self);


MyContextTypeHint* my_php_parser_parse_type_hint(MyPhpParser* self, GError **error);
//----------------- GlobalStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_GLOBAL_STATEMENT            (my_context_global_statement_get_type())
#define MY_CONTEXT_GLOBAL_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_GLOBAL_STATEMENT, MyContextGlobalStatement))
#define MY_CONTEXT_GLOBAL_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_GLOBAL_STATEMENT, MyContextGlobalStatementClass))
#define MY_IS_CONTEXT_GLOBAL_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_GLOBAL_STATEMENT))
#define MY_IS_CONTEXT_GLOBAL_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_GLOBAL_STATEMENT))
#define MY_CONTEXT_GLOBAL_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_GLOBAL_STATEMENT, MyContextGlobalStatementClass))


//typedef struct _MyContextGlobalStatement      MyContextGlobalStatement;
typedef struct _MyContextGlobalStatementClass MyContextGlobalStatementClass;

struct _MyContextGlobalStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextGlobalStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_global_statement_get_type(void) G_GNUC_CONST;
MyContextGlobalStatement *my_context_global_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_global_statement_token_get_global(MyContextGlobalStatement* self);
GList* my_context_global_statement_rule_get_global_var(MyContextGlobalStatement* self);// of MyContextGlobalVar
MyContextGlobalVar* my_context_global_statement_at_rule_get_global_var(MyContextGlobalStatement* self, size_t i);


MyContextGlobalStatement* my_php_parser_parse_global_statement(MyPhpParser* self, GError **error);
//----------------- GlobalVarContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_GLOBAL_VAR            (my_context_global_var_get_type())
#define MY_CONTEXT_GLOBAL_VAR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_GLOBAL_VAR, MyContextGlobalVar))
#define MY_CONTEXT_GLOBAL_VAR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_GLOBAL_VAR, MyContextGlobalVarClass))
#define MY_IS_CONTEXT_GLOBAL_VAR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_GLOBAL_VAR))
#define MY_IS_CONTEXT_GLOBAL_VAR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_GLOBAL_VAR))
#define MY_CONTEXT_GLOBAL_VAR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_GLOBAL_VAR, MyContextGlobalVarClass))


//typedef struct _MyContextGlobalVar      MyContextGlobalVar;
typedef struct _MyContextGlobalVarClass MyContextGlobalVarClass;

struct _MyContextGlobalVar {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextGlobalVarClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_global_var_get_type(void) G_GNUC_CONST;
MyContextGlobalVar *my_context_global_var_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_global_var_token_get_var_name(MyContextGlobalVar* self);
AntlrTerminalNode *my_context_global_var_token_get_dollar(MyContextGlobalVar* self);
MyContextChain *my_context_global_var_rule_get_chain(MyContextGlobalVar* self);
AntlrTerminalNode *my_context_global_var_token_get_open_curly_bracket(MyContextGlobalVar* self);
MyContextExpression *my_context_global_var_rule_get_expression(MyContextGlobalVar* self);


MyContextGlobalVar* my_php_parser_parse_global_var(MyPhpParser* self, GError **error);
//----------------- EchoStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ECHO_STATEMENT            (my_context_echo_statement_get_type())
#define MY_CONTEXT_ECHO_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ECHO_STATEMENT, MyContextEchoStatement))
#define MY_CONTEXT_ECHO_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ECHO_STATEMENT, MyContextEchoStatementClass))
#define MY_IS_CONTEXT_ECHO_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ECHO_STATEMENT))
#define MY_IS_CONTEXT_ECHO_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ECHO_STATEMENT))
#define MY_CONTEXT_ECHO_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ECHO_STATEMENT, MyContextEchoStatementClass))


//typedef struct _MyContextEchoStatement      MyContextEchoStatement;
typedef struct _MyContextEchoStatementClass MyContextEchoStatementClass;

struct _MyContextEchoStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextEchoStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_echo_statement_get_type(void) G_GNUC_CONST;
MyContextEchoStatement *my_context_echo_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_echo_statement_token_get_echo(MyContextEchoStatement* self);
MyContextExpressionList *my_context_echo_statement_rule_get_expression_list(MyContextEchoStatement* self);


MyContextEchoStatement* my_php_parser_parse_echo_statement(MyPhpParser* self, GError **error);
//----------------- StaticVariableStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_STATIC_VARIABLE_STATEMENT            (my_context_static_variable_statement_get_type())
#define MY_CONTEXT_STATIC_VARIABLE_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_STATIC_VARIABLE_STATEMENT, MyContextStaticVariableStatement))
#define MY_CONTEXT_STATIC_VARIABLE_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_STATIC_VARIABLE_STATEMENT, MyContextStaticVariableStatementClass))
#define MY_IS_CONTEXT_STATIC_VARIABLE_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_STATIC_VARIABLE_STATEMENT))
#define MY_IS_CONTEXT_STATIC_VARIABLE_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_STATIC_VARIABLE_STATEMENT))
#define MY_CONTEXT_STATIC_VARIABLE_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_STATIC_VARIABLE_STATEMENT, MyContextStaticVariableStatementClass))


//typedef struct _MyContextStaticVariableStatement      MyContextStaticVariableStatement;
typedef struct _MyContextStaticVariableStatementClass MyContextStaticVariableStatementClass;

struct _MyContextStaticVariableStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextStaticVariableStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_static_variable_statement_get_type(void) G_GNUC_CONST;
MyContextStaticVariableStatement *my_context_static_variable_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_static_variable_statement_token_get_static(MyContextStaticVariableStatement* self);
GList* my_context_static_variable_statement_rule_get_variable_initializer(MyContextStaticVariableStatement* self);// of MyContextVariableInitializer
MyContextVariableInitializer* my_context_static_variable_statement_at_rule_get_variable_initializer(MyContextStaticVariableStatement* self, size_t i);


MyContextStaticVariableStatement* my_php_parser_parse_static_variable_statement(MyPhpParser* self, GError **error);
//----------------- ClassStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CLASS_STATEMENT            (my_context_class_statement_get_type())
#define MY_CONTEXT_CLASS_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CLASS_STATEMENT, MyContextClassStatement))
#define MY_CONTEXT_CLASS_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CLASS_STATEMENT, MyContextClassStatementClass))
#define MY_IS_CONTEXT_CLASS_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CLASS_STATEMENT))
#define MY_IS_CONTEXT_CLASS_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CLASS_STATEMENT))
#define MY_CONTEXT_CLASS_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CLASS_STATEMENT, MyContextClassStatementClass))


//typedef struct _MyContextClassStatement      MyContextClassStatement;
typedef struct _MyContextClassStatementClass MyContextClassStatementClass;

struct _MyContextClassStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextClassStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_class_statement_get_type(void) G_GNUC_CONST;
MyContextClassStatement *my_context_class_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextAttributes *my_context_class_statement_rule_get_attributes(MyContextClassStatement* self);
MyContextPropertyModifiers *my_context_class_statement_rule_get_property_modifiers(MyContextClassStatement* self);
GList* my_context_class_statement_rule_get_variable_initializer(MyContextClassStatement* self);// of MyContextVariableInitializer
MyContextVariableInitializer* my_context_class_statement_at_rule_get_variable_initializer(MyContextClassStatement* self, size_t i);
AntlrTerminalNode *my_context_class_statement_token_get_const(MyContextClassStatement* self);
GList* my_context_class_statement_rule_get_identifier_inititalizer(MyContextClassStatement* self);// of MyContextIdentifierInititalizer
MyContextIdentifierInititalizer* my_context_class_statement_at_rule_get_identifier_inititalizer(MyContextClassStatement* self, size_t i);
AntlrTerminalNode *my_context_class_statement_token_get_function(MyContextClassStatement* self);
MyContextIdentifier *my_context_class_statement_rule_get_identifier(MyContextClassStatement* self);
MyContextFormalParameterList *my_context_class_statement_rule_get_formal_parameter_list(MyContextClassStatement* self);
MyContextMethodBody *my_context_class_statement_rule_get_method_body(MyContextClassStatement* self);
MyContextMemberModifiers *my_context_class_statement_rule_get_member_modifiers(MyContextClassStatement* self);
MyContextTypeParameterListInBrackets *my_context_class_statement_rule_get_type_parameter_list_in_brackets(MyContextClassStatement* self);
MyContextBaseCtorCall *my_context_class_statement_rule_get_base_ctor_call(MyContextClassStatement* self);
AntlrTerminalNode *my_context_class_statement_token_get_use(MyContextClassStatement* self);
MyContextQualifiedNamespaceNameList *my_context_class_statement_rule_get_qualified_namespace_name_list(MyContextClassStatement* self);
MyContextTraitAdaptations *my_context_class_statement_rule_get_trait_adaptations(MyContextClassStatement* self);


MyContextClassStatement* my_php_parser_parse_class_statement(MyPhpParser* self, GError **error);
//----------------- TraitAdaptationsContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TRAIT_ADAPTATIONS            (my_context_trait_adaptations_get_type())
#define MY_CONTEXT_TRAIT_ADAPTATIONS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TRAIT_ADAPTATIONS, MyContextTraitAdaptations))
#define MY_CONTEXT_TRAIT_ADAPTATIONS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TRAIT_ADAPTATIONS, MyContextTraitAdaptationsClass))
#define MY_IS_CONTEXT_TRAIT_ADAPTATIONS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TRAIT_ADAPTATIONS))
#define MY_IS_CONTEXT_TRAIT_ADAPTATIONS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TRAIT_ADAPTATIONS))
#define MY_CONTEXT_TRAIT_ADAPTATIONS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TRAIT_ADAPTATIONS, MyContextTraitAdaptationsClass))


//typedef struct _MyContextTraitAdaptations      MyContextTraitAdaptations;
typedef struct _MyContextTraitAdaptationsClass MyContextTraitAdaptationsClass;

struct _MyContextTraitAdaptations {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTraitAdaptationsClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_trait_adaptations_get_type(void) G_GNUC_CONST;
MyContextTraitAdaptations *my_context_trait_adaptations_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_trait_adaptations_token_get_open_curly_bracket(MyContextTraitAdaptations* self);
GList* my_context_trait_adaptations_rule_get_trait_adaptation_statement(MyContextTraitAdaptations* self);// of MyContextTraitAdaptationStatement
MyContextTraitAdaptationStatement* my_context_trait_adaptations_at_rule_get_trait_adaptation_statement(MyContextTraitAdaptations* self, size_t i);


MyContextTraitAdaptations* my_php_parser_parse_trait_adaptations(MyPhpParser* self, GError **error);
//----------------- TraitAdaptationStatementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TRAIT_ADAPTATION_STATEMENT            (my_context_trait_adaptation_statement_get_type())
#define MY_CONTEXT_TRAIT_ADAPTATION_STATEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TRAIT_ADAPTATION_STATEMENT, MyContextTraitAdaptationStatement))
#define MY_CONTEXT_TRAIT_ADAPTATION_STATEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TRAIT_ADAPTATION_STATEMENT, MyContextTraitAdaptationStatementClass))
#define MY_IS_CONTEXT_TRAIT_ADAPTATION_STATEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TRAIT_ADAPTATION_STATEMENT))
#define MY_IS_CONTEXT_TRAIT_ADAPTATION_STATEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TRAIT_ADAPTATION_STATEMENT))
#define MY_CONTEXT_TRAIT_ADAPTATION_STATEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TRAIT_ADAPTATION_STATEMENT, MyContextTraitAdaptationStatementClass))


//typedef struct _MyContextTraitAdaptationStatement      MyContextTraitAdaptationStatement;
typedef struct _MyContextTraitAdaptationStatementClass MyContextTraitAdaptationStatementClass;

struct _MyContextTraitAdaptationStatement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTraitAdaptationStatementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_trait_adaptation_statement_get_type(void) G_GNUC_CONST;
MyContextTraitAdaptationStatement *my_context_trait_adaptation_statement_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextTraitPrecedence *my_context_trait_adaptation_statement_rule_get_trait_precedence(MyContextTraitAdaptationStatement* self);
MyContextTraitAlias *my_context_trait_adaptation_statement_rule_get_trait_alias(MyContextTraitAdaptationStatement* self);


MyContextTraitAdaptationStatement* my_php_parser_parse_trait_adaptation_statement(MyPhpParser* self, GError **error);
//----------------- TraitPrecedenceContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TRAIT_PRECEDENCE            (my_context_trait_precedence_get_type())
#define MY_CONTEXT_TRAIT_PRECEDENCE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TRAIT_PRECEDENCE, MyContextTraitPrecedence))
#define MY_CONTEXT_TRAIT_PRECEDENCE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TRAIT_PRECEDENCE, MyContextTraitPrecedenceClass))
#define MY_IS_CONTEXT_TRAIT_PRECEDENCE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TRAIT_PRECEDENCE))
#define MY_IS_CONTEXT_TRAIT_PRECEDENCE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TRAIT_PRECEDENCE))
#define MY_CONTEXT_TRAIT_PRECEDENCE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TRAIT_PRECEDENCE, MyContextTraitPrecedenceClass))


//typedef struct _MyContextTraitPrecedence      MyContextTraitPrecedence;
typedef struct _MyContextTraitPrecedenceClass MyContextTraitPrecedenceClass;

struct _MyContextTraitPrecedence {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTraitPrecedenceClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_trait_precedence_get_type(void) G_GNUC_CONST;
MyContextTraitPrecedence *my_context_trait_precedence_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextQualifiedNamespaceName *my_context_trait_precedence_rule_get_qualified_namespace_name(MyContextTraitPrecedence* self);
MyContextIdentifier *my_context_trait_precedence_rule_get_identifier(MyContextTraitPrecedence* self);
AntlrTerminalNode *my_context_trait_precedence_token_get_instead_of(MyContextTraitPrecedence* self);
MyContextQualifiedNamespaceNameList *my_context_trait_precedence_rule_get_qualified_namespace_name_list(MyContextTraitPrecedence* self);


MyContextTraitPrecedence* my_php_parser_parse_trait_precedence(MyPhpParser* self, GError **error);
//----------------- TraitAliasContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TRAIT_ALIAS            (my_context_trait_alias_get_type())
#define MY_CONTEXT_TRAIT_ALIAS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TRAIT_ALIAS, MyContextTraitAlias))
#define MY_CONTEXT_TRAIT_ALIAS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TRAIT_ALIAS, MyContextTraitAliasClass))
#define MY_IS_CONTEXT_TRAIT_ALIAS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TRAIT_ALIAS))
#define MY_IS_CONTEXT_TRAIT_ALIAS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TRAIT_ALIAS))
#define MY_CONTEXT_TRAIT_ALIAS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TRAIT_ALIAS, MyContextTraitAliasClass))


//typedef struct _MyContextTraitAlias      MyContextTraitAlias;
typedef struct _MyContextTraitAliasClass MyContextTraitAliasClass;

struct _MyContextTraitAlias {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTraitAliasClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_trait_alias_get_type(void) G_GNUC_CONST;
MyContextTraitAlias *my_context_trait_alias_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextTraitMethodReference *my_context_trait_alias_rule_get_trait_method_reference(MyContextTraitAlias* self);
AntlrTerminalNode *my_context_trait_alias_token_get_as(MyContextTraitAlias* self);
MyContextMemberModifier *my_context_trait_alias_rule_get_member_modifier(MyContextTraitAlias* self);
MyContextIdentifier *my_context_trait_alias_rule_get_identifier(MyContextTraitAlias* self);


MyContextTraitAlias* my_php_parser_parse_trait_alias(MyPhpParser* self, GError **error);
//----------------- TraitMethodReferenceContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TRAIT_METHOD_REFERENCE            (my_context_trait_method_reference_get_type())
#define MY_CONTEXT_TRAIT_METHOD_REFERENCE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TRAIT_METHOD_REFERENCE, MyContextTraitMethodReference))
#define MY_CONTEXT_TRAIT_METHOD_REFERENCE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TRAIT_METHOD_REFERENCE, MyContextTraitMethodReferenceClass))
#define MY_IS_CONTEXT_TRAIT_METHOD_REFERENCE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TRAIT_METHOD_REFERENCE))
#define MY_IS_CONTEXT_TRAIT_METHOD_REFERENCE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TRAIT_METHOD_REFERENCE))
#define MY_CONTEXT_TRAIT_METHOD_REFERENCE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TRAIT_METHOD_REFERENCE, MyContextTraitMethodReferenceClass))


//typedef struct _MyContextTraitMethodReference      MyContextTraitMethodReference;
typedef struct _MyContextTraitMethodReferenceClass MyContextTraitMethodReferenceClass;

struct _MyContextTraitMethodReference {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTraitMethodReferenceClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_trait_method_reference_get_type(void) G_GNUC_CONST;
MyContextTraitMethodReference *my_context_trait_method_reference_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextIdentifier *my_context_trait_method_reference_rule_get_identifier(MyContextTraitMethodReference* self);
MyContextQualifiedNamespaceName *my_context_trait_method_reference_rule_get_qualified_namespace_name(MyContextTraitMethodReference* self);


MyContextTraitMethodReference* my_php_parser_parse_trait_method_reference(MyPhpParser* self, GError **error);
//----------------- BaseCtorCallContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_BASE_CTOR_CALL            (my_context_base_ctor_call_get_type())
#define MY_CONTEXT_BASE_CTOR_CALL(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_BASE_CTOR_CALL, MyContextBaseCtorCall))
#define MY_CONTEXT_BASE_CTOR_CALL_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_BASE_CTOR_CALL, MyContextBaseCtorCallClass))
#define MY_IS_CONTEXT_BASE_CTOR_CALL(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_BASE_CTOR_CALL))
#define MY_IS_CONTEXT_BASE_CTOR_CALL_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_BASE_CTOR_CALL))
#define MY_CONTEXT_BASE_CTOR_CALL_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_BASE_CTOR_CALL, MyContextBaseCtorCallClass))


//typedef struct _MyContextBaseCtorCall      MyContextBaseCtorCall;
typedef struct _MyContextBaseCtorCallClass MyContextBaseCtorCallClass;

struct _MyContextBaseCtorCall {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextBaseCtorCallClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_base_ctor_call_get_type(void) G_GNUC_CONST;
MyContextBaseCtorCall *my_context_base_ctor_call_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextIdentifier *my_context_base_ctor_call_rule_get_identifier(MyContextBaseCtorCall* self);
MyContextArguments *my_context_base_ctor_call_rule_get_arguments(MyContextBaseCtorCall* self);


MyContextBaseCtorCall* my_php_parser_parse_base_ctor_call(MyPhpParser* self, GError **error);
//----------------- MethodBodyContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_METHOD_BODY            (my_context_method_body_get_type())
#define MY_CONTEXT_METHOD_BODY(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_METHOD_BODY, MyContextMethodBody))
#define MY_CONTEXT_METHOD_BODY_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_METHOD_BODY, MyContextMethodBodyClass))
#define MY_IS_CONTEXT_METHOD_BODY(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_METHOD_BODY))
#define MY_IS_CONTEXT_METHOD_BODY_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_METHOD_BODY))
#define MY_CONTEXT_METHOD_BODY_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_METHOD_BODY, MyContextMethodBodyClass))


//typedef struct _MyContextMethodBody      MyContextMethodBody;
typedef struct _MyContextMethodBodyClass MyContextMethodBodyClass;

struct _MyContextMethodBody {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextMethodBodyClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_method_body_get_type(void) G_GNUC_CONST;
MyContextMethodBody *my_context_method_body_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextBlockStatement *my_context_method_body_rule_get_block_statement(MyContextMethodBody* self);


MyContextMethodBody* my_php_parser_parse_method_body(MyPhpParser* self, GError **error);
//----------------- PropertyModifiersContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_PROPERTY_MODIFIERS            (my_context_property_modifiers_get_type())
#define MY_CONTEXT_PROPERTY_MODIFIERS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_PROPERTY_MODIFIERS, MyContextPropertyModifiers))
#define MY_CONTEXT_PROPERTY_MODIFIERS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_PROPERTY_MODIFIERS, MyContextPropertyModifiersClass))
#define MY_IS_CONTEXT_PROPERTY_MODIFIERS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_PROPERTY_MODIFIERS))
#define MY_IS_CONTEXT_PROPERTY_MODIFIERS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_PROPERTY_MODIFIERS))
#define MY_CONTEXT_PROPERTY_MODIFIERS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_PROPERTY_MODIFIERS, MyContextPropertyModifiersClass))


//typedef struct _MyContextPropertyModifiers      MyContextPropertyModifiers;
typedef struct _MyContextPropertyModifiersClass MyContextPropertyModifiersClass;

struct _MyContextPropertyModifiers {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextPropertyModifiersClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_property_modifiers_get_type(void) G_GNUC_CONST;
MyContextPropertyModifiers *my_context_property_modifiers_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextMemberModifiers *my_context_property_modifiers_rule_get_member_modifiers(MyContextPropertyModifiers* self);
AntlrTerminalNode *my_context_property_modifiers_token_get_var(MyContextPropertyModifiers* self);


MyContextPropertyModifiers* my_php_parser_parse_property_modifiers(MyPhpParser* self, GError **error);
//----------------- MemberModifiersContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_MEMBER_MODIFIERS            (my_context_member_modifiers_get_type())
#define MY_CONTEXT_MEMBER_MODIFIERS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_MEMBER_MODIFIERS, MyContextMemberModifiers))
#define MY_CONTEXT_MEMBER_MODIFIERS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_MEMBER_MODIFIERS, MyContextMemberModifiersClass))
#define MY_IS_CONTEXT_MEMBER_MODIFIERS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_MEMBER_MODIFIERS))
#define MY_IS_CONTEXT_MEMBER_MODIFIERS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_MEMBER_MODIFIERS))
#define MY_CONTEXT_MEMBER_MODIFIERS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_MEMBER_MODIFIERS, MyContextMemberModifiersClass))


//typedef struct _MyContextMemberModifiers      MyContextMemberModifiers;
typedef struct _MyContextMemberModifiersClass MyContextMemberModifiersClass;

struct _MyContextMemberModifiers {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextMemberModifiersClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_member_modifiers_get_type(void) G_GNUC_CONST;
MyContextMemberModifiers *my_context_member_modifiers_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_member_modifiers_rule_get_member_modifier(MyContextMemberModifiers* self);// of MyContextMemberModifier
MyContextMemberModifier* my_context_member_modifiers_at_rule_get_member_modifier(MyContextMemberModifiers* self, size_t i);


MyContextMemberModifiers* my_php_parser_parse_member_modifiers(MyPhpParser* self, GError **error);
//----------------- VariableInitializerContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_VARIABLE_INITIALIZER            (my_context_variable_initializer_get_type())
#define MY_CONTEXT_VARIABLE_INITIALIZER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_VARIABLE_INITIALIZER, MyContextVariableInitializer))
#define MY_CONTEXT_VARIABLE_INITIALIZER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_VARIABLE_INITIALIZER, MyContextVariableInitializerClass))
#define MY_IS_CONTEXT_VARIABLE_INITIALIZER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_VARIABLE_INITIALIZER))
#define MY_IS_CONTEXT_VARIABLE_INITIALIZER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_VARIABLE_INITIALIZER))
#define MY_CONTEXT_VARIABLE_INITIALIZER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_VARIABLE_INITIALIZER, MyContextVariableInitializerClass))


//typedef struct _MyContextVariableInitializer      MyContextVariableInitializer;
typedef struct _MyContextVariableInitializerClass MyContextVariableInitializerClass;

struct _MyContextVariableInitializer {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextVariableInitializerClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_variable_initializer_get_type(void) G_GNUC_CONST;
MyContextVariableInitializer *my_context_variable_initializer_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_variable_initializer_token_get_var_name(MyContextVariableInitializer* self);
AntlrTerminalNode *my_context_variable_initializer_token_get_eq(MyContextVariableInitializer* self);
MyContextConstantInititalizer *my_context_variable_initializer_rule_get_constant_inititalizer(MyContextVariableInitializer* self);


MyContextVariableInitializer* my_php_parser_parse_variable_initializer(MyPhpParser* self, GError **error);
//----------------- IdentifierInititalizerContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_IDENTIFIER_INITITALIZER            (my_context_identifier_inititalizer_get_type())
#define MY_CONTEXT_IDENTIFIER_INITITALIZER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_IDENTIFIER_INITITALIZER, MyContextIdentifierInititalizer))
#define MY_CONTEXT_IDENTIFIER_INITITALIZER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_IDENTIFIER_INITITALIZER, MyContextIdentifierInititalizerClass))
#define MY_IS_CONTEXT_IDENTIFIER_INITITALIZER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_IDENTIFIER_INITITALIZER))
#define MY_IS_CONTEXT_IDENTIFIER_INITITALIZER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_IDENTIFIER_INITITALIZER))
#define MY_CONTEXT_IDENTIFIER_INITITALIZER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_IDENTIFIER_INITITALIZER, MyContextIdentifierInititalizerClass))


//typedef struct _MyContextIdentifierInititalizer      MyContextIdentifierInititalizer;
typedef struct _MyContextIdentifierInititalizerClass MyContextIdentifierInititalizerClass;

struct _MyContextIdentifierInititalizer {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextIdentifierInititalizerClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_identifier_inititalizer_get_type(void) G_GNUC_CONST;
MyContextIdentifierInititalizer *my_context_identifier_inititalizer_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextIdentifier *my_context_identifier_inititalizer_rule_get_identifier(MyContextIdentifierInititalizer* self);
AntlrTerminalNode *my_context_identifier_inititalizer_token_get_eq(MyContextIdentifierInititalizer* self);
MyContextConstantInititalizer *my_context_identifier_inititalizer_rule_get_constant_inititalizer(MyContextIdentifierInititalizer* self);


MyContextIdentifierInititalizer* my_php_parser_parse_identifier_inititalizer(MyPhpParser* self, GError **error);
//----------------- GlobalConstantDeclarationContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_GLOBAL_CONSTANT_DECLARATION            (my_context_global_constant_declaration_get_type())
#define MY_CONTEXT_GLOBAL_CONSTANT_DECLARATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_GLOBAL_CONSTANT_DECLARATION, MyContextGlobalConstantDeclaration))
#define MY_CONTEXT_GLOBAL_CONSTANT_DECLARATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_GLOBAL_CONSTANT_DECLARATION, MyContextGlobalConstantDeclarationClass))
#define MY_IS_CONTEXT_GLOBAL_CONSTANT_DECLARATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_GLOBAL_CONSTANT_DECLARATION))
#define MY_IS_CONTEXT_GLOBAL_CONSTANT_DECLARATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_GLOBAL_CONSTANT_DECLARATION))
#define MY_CONTEXT_GLOBAL_CONSTANT_DECLARATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_GLOBAL_CONSTANT_DECLARATION, MyContextGlobalConstantDeclarationClass))


//typedef struct _MyContextGlobalConstantDeclaration      MyContextGlobalConstantDeclaration;
typedef struct _MyContextGlobalConstantDeclarationClass MyContextGlobalConstantDeclarationClass;

struct _MyContextGlobalConstantDeclaration {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextGlobalConstantDeclarationClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_global_constant_declaration_get_type(void) G_GNUC_CONST;
MyContextGlobalConstantDeclaration *my_context_global_constant_declaration_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextAttributes *my_context_global_constant_declaration_rule_get_attributes(MyContextGlobalConstantDeclaration* self);
AntlrTerminalNode *my_context_global_constant_declaration_token_get_const(MyContextGlobalConstantDeclaration* self);
GList* my_context_global_constant_declaration_rule_get_identifier_inititalizer(MyContextGlobalConstantDeclaration* self);// of MyContextIdentifierInititalizer
MyContextIdentifierInititalizer* my_context_global_constant_declaration_at_rule_get_identifier_inititalizer(MyContextGlobalConstantDeclaration* self, size_t i);


MyContextGlobalConstantDeclaration* my_php_parser_parse_global_constant_declaration(MyPhpParser* self, GError **error);
//----------------- ExpressionListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_EXPRESSION_LIST            (my_context_expression_list_get_type())
#define MY_CONTEXT_EXPRESSION_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_EXPRESSION_LIST, MyContextExpressionList))
#define MY_CONTEXT_EXPRESSION_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_EXPRESSION_LIST, MyContextExpressionListClass))
#define MY_IS_CONTEXT_EXPRESSION_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_EXPRESSION_LIST))
#define MY_IS_CONTEXT_EXPRESSION_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_EXPRESSION_LIST))
#define MY_CONTEXT_EXPRESSION_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_EXPRESSION_LIST, MyContextExpressionListClass))


//typedef struct _MyContextExpressionList      MyContextExpressionList;
typedef struct _MyContextExpressionListClass MyContextExpressionListClass;

struct _MyContextExpressionList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextExpressionListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_expression_list_get_type(void) G_GNUC_CONST;
MyContextExpressionList *my_context_expression_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_expression_list_rule_get_expression(MyContextExpressionList* self);// of MyContextExpression
MyContextExpression* my_context_expression_list_at_rule_get_expression(MyContextExpressionList* self, size_t i);


MyContextExpressionList* my_php_parser_parse_expression_list(MyPhpParser* self, GError **error);
//----------------- ParenthesisContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_PARENTHESIS            (my_context_parenthesis_get_type())
#define MY_CONTEXT_PARENTHESIS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_PARENTHESIS, MyContextParenthesis))
#define MY_CONTEXT_PARENTHESIS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_PARENTHESIS, MyContextParenthesisClass))
#define MY_IS_CONTEXT_PARENTHESIS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_PARENTHESIS))
#define MY_IS_CONTEXT_PARENTHESIS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_PARENTHESIS))
#define MY_CONTEXT_PARENTHESIS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_PARENTHESIS, MyContextParenthesisClass))


//typedef struct _MyContextParenthesis      MyContextParenthesis;
typedef struct _MyContextParenthesisClass MyContextParenthesisClass;

struct _MyContextParenthesis {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextParenthesisClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_parenthesis_get_type(void) G_GNUC_CONST;
MyContextParenthesis *my_context_parenthesis_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextExpression *my_context_parenthesis_rule_get_expression(MyContextParenthesis* self);
MyContextYieldExpression *my_context_parenthesis_rule_get_yield_expression(MyContextParenthesis* self);


MyContextParenthesis* my_php_parser_parse_parenthesis(MyPhpParser* self, GError **error);
//----------------- ExpressionContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_EXPRESSION            (my_context_expression_get_type())
#define MY_CONTEXT_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_EXPRESSION, MyContextExpression))
#define MY_CONTEXT_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_EXPRESSION, MyContextExpressionClass))
#define MY_IS_CONTEXT_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_EXPRESSION))
#define MY_IS_CONTEXT_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_EXPRESSION))
#define MY_CONTEXT_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_EXPRESSION, MyContextExpressionClass))


//typedef struct _MyContextExpression      MyContextExpression;
typedef struct _MyContextExpressionClass MyContextExpressionClass;

struct _MyContextExpression {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextExpressionClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_expression_get_type(void) G_GNUC_CONST;
MyContextExpression *my_context_expression_new(AntlrParserRuleContext *parent, size_t invokingState);



#define MY_TYPE_CONTEXT_CHAIN_EXPRESSION            (my_context_chain_expression_get_type())
#define MY_CONTEXT_CHAIN_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CHAIN_EXPRESSION, MyContextChainExpression))
#define MY_CONTEXT_CHAIN_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CHAIN_EXPRESSION, MyContextChainExpressionClass))
#define MY_IS_CONTEXT_CHAIN_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CHAIN_EXPRESSION))
#define MY_IS_CONTEXT_CHAIN_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CHAIN_EXPRESSION))
#define MY_CONTEXT_CHAIN_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CHAIN_EXPRESSION, MyContextChainExpressionClass))


typedef struct _MyContextChainExpression      MyContextChainExpression;
typedef struct _MyContextChainExpressionClass MyContextChainExpressionClass;

struct _MyContextChainExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextChainExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_chain_expression_get_type(void) G_GNUC_CONST;
MyContextChainExpression *my_context_chain_expression_new(MyContextExpression *ctx);

MyContextChain *my_context_chain_expression_rule_get_chain(MyContextChainExpression* self);



#define MY_TYPE_CONTEXT_UNARY_OPERATOR_EXPRESSION            (my_context_unary_operator_expression_get_type())
#define MY_CONTEXT_UNARY_OPERATOR_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_UNARY_OPERATOR_EXPRESSION, MyContextUnaryOperatorExpression))
#define MY_CONTEXT_UNARY_OPERATOR_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_UNARY_OPERATOR_EXPRESSION, MyContextUnaryOperatorExpressionClass))
#define MY_IS_CONTEXT_UNARY_OPERATOR_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_UNARY_OPERATOR_EXPRESSION))
#define MY_IS_CONTEXT_UNARY_OPERATOR_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_UNARY_OPERATOR_EXPRESSION))
#define MY_CONTEXT_UNARY_OPERATOR_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_UNARY_OPERATOR_EXPRESSION, MyContextUnaryOperatorExpressionClass))


typedef struct _MyContextUnaryOperatorExpression      MyContextUnaryOperatorExpression;
typedef struct _MyContextUnaryOperatorExpressionClass MyContextUnaryOperatorExpressionClass;

struct _MyContextUnaryOperatorExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextUnaryOperatorExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_unary_operator_expression_get_type(void) G_GNUC_CONST;
MyContextUnaryOperatorExpression *my_context_unary_operator_expression_new(MyContextExpression *ctx);

MyContextExpression *my_context_unary_operator_expression_rule_get_expression(MyContextUnaryOperatorExpression* self);



#define MY_TYPE_CONTEXT_SPECIAL_WORD_EXPRESSION            (my_context_special_word_expression_get_type())
#define MY_CONTEXT_SPECIAL_WORD_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_SPECIAL_WORD_EXPRESSION, MyContextSpecialWordExpression))
#define MY_CONTEXT_SPECIAL_WORD_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_SPECIAL_WORD_EXPRESSION, MyContextSpecialWordExpressionClass))
#define MY_IS_CONTEXT_SPECIAL_WORD_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_SPECIAL_WORD_EXPRESSION))
#define MY_IS_CONTEXT_SPECIAL_WORD_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_SPECIAL_WORD_EXPRESSION))
#define MY_CONTEXT_SPECIAL_WORD_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_SPECIAL_WORD_EXPRESSION, MyContextSpecialWordExpressionClass))


typedef struct _MyContextSpecialWordExpression      MyContextSpecialWordExpression;
typedef struct _MyContextSpecialWordExpressionClass MyContextSpecialWordExpressionClass;

struct _MyContextSpecialWordExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextSpecialWordExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_special_word_expression_get_type(void) G_GNUC_CONST;
MyContextSpecialWordExpression *my_context_special_word_expression_new(MyContextExpression *ctx);

AntlrTerminalNode *my_context_special_word_expression_token_get_yield(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_list(MyContextSpecialWordExpression* self);
MyContextAssignmentList *my_context_special_word_expression_rule_get_assignment_list(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_eq(MyContextSpecialWordExpression* self);
MyContextExpression *my_context_special_word_expression_rule_get_expression(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_is_set(MyContextSpecialWordExpression* self);
MyContextChainList *my_context_special_word_expression_rule_get_chain_list(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_empty(MyContextSpecialWordExpression* self);
MyContextChain *my_context_special_word_expression_rule_get_chain(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_eval(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_exit(MyContextSpecialWordExpression* self);
MyContextParenthesis *my_context_special_word_expression_rule_get_parenthesis(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_include(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_include_once(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_require(MyContextSpecialWordExpression* self);
AntlrTerminalNode *my_context_special_word_expression_token_get_require_once(MyContextSpecialWordExpression* self);



#define MY_TYPE_CONTEXT_ARRAY_CREATION_EXPRESSION            (my_context_array_creation_expression_get_type())
#define MY_CONTEXT_ARRAY_CREATION_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ARRAY_CREATION_EXPRESSION, MyContextArrayCreationExpression))
#define MY_CONTEXT_ARRAY_CREATION_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ARRAY_CREATION_EXPRESSION, MyContextArrayCreationExpressionClass))
#define MY_IS_CONTEXT_ARRAY_CREATION_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ARRAY_CREATION_EXPRESSION))
#define MY_IS_CONTEXT_ARRAY_CREATION_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ARRAY_CREATION_EXPRESSION))
#define MY_CONTEXT_ARRAY_CREATION_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ARRAY_CREATION_EXPRESSION, MyContextArrayCreationExpressionClass))


typedef struct _MyContextArrayCreationExpression      MyContextArrayCreationExpression;
typedef struct _MyContextArrayCreationExpressionClass MyContextArrayCreationExpressionClass;

struct _MyContextArrayCreationExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextArrayCreationExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_array_creation_expression_get_type(void) G_GNUC_CONST;
MyContextArrayCreationExpression *my_context_array_creation_expression_new(MyContextExpression *ctx);

AntlrTerminalNode *my_context_array_creation_expression_token_get_array(MyContextArrayCreationExpression* self);
MyContextExpression *my_context_array_creation_expression_rule_get_expression(MyContextArrayCreationExpression* self);
MyContextArrayItemList *my_context_array_creation_expression_rule_get_array_item_list(MyContextArrayCreationExpression* self);



#define MY_TYPE_CONTEXT_NEW_EXPRESSION            (my_context_new_expression_get_type())
#define MY_CONTEXT_NEW_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_NEW_EXPRESSION, MyContextNewExpression))
#define MY_CONTEXT_NEW_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_NEW_EXPRESSION, MyContextNewExpressionClass))
#define MY_IS_CONTEXT_NEW_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_NEW_EXPRESSION))
#define MY_IS_CONTEXT_NEW_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_NEW_EXPRESSION))
#define MY_CONTEXT_NEW_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_NEW_EXPRESSION, MyContextNewExpressionClass))


typedef struct _MyContextNewExpression      MyContextNewExpression;
typedef struct _MyContextNewExpressionClass MyContextNewExpressionClass;

struct _MyContextNewExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextNewExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_new_expression_get_type(void) G_GNUC_CONST;
MyContextNewExpression *my_context_new_expression_new(MyContextExpression *ctx);

MyContextNewExpr *my_context_new_expression_rule_get_new_expr(MyContextNewExpression* self);



#define MY_TYPE_CONTEXT_PARENTHESIS_EXPRESSION            (my_context_parenthesis_expression_get_type())
#define MY_CONTEXT_PARENTHESIS_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_PARENTHESIS_EXPRESSION, MyContextParenthesisExpression))
#define MY_CONTEXT_PARENTHESIS_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_PARENTHESIS_EXPRESSION, MyContextParenthesisExpressionClass))
#define MY_IS_CONTEXT_PARENTHESIS_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_PARENTHESIS_EXPRESSION))
#define MY_IS_CONTEXT_PARENTHESIS_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_PARENTHESIS_EXPRESSION))
#define MY_CONTEXT_PARENTHESIS_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_PARENTHESIS_EXPRESSION, MyContextParenthesisExpressionClass))


typedef struct _MyContextParenthesisExpression      MyContextParenthesisExpression;
typedef struct _MyContextParenthesisExpressionClass MyContextParenthesisExpressionClass;

struct _MyContextParenthesisExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextParenthesisExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_parenthesis_expression_get_type(void) G_GNUC_CONST;
MyContextParenthesisExpression *my_context_parenthesis_expression_new(MyContextExpression *ctx);

MyContextParenthesis *my_context_parenthesis_expression_rule_get_parenthesis(MyContextParenthesisExpression* self);



#define MY_TYPE_CONTEXT_BACK_QUOTE_STRING_EXPRESSION            (my_context_back_quote_string_expression_get_type())
#define MY_CONTEXT_BACK_QUOTE_STRING_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_BACK_QUOTE_STRING_EXPRESSION, MyContextBackQuoteStringExpression))
#define MY_CONTEXT_BACK_QUOTE_STRING_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_BACK_QUOTE_STRING_EXPRESSION, MyContextBackQuoteStringExpressionClass))
#define MY_IS_CONTEXT_BACK_QUOTE_STRING_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_BACK_QUOTE_STRING_EXPRESSION))
#define MY_IS_CONTEXT_BACK_QUOTE_STRING_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_BACK_QUOTE_STRING_EXPRESSION))
#define MY_CONTEXT_BACK_QUOTE_STRING_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_BACK_QUOTE_STRING_EXPRESSION, MyContextBackQuoteStringExpressionClass))


typedef struct _MyContextBackQuoteStringExpression      MyContextBackQuoteStringExpression;
typedef struct _MyContextBackQuoteStringExpressionClass MyContextBackQuoteStringExpressionClass;

struct _MyContextBackQuoteStringExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextBackQuoteStringExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_back_quote_string_expression_get_type(void) G_GNUC_CONST;
MyContextBackQuoteStringExpression *my_context_back_quote_string_expression_new(MyContextExpression *ctx);

AntlrTerminalNode *my_context_back_quote_string_expression_token_get_back_quote_string(MyContextBackQuoteStringExpression* self);



#define MY_TYPE_CONTEXT_CONDITIONAL_EXPRESSION            (my_context_conditional_expression_get_type())
#define MY_CONTEXT_CONDITIONAL_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CONDITIONAL_EXPRESSION, MyContextConditionalExpression))
#define MY_CONTEXT_CONDITIONAL_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CONDITIONAL_EXPRESSION, MyContextConditionalExpressionClass))
#define MY_IS_CONTEXT_CONDITIONAL_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CONDITIONAL_EXPRESSION))
#define MY_IS_CONTEXT_CONDITIONAL_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CONDITIONAL_EXPRESSION))
#define MY_CONTEXT_CONDITIONAL_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CONDITIONAL_EXPRESSION, MyContextConditionalExpressionClass))


typedef struct _MyContextConditionalExpression      MyContextConditionalExpression;
typedef struct _MyContextConditionalExpressionClass MyContextConditionalExpressionClass;

struct _MyContextConditionalExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
    AntlrToken *op;
};

struct _MyContextConditionalExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_conditional_expression_get_type(void) G_GNUC_CONST;
MyContextConditionalExpression *my_context_conditional_expression_new(MyContextExpression *ctx);

GList* my_context_conditional_expression_rule_get_expression(MyContextConditionalExpression* self);// of MyContextExpression
MyContextExpression* my_context_conditional_expression_at_rule_get_expression(MyContextConditionalExpression* self, size_t i);
AntlrTerminalNode *my_context_conditional_expression_token_get_question_mark(MyContextConditionalExpression* self);



#define MY_TYPE_CONTEXT_ARITHMETIC_EXPRESSION            (my_context_arithmetic_expression_get_type())
#define MY_CONTEXT_ARITHMETIC_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ARITHMETIC_EXPRESSION, MyContextArithmeticExpression))
#define MY_CONTEXT_ARITHMETIC_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ARITHMETIC_EXPRESSION, MyContextArithmeticExpressionClass))
#define MY_IS_CONTEXT_ARITHMETIC_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ARITHMETIC_EXPRESSION))
#define MY_IS_CONTEXT_ARITHMETIC_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ARITHMETIC_EXPRESSION))
#define MY_CONTEXT_ARITHMETIC_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ARITHMETIC_EXPRESSION, MyContextArithmeticExpressionClass))


typedef struct _MyContextArithmeticExpression      MyContextArithmeticExpression;
typedef struct _MyContextArithmeticExpressionClass MyContextArithmeticExpressionClass;

struct _MyContextArithmeticExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
    AntlrToken *op;
};

struct _MyContextArithmeticExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_arithmetic_expression_get_type(void) G_GNUC_CONST;
MyContextArithmeticExpression *my_context_arithmetic_expression_new(MyContextExpression *ctx);

GList* my_context_arithmetic_expression_rule_get_expression(MyContextArithmeticExpression* self);// of MyContextExpression
MyContextExpression* my_context_arithmetic_expression_at_rule_get_expression(MyContextArithmeticExpression* self, size_t i);
AntlrTerminalNode *my_context_arithmetic_expression_token_get_divide(MyContextArithmeticExpression* self);



#define MY_TYPE_CONTEXT_INDEXER_EXPRESSION            (my_context_indexer_expression_get_type())
#define MY_CONTEXT_INDEXER_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_INDEXER_EXPRESSION, MyContextIndexerExpression))
#define MY_CONTEXT_INDEXER_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_INDEXER_EXPRESSION, MyContextIndexerExpressionClass))
#define MY_IS_CONTEXT_INDEXER_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_INDEXER_EXPRESSION))
#define MY_IS_CONTEXT_INDEXER_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_INDEXER_EXPRESSION))
#define MY_CONTEXT_INDEXER_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_INDEXER_EXPRESSION, MyContextIndexerExpressionClass))


typedef struct _MyContextIndexerExpression      MyContextIndexerExpression;
typedef struct _MyContextIndexerExpressionClass MyContextIndexerExpressionClass;

struct _MyContextIndexerExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextIndexerExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_indexer_expression_get_type(void) G_GNUC_CONST;
MyContextIndexerExpression *my_context_indexer_expression_new(MyContextExpression *ctx);

MyContextStringConstant *my_context_indexer_expression_rule_get_string_constant(MyContextIndexerExpression* self);
MyContextExpression *my_context_indexer_expression_rule_get_expression(MyContextIndexerExpression* self);



#define MY_TYPE_CONTEXT_SCALAR_EXPRESSION            (my_context_scalar_expression_get_type())
#define MY_CONTEXT_SCALAR_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_SCALAR_EXPRESSION, MyContextScalarExpression))
#define MY_CONTEXT_SCALAR_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_SCALAR_EXPRESSION, MyContextScalarExpressionClass))
#define MY_IS_CONTEXT_SCALAR_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_SCALAR_EXPRESSION))
#define MY_IS_CONTEXT_SCALAR_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_SCALAR_EXPRESSION))
#define MY_CONTEXT_SCALAR_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_SCALAR_EXPRESSION, MyContextScalarExpressionClass))


typedef struct _MyContextScalarExpression      MyContextScalarExpression;
typedef struct _MyContextScalarExpressionClass MyContextScalarExpressionClass;

struct _MyContextScalarExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextScalarExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_scalar_expression_get_type(void) G_GNUC_CONST;
MyContextScalarExpression *my_context_scalar_expression_new(MyContextExpression *ctx);

MyContextConstant *my_context_scalar_expression_rule_get_constant(MyContextScalarExpression* self);
MyContextString *my_context_scalar_expression_rule_get_string(MyContextScalarExpression* self);
AntlrTerminalNode *my_context_scalar_expression_token_get_label(MyContextScalarExpression* self);



#define MY_TYPE_CONTEXT_PREFIX_INC_DEC_EXPRESSION            (my_context_prefix_inc_dec_expression_get_type())
#define MY_CONTEXT_PREFIX_INC_DEC_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_PREFIX_INC_DEC_EXPRESSION, MyContextPrefixIncDecExpression))
#define MY_CONTEXT_PREFIX_INC_DEC_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_PREFIX_INC_DEC_EXPRESSION, MyContextPrefixIncDecExpressionClass))
#define MY_IS_CONTEXT_PREFIX_INC_DEC_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_PREFIX_INC_DEC_EXPRESSION))
#define MY_IS_CONTEXT_PREFIX_INC_DEC_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_PREFIX_INC_DEC_EXPRESSION))
#define MY_CONTEXT_PREFIX_INC_DEC_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_PREFIX_INC_DEC_EXPRESSION, MyContextPrefixIncDecExpressionClass))


typedef struct _MyContextPrefixIncDecExpression      MyContextPrefixIncDecExpression;
typedef struct _MyContextPrefixIncDecExpressionClass MyContextPrefixIncDecExpressionClass;

struct _MyContextPrefixIncDecExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextPrefixIncDecExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_prefix_inc_dec_expression_get_type(void) G_GNUC_CONST;
MyContextPrefixIncDecExpression *my_context_prefix_inc_dec_expression_new(MyContextExpression *ctx);

MyContextChain *my_context_prefix_inc_dec_expression_rule_get_chain(MyContextPrefixIncDecExpression* self);



#define MY_TYPE_CONTEXT_COMPARISON_EXPRESSION            (my_context_comparison_expression_get_type())
#define MY_CONTEXT_COMPARISON_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_COMPARISON_EXPRESSION, MyContextComparisonExpression))
#define MY_CONTEXT_COMPARISON_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_COMPARISON_EXPRESSION, MyContextComparisonExpressionClass))
#define MY_IS_CONTEXT_COMPARISON_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_COMPARISON_EXPRESSION))
#define MY_IS_CONTEXT_COMPARISON_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_COMPARISON_EXPRESSION))
#define MY_CONTEXT_COMPARISON_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_COMPARISON_EXPRESSION, MyContextComparisonExpressionClass))


typedef struct _MyContextComparisonExpression      MyContextComparisonExpression;
typedef struct _MyContextComparisonExpressionClass MyContextComparisonExpressionClass;

struct _MyContextComparisonExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
    AntlrToken *op;
};

struct _MyContextComparisonExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_comparison_expression_get_type(void) G_GNUC_CONST;
MyContextComparisonExpression *my_context_comparison_expression_new(MyContextExpression *ctx);

GList* my_context_comparison_expression_rule_get_expression(MyContextComparisonExpression* self);// of MyContextExpression
MyContextExpression* my_context_comparison_expression_at_rule_get_expression(MyContextComparisonExpression* self, size_t i);
AntlrTerminalNode *my_context_comparison_expression_token_get_less(MyContextComparisonExpression* self);
AntlrTerminalNode *my_context_comparison_expression_token_get_greater(MyContextComparisonExpression* self);
AntlrTerminalNode *my_context_comparison_expression_token_get_is_not_eq(MyContextComparisonExpression* self);



#define MY_TYPE_CONTEXT_LOGICAL_EXPRESSION            (my_context_logical_expression_get_type())
#define MY_CONTEXT_LOGICAL_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_LOGICAL_EXPRESSION, MyContextLogicalExpression))
#define MY_CONTEXT_LOGICAL_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_LOGICAL_EXPRESSION, MyContextLogicalExpressionClass))
#define MY_IS_CONTEXT_LOGICAL_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_LOGICAL_EXPRESSION))
#define MY_IS_CONTEXT_LOGICAL_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_LOGICAL_EXPRESSION))
#define MY_CONTEXT_LOGICAL_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_LOGICAL_EXPRESSION, MyContextLogicalExpressionClass))


typedef struct _MyContextLogicalExpression      MyContextLogicalExpression;
typedef struct _MyContextLogicalExpressionClass MyContextLogicalExpressionClass;

struct _MyContextLogicalExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
    AntlrToken *op;
};

struct _MyContextLogicalExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_logical_expression_get_type(void) G_GNUC_CONST;
MyContextLogicalExpression *my_context_logical_expression_new(MyContextExpression *ctx);

GList* my_context_logical_expression_rule_get_expression(MyContextLogicalExpression* self);// of MyContextExpression
MyContextExpression* my_context_logical_expression_at_rule_get_expression(MyContextLogicalExpression* self, size_t i);
AntlrTerminalNode *my_context_logical_expression_token_get_logical_and(MyContextLogicalExpression* self);
AntlrTerminalNode *my_context_logical_expression_token_get_logical_xor(MyContextLogicalExpression* self);
AntlrTerminalNode *my_context_logical_expression_token_get_logical_or(MyContextLogicalExpression* self);



#define MY_TYPE_CONTEXT_PRINT_EXPRESSION            (my_context_print_expression_get_type())
#define MY_CONTEXT_PRINT_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_PRINT_EXPRESSION, MyContextPrintExpression))
#define MY_CONTEXT_PRINT_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_PRINT_EXPRESSION, MyContextPrintExpressionClass))
#define MY_IS_CONTEXT_PRINT_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_PRINT_EXPRESSION))
#define MY_IS_CONTEXT_PRINT_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_PRINT_EXPRESSION))
#define MY_CONTEXT_PRINT_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_PRINT_EXPRESSION, MyContextPrintExpressionClass))


typedef struct _MyContextPrintExpression      MyContextPrintExpression;
typedef struct _MyContextPrintExpressionClass MyContextPrintExpressionClass;

struct _MyContextPrintExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextPrintExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_print_expression_get_type(void) G_GNUC_CONST;
MyContextPrintExpression *my_context_print_expression_new(MyContextExpression *ctx);

AntlrTerminalNode *my_context_print_expression_token_get_print(MyContextPrintExpression* self);
MyContextExpression *my_context_print_expression_rule_get_expression(MyContextPrintExpression* self);



#define MY_TYPE_CONTEXT_ASSIGNMENT_EXPRESSION            (my_context_assignment_expression_get_type())
#define MY_CONTEXT_ASSIGNMENT_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ASSIGNMENT_EXPRESSION, MyContextAssignmentExpression))
#define MY_CONTEXT_ASSIGNMENT_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ASSIGNMENT_EXPRESSION, MyContextAssignmentExpressionClass))
#define MY_IS_CONTEXT_ASSIGNMENT_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ASSIGNMENT_EXPRESSION))
#define MY_IS_CONTEXT_ASSIGNMENT_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ASSIGNMENT_EXPRESSION))
#define MY_CONTEXT_ASSIGNMENT_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ASSIGNMENT_EXPRESSION, MyContextAssignmentExpressionClass))


typedef struct _MyContextAssignmentExpression      MyContextAssignmentExpression;
typedef struct _MyContextAssignmentExpressionClass MyContextAssignmentExpressionClass;

struct _MyContextAssignmentExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextAssignmentExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_assignment_expression_get_type(void) G_GNUC_CONST;
MyContextAssignmentExpression *my_context_assignment_expression_new(MyContextExpression *ctx);

GList* my_context_assignment_expression_rule_get_chain(MyContextAssignmentExpression* self);// of MyContextChain
MyContextChain* my_context_assignment_expression_at_rule_get_chain(MyContextAssignmentExpression* self, size_t i);
MyContextAssignmentOperator *my_context_assignment_expression_rule_get_assignment_operator(MyContextAssignmentExpression* self);
MyContextExpression *my_context_assignment_expression_rule_get_expression(MyContextAssignmentExpression* self);
AntlrTerminalNode *my_context_assignment_expression_token_get_eq(MyContextAssignmentExpression* self);
MyContextNewExpr *my_context_assignment_expression_rule_get_new_expr(MyContextAssignmentExpression* self);



#define MY_TYPE_CONTEXT_POSTFIX_INC_DEC_EXPRESSION            (my_context_postfix_inc_dec_expression_get_type())
#define MY_CONTEXT_POSTFIX_INC_DEC_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_POSTFIX_INC_DEC_EXPRESSION, MyContextPostfixIncDecExpression))
#define MY_CONTEXT_POSTFIX_INC_DEC_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_POSTFIX_INC_DEC_EXPRESSION, MyContextPostfixIncDecExpressionClass))
#define MY_IS_CONTEXT_POSTFIX_INC_DEC_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_POSTFIX_INC_DEC_EXPRESSION))
#define MY_IS_CONTEXT_POSTFIX_INC_DEC_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_POSTFIX_INC_DEC_EXPRESSION))
#define MY_CONTEXT_POSTFIX_INC_DEC_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_POSTFIX_INC_DEC_EXPRESSION, MyContextPostfixIncDecExpressionClass))


typedef struct _MyContextPostfixIncDecExpression      MyContextPostfixIncDecExpression;
typedef struct _MyContextPostfixIncDecExpressionClass MyContextPostfixIncDecExpressionClass;

struct _MyContextPostfixIncDecExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextPostfixIncDecExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_postfix_inc_dec_expression_get_type(void) G_GNUC_CONST;
MyContextPostfixIncDecExpression *my_context_postfix_inc_dec_expression_new(MyContextExpression *ctx);

MyContextChain *my_context_postfix_inc_dec_expression_rule_get_chain(MyContextPostfixIncDecExpression* self);



#define MY_TYPE_CONTEXT_CAST_EXPRESSION            (my_context_cast_expression_get_type())
#define MY_CONTEXT_CAST_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CAST_EXPRESSION, MyContextCastExpression))
#define MY_CONTEXT_CAST_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CAST_EXPRESSION, MyContextCastExpressionClass))
#define MY_IS_CONTEXT_CAST_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CAST_EXPRESSION))
#define MY_IS_CONTEXT_CAST_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CAST_EXPRESSION))
#define MY_CONTEXT_CAST_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CAST_EXPRESSION, MyContextCastExpressionClass))


typedef struct _MyContextCastExpression      MyContextCastExpression;
typedef struct _MyContextCastExpressionClass MyContextCastExpressionClass;

struct _MyContextCastExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextCastExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_cast_expression_get_type(void) G_GNUC_CONST;
MyContextCastExpression *my_context_cast_expression_new(MyContextExpression *ctx);

MyContextCastOperation *my_context_cast_expression_rule_get_cast_operation(MyContextCastExpression* self);
MyContextExpression *my_context_cast_expression_rule_get_expression(MyContextCastExpression* self);



#define MY_TYPE_CONTEXT_INSTANCE_OF_EXPRESSION            (my_context_instance_of_expression_get_type())
#define MY_CONTEXT_INSTANCE_OF_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_INSTANCE_OF_EXPRESSION, MyContextInstanceOfExpression))
#define MY_CONTEXT_INSTANCE_OF_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_INSTANCE_OF_EXPRESSION, MyContextInstanceOfExpressionClass))
#define MY_IS_CONTEXT_INSTANCE_OF_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_INSTANCE_OF_EXPRESSION))
#define MY_IS_CONTEXT_INSTANCE_OF_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_INSTANCE_OF_EXPRESSION))
#define MY_CONTEXT_INSTANCE_OF_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_INSTANCE_OF_EXPRESSION, MyContextInstanceOfExpressionClass))


typedef struct _MyContextInstanceOfExpression      MyContextInstanceOfExpression;
typedef struct _MyContextInstanceOfExpressionClass MyContextInstanceOfExpressionClass;

struct _MyContextInstanceOfExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextInstanceOfExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_instance_of_expression_get_type(void) G_GNUC_CONST;
MyContextInstanceOfExpression *my_context_instance_of_expression_new(MyContextExpression *ctx);

MyContextExpression *my_context_instance_of_expression_rule_get_expression(MyContextInstanceOfExpression* self);
AntlrTerminalNode *my_context_instance_of_expression_token_get_instance_of(MyContextInstanceOfExpression* self);
MyContextTypeRef *my_context_instance_of_expression_rule_get_type_ref(MyContextInstanceOfExpression* self);



#define MY_TYPE_CONTEXT_LAMBDA_FUNCTION_EXPRESSION            (my_context_lambda_function_expression_get_type())
#define MY_CONTEXT_LAMBDA_FUNCTION_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_LAMBDA_FUNCTION_EXPRESSION, MyContextLambdaFunctionExpression))
#define MY_CONTEXT_LAMBDA_FUNCTION_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_LAMBDA_FUNCTION_EXPRESSION, MyContextLambdaFunctionExpressionClass))
#define MY_IS_CONTEXT_LAMBDA_FUNCTION_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_LAMBDA_FUNCTION_EXPRESSION))
#define MY_IS_CONTEXT_LAMBDA_FUNCTION_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_LAMBDA_FUNCTION_EXPRESSION))
#define MY_CONTEXT_LAMBDA_FUNCTION_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_LAMBDA_FUNCTION_EXPRESSION, MyContextLambdaFunctionExpressionClass))


typedef struct _MyContextLambdaFunctionExpression      MyContextLambdaFunctionExpression;
typedef struct _MyContextLambdaFunctionExpressionClass MyContextLambdaFunctionExpressionClass;

struct _MyContextLambdaFunctionExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextLambdaFunctionExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_lambda_function_expression_get_type(void) G_GNUC_CONST;
MyContextLambdaFunctionExpression *my_context_lambda_function_expression_new(MyContextExpression *ctx);

AntlrTerminalNode *my_context_lambda_function_expression_token_get_function(MyContextLambdaFunctionExpression* self);
MyContextFormalParameterList *my_context_lambda_function_expression_rule_get_formal_parameter_list(MyContextLambdaFunctionExpression* self);
MyContextBlockStatement *my_context_lambda_function_expression_rule_get_block_statement(MyContextLambdaFunctionExpression* self);
AntlrTerminalNode *my_context_lambda_function_expression_token_get_static(MyContextLambdaFunctionExpression* self);
MyContextLambdaFunctionUseVars *my_context_lambda_function_expression_rule_get_lambda_function_use_vars(MyContextLambdaFunctionExpression* self);



#define MY_TYPE_CONTEXT_BITWISE_EXPRESSION            (my_context_bitwise_expression_get_type())
#define MY_CONTEXT_BITWISE_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_BITWISE_EXPRESSION, MyContextBitwiseExpression))
#define MY_CONTEXT_BITWISE_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_BITWISE_EXPRESSION, MyContextBitwiseExpressionClass))
#define MY_IS_CONTEXT_BITWISE_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_BITWISE_EXPRESSION))
#define MY_IS_CONTEXT_BITWISE_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_BITWISE_EXPRESSION))
#define MY_CONTEXT_BITWISE_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_BITWISE_EXPRESSION, MyContextBitwiseExpressionClass))


typedef struct _MyContextBitwiseExpression      MyContextBitwiseExpression;
typedef struct _MyContextBitwiseExpressionClass MyContextBitwiseExpressionClass;

struct _MyContextBitwiseExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
    AntlrToken *op;
};

struct _MyContextBitwiseExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_bitwise_expression_get_type(void) G_GNUC_CONST;
MyContextBitwiseExpression *my_context_bitwise_expression_new(MyContextExpression *ctx);

GList* my_context_bitwise_expression_rule_get_expression(MyContextBitwiseExpression* self);// of MyContextExpression
MyContextExpression* my_context_bitwise_expression_at_rule_get_expression(MyContextBitwiseExpression* self, size_t i);



#define MY_TYPE_CONTEXT_CLONE_EXPRESSION            (my_context_clone_expression_get_type())
#define MY_CONTEXT_CLONE_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CLONE_EXPRESSION, MyContextCloneExpression))
#define MY_CONTEXT_CLONE_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CLONE_EXPRESSION, MyContextCloneExpressionClass))
#define MY_IS_CONTEXT_CLONE_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CLONE_EXPRESSION))
#define MY_IS_CONTEXT_CLONE_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CLONE_EXPRESSION))
#define MY_CONTEXT_CLONE_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CLONE_EXPRESSION, MyContextCloneExpressionClass))


typedef struct _MyContextCloneExpression      MyContextCloneExpression;
typedef struct _MyContextCloneExpressionClass MyContextCloneExpressionClass;

struct _MyContextCloneExpression {
    /*< private >*/
    MyContextExpression parent_instance;

    /*< public >*/
};

struct _MyContextCloneExpressionClass {
    /*< private >*/
    MyContextExpressionClass parent_class;
};

GType my_context_clone_expression_get_type(void) G_GNUC_CONST;
MyContextCloneExpression *my_context_clone_expression_new(MyContextExpression *ctx);

AntlrTerminalNode *my_context_clone_expression_token_get_clone(MyContextCloneExpression* self);
MyContextExpression *my_context_clone_expression_rule_get_expression(MyContextCloneExpression* self);



MyContextExpression* my_php_parser_parse_expression(MyPhpParser* self, GError **error);
MyContextExpression* my_php_parser_parse_expression_with_precedence(MyPhpParser* self, gint precedence, GError **error);

//----------------- NewExprContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_NEW_EXPR            (my_context_new_expr_get_type())
#define MY_CONTEXT_NEW_EXPR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_NEW_EXPR, MyContextNewExpr))
#define MY_CONTEXT_NEW_EXPR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_NEW_EXPR, MyContextNewExprClass))
#define MY_IS_CONTEXT_NEW_EXPR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_NEW_EXPR))
#define MY_IS_CONTEXT_NEW_EXPR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_NEW_EXPR))
#define MY_CONTEXT_NEW_EXPR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_NEW_EXPR, MyContextNewExprClass))


//typedef struct _MyContextNewExpr      MyContextNewExpr;
typedef struct _MyContextNewExprClass MyContextNewExprClass;

struct _MyContextNewExpr {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextNewExprClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_new_expr_get_type(void) G_GNUC_CONST;
MyContextNewExpr *my_context_new_expr_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_new_expr_token_get_new(MyContextNewExpr* self);
MyContextTypeRef *my_context_new_expr_rule_get_type_ref(MyContextNewExpr* self);
MyContextArguments *my_context_new_expr_rule_get_arguments(MyContextNewExpr* self);


MyContextNewExpr* my_php_parser_parse_new_expr(MyPhpParser* self, GError **error);
//----------------- AssignmentOperatorContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ASSIGNMENT_OPERATOR            (my_context_assignment_operator_get_type())
#define MY_CONTEXT_ASSIGNMENT_OPERATOR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ASSIGNMENT_OPERATOR, MyContextAssignmentOperator))
#define MY_CONTEXT_ASSIGNMENT_OPERATOR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ASSIGNMENT_OPERATOR, MyContextAssignmentOperatorClass))
#define MY_IS_CONTEXT_ASSIGNMENT_OPERATOR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ASSIGNMENT_OPERATOR))
#define MY_IS_CONTEXT_ASSIGNMENT_OPERATOR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ASSIGNMENT_OPERATOR))
#define MY_CONTEXT_ASSIGNMENT_OPERATOR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ASSIGNMENT_OPERATOR, MyContextAssignmentOperatorClass))


//typedef struct _MyContextAssignmentOperator      MyContextAssignmentOperator;
typedef struct _MyContextAssignmentOperatorClass MyContextAssignmentOperatorClass;

struct _MyContextAssignmentOperator {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAssignmentOperatorClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_assignment_operator_get_type(void) G_GNUC_CONST;
MyContextAssignmentOperator *my_context_assignment_operator_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_assignment_operator_token_get_eq(MyContextAssignmentOperator* self);


MyContextAssignmentOperator* my_php_parser_parse_assignment_operator(MyPhpParser* self, GError **error);
//----------------- YieldExpressionContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_YIELD_EXPRESSION            (my_context_yield_expression_get_type())
#define MY_CONTEXT_YIELD_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_YIELD_EXPRESSION, MyContextYieldExpression))
#define MY_CONTEXT_YIELD_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_YIELD_EXPRESSION, MyContextYieldExpressionClass))
#define MY_IS_CONTEXT_YIELD_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_YIELD_EXPRESSION))
#define MY_IS_CONTEXT_YIELD_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_YIELD_EXPRESSION))
#define MY_CONTEXT_YIELD_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_YIELD_EXPRESSION, MyContextYieldExpressionClass))


//typedef struct _MyContextYieldExpression      MyContextYieldExpression;
typedef struct _MyContextYieldExpressionClass MyContextYieldExpressionClass;

struct _MyContextYieldExpression {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextYieldExpressionClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_yield_expression_get_type(void) G_GNUC_CONST;
MyContextYieldExpression *my_context_yield_expression_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_yield_expression_token_get_yield(MyContextYieldExpression* self);
GList* my_context_yield_expression_rule_get_expression(MyContextYieldExpression* self);// of MyContextExpression
MyContextExpression* my_context_yield_expression_at_rule_get_expression(MyContextYieldExpression* self, size_t i);


MyContextYieldExpression* my_php_parser_parse_yield_expression(MyPhpParser* self, GError **error);
//----------------- ArrayItemListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ARRAY_ITEM_LIST            (my_context_array_item_list_get_type())
#define MY_CONTEXT_ARRAY_ITEM_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ARRAY_ITEM_LIST, MyContextArrayItemList))
#define MY_CONTEXT_ARRAY_ITEM_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ARRAY_ITEM_LIST, MyContextArrayItemListClass))
#define MY_IS_CONTEXT_ARRAY_ITEM_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ARRAY_ITEM_LIST))
#define MY_IS_CONTEXT_ARRAY_ITEM_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ARRAY_ITEM_LIST))
#define MY_CONTEXT_ARRAY_ITEM_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ARRAY_ITEM_LIST, MyContextArrayItemListClass))


//typedef struct _MyContextArrayItemList      MyContextArrayItemList;
typedef struct _MyContextArrayItemListClass MyContextArrayItemListClass;

struct _MyContextArrayItemList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextArrayItemListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_array_item_list_get_type(void) G_GNUC_CONST;
MyContextArrayItemList *my_context_array_item_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_array_item_list_rule_get_array_item(MyContextArrayItemList* self);// of MyContextArrayItem
MyContextArrayItem* my_context_array_item_list_at_rule_get_array_item(MyContextArrayItemList* self, size_t i);


MyContextArrayItemList* my_php_parser_parse_array_item_list(MyPhpParser* self, GError **error);
//----------------- ArrayItemContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ARRAY_ITEM            (my_context_array_item_get_type())
#define MY_CONTEXT_ARRAY_ITEM(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ARRAY_ITEM, MyContextArrayItem))
#define MY_CONTEXT_ARRAY_ITEM_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ARRAY_ITEM, MyContextArrayItemClass))
#define MY_IS_CONTEXT_ARRAY_ITEM(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ARRAY_ITEM))
#define MY_IS_CONTEXT_ARRAY_ITEM_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ARRAY_ITEM))
#define MY_CONTEXT_ARRAY_ITEM_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ARRAY_ITEM, MyContextArrayItemClass))


//typedef struct _MyContextArrayItem      MyContextArrayItem;
typedef struct _MyContextArrayItemClass MyContextArrayItemClass;

struct _MyContextArrayItem {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextArrayItemClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_array_item_get_type(void) G_GNUC_CONST;
MyContextArrayItem *my_context_array_item_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_array_item_rule_get_expression(MyContextArrayItem* self);// of MyContextExpression
MyContextExpression* my_context_array_item_at_rule_get_expression(MyContextArrayItem* self, size_t i);
MyContextChain *my_context_array_item_rule_get_chain(MyContextArrayItem* self);


MyContextArrayItem* my_php_parser_parse_array_item(MyPhpParser* self, GError **error);
//----------------- LambdaFunctionUseVarsContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VARS            (my_context_lambda_function_use_vars_get_type())
#define MY_CONTEXT_LAMBDA_FUNCTION_USE_VARS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VARS, MyContextLambdaFunctionUseVars))
#define MY_CONTEXT_LAMBDA_FUNCTION_USE_VARS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VARS, MyContextLambdaFunctionUseVarsClass))
#define MY_IS_CONTEXT_LAMBDA_FUNCTION_USE_VARS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VARS))
#define MY_IS_CONTEXT_LAMBDA_FUNCTION_USE_VARS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VARS))
#define MY_CONTEXT_LAMBDA_FUNCTION_USE_VARS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VARS, MyContextLambdaFunctionUseVarsClass))


//typedef struct _MyContextLambdaFunctionUseVars      MyContextLambdaFunctionUseVars;
typedef struct _MyContextLambdaFunctionUseVarsClass MyContextLambdaFunctionUseVarsClass;

struct _MyContextLambdaFunctionUseVars {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextLambdaFunctionUseVarsClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_lambda_function_use_vars_get_type(void) G_GNUC_CONST;
MyContextLambdaFunctionUseVars *my_context_lambda_function_use_vars_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_lambda_function_use_vars_token_get_use(MyContextLambdaFunctionUseVars* self);
GList* my_context_lambda_function_use_vars_rule_get_lambda_function_use_var(MyContextLambdaFunctionUseVars* self);// of MyContextLambdaFunctionUseVar
MyContextLambdaFunctionUseVar* my_context_lambda_function_use_vars_at_rule_get_lambda_function_use_var(MyContextLambdaFunctionUseVars* self, size_t i);


MyContextLambdaFunctionUseVars* my_php_parser_parse_lambda_function_use_vars(MyPhpParser* self, GError **error);
//----------------- LambdaFunctionUseVarContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VAR            (my_context_lambda_function_use_var_get_type())
#define MY_CONTEXT_LAMBDA_FUNCTION_USE_VAR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VAR, MyContextLambdaFunctionUseVar))
#define MY_CONTEXT_LAMBDA_FUNCTION_USE_VAR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VAR, MyContextLambdaFunctionUseVarClass))
#define MY_IS_CONTEXT_LAMBDA_FUNCTION_USE_VAR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VAR))
#define MY_IS_CONTEXT_LAMBDA_FUNCTION_USE_VAR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VAR))
#define MY_CONTEXT_LAMBDA_FUNCTION_USE_VAR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_LAMBDA_FUNCTION_USE_VAR, MyContextLambdaFunctionUseVarClass))


//typedef struct _MyContextLambdaFunctionUseVar      MyContextLambdaFunctionUseVar;
typedef struct _MyContextLambdaFunctionUseVarClass MyContextLambdaFunctionUseVarClass;

struct _MyContextLambdaFunctionUseVar {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextLambdaFunctionUseVarClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_lambda_function_use_var_get_type(void) G_GNUC_CONST;
MyContextLambdaFunctionUseVar *my_context_lambda_function_use_var_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_lambda_function_use_var_token_get_var_name(MyContextLambdaFunctionUseVar* self);


MyContextLambdaFunctionUseVar* my_php_parser_parse_lambda_function_use_var(MyPhpParser* self, GError **error);
//----------------- QualifiedStaticTypeRefContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_QUALIFIED_STATIC_TYPE_REF            (my_context_qualified_static_type_ref_get_type())
#define MY_CONTEXT_QUALIFIED_STATIC_TYPE_REF(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_QUALIFIED_STATIC_TYPE_REF, MyContextQualifiedStaticTypeRef))
#define MY_CONTEXT_QUALIFIED_STATIC_TYPE_REF_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_QUALIFIED_STATIC_TYPE_REF, MyContextQualifiedStaticTypeRefClass))
#define MY_IS_CONTEXT_QUALIFIED_STATIC_TYPE_REF(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_QUALIFIED_STATIC_TYPE_REF))
#define MY_IS_CONTEXT_QUALIFIED_STATIC_TYPE_REF_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_QUALIFIED_STATIC_TYPE_REF))
#define MY_CONTEXT_QUALIFIED_STATIC_TYPE_REF_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_QUALIFIED_STATIC_TYPE_REF, MyContextQualifiedStaticTypeRefClass))


//typedef struct _MyContextQualifiedStaticTypeRef      MyContextQualifiedStaticTypeRef;
typedef struct _MyContextQualifiedStaticTypeRefClass MyContextQualifiedStaticTypeRefClass;

struct _MyContextQualifiedStaticTypeRef {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextQualifiedStaticTypeRefClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_qualified_static_type_ref_get_type(void) G_GNUC_CONST;
MyContextQualifiedStaticTypeRef *my_context_qualified_static_type_ref_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextQualifiedNamespaceName *my_context_qualified_static_type_ref_rule_get_qualified_namespace_name(MyContextQualifiedStaticTypeRef* self);
MyContextGenericDynamicArgs *my_context_qualified_static_type_ref_rule_get_generic_dynamic_args(MyContextQualifiedStaticTypeRef* self);
AntlrTerminalNode *my_context_qualified_static_type_ref_token_get_static(MyContextQualifiedStaticTypeRef* self);


MyContextQualifiedStaticTypeRef* my_php_parser_parse_qualified_static_type_ref(MyPhpParser* self, GError **error);
//----------------- TypeRefContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_TYPE_REF            (my_context_type_ref_get_type())
#define MY_CONTEXT_TYPE_REF(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_TYPE_REF, MyContextTypeRef))
#define MY_CONTEXT_TYPE_REF_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_TYPE_REF, MyContextTypeRefClass))
#define MY_IS_CONTEXT_TYPE_REF(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_TYPE_REF))
#define MY_IS_CONTEXT_TYPE_REF_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_TYPE_REF))
#define MY_CONTEXT_TYPE_REF_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_TYPE_REF, MyContextTypeRefClass))


//typedef struct _MyContextTypeRef      MyContextTypeRef;
typedef struct _MyContextTypeRefClass MyContextTypeRefClass;

struct _MyContextTypeRef {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextTypeRefClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_type_ref_get_type(void) G_GNUC_CONST;
MyContextTypeRef *my_context_type_ref_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextQualifiedNamespaceName *my_context_type_ref_rule_get_qualified_namespace_name(MyContextTypeRef* self);
MyContextIndirectTypeRef *my_context_type_ref_rule_get_indirect_type_ref(MyContextTypeRef* self);
MyContextGenericDynamicArgs *my_context_type_ref_rule_get_generic_dynamic_args(MyContextTypeRef* self);
MyContextPrimitiveType *my_context_type_ref_rule_get_primitive_type(MyContextTypeRef* self);
AntlrTerminalNode *my_context_type_ref_token_get_static(MyContextTypeRef* self);


MyContextTypeRef* my_php_parser_parse_type_ref(MyPhpParser* self, GError **error);
//----------------- IndirectTypeRefContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_INDIRECT_TYPE_REF            (my_context_indirect_type_ref_get_type())
#define MY_CONTEXT_INDIRECT_TYPE_REF(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_INDIRECT_TYPE_REF, MyContextIndirectTypeRef))
#define MY_CONTEXT_INDIRECT_TYPE_REF_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_INDIRECT_TYPE_REF, MyContextIndirectTypeRefClass))
#define MY_IS_CONTEXT_INDIRECT_TYPE_REF(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_INDIRECT_TYPE_REF))
#define MY_IS_CONTEXT_INDIRECT_TYPE_REF_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_INDIRECT_TYPE_REF))
#define MY_CONTEXT_INDIRECT_TYPE_REF_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_INDIRECT_TYPE_REF, MyContextIndirectTypeRefClass))


//typedef struct _MyContextIndirectTypeRef      MyContextIndirectTypeRef;
typedef struct _MyContextIndirectTypeRefClass MyContextIndirectTypeRefClass;

struct _MyContextIndirectTypeRef {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextIndirectTypeRefClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_indirect_type_ref_get_type(void) G_GNUC_CONST;
MyContextIndirectTypeRef *my_context_indirect_type_ref_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextChainBase *my_context_indirect_type_ref_rule_get_chain_base(MyContextIndirectTypeRef* self);
GList* my_context_indirect_type_ref_rule_get_keyed_field_name(MyContextIndirectTypeRef* self);// of MyContextKeyedFieldName
MyContextKeyedFieldName* my_context_indirect_type_ref_at_rule_get_keyed_field_name(MyContextIndirectTypeRef* self, size_t i);


MyContextIndirectTypeRef* my_php_parser_parse_indirect_type_ref(MyPhpParser* self, GError **error);
//----------------- QualifiedNamespaceNameContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME            (my_context_qualified_namespace_name_get_type())
#define MY_CONTEXT_QUALIFIED_NAMESPACE_NAME(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME, MyContextQualifiedNamespaceName))
#define MY_CONTEXT_QUALIFIED_NAMESPACE_NAME_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME, MyContextQualifiedNamespaceNameClass))
#define MY_IS_CONTEXT_QUALIFIED_NAMESPACE_NAME(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME))
#define MY_IS_CONTEXT_QUALIFIED_NAMESPACE_NAME_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME))
#define MY_CONTEXT_QUALIFIED_NAMESPACE_NAME_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME, MyContextQualifiedNamespaceNameClass))


//typedef struct _MyContextQualifiedNamespaceName      MyContextQualifiedNamespaceName;
typedef struct _MyContextQualifiedNamespaceNameClass MyContextQualifiedNamespaceNameClass;

struct _MyContextQualifiedNamespaceName {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextQualifiedNamespaceNameClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_qualified_namespace_name_get_type(void) G_GNUC_CONST;
MyContextQualifiedNamespaceName *my_context_qualified_namespace_name_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextNamespaceNameList *my_context_qualified_namespace_name_rule_get_namespace_name_list(MyContextQualifiedNamespaceName* self);
AntlrTerminalNode *my_context_qualified_namespace_name_token_get_namespace(MyContextQualifiedNamespaceName* self);


MyContextQualifiedNamespaceName* my_php_parser_parse_qualified_namespace_name(MyPhpParser* self, GError **error);
//----------------- NamespaceNameListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_NAMESPACE_NAME_LIST            (my_context_namespace_name_list_get_type())
#define MY_CONTEXT_NAMESPACE_NAME_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_NAMESPACE_NAME_LIST, MyContextNamespaceNameList))
#define MY_CONTEXT_NAMESPACE_NAME_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_NAMESPACE_NAME_LIST, MyContextNamespaceNameListClass))
#define MY_IS_CONTEXT_NAMESPACE_NAME_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_NAMESPACE_NAME_LIST))
#define MY_IS_CONTEXT_NAMESPACE_NAME_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_NAMESPACE_NAME_LIST))
#define MY_CONTEXT_NAMESPACE_NAME_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_NAMESPACE_NAME_LIST, MyContextNamespaceNameListClass))


//typedef struct _MyContextNamespaceNameList      MyContextNamespaceNameList;
typedef struct _MyContextNamespaceNameListClass MyContextNamespaceNameListClass;

struct _MyContextNamespaceNameList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextNamespaceNameListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_namespace_name_list_get_type(void) G_GNUC_CONST;
MyContextNamespaceNameList *my_context_namespace_name_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_namespace_name_list_rule_get_identifier(MyContextNamespaceNameList* self);// of MyContextIdentifier
MyContextIdentifier* my_context_namespace_name_list_at_rule_get_identifier(MyContextNamespaceNameList* self, size_t i);


MyContextNamespaceNameList* my_php_parser_parse_namespace_name_list(MyPhpParser* self, GError **error);
//----------------- QualifiedNamespaceNameListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST            (my_context_qualified_namespace_name_list_get_type())
#define MY_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST, MyContextQualifiedNamespaceNameList))
#define MY_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST, MyContextQualifiedNamespaceNameListClass))
#define MY_IS_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST))
#define MY_IS_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST))
#define MY_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_QUALIFIED_NAMESPACE_NAME_LIST, MyContextQualifiedNamespaceNameListClass))


//typedef struct _MyContextQualifiedNamespaceNameList      MyContextQualifiedNamespaceNameList;
typedef struct _MyContextQualifiedNamespaceNameListClass MyContextQualifiedNamespaceNameListClass;

struct _MyContextQualifiedNamespaceNameList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextQualifiedNamespaceNameListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_qualified_namespace_name_list_get_type(void) G_GNUC_CONST;
MyContextQualifiedNamespaceNameList *my_context_qualified_namespace_name_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_qualified_namespace_name_list_rule_get_qualified_namespace_name(MyContextQualifiedNamespaceNameList* self);// of MyContextQualifiedNamespaceName
MyContextQualifiedNamespaceName* my_context_qualified_namespace_name_list_at_rule_get_qualified_namespace_name(MyContextQualifiedNamespaceNameList* self, size_t i);


MyContextQualifiedNamespaceNameList* my_php_parser_parse_qualified_namespace_name_list(MyPhpParser* self, GError **error);
//----------------- ArgumentsContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ARGUMENTS            (my_context_arguments_get_type())
#define MY_CONTEXT_ARGUMENTS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ARGUMENTS, MyContextArguments))
#define MY_CONTEXT_ARGUMENTS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ARGUMENTS, MyContextArgumentsClass))
#define MY_IS_CONTEXT_ARGUMENTS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ARGUMENTS))
#define MY_IS_CONTEXT_ARGUMENTS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ARGUMENTS))
#define MY_CONTEXT_ARGUMENTS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ARGUMENTS, MyContextArgumentsClass))


//typedef struct _MyContextArguments      MyContextArguments;
typedef struct _MyContextArgumentsClass MyContextArgumentsClass;

struct _MyContextArguments {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextArgumentsClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_arguments_get_type(void) G_GNUC_CONST;
MyContextArguments *my_context_arguments_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_arguments_rule_get_actual_argument(MyContextArguments* self);// of MyContextActualArgument
MyContextActualArgument* my_context_arguments_at_rule_get_actual_argument(MyContextArguments* self, size_t i);
MyContextYieldExpression *my_context_arguments_rule_get_yield_expression(MyContextArguments* self);


MyContextArguments* my_php_parser_parse_arguments(MyPhpParser* self, GError **error);
//----------------- ActualArgumentContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ACTUAL_ARGUMENT            (my_context_actual_argument_get_type())
#define MY_CONTEXT_ACTUAL_ARGUMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ACTUAL_ARGUMENT, MyContextActualArgument))
#define MY_CONTEXT_ACTUAL_ARGUMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ACTUAL_ARGUMENT, MyContextActualArgumentClass))
#define MY_IS_CONTEXT_ACTUAL_ARGUMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ACTUAL_ARGUMENT))
#define MY_IS_CONTEXT_ACTUAL_ARGUMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ACTUAL_ARGUMENT))
#define MY_CONTEXT_ACTUAL_ARGUMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ACTUAL_ARGUMENT, MyContextActualArgumentClass))


//typedef struct _MyContextActualArgument      MyContextActualArgument;
typedef struct _MyContextActualArgumentClass MyContextActualArgumentClass;

struct _MyContextActualArgument {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextActualArgumentClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_actual_argument_get_type(void) G_GNUC_CONST;
MyContextActualArgument *my_context_actual_argument_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextExpression *my_context_actual_argument_rule_get_expression(MyContextActualArgument* self);
MyContextChain *my_context_actual_argument_rule_get_chain(MyContextActualArgument* self);


MyContextActualArgument* my_php_parser_parse_actual_argument(MyPhpParser* self, GError **error);
//----------------- ConstantInititalizerContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CONSTANT_INITITALIZER            (my_context_constant_inititalizer_get_type())
#define MY_CONTEXT_CONSTANT_INITITALIZER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CONSTANT_INITITALIZER, MyContextConstantInititalizer))
#define MY_CONTEXT_CONSTANT_INITITALIZER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CONSTANT_INITITALIZER, MyContextConstantInititalizerClass))
#define MY_IS_CONTEXT_CONSTANT_INITITALIZER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CONSTANT_INITITALIZER))
#define MY_IS_CONTEXT_CONSTANT_INITITALIZER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CONSTANT_INITITALIZER))
#define MY_CONTEXT_CONSTANT_INITITALIZER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CONSTANT_INITITALIZER, MyContextConstantInititalizerClass))


//typedef struct _MyContextConstantInititalizer      MyContextConstantInititalizer;
typedef struct _MyContextConstantInititalizerClass MyContextConstantInititalizerClass;

struct _MyContextConstantInititalizer {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextConstantInititalizerClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_constant_inititalizer_get_type(void) G_GNUC_CONST;
MyContextConstantInititalizer *my_context_constant_inititalizer_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextConstant *my_context_constant_inititalizer_rule_get_constant(MyContextConstantInititalizer* self);
MyContextString *my_context_constant_inititalizer_rule_get_string(MyContextConstantInititalizer* self);
AntlrTerminalNode *my_context_constant_inititalizer_token_get_array(MyContextConstantInititalizer* self);
MyContextConstantArrayItemList *my_context_constant_inititalizer_rule_get_constant_array_item_list(MyContextConstantInititalizer* self);
MyContextConstantInititalizer *my_context_constant_inititalizer_rule_get_constant_inititalizer(MyContextConstantInititalizer* self);


MyContextConstantInititalizer* my_php_parser_parse_constant_inititalizer(MyPhpParser* self, GError **error);
//----------------- ConstantArrayItemListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM_LIST            (my_context_constant_array_item_list_get_type())
#define MY_CONTEXT_CONSTANT_ARRAY_ITEM_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM_LIST, MyContextConstantArrayItemList))
#define MY_CONTEXT_CONSTANT_ARRAY_ITEM_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM_LIST, MyContextConstantArrayItemListClass))
#define MY_IS_CONTEXT_CONSTANT_ARRAY_ITEM_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM_LIST))
#define MY_IS_CONTEXT_CONSTANT_ARRAY_ITEM_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM_LIST))
#define MY_CONTEXT_CONSTANT_ARRAY_ITEM_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM_LIST, MyContextConstantArrayItemListClass))


//typedef struct _MyContextConstantArrayItemList      MyContextConstantArrayItemList;
typedef struct _MyContextConstantArrayItemListClass MyContextConstantArrayItemListClass;

struct _MyContextConstantArrayItemList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextConstantArrayItemListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_constant_array_item_list_get_type(void) G_GNUC_CONST;
MyContextConstantArrayItemList *my_context_constant_array_item_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_constant_array_item_list_rule_get_constant_array_item(MyContextConstantArrayItemList* self);// of MyContextConstantArrayItem
MyContextConstantArrayItem* my_context_constant_array_item_list_at_rule_get_constant_array_item(MyContextConstantArrayItemList* self, size_t i);


MyContextConstantArrayItemList* my_php_parser_parse_constant_array_item_list(MyPhpParser* self, GError **error);
//----------------- ConstantArrayItemContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM            (my_context_constant_array_item_get_type())
#define MY_CONTEXT_CONSTANT_ARRAY_ITEM(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM, MyContextConstantArrayItem))
#define MY_CONTEXT_CONSTANT_ARRAY_ITEM_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM, MyContextConstantArrayItemClass))
#define MY_IS_CONTEXT_CONSTANT_ARRAY_ITEM(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM))
#define MY_IS_CONTEXT_CONSTANT_ARRAY_ITEM_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM))
#define MY_CONTEXT_CONSTANT_ARRAY_ITEM_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CONSTANT_ARRAY_ITEM, MyContextConstantArrayItemClass))


//typedef struct _MyContextConstantArrayItem      MyContextConstantArrayItem;
typedef struct _MyContextConstantArrayItemClass MyContextConstantArrayItemClass;

struct _MyContextConstantArrayItem {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextConstantArrayItemClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_constant_array_item_get_type(void) G_GNUC_CONST;
MyContextConstantArrayItem *my_context_constant_array_item_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_constant_array_item_rule_get_constant_inititalizer(MyContextConstantArrayItem* self);// of MyContextConstantInititalizer
MyContextConstantInititalizer* my_context_constant_array_item_at_rule_get_constant_inititalizer(MyContextConstantArrayItem* self, size_t i);


MyContextConstantArrayItem* my_php_parser_parse_constant_array_item(MyPhpParser* self, GError **error);
//----------------- ConstantContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CONSTANT            (my_context_constant_get_type())
#define MY_CONTEXT_CONSTANT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CONSTANT, MyContextConstant))
#define MY_CONTEXT_CONSTANT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CONSTANT, MyContextConstantClass))
#define MY_IS_CONTEXT_CONSTANT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CONSTANT))
#define MY_IS_CONTEXT_CONSTANT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CONSTANT))
#define MY_CONTEXT_CONSTANT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CONSTANT, MyContextConstantClass))


//typedef struct _MyContextConstant      MyContextConstant;
typedef struct _MyContextConstantClass MyContextConstantClass;

struct _MyContextConstant {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextConstantClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_constant_get_type(void) G_GNUC_CONST;
MyContextConstant *my_context_constant_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_constant_token_get_null(MyContextConstant* self);
MyContextLiteralConstant *my_context_constant_rule_get_literal_constant(MyContextConstant* self);
MyContextMagicConstant *my_context_constant_rule_get_magic_constant(MyContextConstant* self);
MyContextClassConstant *my_context_constant_rule_get_class_constant(MyContextConstant* self);
MyContextQualifiedNamespaceName *my_context_constant_rule_get_qualified_namespace_name(MyContextConstant* self);


MyContextConstant* my_php_parser_parse_constant(MyPhpParser* self, GError **error);
//----------------- LiteralConstantContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_LITERAL_CONSTANT            (my_context_literal_constant_get_type())
#define MY_CONTEXT_LITERAL_CONSTANT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_LITERAL_CONSTANT, MyContextLiteralConstant))
#define MY_CONTEXT_LITERAL_CONSTANT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_LITERAL_CONSTANT, MyContextLiteralConstantClass))
#define MY_IS_CONTEXT_LITERAL_CONSTANT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_LITERAL_CONSTANT))
#define MY_IS_CONTEXT_LITERAL_CONSTANT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_LITERAL_CONSTANT))
#define MY_CONTEXT_LITERAL_CONSTANT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_LITERAL_CONSTANT, MyContextLiteralConstantClass))


//typedef struct _MyContextLiteralConstant      MyContextLiteralConstant;
typedef struct _MyContextLiteralConstantClass MyContextLiteralConstantClass;

struct _MyContextLiteralConstant {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextLiteralConstantClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_literal_constant_get_type(void) G_GNUC_CONST;
MyContextLiteralConstant *my_context_literal_constant_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_literal_constant_token_get_real(MyContextLiteralConstant* self);
AntlrTerminalNode *my_context_literal_constant_token_get_boolean_constant(MyContextLiteralConstant* self);
MyContextNumericConstant *my_context_literal_constant_rule_get_numeric_constant(MyContextLiteralConstant* self);
MyContextStringConstant *my_context_literal_constant_rule_get_string_constant(MyContextLiteralConstant* self);


MyContextLiteralConstant* my_php_parser_parse_literal_constant(MyPhpParser* self, GError **error);
//----------------- NumericConstantContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_NUMERIC_CONSTANT            (my_context_numeric_constant_get_type())
#define MY_CONTEXT_NUMERIC_CONSTANT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_NUMERIC_CONSTANT, MyContextNumericConstant))
#define MY_CONTEXT_NUMERIC_CONSTANT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_NUMERIC_CONSTANT, MyContextNumericConstantClass))
#define MY_IS_CONTEXT_NUMERIC_CONSTANT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_NUMERIC_CONSTANT))
#define MY_IS_CONTEXT_NUMERIC_CONSTANT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_NUMERIC_CONSTANT))
#define MY_CONTEXT_NUMERIC_CONSTANT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_NUMERIC_CONSTANT, MyContextNumericConstantClass))


//typedef struct _MyContextNumericConstant      MyContextNumericConstant;
typedef struct _MyContextNumericConstantClass MyContextNumericConstantClass;

struct _MyContextNumericConstant {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextNumericConstantClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_numeric_constant_get_type(void) G_GNUC_CONST;
MyContextNumericConstant *my_context_numeric_constant_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_numeric_constant_token_get_octal(MyContextNumericConstant* self);
AntlrTerminalNode *my_context_numeric_constant_token_get_decimal(MyContextNumericConstant* self);
AntlrTerminalNode *my_context_numeric_constant_token_get_hex(MyContextNumericConstant* self);
AntlrTerminalNode *my_context_numeric_constant_token_get_binary(MyContextNumericConstant* self);


MyContextNumericConstant* my_php_parser_parse_numeric_constant(MyPhpParser* self, GError **error);
//----------------- ClassConstantContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CLASS_CONSTANT            (my_context_class_constant_get_type())
#define MY_CONTEXT_CLASS_CONSTANT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CLASS_CONSTANT, MyContextClassConstant))
#define MY_CONTEXT_CLASS_CONSTANT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CLASS_CONSTANT, MyContextClassConstantClass))
#define MY_IS_CONTEXT_CLASS_CONSTANT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CLASS_CONSTANT))
#define MY_IS_CONTEXT_CLASS_CONSTANT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CLASS_CONSTANT))
#define MY_CONTEXT_CLASS_CONSTANT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CLASS_CONSTANT, MyContextClassConstantClass))


//typedef struct _MyContextClassConstant      MyContextClassConstant;
typedef struct _MyContextClassConstantClass MyContextClassConstantClass;

struct _MyContextClassConstant {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextClassConstantClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_class_constant_get_type(void) G_GNUC_CONST;
MyContextClassConstant *my_context_class_constant_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_class_constant_token_get_class(MyContextClassConstant* self);
AntlrTerminalNode *my_context_class_constant_token_get_parent_(MyContextClassConstant* self);
MyContextIdentifier *my_context_class_constant_rule_get_identifier(MyContextClassConstant* self);
AntlrTerminalNode *my_context_class_constant_token_get_constructor(MyContextClassConstant* self);
AntlrTerminalNode *my_context_class_constant_token_get_get(MyContextClassConstant* self);
AntlrTerminalNode *my_context_class_constant_token_get_set(MyContextClassConstant* self);
MyContextQualifiedStaticTypeRef *my_context_class_constant_rule_get_qualified_static_type_ref(MyContextClassConstant* self);
MyContextKeyedVariable *my_context_class_constant_rule_get_keyed_variable(MyContextClassConstant* self);


MyContextClassConstant* my_php_parser_parse_class_constant(MyPhpParser* self, GError **error);
//----------------- StringConstantContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_STRING_CONSTANT            (my_context_string_constant_get_type())
#define MY_CONTEXT_STRING_CONSTANT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_STRING_CONSTANT, MyContextStringConstant))
#define MY_CONTEXT_STRING_CONSTANT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_STRING_CONSTANT, MyContextStringConstantClass))
#define MY_IS_CONTEXT_STRING_CONSTANT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_STRING_CONSTANT))
#define MY_IS_CONTEXT_STRING_CONSTANT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_STRING_CONSTANT))
#define MY_CONTEXT_STRING_CONSTANT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_STRING_CONSTANT, MyContextStringConstantClass))


//typedef struct _MyContextStringConstant      MyContextStringConstant;
typedef struct _MyContextStringConstantClass MyContextStringConstantClass;

struct _MyContextStringConstant {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextStringConstantClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_string_constant_get_type(void) G_GNUC_CONST;
MyContextStringConstant *my_context_string_constant_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_string_constant_token_get_label(MyContextStringConstant* self);


MyContextStringConstant* my_php_parser_parse_string_constant(MyPhpParser* self, GError **error);
//----------------- StringContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_STRING            (my_context_string_get_type())
#define MY_CONTEXT_STRING(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_STRING, MyContextString))
#define MY_CONTEXT_STRING_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_STRING, MyContextStringClass))
#define MY_IS_CONTEXT_STRING(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_STRING))
#define MY_IS_CONTEXT_STRING_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_STRING))
#define MY_CONTEXT_STRING_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_STRING, MyContextStringClass))


//typedef struct _MyContextString      MyContextString;
typedef struct _MyContextStringClass MyContextStringClass;

struct _MyContextString {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextStringClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_string_get_type(void) G_GNUC_CONST;
MyContextString *my_context_string_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_string_token_get_start_here_doc(MyContextString* self);
GList* my_context_string_token_get_here_doc_text(MyContextString* self);// of AntlrTerminalNode*
AntlrTerminalNode *my_context_string_at_token_get_here_doc_text(MyContextString* self, size_t i);
AntlrTerminalNode *my_context_string_token_get_start_now_doc(MyContextString* self);
AntlrTerminalNode *my_context_string_token_get_single_quote_string(MyContextString* self);
GList* my_context_string_token_get_double_quote(MyContextString* self);// of AntlrTerminalNode*
AntlrTerminalNode *my_context_string_at_token_get_double_quote(MyContextString* self, size_t i);
GList* my_context_string_rule_get_interpolated_string_part(MyContextString* self);// of MyContextInterpolatedStringPart
MyContextInterpolatedStringPart* my_context_string_at_rule_get_interpolated_string_part(MyContextString* self, size_t i);


MyContextString* my_php_parser_parse_string(MyPhpParser* self, GError **error);
//----------------- InterpolatedStringPartContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_INTERPOLATED_STRING_PART            (my_context_interpolated_string_part_get_type())
#define MY_CONTEXT_INTERPOLATED_STRING_PART(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_INTERPOLATED_STRING_PART, MyContextInterpolatedStringPart))
#define MY_CONTEXT_INTERPOLATED_STRING_PART_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_INTERPOLATED_STRING_PART, MyContextInterpolatedStringPartClass))
#define MY_IS_CONTEXT_INTERPOLATED_STRING_PART(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_INTERPOLATED_STRING_PART))
#define MY_IS_CONTEXT_INTERPOLATED_STRING_PART_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_INTERPOLATED_STRING_PART))
#define MY_CONTEXT_INTERPOLATED_STRING_PART_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_INTERPOLATED_STRING_PART, MyContextInterpolatedStringPartClass))


//typedef struct _MyContextInterpolatedStringPart      MyContextInterpolatedStringPart;
typedef struct _MyContextInterpolatedStringPartClass MyContextInterpolatedStringPartClass;

struct _MyContextInterpolatedStringPart {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextInterpolatedStringPartClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_interpolated_string_part_get_type(void) G_GNUC_CONST;
MyContextInterpolatedStringPart *my_context_interpolated_string_part_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_interpolated_string_part_token_get_string_part(MyContextInterpolatedStringPart* self);
MyContextChain *my_context_interpolated_string_part_rule_get_chain(MyContextInterpolatedStringPart* self);


MyContextInterpolatedStringPart* my_php_parser_parse_interpolated_string_part(MyPhpParser* self, GError **error);
//----------------- ChainListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CHAIN_LIST            (my_context_chain_list_get_type())
#define MY_CONTEXT_CHAIN_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CHAIN_LIST, MyContextChainList))
#define MY_CONTEXT_CHAIN_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CHAIN_LIST, MyContextChainListClass))
#define MY_IS_CONTEXT_CHAIN_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CHAIN_LIST))
#define MY_IS_CONTEXT_CHAIN_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CHAIN_LIST))
#define MY_CONTEXT_CHAIN_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CHAIN_LIST, MyContextChainListClass))


//typedef struct _MyContextChainList      MyContextChainList;
typedef struct _MyContextChainListClass MyContextChainListClass;

struct _MyContextChainList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextChainListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_chain_list_get_type(void) G_GNUC_CONST;
MyContextChainList *my_context_chain_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_chain_list_rule_get_chain(MyContextChainList* self);// of MyContextChain
MyContextChain* my_context_chain_list_at_rule_get_chain(MyContextChainList* self, size_t i);


MyContextChainList* my_php_parser_parse_chain_list(MyPhpParser* self, GError **error);
//----------------- ChainContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CHAIN            (my_context_chain_get_type())
#define MY_CONTEXT_CHAIN(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CHAIN, MyContextChain))
#define MY_CONTEXT_CHAIN_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CHAIN, MyContextChainClass))
#define MY_IS_CONTEXT_CHAIN(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CHAIN))
#define MY_IS_CONTEXT_CHAIN_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CHAIN))
#define MY_CONTEXT_CHAIN_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CHAIN, MyContextChainClass))


//typedef struct _MyContextChain      MyContextChain;
typedef struct _MyContextChainClass MyContextChainClass;

struct _MyContextChain {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextChainClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_chain_get_type(void) G_GNUC_CONST;
MyContextChain *my_context_chain_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextChainBase *my_context_chain_rule_get_chain_base(MyContextChain* self);
MyContextFunctionCall *my_context_chain_rule_get_function_call(MyContextChain* self);
MyContextNewExpr *my_context_chain_rule_get_new_expr(MyContextChain* self);
GList* my_context_chain_rule_get_member_access(MyContextChain* self);// of MyContextMemberAccess
MyContextMemberAccess* my_context_chain_at_rule_get_member_access(MyContextChain* self, size_t i);


MyContextChain* my_php_parser_parse_chain(MyPhpParser* self, GError **error);
//----------------- MemberAccessContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_MEMBER_ACCESS            (my_context_member_access_get_type())
#define MY_CONTEXT_MEMBER_ACCESS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_MEMBER_ACCESS, MyContextMemberAccess))
#define MY_CONTEXT_MEMBER_ACCESS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_MEMBER_ACCESS, MyContextMemberAccessClass))
#define MY_IS_CONTEXT_MEMBER_ACCESS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_MEMBER_ACCESS))
#define MY_IS_CONTEXT_MEMBER_ACCESS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_MEMBER_ACCESS))
#define MY_CONTEXT_MEMBER_ACCESS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_MEMBER_ACCESS, MyContextMemberAccessClass))


//typedef struct _MyContextMemberAccess      MyContextMemberAccess;
typedef struct _MyContextMemberAccessClass MyContextMemberAccessClass;

struct _MyContextMemberAccess {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextMemberAccessClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_member_access_get_type(void) G_GNUC_CONST;
MyContextMemberAccess *my_context_member_access_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextKeyedFieldName *my_context_member_access_rule_get_keyed_field_name(MyContextMemberAccess* self);
MyContextActualArguments *my_context_member_access_rule_get_actual_arguments(MyContextMemberAccess* self);


MyContextMemberAccess* my_php_parser_parse_member_access(MyPhpParser* self, GError **error);
//----------------- FunctionCallContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FUNCTION_CALL            (my_context_function_call_get_type())
#define MY_CONTEXT_FUNCTION_CALL(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FUNCTION_CALL, MyContextFunctionCall))
#define MY_CONTEXT_FUNCTION_CALL_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FUNCTION_CALL, MyContextFunctionCallClass))
#define MY_IS_CONTEXT_FUNCTION_CALL(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FUNCTION_CALL))
#define MY_IS_CONTEXT_FUNCTION_CALL_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FUNCTION_CALL))
#define MY_CONTEXT_FUNCTION_CALL_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FUNCTION_CALL, MyContextFunctionCallClass))


//typedef struct _MyContextFunctionCall      MyContextFunctionCall;
typedef struct _MyContextFunctionCallClass MyContextFunctionCallClass;

struct _MyContextFunctionCall {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextFunctionCallClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_function_call_get_type(void) G_GNUC_CONST;
MyContextFunctionCall *my_context_function_call_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextFunctionCallName *my_context_function_call_rule_get_function_call_name(MyContextFunctionCall* self);
MyContextActualArguments *my_context_function_call_rule_get_actual_arguments(MyContextFunctionCall* self);


MyContextFunctionCall* my_php_parser_parse_function_call(MyPhpParser* self, GError **error);
//----------------- FunctionCallNameContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FUNCTION_CALL_NAME            (my_context_function_call_name_get_type())
#define MY_CONTEXT_FUNCTION_CALL_NAME(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FUNCTION_CALL_NAME, MyContextFunctionCallName))
#define MY_CONTEXT_FUNCTION_CALL_NAME_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FUNCTION_CALL_NAME, MyContextFunctionCallNameClass))
#define MY_IS_CONTEXT_FUNCTION_CALL_NAME(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FUNCTION_CALL_NAME))
#define MY_IS_CONTEXT_FUNCTION_CALL_NAME_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FUNCTION_CALL_NAME))
#define MY_CONTEXT_FUNCTION_CALL_NAME_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FUNCTION_CALL_NAME, MyContextFunctionCallNameClass))


//typedef struct _MyContextFunctionCallName      MyContextFunctionCallName;
typedef struct _MyContextFunctionCallNameClass MyContextFunctionCallNameClass;

struct _MyContextFunctionCallName {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextFunctionCallNameClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_function_call_name_get_type(void) G_GNUC_CONST;
MyContextFunctionCallName *my_context_function_call_name_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextQualifiedNamespaceName *my_context_function_call_name_rule_get_qualified_namespace_name(MyContextFunctionCallName* self);
MyContextClassConstant *my_context_function_call_name_rule_get_class_constant(MyContextFunctionCallName* self);
MyContextChainBase *my_context_function_call_name_rule_get_chain_base(MyContextFunctionCallName* self);


MyContextFunctionCallName* my_php_parser_parse_function_call_name(MyPhpParser* self, GError **error);
//----------------- ActualArgumentsContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ACTUAL_ARGUMENTS            (my_context_actual_arguments_get_type())
#define MY_CONTEXT_ACTUAL_ARGUMENTS(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ACTUAL_ARGUMENTS, MyContextActualArguments))
#define MY_CONTEXT_ACTUAL_ARGUMENTS_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ACTUAL_ARGUMENTS, MyContextActualArgumentsClass))
#define MY_IS_CONTEXT_ACTUAL_ARGUMENTS(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ACTUAL_ARGUMENTS))
#define MY_IS_CONTEXT_ACTUAL_ARGUMENTS_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ACTUAL_ARGUMENTS))
#define MY_CONTEXT_ACTUAL_ARGUMENTS_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ACTUAL_ARGUMENTS, MyContextActualArgumentsClass))


//typedef struct _MyContextActualArguments      MyContextActualArguments;
typedef struct _MyContextActualArgumentsClass MyContextActualArgumentsClass;

struct _MyContextActualArguments {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextActualArgumentsClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_actual_arguments_get_type(void) G_GNUC_CONST;
MyContextActualArguments *my_context_actual_arguments_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextArguments *my_context_actual_arguments_rule_get_arguments(MyContextActualArguments* self);
MyContextGenericDynamicArgs *my_context_actual_arguments_rule_get_generic_dynamic_args(MyContextActualArguments* self);
GList* my_context_actual_arguments_rule_get_square_curly_expression(MyContextActualArguments* self);// of MyContextSquareCurlyExpression
MyContextSquareCurlyExpression* my_context_actual_arguments_at_rule_get_square_curly_expression(MyContextActualArguments* self, size_t i);


MyContextActualArguments* my_php_parser_parse_actual_arguments(MyPhpParser* self, GError **error);
//----------------- ChainBaseContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CHAIN_BASE            (my_context_chain_base_get_type())
#define MY_CONTEXT_CHAIN_BASE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CHAIN_BASE, MyContextChainBase))
#define MY_CONTEXT_CHAIN_BASE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CHAIN_BASE, MyContextChainBaseClass))
#define MY_IS_CONTEXT_CHAIN_BASE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CHAIN_BASE))
#define MY_IS_CONTEXT_CHAIN_BASE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CHAIN_BASE))
#define MY_CONTEXT_CHAIN_BASE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CHAIN_BASE, MyContextChainBaseClass))


//typedef struct _MyContextChainBase      MyContextChainBase;
typedef struct _MyContextChainBaseClass MyContextChainBaseClass;

struct _MyContextChainBase {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextChainBaseClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_chain_base_get_type(void) G_GNUC_CONST;
MyContextChainBase *my_context_chain_base_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_chain_base_rule_get_keyed_variable(MyContextChainBase* self);// of MyContextKeyedVariable
MyContextKeyedVariable* my_context_chain_base_at_rule_get_keyed_variable(MyContextChainBase* self, size_t i);
MyContextQualifiedStaticTypeRef *my_context_chain_base_rule_get_qualified_static_type_ref(MyContextChainBase* self);


MyContextChainBase* my_php_parser_parse_chain_base(MyPhpParser* self, GError **error);
//----------------- KeyedFieldNameContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_KEYED_FIELD_NAME            (my_context_keyed_field_name_get_type())
#define MY_CONTEXT_KEYED_FIELD_NAME(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_KEYED_FIELD_NAME, MyContextKeyedFieldName))
#define MY_CONTEXT_KEYED_FIELD_NAME_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_KEYED_FIELD_NAME, MyContextKeyedFieldNameClass))
#define MY_IS_CONTEXT_KEYED_FIELD_NAME(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_KEYED_FIELD_NAME))
#define MY_IS_CONTEXT_KEYED_FIELD_NAME_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_KEYED_FIELD_NAME))
#define MY_CONTEXT_KEYED_FIELD_NAME_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_KEYED_FIELD_NAME, MyContextKeyedFieldNameClass))


//typedef struct _MyContextKeyedFieldName      MyContextKeyedFieldName;
typedef struct _MyContextKeyedFieldNameClass MyContextKeyedFieldNameClass;

struct _MyContextKeyedFieldName {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextKeyedFieldNameClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_keyed_field_name_get_type(void) G_GNUC_CONST;
MyContextKeyedFieldName *my_context_keyed_field_name_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextKeyedSimpleFieldName *my_context_keyed_field_name_rule_get_keyed_simple_field_name(MyContextKeyedFieldName* self);
MyContextKeyedVariable *my_context_keyed_field_name_rule_get_keyed_variable(MyContextKeyedFieldName* self);


MyContextKeyedFieldName* my_php_parser_parse_keyed_field_name(MyPhpParser* self, GError **error);
//----------------- KeyedSimpleFieldNameContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_KEYED_SIMPLE_FIELD_NAME            (my_context_keyed_simple_field_name_get_type())
#define MY_CONTEXT_KEYED_SIMPLE_FIELD_NAME(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_KEYED_SIMPLE_FIELD_NAME, MyContextKeyedSimpleFieldName))
#define MY_CONTEXT_KEYED_SIMPLE_FIELD_NAME_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_KEYED_SIMPLE_FIELD_NAME, MyContextKeyedSimpleFieldNameClass))
#define MY_IS_CONTEXT_KEYED_SIMPLE_FIELD_NAME(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_KEYED_SIMPLE_FIELD_NAME))
#define MY_IS_CONTEXT_KEYED_SIMPLE_FIELD_NAME_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_KEYED_SIMPLE_FIELD_NAME))
#define MY_CONTEXT_KEYED_SIMPLE_FIELD_NAME_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_KEYED_SIMPLE_FIELD_NAME, MyContextKeyedSimpleFieldNameClass))


//typedef struct _MyContextKeyedSimpleFieldName      MyContextKeyedSimpleFieldName;
typedef struct _MyContextKeyedSimpleFieldNameClass MyContextKeyedSimpleFieldNameClass;

struct _MyContextKeyedSimpleFieldName {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextKeyedSimpleFieldNameClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_keyed_simple_field_name_get_type(void) G_GNUC_CONST;
MyContextKeyedSimpleFieldName *my_context_keyed_simple_field_name_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextIdentifier *my_context_keyed_simple_field_name_rule_get_identifier(MyContextKeyedSimpleFieldName* self);
AntlrTerminalNode *my_context_keyed_simple_field_name_token_get_open_curly_bracket(MyContextKeyedSimpleFieldName* self);
MyContextExpression *my_context_keyed_simple_field_name_rule_get_expression(MyContextKeyedSimpleFieldName* self);
GList* my_context_keyed_simple_field_name_rule_get_square_curly_expression(MyContextKeyedSimpleFieldName* self);// of MyContextSquareCurlyExpression
MyContextSquareCurlyExpression* my_context_keyed_simple_field_name_at_rule_get_square_curly_expression(MyContextKeyedSimpleFieldName* self, size_t i);


MyContextKeyedSimpleFieldName* my_php_parser_parse_keyed_simple_field_name(MyPhpParser* self, GError **error);
//----------------- KeyedVariableContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_KEYED_VARIABLE            (my_context_keyed_variable_get_type())
#define MY_CONTEXT_KEYED_VARIABLE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_KEYED_VARIABLE, MyContextKeyedVariable))
#define MY_CONTEXT_KEYED_VARIABLE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_KEYED_VARIABLE, MyContextKeyedVariableClass))
#define MY_IS_CONTEXT_KEYED_VARIABLE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_KEYED_VARIABLE))
#define MY_IS_CONTEXT_KEYED_VARIABLE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_KEYED_VARIABLE))
#define MY_CONTEXT_KEYED_VARIABLE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_KEYED_VARIABLE, MyContextKeyedVariableClass))


//typedef struct _MyContextKeyedVariable      MyContextKeyedVariable;
typedef struct _MyContextKeyedVariableClass MyContextKeyedVariableClass;

struct _MyContextKeyedVariable {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextKeyedVariableClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_keyed_variable_get_type(void) G_GNUC_CONST;
MyContextKeyedVariable *my_context_keyed_variable_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_keyed_variable_token_get_var_name(MyContextKeyedVariable* self);
GList* my_context_keyed_variable_token_get_dollar(MyContextKeyedVariable* self);// of AntlrTerminalNode*
AntlrTerminalNode *my_context_keyed_variable_at_token_get_dollar(MyContextKeyedVariable* self, size_t i);
AntlrTerminalNode *my_context_keyed_variable_token_get_open_curly_bracket(MyContextKeyedVariable* self);
MyContextExpression *my_context_keyed_variable_rule_get_expression(MyContextKeyedVariable* self);
GList* my_context_keyed_variable_rule_get_square_curly_expression(MyContextKeyedVariable* self);// of MyContextSquareCurlyExpression
MyContextSquareCurlyExpression* my_context_keyed_variable_at_rule_get_square_curly_expression(MyContextKeyedVariable* self, size_t i);


MyContextKeyedVariable* my_php_parser_parse_keyed_variable(MyPhpParser* self, GError **error);
//----------------- SquareCurlyExpressionContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_SQUARE_CURLY_EXPRESSION            (my_context_square_curly_expression_get_type())
#define MY_CONTEXT_SQUARE_CURLY_EXPRESSION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_SQUARE_CURLY_EXPRESSION, MyContextSquareCurlyExpression))
#define MY_CONTEXT_SQUARE_CURLY_EXPRESSION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_SQUARE_CURLY_EXPRESSION, MyContextSquareCurlyExpressionClass))
#define MY_IS_CONTEXT_SQUARE_CURLY_EXPRESSION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_SQUARE_CURLY_EXPRESSION))
#define MY_IS_CONTEXT_SQUARE_CURLY_EXPRESSION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_SQUARE_CURLY_EXPRESSION))
#define MY_CONTEXT_SQUARE_CURLY_EXPRESSION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_SQUARE_CURLY_EXPRESSION, MyContextSquareCurlyExpressionClass))


//typedef struct _MyContextSquareCurlyExpression      MyContextSquareCurlyExpression;
typedef struct _MyContextSquareCurlyExpressionClass MyContextSquareCurlyExpressionClass;

struct _MyContextSquareCurlyExpression {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextSquareCurlyExpressionClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_square_curly_expression_get_type(void) G_GNUC_CONST;
MyContextSquareCurlyExpression *my_context_square_curly_expression_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextExpression *my_context_square_curly_expression_rule_get_expression(MyContextSquareCurlyExpression* self);
AntlrTerminalNode *my_context_square_curly_expression_token_get_open_curly_bracket(MyContextSquareCurlyExpression* self);


MyContextSquareCurlyExpression* my_php_parser_parse_square_curly_expression(MyPhpParser* self, GError **error);
//----------------- AssignmentListContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ASSIGNMENT_LIST            (my_context_assignment_list_get_type())
#define MY_CONTEXT_ASSIGNMENT_LIST(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ASSIGNMENT_LIST, MyContextAssignmentList))
#define MY_CONTEXT_ASSIGNMENT_LIST_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ASSIGNMENT_LIST, MyContextAssignmentListClass))
#define MY_IS_CONTEXT_ASSIGNMENT_LIST(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ASSIGNMENT_LIST))
#define MY_IS_CONTEXT_ASSIGNMENT_LIST_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ASSIGNMENT_LIST))
#define MY_CONTEXT_ASSIGNMENT_LIST_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ASSIGNMENT_LIST, MyContextAssignmentListClass))


//typedef struct _MyContextAssignmentList      MyContextAssignmentList;
typedef struct _MyContextAssignmentListClass MyContextAssignmentListClass;

struct _MyContextAssignmentList {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAssignmentListClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_assignment_list_get_type(void) G_GNUC_CONST;
MyContextAssignmentList *my_context_assignment_list_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_assignment_list_rule_get_assignment_list_element(MyContextAssignmentList* self);// of MyContextAssignmentListElement
MyContextAssignmentListElement* my_context_assignment_list_at_rule_get_assignment_list_element(MyContextAssignmentList* self, size_t i);


MyContextAssignmentList* my_php_parser_parse_assignment_list(MyPhpParser* self, GError **error);
//----------------- AssignmentListElementContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ASSIGNMENT_LIST_ELEMENT            (my_context_assignment_list_element_get_type())
#define MY_CONTEXT_ASSIGNMENT_LIST_ELEMENT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ASSIGNMENT_LIST_ELEMENT, MyContextAssignmentListElement))
#define MY_CONTEXT_ASSIGNMENT_LIST_ELEMENT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ASSIGNMENT_LIST_ELEMENT, MyContextAssignmentListElementClass))
#define MY_IS_CONTEXT_ASSIGNMENT_LIST_ELEMENT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ASSIGNMENT_LIST_ELEMENT))
#define MY_IS_CONTEXT_ASSIGNMENT_LIST_ELEMENT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ASSIGNMENT_LIST_ELEMENT))
#define MY_CONTEXT_ASSIGNMENT_LIST_ELEMENT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ASSIGNMENT_LIST_ELEMENT, MyContextAssignmentListElementClass))


//typedef struct _MyContextAssignmentListElement      MyContextAssignmentListElement;
typedef struct _MyContextAssignmentListElementClass MyContextAssignmentListElementClass;

struct _MyContextAssignmentListElement {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAssignmentListElementClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_assignment_list_element_get_type(void) G_GNUC_CONST;
MyContextAssignmentListElement *my_context_assignment_list_element_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextChain *my_context_assignment_list_element_rule_get_chain(MyContextAssignmentListElement* self);
AntlrTerminalNode *my_context_assignment_list_element_token_get_list(MyContextAssignmentListElement* self);
MyContextAssignmentList *my_context_assignment_list_element_rule_get_assignment_list(MyContextAssignmentListElement* self);


MyContextAssignmentListElement* my_php_parser_parse_assignment_list_element(MyPhpParser* self, GError **error);
//----------------- ModifierContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_MODIFIER            (my_context_modifier_get_type())
#define MY_CONTEXT_MODIFIER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_MODIFIER, MyContextModifier))
#define MY_CONTEXT_MODIFIER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_MODIFIER, MyContextModifierClass))
#define MY_IS_CONTEXT_MODIFIER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_MODIFIER))
#define MY_IS_CONTEXT_MODIFIER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_MODIFIER))
#define MY_CONTEXT_MODIFIER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_MODIFIER, MyContextModifierClass))


//typedef struct _MyContextModifier      MyContextModifier;
typedef struct _MyContextModifierClass MyContextModifierClass;

struct _MyContextModifier {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextModifierClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_modifier_get_type(void) G_GNUC_CONST;
MyContextModifier *my_context_modifier_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_modifier_token_get_abstract(MyContextModifier* self);
AntlrTerminalNode *my_context_modifier_token_get_final(MyContextModifier* self);


MyContextModifier* my_php_parser_parse_modifier(MyPhpParser* self, GError **error);
//----------------- IdentifierContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_IDENTIFIER            (my_context_identifier_get_type())
#define MY_CONTEXT_IDENTIFIER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_IDENTIFIER, MyContextIdentifier))
#define MY_CONTEXT_IDENTIFIER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_IDENTIFIER, MyContextIdentifierClass))
#define MY_IS_CONTEXT_IDENTIFIER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_IDENTIFIER))
#define MY_IS_CONTEXT_IDENTIFIER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_IDENTIFIER))
#define MY_CONTEXT_IDENTIFIER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_IDENTIFIER, MyContextIdentifierClass))


//typedef struct _MyContextIdentifier      MyContextIdentifier;
typedef struct _MyContextIdentifierClass MyContextIdentifierClass;

struct _MyContextIdentifier {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextIdentifierClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_identifier_get_type(void) G_GNUC_CONST;
MyContextIdentifier *my_context_identifier_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_identifier_token_get_label(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_abstract(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_array(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_as(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_binary_cast(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_bool_type(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_boolean_constant(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_break(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_callable(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_case(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_catch(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_class(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_clone(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_const(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_continue(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_declare(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_default(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_do(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_double_cast(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_double_type(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_echo(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_else(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_else_if(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_empty(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_end_declare(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_end_for(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_end_foreach(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_end_if(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_end_switch(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_end_while(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_eval(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_exit(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_extends(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_final(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_finally(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_float_cast(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_for(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_foreach(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_function(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_global(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_goto(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_if(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_implements(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_import(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_include(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_include_once(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_instance_of(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_instead_of(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_int16cast(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_int64type(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_int8cast(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_interface(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_int_type(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_is_set(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_list(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_logical_and(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_logical_or(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_logical_xor(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_namespace(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_new(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_null(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_object_type(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_parent_(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_partial(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_print(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_private(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_protected(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_public(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_require(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_require_once(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_resource(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_return(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_static(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_string_type(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_switch(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_throw(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_trait(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_try(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_typeof(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_uint_cast(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_unicode_cast(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_unset(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_use(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_var(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_while(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_yield(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_get(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_set(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_call(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_call_static(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_constructor(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_destruct(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_wakeup(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_sleep(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_autoload(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_is_set__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_unset__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_to_string__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_invoke(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_set_state(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_clone__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_debug_info(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_namespace__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_class__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_traic__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_function__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_method__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_line__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_file__(MyContextIdentifier* self);
AntlrTerminalNode *my_context_identifier_token_get_dir__(MyContextIdentifier* self);


MyContextIdentifier* my_php_parser_parse_identifier(MyPhpParser* self, GError **error);
//----------------- MemberModifierContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_MEMBER_MODIFIER            (my_context_member_modifier_get_type())
#define MY_CONTEXT_MEMBER_MODIFIER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_MEMBER_MODIFIER, MyContextMemberModifier))
#define MY_CONTEXT_MEMBER_MODIFIER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_MEMBER_MODIFIER, MyContextMemberModifierClass))
#define MY_IS_CONTEXT_MEMBER_MODIFIER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_MEMBER_MODIFIER))
#define MY_IS_CONTEXT_MEMBER_MODIFIER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_MEMBER_MODIFIER))
#define MY_CONTEXT_MEMBER_MODIFIER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_MEMBER_MODIFIER, MyContextMemberModifierClass))


//typedef struct _MyContextMemberModifier      MyContextMemberModifier;
typedef struct _MyContextMemberModifierClass MyContextMemberModifierClass;

struct _MyContextMemberModifier {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextMemberModifierClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_member_modifier_get_type(void) G_GNUC_CONST;
MyContextMemberModifier *my_context_member_modifier_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_member_modifier_token_get_public(MyContextMemberModifier* self);
AntlrTerminalNode *my_context_member_modifier_token_get_protected(MyContextMemberModifier* self);
AntlrTerminalNode *my_context_member_modifier_token_get_private(MyContextMemberModifier* self);
AntlrTerminalNode *my_context_member_modifier_token_get_static(MyContextMemberModifier* self);
AntlrTerminalNode *my_context_member_modifier_token_get_abstract(MyContextMemberModifier* self);
AntlrTerminalNode *my_context_member_modifier_token_get_final(MyContextMemberModifier* self);


MyContextMemberModifier* my_php_parser_parse_member_modifier(MyPhpParser* self, GError **error);
//----------------- MagicConstantContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_MAGIC_CONSTANT            (my_context_magic_constant_get_type())
#define MY_CONTEXT_MAGIC_CONSTANT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_MAGIC_CONSTANT, MyContextMagicConstant))
#define MY_CONTEXT_MAGIC_CONSTANT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_MAGIC_CONSTANT, MyContextMagicConstantClass))
#define MY_IS_CONTEXT_MAGIC_CONSTANT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_MAGIC_CONSTANT))
#define MY_IS_CONTEXT_MAGIC_CONSTANT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_MAGIC_CONSTANT))
#define MY_CONTEXT_MAGIC_CONSTANT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_MAGIC_CONSTANT, MyContextMagicConstantClass))


//typedef struct _MyContextMagicConstant      MyContextMagicConstant;
typedef struct _MyContextMagicConstantClass MyContextMagicConstantClass;

struct _MyContextMagicConstant {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextMagicConstantClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_magic_constant_get_type(void) G_GNUC_CONST;
MyContextMagicConstant *my_context_magic_constant_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_magic_constant_token_get_namespace__(MyContextMagicConstant* self);
AntlrTerminalNode *my_context_magic_constant_token_get_class__(MyContextMagicConstant* self);
AntlrTerminalNode *my_context_magic_constant_token_get_traic__(MyContextMagicConstant* self);
AntlrTerminalNode *my_context_magic_constant_token_get_function__(MyContextMagicConstant* self);
AntlrTerminalNode *my_context_magic_constant_token_get_method__(MyContextMagicConstant* self);
AntlrTerminalNode *my_context_magic_constant_token_get_line__(MyContextMagicConstant* self);
AntlrTerminalNode *my_context_magic_constant_token_get_file__(MyContextMagicConstant* self);
AntlrTerminalNode *my_context_magic_constant_token_get_dir__(MyContextMagicConstant* self);


MyContextMagicConstant* my_php_parser_parse_magic_constant(MyPhpParser* self, GError **error);
//----------------- MagicMethodContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_MAGIC_METHOD            (my_context_magic_method_get_type())
#define MY_CONTEXT_MAGIC_METHOD(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_MAGIC_METHOD, MyContextMagicMethod))
#define MY_CONTEXT_MAGIC_METHOD_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_MAGIC_METHOD, MyContextMagicMethodClass))
#define MY_IS_CONTEXT_MAGIC_METHOD(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_MAGIC_METHOD))
#define MY_IS_CONTEXT_MAGIC_METHOD_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_MAGIC_METHOD))
#define MY_CONTEXT_MAGIC_METHOD_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_MAGIC_METHOD, MyContextMagicMethodClass))


//typedef struct _MyContextMagicMethod      MyContextMagicMethod;
typedef struct _MyContextMagicMethodClass MyContextMagicMethodClass;

struct _MyContextMagicMethod {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextMagicMethodClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_magic_method_get_type(void) G_GNUC_CONST;
MyContextMagicMethod *my_context_magic_method_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_magic_method_token_get_get(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_set(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_call(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_call_static(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_constructor(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_destruct(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_wakeup(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_sleep(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_autoload(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_is_set__(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_unset__(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_to_string__(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_invoke(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_set_state(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_clone__(MyContextMagicMethod* self);
AntlrTerminalNode *my_context_magic_method_token_get_debug_info(MyContextMagicMethod* self);


MyContextMagicMethod* my_php_parser_parse_magic_method(MyPhpParser* self, GError **error);
//----------------- PrimitiveTypeContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_PRIMITIVE_TYPE            (my_context_primitive_type_get_type())
#define MY_CONTEXT_PRIMITIVE_TYPE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_PRIMITIVE_TYPE, MyContextPrimitiveType))
#define MY_CONTEXT_PRIMITIVE_TYPE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_PRIMITIVE_TYPE, MyContextPrimitiveTypeClass))
#define MY_IS_CONTEXT_PRIMITIVE_TYPE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_PRIMITIVE_TYPE))
#define MY_IS_CONTEXT_PRIMITIVE_TYPE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_PRIMITIVE_TYPE))
#define MY_CONTEXT_PRIMITIVE_TYPE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_PRIMITIVE_TYPE, MyContextPrimitiveTypeClass))


//typedef struct _MyContextPrimitiveType      MyContextPrimitiveType;
typedef struct _MyContextPrimitiveTypeClass MyContextPrimitiveTypeClass;

struct _MyContextPrimitiveType {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextPrimitiveTypeClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_primitive_type_get_type(void) G_GNUC_CONST;
MyContextPrimitiveType *my_context_primitive_type_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_primitive_type_token_get_bool_type(MyContextPrimitiveType* self);
AntlrTerminalNode *my_context_primitive_type_token_get_int_type(MyContextPrimitiveType* self);
AntlrTerminalNode *my_context_primitive_type_token_get_int64type(MyContextPrimitiveType* self);
AntlrTerminalNode *my_context_primitive_type_token_get_double_type(MyContextPrimitiveType* self);
AntlrTerminalNode *my_context_primitive_type_token_get_string_type(MyContextPrimitiveType* self);
AntlrTerminalNode *my_context_primitive_type_token_get_resource(MyContextPrimitiveType* self);
AntlrTerminalNode *my_context_primitive_type_token_get_object_type(MyContextPrimitiveType* self);
AntlrTerminalNode *my_context_primitive_type_token_get_array(MyContextPrimitiveType* self);


MyContextPrimitiveType* my_php_parser_parse_primitive_type(MyPhpParser* self, GError **error);
//----------------- CastOperationContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CAST_OPERATION            (my_context_cast_operation_get_type())
#define MY_CONTEXT_CAST_OPERATION(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CAST_OPERATION, MyContextCastOperation))
#define MY_CONTEXT_CAST_OPERATION_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CAST_OPERATION, MyContextCastOperationClass))
#define MY_IS_CONTEXT_CAST_OPERATION(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CAST_OPERATION))
#define MY_IS_CONTEXT_CAST_OPERATION_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CAST_OPERATION))
#define MY_CONTEXT_CAST_OPERATION_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CAST_OPERATION, MyContextCastOperationClass))


//typedef struct _MyContextCastOperation      MyContextCastOperation;
typedef struct _MyContextCastOperationClass MyContextCastOperationClass;

struct _MyContextCastOperation {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextCastOperationClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_cast_operation_get_type(void) G_GNUC_CONST;
MyContextCastOperation *my_context_cast_operation_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *my_context_cast_operation_token_get_bool_type(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_int8cast(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_int16cast(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_int_type(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_int64type(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_uint_cast(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_double_cast(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_double_type(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_float_cast(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_string_type(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_binary_cast(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_unicode_cast(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_array(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_object_type(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_resource(MyContextCastOperation* self);
AntlrTerminalNode *my_context_cast_operation_token_get_unset(MyContextCastOperation* self);


MyContextCastOperation* my_php_parser_parse_cast_operation(MyPhpParser* self, GError **error);

//gboolean my_php_parser_sempred(MyPhpParser *self, AntlrRuleContext *local_context, size_t ruleIndex, size_t predicateIndex);
gboolean my_php_parser_sempred_expression(MyPhpParser* self, AntlrRuleContext *local_context, size_t predicateIndex);



G_END_DECLS

#endif /* __MY_PHP_PARSER_H__ */

