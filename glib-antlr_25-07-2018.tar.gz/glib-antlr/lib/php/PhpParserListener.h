
// Generated from PhpParser.g4 by ANTLR 4.6



//#include "antlr4-runtime.h"
//#include "PhpParser.h"


#ifndef __MY_PHP_PARSER_LISTENER_H__
#define __MY_PHP_PARSER_LISTENER_H__

#include <glib-object.h>

G_BEGIN_DECLS

#define MY_TYPE_PHP_PARSER_LISTENER                (my_php_parser_listener_get_type ())
#define MY_PHP_PARSER_LISTENER(obj)                (G_TYPE_CHECK_INSTANCE_CAST ((obj),  MY_TYPE_PHP_PARSER_LISTENER,  MyPhpParserListener))
#define MY_IS_PHP_PARSER_LISTENER(obj)             (G_TYPE_CHECK_INSTANCE_TYPE ((obj),  MY_TYPE_PHP_PARSER_LISTENER))
#define MY_PHP_PARSER_LISTENER_GET_INTERFACE(inst) (G_TYPE_INSTANCE_GET_INTERFACE ((inst),  MY_TYPE_PHP_PARSER_LISTENER,  MyPhpParserListenerInterface))


typedef struct _MyPhpParserListener          MyPhpParserListener;/* dummy object */
typedef struct _MyPhpParserListenerInterface MyPhpParserListenerInterface;

/**
 * MyPhpParserListenerInterface:
 * @enter_html_document: HtmlDocument enter event
 * @exit_html_document: HtmlDocument exit event
 * @enter_html_element_or_php_block: HtmlElementOrPhpBlock enter event
 * @exit_html_element_or_php_block: HtmlElementOrPhpBlock exit event
 * @enter_html_elements: HtmlElements enter event
 * @exit_html_elements: HtmlElements exit event
 * @enter_html_element: HtmlElement enter event
 * @exit_html_element: HtmlElement exit event
 * @enter_script_text_part: ScriptTextPart enter event
 * @exit_script_text_part: ScriptTextPart exit event
 * @enter_php_block: PhpBlock enter event
 * @exit_php_block: PhpBlock exit event
 * @enter_import_statement: ImportStatement enter event
 * @exit_import_statement: ImportStatement exit event
 * @enter_top_statement: TopStatement enter event
 * @exit_top_statement: TopStatement exit event
 * @enter_use_declaration: UseDeclaration enter event
 * @exit_use_declaration: UseDeclaration exit event
 * @enter_use_declaration_content_list: UseDeclarationContentList enter event
 * @exit_use_declaration_content_list: UseDeclarationContentList exit event
 * @enter_use_declaration_content: UseDeclarationContent enter event
 * @exit_use_declaration_content: UseDeclarationContent exit event
 * @enter_namespace_declaration: NamespaceDeclaration enter event
 * @exit_namespace_declaration: NamespaceDeclaration exit event
 * @enter_namespace_statement: NamespaceStatement enter event
 * @exit_namespace_statement: NamespaceStatement exit event
 * @enter_function_declaration: FunctionDeclaration enter event
 * @exit_function_declaration: FunctionDeclaration exit event
 * @enter_class_declaration: ClassDeclaration enter event
 * @exit_class_declaration: ClassDeclaration exit event
 * @enter_class_entry_type: ClassEntryType enter event
 * @exit_class_entry_type: ClassEntryType exit event
 * @enter_interface_list: InterfaceList enter event
 * @exit_interface_list: InterfaceList exit event
 * @enter_type_parameter_list_in_brackets: TypeParameterListInBrackets enter event
 * @exit_type_parameter_list_in_brackets: TypeParameterListInBrackets exit event
 * @enter_type_parameter_list: TypeParameterList enter event
 * @exit_type_parameter_list: TypeParameterList exit event
 * @enter_type_parameter_with_defaults_list: TypeParameterWithDefaultsList enter event
 * @exit_type_parameter_with_defaults_list: TypeParameterWithDefaultsList exit event
 * @enter_type_parameter_decl: TypeParameterDecl enter event
 * @exit_type_parameter_decl: TypeParameterDecl exit event
 * @enter_type_parameter_with_default_decl: TypeParameterWithDefaultDecl enter event
 * @exit_type_parameter_with_default_decl: TypeParameterWithDefaultDecl exit event
 * @enter_generic_dynamic_args: GenericDynamicArgs enter event
 * @exit_generic_dynamic_args: GenericDynamicArgs exit event
 * @enter_attributes: Attributes enter event
 * @exit_attributes: Attributes exit event
 * @enter_attributes_group: AttributesGroup enter event
 * @exit_attributes_group: AttributesGroup exit event
 * @enter_attribute: Attribute enter event
 * @exit_attribute: Attribute exit event
 * @enter_attribute_arg_list: AttributeArgList enter event
 * @exit_attribute_arg_list: AttributeArgList exit event
 * @enter_attribute_named_arg_list: AttributeNamedArgList enter event
 * @exit_attribute_named_arg_list: AttributeNamedArgList exit event
 * @enter_attribute_named_arg: AttributeNamedArg enter event
 * @exit_attribute_named_arg: AttributeNamedArg exit event
 * @enter_inner_statement_list: InnerStatementList enter event
 * @exit_inner_statement_list: InnerStatementList exit event
 * @enter_inner_statement: InnerStatement enter event
 * @exit_inner_statement: InnerStatement exit event
 * @enter_statement: Statement enter event
 * @exit_statement: Statement exit event
 * @enter_empty_statement: EmptyStatement enter event
 * @exit_empty_statement: EmptyStatement exit event
 * @enter_block_statement: BlockStatement enter event
 * @exit_block_statement: BlockStatement exit event
 * @enter_if_statement: IfStatement enter event
 * @exit_if_statement: IfStatement exit event
 * @enter_else_if_statement: ElseIfStatement enter event
 * @exit_else_if_statement: ElseIfStatement exit event
 * @enter_else_if_colon_statement: ElseIfColonStatement enter event
 * @exit_else_if_colon_statement: ElseIfColonStatement exit event
 * @enter_else_statement: ElseStatement enter event
 * @exit_else_statement: ElseStatement exit event
 * @enter_else_colon_statement: ElseColonStatement enter event
 * @exit_else_colon_statement: ElseColonStatement exit event
 * @enter_while_statement: WhileStatement enter event
 * @exit_while_statement: WhileStatement exit event
 * @enter_do_while_statement: DoWhileStatement enter event
 * @exit_do_while_statement: DoWhileStatement exit event
 * @enter_for_statement: ForStatement enter event
 * @exit_for_statement: ForStatement exit event
 * @enter_for_init: ForInit enter event
 * @exit_for_init: ForInit exit event
 * @enter_for_update: ForUpdate enter event
 * @exit_for_update: ForUpdate exit event
 * @enter_switch_statement: SwitchStatement enter event
 * @exit_switch_statement: SwitchStatement exit event
 * @enter_switch_block: SwitchBlock enter event
 * @exit_switch_block: SwitchBlock exit event
 * @enter_break_statement: BreakStatement enter event
 * @exit_break_statement: BreakStatement exit event
 * @enter_continue_statement: ContinueStatement enter event
 * @exit_continue_statement: ContinueStatement exit event
 * @enter_return_statement: ReturnStatement enter event
 * @exit_return_statement: ReturnStatement exit event
 * @enter_expression_statement: ExpressionStatement enter event
 * @exit_expression_statement: ExpressionStatement exit event
 * @enter_unset_statement: UnsetStatement enter event
 * @exit_unset_statement: UnsetStatement exit event
 * @enter_foreach_statement: ForeachStatement enter event
 * @exit_foreach_statement: ForeachStatement exit event
 * @enter_try_catch_finally: TryCatchFinally enter event
 * @exit_try_catch_finally: TryCatchFinally exit event
 * @enter_catch_clause: CatchClause enter event
 * @exit_catch_clause: CatchClause exit event
 * @enter_finally_statement: FinallyStatement enter event
 * @exit_finally_statement: FinallyStatement exit event
 * @enter_throw_statement: ThrowStatement enter event
 * @exit_throw_statement: ThrowStatement exit event
 * @enter_goto_statement: GotoStatement enter event
 * @exit_goto_statement: GotoStatement exit event
 * @enter_declare_statement: DeclareStatement enter event
 * @exit_declare_statement: DeclareStatement exit event
 * @enter_inline_html_statement: InlineHtmlStatement enter event
 * @exit_inline_html_statement: InlineHtmlStatement exit event
 * @enter_inline_html: InlineHtml enter event
 * @exit_inline_html: InlineHtml exit event
 * @enter_declare_list: DeclareList enter event
 * @exit_declare_list: DeclareList exit event
 * @enter_formal_parameter_list: FormalParameterList enter event
 * @exit_formal_parameter_list: FormalParameterList exit event
 * @enter_formal_parameter: FormalParameter enter event
 * @exit_formal_parameter: FormalParameter exit event
 * @enter_type_hint: TypeHint enter event
 * @exit_type_hint: TypeHint exit event
 * @enter_global_statement: GlobalStatement enter event
 * @exit_global_statement: GlobalStatement exit event
 * @enter_global_var: GlobalVar enter event
 * @exit_global_var: GlobalVar exit event
 * @enter_echo_statement: EchoStatement enter event
 * @exit_echo_statement: EchoStatement exit event
 * @enter_static_variable_statement: StaticVariableStatement enter event
 * @exit_static_variable_statement: StaticVariableStatement exit event
 * @enter_class_statement: ClassStatement enter event
 * @exit_class_statement: ClassStatement exit event
 * @enter_trait_adaptations: TraitAdaptations enter event
 * @exit_trait_adaptations: TraitAdaptations exit event
 * @enter_trait_adaptation_statement: TraitAdaptationStatement enter event
 * @exit_trait_adaptation_statement: TraitAdaptationStatement exit event
 * @enter_trait_precedence: TraitPrecedence enter event
 * @exit_trait_precedence: TraitPrecedence exit event
 * @enter_trait_alias: TraitAlias enter event
 * @exit_trait_alias: TraitAlias exit event
 * @enter_trait_method_reference: TraitMethodReference enter event
 * @exit_trait_method_reference: TraitMethodReference exit event
 * @enter_base_ctor_call: BaseCtorCall enter event
 * @exit_base_ctor_call: BaseCtorCall exit event
 * @enter_method_body: MethodBody enter event
 * @exit_method_body: MethodBody exit event
 * @enter_property_modifiers: PropertyModifiers enter event
 * @exit_property_modifiers: PropertyModifiers exit event
 * @enter_member_modifiers: MemberModifiers enter event
 * @exit_member_modifiers: MemberModifiers exit event
 * @enter_variable_initializer: VariableInitializer enter event
 * @exit_variable_initializer: VariableInitializer exit event
 * @enter_identifier_inititalizer: IdentifierInititalizer enter event
 * @exit_identifier_inititalizer: IdentifierInititalizer exit event
 * @enter_global_constant_declaration: GlobalConstantDeclaration enter event
 * @exit_global_constant_declaration: GlobalConstantDeclaration exit event
 * @enter_expression_list: ExpressionList enter event
 * @exit_expression_list: ExpressionList exit event
 * @enter_parenthesis: Parenthesis enter event
 * @exit_parenthesis: Parenthesis exit event
 * @enter_chain_expression: ChainExpression enter event
 * @exit_chain_expression: ChainExpression exit event
 * @enter_unary_operator_expression: UnaryOperatorExpression enter event
 * @exit_unary_operator_expression: UnaryOperatorExpression exit event
 * @enter_special_word_expression: SpecialWordExpression enter event
 * @exit_special_word_expression: SpecialWordExpression exit event
 * @enter_array_creation_expression: ArrayCreationExpression enter event
 * @exit_array_creation_expression: ArrayCreationExpression exit event
 * @enter_new_expression: NewExpression enter event
 * @exit_new_expression: NewExpression exit event
 * @enter_parenthesis_expression: ParenthesisExpression enter event
 * @exit_parenthesis_expression: ParenthesisExpression exit event
 * @enter_back_quote_string_expression: BackQuoteStringExpression enter event
 * @exit_back_quote_string_expression: BackQuoteStringExpression exit event
 * @enter_conditional_expression: ConditionalExpression enter event
 * @exit_conditional_expression: ConditionalExpression exit event
 * @enter_arithmetic_expression: ArithmeticExpression enter event
 * @exit_arithmetic_expression: ArithmeticExpression exit event
 * @enter_indexer_expression: IndexerExpression enter event
 * @exit_indexer_expression: IndexerExpression exit event
 * @enter_scalar_expression: ScalarExpression enter event
 * @exit_scalar_expression: ScalarExpression exit event
 * @enter_prefix_inc_dec_expression: PrefixIncDecExpression enter event
 * @exit_prefix_inc_dec_expression: PrefixIncDecExpression exit event
 * @enter_comparison_expression: ComparisonExpression enter event
 * @exit_comparison_expression: ComparisonExpression exit event
 * @enter_logical_expression: LogicalExpression enter event
 * @exit_logical_expression: LogicalExpression exit event
 * @enter_print_expression: PrintExpression enter event
 * @exit_print_expression: PrintExpression exit event
 * @enter_assignment_expression: AssignmentExpression enter event
 * @exit_assignment_expression: AssignmentExpression exit event
 * @enter_postfix_inc_dec_expression: PostfixIncDecExpression enter event
 * @exit_postfix_inc_dec_expression: PostfixIncDecExpression exit event
 * @enter_cast_expression: CastExpression enter event
 * @exit_cast_expression: CastExpression exit event
 * @enter_instance_of_expression: InstanceOfExpression enter event
 * @exit_instance_of_expression: InstanceOfExpression exit event
 * @enter_lambda_function_expression: LambdaFunctionExpression enter event
 * @exit_lambda_function_expression: LambdaFunctionExpression exit event
 * @enter_bitwise_expression: BitwiseExpression enter event
 * @exit_bitwise_expression: BitwiseExpression exit event
 * @enter_clone_expression: CloneExpression enter event
 * @exit_clone_expression: CloneExpression exit event
 * @enter_new_expr: NewExpr enter event
 * @exit_new_expr: NewExpr exit event
 * @enter_assignment_operator: AssignmentOperator enter event
 * @exit_assignment_operator: AssignmentOperator exit event
 * @enter_yield_expression: YieldExpression enter event
 * @exit_yield_expression: YieldExpression exit event
 * @enter_array_item_list: ArrayItemList enter event
 * @exit_array_item_list: ArrayItemList exit event
 * @enter_array_item: ArrayItem enter event
 * @exit_array_item: ArrayItem exit event
 * @enter_lambda_function_use_vars: LambdaFunctionUseVars enter event
 * @exit_lambda_function_use_vars: LambdaFunctionUseVars exit event
 * @enter_lambda_function_use_var: LambdaFunctionUseVar enter event
 * @exit_lambda_function_use_var: LambdaFunctionUseVar exit event
 * @enter_qualified_static_type_ref: QualifiedStaticTypeRef enter event
 * @exit_qualified_static_type_ref: QualifiedStaticTypeRef exit event
 * @enter_type_ref: TypeRef enter event
 * @exit_type_ref: TypeRef exit event
 * @enter_indirect_type_ref: IndirectTypeRef enter event
 * @exit_indirect_type_ref: IndirectTypeRef exit event
 * @enter_qualified_namespace_name: QualifiedNamespaceName enter event
 * @exit_qualified_namespace_name: QualifiedNamespaceName exit event
 * @enter_namespace_name_list: NamespaceNameList enter event
 * @exit_namespace_name_list: NamespaceNameList exit event
 * @enter_qualified_namespace_name_list: QualifiedNamespaceNameList enter event
 * @exit_qualified_namespace_name_list: QualifiedNamespaceNameList exit event
 * @enter_arguments: Arguments enter event
 * @exit_arguments: Arguments exit event
 * @enter_actual_argument: ActualArgument enter event
 * @exit_actual_argument: ActualArgument exit event
 * @enter_constant_inititalizer: ConstantInititalizer enter event
 * @exit_constant_inititalizer: ConstantInititalizer exit event
 * @enter_constant_array_item_list: ConstantArrayItemList enter event
 * @exit_constant_array_item_list: ConstantArrayItemList exit event
 * @enter_constant_array_item: ConstantArrayItem enter event
 * @exit_constant_array_item: ConstantArrayItem exit event
 * @enter_constant: Constant enter event
 * @exit_constant: Constant exit event
 * @enter_literal_constant: LiteralConstant enter event
 * @exit_literal_constant: LiteralConstant exit event
 * @enter_numeric_constant: NumericConstant enter event
 * @exit_numeric_constant: NumericConstant exit event
 * @enter_class_constant: ClassConstant enter event
 * @exit_class_constant: ClassConstant exit event
 * @enter_string_constant: StringConstant enter event
 * @exit_string_constant: StringConstant exit event
 * @enter_string: String enter event
 * @exit_string: String exit event
 * @enter_interpolated_string_part: InterpolatedStringPart enter event
 * @exit_interpolated_string_part: InterpolatedStringPart exit event
 * @enter_chain_list: ChainList enter event
 * @exit_chain_list: ChainList exit event
 * @enter_chain: Chain enter event
 * @exit_chain: Chain exit event
 * @enter_member_access: MemberAccess enter event
 * @exit_member_access: MemberAccess exit event
 * @enter_function_call: FunctionCall enter event
 * @exit_function_call: FunctionCall exit event
 * @enter_function_call_name: FunctionCallName enter event
 * @exit_function_call_name: FunctionCallName exit event
 * @enter_actual_arguments: ActualArguments enter event
 * @exit_actual_arguments: ActualArguments exit event
 * @enter_chain_base: ChainBase enter event
 * @exit_chain_base: ChainBase exit event
 * @enter_keyed_field_name: KeyedFieldName enter event
 * @exit_keyed_field_name: KeyedFieldName exit event
 * @enter_keyed_simple_field_name: KeyedSimpleFieldName enter event
 * @exit_keyed_simple_field_name: KeyedSimpleFieldName exit event
 * @enter_keyed_variable: KeyedVariable enter event
 * @exit_keyed_variable: KeyedVariable exit event
 * @enter_square_curly_expression: SquareCurlyExpression enter event
 * @exit_square_curly_expression: SquareCurlyExpression exit event
 * @enter_assignment_list: AssignmentList enter event
 * @exit_assignment_list: AssignmentList exit event
 * @enter_assignment_list_element: AssignmentListElement enter event
 * @exit_assignment_list_element: AssignmentListElement exit event
 * @enter_modifier: Modifier enter event
 * @exit_modifier: Modifier exit event
 * @enter_identifier: Identifier enter event
 * @exit_identifier: Identifier exit event
 * @enter_member_modifier: MemberModifier enter event
 * @exit_member_modifier: MemberModifier exit event
 * @enter_magic_constant: MagicConstant enter event
 * @exit_magic_constant: MagicConstant exit event
 * @enter_magic_method: MagicMethod enter event
 * @exit_magic_method: MagicMethod exit event
 * @enter_primitive_type: PrimitiveType enter event
 * @exit_primitive_type: PrimitiveType exit event
 * @enter_cast_operation: CastOperation enter event
 * @exit_cast_operation: CastOperation exit event
 *
 *
 * This interface defines an abstract listener for a parse tree produced by PhpParser.
 */
struct _MyPhpParserListenerInterface
{
    /*< private >*/
    GTypeInterface parent_iface;

    /*< public >*/
    void (*enter_html_document)  (MyPhpParserListener *self, MyContextHtmlDocument *ctx);
    void (*exit_html_document)   (MyPhpParserListener *self, MyContextHtmlDocument *ctx);

    void (*enter_html_element_or_php_block)  (MyPhpParserListener *self, MyContextHtmlElementOrPhpBlock *ctx);
    void (*exit_html_element_or_php_block)   (MyPhpParserListener *self, MyContextHtmlElementOrPhpBlock *ctx);

    void (*enter_html_elements)  (MyPhpParserListener *self, MyContextHtmlElements *ctx);
    void (*exit_html_elements)   (MyPhpParserListener *self, MyContextHtmlElements *ctx);

    void (*enter_html_element)  (MyPhpParserListener *self, MyContextHtmlElement *ctx);
    void (*exit_html_element)   (MyPhpParserListener *self, MyContextHtmlElement *ctx);

    void (*enter_script_text_part)  (MyPhpParserListener *self, MyContextScriptTextPart *ctx);
    void (*exit_script_text_part)   (MyPhpParserListener *self, MyContextScriptTextPart *ctx);

    void (*enter_php_block)  (MyPhpParserListener *self, MyContextPhpBlock *ctx);
    void (*exit_php_block)   (MyPhpParserListener *self, MyContextPhpBlock *ctx);

    void (*enter_import_statement)  (MyPhpParserListener *self, MyContextImportStatement *ctx);
    void (*exit_import_statement)   (MyPhpParserListener *self, MyContextImportStatement *ctx);

    void (*enter_top_statement)  (MyPhpParserListener *self, MyContextTopStatement *ctx);
    void (*exit_top_statement)   (MyPhpParserListener *self, MyContextTopStatement *ctx);

    void (*enter_use_declaration)  (MyPhpParserListener *self, MyContextUseDeclaration *ctx);
    void (*exit_use_declaration)   (MyPhpParserListener *self, MyContextUseDeclaration *ctx);

    void (*enter_use_declaration_content_list)  (MyPhpParserListener *self, MyContextUseDeclarationContentList *ctx);
    void (*exit_use_declaration_content_list)   (MyPhpParserListener *self, MyContextUseDeclarationContentList *ctx);

    void (*enter_use_declaration_content)  (MyPhpParserListener *self, MyContextUseDeclarationContent *ctx);
    void (*exit_use_declaration_content)   (MyPhpParserListener *self, MyContextUseDeclarationContent *ctx);

    void (*enter_namespace_declaration)  (MyPhpParserListener *self, MyContextNamespaceDeclaration *ctx);
    void (*exit_namespace_declaration)   (MyPhpParserListener *self, MyContextNamespaceDeclaration *ctx);

    void (*enter_namespace_statement)  (MyPhpParserListener *self, MyContextNamespaceStatement *ctx);
    void (*exit_namespace_statement)   (MyPhpParserListener *self, MyContextNamespaceStatement *ctx);

    void (*enter_function_declaration)  (MyPhpParserListener *self, MyContextFunctionDeclaration *ctx);
    void (*exit_function_declaration)   (MyPhpParserListener *self, MyContextFunctionDeclaration *ctx);

    void (*enter_class_declaration)  (MyPhpParserListener *self, MyContextClassDeclaration *ctx);
    void (*exit_class_declaration)   (MyPhpParserListener *self, MyContextClassDeclaration *ctx);

    void (*enter_class_entry_type)  (MyPhpParserListener *self, MyContextClassEntryType *ctx);
    void (*exit_class_entry_type)   (MyPhpParserListener *self, MyContextClassEntryType *ctx);

    void (*enter_interface_list)  (MyPhpParserListener *self, MyContextInterfaceList *ctx);
    void (*exit_interface_list)   (MyPhpParserListener *self, MyContextInterfaceList *ctx);

    void (*enter_type_parameter_list_in_brackets)  (MyPhpParserListener *self, MyContextTypeParameterListInBrackets *ctx);
    void (*exit_type_parameter_list_in_brackets)   (MyPhpParserListener *self, MyContextTypeParameterListInBrackets *ctx);

    void (*enter_type_parameter_list)  (MyPhpParserListener *self, MyContextTypeParameterList *ctx);
    void (*exit_type_parameter_list)   (MyPhpParserListener *self, MyContextTypeParameterList *ctx);

    void (*enter_type_parameter_with_defaults_list)  (MyPhpParserListener *self, MyContextTypeParameterWithDefaultsList *ctx);
    void (*exit_type_parameter_with_defaults_list)   (MyPhpParserListener *self, MyContextTypeParameterWithDefaultsList *ctx);

    void (*enter_type_parameter_decl)  (MyPhpParserListener *self, MyContextTypeParameterDecl *ctx);
    void (*exit_type_parameter_decl)   (MyPhpParserListener *self, MyContextTypeParameterDecl *ctx);

    void (*enter_type_parameter_with_default_decl)  (MyPhpParserListener *self, MyContextTypeParameterWithDefaultDecl *ctx);
    void (*exit_type_parameter_with_default_decl)   (MyPhpParserListener *self, MyContextTypeParameterWithDefaultDecl *ctx);

    void (*enter_generic_dynamic_args)  (MyPhpParserListener *self, MyContextGenericDynamicArgs *ctx);
    void (*exit_generic_dynamic_args)   (MyPhpParserListener *self, MyContextGenericDynamicArgs *ctx);

    void (*enter_attributes)  (MyPhpParserListener *self, MyContextAttributes *ctx);
    void (*exit_attributes)   (MyPhpParserListener *self, MyContextAttributes *ctx);

    void (*enter_attributes_group)  (MyPhpParserListener *self, MyContextAttributesGroup *ctx);
    void (*exit_attributes_group)   (MyPhpParserListener *self, MyContextAttributesGroup *ctx);

    void (*enter_attribute)  (MyPhpParserListener *self, MyContextAttribute *ctx);
    void (*exit_attribute)   (MyPhpParserListener *self, MyContextAttribute *ctx);

    void (*enter_attribute_arg_list)  (MyPhpParserListener *self, MyContextAttributeArgList *ctx);
    void (*exit_attribute_arg_list)   (MyPhpParserListener *self, MyContextAttributeArgList *ctx);

    void (*enter_attribute_named_arg_list)  (MyPhpParserListener *self, MyContextAttributeNamedArgList *ctx);
    void (*exit_attribute_named_arg_list)   (MyPhpParserListener *self, MyContextAttributeNamedArgList *ctx);

    void (*enter_attribute_named_arg)  (MyPhpParserListener *self, MyContextAttributeNamedArg *ctx);
    void (*exit_attribute_named_arg)   (MyPhpParserListener *self, MyContextAttributeNamedArg *ctx);

    void (*enter_inner_statement_list)  (MyPhpParserListener *self, MyContextInnerStatementList *ctx);
    void (*exit_inner_statement_list)   (MyPhpParserListener *self, MyContextInnerStatementList *ctx);

    void (*enter_inner_statement)  (MyPhpParserListener *self, MyContextInnerStatement *ctx);
    void (*exit_inner_statement)   (MyPhpParserListener *self, MyContextInnerStatement *ctx);

    void (*enter_statement)  (MyPhpParserListener *self, MyContextStatement *ctx);
    void (*exit_statement)   (MyPhpParserListener *self, MyContextStatement *ctx);

    void (*enter_empty_statement)  (MyPhpParserListener *self, MyContextEmptyStatement *ctx);
    void (*exit_empty_statement)   (MyPhpParserListener *self, MyContextEmptyStatement *ctx);

    void (*enter_block_statement)  (MyPhpParserListener *self, MyContextBlockStatement *ctx);
    void (*exit_block_statement)   (MyPhpParserListener *self, MyContextBlockStatement *ctx);

    void (*enter_if_statement)  (MyPhpParserListener *self, MyContextIfStatement *ctx);
    void (*exit_if_statement)   (MyPhpParserListener *self, MyContextIfStatement *ctx);

    void (*enter_else_if_statement)  (MyPhpParserListener *self, MyContextElseIfStatement *ctx);
    void (*exit_else_if_statement)   (MyPhpParserListener *self, MyContextElseIfStatement *ctx);

    void (*enter_else_if_colon_statement)  (MyPhpParserListener *self, MyContextElseIfColonStatement *ctx);
    void (*exit_else_if_colon_statement)   (MyPhpParserListener *self, MyContextElseIfColonStatement *ctx);

    void (*enter_else_statement)  (MyPhpParserListener *self, MyContextElseStatement *ctx);
    void (*exit_else_statement)   (MyPhpParserListener *self, MyContextElseStatement *ctx);

    void (*enter_else_colon_statement)  (MyPhpParserListener *self, MyContextElseColonStatement *ctx);
    void (*exit_else_colon_statement)   (MyPhpParserListener *self, MyContextElseColonStatement *ctx);

    void (*enter_while_statement)  (MyPhpParserListener *self, MyContextWhileStatement *ctx);
    void (*exit_while_statement)   (MyPhpParserListener *self, MyContextWhileStatement *ctx);

    void (*enter_do_while_statement)  (MyPhpParserListener *self, MyContextDoWhileStatement *ctx);
    void (*exit_do_while_statement)   (MyPhpParserListener *self, MyContextDoWhileStatement *ctx);

    void (*enter_for_statement)  (MyPhpParserListener *self, MyContextForStatement *ctx);
    void (*exit_for_statement)   (MyPhpParserListener *self, MyContextForStatement *ctx);

    void (*enter_for_init)  (MyPhpParserListener *self, MyContextForInit *ctx);
    void (*exit_for_init)   (MyPhpParserListener *self, MyContextForInit *ctx);

    void (*enter_for_update)  (MyPhpParserListener *self, MyContextForUpdate *ctx);
    void (*exit_for_update)   (MyPhpParserListener *self, MyContextForUpdate *ctx);

    void (*enter_switch_statement)  (MyPhpParserListener *self, MyContextSwitchStatement *ctx);
    void (*exit_switch_statement)   (MyPhpParserListener *self, MyContextSwitchStatement *ctx);

    void (*enter_switch_block)  (MyPhpParserListener *self, MyContextSwitchBlock *ctx);
    void (*exit_switch_block)   (MyPhpParserListener *self, MyContextSwitchBlock *ctx);

    void (*enter_break_statement)  (MyPhpParserListener *self, MyContextBreakStatement *ctx);
    void (*exit_break_statement)   (MyPhpParserListener *self, MyContextBreakStatement *ctx);

    void (*enter_continue_statement)  (MyPhpParserListener *self, MyContextContinueStatement *ctx);
    void (*exit_continue_statement)   (MyPhpParserListener *self, MyContextContinueStatement *ctx);

    void (*enter_return_statement)  (MyPhpParserListener *self, MyContextReturnStatement *ctx);
    void (*exit_return_statement)   (MyPhpParserListener *self, MyContextReturnStatement *ctx);

    void (*enter_expression_statement)  (MyPhpParserListener *self, MyContextExpressionStatement *ctx);
    void (*exit_expression_statement)   (MyPhpParserListener *self, MyContextExpressionStatement *ctx);

    void (*enter_unset_statement)  (MyPhpParserListener *self, MyContextUnsetStatement *ctx);
    void (*exit_unset_statement)   (MyPhpParserListener *self, MyContextUnsetStatement *ctx);

    void (*enter_foreach_statement)  (MyPhpParserListener *self, MyContextForeachStatement *ctx);
    void (*exit_foreach_statement)   (MyPhpParserListener *self, MyContextForeachStatement *ctx);

    void (*enter_try_catch_finally)  (MyPhpParserListener *self, MyContextTryCatchFinally *ctx);
    void (*exit_try_catch_finally)   (MyPhpParserListener *self, MyContextTryCatchFinally *ctx);

    void (*enter_catch_clause)  (MyPhpParserListener *self, MyContextCatchClause *ctx);
    void (*exit_catch_clause)   (MyPhpParserListener *self, MyContextCatchClause *ctx);

    void (*enter_finally_statement)  (MyPhpParserListener *self, MyContextFinallyStatement *ctx);
    void (*exit_finally_statement)   (MyPhpParserListener *self, MyContextFinallyStatement *ctx);

    void (*enter_throw_statement)  (MyPhpParserListener *self, MyContextThrowStatement *ctx);
    void (*exit_throw_statement)   (MyPhpParserListener *self, MyContextThrowStatement *ctx);

    void (*enter_goto_statement)  (MyPhpParserListener *self, MyContextGotoStatement *ctx);
    void (*exit_goto_statement)   (MyPhpParserListener *self, MyContextGotoStatement *ctx);

    void (*enter_declare_statement)  (MyPhpParserListener *self, MyContextDeclareStatement *ctx);
    void (*exit_declare_statement)   (MyPhpParserListener *self, MyContextDeclareStatement *ctx);

    void (*enter_inline_html_statement)  (MyPhpParserListener *self, MyContextInlineHtmlStatement *ctx);
    void (*exit_inline_html_statement)   (MyPhpParserListener *self, MyContextInlineHtmlStatement *ctx);

    void (*enter_inline_html)  (MyPhpParserListener *self, MyContextInlineHtml *ctx);
    void (*exit_inline_html)   (MyPhpParserListener *self, MyContextInlineHtml *ctx);

    void (*enter_declare_list)  (MyPhpParserListener *self, MyContextDeclareList *ctx);
    void (*exit_declare_list)   (MyPhpParserListener *self, MyContextDeclareList *ctx);

    void (*enter_formal_parameter_list)  (MyPhpParserListener *self, MyContextFormalParameterList *ctx);
    void (*exit_formal_parameter_list)   (MyPhpParserListener *self, MyContextFormalParameterList *ctx);

    void (*enter_formal_parameter)  (MyPhpParserListener *self, MyContextFormalParameter *ctx);
    void (*exit_formal_parameter)   (MyPhpParserListener *self, MyContextFormalParameter *ctx);

    void (*enter_type_hint)  (MyPhpParserListener *self, MyContextTypeHint *ctx);
    void (*exit_type_hint)   (MyPhpParserListener *self, MyContextTypeHint *ctx);

    void (*enter_global_statement)  (MyPhpParserListener *self, MyContextGlobalStatement *ctx);
    void (*exit_global_statement)   (MyPhpParserListener *self, MyContextGlobalStatement *ctx);

    void (*enter_global_var)  (MyPhpParserListener *self, MyContextGlobalVar *ctx);
    void (*exit_global_var)   (MyPhpParserListener *self, MyContextGlobalVar *ctx);

    void (*enter_echo_statement)  (MyPhpParserListener *self, MyContextEchoStatement *ctx);
    void (*exit_echo_statement)   (MyPhpParserListener *self, MyContextEchoStatement *ctx);

    void (*enter_static_variable_statement)  (MyPhpParserListener *self, MyContextStaticVariableStatement *ctx);
    void (*exit_static_variable_statement)   (MyPhpParserListener *self, MyContextStaticVariableStatement *ctx);

    void (*enter_class_statement)  (MyPhpParserListener *self, MyContextClassStatement *ctx);
    void (*exit_class_statement)   (MyPhpParserListener *self, MyContextClassStatement *ctx);

    void (*enter_trait_adaptations)  (MyPhpParserListener *self, MyContextTraitAdaptations *ctx);
    void (*exit_trait_adaptations)   (MyPhpParserListener *self, MyContextTraitAdaptations *ctx);

    void (*enter_trait_adaptation_statement)  (MyPhpParserListener *self, MyContextTraitAdaptationStatement *ctx);
    void (*exit_trait_adaptation_statement)   (MyPhpParserListener *self, MyContextTraitAdaptationStatement *ctx);

    void (*enter_trait_precedence)  (MyPhpParserListener *self, MyContextTraitPrecedence *ctx);
    void (*exit_trait_precedence)   (MyPhpParserListener *self, MyContextTraitPrecedence *ctx);

    void (*enter_trait_alias)  (MyPhpParserListener *self, MyContextTraitAlias *ctx);
    void (*exit_trait_alias)   (MyPhpParserListener *self, MyContextTraitAlias *ctx);

    void (*enter_trait_method_reference)  (MyPhpParserListener *self, MyContextTraitMethodReference *ctx);
    void (*exit_trait_method_reference)   (MyPhpParserListener *self, MyContextTraitMethodReference *ctx);

    void (*enter_base_ctor_call)  (MyPhpParserListener *self, MyContextBaseCtorCall *ctx);
    void (*exit_base_ctor_call)   (MyPhpParserListener *self, MyContextBaseCtorCall *ctx);

    void (*enter_method_body)  (MyPhpParserListener *self, MyContextMethodBody *ctx);
    void (*exit_method_body)   (MyPhpParserListener *self, MyContextMethodBody *ctx);

    void (*enter_property_modifiers)  (MyPhpParserListener *self, MyContextPropertyModifiers *ctx);
    void (*exit_property_modifiers)   (MyPhpParserListener *self, MyContextPropertyModifiers *ctx);

    void (*enter_member_modifiers)  (MyPhpParserListener *self, MyContextMemberModifiers *ctx);
    void (*exit_member_modifiers)   (MyPhpParserListener *self, MyContextMemberModifiers *ctx);

    void (*enter_variable_initializer)  (MyPhpParserListener *self, MyContextVariableInitializer *ctx);
    void (*exit_variable_initializer)   (MyPhpParserListener *self, MyContextVariableInitializer *ctx);

    void (*enter_identifier_inititalizer)  (MyPhpParserListener *self, MyContextIdentifierInititalizer *ctx);
    void (*exit_identifier_inititalizer)   (MyPhpParserListener *self, MyContextIdentifierInititalizer *ctx);

    void (*enter_global_constant_declaration)  (MyPhpParserListener *self, MyContextGlobalConstantDeclaration *ctx);
    void (*exit_global_constant_declaration)   (MyPhpParserListener *self, MyContextGlobalConstantDeclaration *ctx);

    void (*enter_expression_list)  (MyPhpParserListener *self, MyContextExpressionList *ctx);
    void (*exit_expression_list)   (MyPhpParserListener *self, MyContextExpressionList *ctx);

    void (*enter_parenthesis)  (MyPhpParserListener *self, MyContextParenthesis *ctx);
    void (*exit_parenthesis)   (MyPhpParserListener *self, MyContextParenthesis *ctx);

    void (*enter_chain_expression)  (MyPhpParserListener *self, MyContextChainExpression *ctx);
    void (*exit_chain_expression)   (MyPhpParserListener *self, MyContextChainExpression *ctx);

    void (*enter_unary_operator_expression)  (MyPhpParserListener *self, MyContextUnaryOperatorExpression *ctx);
    void (*exit_unary_operator_expression)   (MyPhpParserListener *self, MyContextUnaryOperatorExpression *ctx);

    void (*enter_special_word_expression)  (MyPhpParserListener *self, MyContextSpecialWordExpression *ctx);
    void (*exit_special_word_expression)   (MyPhpParserListener *self, MyContextSpecialWordExpression *ctx);

    void (*enter_array_creation_expression)  (MyPhpParserListener *self, MyContextArrayCreationExpression *ctx);
    void (*exit_array_creation_expression)   (MyPhpParserListener *self, MyContextArrayCreationExpression *ctx);

    void (*enter_new_expression)  (MyPhpParserListener *self, MyContextNewExpression *ctx);
    void (*exit_new_expression)   (MyPhpParserListener *self, MyContextNewExpression *ctx);

    void (*enter_parenthesis_expression)  (MyPhpParserListener *self, MyContextParenthesisExpression *ctx);
    void (*exit_parenthesis_expression)   (MyPhpParserListener *self, MyContextParenthesisExpression *ctx);

    void (*enter_back_quote_string_expression)  (MyPhpParserListener *self, MyContextBackQuoteStringExpression *ctx);
    void (*exit_back_quote_string_expression)   (MyPhpParserListener *self, MyContextBackQuoteStringExpression *ctx);

    void (*enter_conditional_expression)  (MyPhpParserListener *self, MyContextConditionalExpression *ctx);
    void (*exit_conditional_expression)   (MyPhpParserListener *self, MyContextConditionalExpression *ctx);

    void (*enter_arithmetic_expression)  (MyPhpParserListener *self, MyContextArithmeticExpression *ctx);
    void (*exit_arithmetic_expression)   (MyPhpParserListener *self, MyContextArithmeticExpression *ctx);

    void (*enter_indexer_expression)  (MyPhpParserListener *self, MyContextIndexerExpression *ctx);
    void (*exit_indexer_expression)   (MyPhpParserListener *self, MyContextIndexerExpression *ctx);

    void (*enter_scalar_expression)  (MyPhpParserListener *self, MyContextScalarExpression *ctx);
    void (*exit_scalar_expression)   (MyPhpParserListener *self, MyContextScalarExpression *ctx);

    void (*enter_prefix_inc_dec_expression)  (MyPhpParserListener *self, MyContextPrefixIncDecExpression *ctx);
    void (*exit_prefix_inc_dec_expression)   (MyPhpParserListener *self, MyContextPrefixIncDecExpression *ctx);

    void (*enter_comparison_expression)  (MyPhpParserListener *self, MyContextComparisonExpression *ctx);
    void (*exit_comparison_expression)   (MyPhpParserListener *self, MyContextComparisonExpression *ctx);

    void (*enter_logical_expression)  (MyPhpParserListener *self, MyContextLogicalExpression *ctx);
    void (*exit_logical_expression)   (MyPhpParserListener *self, MyContextLogicalExpression *ctx);

    void (*enter_print_expression)  (MyPhpParserListener *self, MyContextPrintExpression *ctx);
    void (*exit_print_expression)   (MyPhpParserListener *self, MyContextPrintExpression *ctx);

    void (*enter_assignment_expression)  (MyPhpParserListener *self, MyContextAssignmentExpression *ctx);
    void (*exit_assignment_expression)   (MyPhpParserListener *self, MyContextAssignmentExpression *ctx);

    void (*enter_postfix_inc_dec_expression)  (MyPhpParserListener *self, MyContextPostfixIncDecExpression *ctx);
    void (*exit_postfix_inc_dec_expression)   (MyPhpParserListener *self, MyContextPostfixIncDecExpression *ctx);

    void (*enter_cast_expression)  (MyPhpParserListener *self, MyContextCastExpression *ctx);
    void (*exit_cast_expression)   (MyPhpParserListener *self, MyContextCastExpression *ctx);

    void (*enter_instance_of_expression)  (MyPhpParserListener *self, MyContextInstanceOfExpression *ctx);
    void (*exit_instance_of_expression)   (MyPhpParserListener *self, MyContextInstanceOfExpression *ctx);

    void (*enter_lambda_function_expression)  (MyPhpParserListener *self, MyContextLambdaFunctionExpression *ctx);
    void (*exit_lambda_function_expression)   (MyPhpParserListener *self, MyContextLambdaFunctionExpression *ctx);

    void (*enter_bitwise_expression)  (MyPhpParserListener *self, MyContextBitwiseExpression *ctx);
    void (*exit_bitwise_expression)   (MyPhpParserListener *self, MyContextBitwiseExpression *ctx);

    void (*enter_clone_expression)  (MyPhpParserListener *self, MyContextCloneExpression *ctx);
    void (*exit_clone_expression)   (MyPhpParserListener *self, MyContextCloneExpression *ctx);

    void (*enter_new_expr)  (MyPhpParserListener *self, MyContextNewExpr *ctx);
    void (*exit_new_expr)   (MyPhpParserListener *self, MyContextNewExpr *ctx);

    void (*enter_assignment_operator)  (MyPhpParserListener *self, MyContextAssignmentOperator *ctx);
    void (*exit_assignment_operator)   (MyPhpParserListener *self, MyContextAssignmentOperator *ctx);

    void (*enter_yield_expression)  (MyPhpParserListener *self, MyContextYieldExpression *ctx);
    void (*exit_yield_expression)   (MyPhpParserListener *self, MyContextYieldExpression *ctx);

    void (*enter_array_item_list)  (MyPhpParserListener *self, MyContextArrayItemList *ctx);
    void (*exit_array_item_list)   (MyPhpParserListener *self, MyContextArrayItemList *ctx);

    void (*enter_array_item)  (MyPhpParserListener *self, MyContextArrayItem *ctx);
    void (*exit_array_item)   (MyPhpParserListener *self, MyContextArrayItem *ctx);

    void (*enter_lambda_function_use_vars)  (MyPhpParserListener *self, MyContextLambdaFunctionUseVars *ctx);
    void (*exit_lambda_function_use_vars)   (MyPhpParserListener *self, MyContextLambdaFunctionUseVars *ctx);

    void (*enter_lambda_function_use_var)  (MyPhpParserListener *self, MyContextLambdaFunctionUseVar *ctx);
    void (*exit_lambda_function_use_var)   (MyPhpParserListener *self, MyContextLambdaFunctionUseVar *ctx);

    void (*enter_qualified_static_type_ref)  (MyPhpParserListener *self, MyContextQualifiedStaticTypeRef *ctx);
    void (*exit_qualified_static_type_ref)   (MyPhpParserListener *self, MyContextQualifiedStaticTypeRef *ctx);

    void (*enter_type_ref)  (MyPhpParserListener *self, MyContextTypeRef *ctx);
    void (*exit_type_ref)   (MyPhpParserListener *self, MyContextTypeRef *ctx);

    void (*enter_indirect_type_ref)  (MyPhpParserListener *self, MyContextIndirectTypeRef *ctx);
    void (*exit_indirect_type_ref)   (MyPhpParserListener *self, MyContextIndirectTypeRef *ctx);

    void (*enter_qualified_namespace_name)  (MyPhpParserListener *self, MyContextQualifiedNamespaceName *ctx);
    void (*exit_qualified_namespace_name)   (MyPhpParserListener *self, MyContextQualifiedNamespaceName *ctx);

    void (*enter_namespace_name_list)  (MyPhpParserListener *self, MyContextNamespaceNameList *ctx);
    void (*exit_namespace_name_list)   (MyPhpParserListener *self, MyContextNamespaceNameList *ctx);

    void (*enter_qualified_namespace_name_list)  (MyPhpParserListener *self, MyContextQualifiedNamespaceNameList *ctx);
    void (*exit_qualified_namespace_name_list)   (MyPhpParserListener *self, MyContextQualifiedNamespaceNameList *ctx);

    void (*enter_arguments)  (MyPhpParserListener *self, MyContextArguments *ctx);
    void (*exit_arguments)   (MyPhpParserListener *self, MyContextArguments *ctx);

    void (*enter_actual_argument)  (MyPhpParserListener *self, MyContextActualArgument *ctx);
    void (*exit_actual_argument)   (MyPhpParserListener *self, MyContextActualArgument *ctx);

    void (*enter_constant_inititalizer)  (MyPhpParserListener *self, MyContextConstantInititalizer *ctx);
    void (*exit_constant_inititalizer)   (MyPhpParserListener *self, MyContextConstantInititalizer *ctx);

    void (*enter_constant_array_item_list)  (MyPhpParserListener *self, MyContextConstantArrayItemList *ctx);
    void (*exit_constant_array_item_list)   (MyPhpParserListener *self, MyContextConstantArrayItemList *ctx);

    void (*enter_constant_array_item)  (MyPhpParserListener *self, MyContextConstantArrayItem *ctx);
    void (*exit_constant_array_item)   (MyPhpParserListener *self, MyContextConstantArrayItem *ctx);

    void (*enter_constant)  (MyPhpParserListener *self, MyContextConstant *ctx);
    void (*exit_constant)   (MyPhpParserListener *self, MyContextConstant *ctx);

    void (*enter_literal_constant)  (MyPhpParserListener *self, MyContextLiteralConstant *ctx);
    void (*exit_literal_constant)   (MyPhpParserListener *self, MyContextLiteralConstant *ctx);

    void (*enter_numeric_constant)  (MyPhpParserListener *self, MyContextNumericConstant *ctx);
    void (*exit_numeric_constant)   (MyPhpParserListener *self, MyContextNumericConstant *ctx);

    void (*enter_class_constant)  (MyPhpParserListener *self, MyContextClassConstant *ctx);
    void (*exit_class_constant)   (MyPhpParserListener *self, MyContextClassConstant *ctx);

    void (*enter_string_constant)  (MyPhpParserListener *self, MyContextStringConstant *ctx);
    void (*exit_string_constant)   (MyPhpParserListener *self, MyContextStringConstant *ctx);

    void (*enter_string)  (MyPhpParserListener *self, MyContextString *ctx);
    void (*exit_string)   (MyPhpParserListener *self, MyContextString *ctx);

    void (*enter_interpolated_string_part)  (MyPhpParserListener *self, MyContextInterpolatedStringPart *ctx);
    void (*exit_interpolated_string_part)   (MyPhpParserListener *self, MyContextInterpolatedStringPart *ctx);

    void (*enter_chain_list)  (MyPhpParserListener *self, MyContextChainList *ctx);
    void (*exit_chain_list)   (MyPhpParserListener *self, MyContextChainList *ctx);

    void (*enter_chain)  (MyPhpParserListener *self, MyContextChain *ctx);
    void (*exit_chain)   (MyPhpParserListener *self, MyContextChain *ctx);

    void (*enter_member_access)  (MyPhpParserListener *self, MyContextMemberAccess *ctx);
    void (*exit_member_access)   (MyPhpParserListener *self, MyContextMemberAccess *ctx);

    void (*enter_function_call)  (MyPhpParserListener *self, MyContextFunctionCall *ctx);
    void (*exit_function_call)   (MyPhpParserListener *self, MyContextFunctionCall *ctx);

    void (*enter_function_call_name)  (MyPhpParserListener *self, MyContextFunctionCallName *ctx);
    void (*exit_function_call_name)   (MyPhpParserListener *self, MyContextFunctionCallName *ctx);

    void (*enter_actual_arguments)  (MyPhpParserListener *self, MyContextActualArguments *ctx);
    void (*exit_actual_arguments)   (MyPhpParserListener *self, MyContextActualArguments *ctx);

    void (*enter_chain_base)  (MyPhpParserListener *self, MyContextChainBase *ctx);
    void (*exit_chain_base)   (MyPhpParserListener *self, MyContextChainBase *ctx);

    void (*enter_keyed_field_name)  (MyPhpParserListener *self, MyContextKeyedFieldName *ctx);
    void (*exit_keyed_field_name)   (MyPhpParserListener *self, MyContextKeyedFieldName *ctx);

    void (*enter_keyed_simple_field_name)  (MyPhpParserListener *self, MyContextKeyedSimpleFieldName *ctx);
    void (*exit_keyed_simple_field_name)   (MyPhpParserListener *self, MyContextKeyedSimpleFieldName *ctx);

    void (*enter_keyed_variable)  (MyPhpParserListener *self, MyContextKeyedVariable *ctx);
    void (*exit_keyed_variable)   (MyPhpParserListener *self, MyContextKeyedVariable *ctx);

    void (*enter_square_curly_expression)  (MyPhpParserListener *self, MyContextSquareCurlyExpression *ctx);
    void (*exit_square_curly_expression)   (MyPhpParserListener *self, MyContextSquareCurlyExpression *ctx);

    void (*enter_assignment_list)  (MyPhpParserListener *self, MyContextAssignmentList *ctx);
    void (*exit_assignment_list)   (MyPhpParserListener *self, MyContextAssignmentList *ctx);

    void (*enter_assignment_list_element)  (MyPhpParserListener *self, MyContextAssignmentListElement *ctx);
    void (*exit_assignment_list_element)   (MyPhpParserListener *self, MyContextAssignmentListElement *ctx);

    void (*enter_modifier)  (MyPhpParserListener *self, MyContextModifier *ctx);
    void (*exit_modifier)   (MyPhpParserListener *self, MyContextModifier *ctx);

    void (*enter_identifier)  (MyPhpParserListener *self, MyContextIdentifier *ctx);
    void (*exit_identifier)   (MyPhpParserListener *self, MyContextIdentifier *ctx);

    void (*enter_member_modifier)  (MyPhpParserListener *self, MyContextMemberModifier *ctx);
    void (*exit_member_modifier)   (MyPhpParserListener *self, MyContextMemberModifier *ctx);

    void (*enter_magic_constant)  (MyPhpParserListener *self, MyContextMagicConstant *ctx);
    void (*exit_magic_constant)   (MyPhpParserListener *self, MyContextMagicConstant *ctx);

    void (*enter_magic_method)  (MyPhpParserListener *self, MyContextMagicMethod *ctx);
    void (*exit_magic_method)   (MyPhpParserListener *self, MyContextMagicMethod *ctx);

    void (*enter_primitive_type)  (MyPhpParserListener *self, MyContextPrimitiveType *ctx);
    void (*exit_primitive_type)   (MyPhpParserListener *self, MyContextPrimitiveType *ctx);

    void (*enter_cast_operation)  (MyPhpParserListener *self, MyContextCastOperation *ctx);
    void (*exit_cast_operation)   (MyPhpParserListener *self, MyContextCastOperation *ctx);

};

GType my_php_parser_listener_get_type (void) G_GNUC_CONST;

void my_php_parser_listener_enter_html_document  (MyPhpParserListener *self, MyContextHtmlDocument *ctx);
void my_php_parser_listener_exit_html_document   (MyPhpParserListener *self, MyContextHtmlDocument *ctx);

void my_php_parser_listener_enter_html_element_or_php_block  (MyPhpParserListener *self, MyContextHtmlElementOrPhpBlock *ctx);
void my_php_parser_listener_exit_html_element_or_php_block   (MyPhpParserListener *self, MyContextHtmlElementOrPhpBlock *ctx);

void my_php_parser_listener_enter_html_elements  (MyPhpParserListener *self, MyContextHtmlElements *ctx);
void my_php_parser_listener_exit_html_elements   (MyPhpParserListener *self, MyContextHtmlElements *ctx);

void my_php_parser_listener_enter_html_element  (MyPhpParserListener *self, MyContextHtmlElement *ctx);
void my_php_parser_listener_exit_html_element   (MyPhpParserListener *self, MyContextHtmlElement *ctx);

void my_php_parser_listener_enter_script_text_part  (MyPhpParserListener *self, MyContextScriptTextPart *ctx);
void my_php_parser_listener_exit_script_text_part   (MyPhpParserListener *self, MyContextScriptTextPart *ctx);

void my_php_parser_listener_enter_php_block  (MyPhpParserListener *self, MyContextPhpBlock *ctx);
void my_php_parser_listener_exit_php_block   (MyPhpParserListener *self, MyContextPhpBlock *ctx);

void my_php_parser_listener_enter_import_statement  (MyPhpParserListener *self, MyContextImportStatement *ctx);
void my_php_parser_listener_exit_import_statement   (MyPhpParserListener *self, MyContextImportStatement *ctx);

void my_php_parser_listener_enter_top_statement  (MyPhpParserListener *self, MyContextTopStatement *ctx);
void my_php_parser_listener_exit_top_statement   (MyPhpParserListener *self, MyContextTopStatement *ctx);

void my_php_parser_listener_enter_use_declaration  (MyPhpParserListener *self, MyContextUseDeclaration *ctx);
void my_php_parser_listener_exit_use_declaration   (MyPhpParserListener *self, MyContextUseDeclaration *ctx);

void my_php_parser_listener_enter_use_declaration_content_list  (MyPhpParserListener *self, MyContextUseDeclarationContentList *ctx);
void my_php_parser_listener_exit_use_declaration_content_list   (MyPhpParserListener *self, MyContextUseDeclarationContentList *ctx);

void my_php_parser_listener_enter_use_declaration_content  (MyPhpParserListener *self, MyContextUseDeclarationContent *ctx);
void my_php_parser_listener_exit_use_declaration_content   (MyPhpParserListener *self, MyContextUseDeclarationContent *ctx);

void my_php_parser_listener_enter_namespace_declaration  (MyPhpParserListener *self, MyContextNamespaceDeclaration *ctx);
void my_php_parser_listener_exit_namespace_declaration   (MyPhpParserListener *self, MyContextNamespaceDeclaration *ctx);

void my_php_parser_listener_enter_namespace_statement  (MyPhpParserListener *self, MyContextNamespaceStatement *ctx);
void my_php_parser_listener_exit_namespace_statement   (MyPhpParserListener *self, MyContextNamespaceStatement *ctx);

void my_php_parser_listener_enter_function_declaration  (MyPhpParserListener *self, MyContextFunctionDeclaration *ctx);
void my_php_parser_listener_exit_function_declaration   (MyPhpParserListener *self, MyContextFunctionDeclaration *ctx);

void my_php_parser_listener_enter_class_declaration  (MyPhpParserListener *self, MyContextClassDeclaration *ctx);
void my_php_parser_listener_exit_class_declaration   (MyPhpParserListener *self, MyContextClassDeclaration *ctx);

void my_php_parser_listener_enter_class_entry_type  (MyPhpParserListener *self, MyContextClassEntryType *ctx);
void my_php_parser_listener_exit_class_entry_type   (MyPhpParserListener *self, MyContextClassEntryType *ctx);

void my_php_parser_listener_enter_interface_list  (MyPhpParserListener *self, MyContextInterfaceList *ctx);
void my_php_parser_listener_exit_interface_list   (MyPhpParserListener *self, MyContextInterfaceList *ctx);

void my_php_parser_listener_enter_type_parameter_list_in_brackets  (MyPhpParserListener *self, MyContextTypeParameterListInBrackets *ctx);
void my_php_parser_listener_exit_type_parameter_list_in_brackets   (MyPhpParserListener *self, MyContextTypeParameterListInBrackets *ctx);

void my_php_parser_listener_enter_type_parameter_list  (MyPhpParserListener *self, MyContextTypeParameterList *ctx);
void my_php_parser_listener_exit_type_parameter_list   (MyPhpParserListener *self, MyContextTypeParameterList *ctx);

void my_php_parser_listener_enter_type_parameter_with_defaults_list  (MyPhpParserListener *self, MyContextTypeParameterWithDefaultsList *ctx);
void my_php_parser_listener_exit_type_parameter_with_defaults_list   (MyPhpParserListener *self, MyContextTypeParameterWithDefaultsList *ctx);

void my_php_parser_listener_enter_type_parameter_decl  (MyPhpParserListener *self, MyContextTypeParameterDecl *ctx);
void my_php_parser_listener_exit_type_parameter_decl   (MyPhpParserListener *self, MyContextTypeParameterDecl *ctx);

void my_php_parser_listener_enter_type_parameter_with_default_decl  (MyPhpParserListener *self, MyContextTypeParameterWithDefaultDecl *ctx);
void my_php_parser_listener_exit_type_parameter_with_default_decl   (MyPhpParserListener *self, MyContextTypeParameterWithDefaultDecl *ctx);

void my_php_parser_listener_enter_generic_dynamic_args  (MyPhpParserListener *self, MyContextGenericDynamicArgs *ctx);
void my_php_parser_listener_exit_generic_dynamic_args   (MyPhpParserListener *self, MyContextGenericDynamicArgs *ctx);

void my_php_parser_listener_enter_attributes  (MyPhpParserListener *self, MyContextAttributes *ctx);
void my_php_parser_listener_exit_attributes   (MyPhpParserListener *self, MyContextAttributes *ctx);

void my_php_parser_listener_enter_attributes_group  (MyPhpParserListener *self, MyContextAttributesGroup *ctx);
void my_php_parser_listener_exit_attributes_group   (MyPhpParserListener *self, MyContextAttributesGroup *ctx);

void my_php_parser_listener_enter_attribute  (MyPhpParserListener *self, MyContextAttribute *ctx);
void my_php_parser_listener_exit_attribute   (MyPhpParserListener *self, MyContextAttribute *ctx);

void my_php_parser_listener_enter_attribute_arg_list  (MyPhpParserListener *self, MyContextAttributeArgList *ctx);
void my_php_parser_listener_exit_attribute_arg_list   (MyPhpParserListener *self, MyContextAttributeArgList *ctx);

void my_php_parser_listener_enter_attribute_named_arg_list  (MyPhpParserListener *self, MyContextAttributeNamedArgList *ctx);
void my_php_parser_listener_exit_attribute_named_arg_list   (MyPhpParserListener *self, MyContextAttributeNamedArgList *ctx);

void my_php_parser_listener_enter_attribute_named_arg  (MyPhpParserListener *self, MyContextAttributeNamedArg *ctx);
void my_php_parser_listener_exit_attribute_named_arg   (MyPhpParserListener *self, MyContextAttributeNamedArg *ctx);

void my_php_parser_listener_enter_inner_statement_list  (MyPhpParserListener *self, MyContextInnerStatementList *ctx);
void my_php_parser_listener_exit_inner_statement_list   (MyPhpParserListener *self, MyContextInnerStatementList *ctx);

void my_php_parser_listener_enter_inner_statement  (MyPhpParserListener *self, MyContextInnerStatement *ctx);
void my_php_parser_listener_exit_inner_statement   (MyPhpParserListener *self, MyContextInnerStatement *ctx);

void my_php_parser_listener_enter_statement  (MyPhpParserListener *self, MyContextStatement *ctx);
void my_php_parser_listener_exit_statement   (MyPhpParserListener *self, MyContextStatement *ctx);

void my_php_parser_listener_enter_empty_statement  (MyPhpParserListener *self, MyContextEmptyStatement *ctx);
void my_php_parser_listener_exit_empty_statement   (MyPhpParserListener *self, MyContextEmptyStatement *ctx);

void my_php_parser_listener_enter_block_statement  (MyPhpParserListener *self, MyContextBlockStatement *ctx);
void my_php_parser_listener_exit_block_statement   (MyPhpParserListener *self, MyContextBlockStatement *ctx);

void my_php_parser_listener_enter_if_statement  (MyPhpParserListener *self, MyContextIfStatement *ctx);
void my_php_parser_listener_exit_if_statement   (MyPhpParserListener *self, MyContextIfStatement *ctx);

void my_php_parser_listener_enter_else_if_statement  (MyPhpParserListener *self, MyContextElseIfStatement *ctx);
void my_php_parser_listener_exit_else_if_statement   (MyPhpParserListener *self, MyContextElseIfStatement *ctx);

void my_php_parser_listener_enter_else_if_colon_statement  (MyPhpParserListener *self, MyContextElseIfColonStatement *ctx);
void my_php_parser_listener_exit_else_if_colon_statement   (MyPhpParserListener *self, MyContextElseIfColonStatement *ctx);

void my_php_parser_listener_enter_else_statement  (MyPhpParserListener *self, MyContextElseStatement *ctx);
void my_php_parser_listener_exit_else_statement   (MyPhpParserListener *self, MyContextElseStatement *ctx);

void my_php_parser_listener_enter_else_colon_statement  (MyPhpParserListener *self, MyContextElseColonStatement *ctx);
void my_php_parser_listener_exit_else_colon_statement   (MyPhpParserListener *self, MyContextElseColonStatement *ctx);

void my_php_parser_listener_enter_while_statement  (MyPhpParserListener *self, MyContextWhileStatement *ctx);
void my_php_parser_listener_exit_while_statement   (MyPhpParserListener *self, MyContextWhileStatement *ctx);

void my_php_parser_listener_enter_do_while_statement  (MyPhpParserListener *self, MyContextDoWhileStatement *ctx);
void my_php_parser_listener_exit_do_while_statement   (MyPhpParserListener *self, MyContextDoWhileStatement *ctx);

void my_php_parser_listener_enter_for_statement  (MyPhpParserListener *self, MyContextForStatement *ctx);
void my_php_parser_listener_exit_for_statement   (MyPhpParserListener *self, MyContextForStatement *ctx);

void my_php_parser_listener_enter_for_init  (MyPhpParserListener *self, MyContextForInit *ctx);
void my_php_parser_listener_exit_for_init   (MyPhpParserListener *self, MyContextForInit *ctx);

void my_php_parser_listener_enter_for_update  (MyPhpParserListener *self, MyContextForUpdate *ctx);
void my_php_parser_listener_exit_for_update   (MyPhpParserListener *self, MyContextForUpdate *ctx);

void my_php_parser_listener_enter_switch_statement  (MyPhpParserListener *self, MyContextSwitchStatement *ctx);
void my_php_parser_listener_exit_switch_statement   (MyPhpParserListener *self, MyContextSwitchStatement *ctx);

void my_php_parser_listener_enter_switch_block  (MyPhpParserListener *self, MyContextSwitchBlock *ctx);
void my_php_parser_listener_exit_switch_block   (MyPhpParserListener *self, MyContextSwitchBlock *ctx);

void my_php_parser_listener_enter_break_statement  (MyPhpParserListener *self, MyContextBreakStatement *ctx);
void my_php_parser_listener_exit_break_statement   (MyPhpParserListener *self, MyContextBreakStatement *ctx);

void my_php_parser_listener_enter_continue_statement  (MyPhpParserListener *self, MyContextContinueStatement *ctx);
void my_php_parser_listener_exit_continue_statement   (MyPhpParserListener *self, MyContextContinueStatement *ctx);

void my_php_parser_listener_enter_return_statement  (MyPhpParserListener *self, MyContextReturnStatement *ctx);
void my_php_parser_listener_exit_return_statement   (MyPhpParserListener *self, MyContextReturnStatement *ctx);

void my_php_parser_listener_enter_expression_statement  (MyPhpParserListener *self, MyContextExpressionStatement *ctx);
void my_php_parser_listener_exit_expression_statement   (MyPhpParserListener *self, MyContextExpressionStatement *ctx);

void my_php_parser_listener_enter_unset_statement  (MyPhpParserListener *self, MyContextUnsetStatement *ctx);
void my_php_parser_listener_exit_unset_statement   (MyPhpParserListener *self, MyContextUnsetStatement *ctx);

void my_php_parser_listener_enter_foreach_statement  (MyPhpParserListener *self, MyContextForeachStatement *ctx);
void my_php_parser_listener_exit_foreach_statement   (MyPhpParserListener *self, MyContextForeachStatement *ctx);

void my_php_parser_listener_enter_try_catch_finally  (MyPhpParserListener *self, MyContextTryCatchFinally *ctx);
void my_php_parser_listener_exit_try_catch_finally   (MyPhpParserListener *self, MyContextTryCatchFinally *ctx);

void my_php_parser_listener_enter_catch_clause  (MyPhpParserListener *self, MyContextCatchClause *ctx);
void my_php_parser_listener_exit_catch_clause   (MyPhpParserListener *self, MyContextCatchClause *ctx);

void my_php_parser_listener_enter_finally_statement  (MyPhpParserListener *self, MyContextFinallyStatement *ctx);
void my_php_parser_listener_exit_finally_statement   (MyPhpParserListener *self, MyContextFinallyStatement *ctx);

void my_php_parser_listener_enter_throw_statement  (MyPhpParserListener *self, MyContextThrowStatement *ctx);
void my_php_parser_listener_exit_throw_statement   (MyPhpParserListener *self, MyContextThrowStatement *ctx);

void my_php_parser_listener_enter_goto_statement  (MyPhpParserListener *self, MyContextGotoStatement *ctx);
void my_php_parser_listener_exit_goto_statement   (MyPhpParserListener *self, MyContextGotoStatement *ctx);

void my_php_parser_listener_enter_declare_statement  (MyPhpParserListener *self, MyContextDeclareStatement *ctx);
void my_php_parser_listener_exit_declare_statement   (MyPhpParserListener *self, MyContextDeclareStatement *ctx);

void my_php_parser_listener_enter_inline_html_statement  (MyPhpParserListener *self, MyContextInlineHtmlStatement *ctx);
void my_php_parser_listener_exit_inline_html_statement   (MyPhpParserListener *self, MyContextInlineHtmlStatement *ctx);

void my_php_parser_listener_enter_inline_html  (MyPhpParserListener *self, MyContextInlineHtml *ctx);
void my_php_parser_listener_exit_inline_html   (MyPhpParserListener *self, MyContextInlineHtml *ctx);

void my_php_parser_listener_enter_declare_list  (MyPhpParserListener *self, MyContextDeclareList *ctx);
void my_php_parser_listener_exit_declare_list   (MyPhpParserListener *self, MyContextDeclareList *ctx);

void my_php_parser_listener_enter_formal_parameter_list  (MyPhpParserListener *self, MyContextFormalParameterList *ctx);
void my_php_parser_listener_exit_formal_parameter_list   (MyPhpParserListener *self, MyContextFormalParameterList *ctx);

void my_php_parser_listener_enter_formal_parameter  (MyPhpParserListener *self, MyContextFormalParameter *ctx);
void my_php_parser_listener_exit_formal_parameter   (MyPhpParserListener *self, MyContextFormalParameter *ctx);

void my_php_parser_listener_enter_type_hint  (MyPhpParserListener *self, MyContextTypeHint *ctx);
void my_php_parser_listener_exit_type_hint   (MyPhpParserListener *self, MyContextTypeHint *ctx);

void my_php_parser_listener_enter_global_statement  (MyPhpParserListener *self, MyContextGlobalStatement *ctx);
void my_php_parser_listener_exit_global_statement   (MyPhpParserListener *self, MyContextGlobalStatement *ctx);

void my_php_parser_listener_enter_global_var  (MyPhpParserListener *self, MyContextGlobalVar *ctx);
void my_php_parser_listener_exit_global_var   (MyPhpParserListener *self, MyContextGlobalVar *ctx);

void my_php_parser_listener_enter_echo_statement  (MyPhpParserListener *self, MyContextEchoStatement *ctx);
void my_php_parser_listener_exit_echo_statement   (MyPhpParserListener *self, MyContextEchoStatement *ctx);

void my_php_parser_listener_enter_static_variable_statement  (MyPhpParserListener *self, MyContextStaticVariableStatement *ctx);
void my_php_parser_listener_exit_static_variable_statement   (MyPhpParserListener *self, MyContextStaticVariableStatement *ctx);

void my_php_parser_listener_enter_class_statement  (MyPhpParserListener *self, MyContextClassStatement *ctx);
void my_php_parser_listener_exit_class_statement   (MyPhpParserListener *self, MyContextClassStatement *ctx);

void my_php_parser_listener_enter_trait_adaptations  (MyPhpParserListener *self, MyContextTraitAdaptations *ctx);
void my_php_parser_listener_exit_trait_adaptations   (MyPhpParserListener *self, MyContextTraitAdaptations *ctx);

void my_php_parser_listener_enter_trait_adaptation_statement  (MyPhpParserListener *self, MyContextTraitAdaptationStatement *ctx);
void my_php_parser_listener_exit_trait_adaptation_statement   (MyPhpParserListener *self, MyContextTraitAdaptationStatement *ctx);

void my_php_parser_listener_enter_trait_precedence  (MyPhpParserListener *self, MyContextTraitPrecedence *ctx);
void my_php_parser_listener_exit_trait_precedence   (MyPhpParserListener *self, MyContextTraitPrecedence *ctx);

void my_php_parser_listener_enter_trait_alias  (MyPhpParserListener *self, MyContextTraitAlias *ctx);
void my_php_parser_listener_exit_trait_alias   (MyPhpParserListener *self, MyContextTraitAlias *ctx);

void my_php_parser_listener_enter_trait_method_reference  (MyPhpParserListener *self, MyContextTraitMethodReference *ctx);
void my_php_parser_listener_exit_trait_method_reference   (MyPhpParserListener *self, MyContextTraitMethodReference *ctx);

void my_php_parser_listener_enter_base_ctor_call  (MyPhpParserListener *self, MyContextBaseCtorCall *ctx);
void my_php_parser_listener_exit_base_ctor_call   (MyPhpParserListener *self, MyContextBaseCtorCall *ctx);

void my_php_parser_listener_enter_method_body  (MyPhpParserListener *self, MyContextMethodBody *ctx);
void my_php_parser_listener_exit_method_body   (MyPhpParserListener *self, MyContextMethodBody *ctx);

void my_php_parser_listener_enter_property_modifiers  (MyPhpParserListener *self, MyContextPropertyModifiers *ctx);
void my_php_parser_listener_exit_property_modifiers   (MyPhpParserListener *self, MyContextPropertyModifiers *ctx);

void my_php_parser_listener_enter_member_modifiers  (MyPhpParserListener *self, MyContextMemberModifiers *ctx);
void my_php_parser_listener_exit_member_modifiers   (MyPhpParserListener *self, MyContextMemberModifiers *ctx);

void my_php_parser_listener_enter_variable_initializer  (MyPhpParserListener *self, MyContextVariableInitializer *ctx);
void my_php_parser_listener_exit_variable_initializer   (MyPhpParserListener *self, MyContextVariableInitializer *ctx);

void my_php_parser_listener_enter_identifier_inititalizer  (MyPhpParserListener *self, MyContextIdentifierInititalizer *ctx);
void my_php_parser_listener_exit_identifier_inititalizer   (MyPhpParserListener *self, MyContextIdentifierInititalizer *ctx);

void my_php_parser_listener_enter_global_constant_declaration  (MyPhpParserListener *self, MyContextGlobalConstantDeclaration *ctx);
void my_php_parser_listener_exit_global_constant_declaration   (MyPhpParserListener *self, MyContextGlobalConstantDeclaration *ctx);

void my_php_parser_listener_enter_expression_list  (MyPhpParserListener *self, MyContextExpressionList *ctx);
void my_php_parser_listener_exit_expression_list   (MyPhpParserListener *self, MyContextExpressionList *ctx);

void my_php_parser_listener_enter_parenthesis  (MyPhpParserListener *self, MyContextParenthesis *ctx);
void my_php_parser_listener_exit_parenthesis   (MyPhpParserListener *self, MyContextParenthesis *ctx);

void my_php_parser_listener_enter_chain_expression  (MyPhpParserListener *self, MyContextChainExpression *ctx);
void my_php_parser_listener_exit_chain_expression   (MyPhpParserListener *self, MyContextChainExpression *ctx);

void my_php_parser_listener_enter_unary_operator_expression  (MyPhpParserListener *self, MyContextUnaryOperatorExpression *ctx);
void my_php_parser_listener_exit_unary_operator_expression   (MyPhpParserListener *self, MyContextUnaryOperatorExpression *ctx);

void my_php_parser_listener_enter_special_word_expression  (MyPhpParserListener *self, MyContextSpecialWordExpression *ctx);
void my_php_parser_listener_exit_special_word_expression   (MyPhpParserListener *self, MyContextSpecialWordExpression *ctx);

void my_php_parser_listener_enter_array_creation_expression  (MyPhpParserListener *self, MyContextArrayCreationExpression *ctx);
void my_php_parser_listener_exit_array_creation_expression   (MyPhpParserListener *self, MyContextArrayCreationExpression *ctx);

void my_php_parser_listener_enter_new_expression  (MyPhpParserListener *self, MyContextNewExpression *ctx);
void my_php_parser_listener_exit_new_expression   (MyPhpParserListener *self, MyContextNewExpression *ctx);

void my_php_parser_listener_enter_parenthesis_expression  (MyPhpParserListener *self, MyContextParenthesisExpression *ctx);
void my_php_parser_listener_exit_parenthesis_expression   (MyPhpParserListener *self, MyContextParenthesisExpression *ctx);

void my_php_parser_listener_enter_back_quote_string_expression  (MyPhpParserListener *self, MyContextBackQuoteStringExpression *ctx);
void my_php_parser_listener_exit_back_quote_string_expression   (MyPhpParserListener *self, MyContextBackQuoteStringExpression *ctx);

void my_php_parser_listener_enter_conditional_expression  (MyPhpParserListener *self, MyContextConditionalExpression *ctx);
void my_php_parser_listener_exit_conditional_expression   (MyPhpParserListener *self, MyContextConditionalExpression *ctx);

void my_php_parser_listener_enter_arithmetic_expression  (MyPhpParserListener *self, MyContextArithmeticExpression *ctx);
void my_php_parser_listener_exit_arithmetic_expression   (MyPhpParserListener *self, MyContextArithmeticExpression *ctx);

void my_php_parser_listener_enter_indexer_expression  (MyPhpParserListener *self, MyContextIndexerExpression *ctx);
void my_php_parser_listener_exit_indexer_expression   (MyPhpParserListener *self, MyContextIndexerExpression *ctx);

void my_php_parser_listener_enter_scalar_expression  (MyPhpParserListener *self, MyContextScalarExpression *ctx);
void my_php_parser_listener_exit_scalar_expression   (MyPhpParserListener *self, MyContextScalarExpression *ctx);

void my_php_parser_listener_enter_prefix_inc_dec_expression  (MyPhpParserListener *self, MyContextPrefixIncDecExpression *ctx);
void my_php_parser_listener_exit_prefix_inc_dec_expression   (MyPhpParserListener *self, MyContextPrefixIncDecExpression *ctx);

void my_php_parser_listener_enter_comparison_expression  (MyPhpParserListener *self, MyContextComparisonExpression *ctx);
void my_php_parser_listener_exit_comparison_expression   (MyPhpParserListener *self, MyContextComparisonExpression *ctx);

void my_php_parser_listener_enter_logical_expression  (MyPhpParserListener *self, MyContextLogicalExpression *ctx);
void my_php_parser_listener_exit_logical_expression   (MyPhpParserListener *self, MyContextLogicalExpression *ctx);

void my_php_parser_listener_enter_print_expression  (MyPhpParserListener *self, MyContextPrintExpression *ctx);
void my_php_parser_listener_exit_print_expression   (MyPhpParserListener *self, MyContextPrintExpression *ctx);

void my_php_parser_listener_enter_assignment_expression  (MyPhpParserListener *self, MyContextAssignmentExpression *ctx);
void my_php_parser_listener_exit_assignment_expression   (MyPhpParserListener *self, MyContextAssignmentExpression *ctx);

void my_php_parser_listener_enter_postfix_inc_dec_expression  (MyPhpParserListener *self, MyContextPostfixIncDecExpression *ctx);
void my_php_parser_listener_exit_postfix_inc_dec_expression   (MyPhpParserListener *self, MyContextPostfixIncDecExpression *ctx);

void my_php_parser_listener_enter_cast_expression  (MyPhpParserListener *self, MyContextCastExpression *ctx);
void my_php_parser_listener_exit_cast_expression   (MyPhpParserListener *self, MyContextCastExpression *ctx);

void my_php_parser_listener_enter_instance_of_expression  (MyPhpParserListener *self, MyContextInstanceOfExpression *ctx);
void my_php_parser_listener_exit_instance_of_expression   (MyPhpParserListener *self, MyContextInstanceOfExpression *ctx);

void my_php_parser_listener_enter_lambda_function_expression  (MyPhpParserListener *self, MyContextLambdaFunctionExpression *ctx);
void my_php_parser_listener_exit_lambda_function_expression   (MyPhpParserListener *self, MyContextLambdaFunctionExpression *ctx);

void my_php_parser_listener_enter_bitwise_expression  (MyPhpParserListener *self, MyContextBitwiseExpression *ctx);
void my_php_parser_listener_exit_bitwise_expression   (MyPhpParserListener *self, MyContextBitwiseExpression *ctx);

void my_php_parser_listener_enter_clone_expression  (MyPhpParserListener *self, MyContextCloneExpression *ctx);
void my_php_parser_listener_exit_clone_expression   (MyPhpParserListener *self, MyContextCloneExpression *ctx);

void my_php_parser_listener_enter_new_expr  (MyPhpParserListener *self, MyContextNewExpr *ctx);
void my_php_parser_listener_exit_new_expr   (MyPhpParserListener *self, MyContextNewExpr *ctx);

void my_php_parser_listener_enter_assignment_operator  (MyPhpParserListener *self, MyContextAssignmentOperator *ctx);
void my_php_parser_listener_exit_assignment_operator   (MyPhpParserListener *self, MyContextAssignmentOperator *ctx);

void my_php_parser_listener_enter_yield_expression  (MyPhpParserListener *self, MyContextYieldExpression *ctx);
void my_php_parser_listener_exit_yield_expression   (MyPhpParserListener *self, MyContextYieldExpression *ctx);

void my_php_parser_listener_enter_array_item_list  (MyPhpParserListener *self, MyContextArrayItemList *ctx);
void my_php_parser_listener_exit_array_item_list   (MyPhpParserListener *self, MyContextArrayItemList *ctx);

void my_php_parser_listener_enter_array_item  (MyPhpParserListener *self, MyContextArrayItem *ctx);
void my_php_parser_listener_exit_array_item   (MyPhpParserListener *self, MyContextArrayItem *ctx);

void my_php_parser_listener_enter_lambda_function_use_vars  (MyPhpParserListener *self, MyContextLambdaFunctionUseVars *ctx);
void my_php_parser_listener_exit_lambda_function_use_vars   (MyPhpParserListener *self, MyContextLambdaFunctionUseVars *ctx);

void my_php_parser_listener_enter_lambda_function_use_var  (MyPhpParserListener *self, MyContextLambdaFunctionUseVar *ctx);
void my_php_parser_listener_exit_lambda_function_use_var   (MyPhpParserListener *self, MyContextLambdaFunctionUseVar *ctx);

void my_php_parser_listener_enter_qualified_static_type_ref  (MyPhpParserListener *self, MyContextQualifiedStaticTypeRef *ctx);
void my_php_parser_listener_exit_qualified_static_type_ref   (MyPhpParserListener *self, MyContextQualifiedStaticTypeRef *ctx);

void my_php_parser_listener_enter_type_ref  (MyPhpParserListener *self, MyContextTypeRef *ctx);
void my_php_parser_listener_exit_type_ref   (MyPhpParserListener *self, MyContextTypeRef *ctx);

void my_php_parser_listener_enter_indirect_type_ref  (MyPhpParserListener *self, MyContextIndirectTypeRef *ctx);
void my_php_parser_listener_exit_indirect_type_ref   (MyPhpParserListener *self, MyContextIndirectTypeRef *ctx);

void my_php_parser_listener_enter_qualified_namespace_name  (MyPhpParserListener *self, MyContextQualifiedNamespaceName *ctx);
void my_php_parser_listener_exit_qualified_namespace_name   (MyPhpParserListener *self, MyContextQualifiedNamespaceName *ctx);

void my_php_parser_listener_enter_namespace_name_list  (MyPhpParserListener *self, MyContextNamespaceNameList *ctx);
void my_php_parser_listener_exit_namespace_name_list   (MyPhpParserListener *self, MyContextNamespaceNameList *ctx);

void my_php_parser_listener_enter_qualified_namespace_name_list  (MyPhpParserListener *self, MyContextQualifiedNamespaceNameList *ctx);
void my_php_parser_listener_exit_qualified_namespace_name_list   (MyPhpParserListener *self, MyContextQualifiedNamespaceNameList *ctx);

void my_php_parser_listener_enter_arguments  (MyPhpParserListener *self, MyContextArguments *ctx);
void my_php_parser_listener_exit_arguments   (MyPhpParserListener *self, MyContextArguments *ctx);

void my_php_parser_listener_enter_actual_argument  (MyPhpParserListener *self, MyContextActualArgument *ctx);
void my_php_parser_listener_exit_actual_argument   (MyPhpParserListener *self, MyContextActualArgument *ctx);

void my_php_parser_listener_enter_constant_inititalizer  (MyPhpParserListener *self, MyContextConstantInititalizer *ctx);
void my_php_parser_listener_exit_constant_inititalizer   (MyPhpParserListener *self, MyContextConstantInititalizer *ctx);

void my_php_parser_listener_enter_constant_array_item_list  (MyPhpParserListener *self, MyContextConstantArrayItemList *ctx);
void my_php_parser_listener_exit_constant_array_item_list   (MyPhpParserListener *self, MyContextConstantArrayItemList *ctx);

void my_php_parser_listener_enter_constant_array_item  (MyPhpParserListener *self, MyContextConstantArrayItem *ctx);
void my_php_parser_listener_exit_constant_array_item   (MyPhpParserListener *self, MyContextConstantArrayItem *ctx);

void my_php_parser_listener_enter_constant  (MyPhpParserListener *self, MyContextConstant *ctx);
void my_php_parser_listener_exit_constant   (MyPhpParserListener *self, MyContextConstant *ctx);

void my_php_parser_listener_enter_literal_constant  (MyPhpParserListener *self, MyContextLiteralConstant *ctx);
void my_php_parser_listener_exit_literal_constant   (MyPhpParserListener *self, MyContextLiteralConstant *ctx);

void my_php_parser_listener_enter_numeric_constant  (MyPhpParserListener *self, MyContextNumericConstant *ctx);
void my_php_parser_listener_exit_numeric_constant   (MyPhpParserListener *self, MyContextNumericConstant *ctx);

void my_php_parser_listener_enter_class_constant  (MyPhpParserListener *self, MyContextClassConstant *ctx);
void my_php_parser_listener_exit_class_constant   (MyPhpParserListener *self, MyContextClassConstant *ctx);

void my_php_parser_listener_enter_string_constant  (MyPhpParserListener *self, MyContextStringConstant *ctx);
void my_php_parser_listener_exit_string_constant   (MyPhpParserListener *self, MyContextStringConstant *ctx);

void my_php_parser_listener_enter_string  (MyPhpParserListener *self, MyContextString *ctx);
void my_php_parser_listener_exit_string   (MyPhpParserListener *self, MyContextString *ctx);

void my_php_parser_listener_enter_interpolated_string_part  (MyPhpParserListener *self, MyContextInterpolatedStringPart *ctx);
void my_php_parser_listener_exit_interpolated_string_part   (MyPhpParserListener *self, MyContextInterpolatedStringPart *ctx);

void my_php_parser_listener_enter_chain_list  (MyPhpParserListener *self, MyContextChainList *ctx);
void my_php_parser_listener_exit_chain_list   (MyPhpParserListener *self, MyContextChainList *ctx);

void my_php_parser_listener_enter_chain  (MyPhpParserListener *self, MyContextChain *ctx);
void my_php_parser_listener_exit_chain   (MyPhpParserListener *self, MyContextChain *ctx);

void my_php_parser_listener_enter_member_access  (MyPhpParserListener *self, MyContextMemberAccess *ctx);
void my_php_parser_listener_exit_member_access   (MyPhpParserListener *self, MyContextMemberAccess *ctx);

void my_php_parser_listener_enter_function_call  (MyPhpParserListener *self, MyContextFunctionCall *ctx);
void my_php_parser_listener_exit_function_call   (MyPhpParserListener *self, MyContextFunctionCall *ctx);

void my_php_parser_listener_enter_function_call_name  (MyPhpParserListener *self, MyContextFunctionCallName *ctx);
void my_php_parser_listener_exit_function_call_name   (MyPhpParserListener *self, MyContextFunctionCallName *ctx);

void my_php_parser_listener_enter_actual_arguments  (MyPhpParserListener *self, MyContextActualArguments *ctx);
void my_php_parser_listener_exit_actual_arguments   (MyPhpParserListener *self, MyContextActualArguments *ctx);

void my_php_parser_listener_enter_chain_base  (MyPhpParserListener *self, MyContextChainBase *ctx);
void my_php_parser_listener_exit_chain_base   (MyPhpParserListener *self, MyContextChainBase *ctx);

void my_php_parser_listener_enter_keyed_field_name  (MyPhpParserListener *self, MyContextKeyedFieldName *ctx);
void my_php_parser_listener_exit_keyed_field_name   (MyPhpParserListener *self, MyContextKeyedFieldName *ctx);

void my_php_parser_listener_enter_keyed_simple_field_name  (MyPhpParserListener *self, MyContextKeyedSimpleFieldName *ctx);
void my_php_parser_listener_exit_keyed_simple_field_name   (MyPhpParserListener *self, MyContextKeyedSimpleFieldName *ctx);

void my_php_parser_listener_enter_keyed_variable  (MyPhpParserListener *self, MyContextKeyedVariable *ctx);
void my_php_parser_listener_exit_keyed_variable   (MyPhpParserListener *self, MyContextKeyedVariable *ctx);

void my_php_parser_listener_enter_square_curly_expression  (MyPhpParserListener *self, MyContextSquareCurlyExpression *ctx);
void my_php_parser_listener_exit_square_curly_expression   (MyPhpParserListener *self, MyContextSquareCurlyExpression *ctx);

void my_php_parser_listener_enter_assignment_list  (MyPhpParserListener *self, MyContextAssignmentList *ctx);
void my_php_parser_listener_exit_assignment_list   (MyPhpParserListener *self, MyContextAssignmentList *ctx);

void my_php_parser_listener_enter_assignment_list_element  (MyPhpParserListener *self, MyContextAssignmentListElement *ctx);
void my_php_parser_listener_exit_assignment_list_element   (MyPhpParserListener *self, MyContextAssignmentListElement *ctx);

void my_php_parser_listener_enter_modifier  (MyPhpParserListener *self, MyContextModifier *ctx);
void my_php_parser_listener_exit_modifier   (MyPhpParserListener *self, MyContextModifier *ctx);

void my_php_parser_listener_enter_identifier  (MyPhpParserListener *self, MyContextIdentifier *ctx);
void my_php_parser_listener_exit_identifier   (MyPhpParserListener *self, MyContextIdentifier *ctx);

void my_php_parser_listener_enter_member_modifier  (MyPhpParserListener *self, MyContextMemberModifier *ctx);
void my_php_parser_listener_exit_member_modifier   (MyPhpParserListener *self, MyContextMemberModifier *ctx);

void my_php_parser_listener_enter_magic_constant  (MyPhpParserListener *self, MyContextMagicConstant *ctx);
void my_php_parser_listener_exit_magic_constant   (MyPhpParserListener *self, MyContextMagicConstant *ctx);

void my_php_parser_listener_enter_magic_method  (MyPhpParserListener *self, MyContextMagicMethod *ctx);
void my_php_parser_listener_exit_magic_method   (MyPhpParserListener *self, MyContextMagicMethod *ctx);

void my_php_parser_listener_enter_primitive_type  (MyPhpParserListener *self, MyContextPrimitiveType *ctx);
void my_php_parser_listener_exit_primitive_type   (MyPhpParserListener *self, MyContextPrimitiveType *ctx);

void my_php_parser_listener_enter_cast_operation  (MyPhpParserListener *self, MyContextCastOperation *ctx);
void my_php_parser_listener_exit_cast_operation   (MyPhpParserListener *self, MyContextCastOperation *ctx);



G_END_DECLS

#endif /* __MY_PHP_PARSER_LISTENER_H__ */
