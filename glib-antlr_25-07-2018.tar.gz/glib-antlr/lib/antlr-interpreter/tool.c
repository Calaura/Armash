/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * tool.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <antlr-runtime/runtime.h>

#include "types.h"
#include "parse/ANTLRParser.h"
#include "parse/ANTLRLexer.h"
#include "tool-parser.h"
#include "tool-lexer.h"

#include "tool.h"



static void gap_tool_class_init(GapToolClass *klass);
static void gap_tool_init(GapTool *gobject);

G_DEFINE_TYPE (GapTool, gap_tool, G_TYPE_OBJECT)

static void
gap_tool_class_init(GapToolClass *klass)
{
    //GObjectClass *gobject_class;

    //gobject_class = (GObjectClass *) klass;

    //gap_tool_parent_class = g_type_class_peek_parent (klass);
}

static void
gap_tool_init (GapTool *object)
{
}

GapTool*
gap_tool_new (void)
{
    return g_object_new (GAP_TYPE_TOOL, NULL);
}

void
gap_tool_parse(GapTool *self, AntlrCharStream *stream)
{
//    GapGrammarASTAdaptor *adaptor = gap_grammar_ast_adaptor_new(in);
    GapToolLexer *lexer = gap_tool_lexer_new_from_char_stream (stream, self);
    AntlrCommonTokenStream *tokens = antlr_common_token_stream_new_with_token_source(ANTLR_TOKEN_SOURCE(lexer));
    GAP_LEXER(lexer)->tokens = tokens;
    GapToolParser *p = gap_tool_parser_new_from_token_stream(ANTLR_TOKEN_STREAM(tokens), self);
//    gap_tool_parser_set_tree_adaptor(p, adaptor);

    //GapToolParser *p = gap_tool_parser(tokens, this);
    //gap_tool_parser_set_tree_adaptor(adaptor, p);
    //GapToolParser *p = gap_tool_parser(tokens, this);
    ///GapParserRuleReturnScope *r = gap_grammar_spec(p);

}


#if 0

public GrammarRootAST parse(String fileName, CharStream in) {
    try {
        GrammarASTAdaptor adaptor = new GrammarASTAdaptor(in);
        ToolANTLRLexer lexer = new ToolANTLRLexer(in, this);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        lexer.tokens = tokens;
        ToolANTLRParser p = new ToolANTLRParser(tokens, this);
        p.setTreeAdaptor(adaptor);
        try {
            ParserRuleReturnScope r = p.grammarSpec();
            GrammarAST root = (GrammarAST)r.getTree();
            if ( root instanceof GrammarRootAST) {
                ((GrammarRootAST)root).hasErrors = lexer.getNumberOfSyntaxErrors()>0 || p.getNumberOfSyntaxErrors()>0;
                assert ((GrammarRootAST)root).tokenStream == tokens;
                if ( grammarOptions!=null ) {
                    ((GrammarRootAST)root).cmdLineOptions = grammarOptions;
                }
                return ((GrammarRootAST)root);
            }
        }
        catch (v3TreeGrammarException e) {
            errMgr.grammarError(ErrorType.V3_TREE_GRAMMAR, fileName, e.location);
        }
        return null;
    }
    catch (RecognitionException re) {
        // TODO: do we gen errors now?
        ErrorManager.internalError("can't generate this message at moment; antlr recovers");
    }
    return null;
}

#endif
