/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * tool-lexer.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include <antlr-runtime/runtime.h>

#include "types.h"
#include "parse/ANTLRLexer.h"
#include "tool.h"

#include "tool-lexer.h"


static void gap_tool_lexer_class_init(GapToolLexerClass *klass);
static void gap_tool_lexer_init(GapToolLexer *gobject);

G_DEFINE_TYPE (GapToolLexer, gap_tool_lexer, GAP_TYPE_LEXER)

static void
gap_tool_lexer_class_init(GapToolLexerClass *klass)
{
//	GapLexerClass *gaplexer_class;
//	gaplexer_class = (GapLexerClass *) klass;
//	gap_tool_lexer_parent_class = g_type_class_peek_parent (klass);
}

static void
gap_tool_lexer_init (GapToolLexer *object)
{
}

GapToolLexer *
gap_tool_lexer_new (void)
{
    GapToolLexer *lexer = g_object_new (GAP_TYPE_TOOL_LEXER, NULL);
    return lexer;
}

GapToolLexer *
gap_tool_lexer_new_from_char_stream (AntlrCharStream *stream, GapTool *tool)
{
    GapToolLexer *lexer = (GapToolLexer*)antlr_lexer_super_with_char_stream(GAP_TYPE_TOOL_LEXER, stream);
    lexer->tool = tool;

    return lexer;
}

