/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * common-tree.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __GAP_COMMON_TREE_H__
#define __GAP_COMMON_TREE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define GAP_COMMON_TREE_INVALID_NODE    gap_common_tree_get_invalid_node()

#define GAP_TYPE_COMMON_TREE            (gap_common_tree_get_type())
#define GAP_COMMON_TREE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAP_TYPE_COMMON_TREE, GapCommonTree))
#define GAP_COMMON_TREE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GAP_TYPE_COMMON_TREE, GapCommonTreeClass))
#define GAP_IS_COMMON_TREE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAP_TYPE_COMMON_TREE))
#define GAP_IS_COMMON_TREE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GAP_TYPE_COMMON_TREE))
#define GAP_COMMON_TREE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GAP_TYPE_COMMON_TREE, GapCommonTreeClass))

typedef struct _GapCommonTree GapCommonTree;
typedef struct _GapCommonTreeClass GapCommonTreeClass;

struct _GapCommonTree {
	GObject parent_instance;

    /*< protected >*/
    GList *children;

    /*< public >*/

};

struct _GapCommonTreeClass {
	GObjectClass parent_class;
};

GType gap_common_tree_get_type();
GapCommonTree *gap_common_tree_new();

GapCommonTree *gap_common_tree_get_invalid_node();
GapCommonTree *gap_common_tree_get_child(GapCommonTree*self, gint i);
gint             gap_common_tree_get_child_count(GapCommonTree*self);
GapCommonTree *gap_common_tree_get_parent(GapCommonTree*self);
void             gap_common_tree_set_parent(GapCommonTree *self, GapCommonTree *parent);
gboolean         gap_common_tree_has_ancestor(GapCommonTree *self, gint ttype);
GapCommonTree *gap_common_tree_get_ancestor(GapCommonTree *self, gint ttype);
GList*           gap_common_tree_get_ancestors(GapCommonTree *self);
gint             gap_common_tree_get_child_index(GapCommonTree *self);
void             gap_common_tree_set_child_index(GapCommonTree *self, gint index);
void             gap_common_tree_add_child(GapCommonTree *self, GapCommonTree *child);
void             gap_common_tree_set_child(GapCommonTree *self, gint i, GapCommonTree *child);
GObject*         gap_common_tree_delete_child(GapCommonTree *self, gint i);
void             gap_common_tree_replace_children(GapCommonTree *self, gint start_child_index, gint stop_child_index, GapCommonTree *tree);
gboolean         gap_common_tree_is_nil(GapCommonTree *self);
gint             gap_common_tree_get_token_start_index(GapCommonTree *self);
void             gap_common_tree_set_token_start_index(GapCommonTree *self, gint index);
void             gap_common_tree_set_token_stop_index(GapCommonTree *self, gint index);
GapCommonTree *gap_common_tree_dup_node(GapCommonTree *self);
gint             gap_common_tree_get_token_type(GapCommonTree *self);
GString*         gap_common_tree_get_text(GapCommonTree *self);
gint             gap_common_tree_get_line(GapCommonTree *self);
gint             gap_common_tree_get_char_position_in_line(GapCommonTree *self);

GList*           gap_common_tree_get_children(GapCommonTree*self);

G_END_DECLS

#endif /* __GAP_COMMON_TREE_H__ */

