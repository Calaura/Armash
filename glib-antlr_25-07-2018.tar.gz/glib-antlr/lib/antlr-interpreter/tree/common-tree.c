/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * common-tree.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#include "common-tree.h"

static GapCommonTree *gap_common_tree_invalid_node = NULL;


static void gap_common_tree_class_init(GapCommonTreeClass *klass);
static void gap_common_tree_init(GapCommonTree *gobject);

G_DEFINE_TYPE (GapCommonTree, gap_common_tree, G_TYPE_OBJECT)

static void
gap_common_tree_class_gobject_finalize(GObject *object)
{
    //GapCommonTree *self = GAP_COMMON_TREE(object);
    if (gap_common_tree_invalid_node) {
        g_object_unref(gap_common_tree_invalid_node);
        gap_common_tree_invalid_node = NULL;
    }
}

static void
gap_common_tree_class_init(GapCommonTreeClass *klass)
{
    GObjectClass *gobject_class;
    gobject_class = (GObjectClass *) klass;

    gobject_class->finalize = gap_common_tree_class_gobject_finalize;
}

static void
gap_common_tree_init (GapCommonTree *self)
{
    self->children = NULL;

}

GapCommonTree *
gap_common_tree_new (void)
{
    return g_object_new (gap_common_tree_get_type (),
	                     NULL);
}

GapCommonTree*
gap_common_tree_get_invalid_node()
{
    if (gap_common_tree_invalid_node==NULL) {
        gap_common_tree_invalid_node = gap_common_tree_new ();
    }
    return gap_common_tree_invalid_node;
}



GapCommonTree*
gap_common_tree_get_child(GapCommonTree*self, gint i)
{
    return (GapCommonTree*)g_list_nth_data(self->children, i);
}

/**
 * gap_common_tree_get_children:
 * @self:
 *
 * Get the children internal List; note that if you directly mess with
 * the list, do so at your own risk.
 */
GList* gap_common_tree_get_children(GapCommonTree*self) {
    return self->children;
}

GapCommonTree*
gap_common_tree_get_first_child_with_type(GapCommonTree*self, gint type) {
    GList *list = NULL;
    GapCommonTree* tree = NULL;
    for(list=g_list_first(self->children); list; list=list->next) {
        tree = (GapCommonTree*)list->data;
        if (gap_common_tree_get_token_type(tree)==type) {
            return tree;
        }
    }
    return NULL;
}

gint
gap_common_tree_get_child_count(GapCommonTree*self)
{
    return g_list_length(self->children);
}

// Tree tracks parent and child index now > 3.0
GapCommonTree*
gap_common_tree_get_parent(GapCommonTree*self)
{
    return NULL;
}

void
gap_common_tree_set_parent(GapCommonTree *self, GapCommonTree *parent)
{

}


/**
 * gap_common_tree_has_ancestor:
 * @self:
 * @ttype:
 *
 * Is there is a node above with token type ttype?
 *
 */
gboolean
gap_common_tree_has_ancestor(GapCommonTree *self, gint ttype)
{
    return FALSE;
}

/**
 * gap_common_tree_get_ancestor:
 * @self:
 * @ttype:
 *
 * Walk upwards and get first ancestor with this token type.
 */
GapCommonTree *
gap_common_tree_get_ancestor(GapCommonTree *self, gint ttype)
{
    return NULL;
}

/**
 * gap_common_tree_get_ancestors:
 * @self: Some #GapCommonTree
 *
 * Return a list of all ancestors of this node.  The first node of
 *  list is the root and the last is the parent of this node.
 *
 * Returns: #GList of GapCommonTree
 */
GList*
gap_common_tree_get_ancestors(GapCommonTree *self)
{
    GList *ancestors = NULL;
    return ancestors;
}

/**
 * gap_common_tree_get_child_index:
 * @self:
 *
 * This node is what child index? 0..n-1
 *
 * Returns
 */
gint
gap_common_tree_get_child_index(GapCommonTree *self)
{
    return -1;
}

void
gap_common_tree_set_child_index(GapCommonTree *self, gint index)
{

}

/**
 * gap_common_tree_freshen_parent_and_child_indexes:
 * @self:
 *
 * Set the parent and child index values for all children
 *
 */
void
gap_common_tree_freshen_parent_and_child_indexes(GapCommonTree *self)
{

}

/**
 * gap_common_tree_add_child:
 * @self:
 * @child:
 *
 * Add t as a child to this node.  If t is null, do nothing.  If t
 * is nil, add all children of t to this' children.
 *
 */
void
gap_common_tree_add_child(GapCommonTree *self, GapCommonTree *child)
{
    self->children = g_list_concat(self->children, child->children);
}

/**
 * gap_common_tree_set_child:
 * @self:
 * @i:
 * @child:
 *
 * Set ith child (0..n-1) to t; t must be non-null and non-nil node
 *
 */
void
gap_common_tree_set_child(GapCommonTree *self, gint i, GapCommonTree *child)
{

}

GObject*
gap_common_tree_delete_child(GapCommonTree *self, gint i)
{
    return NULL;
}

/**
 * gap_common_tree_replace_children:
 * @self:
 * @start_child_index:
 * @stop_child_index:
 * @tree:
 *
 * Delete children from start to stop and replace with t even if t is
 *  a list (nil-root tree).  num of children can increase or decrease.
 *  For huge child lists, inserting children can force walking rest of
 *  children to set their childindex; could be slow.
 */
void
gap_common_tree_replace_children(GapCommonTree *self, gint start_child_index, gint stop_child_index, GapCommonTree *tree)
{

}

/**
 * gap_common_tree_is_nil:
 * @self
 *
 * Indicates the node is a nil node but may still have children, meaning
 *  the tree is a flat list.
 */
gboolean
gap_common_tree_is_nil(GapCommonTree *self)
{
    return TRUE;
}

/**
 * gap_common_tree_get_token_start_index
 * @self
 *
 * What is the smallest token index (indexing from 0) for this node
 * and its children?
 */
gint
gap_common_tree_get_token_start_index(GapCommonTree *self)
{
    return -1;
}

void
gap_common_tree_set_token_start_index(GapCommonTree *self, gint index)
{

}

/**
 * gap_common_tree_get_token_stop_index:
 * @self:
 *
 * What is the largest token index (indexing from 0) for this node
 * and its children?
 */
gint
gap_common_tree_get_token_stop_index(GapCommonTree *self)
{
    return -1;
}

void
gap_common_tree_set_token_stop_index(GapCommonTree *self, gint index)
{

}


GapCommonTree*
gap_common_tree_dup_node(GapCommonTree *self)
{
    GapCommonTree *node=NULL;
    return node;
}

/**
 * gap_common_tree_get_token_type:
 * @self
 *
 * Return a token type; needed for tree parsing
 *
 */
gint
gap_common_tree_get_token_type(GapCommonTree *self)
{
    return -1;
}

GString*
gap_common_tree_get_text(GapCommonTree *self)
{
    GString*text = NULL;
    return text;
}


/**
 * gap_common_tree_get_line:
 * @self:
 *
 * In case we don't have a token payload, what is the line for errors?
 */
gint
gap_common_tree_get_line(GapCommonTree *self)
{
    return -1;
}

gint
gap_common_tree_get_char_position_in_line(GapCommonTree *self)
{
    return -1;
}

