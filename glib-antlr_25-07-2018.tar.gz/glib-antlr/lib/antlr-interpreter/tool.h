/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * tool.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __GAP_TOOL_H__
#define __GAP_TOOL_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define GAP_TYPE_TOOL            (gap_tool_get_type())
#define GAP_TOOL(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAP_TYPE_TOOL, GapTool))
#define GAP_TOOL_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GAP_TYPE_TOOL, GapToolClass))
#define GAP_IS_TOOL(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAP_TYPE_TOOL))
#define GAP_IS_TOOL_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GAP_TYPE_TOOL))
#define GAP_TOOL_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GAP_TYPE_TOOL, GapToolClass))

typedef struct _GapToolClass GapToolClass;

struct _GapTool {
	GObject parent_instance;
};

struct _GapToolClass {
	GObjectClass parent_class;
};

GType gap_tool_get_type();
GapTool *gap_tool_new();
void gap_tool_parse(GapTool *self, AntlrCharStream *stream);


G_END_DECLS

#endif /* __GAP_TOOL_H__ */

