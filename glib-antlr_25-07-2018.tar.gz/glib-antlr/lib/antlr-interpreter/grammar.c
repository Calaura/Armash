/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * grammar.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <glib-object.h>

#include "antlr-runtime/types.h"
#include "antlr-runtime/misc/object.h"
#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/char-stream.h"
#include "antlr-runtime/input-stream.h"
#include "antlr-runtime/file-stream.h"

#include "types.h"
#include "tool.h"

#include "grammar.h"


static void gap_grammar_class_init(GapGrammarClass *klass);
static void gap_grammar_init(GapGrammar *gobject);

G_DEFINE_TYPE (GapGrammar, gap_grammar, G_TYPE_OBJECT)

static void
gap_grammar_class_init(GapGrammarClass *klass)
{
	GObjectClass *gobject_class;
    //gobject_class = (GObjectClass *) klass;
}

static void
gap_grammar_init (GapGrammar *object)
{
}


/** For testing; builds trees, does sem anal */
#if 0
public Grammar(String fileName, String grammarText, Grammar tokenVocabSource, ANTLRToolListener listener)
    throws org.antlr.runtime.RecognitionException
{

    this.text = grammarText;
    this.fileName = fileName;
    this.tool = new Tool();
    ANTLRToolListener hush = new ANTLRToolListener() {
        @Override
        public void info(String msg) { }
        @Override
        public void error(ANTLRMessage msg) { }
        @Override
        public void warning(ANTLRMessage msg) { }
    };
    tool.addListener(hush); // we want to hush errors/warnings
    this.tool.addListener(listener);
    org.antlr.runtime.ANTLRStringStream in = new org.antlr.runtime.ANTLRStringStream(grammarText);
    in.name = fileName;

    this.ast = tool.parse(fileName, in);
    if ( ast==null ) {
        throw new UnsupportedOperationException();
    }

    if (ast.tokenStream == null) {
        throw new IllegalStateException("expected ast to have a token stream");
    }

    this.tokenStream = ast.tokenStream;
    this.originalTokenStream = this.tokenStream;

    // ensure each node has pointer to surrounding grammar
    final Grammar thiz = this;
    org.antlr.runtime.tree.TreeVisitor v = new org.antlr.runtime.tree.TreeVisitor(new GrammarASTAdaptor());
    v.visit(ast, new org.antlr.runtime.tree.TreeVisitorAction() {
        @Override
        public Object pre(Object t) { ((GrammarAST)t).g = thiz; return t; }
        @Override
        public Object post(Object t) { return t; }
    });
    initTokenSymbolTables();

    if (tokenVocabSource != null) {
        importVocab(tokenVocabSource);
    }

    tool.process(this, false);
}
#endif
GapGrammar*
gap_grammar_super (GType type)
{
    GapGrammar *grammar = g_object_new (type, NULL);

    return grammar;
}

GapGrammar*
gap_grammar_new (void)
{
    return gap_grammar_super(GAP_TYPE_GRAMMAR);
}

GapGrammar*
gap_grammar_new_from_string(const gchar *grammar_text)
{
    GapGrammar *grammar = gap_grammar_super(GAP_TYPE_GRAMMAR);
    AntlrInputStream *in= antlr_input_stream_new_from_string(grammar_text);
    //GapStringStream in = new org.antlr.runtime.ANTLRStringStream(grammarText);
    GapTool *tool = gap_tool_new();
    //this.ast = tool.parse(fileName, in);
    gap_tool_parse(tool, ANTLR_CHAR_STREAM(in));

    return grammar;
}

GapGrammar*
gap_grammar_new_from_filename(const gchar *filename)
{
    GError *error = NULL;
    GapGrammar *grammar = gap_grammar_super(GAP_TYPE_GRAMMAR);
    AntlrFileStream *in= antlr_file_stream_new_from_filename_encoding(filename, NULL, &error);
    //GapStringStream in = new org.antlr.runtime.ANTLRStringStream(grammarText);
    //ast = tool.parse(fileName, in);
    GapTool *tool = gap_tool_new();
    gap_tool_parse(tool, ANTLR_CHAR_STREAM(in));


    return grammar;
}
