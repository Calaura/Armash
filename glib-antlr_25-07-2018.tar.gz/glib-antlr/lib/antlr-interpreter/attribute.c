/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * attribute.c
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/**
 * SECTION:attribute
 * @title: GapAttribute
 * @short_description: Argument list
 * @stability: Stable
 *
 *
 * Track the names of attributes defined in arg lists, return values,
 * scope blocks etc...
 *
 */

#include <antlr-runtime/runtime.h>

#include "token.h"
#include "attribute.h"


static void gap_attribute_class_init(GapAttributeClass *klass);
static void gap_attribute_init(GapAttribute *gobject);

G_DEFINE_TYPE (GapAttribute, gap_attribute, G_TYPE_OBJECT)

static void
gap_attribute_class_init(GapAttributeClass *klass)
{
	GObjectClass *gobject_class;
    gobject_class = (GObjectClass *) klass;

    //gobject_class->dispose = gap_attribute_class_gobject_dispose;
    //gobject_class->finalize = gap_attribute_class_gobject_finalize;
    //gobject_class->get_property = gap_attribute_class_gobject_get_property;
    //gobject_class->set_property = gap_attribute_class_gobject_set_property;
}

static void
gap_attribute_init (GapAttribute *object)
{
}

GapAttribute*
gap_attribute_super (GType type)
{
    return g_object_new (type, NULL);
}

GapAttribute *
gap_attribute_new (void)
{
    return g_object_new (gap_attribute_get_type (),
                         NULL);
}

GapAttribute*
gap_attribute_new_with_name (GString *name)
{
    GapAttribute *attribute= g_object_new (GAP_TYPE_ATTRIBUTE, NULL);
    attribute->name = name;
    return attribute;
}

GapAttribute *
gap_attribute_new_with_name_and_declaration (GString *name, GString *declaration)
{
    GapAttribute *attribute= g_object_new (GAP_TYPE_ATTRIBUTE, NULL);
    attribute->name = name;
    attribute->decl = declaration;
    return attribute;
}
