/* -*- Mode: C; indent-tabs-mode: t; c-basic-offset: 4; tab-width: 4 -*- */
/*
 * attribute.h
 * Copyright (C) 2014 Sergio DE VASCONCELOS <schaublore@gmail.com>
 *
 * This program is free software: you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program.  If not, see <http://www.gnu.org/licenses/>.
 */


#ifndef __GAP_ATTRIBUTE_H__
#define __GAP_ATTRIBUTE_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define GAP_TYPE_ATTRIBUTE            (gap_attribute_get_type())
#define GAP_ATTRIBUTE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAP_TYPE_ATTRIBUTE, GapAttribute))
#define GAP_ATTRIBUTE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GAP_TYPE_ATTRIBUTE, GapAttributeClass))
#define GAP_IS_ATTRIBUTE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAP_TYPE_ATTRIBUTE))
#define GAP_IS_ATTRIBUTE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GAP_TYPE_ATTRIBUTE))
#define GAP_ATTRIBUTE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GAP_TYPE_ATTRIBUTE, GapAttributeClass))

typedef struct _GapAttribute      GapAttribute;
typedef struct _GapAttributeClass GapAttributeClass;

/**
 * GapAttribute:
 * @decl: The entire declaration such as "String foo" or "x:int"
 * @type: The type; might be empty such as for Python which has no static typing
 * @name: The name of the attribute "foo"
 * @token: A #GapToken giving the position of the name of this attribute in the grammar.
 * @init_value: The optional attribute initialization expression
 *
 * dict Who contains us?
 *
 */
struct _GapAttribute {
	GObject parent_instance;
    GString *decl;
    GString *type;
    GString *name;
    GapToken *token;
    GString *init_value;
    //GapAttributeDict *dict;
};


struct _GapAttributeClass {
	GObjectClass parent_class;
};

GType gap_attribute_get_type();

GapAttribute *gap_attribute_new ();
GapAttribute *gap_attribute_new_with_name (GString *name);
GapAttribute *gap_attribute_new_with_name_and_declaration (GString *name, GString *declaration);

G_END_DECLS

#endif /* __GAP_ATTRIBUTE_H__ */
