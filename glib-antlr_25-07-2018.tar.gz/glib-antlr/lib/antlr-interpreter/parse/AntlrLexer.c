
// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/antlr/AntlrLexer.g by ANTLR 4.6





#include <glib-object.h>

#include "antlr/types.h"
//#include "antlr/char-stream.h"

#include "antlr/misc/bit-set.h"
#include "antlr/misc/int-iset.h"
#include "antlr/misc/interval.h"
#include "antlr/vocabulary.h"
#include "antlr/vocabulary-impl.h"
#include "antlr/misc/interval-set.h"
#include "antlr/misc/integer-list.h"
#include "antlr/misc/integer-stack.h"
#include "antlr/atn/transition.h"
#include "antlr/atn/lexer-action.h"
#include "antlr/atn/atn-state.h"
#include "antlr/atn/semantic-context.h"
#include "antlr/atn/config.h"
#include "antlr/atn/config-set.h"
#include "antlr/atn/rule-stop-state.h"
#include "antlr/atn/rule-start-state.h"
#include "antlr/atn/atn.h"
#include "antlr/atn/prediction-context.h"
#include "antlr/atn/prediction-context-cache.h"
#include "antlr/atn/atn-simulator.h"
#include "antlr/atn/lexer-action-executor.h"
#include "antlr/atn/decision-state.h"
#include "antlr/atn/atn-deserialization-options.h"
#include "antlr/atn/atn-deserializer.h"
#include "antlr/atn/lexer-atn-simulator.h"

#include "antlr/dfa/dfa-state.h"
#include "antlr/dfa/dfa.h"

#include "antlr/int-stream.h"
#include "antlr/recognizer.h"
#include "antlr/int-stream.h"
#include "antlr/token-factory.h"
#include "antlr/lexer.h"

#include "AntlrLexer.h"


// We own the ATN which in turn owns the ATN states.
static AntlrATN *antlr_lexer_atn = NULL;// AntlrATN * || GArray *
static GArray   *antlr_lexer_decision_to_dfa = NULL;// of AntlrDFA*
static AntlrPredictionContextCache *antlr_lexer_shared_context_cache = NULL;
static AntlrPredictionContextCache*
antlr_lexer_get_shared_context_cache ()
{
    if (!antlr_lexer_shared_context_cache) {
        antlr_lexer_shared_context_cache = antlr_prediction_context_cache_new();
    }
    return antlr_lexer_shared_context_cache;
}

static guint antlr_lexer_serialized_atn[] = {
  0x03, 0x0430, 0xD6D1, 0x8206, 0xAD2D, 0x4417, 0xAEF1, 0x8D80, 0xAADD, 0x02, 0x07, 0x07, 0x08, 0x01, 0x04, 0x02, 0x09, 0x02, 0x03, 0x02, 0x03, 0x02, 0x02, 0x02, 0x03, 0x03, 0x02, 0x03, 0x02, 0x02, 0x05, 0x03, 0x05, 0x03, 0x02, 0x02, 0x02, 0x05, 0x06, 0x03, 0x02, 0x02, 0x02, 0x06, 0x04, 0x03, 0x02, 0x02, 0x02, 0x03, 0x02, 0x02
};

static AntlrATN*
antlr_lexer_get_atn ()
{
    if (!antlr_lexer_atn) {
        AntlrATNDeserializer *deserializer = antlr_atn_deserializer_new_full(NULL);
        antlr_lexer_atn = antlr_atn_deserializer_deserialize(deserializer, antlr_lexer_serialized_atn, G_N_ELEMENTS(antlr_lexer_serialized_atn));
    }
    return antlr_lexer_atn;
}

static GArray*
antlr_lexer_get_decision_to_dfa (ANTLRLexer *lexer)
{
    if (!antlr_lexer_decision_to_dfa) {
        AntlrATN *atn = antlr_lexer_get_atn();
        gint size = antlr_atn_get_number_of_decisions(atn);
        antlr_lexer_decision_to_dfa = g_array_sized_new(FALSE, FALSE, sizeof(AntlrDFA *), size);
        int i;
        for (i = 0; i < size; i++) {
            AntlrDFA *v = antlr_dfa_new_with_decision_state_and_decision(antlr_atn_get_decision_state(atn, i), i);
            g_array_insert_val(antlr_lexer_decision_to_dfa, i, v);
        }
    }
    return antlr_lexer_decision_to_dfa;
}



static gchar* antlr_lexer__RULE_NAMES[] = {
    "DOC_COMMENT"
};

static gchar* antlr_lexer__MODE_NAMES[] = {
    "DEFAULT_MODE"
};

static gchar* antlr_lexer__LITERAL_NAMES[] = {
};

static gchar* antlr_lexer__SYMBOLIC_NAMES[] = {
    "", "SEMPRED", "TOKEN_REF", "RULE_REF", "LEXER_CHAR_SET", "ARG_ACTION"
};



/* private functions */

static GArray*
antlr_lexer_symbolic_names_to_array () {
    GArray *array = g_array_new(FALSE, FALSE, sizeof(GString*));

    int i;
    for (i=0; i<G_N_ELEMENTS(antlr_lexer__SYMBOLIC_NAMES); i++) {
        GString * s = g_string_new( antlr_lexer__SYMBOLIC_NAMES[i] );
        g_array_append_val(array, s);
    }

    return array;
}

static GArray*
antlr_lexer_literal_names_to_array () {
    GArray *array = g_array_new(FALSE, FALSE, sizeof(GString*));

    int i;
    for (i=0; i<G_N_ELEMENTS(antlr_lexer__LITERAL_NAMES); i++) {
        GString * s = g_string_new( antlr_lexer__LITERAL_NAMES[i] );
        g_array_append_val(array, s);
    }

    return array;
}


/* virtual AntlrRecognizer */

static AntlrVocabulary *antlr_lexer_vocabulary = NULL;

static AntlrVocabulary*
antlr_lexer_get_vocabulary(ANTLRLexer *lexer)
{
    if (!antlr_lexer_vocabulary) {
        antlr_lexer_vocabulary = antlr_vocabulary_new(antlr_lexer_literal_names_to_array (), antlr_lexer_symbolic_names_to_array (), NULL);
    }
    return antlr_lexer_vocabulary;
}

static GArray* antlr_lexer_token_names = NULL;

static GArray*
antlr_lexer_class_recognizer_get_token_names(AntlrRecognizer *recognizer)
{
    if (!antlr_lexer_token_names) {
        AntlrVocabulary *vocabulary = antlr_lexer_get_vocabulary(ANTLR_LEXER(recognizer));
        AntlrIVocabulary *ivocabulary = ANTLR_IVOCABULARY(vocabulary);
        gint length = G_N_ELEMENTS(antlr_lexer__SYMBOLIC_NAMES);
        antlr_lexer_token_names = g_array_sized_new(FALSE, FALSE, sizeof(GString*), length);
        gint i;
        for (i=0; i<length; i++) {
            gchar *str = antlr_ivocabulary_get_literal_name(ivocabulary, i);
            if (str == NULL) {
                str = antlr_ivocabulary_get_symbolic_name(ivocabulary, i);
            }

            if (str == NULL) {
                str = g_strdup("<INVALID>");
            }
            GString *s = g_string_new(str);
            g_array_append_val(antlr_lexer_token_names, s);
        }
    }
    return antlr_lexer_token_names;
}

static GArray* antlr_lexer_rule_names = NULL;

static GArray*
antlr_lexer_class_recognizer_get_rule_names(AntlrRecognizer *recognizer)
{
    if (!antlr_lexer_rule_names) {
        gint capacity = G_N_ELEMENTS(antlr_lexer__RULE_NAMES);
        GArray *antlr_lexer_rule_names = g_array_sized_new(FALSE, FALSE, sizeof(GString*), capacity);
        gint i;
        for (i=0; i<capacity; i++) {
            GString *s = g_string_new(antlr_lexer__RULE_NAMES[i]);
            g_array_append_val(antlr_lexer_rule_names, s);
        }
    }
    return antlr_lexer_rule_names;
}

/* virtual GObject */

static void antlr_lexer_class_init(ANTLRLexerClass *klass);
static void antlr_lexer_init(ANTLRLexer *gobject);

G_DEFINE_TYPE (ANTLRLexer, antlr_lexer, antlr_lexer_get_type())

static void
antlr_lexer_class_init(ANTLRLexerClass *klass)
{
	ANTLR_RECOGNIZER_CLASS(klass)->get_rule_names = antlr_lexer_class_recognizer_get_rule_names;
	ANTLR_RECOGNIZER_CLASS(klass)->get_token_names = antlr_lexer_class_recognizer_get_token_names;
}

static void
antlr_lexer_init (ANTLRLexer *object)
{
}

ANTLRLexer*
antlr_lexer_new (void)
{
	return g_object_new (antlr_lexer_get_type (),
	                     NULL);
}

ANTLRLexer*
antlr_lexer_new_with_char_stream (AntlrCharStream *char_stream)
{
    AntlrLexer *antlr_lexer = antlr_lexer_super_with_char_stream(ANTLR_TYPE_LEXER, char_stream);
    ANTLRLexer *lexer = ANTLR_LEXER(antlr_lexer);

    ANTLR_LEXER(lexer)->input = char_stream;

    //_interp = new LexerATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
    ANTLR_RECOGNIZER(lexer)->interp = (AntlrATNInterpreter*)
            antlr_lexer_atn_simulator_new_from_lexer(
                ANTLR_LEXER(lexer),
                antlr_lexer_get_atn(),
                antlr_lexer_get_decision_to_dfa(lexer),
                antlr_lexer_get_shared_context_cache()
             );

    return lexer;
}









