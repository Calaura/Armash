
// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/antlr/ANTLRParser.g by ANTLR 4.6


//#include "antlr4-runtime.h"




#ifndef __GAP_PARSER_H__
#define __GAP_PARSER_H__

#include <glib-object.h>

G_BEGIN_DECLS

typedef enum _GapParserTokens  GapParserTokens;
typedef enum _GapParserRules   GapParserRules;

enum _GapParserTokens {
    GAP_PARSER_TOKEN_SEMPRED = 1,
    GAP_PARSER_TOKEN_TOKEN_REF = 2,
    GAP_PARSER_TOKEN_RULE_REF = 3,
    GAP_PARSER_TOKEN_LEXER_CHAR_SET = 4,
    GAP_PARSER_TOKEN_ARG_ACTION = 5,
    GAP_PARSER_TOKEN_COMMENT = 6,
    GAP_PARSER_TOKEN_ID = 7
};

enum _GapParserRules {
    GAP_PARSER_RULE_ID = 0
};

#define GAP_PARSER_EOF ANTLR_TOKEN_EOF

#define GAP_TYPE_PARSER            (gap_parser_get_type())
#define GAP_PARSER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAP_TYPE_PARSER, GapParser))
#define GAP_PARSER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  GAP_TYPE_PARSER, GapParserClass))
#define GAP_IS_PARSER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAP_TYPE_PARSER))
#define GAP_IS_PARSER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  GAP_TYPE_PARSER))
#define GAP_PARSER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  GAP_TYPE_PARSER, GapParserClass))

typedef struct _GapParser      GapParser;
typedef struct _GapParserClass GapParserClass;

struct _GapParser {
    /*< private >*/
    AntlrParser parent_instance;

    GArray *rule_names;
};

struct _GapParserClass {
    /*< private >*/
    AntlrParserClass parent_class;
};

GType gap_parser_get_type(void) G_GNUC_CONST;
GapParser *gap_parser_new();
GapParser *gap_parser_new_with_token_stream (AntlrTokenStream *input);

void gap_parser_atn_free ();
void gap_parser_decision_to_dfa_free ();
void gap_parser_token_names_free();


typedef struct _GapContextId GapContextId; 

//----------------- IdContext ------------------------------------------------------------------

#define GAP_TYPE_CONTEXT_ID            (gap_context_id_get_type())
#define GAP_CONTEXT_ID(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAP_TYPE_CONTEXT_ID, GapContextId))
#define GAP_CONTEXT_ID_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  GAP_TYPE_CONTEXT_ID, GapContextIdClass))
#define GAP_IS_CONTEXT_ID(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAP_TYPE_CONTEXT_ID))
#define GAP_IS_CONTEXT_ID_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  GAP_TYPE_CONTEXT_ID))
#define GAP_CONTEXT_ID_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  GAP_TYPE_CONTEXT_ID, GapContextIdClass))


//typedef struct _GapContextId      GapContextId;
typedef struct _GapContextIdClass GapContextIdClass;

struct _GapContextId {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _GapContextIdClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType gap_context_id_get_type(void) G_GNUC_CONST;
GapContextId *gap_context_id_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTerminalNode *gap_context_id_token_get_rule_ref(GapContextId* self);
AntlrTerminalNode *gap_context_id_token_get_token_ref(GapContextId* self);


GapContextId* gap_parser_parse_id(GapParser* self, GError **error);



G_END_DECLS

#endif /* __GAP_PARSER_H__ */

