
// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/antlr/AntlrLexer.g by ANTLR 4.6



#ifndef __ANTLR_LEXER_H__
#define __ANTLR_LEXER_H__

#include <glib-object.h>

G_BEGIN_DECLS

typedef enum _ANTLRLexerSymbols  ANTLRLexerSymbols;

enum _ANTLRLexerSymbols {
  ANTLR_LEXER_SYMBOL_SEMPRED = 1, ANTLR_LEXER_SYMBOL_TOKEN_REF = 2, ANTLR_LEXER_SYMBOL_RULE_REF = 3, 
  ANTLR_LEXER_SYMBOL_LEXER_CHAR_SET = 4, ANTLR_LEXER_SYMBOL_ARG_ACTION = 5
};



#define ANTLR_TYPE_LEXER            (antlr_lexer_get_type())
#define ANTLR_LEXER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), ANTLR_TYPE_LEXER, ANTLRLexer))
#define ANTLR_LEXER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  ANTLR_TYPE_LEXER, ANTLRLexerClass))
#define ANTLR_IS_LEXER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), ANTLR_TYPE_LEXER))
#define ANTLR_IS_LEXER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  ANTLR_TYPE_LEXER))
#define ANTLR_LEXER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  ANTLR_TYPE_LEXER, ANTLRLexerClass))

typedef struct _ANTLRLexer      ANTLRLexer;
typedef struct _ANTLRLexerClass ANTLRLexerClass;

struct _ANTLRLexer {
    /*< private >*/
    AntlrLexer parent_instance;
};

struct _ANTLRLexerClass {
    /*< private >*/
    AntlrLexerClass parent_class;
};

GType antlr_lexer_get_type(void) G_GNUC_CONST;
ANTLRLexer *antlr_lexer_new();

ANTLRLexer *antlr_lexer_new_with_char_stream (AntlrCharStream *char_stream);



// Individual action functions triggered by action() above.

// Individual semantic predicate functions triggered by sempred() above.


G_END_DECLS

#endif /* __ANTLR_LEXER_H__ */

