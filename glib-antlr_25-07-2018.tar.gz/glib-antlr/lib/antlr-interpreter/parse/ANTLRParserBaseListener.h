
// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/antlr/ANTLRParser.g by ANTLR 4.6



//#include "antlr4-runtime.h"
#include "ANTLRParserListener.h"


#ifndef __GAP_PARSER_BASE_LISTENER_H__
#define __GAP_PARSER_BASE_LISTENER_H__

#include <glib-object.h>


G_BEGIN_DECLS

#define GAP_TYPE_PARSER_BASE_LISTENER            (gap_parser_base_listener_get_type())
#define GAP_PARSER_BASE_LISTENER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAP_TYPE_PARSER_BASE_LISTENER, GapParserBaseListener))
#define GAP_PARSER_BASE_LISTENER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass), GAP_TYPE_PARSER_BASE_LISTENER, GapParserBaseListenerClass))
#define GAP_IS_PARSER_BASE_LISTENER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAP_TYPE_PARSER_BASE_LISTENER))
#define GAP_IS_PARSER_BASE_LISTENER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass), GAP_TYPE_PARSER_BASE_LISTENER))
#define GAP_PARSER_BASE_LISTENER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj), GAP_TYPE_PARSER_BASE_LISTENER, GapParserBaseListenerClass))

typedef struct _GapParserBaseListener GapParserBaseListener;
typedef struct _GapParserBaseListenerClass GapParserBaseListenerClass;

/**
 * GapParserBaseListener:
 *
 * This class provides an empty implementation of ANTLRParserListener,
 * which can be extended to create a listener which only needs to handle a subset
 * of the available methods.
 */
struct _GapParserBaseListener {
        /*< private >*/
        GObject parent_instance;
};

struct _GapParserBaseListenerClass {
        /*< private >*/
        GObjectClass parent_class;
};

GType gap_parser_base_listener_get_type(void)G_GNUC_CONST;
GapParserBaseListener *gap_parser_base_listener_new();

G_END_DECLS

#endif /* __GAP_PARSER_BASE_LISTENER_H__ */







/*
class ANTLRParserBaseListener : public ANTLRParserListener {
public:

};
*/
