
// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/antlr/ANTLRLexer.g by ANTLR 4.6



#ifndef __GAP_LEXER_H__
#define __GAP_LEXER_H__

#include <glib-object.h>

G_BEGIN_DECLS

typedef enum _GapLexerSymbols  GapLexerSymbols;

enum _GapLexerSymbols {
  GAP_LEXER_SYMBOL_SEMPRED = 1, GAP_LEXER_SYMBOL_TOKEN_REF = 2, GAP_LEXER_SYMBOL_RULE_REF = 3, 
  GAP_LEXER_SYMBOL_LEXER_CHAR_SET = 4, GAP_LEXER_SYMBOL_ARG_ACTION = 5, 
  GAP_LEXER_SYMBOL_COMMENT = 6, GAP_LEXER_SYMBOL_ID = 7
};



#define GAP_TYPE_LEXER            (gap_lexer_get_type())
#define GAP_LEXER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), GAP_TYPE_LEXER, GapLexer))
#define GAP_LEXER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  GAP_TYPE_LEXER, GapLexerClass))
#define GAP_IS_LEXER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), GAP_TYPE_LEXER))
#define GAP_IS_LEXER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  GAP_TYPE_LEXER))
#define GAP_LEXER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  GAP_TYPE_LEXER, GapLexerClass))

typedef struct _GapLexer      GapLexer;
typedef struct _GapLexerClass GapLexerClass;

/**
 * GapLexer:
 * @tokens: track stream we push to; need for context info
 *
 */
struct _GapLexer {
    /*< private >*/
    AntlrLexer parent_instance;

    /*< public >*/
    AntlrCommonTokenStream *tokens;
};

struct _GapLexerClass {
    /*< private >*/
    AntlrLexerClass parent_class;
};

GType gap_lexer_get_type(void) G_GNUC_CONST;
GapLexer *gap_lexer_new();

GapLexer *gap_lexer_new_with_char_stream (AntlrCharStream *char_stream);

void gap_lexer_atn_free ();
void gap_lexer_decision_to_dfa_free ();
void gap_lexer_token_names_free();



// Individual action functions triggered by action() above.

// Individual semantic predicate functions triggered by sempred() above.


G_END_DECLS

#endif /* __GAP_LEXER_H__ */

