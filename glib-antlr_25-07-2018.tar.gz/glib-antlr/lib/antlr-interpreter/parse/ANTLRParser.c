
// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/antlr/ANTLRParser.g by ANTLR 4.6


//#include "ANTLRParserListener.h"
//

//#include "ANTLRParser.h"



#include <glib-object.h>

#include "antlr-runtime/types.h"

#include "antlr-runtime/misc/object.h"
#include "antlr-runtime/vocabulary.h"
#include "antlr-runtime/vocabulary-impl.h"
#include "antlr-runtime/misc/int-iset.h"
#include "antlr-runtime/misc/interval.h"
#include "antlr-runtime/misc/interval-set.h"
#include "antlr-runtime/misc/bit-set.h"
#include "antlr-runtime/misc/double-key-map.h"
#include "antlr-runtime/atn/transition.h"
#include "antlr-runtime/atn/lexer-action.h"
#include "antlr-runtime/atn/atn-state.h"
#include "antlr-runtime/atn/rule-stop-state.h"
#include "antlr-runtime/atn/rule-start-state.h"
#include "antlr-runtime/atn/atn.h"
#include "antlr-runtime/atn/prediction-context.h"
#include "antlr-runtime/atn/prediction-context-cache.h"
#include "antlr-runtime/atn/semantic-context.h"
#include "antlr-runtime/atn/config.h"
#include "antlr-runtime/atn/config-set.h"
#include "antlr-runtime/dfa/dfa-state.h"
#include "antlr-runtime/dfa/dfa.h"
#include "antlr-runtime/atn/prediction-mode.h"
#include "antlr-runtime/atn/atn-simulator.h"
#include "antlr-runtime/atn/parser-atn-simulator.h"

#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/tree/tree.h"
#include "antlr-runtime/tree/syntax-tree.h"
#include "antlr-runtime/tree/parse-tree.h"
#include "antlr-runtime/tree/terminal-node.h"
#include "antlr-runtime/tree/error-node.h"
#include "antlr-runtime/tree/parse-tree-listener.h"
#include "antlr-runtime/rule-node.h"
#include "antlr-runtime/rule-context.h"
#include "antlr-runtime/parser-rule-context.h"
#include "antlr-runtime/recognizer.h"
#include "antlr-runtime/parser.h"

#include "antlr-runtime/misc/integer-list.h"
#include "antlr-runtime/misc/integer-stack.h"
#include "antlr-runtime/recognizer.h"
#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/token-factory.h"
#include "antlr-runtime/lexer.h"

#include "antlr-runtime/rule-context.h"
#include "antlr-runtime/tree/tree.h"
#include "antlr-runtime/tree/syntax-tree.h"
#include "antlr-runtime/tree/parse-tree.h"
#include "antlr-runtime/tree/error-node.h"
#include "antlr-runtime/tree/terminal-node.h"
#include "antlr-runtime/tree/parse-tree-listener.h"

#include "antlr-runtime/token-stream.h"
#include "antlr-runtime/buffered-token-stream.h"
#include "antlr-runtime/common-token-stream.h"
#include "antlr-runtime/atn/atn-deserialization-options.h"
#include "antlr-runtime/atn/atn-deserializer.h"

#include "antlr-runtime/dfa/dfa.h"
#include "antlr-runtime/atn/decision-state.h"

#include "antlr-runtime/error-strategy.h"
#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/token-stream.h"
#include "antlr-runtime/token.h"

#include "antlr-runtime/parser-rule-context.h"

//#include "ANTLRParserLexer.h"
//#include ".h"

#include "ANTLRParser.h"

#include "ANTLRParserListener.h"


static AntlrATN *gap_parser_atn = NULL;// AntlrATN * || GArray *
static GArray   *gap_parser_decision_to_dfa = NULL;// of AntlrDFA*
static AntlrPredictionContextCache *gap_parser_shared_context_cache = NULL;
static AntlrPredictionContextCache*
gap_parser_get_shared_context_cache ()
{
    if (!gap_parser_shared_context_cache) {
        gap_parser_shared_context_cache = antlr_prediction_context_cache_new();
    }
    return gap_parser_shared_context_cache;
}

static guint gap_parser_serialized_atn[] = {
  0x03, 0x0430, 0xD6D1, 0x8206, 0xAD2D, 0x4417, 0xAEF1, 0x8D80, 0xAADD, 0x03, 0x09, 0x07, 0x04, 0x02, 0x09, 0x02, 0x03, 0x02, 0x03, 0x02, 0x03, 0x02, 0x02, 0x02, 0x03, 0x02, 0x02, 0x03, 0x03, 0x02, 0x04, 0x05, 0x05, 0x02, 0x04, 0x03, 0x02, 0x02, 0x02, 0x04, 0x05, 0x09, 0x02, 0x02, 0x02, 0x05, 0x03, 0x03, 0x02, 0x02, 0x02, 0x02
};

static AntlrATN*
gap_parser_get_atn ()
{
    if (!gap_parser_atn) {
        AntlrATNDeserializer *deserializer = antlr_atn_deserializer_new_full(NULL);
        gap_parser_atn = antlr_atn_deserializer_deserialize(deserializer, gap_parser_serialized_atn, G_N_ELEMENTS(gap_parser_serialized_atn));
        g_object_unref(deserializer);
    }
    return gap_parser_atn;
}

///
void
gap_parser_atn_free ()
{
    if (gap_parser_atn!=NULL) {
        g_clear_object(&gap_parser_atn);
    }
}


static void
my_pointer_object_unref(GObject **object)
{
    g_object_unref(*object);
}

void
gap_parser_decision_to_dfa_free ()
{
    if (gap_parser_decision_to_dfa!=NULL) {
        g_array_set_clear_func(gap_parser_decision_to_dfa, (GDestroyNotify)my_pointer_object_unref);
        g_array_free(gap_parser_decision_to_dfa, TRUE);
    }
    gap_parser_decision_to_dfa=NULL;
}

///
static GArray*
gap_parser_get_decision_to_dfa (GapParser *lexer)
{
    if (!gap_parser_decision_to_dfa) {
        AntlrATN *atn = gap_parser_get_atn();
        gint size = antlr_atn_get_number_of_decisions(atn);
        gap_parser_decision_to_dfa = g_array_sized_new(FALSE, FALSE, sizeof(AntlrDFA *), size);
        int i;
        for (i = 0; i < size; i++) {
            AntlrDFA *v = antlr_dfa_new_with_decision_state_and_decision(antlr_atn_get_decision_state(atn, i), i);
            g_array_insert_val(gap_parser_decision_to_dfa, i, v);
        }
    }
    return gap_parser_decision_to_dfa;
}


static gchar* gap_parser__RULE_NAMES[] = {
  "id"
};
static gchar* gap_parser__LITERAL_NAMES[] = {
  "", "", "", "", "", "", "'//'"
};
static gchar* gap_parser__SYMBOLIC_NAMES[] = {
  "", "SEMPRED", "TOKEN_REF", "RULE_REF", "LEXER_CHAR_SET", "ARG_ACTION", 
  "COMMENT", "ID"
};

static GArray*
gap_parser_symbolic_names_to_array () {
    GArray *array = g_array_new(FALSE, FALSE, sizeof(GString*));
    // TODO sized_new

    int i;
    for (i=0; i<G_N_ELEMENTS(gap_parser__SYMBOLIC_NAMES); i++) {
        GString * s = g_string_new( gap_parser__SYMBOLIC_NAMES[i] );
        g_array_append_val(array, s);
    }

    return array;
}

static GArray*
gap_parser_literal_names_to_array () {
    GArray *array = g_array_new(FALSE, FALSE, sizeof(GString*));
    // TODO sized_new

    int i;
    for (i=0; i<G_N_ELEMENTS(gap_parser__LITERAL_NAMES); i++) {
        GString * s = g_string_new( gap_parser__LITERAL_NAMES[i] );
        g_array_append_val(array, s);
    }

    return array;
}

static GArray*
gap_parser_rule_names_to_array () {
    GArray *array = g_array_sized_new(FALSE, FALSE, sizeof(GString*), G_N_ELEMENTS(gap_parser__RULE_NAMES));

    int i;
    for (i=0; i<G_N_ELEMENTS(gap_parser__RULE_NAMES); i++) {
        GString * s = g_string_new( gap_parser__RULE_NAMES[i] );
        g_array_append_val(array, s);
    }

    return array;
}


static AntlrVocabulary *gap_parser_vocabulary = NULL;

static AntlrVocabulary*
gap_parser_get_vocabulary(GapParser *parser)
{
    if (!gap_parser_vocabulary) {
        gap_parser_vocabulary = antlr_vocabulary_new(gap_parser_literal_names_to_array(), gap_parser_symbolic_names_to_array(), NULL);
    }
    return gap_parser_vocabulary;
}

static GArray* gap_parser_token_names = NULL;

static GArray*
gap_parser_get_token_names(AntlrRecognizer *recognizer)
{
    GapParser *parser = GAP_PARSER(recognizer);

    if (!gap_parser_token_names) {
        AntlrVocabulary *vocabulary = gap_parser_get_vocabulary(parser);
        AntlrIVocabulary *i_vocabulary = ANTLR_IVOCABULARY(vocabulary);

        gint length = G_N_ELEMENTS(gap_parser__SYMBOLIC_NAMES);
        gap_parser_token_names = g_array_sized_new(FALSE, FALSE, sizeof(GString*), length);
        gint i;
        for (i=0; i<length; i++) {
            gchar *token_name = antlr_ivocabulary_get_literal_name(i_vocabulary, i);
            if (token_name == NULL) {
                token_name = antlr_ivocabulary_get_symbolic_name(i_vocabulary, i);
            } else if (token_name[0] == '\0') {
                g_free(token_name);
                token_name = antlr_ivocabulary_get_symbolic_name(i_vocabulary, i);
            }

            if (token_name == NULL) {
                token_name = g_strdup("<INVALID>");
            } else if (token_name[0] == '\0') {
                g_free(token_name);
                token_name = g_strdup("<INVALID>");
            }


            GString *v = g_string_new(token_name);
            g_free(token_name);
            g_array_append_val(gap_parser_token_names, v);
        }
    }

    return gap_parser_token_names;
}

static void
gap_parser_g_string_free(gpointer *object) {
    GString *str = *object;
    if(str)
        g_string_free(str, TRUE);
}

void
gap_parser_token_names_free()
{
    if (gap_parser_token_names) {
        g_array_set_clear_func(gap_parser_token_names, (GDestroyNotify)gap_parser_g_string_free);
        g_array_free(gap_parser_token_names, TRUE);
    }
    gap_parser_token_names = NULL;
}

static GArray*
gap_parser_get_rule_names(AntlrRecognizer *recognizer)
{
    GapParser *parser = GAP_PARSER(recognizer);
    if (parser->rule_names==NULL) {
        parser->rule_names = gap_parser_rule_names_to_array();
    }
    return parser->rule_names;
}

G_DEFINE_TYPE (GapParser, gap_parser, antlr_parser_get_type())


static void
gap_parser_init (GapParser *parser)
{
    /* TODO: Add initialization code here */
    parser->rule_names = NULL;
}

static void
gap_parser_class_init (GapParserClass *klass)
{
    GObjectClass* object_class = G_OBJECT_CLASS (klass);
    AntlrRecognizerClass* recognizer_class = ANTLR_RECOGNIZER_CLASS (klass);

    //g_type_class_add_private (klass, sizeof (SqlParserRules));

    //object_class->finalize = sql_parser_finalize;
    //parser_class->enter_rule

    recognizer_class->get_token_names = gap_parser_get_token_names;
    recognizer_class->get_rule_names  = gap_parser_get_rule_names;
    recognizer_class->get_atn         = gap_parser_get_atn;

    // build token_names
}


GapParser*
gap_parser_new_with_token_stream (AntlrTokenStream *input)
{
    GapParser *parser;
    parser = g_object_new(GAP_TYPE_PARSER, NULL);
    //AntlrATN *atn = gap_parser_get_atn(ANTLR_RECOGNIZER(parser));

    ANTLR_PARSER(parser)->input = input;
    ANTLR_RECOGNIZER(parser)->interp = (AntlrATNInterpreter*)antlr_parser_atn_simulator_new_full(
                ANTLR_PARSER(parser),
                gap_parser_get_atn(/*ANTLR_RECOGNIZER(parser)*/),
                gap_parser_get_decision_to_dfa(parser),
                NULL//gap_parser_get_shared_context_cache()
    );
    return parser;
}



//----------------- IdContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint gap_context_id_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return GAP_PARSER_RULE_ID;
}

/* virtual AntlrParserRuleContext */
void gap_context_id_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    gap_parser_listener_enter_id(GAP_PARSER_LISTENER(listener), GAP_CONTEXT_ID(self));
}

void gap_context_id_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    gap_parser_listener_exit_id(GAP_PARSER_LISTENER(listener), GAP_CONTEXT_ID(self));
}

/* virtual GObject */
static void gap_context_id_class_init(GapContextIdClass *klass);
static void gap_context_id_init(GapContextId *gobject);

G_DEFINE_TYPE (GapContextId, gap_context_id, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
gap_context_id_class_init(GapContextIdClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = gap_context_id_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = gap_context_id_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = gap_context_id_class_rule_context_get_rule_index;
}

static void
gap_context_id_init (GapContextId *object)
{
}

GapContextId *gap_context_id_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(GAP_TYPE_CONTEXT_ID, parent, invoking_state);
    GapContextId *self = GAP_CONTEXT_ID(ctx);
    return self;
}

AntlrTerminalNode *gap_context_id_token_get_rule_ref(GapContextId* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PARSER_RULE_CONTEXT(self), GAP_PARSER_TOKEN_RULE_REF, 0);
}
AntlrTerminalNode *gap_context_id_token_get_token_ref(GapContextId* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PARSER_RULE_CONTEXT(self), GAP_PARSER_TOKEN_TOKEN_REF, 0);
}




GapContextId* gap_parser_parse_id(GapParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    GapContextId *local_context = gap_context_id_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, GAP_PARSER_RULE_ID);
    //paraphrases.push("looking for an identifier");
    size_t _la = 0;

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 2);
    _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    if ( !(_la == GAP_PARSER_TOKEN_TOKEN_REF || _la == GAP_PARSER_TOKEN_RULE_REF)) {
      antlr_error_strategy_recover_inline(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    } else {
      antlr_parser_consume(ANTLR_PARSER(self));
    }

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}



