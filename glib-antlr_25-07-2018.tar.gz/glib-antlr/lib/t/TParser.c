/* parser/listener/visitor header section */

// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/t/TParser.g4 by ANTLR 4.6

/* parser precinclude section */

#include "TParserListener.h"

#include "TParser.h"


/* parser postinclude section */



#include <glib-object.h>

#include "antlr-runtime/types.h"

#include "antlr-runtime/vocabulary.h"
#include "antlr-runtime/vocabulary-impl.h"
#include "antlr-runtime/misc/int-iset.h"
#include "antlr-runtime/misc/interval.h"
#include "antlr-runtime/misc/interval-set.h"
#include "antlr-runtime/misc/bit-set.h"
#include "antlr-runtime/misc/double-key-map.h"
#include "antlr-runtime/atn/transition.h"
#include "antlr-runtime/atn/lexer-action.h"
#include "antlr-runtime/atn/atn-state.h"
#include "antlr-runtime/atn/rule-stop-state.h"
#include "antlr-runtime/atn/rule-start-state.h"
#include "antlr-runtime/atn/atn.h"
#include "antlr-runtime/atn/prediction-context.h"
#include "antlr-runtime/atn/prediction-context-cache.h"
#include "antlr-runtime/atn/semantic-context.h"
#include "antlr-runtime/atn/config.h"
#include "antlr-runtime/atn/config-set.h"
#include "antlr-runtime/dfa/dfa-state.h"
#include "antlr-runtime/dfa/dfa.h"
#include "antlr-runtime/atn/prediction-mode.h"
#include "antlr-runtime/atn/atn-simulator.h"
#include "antlr-runtime/atn/parser-atn-simulator.h"

#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/tree/tree.h"
#include "antlr-runtime/tree/syntax-tree.h"
#include "antlr-runtime/tree/parse-tree.h"
#include "antlr-runtime/tree/terminal-node.h"
#include "antlr-runtime/tree/error-node.h"
#include "antlr-runtime/tree/parse-tree-listener.h"
#include "antlr-runtime/rule-node.h"
#include "antlr-runtime/rule-context.h"
#include "antlr-runtime/parser-rule-context.h"
#include "antlr-runtime/recognizer.h"
#include "antlr-runtime/parser.h"

#include "antlr-runtime/misc/integer-list.h"
#include "antlr-runtime/misc/integer-stack.h"
#include "antlr-runtime/recognizer.h"
#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/token-factory.h"
#include "antlr-runtime/lexer.h"

#include "antlr-runtime/rule-context.h"
#include "antlr-runtime/tree/tree.h"
#include "antlr-runtime/tree/syntax-tree.h"
#include "antlr-runtime/tree/parse-tree.h"
#include "antlr-runtime/tree/error-node.h"
#include "antlr-runtime/tree/terminal-node.h"
#include "antlr-runtime/tree/parse-tree-listener.h"

#include "antlr-runtime/token-stream.h"
#include "antlr-runtime/buffered-token-stream.h"
#include "antlr-runtime/common-token-stream.h"
#include "antlr-runtime/atn/atn-deserialization-options.h"
#include "antlr-runtime/atn/atn-deserializer.h"

#include "antlr-runtime/dfa/dfa.h"
#include "antlr-runtime/atn/decision-state.h"

#include "antlr-runtime/error-strategy.h"
#include "antlr-runtime/int-stream.h"
#include "antlr-runtime/token-stream.h"

#include "antlr-runtime/parser-rule-context.h"

#include ".h"
#include "TParser.h"


static gchar* my_parser__RULE_NAMES[] = {
  "main", "divide", "and", "conquer", "unused", "unused2", "stat", "expr", 
  "flowControl", "id", "array", "idarray", "any"
};
static gchar* my_parser__LITERAL_NAMES[] = {
  "", "", "'return'", "'continue'", "", "", "", "'<'", "'>'", "'='", "'and'", 
  "':'", "';'", "'+'", "'-'", "'*'", "'('", "')'", "'{'", "'}'", "'?'", 
  "','", "", "", "", "", "", "", "'.'", "'..'"
};
static gchar* my_parser__SYMBOLIC_NAMES[] = {
  "", "DUMMY", "Return", "Continue", "INT", "Digit", "ID", "LessThan", "GreaterThan", 
  "Equal", "And", "Colon", "Semicolon", "Plus", "Minus", "Star", "OpenPar", 
  "ClosePar", "OpenCurly", "CloseCurly", "QuestionMark", "Comma", "String", 
  "Foo", "Bar", "Any", "Comment", "WS", "Dot", "DotDot"
};

static AntlrATN* my_parser_get_atn(AntlrRecognizer *recognizer);

static GArray *my_parser_decision_to_dfa = NULL;// of AntlrDFA*

static GArray* // of AntlrDFA*
my_parser_get_decision_to_dfa()
{
    if (!my_parser_decision_to_dfa) {
        AntlrATN *atn = my_parser_get_atn(NULL);
        gint number_of_decisions = antlr_atn_get_number_of_decisions(atn);
        my_parser_decision_to_dfa = g_array_sized_new(FALSE, TRUE, sizeof(AntlrATN*), number_of_decisions);
        gint i;
        for (i = 0; i < number_of_decisions; i++) {
            AntlrDecisionState *decision = antlr_atn_get_decision_state(atn, i);
            AntlrDFA *dfa = antlr_dfa_new_with_decision_state_and_decision(decision, i);
            g_array_insert_val(my_parser_decision_to_dfa, i, dfa);
        }
    }
    return my_parser_decision_to_dfa;
}

static GArray*
my_parser_symbolic_names_to_array () {
    GArray *array = g_array_new(FALSE, FALSE, sizeof(GString*));
    // TODO sized_new

    int i;
    for (i=0; i<G_N_ELEMENTS(my_parser__SYMBOLIC_NAMES); i++) {
        GString * s = g_string_new( my_parser__SYMBOLIC_NAMES[i] );
        g_array_append_val(array, s);
    }

    return array;
}

static GArray*
my_parser_literal_names_to_array () {
    GArray *array = g_array_new(FALSE, FALSE, sizeof(GString*));
    // TODO sized_new

    int i;
    for (i=0; i<G_N_ELEMENTS(my_parser__LITERAL_NAMES); i++) {
        GString * s = g_string_new( my_parser__LITERAL_NAMES[i] );
        g_array_append_val(array, s);
    }

    return array;
}

static GArray*
my_parser_rule_names_to_array () {
    GArray *array = g_array_sized_new(FALSE, FALSE, sizeof(GString*), G_N_ELEMENTS(my_parser__RULE_NAMES));

    int i;
    for (i=0; i<G_N_ELEMENTS(my_parser__RULE_NAMES); i++) {
        GString * s = g_string_new( my_parser__RULE_NAMES[i] );
        g_array_append_val(array, s);
    }

    return array;
}


static GArray* my_parser_token_names = NULL;

static GArray*
my_parser_get_token_names(AntlrRecognizer *recognizer)
{
    MyParser *parser = MY_PARSER(recognizer);

    if (!my_parser_token_names) {
        AntlrVocabulary *vocabulary = my_parser_get_vocabulary(parser);
        AntlrIVocabulary *i_vocabulary = ANTLR_IVOCABULARY(vocabulary);

        gint length = G_N_ELEMENTS(my_parser__SYMBOLIC_NAMES);
        my_parser_token_names = g_array_sized_new(FALSE, FALSE, sizeof(GString*), length);
        gint i;
        for (i=0; i<length; i++) {
            gchar *token_name = antlr_ivocabulary_get_literal_name(i_vocabulary, i);
            if (token_name == NULL || token_name[0] == '\0') {
                token_name = antlr_ivocabulary_get_symbolic_name(i_vocabulary, i);
            }

            if (token_name == NULL || token_name[0] == '\0') {
                token_name = g_strdup("<INVALID>");
            }

            GString *v = g_string_new(token_name);
            g_free(token_name);
            g_array_append_val(my_parser_token_names, v);
        }
    }

    return my_parser_token_names;
}

static GArray*
my_parser_get_rule_names(AntlrRecognizer *recognizer)
{
    MyParser *parser = MY_PARSER(recognizer);
    if (parser->rule_names==NULL) {
        parser->rule_names = my_parser_rule_names_to_array();
    }
    return parser->rule_names;
}


static AntlrVocabulary *my_parser_vocabulary = NULL;

static AntlrVocabulary*
my_parser_get_vocabulary(SqlParser *parser)
{
    if (!my_parser_vocabulary) {
        my_parser_vocabulary = antlr_vocabulary_new(my_parser_literal_names_to_array(), my_parser_symbolic_names_to_array(), NULL);
    }
    return my_parser_vocabulary;
}


G_DEFINE_TYPE (MyParser, my_parser, antlr_parser_get_type())


static void
my_parser_init (MyParser *parser)
{
    /* TODO: Add initialization code here */
    parser->rule_names = NULL;
}

static void
my_parser_class_init (MyParserClass *klass)
{
    GObjectClass* object_class = G_OBJECT_CLASS (klass);
    AntlrRecognizerClass* recognizer_class = ANTLR_RECOGNIZER_CLASS (klass);

    //g_type_class_add_private (klass, sizeof (SqlParserRules));

    //object_class->finalize = sql_parser_finalize;
    //parser_class->enter_rule

    recognizer_class->get_token_names = my_parser_get_token_names;
    recognizer_class->get_rule_names  = my_parser_get_rule_names;
    recognizer_class->get_atn         = my_parser_get_atn;

    // build token_names
}


MyParser*
my_parser_new_with_token_stream (AntlrTokenStream *input)
{
    MyParser *parser;
    parser = g_object_new(MY_TYPE_PARSER, NULL);
    AntlrATN *atn = my_parser_get_atn(ANTLR_RECOGNIZER(parser));

    ANTLR_PARSER(parser)->input = input;
    ANTLR_RECOGNIZER(parser)->interp = (AntlrATNInterpreter*)antlr_parser_atn_simulator_new_full(
                ANTLR_PARSER(parser),
                my_parser_get_atn(ANTLR_RECOGNIZER(parser)),
                my_parser_get_decision_to_dfa(),
                NULL//my_parser_get_shared_context_cache()
    );
    return parser;
}


/* parser definitions section */

//----------------- MainContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_main_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_MAIN;
}

/* virtual AntlrParserRuleContext */
void my_context_main_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_main(MY_PARSER_LISTENER(listener), MY_CONTEXT_MAIN(self));
}

void my_context_main_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_main(MY_PARSER_LISTENER(listener), MY_CONTEXT_MAIN(self));
}

/* virtual GObject */
static void my_context_main_class_init(MyContextMainClass *klass);
static void my_context_main_init(MyContextMain *gobject);

G_DEFINE_TYPE (MyContextMain, my_context_main, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_main_class_init(MyContextMainClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_main_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_main_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_main_class_rule_context_get_rule_index;
}

static void
my_context_main_init (MyContextMain *object)
{
}

MyContextMain *my_context_main_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_MAIN, parent, invoking_state);
    MyContextMain *self = MY_CONTEXT_MAIN(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_main_token_get_eof(MyContextMain* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EOF, 0);
}
GList* my_context_main_rule_get_stat(MyContextMain* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextStat* my_context_main_at_rule_get_stat(MyContextMain* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_STAT, i);
    return MY_CONTEXT_STAT(context);
}




MyContextMain* my_parser_parse_main(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextMain *local_context = my_context_main_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_MAIN);
    size_t _la = 0;

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 27); 
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

    _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    do {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 26);
      my_parser_parse_stat(self, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 29); 
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    } while (((((_la) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la)) & ((1ULL << (MY_PARSER_RETURN))
      | (1ULL << (MY_PARSER_CONTINUE))
      | (1ULL << (MY_PARSER_INT))
      | (1ULL << (MY_PARSER_ID))
      | (1ULL << (MY_PARSER_OPEN_PAR))
      | (1ULL << (MY_PARSER_STRING)))) != 0));

    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 31);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_EOF);

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- DivideContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_divide_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_DIVIDE;
}

/* virtual AntlrParserRuleContext */
void my_context_divide_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_divide(MY_PARSER_LISTENER(listener), MY_CONTEXT_DIVIDE(self));
}

void my_context_divide_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_divide(MY_PARSER_LISTENER(listener), MY_CONTEXT_DIVIDE(self));
}

/* virtual GObject */
static void my_context_divide_class_init(MyContextDivideClass *klass);
static void my_context_divide_init(MyContextDivide *gobject);

G_DEFINE_TYPE (MyContextDivide, my_context_divide, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_divide_class_init(MyContextDivideClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_divide_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_divide_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_divide_class_rule_context_get_rule_index;
}

static void
my_context_divide_init (MyContextDivide *object)
{
}

MyContextDivide *my_context_divide_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_DIVIDE, parent, invoking_state);
    MyContextDivide *self = MY_CONTEXT_DIVIDE(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_divide_token_get_id(MyContextDivide* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, 0);
}
MyContextAnd *my_context_divide_rule_get_and(MyContextDivide* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_AND, 0);
    return MY_CONTEXT_AND(context);
}
AntlrTreeTerminalNode *my_context_divide_token_get_greater_than(MyContextDivide* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_GREATER_THAN, 0);
}




MyContextDivide* my_parser_parse_divide(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextDivide *local_context = my_context_divide_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_DIVIDE);

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 33);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_ID);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 37);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 1, ANTLR_PARSER(self)->ctx)) {
    case 1: {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 34);
      my_parser_parse_and(self, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 35);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_GREATER_THAN);
      break;
    }

    }
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 39);

    if (!(doesItBlend())){
        error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "doesItBlend()");
        return NULL;
    }


    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- AndContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_and_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_AND;
}

/* virtual AntlrParserRuleContext */
void my_context_and_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_and(MY_PARSER_LISTENER(listener), MY_CONTEXT_AND(self));
}

void my_context_and_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_and(MY_PARSER_LISTENER(listener), MY_CONTEXT_AND(self));
}

/* virtual GObject */
static void my_context_and_class_init(MyContextAndClass *klass);
static void my_context_and_init(MyContextAnd *gobject);

G_DEFINE_TYPE (MyContextAnd, my_context_and, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_and_class_init(MyContextAndClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_and_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_and_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_and_class_rule_context_get_rule_index;
}

static void
my_context_and_init (MyContextAnd *object)
{
}

MyContextAnd *my_context_and_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_AND, parent, invoking_state);
    MyContextAnd *self = MY_CONTEXT_AND(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_and_token_get_and(MyContextAnd* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_AND, 0);
}




MyContextAnd* my_parser_parse_and(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextAnd *local_context = my_context_and_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_AND);
    doInit(); 

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 41);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_AND);
    ctx->stop = antlr_token_stream_LT(ANTLR_TOKEN_STREAM(ANTLR_PARSER(self)->input), -1);
    doAfter(); 

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- ConquerContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_conquer_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_CONQUER;
}

/* virtual AntlrParserRuleContext */
void my_context_conquer_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_conquer(MY_PARSER_LISTENER(listener), MY_CONTEXT_CONQUER(self));
}

void my_context_conquer_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_conquer(MY_PARSER_LISTENER(listener), MY_CONTEXT_CONQUER(self));
}

/* virtual GObject */
static void my_context_conquer_class_init(MyContextConquerClass *klass);
static void my_context_conquer_init(MyContextConquer *gobject);

G_DEFINE_TYPE (MyContextConquer, my_context_conquer, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_conquer_class_init(MyContextConquerClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_conquer_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_conquer_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_conquer_class_rule_context_get_rule_index;
}

static void
my_context_conquer_init (MyContextConquer *object)
{
}

MyContextConquer *my_context_conquer_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_CONQUER, parent, invoking_state);
    MyContextConquer *self = MY_CONTEXT_CONQUER(ctx);
    return self;
}

GList* my_context_conquer_rule_get_divide(MyContextConquer* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextDivide* my_context_conquer_at_rule_get_divide(MyContextConquer* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_DIVIDE, i);
    return MY_CONTEXT_DIVIDE(context);
}
MyContextAnd *my_context_conquer_rule_get_and(MyContextConquer* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_AND, 0);
    return MY_CONTEXT_AND(context);
}
AntlrTreeTerminalNode *my_context_conquer_token_get_id(MyContextConquer* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, 0);
}
GList* my_context_conquer_token_get_less_than(MyContextConquer* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_LESS_THAN);
}
AntlrTreeTerminalNode *my_context_conquer_at_token_get_less_than(MyContextConquer* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_LESS_THAN, i);
}




MyContextConquer* my_parser_parse_conquer(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextConquer *local_context = my_context_conquer_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_CONQUER);
    size_t _la = 0;

    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 63); 
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 5, ANTLR_PARSER(self)->ctx)) {
    case 1: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 44); 
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
      do {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 43);
        my_parser_parse_divide(self, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 46); 
        antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
        _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
      } while (_la == MY_PARSER_ID);

      break;
    }

    case 2: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  2);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 48);

      if (!(doesItBlend())){
          error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "doesItBlend()");
          return NULL;
      }

      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 49);
      my_parser_parse_and(self, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
       myAction(); 
      break;
    }

    case 3: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  3);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 52);
      MY_CONTEXT_CONQUER(local_context)->idToken = 
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_ID);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 60);
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

      AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
      switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 4, ANTLR_PARSER(self)->ctx)) {
      case 1 + 1: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 56);
        antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
        _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
        while (_la == MY_PARSER_LESS_THAN) {
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 53);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_LESS_THAN);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 58);
          antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
          _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
        }
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 59);
        my_parser_parse_divide(self, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        break;
      }

      }
       //FIXME: (MY_CONTEXT_CONQUER(local_context)->idToken != NULL ? antlr_token_stream_get_text(ANTLR_TOKEN_STREAM(MY_CONTEXT_CONQUER(local_context)->idToken)) : g_strdup("")); 
      break;
    }

    }

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- UnusedContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_unused_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_UNUSED;
}

/* virtual AntlrParserRuleContext */
void my_context_unused_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_unused(MY_PARSER_LISTENER(listener), MY_CONTEXT_UNUSED(self));
}

void my_context_unused_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_unused(MY_PARSER_LISTENER(listener), MY_CONTEXT_UNUSED(self));
}

/* virtual GObject */
static void my_context_unused_class_init(MyContextUnusedClass *klass);
static void my_context_unused_init(MyContextUnused *gobject);

G_DEFINE_TYPE (MyContextUnused, my_context_unused, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_unused_class_init(MyContextUnusedClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_unused_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_unused_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_unused_class_rule_context_get_rule_index;
}

static void
my_context_unused_init (MyContextUnused *object)
{
}

MyContextUnused *my_context_unused_new_full(AntlrParserRuleContext *parent, size_t invokingState, double input)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_UNUSED, parent, state);
    MyContextUnused *self = MY_CONTEXT_UNUSED(ctx);
    self->input = input;
    return self;
}

MyContextUnused *my_context_unused_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_UNUSED, parent, invoking_state);
    MyContextUnused *self = MY_CONTEXT_UNUSED(ctx);
    return self;
}

MyContextStat *my_context_unused_rule_get_stat(MyContextUnused* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_STAT, 0);
    return MY_CONTEXT_STAT(context);
}




MyContextUnused* my_parser_parse_unused(MyParser* self, double input, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextUnused *local_context = my_context_unused_new_full(ctx, state, input);
    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_UNUSED);
     doInit(); 

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 65);
    my_parser_parse_stat(self, error);
    if (error && *error) {
        /* TODO: manage error .. */
        return NULL;
    }
    ctx->stop = antlr_token_stream_LT(ANTLR_TOKEN_STREAM(ANTLR_PARSER(self)->input), -1);
     doAfter(); 

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- Unused2Context ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_unused2_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_UNUSED2;
}

/* virtual AntlrParserRuleContext */
void my_context_unused2_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_unused2(MY_PARSER_LISTENER(listener), MY_CONTEXT_UNUSED2(self));
}

void my_context_unused2_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_unused2(MY_PARSER_LISTENER(listener), MY_CONTEXT_UNUSED2(self));
}

/* virtual GObject */
static void my_context_unused2_class_init(MyContextUnused2Class *klass);
static void my_context_unused2_init(MyContextUnused2 *gobject);

G_DEFINE_TYPE (MyContextUnused2, my_context_unused2, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_unused2_class_init(MyContextUnused2Class *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_unused2_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_unused2_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_unused2_class_rule_context_get_rule_index;
}

static void
my_context_unused2_init (MyContextUnused2 *object)
{
}

MyContextUnused2 *my_context_unused2_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_UNUSED2, parent, invoking_state);
    MyContextUnused2 *self = MY_CONTEXT_UNUSED2(ctx);
    return self;
}

GList* my_context_unused2_token_get_semicolon(MyContextUnused2* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_SEMICOLON);
}
AntlrTreeTerminalNode *my_context_unused2_at_token_get_semicolon(MyContextUnused2* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_SEMICOLON, i);
}
GList* my_context_unused2_rule_get_unused(MyContextUnused2* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextUnused* my_context_unused2_at_rule_get_unused(MyContextUnused2* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_UNUSED, i);
    return MY_CONTEXT_UNUSED(context);
}
AntlrTreeTerminalNode *my_context_unused2_token_get_colon(MyContextUnused2* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COLON, 0);
}
AntlrTreeTerminalNode *my_context_unused2_token_get_plus(MyContextUnused2* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_PLUS, 0);
}




MyContextUnused2* my_parser_parse_unused2(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextUnused2 *local_context = my_context_unused2_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_UNUSED2);
    size_t _la = 0;

    size_t alt;
    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 70);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    alt = 1;
    do {
      switch (alt) {
        case 1: {
              antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 67);
              my_parser_parse_unused(self, 1, error);
              if (error && *error) {
                  /* TODO: manage error .. */
                  return NULL;
              }
              antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 68);
              antlr_parser_match_wildcard(ANTLR_PARSER(self)); /* TODO */
              break;
            }

      default:
        error = g_error_new(g_quark_from_string("ANTLR"), 200, "NoViableAlt%s", "");
        return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 72);
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

      AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
      alt = antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 6, ANTLR_PARSER(self)->ctx);
    } while (alt != 2 && alt != ANTLR_ATN_INVALID_ALT_NUMBER);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 75);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 7, ANTLR_PARSER(self)->ctx)) {
    case 1: {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 74);
      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
      if (!(((((_la) & ~ 0x3fULL) == 0) &&
        ((1ULL << (_la)) & ((1ULL << (MY_PARSER_COLON))
        | (1ULL << (MY_PARSER_SEMICOLON))
        | (1ULL << (MY_PARSER_PLUS)))) != 0))) {
      antlr_error_strategy_recover_inline(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
      } else {
        antlr_parser_consume(ANTLR_PARSER(self));
      }
      break;
    }

    }
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 77);
    _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    if (_la == 0 || _la == ANTLR_TOKEN_EOF || (_la == MY_PARSER_SEMICOLON)) {
    antlr_error_strategy_recover_inline(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    } else {
      antlr_parser_consume(ANTLR_PARSER(self));
    }

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- StatContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_stat_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_STAT;
}

/* virtual AntlrParserRuleContext */
void my_context_stat_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_stat(MY_PARSER_LISTENER(listener), MY_CONTEXT_STAT(self));
}

void my_context_stat_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_stat(MY_PARSER_LISTENER(listener), MY_CONTEXT_STAT(self));
}

/* virtual GObject */
static void my_context_stat_class_init(MyContextStatClass *klass);
static void my_context_stat_init(MyContextStat *gobject);

G_DEFINE_TYPE (MyContextStat, my_context_stat, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_stat_class_init(MyContextStatClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_stat_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_stat_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_stat_class_rule_context_get_rule_index;
}

static void
my_context_stat_init (MyContextStat *object)
{
}

MyContextStat *my_context_stat_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_STAT, parent, invoking_state);
    MyContextStat *self = MY_CONTEXT_STAT(ctx);
    return self;
}

GList* my_context_stat_rule_get_expr(MyContextStat* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextExpr* my_context_stat_at_rule_get_expr(MyContextStat* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EXPR, i);
    return MY_CONTEXT_EXPR(context);
}
AntlrTreeTerminalNode *my_context_stat_token_get_equal(MyContextStat* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EQUAL, 0);
}
AntlrTreeTerminalNode *my_context_stat_token_get_semicolon(MyContextStat* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_SEMICOLON, 0);
}




MyContextStat* my_parser_parse_stat(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextStat *local_context = my_context_stat_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_STAT);

    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 87); 
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 8, ANTLR_PARSER(self)->ctx)) {
    case 1: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 79);
      my_parser_parse_expr(self, 0, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 80);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_EQUAL);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 81);
      my_parser_parse_expr(self, 0, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 82);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_SEMICOLON);
      break;
    }

    case 2: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  2);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 84);
      my_parser_parse_expr(self, 0, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 85);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_SEMICOLON);
      break;
    }

    }

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- ExprContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_expr_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_EXPR;
}

/* virtual AntlrParserRuleContext */
void my_context_expr_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_expr(MY_PARSER_LISTENER(listener), MY_CONTEXT_EXPR(self));
}

void my_context_expr_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_expr(MY_PARSER_LISTENER(listener), MY_CONTEXT_EXPR(self));
}

/* virtual GObject */
static void my_context_expr_class_init(MyContextExprClass *klass);
static void my_context_expr_init(MyContextExpr *gobject);

G_DEFINE_TYPE (MyContextExpr, my_context_expr, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_expr_class_init(MyContextExprClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_expr_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_expr_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_expr_class_rule_context_get_rule_index;
}

static void
my_context_expr_init (MyContextExpr *object)
{
}

MyContextExpr *my_context_expr_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_EXPR, parent, invoking_state);
    MyContextExpr *self = MY_CONTEXT_EXPR(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_expr_token_get_open_par(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_OPEN_PAR, 0);
}
GList* my_context_expr_rule_get_expr(MyContextExpr* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextExpr* my_context_expr_at_rule_get_expr(MyContextExpr* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EXPR, i);
    return MY_CONTEXT_EXPR(context);
}
AntlrTreeTerminalNode *my_context_expr_token_get_close_par(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_CLOSE_PAR, 0);
}
MyContextId *my_context_expr_rule_get_id(MyContextExpr* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, 0);
    return MY_CONTEXT_ID(context);
}
MyContextFlowControl *my_context_expr_rule_get_flow_control(MyContextExpr* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_FLOW_CONTROL, 0);
    return MY_CONTEXT_FLOW_CONTROL(context);
}
AntlrTreeTerminalNode *my_context_expr_token_get_int(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_INT, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_string(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_STRING, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_star(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_STAR, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_plus(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_PLUS, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_question_mark(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_QUESTION_MARK, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_colon(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COLON, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_equal(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EQUAL, 0);
}




TParser::ExprContext* TParser::expr() {
   return expr(0);
}

TParser::ExprContext* TParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  TParser::ExprContext *previousContext = _localctx;
  size_t startState = 14;
  enterRecursionRule(_localctx, 14, TParser::RuleExpr, precedence);


  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    setState(98);
    _errHandler->sync(this);// TODO: untested LL1AltBlock
    switch (_input->LA(1)) {
      case TParser::OpenPar: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 90);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_OPEN_PAR);
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 91);
        my_parser_parse_expr(self, 0, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 92);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_CLOSE_PAR);
        break;
      }

      case TParser::ID: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 94);
        MY_CONTEXT_EXPR(local_context)->identifier = my_parser_parse_id(self, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        break;
      }

      case TParser::Return:
      case TParser::Continue: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 95);
        my_parser_parse_flow_control(self, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        break;
      }

      case TParser::INT: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 96);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_INT);
        break;
      }

      case TParser::String: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 97);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_STRING);
        break;
      }

    default:
      error = g_error_new(g_quark_from_string("ANTLR"), 200, "NoViableAlt%s", "");
      return NULL;
    }
    ctx->stop = antlr_token_stream_LT(ANTLR_TOKEN_STREAM(ANTLR_PARSER(self)->input), -1);
    setState(117);
    _errHandler->sync(this);// TODO: untested StarBlock
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 11, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 115); 
        antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
        AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
        switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 10, ANTLR_PARSER(self)->ctx)) {
        case 1: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 100);

          if (!(precpred(_ctx, 9))){
              error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "precpred(_ctx, 9)");
              return NULL;
          }

          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 101);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_STAR);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 102);
          my_parser_parse_expr(self, 10, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          break;
        }

        case 2: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 103);

          if (!(precpred(_ctx, 8))){
              error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "precpred(_ctx, 8)");
              return NULL;
          }

          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 104);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_PLUS);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 105);
          my_parser_parse_expr(self, 9, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          break;
        }

        case 3: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 106);

          if (!(precpred(_ctx, 6))){
              error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "precpred(_ctx, 6)");
              return NULL;
          }

          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 107);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_QUESTION_MARK);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 108);
          my_parser_parse_expr(self, 0, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 109);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_COLON);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 110);
          my_parser_parse_expr(self, 6, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          break;
        }

        case 4: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 112);

          if (!(precpred(_ctx, 5))){
              error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "precpred(_ctx, 5)");
              return NULL;
          }

          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 113);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_EQUAL);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 114);
          my_parser_parse_expr(self, 5, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          break;
        }

        } 
      }
      setState(119);
      _errHandler->sync(this);// TODO: untested StarBlock
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 11, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- FlowControlContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_flow_control_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_FLOW_CONTROL;
}

/* virtual AntlrParserRuleContext */

/* virtual GObject */
static void my_context_flow_control_class_init(MyContextFlowControlClass *klass);
static void my_context_flow_control_init(MyContextFlowControl *gobject);

G_DEFINE_TYPE (MyContextFlowControl, my_context_flow_control, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_flow_control_class_init(MyContextFlowControlClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_flow_control_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_flow_control_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_flow_control_class_rule_context_get_rule_index;
}

static void
my_context_flow_control_init (MyContextFlowControl *object)
{
}

MyContextFlowControl *my_context_flow_control_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_FLOW_CONTROL, parent, invoking_state);
    MyContextFlowControl *self = MY_CONTEXT_FLOW_CONTROL(ctx);
    return self;
}



void TParser::FlowControlContext::copyFrom(FlowControlContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}


//----------------- ReturnContext ------------------------------------------------------------------

AntlrTreeTerminalNode *my_context_return_token_get_return(MyContextReturn* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_RETURN, 0);
}
MyContextExpr *my_context_return_rule_get_expr(MyContextReturn* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EXPR, 0);
    return MY_CONTEXT_EXPR(context);
}
TParser::ReturnContext::ReturnContext(FlowControlContext *ctx) { copyFrom(ctx); }

void my_context_return_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_return(MY_PARSER_LISTENER(listener), MY_CONTEXT_RETURN(self));
}
void my_context_return_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_return(MY_PARSER_LISTENER(listener), MY_CONTEXT_RETURN(self));
}
//----------------- ContinueContext ------------------------------------------------------------------

AntlrTreeTerminalNode *my_context_continue_token_get_continue(MyContextContinue* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_CONTINUE, 0);
}
TParser::ContinueContext::ContinueContext(FlowControlContext *ctx) { copyFrom(ctx); }

void my_context_continue_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_continue(MY_PARSER_LISTENER(listener), MY_CONTEXT_CONTINUE(self));
}
void my_context_continue_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_continue(MY_PARSER_LISTENER(listener), MY_CONTEXT_CONTINUE(self));
}

MyContextFlowControl* my_parser_parse_flow_control(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextFlowControl *local_context = my_context_flow_control_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_FLOW_CONTROL);

    setState(123);
    _errHandler->sync(this);// TODO: untested LL1AltBlock
    switch (_input->LA(1)) {
      case TParser::Return: {
        _localctx = dynamic_cast<FlowControlContext *>(_tracker.createInstance<TParser::ReturnContext>(_localctx));
        antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 120);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_RETURN);
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 121);
        my_parser_parse_expr(self, 0, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        break;
      }

      case TParser::Continue: {
        _localctx = dynamic_cast<FlowControlContext *>(_tracker.createInstance<TParser::ContinueContext>(_localctx));
        antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  2);
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 122);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_CONTINUE);
        break;
      }

    default:
      error = g_error_new(g_quark_from_string("ANTLR"), 200, "NoViableAlt%s", "");
      return NULL;
    }

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- IdContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_id_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_ID;
}

/* virtual AntlrParserRuleContext */
void my_context_id_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_id(MY_PARSER_LISTENER(listener), MY_CONTEXT_ID(self));
}

void my_context_id_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_id(MY_PARSER_LISTENER(listener), MY_CONTEXT_ID(self));
}

/* virtual GObject */
static void my_context_id_class_init(MyContextIdClass *klass);
static void my_context_id_init(MyContextId *gobject);

G_DEFINE_TYPE (MyContextId, my_context_id, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_id_class_init(MyContextIdClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_id_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_id_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_id_class_rule_context_get_rule_index;
}

static void
my_context_id_init (MyContextId *object)
{
}

MyContextId *my_context_id_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_ID, parent, invoking_state);
    MyContextId *self = MY_CONTEXT_ID(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_id_token_get_id(MyContextId* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, 0);
}




MyContextId* my_parser_parse_id(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextId *local_context = my_context_id_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_ID);

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 125);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_ID);

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- ArrayContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_array_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_ARRAY;
}

/* virtual AntlrParserRuleContext */
void my_context_array_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_array(MY_PARSER_LISTENER(listener), MY_CONTEXT_ARRAY(self));
}

void my_context_array_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_array(MY_PARSER_LISTENER(listener), MY_CONTEXT_ARRAY(self));
}

/* virtual GObject */
static void my_context_array_class_init(MyContextArrayClass *klass);
static void my_context_array_init(MyContextArray *gobject);

G_DEFINE_TYPE (MyContextArray, my_context_array, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_array_class_init(MyContextArrayClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_array_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_array_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_array_class_rule_context_get_rule_index;
}

static void
my_context_array_init (MyContextArray *object)
{
}

MyContextArray *my_context_array_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_ARRAY, parent, invoking_state);
    MyContextArray *self = MY_CONTEXT_ARRAY(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_array_token_get_open_curly(MyContextArray* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_OPEN_CURLY, 0);
}
AntlrTreeTerminalNode *my_context_array_token_get_close_curly(MyContextArray* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_CLOSE_CURLY, 0);
}
GList* my_context_array_token_get_int(MyContextArray* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_INT);
}
AntlrTreeTerminalNode *my_context_array_at_token_get_int(MyContextArray* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_INT, i);
}
GList* my_context_array_token_get_comma(MyContextArray* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COMMA);
}
AntlrTreeTerminalNode *my_context_array_at_token_get_comma(MyContextArray* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COMMA, i);
}




MyContextArray* my_parser_parse_array(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextArray *local_context = my_context_array_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_ARRAY);
    size_t _la = 0;

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 127);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_OPEN_CURLY);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 128);
    MY_CONTEXT_ARRAY(local_context)->intToken = 
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_INT);
    MY_CONTEXT_ARRAY(local_context)->el.push_back(MY_CONTEXT_ARRAY(local_context)->intToken);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 133);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    while (_la == MY_PARSER_COMMA) {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 129);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_COMMA);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 130);
      MY_CONTEXT_ARRAY(local_context)->intToken = 
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_INT);
      MY_CONTEXT_ARRAY(local_context)->el.push_back(MY_CONTEXT_ARRAY(local_context)->intToken);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 135);
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    }
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 136);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_CLOSE_CURLY);

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- IdarrayContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_idarray_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_IDARRAY;
}

/* virtual AntlrParserRuleContext */
void my_context_idarray_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_idarray(MY_PARSER_LISTENER(listener), MY_CONTEXT_IDARRAY(self));
}

void my_context_idarray_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_idarray(MY_PARSER_LISTENER(listener), MY_CONTEXT_IDARRAY(self));
}

/* virtual GObject */
static void my_context_idarray_class_init(MyContextIdarrayClass *klass);
static void my_context_idarray_init(MyContextIdarray *gobject);

G_DEFINE_TYPE (MyContextIdarray, my_context_idarray, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_idarray_class_init(MyContextIdarrayClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_idarray_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_idarray_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_idarray_class_rule_context_get_rule_index;
}

static void
my_context_idarray_init (MyContextIdarray *object)
{
}

MyContextIdarray *my_context_idarray_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_IDARRAY, parent, invoking_state);
    MyContextIdarray *self = MY_CONTEXT_IDARRAY(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_idarray_token_get_open_curly(MyContextIdarray* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_OPEN_CURLY, 0);
}
AntlrTreeTerminalNode *my_context_idarray_token_get_close_curly(MyContextIdarray* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_CLOSE_CURLY, 0);
}
GList* my_context_idarray_rule_get_id(MyContextIdarray* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextId* my_context_idarray_at_rule_get_id(MyContextIdarray* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, i);
    return MY_CONTEXT_ID(context);
}
GList* my_context_idarray_token_get_comma(MyContextIdarray* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COMMA);
}
AntlrTreeTerminalNode *my_context_idarray_at_token_get_comma(MyContextIdarray* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COMMA, i);
}




MyContextIdarray* my_parser_parse_idarray(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextIdarray *local_context = my_context_idarray_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_IDARRAY);
    size_t _la = 0;

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 138);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_OPEN_CURLY);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 139);
    MY_CONTEXT_IDARRAY(local_context)->idContext = my_parser_parse_id(self, error);
    if (error && *error) {
        /* TODO: manage error .. */
        return NULL;
    }
    MY_CONTEXT_IDARRAY(local_context)->element.push_back(MY_CONTEXT_IDARRAY(local_context)->idContext);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 144);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    while (_la == MY_PARSER_COMMA) {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 140);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_COMMA);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 141);
      MY_CONTEXT_IDARRAY(local_context)->idContext = my_parser_parse_id(self, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      MY_CONTEXT_IDARRAY(local_context)->element.push_back(MY_CONTEXT_IDARRAY(local_context)->idContext);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 146);
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    }
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 147);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_CLOSE_CURLY);

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- AnyContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_any_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_ANY;
}

/* virtual AntlrParserRuleContext */
void my_context_any_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_any(MY_PARSER_LISTENER(listener), MY_CONTEXT_ANY(self));
}

void my_context_any_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_any(MY_PARSER_LISTENER(listener), MY_CONTEXT_ANY(self));
}

/* virtual GObject */
static void my_context_any_class_init(MyContextAnyClass *klass);
static void my_context_any_init(MyContextAny *gobject);

G_DEFINE_TYPE (MyContextAny, my_context_any, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_any_class_init(MyContextAnyClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_any_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_any_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_any_class_rule_context_get_rule_index;
}

static void
my_context_any_init (MyContextAny *object)
{
}

MyContextAny *my_context_any_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_ANY, parent, invoking_state);
    MyContextAny *self = MY_CONTEXT_ANY(ctx);
    return self;
}





MyContextAny* my_parser_parse_any(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextAny *local_context = my_context_any_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_ANY);

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 149);
    MY_CONTEXT_ANY(local_context)->t = antlr_parser_match_wildcard(ANTLR_PARSER(self)); /* TODO */

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}



//----------------- MainContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_main_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_MAIN;
}

/* virtual AntlrParserRuleContext */
void my_context_main_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_main(MY_PARSER_LISTENER(listener), MY_CONTEXT_MAIN(self));
}

void my_context_main_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_main(MY_PARSER_LISTENER(listener), MY_CONTEXT_MAIN(self));
}

/* virtual GObject */
static void my_context_main_class_init(MyContextMainClass *klass);
static void my_context_main_init(MyContextMain *gobject);

G_DEFINE_TYPE (MyContextMain, my_context_main, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_main_class_init(MyContextMainClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_main_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_main_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_main_class_rule_context_get_rule_index;
}

static void
my_context_main_init (MyContextMain *object)
{
}

MyContextMain *my_context_main_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_MAIN, parent, invoking_state);
    MyContextMain *self = MY_CONTEXT_MAIN(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_main_token_get_eof(MyContextMain* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EOF, 0);
}
GList* my_context_main_rule_get_stat(MyContextMain* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextStat* my_context_main_at_rule_get_stat(MyContextMain* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_STAT, i);
    return MY_CONTEXT_STAT(context);
}




MyContextMain* my_parser_parse_main(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextMain *local_context = my_context_main_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_MAIN);
    size_t _la = 0;

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 27); 
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

    _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    do {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 26);
      my_parser_parse_stat(self, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 29); 
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    } while (((((_la) & ~ 0x3fULL) == 0) &&
      ((1ULL << (_la)) & ((1ULL << (MY_PARSER_RETURN))
      | (1ULL << (MY_PARSER_CONTINUE))
      | (1ULL << (MY_PARSER_INT))
      | (1ULL << (MY_PARSER_ID))
      | (1ULL << (MY_PARSER_OPEN_PAR))
      | (1ULL << (MY_PARSER_STRING)))) != 0));

    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 31);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_EOF);

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- DivideContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_divide_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_DIVIDE;
}

/* virtual AntlrParserRuleContext */
void my_context_divide_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_divide(MY_PARSER_LISTENER(listener), MY_CONTEXT_DIVIDE(self));
}

void my_context_divide_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_divide(MY_PARSER_LISTENER(listener), MY_CONTEXT_DIVIDE(self));
}

/* virtual GObject */
static void my_context_divide_class_init(MyContextDivideClass *klass);
static void my_context_divide_init(MyContextDivide *gobject);

G_DEFINE_TYPE (MyContextDivide, my_context_divide, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_divide_class_init(MyContextDivideClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_divide_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_divide_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_divide_class_rule_context_get_rule_index;
}

static void
my_context_divide_init (MyContextDivide *object)
{
}

MyContextDivide *my_context_divide_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_DIVIDE, parent, invoking_state);
    MyContextDivide *self = MY_CONTEXT_DIVIDE(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_divide_token_get_id(MyContextDivide* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, 0);
}
MyContextAnd *my_context_divide_rule_get_and(MyContextDivide* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_AND, 0);
    return MY_CONTEXT_AND(context);
}
AntlrTreeTerminalNode *my_context_divide_token_get_greater_than(MyContextDivide* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_GREATER_THAN, 0);
}




MyContextDivide* my_parser_parse_divide(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextDivide *local_context = my_context_divide_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_DIVIDE);

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 33);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_ID);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 37);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 1, ANTLR_PARSER(self)->ctx)) {
    case 1: {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 34);
      my_parser_parse_and(self, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 35);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_GREATER_THAN);
      break;
    }

    }
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 39);

    if (!(doesItBlend())){
        error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "doesItBlend()");
        return NULL;
    }


    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- AndContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_and_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_AND;
}

/* virtual AntlrParserRuleContext */
void my_context_and_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_and(MY_PARSER_LISTENER(listener), MY_CONTEXT_AND(self));
}

void my_context_and_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_and(MY_PARSER_LISTENER(listener), MY_CONTEXT_AND(self));
}

/* virtual GObject */
static void my_context_and_class_init(MyContextAndClass *klass);
static void my_context_and_init(MyContextAnd *gobject);

G_DEFINE_TYPE (MyContextAnd, my_context_and, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_and_class_init(MyContextAndClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_and_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_and_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_and_class_rule_context_get_rule_index;
}

static void
my_context_and_init (MyContextAnd *object)
{
}

MyContextAnd *my_context_and_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_AND, parent, invoking_state);
    MyContextAnd *self = MY_CONTEXT_AND(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_and_token_get_and(MyContextAnd* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_AND, 0);
}




MyContextAnd* my_parser_parse_and(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextAnd *local_context = my_context_and_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_AND);
    doInit(); 

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 41);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_AND);
    ctx->stop = antlr_token_stream_LT(ANTLR_TOKEN_STREAM(ANTLR_PARSER(self)->input), -1);
    doAfter(); 

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- ConquerContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_conquer_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_CONQUER;
}

/* virtual AntlrParserRuleContext */
void my_context_conquer_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_conquer(MY_PARSER_LISTENER(listener), MY_CONTEXT_CONQUER(self));
}

void my_context_conquer_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_conquer(MY_PARSER_LISTENER(listener), MY_CONTEXT_CONQUER(self));
}

/* virtual GObject */
static void my_context_conquer_class_init(MyContextConquerClass *klass);
static void my_context_conquer_init(MyContextConquer *gobject);

G_DEFINE_TYPE (MyContextConquer, my_context_conquer, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_conquer_class_init(MyContextConquerClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_conquer_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_conquer_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_conquer_class_rule_context_get_rule_index;
}

static void
my_context_conquer_init (MyContextConquer *object)
{
}

MyContextConquer *my_context_conquer_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_CONQUER, parent, invoking_state);
    MyContextConquer *self = MY_CONTEXT_CONQUER(ctx);
    return self;
}

GList* my_context_conquer_rule_get_divide(MyContextConquer* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextDivide* my_context_conquer_at_rule_get_divide(MyContextConquer* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_DIVIDE, i);
    return MY_CONTEXT_DIVIDE(context);
}
MyContextAnd *my_context_conquer_rule_get_and(MyContextConquer* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_AND, 0);
    return MY_CONTEXT_AND(context);
}
AntlrTreeTerminalNode *my_context_conquer_token_get_id(MyContextConquer* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, 0);
}
GList* my_context_conquer_token_get_less_than(MyContextConquer* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_LESS_THAN);
}
AntlrTreeTerminalNode *my_context_conquer_at_token_get_less_than(MyContextConquer* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_LESS_THAN, i);
}




MyContextConquer* my_parser_parse_conquer(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextConquer *local_context = my_context_conquer_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_CONQUER);
    size_t _la = 0;

    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 63); 
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 5, ANTLR_PARSER(self)->ctx)) {
    case 1: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 44); 
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
      do {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 43);
        my_parser_parse_divide(self, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 46); 
        antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
        _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
      } while (_la == MY_PARSER_ID);

      break;
    }

    case 2: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  2);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 48);

      if (!(doesItBlend())){
          error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "doesItBlend()");
          return NULL;
      }

      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 49);
      my_parser_parse_and(self, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
       myAction(); 
      break;
    }

    case 3: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  3);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 52);
      MY_CONTEXT_CONQUER(local_context)->idToken = 
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_ID);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 60);
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

      AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
      switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 4, ANTLR_PARSER(self)->ctx)) {
      case 1 + 1: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 56);
        antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
        _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
        while (_la == MY_PARSER_LESS_THAN) {
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 53);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_LESS_THAN);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 58);
          antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
          _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
        }
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 59);
        my_parser_parse_divide(self, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        break;
      }

      }
       //FIXME: (MY_CONTEXT_CONQUER(local_context)->idToken != NULL ? antlr_token_stream_get_text(ANTLR_TOKEN_STREAM(MY_CONTEXT_CONQUER(local_context)->idToken)) : g_strdup("")); 
      break;
    }

    }

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- UnusedContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_unused_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_UNUSED;
}

/* virtual AntlrParserRuleContext */
void my_context_unused_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_unused(MY_PARSER_LISTENER(listener), MY_CONTEXT_UNUSED(self));
}

void my_context_unused_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_unused(MY_PARSER_LISTENER(listener), MY_CONTEXT_UNUSED(self));
}

/* virtual GObject */
static void my_context_unused_class_init(MyContextUnusedClass *klass);
static void my_context_unused_init(MyContextUnused *gobject);

G_DEFINE_TYPE (MyContextUnused, my_context_unused, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_unused_class_init(MyContextUnusedClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_unused_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_unused_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_unused_class_rule_context_get_rule_index;
}

static void
my_context_unused_init (MyContextUnused *object)
{
}

MyContextUnused *my_context_unused_new_full(AntlrParserRuleContext *parent, size_t invokingState, double input)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_UNUSED, parent, state);
    MyContextUnused *self = MY_CONTEXT_UNUSED(ctx);
    self->input = input;
    return self;
}

MyContextUnused *my_context_unused_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_UNUSED, parent, invoking_state);
    MyContextUnused *self = MY_CONTEXT_UNUSED(ctx);
    return self;
}

MyContextStat *my_context_unused_rule_get_stat(MyContextUnused* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_STAT, 0);
    return MY_CONTEXT_STAT(context);
}




MyContextUnused* my_parser_parse_unused(MyParser* self, double input, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextUnused *local_context = my_context_unused_new_full(ctx, state, input);
    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_UNUSED);
     doInit(); 

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 65);
    my_parser_parse_stat(self, error);
    if (error && *error) {
        /* TODO: manage error .. */
        return NULL;
    }
    ctx->stop = antlr_token_stream_LT(ANTLR_TOKEN_STREAM(ANTLR_PARSER(self)->input), -1);
     doAfter(); 

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- Unused2Context ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_unused2_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_UNUSED2;
}

/* virtual AntlrParserRuleContext */
void my_context_unused2_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_unused2(MY_PARSER_LISTENER(listener), MY_CONTEXT_UNUSED2(self));
}

void my_context_unused2_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_unused2(MY_PARSER_LISTENER(listener), MY_CONTEXT_UNUSED2(self));
}

/* virtual GObject */
static void my_context_unused2_class_init(MyContextUnused2Class *klass);
static void my_context_unused2_init(MyContextUnused2 *gobject);

G_DEFINE_TYPE (MyContextUnused2, my_context_unused2, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_unused2_class_init(MyContextUnused2Class *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_unused2_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_unused2_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_unused2_class_rule_context_get_rule_index;
}

static void
my_context_unused2_init (MyContextUnused2 *object)
{
}

MyContextUnused2 *my_context_unused2_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_UNUSED2, parent, invoking_state);
    MyContextUnused2 *self = MY_CONTEXT_UNUSED2(ctx);
    return self;
}

GList* my_context_unused2_token_get_semicolon(MyContextUnused2* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_SEMICOLON);
}
AntlrTreeTerminalNode *my_context_unused2_at_token_get_semicolon(MyContextUnused2* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_SEMICOLON, i);
}
GList* my_context_unused2_rule_get_unused(MyContextUnused2* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextUnused* my_context_unused2_at_rule_get_unused(MyContextUnused2* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_UNUSED, i);
    return MY_CONTEXT_UNUSED(context);
}
AntlrTreeTerminalNode *my_context_unused2_token_get_colon(MyContextUnused2* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COLON, 0);
}
AntlrTreeTerminalNode *my_context_unused2_token_get_plus(MyContextUnused2* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_PLUS, 0);
}




MyContextUnused2* my_parser_parse_unused2(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextUnused2 *local_context = my_context_unused2_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_UNUSED2);
    size_t _la = 0;

    size_t alt;
    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 70);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    alt = 1;
    do {
      switch (alt) {
        case 1: {
              antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 67);
              my_parser_parse_unused(self, 1, error);
              if (error && *error) {
                  /* TODO: manage error .. */
                  return NULL;
              }
              antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 68);
              antlr_parser_match_wildcard(ANTLR_PARSER(self)); /* TODO */
              break;
            }

      default:
        error = g_error_new(g_quark_from_string("ANTLR"), 200, "NoViableAlt%s", "");
        return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 72);
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

      AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
      alt = antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 6, ANTLR_PARSER(self)->ctx);
    } while (alt != 2 && alt != ANTLR_ATN_INVALID_ALT_NUMBER);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 75);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));

    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 7, ANTLR_PARSER(self)->ctx)) {
    case 1: {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 74);
      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
      if (!(((((_la) & ~ 0x3fULL) == 0) &&
        ((1ULL << (_la)) & ((1ULL << (MY_PARSER_COLON))
        | (1ULL << (MY_PARSER_SEMICOLON))
        | (1ULL << (MY_PARSER_PLUS)))) != 0))) {
      antlr_error_strategy_recover_inline(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
      } else {
        antlr_parser_consume(ANTLR_PARSER(self));
      }
      break;
    }

    }
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 77);
    _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    if (_la == 0 || _la == ANTLR_TOKEN_EOF || (_la == MY_PARSER_SEMICOLON)) {
    antlr_error_strategy_recover_inline(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    } else {
      antlr_parser_consume(ANTLR_PARSER(self));
    }

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- StatContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_stat_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_STAT;
}

/* virtual AntlrParserRuleContext */
void my_context_stat_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_stat(MY_PARSER_LISTENER(listener), MY_CONTEXT_STAT(self));
}

void my_context_stat_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_stat(MY_PARSER_LISTENER(listener), MY_CONTEXT_STAT(self));
}

/* virtual GObject */
static void my_context_stat_class_init(MyContextStatClass *klass);
static void my_context_stat_init(MyContextStat *gobject);

G_DEFINE_TYPE (MyContextStat, my_context_stat, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_stat_class_init(MyContextStatClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_stat_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_stat_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_stat_class_rule_context_get_rule_index;
}

static void
my_context_stat_init (MyContextStat *object)
{
}

MyContextStat *my_context_stat_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_STAT, parent, invoking_state);
    MyContextStat *self = MY_CONTEXT_STAT(ctx);
    return self;
}

GList* my_context_stat_rule_get_expr(MyContextStat* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextExpr* my_context_stat_at_rule_get_expr(MyContextStat* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EXPR, i);
    return MY_CONTEXT_EXPR(context);
}
AntlrTreeTerminalNode *my_context_stat_token_get_equal(MyContextStat* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EQUAL, 0);
}
AntlrTreeTerminalNode *my_context_stat_token_get_semicolon(MyContextStat* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_SEMICOLON, 0);
}




MyContextStat* my_parser_parse_stat(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextStat *local_context = my_context_stat_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_STAT);

    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 87); 
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
    switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 8, ANTLR_PARSER(self)->ctx)) {
    case 1: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 79);
      my_parser_parse_expr(self, 0, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 80);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_EQUAL);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 81);
      my_parser_parse_expr(self, 0, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 82);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_SEMICOLON);
      break;
    }

    case 2: {
      antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  2);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 84);
      my_parser_parse_expr(self, 0, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 85);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_SEMICOLON);
      break;
    }

    }

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- ExprContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_expr_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_EXPR;
}

/* virtual AntlrParserRuleContext */
void my_context_expr_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_expr(MY_PARSER_LISTENER(listener), MY_CONTEXT_EXPR(self));
}

void my_context_expr_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_expr(MY_PARSER_LISTENER(listener), MY_CONTEXT_EXPR(self));
}

/* virtual GObject */
static void my_context_expr_class_init(MyContextExprClass *klass);
static void my_context_expr_init(MyContextExpr *gobject);

G_DEFINE_TYPE (MyContextExpr, my_context_expr, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_expr_class_init(MyContextExprClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_expr_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_expr_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_expr_class_rule_context_get_rule_index;
}

static void
my_context_expr_init (MyContextExpr *object)
{
}

MyContextExpr *my_context_expr_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_EXPR, parent, invoking_state);
    MyContextExpr *self = MY_CONTEXT_EXPR(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_expr_token_get_open_par(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_OPEN_PAR, 0);
}
GList* my_context_expr_rule_get_expr(MyContextExpr* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextExpr* my_context_expr_at_rule_get_expr(MyContextExpr* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EXPR, i);
    return MY_CONTEXT_EXPR(context);
}
AntlrTreeTerminalNode *my_context_expr_token_get_close_par(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_CLOSE_PAR, 0);
}
MyContextId *my_context_expr_rule_get_id(MyContextExpr* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, 0);
    return MY_CONTEXT_ID(context);
}
MyContextFlowControl *my_context_expr_rule_get_flow_control(MyContextExpr* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_FLOW_CONTROL, 0);
    return MY_CONTEXT_FLOW_CONTROL(context);
}
AntlrTreeTerminalNode *my_context_expr_token_get_int(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_INT, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_string(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_STRING, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_star(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_STAR, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_plus(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_PLUS, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_question_mark(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_QUESTION_MARK, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_colon(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COLON, 0);
}
AntlrTreeTerminalNode *my_context_expr_token_get_equal(MyContextExpr* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EQUAL, 0);
}




TParser::ExprContext* TParser::expr() {
   return expr(0);
}

TParser::ExprContext* TParser::expr(int precedence) {
  ParserRuleContext *parentContext = _ctx;
  size_t parentState = getState();
  TParser::ExprContext *_localctx = _tracker.createInstance<ExprContext>(_ctx, parentState);
  TParser::ExprContext *previousContext = _localctx;
  size_t startState = 14;
  enterRecursionRule(_localctx, 14, TParser::RuleExpr, precedence);


  auto onExit = finally([=] {
    unrollRecursionContexts(parentContext);
  });
  try {
    size_t alt;
    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    setState(98);
    _errHandler->sync(this);// TODO: untested LL1AltBlock
    switch (_input->LA(1)) {
      case TParser::OpenPar: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 90);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_OPEN_PAR);
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 91);
        my_parser_parse_expr(self, 0, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 92);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_CLOSE_PAR);
        break;
      }

      case TParser::ID: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 94);
        MY_CONTEXT_EXPR(local_context)->identifier = my_parser_parse_id(self, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        break;
      }

      case TParser::Return:
      case TParser::Continue: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 95);
        my_parser_parse_flow_control(self, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        break;
      }

      case TParser::INT: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 96);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_INT);
        break;
      }

      case TParser::String: {
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 97);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_STRING);
        break;
      }

    default:
      error = g_error_new(g_quark_from_string("ANTLR"), 200, "NoViableAlt%s", "");
      return NULL;
    }
    ctx->stop = antlr_token_stream_LT(ANTLR_TOKEN_STREAM(ANTLR_PARSER(self)->input), -1);
    setState(117);
    _errHandler->sync(this);// TODO: untested StarBlock
    alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 11, _ctx);
    while (alt != 2 && alt != atn::ATN::INVALID_ALT_NUMBER) {
      if (alt == 1) {
        if (!_parseListeners.empty())
          triggerExitRuleEvent();
        previousContext = _localctx;
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 115); 
        antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
        AntlrATNInterpreter *interpreter = antlr_recognizer_get_interpreter(ANTLR_RECOGNIZER(self));
        switch (antlr_parser_atn_simulator_adaptive_predict(ANTLR_PARSER_ATN_SIMULATOR(interpreter), ANTLR_PARSER(self)->input, 10, ANTLR_PARSER(self)->ctx)) {
        case 1: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 100);

          if (!(precpred(_ctx, 9))){
              error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "precpred(_ctx, 9)");
              return NULL;
          }

          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 101);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_STAR);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 102);
          my_parser_parse_expr(self, 10, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          break;
        }

        case 2: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 103);

          if (!(precpred(_ctx, 8))){
              error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "precpred(_ctx, 8)");
              return NULL;
          }

          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 104);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_PLUS);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 105);
          my_parser_parse_expr(self, 9, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          break;
        }

        case 3: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 106);

          if (!(precpred(_ctx, 6))){
              error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "precpred(_ctx, 6)");
              return NULL;
          }

          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 107);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_QUESTION_MARK);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 108);
          my_parser_parse_expr(self, 0, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 109);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_COLON);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 110);
          my_parser_parse_expr(self, 6, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          break;
        }

        case 4: {
          _localctx = _tracker.createInstance<ExprContext>(parentContext, parentState);
          pushNewRecursionContext(_localctx, startState, RuleExpr);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 112);

          if (!(precpred(_ctx, 5))){
              error = g_error_new(g_quark_from_string("ANTLR"), 200, "FailedPredicate: %s", "precpred(_ctx, 5)");
              return NULL;
          }

          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 113);
          antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_EQUAL);
          antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 114);
          my_parser_parse_expr(self, 5, error);
          if (error && *error) {
              /* TODO: manage error .. */
              return NULL;
          }
          break;
        }

        } 
      }
      setState(119);
      _errHandler->sync(this);// TODO: untested StarBlock
      alt = getInterpreter<atn::ParserATNSimulator>()->adaptivePredict(_input, 11, _ctx);
    }
  }
  catch (RecognitionException &e) {
    _errHandler->reportError(this, e);
    _localctx->exception = std::current_exception();
    _errHandler->recover(this, _localctx->exception);
  }
  return _localctx;
}

//----------------- FlowControlContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_flow_control_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_FLOW_CONTROL;
}

/* virtual AntlrParserRuleContext */

/* virtual GObject */
static void my_context_flow_control_class_init(MyContextFlowControlClass *klass);
static void my_context_flow_control_init(MyContextFlowControl *gobject);

G_DEFINE_TYPE (MyContextFlowControl, my_context_flow_control, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_flow_control_class_init(MyContextFlowControlClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_flow_control_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_flow_control_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_flow_control_class_rule_context_get_rule_index;
}

static void
my_context_flow_control_init (MyContextFlowControl *object)
{
}

MyContextFlowControl *my_context_flow_control_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_FLOW_CONTROL, parent, invoking_state);
    MyContextFlowControl *self = MY_CONTEXT_FLOW_CONTROL(ctx);
    return self;
}



void TParser::FlowControlContext::copyFrom(FlowControlContext *ctx) {
  ParserRuleContext::copyFrom(ctx);
}


//----------------- ReturnContext ------------------------------------------------------------------

AntlrTreeTerminalNode *my_context_return_token_get_return(MyContextReturn* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_RETURN, 0);
}
MyContextExpr *my_context_return_rule_get_expr(MyContextReturn* self) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_EXPR, 0);
    return MY_CONTEXT_EXPR(context);
}
TParser::ReturnContext::ReturnContext(FlowControlContext *ctx) { copyFrom(ctx); }

void my_context_return_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_return(MY_PARSER_LISTENER(listener), MY_CONTEXT_RETURN(self));
}
void my_context_return_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_return(MY_PARSER_LISTENER(listener), MY_CONTEXT_RETURN(self));
}
//----------------- ContinueContext ------------------------------------------------------------------

AntlrTreeTerminalNode *my_context_continue_token_get_continue(MyContextContinue* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_CONTINUE, 0);
}
TParser::ContinueContext::ContinueContext(FlowControlContext *ctx) { copyFrom(ctx); }

void my_context_continue_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_continue(MY_PARSER_LISTENER(listener), MY_CONTEXT_CONTINUE(self));
}
void my_context_continue_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_continue(MY_PARSER_LISTENER(listener), MY_CONTEXT_CONTINUE(self));
}

MyContextFlowControl* my_parser_parse_flow_control(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextFlowControl *local_context = my_context_flow_control_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_FLOW_CONTROL);

    setState(123);
    _errHandler->sync(this);// TODO: untested LL1AltBlock
    switch (_input->LA(1)) {
      case TParser::Return: {
        _localctx = dynamic_cast<FlowControlContext *>(_tracker.createInstance<TParser::ReturnContext>(_localctx));
        antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 120);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_RETURN);
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 121);
        my_parser_parse_expr(self, 0, error);
        if (error && *error) {
            /* TODO: manage error .. */
            return NULL;
        }
        break;
      }

      case TParser::Continue: {
        _localctx = dynamic_cast<FlowControlContext *>(_tracker.createInstance<TParser::ContinueContext>(_localctx));
        antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  2);
        antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 122);
        antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_CONTINUE);
        break;
      }

    default:
      error = g_error_new(g_quark_from_string("ANTLR"), 200, "NoViableAlt%s", "");
      return NULL;
    }

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- IdContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_id_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_ID;
}

/* virtual AntlrParserRuleContext */
void my_context_id_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_id(MY_PARSER_LISTENER(listener), MY_CONTEXT_ID(self));
}

void my_context_id_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_id(MY_PARSER_LISTENER(listener), MY_CONTEXT_ID(self));
}

/* virtual GObject */
static void my_context_id_class_init(MyContextIdClass *klass);
static void my_context_id_init(MyContextId *gobject);

G_DEFINE_TYPE (MyContextId, my_context_id, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_id_class_init(MyContextIdClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_id_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_id_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_id_class_rule_context_get_rule_index;
}

static void
my_context_id_init (MyContextId *object)
{
}

MyContextId *my_context_id_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_ID, parent, invoking_state);
    MyContextId *self = MY_CONTEXT_ID(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_id_token_get_id(MyContextId* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, 0);
}




MyContextId* my_parser_parse_id(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextId *local_context = my_context_id_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_ID);

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 125);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_ID);

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- ArrayContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_array_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_ARRAY;
}

/* virtual AntlrParserRuleContext */
void my_context_array_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_array(MY_PARSER_LISTENER(listener), MY_CONTEXT_ARRAY(self));
}

void my_context_array_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_array(MY_PARSER_LISTENER(listener), MY_CONTEXT_ARRAY(self));
}

/* virtual GObject */
static void my_context_array_class_init(MyContextArrayClass *klass);
static void my_context_array_init(MyContextArray *gobject);

G_DEFINE_TYPE (MyContextArray, my_context_array, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_array_class_init(MyContextArrayClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_array_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_array_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_array_class_rule_context_get_rule_index;
}

static void
my_context_array_init (MyContextArray *object)
{
}

MyContextArray *my_context_array_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_ARRAY, parent, invoking_state);
    MyContextArray *self = MY_CONTEXT_ARRAY(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_array_token_get_open_curly(MyContextArray* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_OPEN_CURLY, 0);
}
AntlrTreeTerminalNode *my_context_array_token_get_close_curly(MyContextArray* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_CLOSE_CURLY, 0);
}
GList* my_context_array_token_get_int(MyContextArray* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_INT);
}
AntlrTreeTerminalNode *my_context_array_at_token_get_int(MyContextArray* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_INT, i);
}
GList* my_context_array_token_get_comma(MyContextArray* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COMMA);
}
AntlrTreeTerminalNode *my_context_array_at_token_get_comma(MyContextArray* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COMMA, i);
}




MyContextArray* my_parser_parse_array(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextArray *local_context = my_context_array_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_ARRAY);
    size_t _la = 0;

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 127);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_OPEN_CURLY);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 128);
    MY_CONTEXT_ARRAY(local_context)->intToken = 
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_INT);
    MY_CONTEXT_ARRAY(local_context)->el.push_back(MY_CONTEXT_ARRAY(local_context)->intToken);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 133);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    while (_la == MY_PARSER_COMMA) {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 129);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_COMMA);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 130);
      MY_CONTEXT_ARRAY(local_context)->intToken = 
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_INT);
      MY_CONTEXT_ARRAY(local_context)->el.push_back(MY_CONTEXT_ARRAY(local_context)->intToken);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 135);
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    }
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 136);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_CLOSE_CURLY);

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- IdarrayContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_idarray_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_IDARRAY;
}

/* virtual AntlrParserRuleContext */
void my_context_idarray_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_idarray(MY_PARSER_LISTENER(listener), MY_CONTEXT_IDARRAY(self));
}

void my_context_idarray_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_idarray(MY_PARSER_LISTENER(listener), MY_CONTEXT_IDARRAY(self));
}

/* virtual GObject */
static void my_context_idarray_class_init(MyContextIdarrayClass *klass);
static void my_context_idarray_init(MyContextIdarray *gobject);

G_DEFINE_TYPE (MyContextIdarray, my_context_idarray, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_idarray_class_init(MyContextIdarrayClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_idarray_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_idarray_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_idarray_class_rule_context_get_rule_index;
}

static void
my_context_idarray_init (MyContextIdarray *object)
{
}

MyContextIdarray *my_context_idarray_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_IDARRAY, parent, invoking_state);
    MyContextIdarray *self = MY_CONTEXT_IDARRAY(ctx);
    return self;
}

AntlrTreeTerminalNode *my_context_idarray_token_get_open_curly(MyContextIdarray* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_OPEN_CURLY, 0);
}
AntlrTreeTerminalNode *my_context_idarray_token_get_close_curly(MyContextIdarray* self) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_CLOSE_CURLY, 0);
}
GList* my_context_idarray_rule_get_id(MyContextIdarray* self) {
    return antlr_parser_rule_context_get_rule_contexts(ANTLR_PASER_RULE_CONTEXT(self));
}
MyContextId* my_context_idarray_at_rule_get_id(MyContextIdarray* self, size_t i) {
    AntlrParserRuleContext *context = antlr_parser_rule_context_get_rule_context(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_ID, i);
    return MY_CONTEXT_ID(context);
}
GList* my_context_idarray_token_get_comma(MyContextIdarray* self) {
    return antlr_parser_rule_context_get_tokens(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COMMA);
}
AntlrTreeTerminalNode *my_context_idarray_at_token_get_comma(MyContextIdarray* self, size_t i) {
    return antlr_parser_rule_context_get_token(ANTLR_PASER_RULE_CONTEXT(self), MY_PARSER_COMMA, i);
}




MyContextIdarray* my_parser_parse_idarray(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextIdarray *local_context = my_context_idarray_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_IDARRAY);
    size_t _la = 0;

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 138);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_OPEN_CURLY);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 139);
    MY_CONTEXT_IDARRAY(local_context)->idContext = my_parser_parse_id(self, error);
    if (error && *error) {
        /* TODO: manage error .. */
        return NULL;
    }
    MY_CONTEXT_IDARRAY(local_context)->element.push_back(MY_CONTEXT_IDARRAY(local_context)->idContext);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 144);
    antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
    _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    while (_la == MY_PARSER_COMMA) {
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 140);
      antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_COMMA);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 141);
      MY_CONTEXT_IDARRAY(local_context)->idContext = my_parser_parse_id(self, error);
      if (error && *error) {
          /* TODO: manage error .. */
          return NULL;
      }
      MY_CONTEXT_IDARRAY(local_context)->element.push_back(MY_CONTEXT_IDARRAY(local_context)->idContext);
      antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 146);
      antlr_error_strategy_sync(ANTLR_PARSER(self)->err_handler, ANTLR_PARSER(self));
      _la = antlr_int_stream_LA(ANTLR_INT_STREAM(ANTLR_PARSER(self)->input), 1);
    }
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 147);
    antlr_parser_match(ANTLR_PARSER(self), MY_PARSER_CLOSE_CURLY);

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


//----------------- AnyContext ------------------------------------------------------------------

/* virtual AntlrRuleContext */
gint my_context_any_class_rule_context_get_rule_index(AntlrRuleContext *self) {
  return MY_PARSER_ANY;
}

/* virtual AntlrParserRuleContext */
void my_context_any_class_parser_rule_context_enter_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_enter_any(MY_PARSER_LISTENER(listener), MY_CONTEXT_ANY(self));
}

void my_context_any_class_parser_rule_context_exit_rule(AntlrParserRuleContext *self, AntlrParseTreeListener *listener) {
    my_parser_listener_exit_any(MY_PARSER_LISTENER(listener), MY_CONTEXT_ANY(self));
}

/* virtual GObject */
static void my_context_any_class_init(MyContextAnyClass *klass);
static void my_context_any_init(MyContextAny *gobject);

G_DEFINE_TYPE (MyContextAny, my_context_any, ANTLR_TYPE_PARSER_RULE_CONTEXT)

static void
my_context_any_class_init(MyContextAnyClass *klass)
{
    AntlrParserRuleContextClass *parserrulecontext_class;
    AntlrRuleContextClass *rulecontext_class;

    rulecontext_class = (AntlrRuleContextClass *) klass;
    parserrulecontext_class = (AntlrParserRuleContextClass *) klass;

    parserrulecontext_class->enter_rule = my_context_any_class_parser_rule_context_enter_rule;
    parserrulecontext_class->exit_rule = my_context_any_class_parser_rule_context_exit_rule;

    rulecontext_class->get_rule_index = my_context_any_class_rule_context_get_rule_index;
}

static void
my_context_any_init (MyContextAny *object)
{
}

MyContextAny *my_context_any_new(AntlrParserRuleContext *parent, size_t invoking_state)
{
    AntlrParserRuleContext *ctx = antlr_parser_rule_context_super_with_parent(MY_TYPE_CONTEXT_ANY, parent, invoking_state);
    MyContextAny *self = MY_CONTEXT_ANY(ctx);
    return self;
}





MyContextAny* my_parser_parse_any(MyParser* self, GError **error) {
    AntlrParserRuleContext *ctx = ANTLR_PARSER(self)->ctx;
    gint state = antlr_recognizer_get_state(ANTLR_RECOGNIZER(self));
    MyContextAny *local_context = my_context_any_new(ctx, state);

    antlr_parser_enter_rule(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context), 0, MY_PARSER_ANY);

    antlr_parser_enter_outer_alt(ANTLR_PARSER(self), ANTLR_PARSER_RULE_CONTEXT(local_context),  1);
    antlr_recognizer_set_state(ANTLR_RECOGNIZER(self), 149);
    MY_CONTEXT_ANY(local_context)->t = antlr_parser_match_wildcard(ANTLR_PARSER(self)); /* TODO */

    antlr_parser_exit_rule(ANTLR_PARSER(self));

    return local_context;
}


bool my_parser_sempred(MyParser *self, AntlrRuleContext *context, size_t ruleIndex, size_t predicateIndex) {
  switch (ruleIndex) {
    case 1: return my_parser_sempred_divide(self, context, predicateIndex);
    case 3: return my_parser_sempred_conquer(self, context, predicateIndex);
    case 7: return my_parser_sempred_expr(self, context, predicateIndex);

  default:
    break;
  }
  return true;
}

gboolean my_parser_sempred_divide(MyParser* self, AntlrRuleContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 0: return doesItBlend();

  default:
    break;
  }
  return true;
}

gboolean my_parser_sempred_conquer(MyParser* self, AntlrRuleContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 1: return doesItBlend();

  default:
    break;
  }
  return true;
}

gboolean my_parser_sempred_expr(MyParser* self, AntlrRuleContext *_localctx, size_t predicateIndex) {
  switch (predicateIndex) {
    case 2: return precpred(_ctx, 9);
    case 3: return precpred(_ctx, 8);
    case 4: return precpred(_ctx, 6);
    case 5: return precpred(_ctx, 5);

  default:
    break;
  }
  return true;
}

