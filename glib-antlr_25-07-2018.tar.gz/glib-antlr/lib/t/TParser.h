/* parser/listener/visitor header section */

// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/t/TParser.g4 by ANTLR 4.6

/* parser precinclude section */

#include "antlr4-runtime.h"


/* parser postinclude section */


/* parser context section */


#ifndef __MY_PARSER_H__
#define __MY_PARSER_H__

#include <glib-object.h>

G_BEGIN_DECLS

typedef enum _MyParserTokens  MyParserTokens;
typedef enum _MyParserRules   MyParserRules;

enum _MyParserTokens {
  MY_PARSER_DUMMY = 1, MY_PARSER_RETURN = 2, MY_PARSER_CONTINUE = 3, MY_PARSER_INT = 4, 
  MY_PARSER_DIGIT = 5, MY_PARSER_ID = 6, MY_PARSER_LESS_THAN = 7, MY_PARSER_GREATER_THAN = 8, 
  MY_PARSER_EQUAL = 9, MY_PARSER_AND = 10, MY_PARSER_COLON = 11, MY_PARSER_SEMICOLON = 12, 
  MY_PARSER_PLUS = 13, MY_PARSER_MINUS = 14, MY_PARSER_STAR = 15, MY_PARSER_OPEN_PAR = 16, 
  MY_PARSER_CLOSE_PAR = 17, MY_PARSER_OPEN_CURLY = 18, MY_PARSER_CLOSE_CURLY = 19, 
  MY_PARSER_QUESTION_MARK = 20, MY_PARSER_COMMA = 21, MY_PARSER_STRING = 22, 
  MY_PARSER_FOO = 23, MY_PARSER_BAR = 24, MY_PARSER_ANY = 25, MY_PARSER_COMMENT = 26, 
  MY_PARSER_WS = 27, MY_PARSER_DOT = 28, MY_PARSER_DOT_DOT = 29
};

enum _MyParserRules {
    MY_PARSER_MAIN = 0, MY_PARSER_DIVIDE = 1, MY_PARSER_AND = 2, MY_PARSER_CONQUER = 3, 
    MY_PARSER_UNUSED = 4, MY_PARSER_UNUSED2 = 5, MY_PARSER_STAT = 6, MY_PARSER_EXPR = 7, 
    MY_PARSER_FLOW_CONTROL = 8, MY_PARSER_ID = 9, MY_PARSER_ARRAY = 10, 
    MY_PARSER_IDARRAY = 11, MY_PARSER_ANY = 12
};

#define MY_TYPE_PARSER            (my_parser_get_type())
#define MY_PARSER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_PARSER, MyParser))
#define MY_PARSER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_PARSER, MyParserClass))
#define MY_IS_PARSER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_PARSER))
#define MY_IS_PARSER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_PARSER))
#define MY_PARSER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_PARSER, MyParserClass))

typedef struct _MyParser      MyParser;
typedef struct _MyParserClass MyParserClass;

struct _MyParser {
    /*< private >*/
    AntlrParser parent_instance;

    GArray *rule_names;
};

struct _MyParserClass {
    /*< private >*/
    AntlrParserClass parent_class;
};

GType my_parser_get_type(void) G_GNUC_CONST;
MyParser *my_parser_new();


/* public parser declarations/members section */
bool myAction() { return true; }
bool doesItBlend() { return true; }
void cleanUp() {}
void doInit() {}
void doAfter() {}


//----------------- MainContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_MAIN            (my_context_main_get_type())
#define MY_CONTEXT_MAIN(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_MAIN, MyContextMain))
#define MY_CONTEXT_MAIN_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_MAIN, MyContextMainClass))
#define MY_IS_CONTEXT_MAIN(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_MAIN))
#define MY_IS_CONTEXT_MAIN_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_MAIN))
#define MY_CONTEXT_MAIN_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_MAIN, MyContextMainClass))


typedef struct _MyContextMain      MyContextMain;
typedef struct _MyContextMainClass MyContextMainClass;

struct _MyContextMain {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextMainClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_main_get_type(void) G_GNUC_CONST;
MyContextMain *my_context_main_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTreeTerminalNode *my_context_main_token_get_eof(MyContextMain* self);
GList* my_context_main_rule_get_stat(MyContextMain* self);// of MyContextStat
MyContextStat* my_context_main_at_rule_get_stat(MyContextMain* self, size_t i);


MyContextMain* my_parser_parse_main(MyParser* self, GError **error);
//----------------- DivideContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_DIVIDE            (my_context_divide_get_type())
#define MY_CONTEXT_DIVIDE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_DIVIDE, MyContextDivide))
#define MY_CONTEXT_DIVIDE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_DIVIDE, MyContextDivideClass))
#define MY_IS_CONTEXT_DIVIDE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_DIVIDE))
#define MY_IS_CONTEXT_DIVIDE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_DIVIDE))
#define MY_CONTEXT_DIVIDE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_DIVIDE, MyContextDivideClass))


typedef struct _MyContextDivide      MyContextDivide;
typedef struct _MyContextDivideClass MyContextDivideClass;

struct _MyContextDivide {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextDivideClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_divide_get_type(void) G_GNUC_CONST;
MyContextDivide *my_context_divide_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTreeTerminalNode *my_context_divide_token_get_id(MyContextDivide* self);
MyContextAnd *my_context_divide_rule_get_and(MyContextDivide* self);
AntlrTreeTerminalNode *my_context_divide_token_get_greater_than(MyContextDivide* self);


MyContextDivide* my_parser_parse_divide(MyParser* self, GError **error);
//----------------- AndContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_AND            (my_context_and_get_type())
#define MY_CONTEXT_AND(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_AND, MyContextAnd))
#define MY_CONTEXT_AND_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_AND, MyContextAndClass))
#define MY_IS_CONTEXT_AND(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_AND))
#define MY_IS_CONTEXT_AND_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_AND))
#define MY_CONTEXT_AND_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_AND, MyContextAndClass))


typedef struct _MyContextAnd      MyContextAnd;
typedef struct _MyContextAndClass MyContextAndClass;

struct _MyContextAnd {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextAndClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_and_get_type(void) G_GNUC_CONST;
MyContextAnd *my_context_and_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTreeTerminalNode *my_context_and_token_get_and(MyContextAnd* self);


MyContextAnd* my_parser_parse_and(MyParser* self, GError **error);
//----------------- ConquerContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_CONQUER            (my_context_conquer_get_type())
#define MY_CONTEXT_CONQUER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CONQUER, MyContextConquer))
#define MY_CONTEXT_CONQUER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CONQUER, MyContextConquerClass))
#define MY_IS_CONTEXT_CONQUER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CONQUER))
#define MY_IS_CONTEXT_CONQUER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CONQUER))
#define MY_CONTEXT_CONQUER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CONQUER, MyContextConquerClass))


typedef struct _MyContextConquer      MyContextConquer;
typedef struct _MyContextConquerClass MyContextConquerClass;

struct _MyContextConquer {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
    Token *idToken = nullptr;;
};

struct _MyContextConquerClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_conquer_get_type(void) G_GNUC_CONST;
MyContextConquer *my_context_conquer_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_conquer_rule_get_divide(MyContextConquer* self);// of MyContextDivide
MyContextDivide* my_context_conquer_at_rule_get_divide(MyContextConquer* self, size_t i);
MyContextAnd *my_context_conquer_rule_get_and(MyContextConquer* self);
AntlrTreeTerminalNode *my_context_conquer_token_get_id(MyContextConquer* self);
GList* my_context_conquer_token_get_less_than(MyContextConquer* self);// of AntlrTreeTerminalNode*
AntlrTreeTerminalNode *my_context_conquer_at_token_get_less_than(MyContextConquer* self, size_t i);


MyContextConquer* my_parser_parse_conquer(MyParser* self, GError **error);
//----------------- UnusedContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_UNUSED            (my_context_unused_get_type())
#define MY_CONTEXT_UNUSED(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_UNUSED, MyContextUnused))
#define MY_CONTEXT_UNUSED_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_UNUSED, MyContextUnusedClass))
#define MY_IS_CONTEXT_UNUSED(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_UNUSED))
#define MY_IS_CONTEXT_UNUSED_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_UNUSED))
#define MY_CONTEXT_UNUSED_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_UNUSED, MyContextUnusedClass))


typedef struct _MyContextUnused      MyContextUnused;
typedef struct _MyContextUnusedClass MyContextUnusedClass;

struct _MyContextUnused {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
    double input;
    double calculated;
    int _a;
    double _b;
    int _c;
};

struct _MyContextUnusedClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_unused_get_type(void) G_GNUC_CONST;
MyContextUnused *my_context_unused_new(AntlrParserRuleContext *parent, size_t invokingState);

MyContextStat *my_context_unused_rule_get_stat(MyContextUnused* self);


MyContextUnused* my_parser_parse_unused(MyParser* self, double input, GError **error);
//----------------- Unused2Context ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_UNUSED2            (my_context_unused2_get_type())
#define MY_CONTEXT_UNUSED2(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_UNUSED2, MyContextUnused2))
#define MY_CONTEXT_UNUSED2_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_UNUSED2, MyContextUnused2Class))
#define MY_IS_CONTEXT_UNUSED2(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_UNUSED2))
#define MY_IS_CONTEXT_UNUSED2_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_UNUSED2))
#define MY_CONTEXT_UNUSED2_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_UNUSED2, MyContextUnused2Class))


typedef struct _MyContextUnused2      MyContextUnused2;
typedef struct _MyContextUnused2Class MyContextUnused2Class;

struct _MyContextUnused2 {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextUnused2Class {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_unused2_get_type(void) G_GNUC_CONST;
MyContextUnused2 *my_context_unused2_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_unused2_token_get_semicolon(MyContextUnused2* self);// of AntlrTreeTerminalNode*
AntlrTreeTerminalNode *my_context_unused2_at_token_get_semicolon(MyContextUnused2* self, size_t i);
GList* my_context_unused2_rule_get_unused(MyContextUnused2* self);// of MyContextUnused
MyContextUnused* my_context_unused2_at_rule_get_unused(MyContextUnused2* self, size_t i);
AntlrTreeTerminalNode *my_context_unused2_token_get_colon(MyContextUnused2* self);
AntlrTreeTerminalNode *my_context_unused2_token_get_plus(MyContextUnused2* self);


MyContextUnused2* my_parser_parse_unused2(MyParser* self, GError **error);
//----------------- StatContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_STAT            (my_context_stat_get_type())
#define MY_CONTEXT_STAT(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_STAT, MyContextStat))
#define MY_CONTEXT_STAT_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_STAT, MyContextStatClass))
#define MY_IS_CONTEXT_STAT(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_STAT))
#define MY_IS_CONTEXT_STAT_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_STAT))
#define MY_CONTEXT_STAT_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_STAT, MyContextStatClass))


typedef struct _MyContextStat      MyContextStat;
typedef struct _MyContextStatClass MyContextStatClass;

struct _MyContextStat {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextStatClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_stat_get_type(void) G_GNUC_CONST;
MyContextStat *my_context_stat_new(AntlrParserRuleContext *parent, size_t invokingState);

GList* my_context_stat_rule_get_expr(MyContextStat* self);// of MyContextExpr
MyContextExpr* my_context_stat_at_rule_get_expr(MyContextStat* self, size_t i);
AntlrTreeTerminalNode *my_context_stat_token_get_equal(MyContextStat* self);
AntlrTreeTerminalNode *my_context_stat_token_get_semicolon(MyContextStat* self);


MyContextStat* my_parser_parse_stat(MyParser* self, GError **error);
//----------------- ExprContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_EXPR            (my_context_expr_get_type())
#define MY_CONTEXT_EXPR(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_EXPR, MyContextExpr))
#define MY_CONTEXT_EXPR_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_EXPR, MyContextExprClass))
#define MY_IS_CONTEXT_EXPR(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_EXPR))
#define MY_IS_CONTEXT_EXPR_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_EXPR))
#define MY_CONTEXT_EXPR_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_EXPR, MyContextExprClass))


typedef struct _MyContextExpr      MyContextExpr;
typedef struct _MyContextExprClass MyContextExprClass;

struct _MyContextExpr {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
    TParser::IdContext *identifier = nullptr;;
};

struct _MyContextExprClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_expr_get_type(void) G_GNUC_CONST;
MyContextExpr *my_context_expr_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTreeTerminalNode *my_context_expr_token_get_open_par(MyContextExpr* self);
GList* my_context_expr_rule_get_expr(MyContextExpr* self);// of MyContextExpr
MyContextExpr* my_context_expr_at_rule_get_expr(MyContextExpr* self, size_t i);
AntlrTreeTerminalNode *my_context_expr_token_get_close_par(MyContextExpr* self);
MyContextId *my_context_expr_rule_get_id(MyContextExpr* self);
MyContextFlowControl *my_context_expr_rule_get_flow_control(MyContextExpr* self);
AntlrTreeTerminalNode *my_context_expr_token_get_int(MyContextExpr* self);
AntlrTreeTerminalNode *my_context_expr_token_get_string(MyContextExpr* self);
AntlrTreeTerminalNode *my_context_expr_token_get_star(MyContextExpr* self);
AntlrTreeTerminalNode *my_context_expr_token_get_plus(MyContextExpr* self);
AntlrTreeTerminalNode *my_context_expr_token_get_question_mark(MyContextExpr* self);
AntlrTreeTerminalNode *my_context_expr_token_get_colon(MyContextExpr* self);
AntlrTreeTerminalNode *my_context_expr_token_get_equal(MyContextExpr* self);



MyContextExpr* my_parser_parse_expr(MyParser* self, GError **error);
MyContextExpr* my_parser_parse_expr(MyParser* self, int precedence, GError **error);

//----------------- FlowControlContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_FLOW_CONTROL            (my_context_flow_control_get_type())
#define MY_CONTEXT_FLOW_CONTROL(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_FLOW_CONTROL, MyContextFlowControl))
#define MY_CONTEXT_FLOW_CONTROL_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_FLOW_CONTROL, MyContextFlowControlClass))
#define MY_IS_CONTEXT_FLOW_CONTROL(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_FLOW_CONTROL))
#define MY_IS_CONTEXT_FLOW_CONTROL_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_FLOW_CONTROL))
#define MY_CONTEXT_FLOW_CONTROL_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_FLOW_CONTROL, MyContextFlowControlClass))


typedef struct _MyContextFlowControl      MyContextFlowControl;
typedef struct _MyContextFlowControlClass MyContextFlowControlClass;

struct _MyContextFlowControl {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextFlowControlClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_flow_control_get_type(void) G_GNUC_CONST;
MyContextFlowControl *my_context_flow_control_new(AntlrParserRuleContext *parent, size_t invokingState);



#define MY_TYPE_CONTEXT_RETURN            (my_context_return_get_type())
#define MY_CONTEXT_RETURN(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_RETURN, MyContextReturn))
#define MY_CONTEXT_RETURN_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_RETURN, MyContextReturnClass))
#define MY_IS_CONTEXT_RETURN(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_RETURN))
#define MY_IS_CONTEXT_RETURN_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_RETURN))
#define MY_CONTEXT_RETURN_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_RETURN, MyContextReturnClass))


typedef struct _MyContextReturn      MyContextReturn;
typedef struct _MyContextReturnClass MyContextReturnClass;

struct _MyContextReturn {
    /*< private >*/
    MyContextFlowControl parent_instance;

    /*< public >*/
};

struct _MyContextReturnClass {
    /*< private >*/
    MyContextFlowControlClass parent_class;
};

GType my_context_return_get_type(void) G_GNUC_CONST;
MyContextReturn *my_context_return_new(MyContextFlowControl *ctx);

AntlrTreeTerminalNode *my_context_return_token_get_return(MyContextReturn* self);
MyContextExpr *my_context_return_rule_get_expr(MyContextReturn* self);



#define MY_TYPE_CONTEXT_CONTINUE            (my_context_continue_get_type())
#define MY_CONTEXT_CONTINUE(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_CONTINUE, MyContextContinue))
#define MY_CONTEXT_CONTINUE_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_CONTINUE, MyContextContinueClass))
#define MY_IS_CONTEXT_CONTINUE(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_CONTINUE))
#define MY_IS_CONTEXT_CONTINUE_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_CONTINUE))
#define MY_CONTEXT_CONTINUE_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_CONTINUE, MyContextContinueClass))


typedef struct _MyContextContinue      MyContextContinue;
typedef struct _MyContextContinueClass MyContextContinueClass;

struct _MyContextContinue {
    /*< private >*/
    MyContextFlowControl parent_instance;

    /*< public >*/
};

struct _MyContextContinueClass {
    /*< private >*/
    MyContextFlowControlClass parent_class;
};

GType my_context_continue_get_type(void) G_GNUC_CONST;
MyContextContinue *my_context_continue_new(MyContextFlowControl *ctx);

AntlrTreeTerminalNode *my_context_continue_token_get_continue(MyContextContinue* self);


MyContextFlowControl* my_parser_parse_flow_control(MyParser* self, GError **error);
//----------------- IdContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ID            (my_context_id_get_type())
#define MY_CONTEXT_ID(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ID, MyContextId))
#define MY_CONTEXT_ID_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ID, MyContextIdClass))
#define MY_IS_CONTEXT_ID(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ID))
#define MY_IS_CONTEXT_ID_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ID))
#define MY_CONTEXT_ID_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ID, MyContextIdClass))


typedef struct _MyContextId      MyContextId;
typedef struct _MyContextIdClass MyContextIdClass;

struct _MyContextId {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
};

struct _MyContextIdClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_id_get_type(void) G_GNUC_CONST;
MyContextId *my_context_id_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTreeTerminalNode *my_context_id_token_get_id(MyContextId* self);


MyContextId* my_parser_parse_id(MyParser* self, GError **error);
//----------------- ArrayContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ARRAY            (my_context_array_get_type())
#define MY_CONTEXT_ARRAY(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ARRAY, MyContextArray))
#define MY_CONTEXT_ARRAY_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ARRAY, MyContextArrayClass))
#define MY_IS_CONTEXT_ARRAY(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ARRAY))
#define MY_IS_CONTEXT_ARRAY_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ARRAY))
#define MY_CONTEXT_ARRAY_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ARRAY, MyContextArrayClass))


typedef struct _MyContextArray      MyContextArray;
typedef struct _MyContextArrayClass MyContextArrayClass;

struct _MyContextArray {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
    Token *intToken = nullptr;;
    std::vector<Token *> el;;
};

struct _MyContextArrayClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_array_get_type(void) G_GNUC_CONST;
MyContextArray *my_context_array_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTreeTerminalNode *my_context_array_token_get_open_curly(MyContextArray* self);
AntlrTreeTerminalNode *my_context_array_token_get_close_curly(MyContextArray* self);
GList* my_context_array_token_get_int(MyContextArray* self);// of AntlrTreeTerminalNode*
AntlrTreeTerminalNode *my_context_array_at_token_get_int(MyContextArray* self, size_t i);
GList* my_context_array_token_get_comma(MyContextArray* self);// of AntlrTreeTerminalNode*
AntlrTreeTerminalNode *my_context_array_at_token_get_comma(MyContextArray* self, size_t i);


MyContextArray* my_parser_parse_array(MyParser* self, GError **error);
//----------------- IdarrayContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_IDARRAY            (my_context_idarray_get_type())
#define MY_CONTEXT_IDARRAY(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_IDARRAY, MyContextIdarray))
#define MY_CONTEXT_IDARRAY_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_IDARRAY, MyContextIdarrayClass))
#define MY_IS_CONTEXT_IDARRAY(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_IDARRAY))
#define MY_IS_CONTEXT_IDARRAY_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_IDARRAY))
#define MY_CONTEXT_IDARRAY_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_IDARRAY, MyContextIdarrayClass))


typedef struct _MyContextIdarray      MyContextIdarray;
typedef struct _MyContextIdarrayClass MyContextIdarrayClass;

struct _MyContextIdarray {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
    TParser::IdContext *idContext = nullptr;;
    std::vector<IdContext *> element;;
};

struct _MyContextIdarrayClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_idarray_get_type(void) G_GNUC_CONST;
MyContextIdarray *my_context_idarray_new(AntlrParserRuleContext *parent, size_t invokingState);

AntlrTreeTerminalNode *my_context_idarray_token_get_open_curly(MyContextIdarray* self);
AntlrTreeTerminalNode *my_context_idarray_token_get_close_curly(MyContextIdarray* self);
GList* my_context_idarray_rule_get_id(MyContextIdarray* self);// of MyContextId
MyContextId* my_context_idarray_at_rule_get_id(MyContextIdarray* self, size_t i);
GList* my_context_idarray_token_get_comma(MyContextIdarray* self);// of AntlrTreeTerminalNode*
AntlrTreeTerminalNode *my_context_idarray_at_token_get_comma(MyContextIdarray* self, size_t i);


MyContextIdarray* my_parser_parse_idarray(MyParser* self, GError **error);
//----------------- AnyContext ------------------------------------------------------------------

#define MY_TYPE_CONTEXT_ANY            (my_context_any_get_type())
#define MY_CONTEXT_ANY(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_CONTEXT_ANY, MyContextAny))
#define MY_CONTEXT_ANY_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_CONTEXT_ANY, MyContextAnyClass))
#define MY_IS_CONTEXT_ANY(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_CONTEXT_ANY))
#define MY_IS_CONTEXT_ANY_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_CONTEXT_ANY))
#define MY_CONTEXT_ANY_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_CONTEXT_ANY, MyContextAnyClass))


typedef struct _MyContextAny      MyContextAny;
typedef struct _MyContextAnyClass MyContextAnyClass;

struct _MyContextAny {
    /*< private >*/
    AntlrParserRuleContext parent_instance;

    /*< public >*/
    Token *t = nullptr;;
};

struct _MyContextAnyClass {
    /*< private >*/
    AntlrParserRuleContextClass parent_class;
};

GType my_context_any_get_type(void) G_GNUC_CONST;
MyContextAny *my_context_any_new(AntlrParserRuleContext *parent, size_t invokingState);



MyContextAny* my_parser_parse_any(MyParser* self, GError **error);

gboolean my_parser_sempred(MyParser *self, AntlrRuleContext *_localctx, size_t ruleIndex, size_t predicateIndex);
gboolean my_parser_sempred_divide(MyParser* self, AntlrRuleContext *_localctx, size_t predicateIndex);
gboolean my_parser_sempred_conquer(MyParser* self, AntlrRuleContext *_localctx, size_t predicateIndex);
gboolean my_parser_sempred_expr(MyParser* self, AntlrRuleContext *_localctx, size_t predicateIndex);

/* private parser declarations section */


G_END_DECLS

#endif /* __MY_PARSER_H__ */

