/* lexer header section */

// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/t/TLexer.g4 by ANTLR 4.6

/* lexer context section */


#ifndef __MY_LEXER_H__
#define __MY_LEXER_H__

#include <glib-object.h>

G_BEGIN_DECLS

typedef enum _MyLexerSymbols  MyLexerSymbols;
typedef enum _MyLexerChannels MyLexerChannels;
typedef enum _MyLexerRules    MyLexerRules;


enum _MyLexerSymbols {
  MY_LEXER_SYMBOL_DUMMY = 1, MY_LEXER_SYMBOL_RETURN = 2, MY_LEXER_SYMBOL_CONTINUE = 3, 
  MY_LEXER_SYMBOL_INT = 4, MY_LEXER_SYMBOL_DIGIT = 5, MY_LEXER_SYMBOL_ID = 6, 
  MY_LEXER_SYMBOL_LESSTHAN = 7, MY_LEXER_SYMBOL_GREATERTHAN = 8, MY_LEXER_SYMBOL_EQUAL = 9, 
  MY_LEXER_SYMBOL_AND = 10, MY_LEXER_SYMBOL_COLON = 11, MY_LEXER_SYMBOL_SEMICOLON = 12, 
  MY_LEXER_SYMBOL_PLUS = 13, MY_LEXER_SYMBOL_MINUS = 14, MY_LEXER_SYMBOL_STAR = 15, 
  MY_LEXER_SYMBOL_OPENPAR = 16, MY_LEXER_SYMBOL_CLOSEPAR = 17, MY_LEXER_SYMBOL_OPENCURLY = 18, 
  MY_LEXER_SYMBOL_CLOSECURLY = 19, MY_LEXER_SYMBOL_QUESTIONMARK = 20, MY_LEXER_SYMBOL_COMMA = 21, 
  MY_LEXER_SYMBOL_STRING = 22, MY_LEXER_SYMBOL_FOO = 23, MY_LEXER_SYMBOL_BAR = 24, 
  MY_LEXER_SYMBOL_ANY = 25, MY_LEXER_SYMBOL_COMMENT = 26, MY_LEXER_SYMBOL_WS = 27, 
  MY_LEXER_SYMBOL_DOT = 28, MY_LEXER_SYMBOL_DOTDOT = 29
};

enum _MyLexerChannels {
  MY_LEXER_CHANNEL_COMMENTS = 2, MY_LEXER_CHANNEL_DIRECTIVE = 3
};

enum _MyLexerRules {
  MY_LEXER_RULE_MODE1 = 1,
  MY_LEXER_RULE_MODE2 = 2,
};



#define MY_TYPE_LEXER            (my_lexer_get_type())
#define MY_LEXER(obj)            (G_TYPE_CHECK_INSTANCE_CAST ((obj), MY_TYPE_LEXER, MyLexer))
#define MY_LEXER_CLASS(klass)    (G_TYPE_CHECK_CLASS_CAST ((klass),  MY_TYPE_LEXER, MyLexerClass))
#define MY_IS_LEXER(obj)         (G_TYPE_CHECK_INSTANCE_TYPE ((obj), MY_TYPE_LEXER))
#define MY_IS_LEXER_CLASS(klass) (G_TYPE_CHECK_CLASS_TYPE ((klass),  MY_TYPE_LEXER))
#define MY_LEXER_GET_CLASS(obj)  (G_TYPE_INSTANCE_GET_CLASS ((obj),  MY_TYPE_LEXER, MyLexerClass))

typedef struct _MyLexer      MyLexer;
typedef struct _MyLexerClass MyLexerClass;

struct _MyLexer {
    /*< private >*/
    AntlrLexer parent_instance;
};

struct _MyLexerClass {
    /*< private >*/
    AntlrLexerClass parent_class;
};

GType my_lexer_get_type(void) G_GNUC_CONST;
MyLexer *my_lexer_new();

MyLexer *my_lexer_new_with_char_stream (AntlrCharStream *char_stream);

/* start public lexer declarations section */
gboolean canTestFoo(/*TLexer *self*/);
gboolean isItFoo();
gboolean isItBar();

void myFooLexerAction();
void myBarLexerAction();
/* end public lexer declarations section */

void my_lexer_action(MyLexer* self, AntlrRuleContext *context, size_t ruleIndex, size_t actionIndex);
gboolean my_lexer_sempred(MyLexer* self, AntlrRuleContext *_localctx, size_t ruleIndex, size_t predicateIndex);

/* private lexer declarations/members section */

// Individual action functions triggered by action() above.
void my_lexer_action_foo(MyLexer* self, AntlrRuleContext *context, size_t actionIndex);
void my_lexer_action_bar(MyLexer* self, AntlrRuleContext *context, size_t actionIndex);

// Individual semantic predicate functions triggered by sempred() above.
gboolean my_lexer_sempred_foo(MyLexer* self, AntlrRuleContext *_localctx, size_t predicateIndex);
gboolean my_lexer_sempred_bar(MyLexer* self, AntlrRuleContext *_localctx, size_t predicateIndex);


G_END_DECLS

#endif /* __MY_LEXER_H__ */

