/* parser/listener/visitor header section */

// Generated from /home/gaulouis/local/src/glib-antlr/share/grammar/t/TParser.g4 by ANTLR 4.6

/* listener preinclude section */

#include "TParserListener.h"

/* listener postinclude section */

using namespace T;

/* listener definitions section */